import os
import json


def load_json_test_data_file(json_file):
    if 'APITESTDATADIRECTORY' not in os.environ:
        raise EnvironmentError('APITESTDATADIRECTORY environment variable not set')

    file_dir = str(os.environ['APITESTDATADIRECTORY'])
    return json.load(open(os.path.join(file_dir, json_file)))
