import requests
import json
import re
from datetime import datetime, time, timezone
import os
from .session_security import Security
from idaptive_automation.api_payloads import AdvanceAuthentication, MultiOperationAdvanceAuthentication
from idaptive_automation.api_payloads import ApiResult


class ApiSession:
    def __init__(self,
                 base_url,
                 tenant_id,
                 username,
                 password,
                 start_auth=True,
                 auto_auth=True,
                 test_name=None,
                 db_metrics=True):
        """
        :param base_url: the url of the tenant
        :param tenant_id: the id of the tenant
        :param username: the username for authentication on the tenant
        :param password: the password for authentication on the tenant
        :param start_auth: Automatically start authentication for this client?
        :param auto_auth:  Automatically advance authentication for this client?
        :param test_name: the name of the test being run
        :param db_metrics: this flag determines if a metric db record should be inserted
        """
        self.headers = {'X-CENTRIFY-NATIVE-CLIENT': 'true', 'Content-type': 'application/json'}
        self.headers_url_encoded = {'X-CENTRIFY-NATIVE-CLIENT': 'true',
                                    'Content-type': 'application/x-www-form-urlencoded'}
        self.session = requests.sessions.Session()
        self.base_url = base_url
        self.auth_details = None
        self.tenant_id = tenant_id
        self.username = username
        self.password = password
        self.user_id = None
        self.time_stamp = self.get_timestamp()
        self.metrics = []
        self.test_name = test_name
        self.computer_name = os.environ.get("COMPUTERNAME")
        self.challenge_details = None
        self.security = Security(self)
        self.db_metrics = db_metrics

        self._handle_auto_login(start_auth, auto_auth)

    @staticmethod
    def get_timestamp():
        return datetime.combine(datetime.today(), time.min).replace(tzinfo=timezone.utc).timestamp()

    def _handle_auto_login(self, start_auth, auto_auth):
        if start_auth:
            self.security.start_authentication()
            if auto_auth:
                self.security.advance_authentication()

    def get(self, url, payload=None):
        """
        Submits a get request to the specified url
        :param url: the url of the request
        :param payload: the payload for the get request (LEGACY - do not use)
        :return: the full response
        """
        start_time = self.get_timestamp()
        response = self.session.get(url, data=payload, headers=self.headers)
        end_time = self.get_timestamp()
        if self.db_metrics:
            self.metrics.append({
                'timeStamp': self.time_stamp,
                'tenant': self.tenant_id,
                'name': url,
                'type': 'apiGet',
                'testName': self.test_name,
                'machine': self.computer_name,
                'data': {
                    'payload': payload,
                    'startTime': start_time,
                    'endTime': end_time,
                    'elapsedTime': end_time - start_time
                }
            })
        return response

    def upload_file(self,
                    log_message,
                    url,
                    files,
                    assert_success=True,
                    url_ext=''):
        """
        Uploads a file to the server
        :param log_message: DEPRECATED
        :param url: the url to upload the file to
        :param files: the files to upload
        :param assert_success: expect a success code in the message
        :param url_ext: Anything needed to be added to the URL
        :return: The full response in the form of an ApiResult object
        """
        url = f'{self.base_url}{url}{url_ext}'

        request = requests.Request('POST',
                                   url,
                                   files=files).prepare().body.decode('utf8')

        m = re.search('--([^\r\n]*)', request)
        form = m.group(1)

        response = self.session.post(url,
                                     data=request,
                                     headers={**self.headers,
                                              'Content-Type': f'multipart/form-data; boundary={form}'})
        result = ApiResult(response)

        if assert_success:
            assert result.success(), f'Post request for: {log_message} was not successful. {result.message()}'

        return result

    def param_post(self, log_message, url, params=None, assert_success=True):
        """
        Send a post request with parameters
        :param log_message: DEPRECATED
        :param url: the url to send the request to
        :param params: the parameters to include with the request
        :param assert_success:
        :return: The full response in the form of an ApiResult object
        """
        response = self.session.post(f'{self.base_url}{url}', params=params, headers=self.headers)
        result = ApiResult(response)

        if assert_success:
            assert result.success(), f'Post request for: {log_message} was not successful'

        return result

    def authenticate_user(self, assert_success=True):
        """
        Authenticate the user
        :return: The full response in the form of an ApiResult object
        """
        self.security.start_authentication()
        return self.security.advance_authentication(assert_success=assert_success)

    def logout(self):
        """
        Log the user out
        :return: The full response in the form of an ApiResult object
        """
        return self.security.logout()

    def post(self, log_message, url, payload=None, assert_success=True):
        """
        Send a post request
        :param log_message: DEPRECATED
        :param url: the url of the request
        :param payload: the payload to include in the request
        :param assert_success: ensure a successful response?
        :return: The full response in the form of an ApiResult object
        """
        method = lambda : self.session.post(f'{self.base_url}{url}',
                                            data=json.dumps(payload),
                                            headers=self.headers)
        start_time = self.get_timestamp()

        response = self.__post__(log_message,
                                 method,
                                 assert_success)

        end_time = self.get_timestamp()
        if self.db_metrics:
            self.metrics.append({
                'timeStamp': self.time_stamp,
                'tenant': self.tenant_id,
                'name': url,
                'type': 'apiPost',
                'testName': self.test_name,
                'machine': self.computer_name,
                'data': {
                    'payload': payload,
                    'startTime': start_time,
                    'endTime': end_time,
                    'elapsedTime': end_time - start_time
                }
            })
        return response

    def post_urlencoded(self, log_message, url, payload=None, assert_success=True):
        """
        Send a post request in url encoded form
        :param log_message: DEPRECATED - no longer used
        :param url: the url to send the request to
        :param payload: the payload to include with the request
        :param assert_success: verify a successful response?
        :return: The full response in the form of an ApiResult object
        """
        method = lambda: self.session.post(f'{self.base_url}{url}',
                                           data=payload,
                                           headers=self.headers_url_encoded)
        start_time = self.get_timestamp()

        response = self.__post__(url,
                                 method,
                                 assert_success)

        end_time = self.get_timestamp()
        if self.db_metrics:
            self.metrics.append({
                'timeStamp': self.time_stamp,
                'tenant': self.tenant_id,
                'name': url,
                'type': 'apiPostUrlEncoded',
                'testName': self.test_name,
                'machine': self.computer_name,
                'data': {
                    'payload': payload,
                    'startTime': start_time,
                    'endTime': end_time,
                    'elapsedTime': end_time - start_time
                }
            })
        return response

    def refresh_token(self):
        """
        Refreshes the user's token
        :return: None
        """
        self.security.refresh_token()

    @staticmethod
    def __post__(log_message, method, assert_success):
        response = method()
        result = ApiResult(response)

        if assert_success:
            assert result.success(), f'Post request for: {log_message} was not successful.\n\n{result.message()}\n{result.exception()}\n\n'

        return result
