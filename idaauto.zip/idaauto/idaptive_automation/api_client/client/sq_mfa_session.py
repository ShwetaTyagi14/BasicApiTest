from idaptive_automation.api_client.client.api_session import ApiSession
from idaptive_automation.api_client.client.session_security import SQSecurity


class SQMFASession(ApiSession):
    def __init__(self,
                 base_url,
                 tenant_id,
                 username,
                 password,
                 start_auth=True,
                 auto_auth=True,
                 test_name=None,
                 db_metrics=True):
        """
        :param base_url: the url of the tenant
        :param tenant_id: the id of the tenant
        :param username: the username for authentication on the tenant
        :param password: the password for authentication on the tenant
        :param start_auth: Automatically start authentication for this client?
        :param auto_auth:  Automatically advance authentication for this client?
        :param test_name: the name of the test being run
        :param db_metrics: this flag determines if a metric db record should be inserted
        """
        super().__init__(base_url,
                         tenant_id,
                         username=username,
                         password=password,
                         start_auth=False,
                         auto_auth=False,
                         test_name=test_name,
                         db_metrics=db_metrics)
        self.security = SQSecurity(self)

        self._handle_auto_login(start_auth, auto_auth)
