import pytest
from idaptive_automation.mongo_dal import AutomationMongoClient
from idaptive_automation.api_client.client.sq_mfa_session import SQMFASession


@pytest.fixture()
def api_session():
    yield SQMFASession


@pytest.fixture(scope='class')
def api_class_session():
    yield SQMFASession


@pytest.fixture(scope='session')
def api_session_fixture():
    yield SQMFASession


@pytest.fixture()
def mongo_dal():
    yield AutomationMongoClient


@pytest.fixture(scope='class')
def mongo_class_dal():
    yield AutomationMongoClient


@pytest.fixture(scope='session')
def mongo_session_client():
    yield AutomationMongoClient
