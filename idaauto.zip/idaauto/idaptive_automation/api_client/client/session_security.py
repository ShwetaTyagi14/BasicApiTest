from idaptive_automation.api_payloads.payloads.security.start_authentication import StartAuthentication
from idaptive_automation.api_payloads.payloads.security.logout import Logout
from idaptive_automation.api_payloads.payloads.security.on_demand_challenge import OnDemandChallenge
from idaptive_automation.api_payloads.payloads.security.advance_authentication import AdvanceAuthentication,\
    MultiOperationAdvanceAuthentication
import os
import json


class Security:
    mechanisms = None  # do we still need this??

    def __init__(self, session):
        """
        Intended for internal use only - do not invoke directly
        :param session:
        """
        self.tenant_id = session.tenant_id
        self.username = session.username
        self.password = session.password
        self.api_session = session
        self.challenges = None
        self.auth_details = None
        self.start_authentication_payload = StartAuthentication(self.tenant_id,
                                                                self.username).to_payload()
        self.advance_authentication_payload = AdvanceAuthentication().with_tenant_id(self.tenant_id)\
                                                                     .with_answer(self.password)
        self.cleanup_authentication = self.advance_authentication_payload.base()

    def start_authentication(self):
        response = self.__start_auth__()

        if response.success():
            if len(self.challenges) == 1:
                if self.challenges[0]['Mechanisms'][0]['PromptSelectMech'] == 'Password':
                    self.advance_authentication_payload.mechanism_id = \
                        self.challenges[0]['Mechanisms'][0]['MechanismId']

        return response

    def __start_auth__(self):
        response = self.api_session.post('Starting authentication session',
                                         '/Security/StartAuthentication',
                                         self.start_authentication_payload)

        if 'PodFqdn' in response.result().keys() and len(response.result().keys()) == 1:
            raise Exception(f"Login failed. Redirect detected. Change url to {response.result()['PodFqdn']}")
        self.challenges = response.result()['Challenges']
        self.advance_authentication_payload.session_id = response.result()['SessionId']
        return response

    def advance_authentication(self, assert_success=True):
        response = self.api_session.post('Advancing authentication',
                                         '/Security/AdvanceAuthentication',
                                         self.advance_authentication_payload.to_payload(),
                                         assert_success=assert_success)

        if response.ok():
            self.api_session.cookies = response.cookies()
            self.api_session.auth_details = self.auth_details = response.deserialized_response()
            if self.api_session.auth_details.Result.Summary == "LoginSuccess":
                self.api_session.user_id = self.api_session.auth_details.Result.UserId
        else:
            print('\n\n\nLogin Failed')
            if 'Message' in response.keys():
                print(response.Message)
            if 'message' in response.keys():
                print(response.message)

        return self.api_session.auth_details

    def cleanup_authentication(self):
        return self.api_session.post('Cleaning up authentication session',
                                     '/Security/CleanupAuthentication',
                                     self.cleanup_authentication.to_payload())

    def logout(self):
        try:
            return self.api_session.post('Logging out of authentication session',
                                         '/Security/Logout',
                                         Logout(self.auth_details.Result.Auth).to_payload())
        except Exception as e:
            print(f'Logging out threw exception: {e}')

    def on_demand_challenge(self):
        return self.api_session.post('Performing MFA on behalf of user',
                                     '/Security/OnDemandChallenge',
                                     OnDemandChallenge(self.username, None).to_payload())

    def refresh_token(self):
        return self.api_session.post('Reloading cached identity from directory service',
                                     '/Security/RefreshToken')

    def get_authenticated_user(self):
        return self.api_session.post('Getting information about the currently authenticated user',
                                     '/Security/whoami')


class EmailMfaSecurity(Security):
    def __init__(self, session):
        super().__init__(session)
        self.advance_authentication_payload = MultiOperationAdvanceAuthentication().with_tenant_id(self.tenant_id)

    def start_authentication(self):
        self.__start_auth__()

        if len(self.challenges) > 1:
            password_op = {
                "MechanismId": self.challenges[0]['Mechanisms'][0]['MechanismId'],
                "Answer": self.password,
                "Action": 'Answer'
            }
            mfa_mechs = [mech for mech in self.challenges[1]['Mechanisms'] if mech['Name'] == 'EMAIL']
            if len(mfa_mechs) == 0:
                raise Exception(f'No email MFA challenge found for user {self.username} on tenant {self.tenant_id}')

            mfa_op = {
                "MechanismId": mfa_mechs[0]["MechanismId"],
                "Action": 'StartOOB'
            }
            self.advance_authentication_payload.operations.append(password_op)
            self.advance_authentication_payload.operations.append(mfa_op)
        else:
            raise Exception(f'MFA challenge expected, no challenge received')


class SQSecurity(Security):
    def __init__(self, session, security_question=None):
        super().__init__(session)
        self.security_questions = self.__config__(security_question)
        if self.security_questions is not None:
            self.advance_authentication_payload = MultiOperationAdvanceAuthentication().with_tenant_id(None)

    def start_authentication(self):
        if self.security_questions is None:
            return super().start_authentication()
        self.__start_auth__()
        if len(self.challenges) > 1:
            password_op = {
                "MechanismId": self.challenges[0]['Mechanisms'][0]['MechanismId'],
                "Answer": self.password,
                "Action": 'Answer'
            }
            mfa_mechs = [mech for mech in self.challenges[1]['Mechanisms'] if mech['Name'] == 'SQ']
            if len(mfa_mechs) == 0:
                assert False,\
                    f'No SQ MFA challenge found for user {self.username} on tenant {self.tenant_id}'
            answer = [q['answer'] for q in self.security_questions if q['question'] == mfa_mechs[0]['Question']]
            if len(answer) == 0:
                assert False,\
                    f'Answer to SQ {mfa_mechs[0]["Question"]} not found for {self.username} on tenant {self.tenant_id}'

            mfa_op = {
                "MechanismId": mfa_mechs[0]["MechanismId"],
                "Answer": answer[0],
                "Action": 'Answer'
            }
            self.advance_authentication_payload.operations.append(password_op)
            self.advance_authentication_payload.operations.append(mfa_op)
        else:
            raise Exception(f'MFA challenge expected for {self.username} on tenant {self.tenant_id}')

    def __config__(self, security_question):
        if security_question is None:
            try:
                val = os.environ.get(self.api_session.username)
                return None if len(val) == 0 else json.loads(val.strip())
            except:
                return None
