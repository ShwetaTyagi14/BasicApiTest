from idaptive_automation.api_client.client.api_session import ApiSession


class OTPSession(ApiSession):
    def __init__(self,
                 base_url,
                 tenant_id,
                 otp,
                 test_name=None):
        super().__init__(base_url,
                         tenant_id,
                         None,
                         None,
                         start_auth=False,
                         auto_auth=False,
                         test_name=test_name)
        self.otp = otp
        self._login_with_otp()

    def _login_with_otp(self):
        self.get(self.otp)
