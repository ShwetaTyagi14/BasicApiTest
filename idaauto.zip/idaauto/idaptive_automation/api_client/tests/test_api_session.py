from idaptive_automation.fixtures.function_fixtures import authenticated_api_function_fixture as fixture
from idaptive_automation.api_client.client.fixtures import api_session, mongo_dal
from idaptive_automation.api_client.client.otp_session import OTPSession
from idaptive_automation.api_client.client.email_mfa_session import EmailMFASession
import re
import pytest
from time import sleep


def test_api_login(fixture):
    user = fixture['session'].security.get_authenticated_user()
    assert user.result()['User'] == fixture['username']


def test_otp_login():
    user = OTPSession(base_url='https://aaa4788.my.idaptive.app',
                      tenant_id='aaa4788',
                      otp="https://aaa4788.my.idaptive.app/manage?OneTimePass=L3dVSFFVRkJORGM0T0FMV2hDTWNaWGVnTVI2alVMeHBRWldFN25XNGo5ckZNSXpoUXJLaWJaN0tBMW1LVytIMHM1UW1ia0RzRVJ1UTBweXV0RGFWYS96R2p0Tk1qR3BLM0FDMEc1N3p2cUJIdVhJcXBaRm84alNvalVWVVR3VWlGaDhhRzBSZ1hYODZPTDZGQUd0SzFVMytVWGtNL1piVmZXam1KdGpVYkZkRzFPM1ZzSTF6QUxyS1NIVXVJbWF0SzIvYlUvMDQ0YXZhQ0JYSWlYdzJhdzFTQzR3ZWRNR2JPVzkraS9rMThTbGxvQnhacWh2elpQQVMwV2tNSlhncWxJdWYwcVpRVERUekVpST0_")\
        .security.get_authenticated_user()
    assert re.match(r"[A-z]+@.+", user.result()['User'])


@pytest.fixture()
def email_mfa_fixture(request):
    tenant = request.config.getoption('tenant')[0]
    return {
        'tenant': tenant,
        'username': f'mfatest@{tenant}',
        'password': 'UtahQA987'
    }


def test_mfa_login(email_mfa_fixture):
    file_path = 'mfacode.txt'
    with open(file_path, 'w') as file:
        pass
    session = EmailMFASession(f'https://{email_mfa_fixture["tenant"]}.my.idaptive.qa',
                              email_mfa_fixture["tenant"],
                              email_mfa_fixture["username"],
                              email_mfa_fixture["password"])
    mfa_code = None
    while mfa_code is None or len(mfa_code) == 0:
        with open(file_path) as file:
            mfa_code = file.readline()
        if mfa_code is None or len(mfa_code) == 0:
            sleep(5)
    session.submit_mfa_code(mfa_code)
    user = session.security.get_authenticated_user()
    assert user.result()['User'] == email_mfa_fixture["username"]
