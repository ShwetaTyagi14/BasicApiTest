from idaptive_automation.api_client.client.fixtures import api_session, mongo_dal
from idaptive_automation.fixtures  import authenticated_api_function_fixture as fixture
import pytest
from idaptive_automation.api_client.test_helpers.file_helper import load_json_test_data_file


@pytest.mark.parametrize('input_file', [
    'Partner details.json'
])
def test_url_encoded_post_request(input_file, fixture):
    file = load_json_test_data_file(input_file)
    response = fixture['session'].post_urlencoded('Saving federation',
                                                  '/Federation/CreateFederation',
                                                  file, False)

    assert not response.success()
    assert 'No name has been specified for the federation.' in response.message()





