# api-client
The main class for this solution is 

`ApiSession`

This is API client that actually makes the API calls to our endpoints. 

This is a stable library that is not often modified

Basic usage example:
```python
session = ApiSession(base_url='aaq0197.my-qa.centrify.com',
                     tenant_id='aaq0197',
                     username='adminuser',
                     password='testPassword1234',
                     test_name='the name of the test using the client')
cloud_users=UserApi(session).get_all_cloud_users()
```

For more usage examples, refer to the [main idaptive-automation repo README.md file](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/readme.md)