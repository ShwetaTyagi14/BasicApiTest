# ui_automation

This project contains all the Page Object Model and Ui element classes needed to 
navigate thru the Idaptive UI

### Driver
Our pages rely on a browser driver that extends the behavior of the standard Selenium driver. It relys on the
use of Selenium Grid. The driver can be found [here](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/ui_automation/idaptive_driver.py).

### Page Object Model (POM) structure
The Idaptive UI uses a non-standard structure, and is quite hostile to automation. It is critical that all UI 
functionality be written only once, and we <b>avoid duplicate solutions for handling the same problems </b>. Please
prefer using existing functionality over writing your own.

Proper use of this framework provides you with these benefits:
* Never having to wait for an element to appear or a page to load in a test - this is the default behavior of
our UI classes
* Write tests using a declarative model - simply state what you want to do, and let the framework figure
out the best way to do it
* Having a single place to update all UI elements as they evolve

#### UI tests
* The first rule of Xpath in a test is - you do not talk about Xpath in a test
* The second rule of Xpath in a test is - you do not talk about Xpath in a test!!

All Xpaths belong either in a page class, or in the element itself (the latter is usually only done as a last resort). Tests
should never contain Xpath, and they should not have to know anything about the structure of a page. Test should
rely on the declarative programming model - tell the page what you want to do, and let it figure out the
best way to do it


#### Basic structure of a UI page
All pages <b>must</b>:
* Inherit from [UIPage](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/ui_automation/pages/ui_page.py)
* Contain an  `elements` array that holds all of the known UI elements for that page
* The `elements` array should contain an element called 'LOADED', which will be used by the base class
to verify that the page is loaded
* Contain methods for interacting with its elements
* Support simple UI validation of all elements via the `validate_all_elements(self)` method in the base class
* Support simple UI validation of all child elements via the `validate_all_child_elements(self)` method in the base class

Pages <b>must not</b>:
* Directly manipulate any elements. In order to interact with an element, the page should
simply tell the element what it wants to do, and the element should know how to do it

Example:
```python
from idaptive_automation.ui_automation.Pages import UIPage


# notice that the page is invoking methods on the correct elements, nothing more
class AdminPortalPage(UIPage):
    def select_users(self):
        self.elements['users'].click()
        
    def select_option(self, select_name, option):
        if select_name not in self.elements:
            raise KeyError(f'{select_name} is not a valid select box')
    
        self.elements[select_name].select_option(option)
```

#### Basic structure of a UI element
All UI elements <b>must</b>:
* Be defined using one of our pre-defined UI elements
* Encapsulate all interaction with the element in a generic, reusable, extensible fashion
* Be aware of their 'child' elements - these are elements that appear/disappear based on their properties. An example of
this is a select box that causes changes in the UI based on what value is selected 

Most of our existing UI already has at least one working example. Refer to the exising pages and use their code as 
an example.


#### POM Full example:
A good example of a POM class that involves child elements can be found [here](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/ui_automation/Pages/PolicyDetails/EndpointPolicies/device_enrollment_page.py)


#### Login example:
```python
from idaptive_automation.ui_automation import SignInPage, UserPortalPage

def login_to_user_portal(self, user_name, password):
    SignInPage(self.driver).login(user_name, password)
    UserPortalPage(self.driver).wait_for_page_to_load()
```

For more usage examples, refer to the pages that are already written. The code should be self documenting. 
If you still have question, email Hunter at hunter.alving@idaptive.com