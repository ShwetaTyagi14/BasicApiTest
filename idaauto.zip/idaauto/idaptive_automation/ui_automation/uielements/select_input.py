from idaptive_automation.ui_automation.uielements.labeled_element import LabeledElement
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.missing_element_exception import MissingElementException


class SelectInput(LabeledElement):
    li_container_selector = '//div[not(contains(@style,"display: none")) and starts-with(@class,"x-boundlist x-boundlist-floating x-layer x-ltr x-boundlist-default x-border-box")]'
    li_selector = f'{li_container_selector}//li'

    def __init__(self, definition):
        self.options_container_id = None
        super().__init__(definition)

    def open(self):
        self.toggle()
        if not self.is_open():
            self.toggle()

    def toggle(self):
        try:
            self.scroll_into_view()
            self.definition.driver.extended_click_element(self.definition.locator.toggle_locator)
        except AttributeError:
            raise MissingElementException(f'Element: {self.definition.locator.toggle_locator} not found')

    def is_open(self):
        elems = self.definition.driver.fetch_elements((By.XPATH, SelectInput.li_selector),1)
        return elems is not None

    def add_option_to_definition(self, option):
        if option not in self.definition.options:
            self.definition.options.append(option)

    def get_options(self):
        elems = None
        self._set_options_container_id()
        selector = f'//div[@id="{self.options_container_id}"]//li'
        elems = self.definition.driver.fetch_elements((By.XPATH, selector))

        if elems is None:
            return None

        options = []
        for option in elems:
            options.append(option.text)
        return options

    def display_options(self):
        self.toggle()
        options = self.get_options()
        self.toggle()
        return options

    def _set_options_container_id(self):
        """Necessary due to the way our UI handles select options. Internal use only\
            Assumes the select is already open."""
        if self.options_container_id is None:
            options = self.definition.driver.fetch_elements((By.XPATH, self.li_container_selector), 2)
            if options is None:
                raise MissingElementException(f'Could not find options for select box: {self.definition.locator.element_locator}')
            self.options_container_id = options[-1].get_attribute('id')

    def select_option(self,option):
        self.open()
        self._set_options_container_id()
        selector = f'//div[@id="{self.options_container_id}"]//li[@data-text="{option}"]'
        self.definition.driver.wait_for_visible_element((By.XPATH, selector), 2).click()

    def validate(self):
        super().validate()
        if self.definition.options is not None:
            opts = self.display_options()
            if sorted(opts) != sorted(self.definition.options):
                assert False, f'''options expectation failed for {self.definition.locator.element_locator}
Expected: {self.definition.options}, Found: {opts}'''

    def validate_all_children(self):
        if self.definition.children is None:
            return

        for child in self.definition.children:
            if child['supports_validation']:
                self.select_option(child['depends_on'])
                for elem in child['elements']:
                    elem.validate()
                    elem.validate_all_children()
