from idaptive_automation.ui_automation.uielements.ui_element import UIElement


class UserSetFilter(UIElement):
    def select(self):
        if not self.is_selected():
            self.click()

    def is_selected(self):
        parent = self.definition.driver.wait_for_visible_element(self.definition.locator.parent_locator, 2)
        elem_class = parent.get_attribute('class')
        return 'selected-set' in elem_class
