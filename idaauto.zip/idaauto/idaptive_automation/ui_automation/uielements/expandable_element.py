from idaptive_automation.ui_automation.uielements.ui_element import UIElement


class ExpandableElement(UIElement):
    def validate_all_children(self):
        self.click()

        super().validate_all_children()
