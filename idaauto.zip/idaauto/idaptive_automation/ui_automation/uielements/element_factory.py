from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.select_input import SelectInput
from idaptive_automation.ui_automation.uielements.checkbox import Checkbox
from idaptive_automation.ui_automation.uielements.td_checkbox import TDCheckbox
from idaptive_automation.ui_automation.uielements.text_input import TextInput
from idaptive_automation.ui_automation.uielements.element_group import UiElementGroup
from idaptive_automation.ui_automation.uielements.multi_select_button import MultiSelectButton
from idaptive_automation.ui_automation.uielements.user_set_filter import UserSetFilter
from idaptive_automation.ui_automation.uielements.email_settings import EmailSettings
from idaptive_automation.ui_automation.uielements.exchange_settings import ExchangeSettings
from idaptive_automation.ui_automation.uielements.modify_delete_grid import ModifyDeleteGrid
from idaptive_automation.ui_automation.uielements.search_box import SearchBox
from idaptive_automation.ui_automation.uielements.searchable_selection_dialog import SearchableSelectionDialog
from idaptive_automation.ui_automation.uielements.add_edit_device_enrollment_rule import AddEditDeviceEnrollmentRule
from idaptive_automation.ui_automation.uielements.ui_image import UiImage
from idaptive_automation.ui_automation.uielements.displayed_text import DisplayedText
from idaptive_automation.ui_automation.uielements.expandable_element import ExpandableElement
from selenium.webdriver.common.by import By


class ElementFactory:
    def __init__(self, driver):
        self.driver = driver

    def define_element(self, args):
        return UIElement(ElementDefinition(self.driver, **args))

    def define_select(self, args):
        return SelectInput(ElementDefinition(self.driver, **args))

    def define_checkbox(self, args):
        return Checkbox(ElementDefinition(self.driver, **args))

    def define_td_checkbox(self, args):
        return TDCheckbox(ElementDefinition(self.driver, **args))

    def define_text_input(self, args):
        return TextInput(ElementDefinition(self.driver, **args))

    def define_element_group(self, args):
        return UiElementGroup(ElementDefinition(self.driver, **args))

    def define_search_box(self, args):
        return SearchBox(ElementDefinition(self.driver, **args))

    def define_multi_select(self, args):
        return MultiSelectButton(ElementDefinition(self.driver, **args))

    def define_user_set_filter(self, args):
        return UserSetFilter(ElementDefinition(self.driver, **args))

    def define_email_settings(self, args):
        return EmailSettings(ElementDefinition(self.driver, **args))

    def define_exchange_settings(self, args):
        return ExchangeSettings(ElementDefinition(self.driver, **args))

    def define_modify_delete_grid(self, args):
        return ModifyDeleteGrid(ElementDefinition(self.driver, **args))

    def define_searchable_selection_dialog(self, args):
        return SearchableSelectionDialog(ElementDefinition(self.driver, **args))

    def define_device_enrollment_grid(self, args):
        return AddEditDeviceEnrollmentRule(ElementDefinition(self.driver, **args))

    def define_ui_image(self, args):
        return UiImage(ElementDefinition(self.driver, **args))

    def define_displayed_text(self, text, args):
        return DisplayedText(ElementDefinition(self.driver, **args), text)

    def define_expandable_element(self, args):
        return ExpandableElement(ElementDefinition(self.driver, **args))

    def find_elements_by_xpath(self, xpath):
        """This method is experimental"""
        elems = self.driver.find_elements_by_xpath(xpath)
        if not elems:
            return elems
        ret_val = []
        for indx, val in enumerate(elems):
            args = {
                'locator': ElementSetLocator(element_locator=(By.XPATH, f'{xpath}[{indx}]'))
            }
            ret_val.append(self.define_element(args))
        return ret_val

    def find_element_by_xpath(self, xpath):
        """This method is experimental"""
        elem = self.driver.find_element_by_xpath(xpath)
        if not elem:
            return elem
        args = {
            'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))
        }
        return self.define_element(args)

    def find_element(self, by, selector):
        """This method is experimental"""
        elem = self.driver.find_element(by, selector)
        if not elem:
            return elem
        return self.define_element({'locator': ElementSetLocator(element_locator=(by, selector))})

    def find_elements(self, by, selector):
        """This method is experimental"""
        elems = self.driver.find_elements(by, selector)
        if not elems:
            return elems
        ret_val = []
        for elem in elems:
            args = {
                'locator': ElementSetLocator(element_locator=(By.ID, elem.get_attribute('id')))
            }
            elem = self.define_element(args)
            ret_val.append(elem)
        return ret_val

    def find_element_by_tag_name(self, name):
        """This method is experimental"""
        elem = self.driver.find_element_by_tag_name(name)
        if not elem:
            return elem
        return self.define_element({'locator': ElementSetLocator(element_locator=(By.TAG_NAME, name))})
