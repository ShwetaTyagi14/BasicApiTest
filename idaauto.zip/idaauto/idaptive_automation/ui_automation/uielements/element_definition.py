class ElementDefinition:
    def __init__(self,
                 driver,
                 locator,
                 inner_text=None,
                 label_text=None,
                 css_class=None,
                 validation_error_class=None,
                 enabled=True,
                 options=None,
                 checked=False,
                 tooltip=None,
                 supports_validation=True,
                 children=None,
                 title_locator=None,
                 btn_locator=None,
                 grid_rows_locator=None,
                 grid_header_locator=None):
        self.driver = driver
        self.locator = locator
        self.text = inner_text
        self.label_text = label_text
        self.css_class = css_class
        self.validation_error_class = validation_error_class
        self.enabled = enabled
        self.options = options
        self.checked = checked
        self.tooltip = tooltip
        self.supports_validation = supports_validation
        self.children = children
        self.title_locator = title_locator
        self.grid_rows_locator = grid_rows_locator
        self.grid_header_locator = grid_header_locator
        self.btn_locator = btn_locator
