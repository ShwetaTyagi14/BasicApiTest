from idaptive_automation.ui_automation.uielements.ui_element import UIElement


class DisplayedText(UIElement):
    def __init__(self, definition,  text):
        self.expected_text = text

        super().__init__(definition)

    def validate(self):
        text = self.get_text()
        assert text == self.expected_text, f'Expected {self.expected_text}, found {text}'
