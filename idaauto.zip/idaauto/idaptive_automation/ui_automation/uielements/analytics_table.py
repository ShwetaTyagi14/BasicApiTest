from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from selenium.common.exceptions import NoSuchElementException


class AnalyticTable(UIPage):
    def __init__(self, driver, table_title=None):
        self.leading_empty_column_counter = 0
        self.table_title = table_title

        if table_title is None:
            self.table_header_columns = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, '//thead[contains(@class,"ant-table-thead")]//th'))}

            self.table_rows = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, '//div[contains(@class,"ant-table-content")]//tbody[@class="ant-table-tbody"]//tr'))}
        else:
            self.table_header_columns = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//div[contains(@class,"ant-table-large")][.//span[.="{self.table_title}"]]//tr/th'))}

            self.table_rows = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//div[contains(@class,"ant-table-large")][.//span[.="{self.table_title}"]]//tbody[@class="ant-table-tbody"]//tr'))}

        self.elements = {
            'table_header_columns': ElementFactory(driver).define_element_group(self.table_header_columns),
            'table_rows': ElementFactory(driver).define_element_group(self.table_rows),
        }

        super().__init__(driver, self.elements)

        self.analytic_table_columns = self._get_table_header_columns()
        self.analytic_table_rows = self._get_table_rows()

    def _get_table_header_columns(self):
        _table_columns = {}
        columns = self.elements['table_header_columns'].get_elements()

        for column in columns:
            column_name = column.get_text()
            if len(column_name) > 0:
                try:
                    _column_locator = column.definition.locator.element_locator[1]
                    sort_buttons = {'Sort_Up': column.find_element(By.XPATH, f"{_column_locator}//span[contains(@class,'ant-table-column-sorter-up')]"),
                                    'Sort_Down': column.find_element(By.XPATH, f"{_column_locator}//span[contains(@class,'ant-table-column-sorter-down')]")}

                    _table_columns[column_name] = sort_buttons
                except NoSuchElementException:
                    _table_columns[column_name] = None
            else:
                self.leading_empty_column_counter += 1

        _table_columns['Action Column'] = None

        return _table_columns

    def _get_table_rows(self):
        row_builder = []
        rows = self.elements['table_rows'].get_elements()
        leading_empty_column = self.leading_empty_column_counter - 1

        if rows is None:
            return row_builder

        for row in rows:
            _dict = {}
            _row_locator = row.definition.locator.element_locator[1]
            columns = row.find_elements_by_xpath(By.XPATH, f'{_row_locator}//td')
            column_index = 0

            if len(columns) > 0:
                for key in self.analytic_table_columns:
                    if key == 'Action Column':
                        buttons = columns[column_index + leading_empty_column].find_elements_by_xpath(
                            By.XPATH, f'{_row_locator}//span//a')

                        # Exception handling for Custom Model table
                        if self.table_title is not None and self.table_title in 'Custom Model':
                            delete_button = columns[column_index + leading_empty_column].\
                                find_elements_by_xpath(By.XPATH, f'{_row_locator}//span//span//a')
                            buttons.pop(2)
                            buttons.append(delete_button[0])

                        for button in buttons:
                            _dict[button.get_text()] = button
                        break
                    else:
                        _dict[key] = columns[column_index + leading_empty_column].get_text()

                    column_index += 1

                row_builder.append(_dict)

        return row_builder

    def get_refreshed_table_rows(self):
        self.analytic_table_rows = self._get_table_rows()
        return self.analytic_table_rows
