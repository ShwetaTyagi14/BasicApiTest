from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_group import UiElementGroup


class AddEditDeviceEnrollmentRule(UIElement):
    def __init__(self, definition):
        self.title = UIElement(ElementDefinition(definition.driver, **{
            'locator':
            ElementSetLocator(element_locator=(By.XPATH, definition.locator.title_locator))}))
        self.add_rule_btn = UIElement(ElementDefinition(definition.driver, **{
            'locator':
            ElementSetLocator(element_locator=(By.XPATH, definition.locator.btn_locator))}))
        self.grid_rows = UiElementGroup(ElementDefinition(definition.driver, **{
            'locator':
            ElementSetLocator(element_locator=(By.XPATH, definition.locator.grid_rows_locator))}))
        self.grid_header = UIElement(ElementDefinition(definition.driver, **{
            'locator':
            ElementSetLocator(element_locator=(By.XPATH, definition.locator.grid_header_locator))}))

        definition.children = [
            {
                'supports_validation': True,
                'elements': [
                    self.title,
                    self.add_rule_btn,
                    self.grid_header
                ]
            }
        ]

        super().__init__(definition)

    def get_grid_column_names(self):
        return self.grid_header.get_text().split('\r\n')

    def add_rule(self, rule):
        pass

    def set_filter(self, version):
        pass

    def set_condition(self, condition):
        pass

    def set_value(self, value):
        pass

    def click_add(self):
        self.add_rule_btn.click()

    def cancel_rule_add(self):
        pass

    def get_displayed_rules(self):
        return [{'Filter': row[0], 'Condition': row[1], 'Value': row[2]} for row in self.grid_rows.get_text().split('\r\n')]

    def delete_displayed_rule(self, rule_index):
        pass

    def validate(self):
        if self.definition.children is None:
            return

        for child in self.definition.children:
            if child['supports_validation']:
                for elem in child['elements']:
                    elem.validate()
                    elem.validate_all_children()
