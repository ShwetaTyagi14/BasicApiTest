from idaptive_automation.ui_automation.uielements.ui_element import UIElement


class ExchangeSettings(UIElement):
    def validate(self):
        return True
