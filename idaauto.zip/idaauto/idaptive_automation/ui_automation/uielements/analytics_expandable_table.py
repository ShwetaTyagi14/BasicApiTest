from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory


class AnalyticExpandableTable(UIPage):
    def __init__(self, driver, table_title):

        self.table_title = table_title
        self.table_rows = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f'//div[contains(@class,"ant-collapse-header")]'
            f'[.="{self.table_title}"]/following-sibling::div//tbody[@class="ant-table-tbody"]//tr'))}

        self.elements = {
            'table_rows': ElementFactory(driver).define_element_group(self.table_rows),
        }
        super().__init__(driver, self.elements)

        self.analytic_table_rows = self._get_table_rows()

    def _get_table_rows(self):
        row_builder = []
        rows = self.elements['table_rows'].get_elements()

        if rows is None:
            return row_builder

        leading_empty_column = self._calculate_empty_column(rows)

        for row in rows:
            _dict = {}
            _row_locator = row.definition.locator.element_locator[1]
            columns = row.find_elements_by_xpath(By.XPATH, f'{_row_locator}//td')

            if len(columns) > 0:
                for idx in range(leading_empty_column, len(columns)-1):
                    _dict[f'column_{idx}'] = columns[idx].get_text()

                buttons = columns[len(columns)-1].find_elements_by_xpath(By.XPATH, f'{_row_locator}//span//a')
                for button in buttons:
                    _dict[button.get_text()] = button

            row_builder.append(_dict)

        return row_builder

    def get_refreshed_table_rows(self):
        self.analytic_table_rows = self._get_table_rows()
        return self.analytic_table_rows

    @staticmethod
    def _calculate_empty_column(rows):
        empty_counter = 0

        if len(rows) > 0:
            _row_locator = rows[0].definition.locator.element_locator[1]
            columns = rows[0].find_elements_by_xpath(By.XPATH, f'{_row_locator}//td')
            for column in columns:
                if len(column.get_text()) == 0:
                    empty_counter += 1

        return empty_counter
