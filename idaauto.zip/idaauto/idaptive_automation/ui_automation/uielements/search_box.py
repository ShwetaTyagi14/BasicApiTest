from .ui_element import UIElement
from idaptive_automation.ui_automation.uielements.missing_element_exception import MissingElementException
from selenium.webdriver.common.keys import Keys


class SearchBox(UIElement):
    def search_for(self, text):
        self._element().send_keys(text)
        self._element().send_keys(Keys.RETURN)

    def clear(self):
        self._element().clear()
        return self
