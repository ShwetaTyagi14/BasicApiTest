from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.missing_element_exception import MissingElementException


class Checkbox(UIElement):
    def _label(self):
        return self.definition.driver.wait_for_visible_element(self.definition.locator.label_text_locator)

    def get_label_text(self):
        label = self._label()
        if label is None:
            raise MissingElementException(f'Element {self.definition.locator.parent_locator} not found')
        return label.text

    def check(self):
        self.click()

    def select(self):
        if not self.is_checked():
            self.check()

    def unselect(self):
        if self.is_checked():
            self.check()

    def is_checked(self):
        elems = self.definition.driver.wait_for_visible_elements(self.definition.locator.parent_locator, 2)
        if elems is None:
            raise MissingElementException(f'Element {self.definition.locator.parent_locator} not found')
        elem_class = elems[-1].get_attribute('class')
        return 'checked' in elem_class

    def validate(self):
        super().validate()
        if not self.definition.supports_validation:
            return
        try:
            assert self.definition.label_text is None or \
                   self.get_label_text() == self.definition.label_text
            assert self.definition.checked == self.is_checked()
        except AssertionError:
            raise Exception(f'Wrong text found on checkbox. Expected "{self.definition.label_text}", found "{self.get_label_text()}" on element {self.definition.locator.parent_locator} not found')

    def validate_all_children(self):
        if self.definition.children is None:
            return

        for child in self.definition.children:
            if child['supports_validation']:
                if not self.is_checked():
                    self.check()
                for elem in child['elements']:
                    elem.validate()
                    elem.validate_all_children()
