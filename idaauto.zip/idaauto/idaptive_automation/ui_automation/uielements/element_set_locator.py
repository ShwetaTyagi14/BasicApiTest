class ElementSetLocator:
    def __init__(self,
                 element_locator=None,
                 parent_container_locator=None,
                 label_text_locator=None,
                 tool_tip_locator=None,
                 toggle_locator=None,
                 title_locator=None,
                 btn_locator=None,
                 grid_rows_locator=None,
                 grid_header_locator=None):
        self.element_locator = element_locator
        self.parent_locator = parent_container_locator
        self.tool_tip_locator = tool_tip_locator
        self.label_text_locator = label_text_locator
        self.toggle_locator = toggle_locator
        self.title_locator = title_locator
        self.btn_locator = btn_locator
        self.grid_rows_locator = grid_rows_locator
        self.grid_header_locator = grid_header_locator
