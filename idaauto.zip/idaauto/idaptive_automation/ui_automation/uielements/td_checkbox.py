from idaptive_automation.ui_automation.uielements.checkbox import Checkbox
from idaptive_automation.ui_automation.uielements.missing_element_exception import MissingElementException


class TDCheckbox(Checkbox):

    def is_checked(self):
        elem = self.definition.driver.wait_for_visible_element(self.definition.locator.parent_locator, 2)
        if elem is None:
            raise MissingElementException(f'Element {self.definition.locator.parent_locator} not found')
        elem_class = elem.get_attribute('class')
        return 'x-grid-row-selected' in elem_class
