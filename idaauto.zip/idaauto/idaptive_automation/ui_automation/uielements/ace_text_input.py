"""
Helper method for UBA pages that contain Ace editor text input boxes - https://ace.c9.io
Javascript execution is required to interact, enter text, etc
"""


class AceTextInput:
    def __init__(self, driver):
        self.driver = driver

    def get_ace_input(self):
        return self.driver.execute_script('var res = ace.edit("brace-editor").getValue();return res')

    def type_ace_input(self, value):
        self.driver.execute_script('ace.edit("brace-editor").setValue(`{}`)'.format(value))
