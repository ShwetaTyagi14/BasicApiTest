"""
Helper methods for UBA pages that use Ant table https://ant.design/components/table
"""
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory


class AntTable:
    def __init__(self, driver):
        self.driver = driver

    def get_row_button_element(self, row_name, button_name, page=None):
        if page == 'Risk Rules':
            button = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                    f"//span[text()='{row_name}']"
                    f"/parent::span/parent::td/following-sibling::td//span/a[text()='{button_name}']"))}
        else:
            button = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                    f"//span[@class='break-word'][contains(text(),'{row_name}')]"
                    f"/parent::td/following-sibling::td/span/a[text()='{button_name}']"))}

        return ElementFactory(self.driver).define_element(button)

