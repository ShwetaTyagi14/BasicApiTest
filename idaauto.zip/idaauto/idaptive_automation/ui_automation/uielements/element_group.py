from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from selenium.webdriver.common.by import By


class UiElementGroup(UIElement):
    def _element(self, wait_time=5):
        return self.definition.driver.wait_for_visible_elements(self.definition.locator.element_locator, wait_time)

    def element_at_index(self, index):
        elem = self._element()[index]
        return elem

    def get_text(self):
        try:
            return [row.text.split('\n') for row in self.get_element()]
        except TypeError:
            return

    def get_elements(self):
        elems = self.get_element()
        if not elems:
            return elems
        ret_val = []
        if [elem for elem in elems if not elem.get_attribute('id')]:
            if self.definition.locator.element_locator[0] == By.XPATH:
                for indx, val in enumerate(self.get_element()):
                    xpath = f'{self.definition.locator.element_locator[1]}[{indx+1}]'
                    ret_val.append(UIElement(
                        ElementDefinition(self.definition.driver,
                                          ElementSetLocator(element_locator=(By.XPATH, xpath)))))
                return ret_val
            return elems
        for elem in self.get_element():
            ret_val.append(UIElement(
                ElementDefinition(self.definition.driver,
                                  ElementSetLocator(element_locator=(By.ID, elem.get_attribute_value('id'))))))
        return ret_val

