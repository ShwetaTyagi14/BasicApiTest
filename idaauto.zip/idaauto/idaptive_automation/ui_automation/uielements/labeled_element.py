from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.missing_element_exception import MissingElementException


class LabeledElement(UIElement):
    def get_label_text(self):
        try:
            return self.definition.driver.wait_for_visible_element(self.definition.locator.label_text_locator, 3).text
        except AttributeError:
            raise MissingElementException(f'Could not find label text element: {self.definition.locator.label_text_locator}')

    def validate(self):
        super().validate()
        assert self.definition.label_text is None or \
               self.get_label_text() == self.definition.label_text, f'Expected: {self.definition.label_text}, found: \'{self.get_label_text()}\''
