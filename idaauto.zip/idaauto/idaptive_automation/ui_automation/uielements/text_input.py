from idaptive_automation.ui_automation.uielements.labeled_element import LabeledElement


class TextInput(LabeledElement):
    def get_text(self):
        return self._element().get_attribute('value')

    def clear(self):
        self._element().clear()
        return self

    def type(self, value):
        self._element().send_keys(value)
