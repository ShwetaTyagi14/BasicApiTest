from idaptive_automation.ui_automation.uielements.missing_element_exception import MissingElementException
from selenium.common.exceptions import ElementNotInteractableException, ElementClickInterceptedException
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from selenium.webdriver.common.by import By
import re


class UIElement:
    def __init__(self, definition):
        self.definition = definition

    def _element(self, wait_time=5):
        elem = self.wait_for_visible(wait_time)
        if elem is None:
            print(f'element: {self.definition.locator.element_locator} not found')
        return elem

    def wait_for_visible(self, wait_time=5):
        try:
            return self.definition.driver.wait_for_visible_element(self.definition.locator.element_locator, wait_time)
        except AttributeError:
            raise

    def wait_for_not_visible(self, wait_time=5):
        try:
            return self.definition.driver.wait_for_invisible_element(self.definition.locator.element_locator, wait_time)
        except AttributeError:
            raise

    def wait_for_element_to_disappear(self, wait_time=5):
        elem = self._element(wait_time)
        if elem is not None and elem.is_displayed():
            elem = self.definition.driver.wait_for_invisible_element(self.definition.locator.element_locator, wait_time)
            if elem is not None and elem.is_displayed():
                raise Exception('Element did not disappear')

    def get_element(self):
        return self._element()

    def get_class(self):
        return self._element().get_attribute('class')

    def is_enabled(self):
        try:
            return self._element().is_enabled()
        except AttributeError:
            raise MissingElementException(f'Could not find: {self.definition.locator.element_locator}')

    def is_displayed(self):
        elem = self._element()
        if elem is None:
            return False
        return elem.is_displayed()

    def is_selected(self):
        return self._element().is_selected()

    def css_value(self, selector):
        return self._element().value_of_css_property(selector)

    def get_attribute_value(self, selector):
        return self._element().get_attribute(selector)

    def get_id(self):
        return self._element().id

    def get_tagname(self):
        return self._element().tag_name

    def get_text(self):
        return self._element().text

    def get_tool_tip(self):
        if self.definition.locator.tool_tip_locator is None:
            return
        return self.definition.driver.wait_for_visible_element(*self.definition.locator.tool_tip_locator)

    def click(self, wait_time=5):
        try:
            self._element(wait_time).click()
        except (AttributeError, ElementNotInteractableException):
            self.definition.driver.get_screenshot_as_png()
            raise
        except ElementClickInterceptedException as e:
            warning_dialog = self.definition.driver.get_warning_dialog()
            if warning_dialog is not None:
                raise Exception(f'Element click intercepted. Warning dialog detected: {warning_dialog.text}')

    def validate(self):
        if not self.definition.supports_validation:
            return

        try:
            assert self.definition.text is None or \
                   re.fullmatch(self.definition.text, self.get_text()) != None, f'expected: {self.definition.text}, found {self.get_text()}'

            assert self.is_enabled() == self.definition.enabled, f'expected: {self.definition.enabled}, found {self.is_enabled()}'

            assert self.definition.css_class is None or \
                   self.get_class() == self.definition.css_class, f'expected: {self.definition.css_class}, found {self.get_class()}'

            assert self.definition.tooltip is None or \
                   self.get_tool_tip() == self.definition.tooltip, f'expected: {self.definition.tooltip}, found {self.get_tool_tip()}'
        except AssertionError:
            raise

    def nth_child(self, n):
        """
        gets the nth child element
        :param n: the child index
        :return: the nth child element
        """
        return self.definition.children[n]

    def grandchild(self, child_index, grand_child_index):
        """
        gets a descendant child element
        :param child_index: the child index
        :param grand_child_index: the grandchild index
        :return: the descendant element
        """
        return self.definition.children[child_index]['elements'][grand_child_index]

    def validate_all_children(self):
        pass

    def validate_invalid_state(self):
        assert self.definition.validation_error_class in self.get_class()

    def scroll_into_view(self):
        self.definition.driver.execute_script("arguments[0].scrollIntoView(true);", self.get_element())

    def find_element(self, by, selector):
        """This method is experimental"""

        elem = self.get_element().find_element(by, selector)
        if not elem:
            return elem
        return UIElement(ElementDefinition(self.definition.driver, ElementSetLocator(element_locator=(by, selector))))

    def find_elements_with_ids(self, by, selector):
        """This method is experimental"""
        elems = self.definition.driver.find_elements(by, selector)
        if not elems:
            return elems
        ret_val = []
        for elem in elems:
            ret_val.append(UIElement(ElementDefinition(self.definition.driver,
                                                       ElementSetLocator(element_locator=(elem.get_attribute('id'))))))
        return ret_val

    def find_elements_by_xpath(self, by, selector):
        """This method is experimental"""
        elems = self.definition.driver.find_elements(by, selector)
        if not elems:
            return elems

        ret_val = []

        for idx, val in enumerate(elems):
            xpath = f'{selector}[{idx+1}]'
            ret_val.append(UIElement(ElementDefinition(self.definition.driver,
                                                       ElementSetLocator(element_locator=(By.XPATH, xpath)))))
        return ret_val
