from idaptive_automation.ui_automation.uielements.ui_element import UIElement


class MultiSelectButton(UIElement):
    def wait_for_visible(self, wait_time=5):
        try:
            elems = self.definition.driver.wait_for_visible_elements(self.definition.locator.element_locator, wait_time)
            return elems[0].find_element(by='xpath', value='./a')
        except AttributeError:
            raise
