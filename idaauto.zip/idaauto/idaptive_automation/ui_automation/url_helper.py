class UrlHelper:
    def build_url(self, segments):
        return '/'.join(s.strip('/') for s in segments)
