DEFAULT_PASSWORD = 'testTEST1234'


class PolicyDetailLeftNavConstants:
    ANDROID_MANAGEMENT_SETTINGS = "Android Management Settings"
    APPLICATION_POLICIES = 'Application Policies'
    ENDPOINT_POLICIES = "Endpoint Policies"
    DEVICE_MANAGEMENT_SEWTTINGS = 'Device Management Settings'
    DEVICE_ENROLLMENT_SETTINGS = 'Device Enrollment Settings'
    COMMON_SETTINGS = 'Common Settings'
    MOBILE_SETTINGS = 'Mobile Settings'
    IOS_SETTINGS = 'iOS Settings'
    RESTRICTIONS_SETTINGS = 'Restrictions Settings'
    EXCHANGE_SETTINGS = 'Exchange Settings'
    DOMAIN_SETTINGS = 'Domain Settings'
    KIOSK_MODE = 'Kiosk Mode'
    GLOBAL_HTTP_PROXY = 'Global HTTP Proxy'
    PER_APP_VPN_SETTINGS = 'Per-App VPN Settings'
    CALENDAR_SETTINGS = 'Calendar Settings'
    CONTACTS_SETTINGS = 'Contacts Settings'
    LDAP_SETTINGS = 'LDAP Settings'
    MAIL_SETTINGS = 'Mail Settings'
    APPLICATION_MANAGEMENT_SETTINGS = 'Application Management Settings'
    PROVISIONING_PROFILES = 'Provisioning Profiles'
    COMMON = 'Common'
    SECURITY_SETTINGS = 'Security Settings'
    WIFI_SETTINGS = 'Wi-Fi Settings'
    WIFI_RESTRICTIONS = 'Wi-Fi Restrictions'
    OSX_IOS_SETTINGS = 'OS X and iOS Settings'
    CERTIFICATE_PROFILES = 'Certificate Profiles'
    VPN_SETTINGS = 'VPN Settings'
    VPN_RESTRICTIONS = 'VPN Restrictions'
    CONFIGURATION_PROFILES = 'Configuration Profiles'
    OSX_SETTINGS = 'OS X Settings'
    CUSTOM_SETTINGS = 'Custom Settings'
    OPEN_APPS_ON_USER_LOGIN = 'Open applications when user logs in'
    OPEN_AUTH_NETWORK_ON_USER_LOGIN = 'Open authenticated network mounts when user logs in'
    OPEN_FILES_ON_USER_LOGIN = 'Open files, folders and items when user logs in'
    OPEN_NETWORK_MOUNTS_ON_USER_LOGIN = 'Open network mounts when user logs in'
    PERMIT_SHIFT_TO_SKIP_ON_USER_LOGIN = 'Permit shift key to skip opening items when user logs in'
    SECURITY_PRIVACY_SETTINGS = 'Security and privacy settings'
    APPLICATION_MANAGEMENT = 'Application Management'
    MANAGE_LOCAL_ADMIN_ACCT = 'Manage Local Admin Account'
    APPLICATIONS = 'Applications'
    MEDIA = 'Media'
    PREFERENCES = 'Preferences'
    RESTRICT_APPLICATIONS = 'Restrict applications'
    RESTRICT_PREFERENCES = 'Restrict preferences'
    SAMSUMG_KNOX_DEV_SETTINGS = 'Samsung KNOX Device Settings'
    SMASUNG_KNOX_WRKSPACE_SETTINGS = 'Samsung KNOX Workspace Settings'
    TOUCHDOWN_SETTINGS = 'Touchdown Settings'
    POLICY_SETTINGS = 'Policy Settings'
    AUTHENTICATION_POLICIES = 'Authentication Policies'
    PRIVILEGE_ELEVATION_POLICIES = 'Privilege Elevation Policies'
    USER_SECURITY_POLICIES = 'User Security Policies'
    THIRD_PARTY_INTEGRATION = 'Third Party Integration'
    SUMMARY = 'Summary'
    USER_SETTINGS = 'User Settings'
    DEFAULT_POLICY_NAME = 'PolicySet_[0-9]{1,4}'
    ROAMING_SETTINGS = 'Roaming Settings'
    ENABLE_WORK_PROFILES = 'Enable Work Profiles'
    PASSWORD_SETTINGS = 'Password Settings'
    ENABLE_KNOX_CONTAINER = 'Enable KNOX Container'
    ENABLE_TIMA_KEY_STORE = 'Enable TIMA Key Store'
    ENABLE_ODE_TRUSTED = 'Enable ODE Trusted Boot verification'
    ENABLE_COMMON_CRITERIA = 'Enable Common Criteria mode'
    REQUIRE_ATTESTATION = 'Require Attestation Verification'
    CONFIGURE_APPLICATIONS = 'Configure applications that can sync with container'
    ENTERPRISE_BILLING = 'Enterprise Billing'
    DEVICE_INVENTORY_SETTINGS = 'Device Inventory Settings'
    OATH_OTP = 'OATH OTP'
    RADIUS = 'RADIUS'
    BLUETOOTH_SETTINGS = 'Bluetooth Settings'
    RESTRICTIONS = 'Restrictions'
    SYSTEM_APPS = 'System Apps'
    DEVICE_OWNER = 'Device Owner'
    USER_ACCOUNT_SETTINGS = 'User Account Settings'
    SELF_SERVICE = 'Self Service'
    DEVICE_SETTINGS = 'Device Settings'
    ENABLE_CERTIFICATE = 'Enable certificate validation before installation'
    ENABLE_REVOCATION = 'Enable revocation check for application SSL connections'
    TRUSTED_CERTIFICATE = 'Trusted certificate authorities'
    ENABLE_AUDIT_LOG = 'Enable Audit Log'
    RESTRICTION_SETTINGS = 'Restriction Settings'
    APP_VPN_SETTINGS = 'Per-App VPN settings'
    APN_SETTINGS = 'APN Settings'
    LEGACY = 'Legacy'
    KNOX = 'Knox 2.6+'
    CONTAINER_SETTINGS = 'Container Settings'
    APPLICATION_SETTINGS = 'Application Settings'
    BROWSER_SETTINGS = 'Browser Settings'
    CERTIFICATE_SETTINGS = 'Certificate Settings'
    CONTAINER_ACCOUNT_SETTINGS = 'Container Account Settings'
    EMAIL_SETTINGS = 'Email Settings'
    PASSCODE_SETTINGS = 'Passcode Settings'
    ENABLE_GOOGLE_APPS = 'Enable Google Apps'
    EMAIL_ACCOUNT_SETTINGS = 'Email Account Settings'
    IDAPTIVE_SERVICES = 'CyberArk Identity'
    WINDOWS_WORKSTATIONS = 'Windows Workstations'
    LOCAL_ACCOUNT_LINKING = 'Local Account Linking'
    ENDPOINT_AUTHENTICATION = 'Endpoint Authentication'
    FIREWALL_SETTINGS = 'Firewall Settings'
    AGENT_SETTINGS = 'Agent Settings'
    BOOKMARK_SETTINGS = 'Bookmark Settings'
    LOCK_SCREEN = 'Lock Screen'


class Xpaths:
    SELECT_LABLEL = '/ancestor::table/ancestor::table/following-sibling::label'
    SELECT_TOGGLE = '/ancestor::td/following-sibling::td/div'
    PLACEHOLDER = 'placeholder'


class AddEditUser:
    class TextConstants:
        SUFFIX = 'Suffix'


class Options:
    YES_NO = ['--', 'Yes', 'No']
    ALL_FILTER_NONE = ['--', 'All', 'Filter', 'None']
    BROWSER_EXTENSION_VERSIONS = ['--', 'Latest Version']
    APPLICATION_MANAGEMENT_SETTINGS = ['--', '1', '2', '3', 'Indefinite']
    AUTO_LOCK = ['--', '1', '2', '5', '15', '30']
    AUTO_LOCK_TIME = ['--', '1', '2', '3', '4', '5', '10']
    MAX_FAILED_ATTEMPTS = ['--', '4', '5', '6', '7', '8', '9', '10']
    GRACE_PERIOD_DEVICE_LOCK = ['--', 'Immediately', '1 minute', '5 minutes', '15 minutes', '1 hour', '4 hours']
    MIN_COMPLEX_CHARS = ['--', '1', '2', '3', '4']
    MIN_PASSCODE_LEN = ['--', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16']
    BLOCK_APPS_NOTIFICATIONS = ['--', 'Block All', 'Block Text and Sound', 'Block Text']
    PREVENT_APPS_INSTALL = ['--', 'Allowed', 'Disallowed']
    NO_ALWAYS_ALLOWED_PROFILES = ['Default New Device Login Profile', 'Default Other Login Profile',
                                  'Default Password Reset Profile', '- Not Allowed -', '- Add New Profile -']
    INCLUDE_ALWAYS_ALLOWED_PROFILES = ['Default New Device Login Profile', 'Default Other Login Profile',
                                       'Default Password Reset Profile', '- Always Allowed -', '- Not Allowed -',
                                       '- Add New Profile -']


class UserSettings:
    class TextConstants:
        ALLOW_PERSONAL_APPS = 'Allow users to add personal apps'
        ALLOW_COPY_PASSWORDS = 'Allow users to view/copy personal passwords'
        SET_BROWSER_EXTENSION_VER = 'Set Browser Extension version (default latest version)'
        ENABLE_L_AND_C = 'Enable Browser Extension Land & Catch'
        ENABLE_TRUST_PROTCL = 'Enable WS-Trust protocol'
        ENFORCE_TRUST_CHALLENGE = 'Enforce application challenge with WS-Trust'

    class ElementNames:
        ALLOW_PERSONAL_APPS = 'ALLOW_PERSONAL_APPS'
        ALLOW_COPY_PASSWORDS = 'ALLOW_COPY_PASSWORDS'
        SET_BROWSER_EXTENSION_VERSION = 'SET_BROWSER_EXTENSION_VERSION'
        ENABLE_L_AND_C = 'ENABLE_L_AND_C'
        ENABLE_TRUST_PROTCL = 'ENABLE_TRUST_PROTCL'
        ENFORCE_TRUST_CHALLENGE = 'ENFORCE_TRUST_CHALLENGE'


class DeviceManagementSettings:
    class TextConstants:
        USE_CENTRIFY_AS_MDM = 'Use the CyberArk Identity Platform for mobile device management (default yes)'
        DEVICE_BASIC_INFO_FREQUENCY = 'Update device information frequency (default 12 hours)'
        DEVICE_UNREACHABLE_THRESHOLD = 'Mark unresponsive devices as "Unreachable" threshold (default 14 days)'
        DISABLE_UNREACHABLE_CLIENTS = 'Disable unreachable clients'
        DISABLE_ACTION = 'Disable action'
        DAYS_UNTIL_DISABLE = 'Days unreachable until disable action '
        ENABLE_INTERCEDE = 'Enable Intercede MyID on Client (default no)'

    class ElementNames:
        USE_CENTRIFY_AS_MDM = '/Mobile/DeviceManagement/UseCentrifyAsMdm'
        DEVICE_BASIC_INFO_FREQUENCY = '/Mobile/DeviceManagement/DeviceBasicInfoFrequencyTimeSpanInHours'
        DEVICE_UNREACHABLE_THRESHOLD = '/Mobile/DeviceManagement/DeviceUnreachableThresholdInDays'
        DISABLE_UNREACHABLE_CLIENTS = '/Mobile/DeviceManagement/DisableUnreachableClient'
        DISABLE_ACTION = '/Mobile/DeviceManagement/DisableAction'
        DAYS_UNTIL_DISABLE = '/Mobile/DeviceManagement/DaysUntilDisableAction'
        ENABLE_INTERCEDE = '/Mobile/Software/Policies/Centrify/Application/Security/Intercede/EnableIntercedeDerivedCredntialProvisioning'


class DeviceEnrollmentSettings:
    class TextConstants:
        PERMIT_DEVICE_ENROLLMENT = 'Permit device enrollment'
        ADD_DEVICE_OPTIONS = 'Customize user portal Add Devices options'
        ONLY_CORPORATE_DEVICES = 'Permit only corporate device enrollment'
        NON_COMPLIANT_DEVICES = 'Permit non-compliant devices to enroll'
        INVITE_BASED_ENROLLMENT = 'Enable invite based enrollment'
        INVITE_BASED_EXPIRATION = 'Invite based enrollment link expiration (default 60 minutes) *'
        MAX_DEVICES = 'Max number of devices a user can enroll (default 20)'
        NOTIFY_ON_DEVICE_ENROLL = 'Send notification on device enrollment'
        WELCOME_TEXT_ON_DEVICE_ENROLL = 'Show welcome text on device enrollment'
        ALLOW_PERSONAL_DEVICE = 'Allow personal or company owned device selection during enrollment'
        DEFAULT_COMPANY_OWNED = 'Default company owned'
        PERMIT_ANDROID = 'Permit Android device enrollment'
        PERMIT_IOS = 'Permit iOS device enrollment'
        PERMIT_OSX = 'Permit OS X device enrollment'
        ENROLL_MAC_PROMPT = 'Enable "Enroll your Mac" prompt at portal login'
        PERMIT_WINDOWS = 'Permit Windows device enrollment'
        DISPLAY_SMS = 'Display SMS enrollment option'
        DISPLAY_EMAIL = 'Display Email enrollment option'
        DISPLAY_QR_CODE = 'Display QR code enrollment option'
        ANDROID_ENROLLMENT_RULES = 'Enrollment rules (must evaluate to true to enroll)'

    class ElementNames:
        PERMIT_DEVICE_ENROLLMENT = '/Mobile/EnrollRules/Common/AllowEnrollment'
        ADD_DEVICE_OPTIONS = '/Mobile/EnrollRules/Common/CustomizeAddDevicesOptions'
        ONLY_CORPORATE_DEVICES = '/Mobile/DeviceManagement/PermitOnlyCorporateDeviceEnrollment'
        NON_COMPLIANT_DEVICES = '/Mobile/EnrollRules/Common/AllowJailBrokenDevices'
        INVITE_BASED_ENROLLMENT = '/Mobile/DeviceManagement/EnableInviteBasedEnrollment'
        INVITE_BASED_EXPIRATION = '/Mobile/DeviceManagement/InviteBasedEnrollmentTimeoutInMins'
        MAX_DEVICES = '/Mobile/EnrollRules/Common/MaxNumberOfDevicesPerUser'
        NOTIFY_ON_DEVICE_ENROLL = '/Mobile/EnrollRules/Common/SendEnrollmentNotification'
        WELCOME_TEXT_ON_DEVICE_ENROLL = '/Mobile/DeviceManagement/ShowWelcomeScreen'
        ALLOW_PERSONAL_DEVICE = '/Mobile/DeviceManagement/ShowOwnershipSelection'
        DEFAULT_COMPANY_OWNED = '/Mobile/DeviceManagement/DefaultCorporateOwned'
        PERMIT_ANDROID = '/Mobile/EnrollRules/Android/AllowEnrollment'
        PERMIT_IOS = '/Mobile/EnrollRules/iOS/AllowEnrollment'
        PERMIT_OSX = '/Mobile/EnrollRules/Mac/AllowEnrollment'
        ENROLL_MAC_PROMPT = '/Mobile/EnrollRules/Mac/ShowMacEnrollmentPrompt'
        PERMIT_WINDOWS = '/Mobile/EnrollRules/Windows/AllowEnrollment'
        DISPLAY_SMS = '/Mobile/EnrollRules/Common/CustomizeAddDevicesOptions/DisplaySMSEnrollment'
        DISPLAY_EMAIL = '/Mobile/EnrollRules/Common/CustomizeAddDevicesOptions/DisplayEmailEnrollment'
        DISPLAY_QR_CODE = '/Mobile/EnrollRules/Common/CustomizeAddDevicesOptions/DisplayQRCodeEnrollment'


class CommonMobileWifiSettings:
    class TextConstants:
        HEADER = 'Wi-Fi Settings'
        ADD = 'Add'
        SSID = 'SSID_STR'
        AUTO_JOIN = 'Auto join'
        HIDDEN_NETWORK = 'Hidden network'
        SECURITY_TYPE = 'Security type'
        PASSWORD = 'Password'
        ALL_DEVICES = 'All Devices'
        IOS_ONLY = 'iOS only'
        OS_X_ONLY = 'OS X only'
        ANDROID_ONLY = 'Android only'
        CANCEL = 'Cancel'
        SAVE = 'Save'

    class ElementNames:
        HEADER = 'Wi-Fi Settings'
        ADD = 'Add'
        SSID = 'SSID_STR'
        AUTO_JOIN = 'Auto join'
        HIDDEN_NETWORK = 'HIDDEN_NETWORK'
        SECURITY_TYPE = 'EncryptionType'
        PASSWORD = 'Password'
        ALL_DEVICES = 'All Devices'
        IOS_ONLY = 'iOS only'
        OS_X_ONLY = 'OS X only'
        ANDROID_ONLY = 'Android only'
        CANCEL = 'Cancel'
        SAVE = 'Save'


class IosSettingsKioskMode:
    class TextConstants:
        HEADER = 'Kiosk Mode'
        KIOSK_MODE = 'Enable Kiosk Mode (Supervised Only)'
        USE_MDM = 'Use MDM client as kiosk mode application'
        USE_BUILT_IN = 'Use built-in application as kiosk mode application'
        USE_CUSTOM = 'Use custom application as kiosk mode application'
        BUILT_IN = 'Select built-in application *'
        BUNDLE_IDENTIFIER = 'Application Bundle Identifier '
        DISABLE_TOUCH = 'Disable touch'
        DISABLE_DEVICE = 'Disable device rotation'
        DISABLE_VOLUME = 'Disable volume buttons'
        DISABLE_SIDE = 'Disable side switch'
        DISABLE_SLEEP = 'Disable sleep-wake button'
        DISABLE_AUTO = 'Disable auto-lock'
        ENABLE_VOICE_OVER = 'Enable voice-over'
        ENABLE_ZOOM = 'Enable zoom'
        ENABLE_INVERT_COLORS = 'Enable invert colors'
        ENABLE_ASSISTIVE_TOUCH = 'Enable assistive touch'
        ENABLE_SPEAK_SELECTION = 'Enable speak selection'
        ENABLE_MONO_AUDIO = 'Enable mono-audio'
        VOICE_OVER_SETTING = 'Allow user to control voice-over setting'
        ZOOM_SETTING = 'Allow user to control zoom setting'
        INVERT_COLOR_SETTING = 'Allow user to control invert-color setting'
        ASSISTIVE_TOUCH_SETTING = 'Allow user to control assistive touch setting'

    class ElementNames:
        HEADER = 'Kiosk Mode'
        KIOSK_MODE = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/KioskModeEnabled'
        USE_MDM = 'Use MDM client as kiosk mode application'
        USE_BUILT_IN = 'Use built-in application as kiosk mode application'
        USE_CUSTOM = 'Use custom application as kiosk mode application'
        BUILT_IN = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/KioskAppleAppPackageName'
        BUNDLE_IDENTIFIER = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/KioskPackageName'
        DISABLE_TOUCH = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionDisableTouch'
        DISABLE_DEVICE = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionDisableDeviceRotation'
        DISABLE_VOLUME = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionDisableVolumeButtons'
        DISABLE_SIDE = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionDisableRingerSwitch'
        DISABLE_SLEEP = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionDisableSleepWakeButton'
        DISABLE_AUTO = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionDisableAutoLock'
        ENABLE_VOICE_OVER = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionEnableVoiceOver'
        ENABLE_ZOOM = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionEnableZoom'
        ENABLE_INVERT_COLORS = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionEnableInvertColors'
        ENABLE_ASSISTIVE_TOUCH = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionEnableAssistiveTouch'
        ENABLE_SPEAK_SELECTION = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionEnableSpeakSelection'
        ENABLE_MONO_AUDIO = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/OptionEnableMonoAudio'
        VOICE_OVER_SETTING = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/UserEnabledOptionVoiceOver'
        ZOOM_SETTING = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/UserEnabledOptionZoom'
        INVERT_COLOR_SETTING = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/UserEnabledOptionInvertColors'
        ASSISTIVE_TOUCH_SETTING = '/Mobile/Software/Policies/Centrify/iOSSettings/KioskSettings/UserEnabledOptionAssistiveTouch'


class IosSettingsGlobalHttpProxy:
    class TextConstants:
        HEADER = 'Global HTTP Proxy'
        GLOBAL_HTTP_PROXY = 'Enable Global HTTP Proxy (Supervised Only)'
        PROXY_TYPE = 'Proxy Type'
        PROXY_SERVER = 'Proxy Server *'
        PORT = 'Port *'
        USERNAME = 'Username'
        PASSWORD = 'Password'
        PROXY_PAC = 'Proxy PAC URL *'
        ALLOW_DIRECT_CONNECTION = 'Allow direct connection if PAC is unreachable'
        ALLOW_BYPASS_PROXY = 'Allow bypassing proxy to access captive networks'

    class ElementNames:
        HEADER = 'Global HTTP Proxy'
        GLOBAL_HTTP_PROXY = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/EnableHttpProxy'
        PROXY_TYPE = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyType'
        PROXY_SERVER = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyServer'
        PORT = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyServerPort'
        USERNAME = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyUsername'
        PASSWORD = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyPassword'
        PROXY_PAC = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyPACURL'
        ALLOW_DIRECT_CONNECTION = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyPACFallbackAllowed'
        ALLOW_BYPASS_PROXY = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableHttpProxy/ProxyCaptiveLoginAllowed'


class IosSettingsApplicationManagementSettings:
    class TextConstants:
        HEADER = 'Application Management Settings'
        PROMPT_USER = 'Number of times to prompt user to install application (non-supervised only)'
        PUSH_COMPANY_APPS = 'Push "Company Apps" to enrolled iOS devices'

    class ElementNames:
        HEADER = 'Application Management Settings'
        PROMPT_USER = '/Mobile/Software/Policies/Centrify/iOSSettings/MaxAppInstallNaggingPrompts'
        PUSH_COMPANY_APPS = '/Mobile/Software/Policies/Centrify/iOSSettings/EnableIosWebAppStore'


class CommonMobileCommon:
    class ElementNames:
        HEADER = 'Common'
        ALLOW_USER_NOTIFICATIONS = '/Mobile/Software/Policies/Centrify/Common/AllowNotificationOnMutipleDevices'
        ENABLE_DEBUG = '/Mobile/Software/Policies/Centrify/iOSSettings/AllowDebugLogging'
        ENCRYPT_INTERNAL = '/Mobile/Software/Policies/Centrify/iOSSettings/EncryptInternalStorage'
        REPORT_DEVICE = '/Mobile/Software/Policies/Centrify/Common/ReportInstalledApps'
        SHOW_PASSCODES = '/Mobile/Software/Policies/Centrify/Common/Restrictions/ShowPasscodesInterface'

    class TextConstants:
        HEADER = 'Common'
        ALLOW_USER_NOTIFICATIONS = 'Allow user notifications on multiple devices'
        ENABLE_DEBUG = 'Enable debug logging'
        ENCRYPT_INTERNAL = 'Encrypt internal onboard storage'
        REPORT_DEVICE = 'Report device installed applications'
        SHOW_PASSCODES = 'Show "Passcodes" interface in CyberArk Identity mobile application'


class CommonMobileSecurity:
    class ElementNames:
        HEADER = 'Security Settings'
        SHOW_MOBILEAUTH = '/Mobile/Software/Policies/Centrify/Application/Security/MobileAuthenticator/ShowMobileAuthenticator'
        ENFORCE_FINGERPRINT = '/Mobile/Software/Policies/Centrify/Application/Security/MobileAuthenticator/ForceFingerprintForMobileAuthenticator'
        ALLOW_APP_PIN = '/Mobile/Software/Policies/Centrify/Application/Security/MobileAuthenticator/ForceFingerprintForMobileAuthenticatorAllowFallbackAppPin'
        REQ_CLIENT_APP_PASSCODE = '/Mobile/Software/Policies/Centrify/Application/Passcode/ForceAppPin'
        AUTO_LOCK = '/Mobile/Software/Policies/Centrify/Application/Passcode/AppInactivityTimeout'
        LOCK_ON_EXIT = '/Mobile/Software/Policies/Centrify/Application/Passcode/AppLockOnExit'
        REQ_PASSCODE = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/forcePIN'
        PERMIT_SIMPLE = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/allowSimple'
        AUTO_LOCK_TIME = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/maxInactivity'
        MAX_FAILED_ATTEMPTS = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/maxFailedAttempts'
        GRACE_PERIOD_DEVICE_LOCK = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/maxGracePeriod'
        PASSCODE_HISTORY = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/pinHistory'
        MAX_PASSCODE_AGE = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/maxPINAgeInDays'
        MIN_COMPLEX_CHARS = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/minComplexChars'
        MIN_PASSCODE_LEN = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/minLength'
        REQ_ALPHANUM_VALUE = '/Mobile/Software/Policies/Centrify/iOSSettings/Passcode/requireAlphanumeric'

    class TextConstants:
        HEADER = 'Security Settings'
        SHOW_MOBILEAUTH = 'Show Mobile Authenticator by default'
        ENFORCE_FINGERPRINT = 'Enforce fingerprint scan for Mobile Authenticator'
        ALLOW_APP_PIN = 'Allow App PIN'
        REQ_CLIENT_APP_PASSCODE = 'Require client application passcode on device'
        AUTO_LOCK = 'Auto-Lock (minutes)'
        LOCK_ON_EXIT = 'Lock on exit'
        REQ_PASSCODE = 'Require passcode on device'
        PERMIT_SIMPLE = 'Permit simple value'
        AUTO_LOCK_TIME = 'Auto-Lock (minutes)'
        MAX_FAILED_ATTEMPTS = 'Maximum number of failed attempts'
        GRACE_PERIOD_DEVICE_LOCK = 'Grace period for device lock'
        PASSCODE_HISTORY = 'Passcode history'
        MAX_PASSCODE_AGE = 'Maximum passcode age (days)'
        MIN_COMPLEX_CHARS = 'Minimum number of complex characters'
        MIN_PASSCODE_LEN = 'Minimum passcode length'
        REQ_ALPHANUM_VALUE = 'Require alphanumeric value'


class IosDomainSettings:
    class ElementNames:
        HEADER = 'Domain Settings'

    class TextConstants:
        HEADER = 'Domain Settings'
        MANAGE_SAFARI_DOMAINS = 'Managed Safari Web Domains'
        UNMARKED_EMAIL = 'Unmarked Email Domains'


class OsxSettingsPermitSkipOpeningItem:
    class ElementNames:
        HEADER = 'Permit shift key to skip opening items when user logs in'
        PERMIT_KEY = '/Mobile/Software/Policies/Centrify/OSXSettings/LoginItems/allowShiftToPreventItemOpen'

    class TextConstants:
        HEADER = 'Permit shift key to skip opening items when user logs in'
        PERMIT_KEY = 'Permit shift key to skip opening items when user logs in'


class OsxSettingsApplicationManagement:
    class ElementNames:
        HEADER = 'Application Management'
        APPLICATION_MANAGEMENT = '/Mobile/Software/Policies/Centrify/OSXSettings/MunkiSettings/enableMunkiClient'

    class TextConstants:
        HEADER = 'Application Management'
        APPLICATION_MANAGEMENT = 'Enable Munki Managed Software Center client for application management'


class OsxSettingsSecurityPrivacySettings:
    class ElementNames:
        HEADER = 'Security and privacy settings'
        FILE_VAULT_ENCRYPTION = '/Mobile/Software/Policies/Centrify/OSXSettings/SecurityAndPrivacy/FileVault/FileVaultEnable'
        SECURITY_PRIVACY = '/Mobile/Software/Policies/Centrify/iOSSettings/SecurityAndPrivacy/securityAndPrivacy'
        RECOVERY_KEY = '/Mobile/Software/Policies/Centrify/OSXSettings/SecurityAndPrivacy/FileVault/ShowRecoveryKey'
        GATEKEEPER_SETTINGS = '/Mobile/Software/Policies/Centrify/iOSSettings/SecurityAndPrivacy/disableGatekeeperOverride'
        CHANGE_PASSWORD = '/Mobile/Software/Policies/Centrify/iOSSettings/SecurityAndPrivacy/allowUserToChangePassword'
        SCREEN_SAVER = '/Mobile/Software/Policies/Centrify/iOSSettings/SecurityAndPrivacy/requirePasswordAfterSleepOrScreensaver'
        SET_LOCK_MESSAGE = '/Mobile/Software/Policies/Centrify/iOSSettings/SecurityAndPrivacy/allowUserToSetLockMessage'

    class TextConstants:
        HEADER = 'Security and privacy settings'
        FILE_VAULT_ENCRYPTION = 'Enable FileVault Encryption'
        SECURITY_PRIVACY = 'Security and privacy settings'
        RECOVERY_KEY = 'Permit one-time display of recovery key on users Mac device'
        GATEKEEPER_SETTINGS = 'Do not allow user to override Gatekeeper settings'
        CHANGE_PASSWORD = 'Allow user to change password'
        SCREEN_SAVER = 'Require password after sleep or screen saver begins'
        SET_LOCK_MESSAGE = 'Allow user to set lock message'


class OsxSettingsManageLocalAdminAccount:
    class ElementNames:
        HEADER = 'Manage Local Admin Account'
        LOCAL_ADMIN_ACCOUNT = '/Mobile/Software/Policies/Centrify/OSXSettings/LocalAdminAccount/Enabled'
        ACCOUNT_NAME = '/Mobile/Software/Policies/Centrify/OSXSettings/LocalAdminAccount/AccountName'
        ROTATION_INTERVAL = '/Mobile/Software/Policies/Centrify/OSXSettings/LocalAdminAccount/RotationInterval'
        CHECKOUT_LIFETIME = '/Mobile/Software/Policies/Centrify/OSXSettings/LocalAdminAccount/DefaultCheckoutTime'
        ENROLLED_USER_CHECKOUT = '/Mobile/Software/Policies/Centrify/OSXSettings/LocalAdminAccount/AllowEnrolledUserCheckout'
        PASSWORD_GENERATION_PROFILE = '/Mobile/Software/Policies/Centrify/OSXSettings/LocalAdminAccount/PasswordGenerationProfileId'

    class TextConstants:
        HEADER = 'Manage Local Admin Account'
        LOCAL_ADMIN_ACCOUNT = 'Create and manage a local admin account.'
        ACCOUNT_NAME = 'Account Name *'
        ROTATION_INTERVAL = 'Periodic password rotation interval (days) *'
        CHECKOUT_LIFETIME = 'Checkout lifetime (minutes)'
        ENROLLED_USER_CHECKOUT = 'Allow the enrolled user to checkout the local admin password'
        PASSWORD_GENERATION_PROFILE = 'Password Generation Profile'


class SamgKNOXDeviceSettingsRoamingSettings:
    class ElementNames:
        HEADER = 'Roaming Settings'
        ROAMING_CELLULAR = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Roaming/RoamingDataEnabled'
        ROAMING_SYNC = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Roaming/RoamingSyncEnabled'
        ROAMING_VOICE_CALL = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Roaming/RoamingVoiceCallsEnabled'
        ROAMING_WAP = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Roaming/RoamingPushEnabled'

    class TextConstants:
        HEADER = 'Roaming Settings'
        ROAMING_CELLULAR = 'Enable roaming cellular data'
        ROAMING_SYNC = 'Enable roaming sync'
        ROAMING_VOICE_CALL = 'Enable roaming voice calls'
        ROAMING_WAP = 'Enable roaming WAP push'


class SamgKNOXDeviceSettingsSecuritySettings:
    class ElementNames:
        HEADER = 'Security Settings'
        BANNER_MESSAGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Security/RebootBannerEnabled'
        SIM_CARD_LOCK = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Security/SIMLockPin'
        SIM_CARD_REMOVAL = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Security/EnableSimRemovalAudit'
        REMOVABLE_STORAGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Security/EncryptExternalStorage'
        SIM_PIN = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Security/defaultPin'
        NEW_SIM_PIN = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Security/newPin'

    class TextConstants:
        HEADER = 'Security Settings'
        BANNER_MESSAGE = 'Enable banner message'
        SIM_CARD_LOCK = 'Enable SIM card lock'
        SIM_CARD_REMOVAL = 'Enable SIM card removal reporting'
        REMOVABLE_STORAGE = 'Encrypt removable storage'
        SIM_PIN = 'Default SIM PIN '
        NEW_SIM_PIN = 'New SIM PIN '


class SamgKNOXDeviceSettingsVpnRestrictions:
    class ElementNames:
        HEADER = 'VPN Restrictions'
        VPN_CONNECTIONS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/VPNPolicy/AllowOnlySecureConnections'

    class TextConstants:
        HEADER = 'VPN Restrictions'
        VPN_CONNECTIONS = 'Allow only IPsec or SSL/TLS VPN connections'


class SamgKNOXDeviceSettingsRestrictionsSettings:
    class ElementNames:
        HEADER = 'Restrictions Settings'
        FORCE_GPS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/ForceGps'
        ALLOW_BACKGROUND_DATA = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowBackgroundData'
        ALLOW_CLIPBOARD = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowClipboard'
        ALLOW_ANDROID_BEAM = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowAndroidBeam'
        ALLOW_AUDIO_RECORD = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowAudioRecord'
        ALLOW_BLUETOOTH = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowBluetooth'
        ALLOW_CELLULAR_DATA = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowCellularData'
        ALLOW_WALLPAPER_CHANGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowWallpaperChange'
        ALLOW_DATETIME_CHANGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowDateTimeChange'
        ALLOW_USB_MEDIA = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowUsbMediaPlayer'
        ALLOW_STATUSBAR_EXPANSION = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowStatusBarExpansion'
        ALLOW_FIRMWARE_RECOVERY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowFirmwareRecovery'
        ALLOW_BACKUP = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowBackup'
        ALLOW_HOMEKEY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowHomeKey'
        PERMIT_INCOMING_CALLS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/PermitIncomingCalls'
        ALLOW_NONMARKET_APPS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowNonMarketApps'
        ALLOW_KILLING_ACTIVITIES = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowKillingActivitiesOnLeave'
        ALLOW_MICROPHONE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowMicrophoneState'
        ALLOW_MOCK_LOCATION = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowMockLocation'
        ENABLE_MULTI_USERS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/EnableMultipleUsers'
        ALLOW_ENABLE_NFC = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowEnableNFC'
        ALLOW_POWER_OFF = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowPowerOff'
        ALLOW_SBEAM = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowSBeam'
        ALLOW_SVOICE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowSVoice'
        ALLOW_SAFE_MODE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowSafeMode'
        ALLOW_SCREEN_CAPTURE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowScreenCapture'
        ALLOW_SDCARD = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowSdCard'
        ALLOW_SDCARD_WRITE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowSDCardWrite'
        ALLOW_CRASH_REPORT = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowGoogleCrashReport'
        ALLOW_BACKGROUND_PROCESS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowBackgroundProcessLimit'
        ALLOW_USER_MOBILE_DATA = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowUserMobileDataLimit'
        ALLOW_SETTINGS_CHANGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowSettingsChanges'
        ALLOW_CLIPBOARD_SHARE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowClipboardShare'
        ALLOW_STOP_SYSTEM_APP = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowStopSystemApp'
        ALLOW_TETHERING = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowTethering'
        ALLOW_USB_TETHERING = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowUsbTethering'
        ALLOW_WIFI_TETHERING = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowWifiTethering'
        ALLOW_BLUETOOTH_TETHERING = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowBluetoothTethering'
        ALLOW_OTA_UPGRADE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowOTAUpgrade'
        ALLOW_USB_DEBUGGING = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowUsbDebugging'
        ALLOW_USB_HOST_STORAGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowUsbHostStorage'
        ALLOW_VIDEO_RECORD = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowVideoRecord'
        ALLOW_VPN = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowVpn'
        ALLOW_WIFI = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Restrictions/AllowWiFi'

    class TextConstants:
        HEADER = 'Restrictions Settings'
        FORCE_GPS = 'Force GPS'
        ALLOW_BACKGROUND_DATA = 'Permit access to manage background data usage'
        ALLOW_CLIPBOARD = 'Permit access to the clipboard'
        ALLOW_ANDROID_BEAM = 'Permit Android Beam use'
        ALLOW_AUDIO_RECORD = 'Permit audio recording'
        ALLOW_BLUETOOTH = 'Permit Bluetooth access'
        ALLOW_CELLULAR_DATA = 'Permit cellular data use'
        ALLOW_WALLPAPER_CHANGE = 'Permit changing wallpaper'
        ALLOW_DATETIME_CHANGE = 'Permit date and time change'
        ALLOW_USB_MEDIA = 'Permit device as a media player via USB'
        ALLOW_STATUSBAR_EXPANSION = 'Permit expansion of status bar'
        ALLOW_FIRMWARE_RECOVERY = 'Permit firmware recovery'
        ALLOW_BACKUP = 'Permit Google backup'
        ALLOW_HOMEKEY = 'Permit home key functionality'
        PERMIT_INCOMING_CALLS = 'Permit incoming calls'
        ALLOW_NONMARKET_APPS = 'Permit installation of non-Google-Play apps'
        ALLOW_KILLING_ACTIVITIES = 'Permit killing an activity when user leaves it'
        ALLOW_MICROPHONE = 'Permit microphone use'
        ALLOW_MOCK_LOCATION = 'Permit mock GPS locations'
        ENABLE_MULTI_USERS = 'Permit multiple users'
        ALLOW_ENABLE_NFC = 'Permit NFC use'
        ALLOW_POWER_OFF = 'Permit power off'
        ALLOW_SBEAM = 'Permit S Beam use'
        ALLOW_SVOICE = 'Permit S Voice application use'
        ALLOW_SAFE_MODE = 'Permit safe mode launch'
        ALLOW_SCREEN_CAPTURE = 'Permit screen capture'
        ALLOW_SDCARD = 'Permit SD card access'
        ALLOW_SDCARD_WRITE = 'Permit SD card write'
        ALLOW_CRASH_REPORT = 'Permit sending crash report to Google'
        ALLOW_BACKGROUND_PROCESS = 'Permit setting a background process limit'
        ALLOW_USER_MOBILE_DATA = 'Permit setting mobile data limit'
        ALLOW_SETTINGS_CHANGE = 'Permit settings changes'
        ALLOW_CLIPBOARD_SHARE = 'Permit sharing the clipboard between applications'
        ALLOW_STOP_SYSTEM_APP = 'Permit stopping system app'
        ALLOW_TETHERING = 'Permit Tethering'
        ALLOW_USB_TETHERING = 'Permit USB Tethering'
        ALLOW_WIFI_TETHERING = 'Permit Wi-Fi Tethering'
        ALLOW_BLUETOOTH_TETHERING = 'Permit Bluetooth Tethering'
        ALLOW_OTA_UPGRADE = 'Permit upgrading the operating system (OS) over-the-air (OTA)'
        ALLOW_USB_DEBUGGING = 'Permit USB debugging'
        ALLOW_USB_HOST_STORAGE = 'Permit USB host storage'
        ALLOW_VIDEO_RECORD = 'Permit video recording'
        ALLOW_VPN = 'Permit VPN use'
        ALLOW_WIFI = 'Permit Wi-Fi use'


class SamgKNOXDeviceSettingsWifiRestrictions:
    class ElementNames:
        HEADER = 'Wi-Fi Restrictions'
        CERTIFICATE_SECURITY_LEVEL = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/TlsCertificateSecurityLevel'
        MINIMUM_REQUIRED_SECURITY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/MinimumRequiredSecurity'
        ALLOW_USER_PROFILES = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/AllowUserProfiles'
        ALLOW_WIFI_STATE_CHANGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/AllowWifiStateChange'
        ALLOW_AUTOMATIC_CONNECTION = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/AllowAutomaticConnectionToWifi'
        ALLOW_WIFI_AP_SETTING = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/AllowWifiApSettingUserModification'
        ALLOW_USER_POLICY_CHANGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/AllowUserPolicyChanges'
        ALLOW_OPEN_WIFI_AP = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/AllowOpenWifiAp'
        PROMPT_CREDENTIALS_ENABLED = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/PromptCredentialsEnabled'
        PASSWORD_HIDDEN = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/PasswordHidden'
        WIFI_AP_SETTINGS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/WiFiPolicy/WiFiApSettings'
        SSID = 'SSID'
        SECURITY_TYPE = 'SecurityType'
        PASSWORD = 'Password'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Wi-Fi Restrictions'
        CERTIFICATE_SECURITY_LEVEL = 'Minimum certificate security level for EAP-TLS networks'
        MINIMUM_REQUIRED_SECURITY = 'Minimum security level of connected Wi-Fi'
        ALLOW_USER_PROFILES = 'Permit user to add Wi-Fi networks'
        ALLOW_WIFI_STATE_CHANGE = 'Permit user to change the Wi-Fi state'
        ALLOW_AUTOMATIC_CONNECTION = 'Permit user to connect automatically to known Wi-Fi networks'
        ALLOW_WIFI_AP_SETTING = 'Permit user to edit Wi-Fi AP settings'
        ALLOW_USER_POLICY_CHANGE = 'Permit user to modify Wi-Fi settings'
        ALLOW_OPEN_WIFI_AP = 'Permit user to start an open (non-secured) Wi-Fi hotspot'
        PROMPT_CREDENTIALS_ENABLED = 'Prompt user to re-enter credentials if WPA/WPA2-PSK authentication fails'
        PASSWORD_HIDDEN = 'Show password in the Wi-Fi network edit dialog'
        WIFI_AP_SETTINGS = 'Wi-Fi access point settings'
        SSID = 'SSID'
        SECURITY_TYPE = 'Security type'
        PASSWORD = 'Password *'
        ADD = 'Add'


class CommonMobileRestrictions:
    class ElementNames:
        HEADER = 'Restrictions Settings'
        PERMIT_CAMERA_USE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowCamera'
        PERMIT_USER_UNENROLL = '/Mobile/Software/Policies/Centrify/Common/Restrictions/AllowDeviceUnenrollmentByUser'
        PERMIT_USER_WIPE = '/Mobile/Software/Policies/Centrify/Common/Restrictions/AllowDeviceWipeByUser'
        REPORT_MOB_LOC = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/LocationTracking'
        PERMIT_ADMIN = '/Mobile/Software/Policies/Centrify/Common/Restrictions/AdminLocationTracking'
        ALLOW_FACETIME = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowVideoConferencing'

    class TextConstants:
        HEADER = 'Restrictions Settings'
        PERMIT_CAMERA_USE = 'Permit camera use'
        PERMIT_USER_UNENROLL = 'Permit user to unenroll devices'
        PERMIT_USER_WIPE = 'Permit user to wipe devices'
        REPORT_MOB_LOC = 'Report mobile device location'
        PERMIT_ADMIN = 'Permit administrator to see device location'
        ALLOW_FACETIME = 'Allow FaceTime (iOS only)'


class EndpointPoliciesTouchdownSettings:
    class TextConstants:
        HEADER = 'Touchdown Settings'
        ENABLE_TOUCHDOWN = 'Enable Touchdown and active sync settings'
        PAST_DAYS = 'Past days of mail to sync'

    class ElementNames:
        HEADER = 'Touchdown Settings'
        ENABLE_TOUCHDOWN = 'ExchangeActiveSync'
        PAST_DAYS = 'MailNumberOfPastDaysToSync'


class AndroidManagementSettingsEnableWorkProfiles:
    class TextConstants:
        HEADER = 'Enable Work Profiles'
        WORK_PROFILES = 'Enable Work Profiles'

    class ElementNames:
        HEADER = 'Enable Work Profiles'
        WORK_PROFILES = '/Mobile/Software/Policies/Centrify/AndroidForWork/EnableManagedProfiles'


class ExchangeSettings:
    class TextConstants:
        HEADER = 'Exchange Settings'
        ENABLE_EXC_SYNC = 'Enable Exchange ActiveSync settings'
        BASIC = 'Basic'

    class ElementNames:
        HEADER = 'Exchange Settings'
        ENABLE_EXC_SYNC = 'ExchangeActiveSync'
        BASIC = 'Basic'


class SamsunKnoxApplicationManagement:
    class TextConstants:
        HEADER = 'Application Management'
        PER_RESTRICTION_BLOCK = 'Permission restrictions to block third-party apps'
        ADD = 'Add'
        BLOCK_APPS_NOTIFICATIONS = 'Block applications from showing status bar notifications'
        PREVENT_APPS_INSTALL = 'Prevent installation of applications'

    class ElementNames:
        HEADER = 'Application Management'
        PER_RESTRICTION_BLOCK = 'Permission restrictions to block third-party apps'
        ADD = 'Add'
        BLOCK_APPS_NOTIFICATIONS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Application/ApplicationNotificationMode'
        PREVENT_APPS_INSTALL = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Application/InstallationMode'


class SamsungKnoxKioskMode:
    class TextConstants:
        HEADER = 'Kiosk Mode'
        ENABLE_KIOSK = 'Enable Kiosk Mode'
        PER_MULTI_WIN = 'Permit multi-window mode'
        PER_NAVBAR_VISIBILITY = 'Permit navigation bar visibility'
        PER_STATUSBAR_VISIBILITY = 'Permit status bar visibility'
        PER_TASK_MANAGER = 'Permit task manager access'
        USE_DEFAULT_HOME = 'Use default(Android) home screen as home launcher'
        USE_CUSTOM_LAUNCHER = 'Use custom launcher as home launcher'
        PACKAGE_NAME = 'Package Name'
        USE_MDM_CLIENT = 'Use MDM client as home launcher'
        ENABLE_AUTO_UPDATE = 'Enable automatic update'
        ENABLE_AUTO_UPDATE_TIME = 'Enable automatic update time'
        AUTO_UPDATE_TIME = 'Automatic update time:'

    class ElementNames:
        HEADER = 'Kiosk Mode'
        ENABLE_KIOSK = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/kioskModeEnabled'
        PER_MULTI_WIN = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/AllowMultiWindowMode'
        PER_NAVBAR_VISIBILITY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/NavigationBarVisibility'
        PER_STATUSBAR_VISIBILITY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/StatusBarVisibility'
        PER_TASK_MANAGER = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/AllowTaskManagerAccess'
        USE_DEFAULT_HOME = 'Use default(Android) home screen as home launcher'
        USE_CUSTOM_LAUNCHER = 'Use custom launcher as home launcher'
        PACKAGE_NAME = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/kioskPackageName'
        USE_MDM_CLIENT = 'Use MDM client as home launcher'
        ENABLE_AUTO_UPDATE = 'Enable automatic update'
        ENABLE_AUTO_UPDATE_TIME = 'Enable automatic update time'
        AUTO_UPDATE_TIME = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/KioskMode/kioskAppUpdateTime'


class IOSSettingsCalenderSettings:
    class TextConstants:
        HEADER = "Calendar Settings"

    class ElementNames:
        HEADER = "Calendar Settings"


class IOSSettingsExchangeSettings:
    class TextConstants:
        HEADER = "Exchange Settings"

    class ElementNames:
        HEADER = "Exchange Settings"


class IOSSettingsLdapSettings:
    class TextConstants:
        HEADER = "LDAP Settings"

    class ElementNames:
        HEADER = "LDAP Settings"


class IOSSettingsMailSettings:
    class TextConstants:
        HEADER = "Mail Settings"

    class ElementNames:
        HEADER = "Mail Settings"


class IOSSettingsProvisioningProfiles:
    class TextConstants:
        HEADER = "Provisioning Profiles"

    class ElementNames:
        HEADER = "Provisioning Profiles"


class OSXIOSSettingsCertificateProfiles:
    class TextConstants:
        HEADER = "Certificate Profiles"

    class ElementNames:
        HEADER = "Certificate Profiles"


class OSXIOSSettingsVPNSettings:
    class TextConstants:
        HEADER = "VPN Settings"

    class ElementNames:
        HEADER = "VPN Settings"


class OSXIOSSettingsConfigurationProfiles:
    class TextConstants:
        HEADER = "Configuration Profiles"

    class ElementNames:
        HEADER = "Configuration Profiles"


class OSXSettingsOpenApplications:
    class TextConstants:
        HEADER = "Open applications when user logs in"

    class ElementNames:
        HEADER = "Open applications when user logs in"


class OSXSettingsCustomSettings:
    class TextConstants:
        HEADER = "Custom Settings"

    class ElementNames:
        HEADER = "Custom Settings"


class OSXSettingsOpenAuthenticatedNetworkMounts:
    class TextConstants:
        HEADER = "Open authenticated network mounts when user logs in"

    class ElementNames:
        HEADER = "Open authenticated network mounts when user logs in"


class SamgKNOXDeviceSettingsPasswordSettings:
    class ElementNames:
        HEADER = 'Password Settings'
        PASSWORD_VISIBILITY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/PasswordVisibilityEnabled'
        PATTERN_VISIBILITY = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/ScreenLockPatternVisibilityEnabled'
        FINGERPRINT_AUTHENTICATION = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/FingerprintAuthEnabled'
        FAILED_PASSWORD_WIPE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/ExcludeExternalStorageForFailedPasswordsWipe'
        DEVICE_DISABLE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/MaximumFailedPasswordsForDeviceDisable'
        CHANGED_CHARACTER = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/MinimumCharacterChangeLength'
        PASSWORD_CHANGE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/PasswordChangeTimeout'
        MAXIMUM_CHARACTER_SEQUENCE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/MaximumCharacterSequenceLength'
        MAXIMUM_NUMERIC_SEQUENCE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/MaximumNumericSequenceLength'
        MAXIMUM_OCCURANCE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/MaximumCharacterOccurrences'
        PASSWORD_PATTERN = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Password/PasswordPattern'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Password Settings'
        PASSWORD_VISIBILITY = 'Enable password visibility'
        PATTERN_VISIBILITY = 'Enable screen lock pattern visibility'
        FINGERPRINT_AUTHENTICATION = 'Enable lock screen fingerprint authentication'
        FAILED_PASSWORD_WIPE = 'Exclude external storage for failed passwords wipe'
        DEVICE_DISABLE = 'Maximum failed password attempt for disabled device'
        CHANGED_CHARACTER = 'Minimum number of changed characters in password'
        PASSWORD_CHANGE = 'Timeout for password change enforcement'
        MAXIMUM_CHARACTER_SEQUENCE = 'Maximum character sequence length in password'
        MAXIMUM_NUMERIC_SEQUENCE = 'Maximum numeric sequence length in password'
        MAXIMUM_OCCURANCE = 'Maximum occurrences of a character in password'
        PASSWORD_PATTERN = 'Password pattern enforcement'
        ADD = 'Add'


class SamsungKNOXWorkspaceEnableKNOXContainer:
    class ElementNames:
        HEADER = 'Enable KNOX Container'
        CONTAINER_CREATE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/containerCreate'

    class TextConstants:
        HEADER = 'Enable KNOX Container'
        CONTAINER_CREATE = 'Enable KNOX Container'


class SamsungKNOXWorkspaceEnableTIMAKeyStore:
    class ElementNames:
        HEADER = 'Enable TIMA Key Store'
        ENABLE_TIMA_KEY = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnableTimaKeyStore'

    class TextConstants:
        HEADER = 'Enable TIMA Key Store'
        ENABLE_TIMA_KEY = 'Enable TIMA Key Store'


class SamsungKNOXWorkspaceEnableODE:
    class ElementNames:
        HEADER = 'Enable ODE Trusted Boot verification'
        ODE_TRUSTED_BOOT = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/ODETrustedBootVerification'

    class TextConstants:
        HEADER = 'Enable ODE Trusted Boot verification'
        ODE_TRUSTED_BOOT = 'Enable ODE Trusted Boot verification'


class SamsungKNOXWorkspaceEnableCommonCriteriaMode:
    class ElementNames:
        HEADER = 'Enable Common Criteria mode'
        CCMODE_ENABLE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/CCModeEnable'
        MAXIMUM_ATTEMPTS = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/CCModeMaximumAttemptsBeforeWipe'

    class TextConstants:
        HEADER = 'Enable Common Criteria mode'
        CCMODE_ENABLE = 'Enable Common Criteria mode'
        MAXIMUM_ATTEMPTS = 'Maximum number of failed attempts'


class SamsungKNOXWorkspaceRequireAttestationVerification:
    class ElementNames:
        HEADER = 'Require Attestation Verification'
        ATTESTATION_VERIFICATION = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/AttestationVerification'

    class TextConstants:
        HEADER = 'Require Attestation Verification'
        ATTESTATION_VERIFICATION = 'Require attestation verification'


class SamsungKNOXWorkspaceVPNSettings:
    class ElementNames:
        HEADER = 'VPN Settings'
        VPN_MODE_OPERATION = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/VPNModeOfOperation'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'VPN Settings'
        VPN_MODE_OPERATION = 'VPN mode of operation'
        ADD = 'Add'


class SamsungKNOXWorkspaceConfigureApplicationContainer:
    class ElementNames:
        HEADER = 'Configure applications that can sync with container'
        ALLOW_DATA_SYNC = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/AllowDataSync'
        PREVIEW_NOTIFICATIONS = 'preview_notifications_allow'
        EXPORT_CONTACTS = 'export_contacts_allow'
        EXPORT_S_PLANNER = 'export_splanner_allow'
        IMPORT_CONTACTS = 'import_contacts_allow'
        IMPORT_S_PLANNER = 'import_splanner_allow'

    class TextConstants:
        HEADER = 'Configure applications that can sync with container'
        ALLOW_DATA_SYNC = 'Configure applications that can sync with container'
        PREVIEW_NOTIFICATIONS = 'Preview KNOX notifications'
        EXPORT_CONTACTS = 'Contacts'
        EXPORT_S_PLANNER = 'S Planner (Calendar)'
        IMPORT_CONTACTS = 'Contacts'
        IMPORT_S_PLANNER = 'S Planner (Calendar)'


class SamsungKNOXWorkspaceEnterpriseBilling:
    class ElementNames:
        HEADER = 'Enterprise Billing'
        ENABLE_ENTERPRISE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnterpriseBilling/ContainerBilling/ContainerBillingEnabled'
        PROFILE_NAME = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnterpriseBilling/ContainerBilling/ProfileName'
        ACCESS_POINT_NAME = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnterpriseBilling/ContainerBilling/name'
        MOBILE_COUNTRY_CODE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnterpriseBilling/ContainerBilling/MCC'
        MOBILE_NETWORK_CODE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnterpriseBilling/ContainerBilling/MNC'

    class TextConstants:
        HEADER = 'Enterprise Billing'
        ENABLE_ENTERPRISE = 'Enable Enterprise Billing'
        PROFILE_NAME = 'Profile Name *'
        ACCESS_POINT_NAME = 'Access Point Name *'
        MOBILE_COUNTRY_CODE = 'Mobile Country Code *'
        MOBILE_NETWORK_CODE = 'Mobile Network Code *'


class SamgKNOXDeviceSettingsDeviceInventorySettings:
    class TextConstants:
        HEADER = 'Device Inventory Settings'
        ENABLE_LOG_CALL_INFO = 'Enable logging of call information'
        ENABLE_LOG_CELLULAR_DATA = 'Enable logging of cellular data network statistics'
        ENABLE_LOG_WIFI = 'Enable logging of Wi-Fi network statistics'
        TIME_BETWEEN_UPDATES = 'Time between updates of data logging'

    class ElementNames:
        HEADER = 'Device Inventory Settings'
        ENABLE_LOG_CALL_INFO = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/DeviceInventory/CallingCaptureEnabled'
        ENABLE_LOG_CELLULAR_DATA = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/DeviceInventory/DataCallStatisticsEnabled'
        ENABLE_LOG_WIFI = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/DeviceInventory/WifiStatisticEnabled'
        TIME_BETWEEN_UPDATES = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/DeviceInventory/DataUsageTimer'


class UserSecuriyPoliciesOathOtp:
    class TextConstants:
        HEADER = 'OATH OTP'
        ALLOW_OATH = 'Allow OATH OTP integration'

    class ElementNames:
        HEADER = 'OATH OTP'
        ALLOW_OATH = '/Core/Security/CDS/ExternalMFA/ShowQRCode'


class UserSecurityPoliciesRadius:
    class TextConstants:
        HEADER = 'RADIUS'
        ALLOW_RADIUS_CLIENT = 'Allow RADIUS client connections'
        REQUIRE_AUTH_CHALLENGE = 'Require authentication challenge'
        AUTH_PROFILE = 'Default Authentication Profile*'
        SEND_VENDOR_SPECIFIC = 'Send vendor specific attributes'
        ADD_ATTRIBUTES = 'Add Attributes'
        ALLOW_3RD_PARTY_RADIUS = 'Allow 3rd Party RADIUS Authentication'

    class ElementNames:
        HEADER = 'RADIUS'
        ALLOW_RADIUS_CLIENT = '/Core/Authentication/AllowRadius'
        REQUIRE_AUTH_CHALLENGE = '/Core/Authentication/RadiusUseChallenges'
        AUTH_PROFILE = '/Core/Authentication/RadiusChallengeProfile'
        SEND_VENDOR_SPECIFIC = '/Core/Authentication/SendRadiusVendorSpecificAttributes'
        ADD_ATTRIBUTES = 'Add Attributes'
        ALLOW_3RD_PARTY_RADIUS = '/Core/Authentication/AllowExternalRadius'


class UserSecurityPoliciesPasswordSettings:
    class TextConstants:
        HEADER = 'Password Settings'
        # Password Requirements
        MIN_PASSWORD_LENGTH = 'Minimum password length (default 8)'
        MAX_PASSWORD_LENGTH = 'Maximum password length (default 64)'
        REQ_ATLEAST_ONE_DIGIT = 'Require at least one digit (default yes)'
        REQ_ATLEAST_ONE_UPPERLOWER = 'Require at least one upper case and one lower case letter (default yes)'
        REQ_ATLEAST_ONE_SYMBOL = 'Require at least one symbol (default no)'

        # Display Requirements
        SHOW_PWD_COMPLEXITY_REQ = 'Show password complexity requirements when entering a new password (default no)'
        PWD_COMPLEXITY_REQ_DIRECTOY_SERVICES = 'Password complexity requirements for directory services other than CyberArk Cloud Directory'

        # Additional Requirements
        LIMIT_CONSECUTIVE_REP_CHAR = 'Limit the number of consecutive repeated characters'
        CHCK_AGAINST_WEAK_PWD = 'Check against weak password'
        ALLOW_USERNAME_PART_PWD = 'Allow username as part of password'
        ALLOW_DISPLAYNAME_PART_PWD = 'Allow display name as part of password'
        REQ_ATLEAST_ONE_UNICODE = 'Require at least one Unicode characters'

        # Passworde Age
        MIN_PWD_AGE = 'Minimum password age before change is allowed (default 0 days)'
        MAX_PWD_AGE = 'Maximum password age (default 365 days)'
        PWD_HISTORY = 'Password history (default 3)'
        PWD_EXPIRATION_NOT = 'Password Expiration Notification (default 14 days)'
        ESCALATE_PWD_EXPIRATION = 'Escalated Password Expiration Notification (default 48 hours)'
        ENABLE_PWD_EXPIRATION = 'Enable password expiration notifications on enrolled mobile devices'

        # Capture Settings
        MAX_CONSECUTIVE_BAD_PWD_ATTEMTS = 'Maximum consecutive bad password attempts allowed within window (default Off)'
        CAPTURE_WINDOW_CONSECUTIVE_BAD_ATTEMPTES = 'Capture window for consecutive bad password attempts (default 30 minutes)'
        LOCKOUT_DURATION = 'Lockout duration before password re-attempt allowed (default 30 minutes)'

    class ElementNames:
        HEADER = 'Password Settings'
        # Password Requirements
        MIN_PASSWORD_LENGTH = '/Core/Security/CDS/PasswordPolicy/MinLength'
        MAX_PASSWORD_LENGTH = '/Core/Security/CDS/PasswordPolicy/MaxLength'
        REQ_ATLEAST_ONE_DIGIT = '/Core/Security/CDS/PasswordPolicy/RequireDigit'
        REQ_ATLEAST_ONE_UPPERLOWER = '/Core/Security/CDS/PasswordPolicy/RequireMixCase'
        REQ_ATLEAST_ONE_SYMBOL = '/Core/Security/CDS/PasswordPolicy/RequireSymbol'

        # Display Requirements
        SHOW_PWD_COMPLEXITY_REQ = '/Core/Security/CDS/PasswordPolicy/ShowPasswordComplexity'
        PWD_COMPLEXITY_REQ_DIRECTOY_SERVICES = '/Core/Security/CDS/PasswordPolicy/NonCdsComplexityHint'

        # Additional Requirements
        LIMIT_CONSECUTIVE_REP_CHAR = '/Core/Security/CDS/PasswordPolicy/AllowRepeatedChar'
        CHCK_AGAINST_WEAK_PWD = '/Core/Security/CDS/PasswordPolicy/CheckWeakPassword'
        ALLOW_USERNAME_PART_PWD = '/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername'
        ALLOW_DISPLAYNAME_PART_PWD = '/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname'
        REQ_ATLEAST_ONE_UNICODE = '/Core/Security/CDS/PasswordPolicy/RequireUnicode'

        # Passworde Age
        MIN_PWD_AGE = '/Core/Security/CDS/PasswordPolicy/MinAgeInDays'
        MAX_PWD_AGE = '/Core/Security/CDS/PasswordPolicy/AgeInDays'
        PWD_HISTORY = '/Core/Security/CDS/PasswordPolicy/History'
        PWD_EXPIRATION_NOT = '/Core/PasswordReset/NotifySoft'
        ESCALATE_PWD_EXPIRATION = '/Core/PasswordReset/NotifyHard'
        ENABLE_PWD_EXPIRATION = '/Core/PasswordChange/NotifyOnMobile'

        # Capture Settings
        MAX_CONSECUTIVE_BAD_PWD_ATTEMTS = '/Core/Security/CDS/LockoutPolicy/Threshold'
        CAPTURE_WINDOW_CONSECUTIVE_BAD_PWD_ATTEMPTS = '/Core/Security/CDS/LockoutPolicy/Window'
        LOCKOUT_DURATION = '/Core/Security/CDS/LockoutPolicy/Duration'


class AndroidManagementSettingsExchangeSettings:
    class TextConstants:
        HEADER = 'Exchange Settings'
        ENABLE_EXCHANGE_ACTIVE = 'Enable Exchange ActiveSync settings'
        BASIC = 'Basic'

    class ElementNames:
        HEADER = 'Exchange Settings'
        ENABLE_EXCHANGE_ACTIVESYNC = 'ExchangeActiveSync'
        BASIC = 'Basic'


class AndroidManagementSettingsCertificateProfiles:
    class TextConstants:
        HEADER = 'Certificate Profiles'
        ADD = 'Add'
        PUSH_USER = 'Push user certificate to Android device'

    class ElementNames:
        HEADER = 'Certificate Profiles'
        ADD = 'Add'
        PUSH_USER = '/Mobile/Software/Policies/Centrify/AndroidForWork/CertProfiles/PushUserCertToClient'


class IosSettingsRestrictionsSetings:
    class ElementNames:
        HEADER = 'Restrictions Settings'
        APP_LIST_MODE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/Applist/AppListMode'
        ENCRYPTED_BACKUPS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/forceEncryptedBackup'
        STORE_PASSWORD = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/forceITunesStorePasswordEntry'
        AD_TRACKING = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/forceLimitAdTracking'
        PROFANITY_FILTER = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/forceAssistantProfanityFilter'
        ALLOW_AIRDROP = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAirDrop'
        ALLOW_BOOKSTORE_EROTICA = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowBookstoreErotica'
        GAME_CENTER = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowGameCenter'
        ALLOW_BOOKSTORE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowBookstore'
        SHARED_STREAM = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowSharedStream'
        ACCOUNT_MODIFICATION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAccountModification'
        ADDING_GAME_CENTER = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAddingGameCenterFriends'
        AIRDROP_UNMANAGED = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/forceAirDropUnmanaged'
        DATA_MODIFICATION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAppCellularDataModification'
        APP_DOWNLOADS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAutomaticAppDownloads'
        DIAGNOSTIC_SUBMISSION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowDiagnosticSubmission'
        SYNC_ROAMING = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowGlobalBackgroundFetchWhenRoaming'
        PHOTO_LIBRARY = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowCloudPhotoLibrary'
        NAME_MODIFICATION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowDeviceNameModification'
        ALLOW_LOCK_SCREEN = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowPassbookWhileLocked'
        APP_TRUST = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowEnterpriseAppTrust'
        EXPLICIT_CONTENT = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowExplicitContent'
        FRIENDS_MODIFICATION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowFindMyFriendsModification'
        CLOUD_BACKUP = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowCloudBackup'
        CLOUD_DOCUMENT = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowCloudDocumentSync'
        CLOUD_KEYCHAIN = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowCloudKeychainSync'
        MESSAGE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowChat'
        APP_PURCHASES = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowInAppPurchases'
        APP_INSTALLATION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAppInstallation'
        ALLOW_TUNES = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowiTunes'
        KEYBOARD_SHORTCUTS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowKeyboardShortcuts'
        CONTROL_CENTER = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowLockScreenControlCenter'
        NOTIFICATION_VIEW = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowLockScreenNotificationsView'
        TODAY_VIEW = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowLockScreenTodayView'
        CONFIGURATION_FILE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowUIConfigurationProfileInstallation'
        MULTIPLAYER_GAMING = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowMultiplayerGaming'
        MANAGED_UNMANAGED = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowOpenFromManagedToUnmanaged'
        UNMANAGED_MANAGED = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowOpenFromUnmanagedToManaged'
        HOST_PAIRING = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowHostPairing'
        PASSCODE_MODIFICATION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowPasscodeModification'
        PHOTO_STREAM = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowPhotoStream'
        APP_REMOVAL = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAppRemoval'
        ALLOW_SAFARI = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowSafari'
        ALLOW_SCREEN_CAPTURE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowScreenShot'
        ALLOW_ASSISTANT = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAssistant'
        ASSISTANT_LOCKED = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAssistantWhileLocked'
        UNLOCK_DEVICE = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowFingerprintForUnlock'
        UI_APP = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowUIAppInstallation'
        TLS_PROMPT = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowUntrustedTLSPrompt'
        ALLOW_NEWS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowNews'
        USER_CONTENT = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowAssistantUserGeneratedContent'
        VOICE_DAILING = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowVoiceDialing'
        ALLOW_WALLPAPER = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowWallpaperModification'
        ALLOW_PAIRED = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/allowPairedWatch'
        RATINGS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/rating'
        ALLOW_AUTO_FILL = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/safariAllowAutoFill'
        FORCE_FRAUD_WARNING = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/safariForceFraudWarning'
        ENABLE_JAVA_SCRIPT = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/safariAllowJavaScript'
        BLOCK_POPUPS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/safariAllowPopups'
        BLOCK_COOKIES = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/safariAcceptCookies'
        RATING_REGION = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/ratingRegion'
        RATING_MOVIES = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/ratingMovies'
        RATING_TV_SHOWS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/ratingTVShows'
        RATING_APPS = '/Mobile/Software/Policies/Centrify/iOSSettings/Restrictions/ratingApps'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Restrictions Settings'
        APP_LIST_MODE = 'Application launch restrictions (Supervised only)'
        ENCRYPTED_BACKUPS = 'Force encrypted backups'
        STORE_PASSWORD = 'Force iTunes Store password'
        AD_TRACKING = 'Force limit Ad tracking'
        PROFANITY_FILTER = 'Force Siri Profanity Filter (Supervised Only)'
        ALLOW_AIRDROP = 'Permit access to AirDrop (Supervised Only)'
        ALLOW_BOOKSTORE_EROTICA = 'Permit access to erotic media of iBookstore'
        GAME_CENTER = 'Permit access to Game Center (Supervised Only)'
        ALLOW_BOOKSTORE = 'Permit access to iBookstore (Supervised Only)'
        SHARED_STREAM = 'Permit access to Shared Photo Stream'
        ACCOUNT_MODIFICATION = 'Permit account modification (Supervised Only)'
        ADDING_GAME_CENTER = 'Permit adding Game Center friends'
        AIRDROP_UNMANAGED = 'Permit AirDrop to be an unmanaged drop target'
        DATA_MODIFICATION = 'Permit app cellular data modification (Supervised Only)'
        APP_DOWNLOADS = 'Permit automatic application downloads (Supervised Only)'
        DIAGNOSTIC_SUBMISSION = 'Permit automatic diagnostic reports submission'
        SYNC_ROAMING = 'Permit automatic sync while roaming'
        PHOTO_LIBRARY = 'Permit cloud photo library use'
        NAME_MODIFICATION = 'Permit device name modification (Supervised Only)'
        ALLOW_LOCKS_SCREEN = 'Permit device to show Wallet notifications on lock screen'
        APP_TRUST = 'Permit enterprise application trusting'
        EXPLICIT_CONTENT = 'Permit explicit music & podcasts'
        FRIENDS_MODIFICATION = 'Permit Find My Friends settings modification (Supervised Only)'
        CLOUD_BACKUP = 'Permit iCloud backup'
        CLOUD_DOCUMENT = 'Permit iCloud document sync'
        CLOUD_KEYCHAIN = 'Permit iCloud keychain sync'
        MESSAGE = 'Permit iMessage (Supervised Only)'
        APP_PURCHASES = 'Permit in-app purchase'
        APP_INSTALLATION = 'Permit installing apps'
        ALLOW_TUNES = 'Permit iTunes Music Store use'
        KEYBOARD_SHORTCUTS = 'Permit keyboard shortcuts use (Supervised Only)'
        CONTROL_CENTER = 'Permit lock screen control center'
        NOTIFICATION_VIEW = 'Permit lock screen notification view'
        TODAY_VIEW = 'Permit lock screen today view'
        CONFIGURATION_FILE = 'Permit manual configuration file installation (Supervised Only)'
        MULTIPLAYER_GAMING = 'Permit multiplayer gaming (Supervised Only)'
        MANAGED_UNMANAGED = 'Permit opening managed app documents in unmanaged apps'
        UNMANAGED_MANAGED = 'Permit opening unmanaged app documents in managed apps'
        HOST_PAIRING = 'Permit pairing with non-Configurator hosts (Supervised Only)'
        PASSCODE_MODIFICATION = 'Permit passcode modification (Supervised Only)'
        PHOTO_STREAM = 'Permit Photo Stream'
        APP_REMOVAL = 'Permit removing apps (Supervised Only)'
        ALLOW_SAFARI = 'Permit Safari use'
        ALLOW_SCREEN_CAPTURE = 'Permit screen capture'
        ALLOW_ASSISTANT = 'Permit Siri use'
        ASSISTANT_LOCKED = 'Permit Siri use while device is locked'
        UNLOCK_DEVICE = 'Permit Touch ID to unlock device'
        UI_APP = 'Permit UI app installation (Supervised Only)'
        TLS_PROMPT = 'Permit untrusted TLS prompt'
        ALLOW_NEWS = 'Permit use of News application (Supervised Only)'
        USER_CONTENT = 'Permit user-generated content in Siri (Supervised Only)'
        VOICE_DAILING = 'Permit voice dialing while phone is locked'
        ALLOW_WALLPAPER = 'Permit wallpaper modification (Supervised Only)'
        ALLOW_PAIRED = 'Permit watch pairing (Supervised Only)'
        RATINGS = 'Ratings'
        ALLOW_AUTO_FILL = 'Permit auto-fill'
        FORCE_FRAUD_WARNING = 'Force fraud warning'
        ENABLE_JAVA_SCRIPT = 'Enable JavaScript'
        BLOCK_POPUPS = 'Block pop-ups'
        BLOCK_COOKIES = 'Block Cookies'
        RATING_REGION = 'Set ratings region'
        RATING_MOVIES = 'Movies'
        RATING_TV_SHOWS = 'TV shows'
        RATING_APPS = 'Apps'
        ADD = 'Add'


class SamgKNOXDeviceSettingsBluetoothSettings:
    class ElementNames:
        HEADER = 'Bluetooth Settings'
        BLUETOOTH_MODE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Bluetooth/DiscoverableState'
        LIMITED_MODE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Bluetooth/LimitedDiscoverableState'
        DATA_TRANSFER = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Bluetooth/AllowBluetoothDataTransfer'
        DESKTOP_CONNECTION = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Bluetooth/DesktopConnectivityState'
        OUTGOING_CALLS = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Bluetooth/AllowOutgoingCalls'
        PAIRING_STATE = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Bluetooth/PairingState'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Bluetooth Settings'
        BLUETOOTH_MODE = 'Enable Bluetooth discoverable mode'
        LIMITED_MODE = 'Enable limited discoverable mode'
        DATA_TRANSFER = 'Permit data transfer via Bluetooth'
        DESKTOP_CONNECTION = 'Permit desktop or laptop connection via Bluetooth'
        OUTGOING_CALLS = 'Permit outgoing calls via Bluetooth headset'
        PAIRING_STATE = 'Permit pairing with other Bluetooth devices'
        ADD = 'Add'


class OsxRestrictionsSettingsApplications:
    class ElementNames:
        HEADER = 'Applications'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Applications'
        ADD = 'Add'


class OsxRestrictionsSettingsMedia:
    class ElementNames:
        HEADER = 'Media'
        ALLOW_AIRDROP = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowAirDrop'
        ALLOW_CD = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowCD'
        ALLOW_DISK_IMAGE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowDiskImage'
        ALLOW_DVDRAM = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowDVDRAM'
        ALLOW_DVD = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowDVD'
        ALLOW_EXTERNAL_DISK = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowExternalDisk'
        ALLOW_INTERNAL_DISK = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowInternalDisk'
        ALLOW_RECORDABLE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaAllowRecordableCD'
        EJECT_MEDIA = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaEjectAtLogout'
        CD_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaCDReqAuth'
        DISK_IMAGE_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaDiskImageReqAuth'
        DISK_IMAGE_READONLY = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaDiskImageReadOnly'
        DVDRAM_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaDVDRAMReqAuth'
        DVDRAM_READONLY = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaDVDRAMReadOnly'
        DVD_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaDVDReqAuth'
        EXTERNAL_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaExternalDiskReqAuth'
        EXTERNAL_READONLY = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaExternalDiskReadOnly'
        INTERNAL_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaInternalDiskReqAuth'
        INTERNAL_READONLY = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaInternalDiskReadOnly'
        RECORDABLE_REQ_AUTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/mediaRecordableCDReqAuth'

    class TextConstants:
        HEADER = 'Media'
        ALLOW_AIRDROP = 'Allow access to AirDrop'
        ALLOW_CD = 'Allow access to CDs & CD-ROMs'
        ALLOW_DISK_IMAGE = 'Allow access to disk images'
        ALLOW_DVDRAM = 'Allow access to DVD-RAM'
        ALLOW_DVD = 'Allow access to DVDs'
        ALLOW_EXTERNAL_DISK = 'Allow access to external disks'
        ALLOW_INTERNAL_DISK = 'Allow access to internal disks'
        ALLOW_RECORDABLE = 'Allow access to Recordable Discs'
        EJECT_MEDIA = 'Eject all removable media at logout'
        CD_REQ_AUTH = 'Require Authentication'
        DISK_IMAGE_REQ_AUTH = 'Require Authentication'
        DISK_IMAGE_READONLY = 'Read-Only'
        DVDRAM_REQ_AUTH = 'Require Authentication'
        DVDRAM_READONLY = 'Read-Only'
        DVD_REQ_AUTH = 'Require Authentication'
        EXTERNAL_REQ_AUTH = 'Require Authentication'
        EXTERNAL_READONLY = 'Read-Only'
        INTERNAL_REQ_AUTH = 'Require Authentication'
        INTERNAL_READONLY = 'Read-Only'
        RECORDABLE_REQ_AUTH = 'Require Authentication'


class OsxRestrictionsSettingsPreferences:
    class ElementNames:
        HEADER = 'Preferences'
        ADD = 'Add'
        SYSTEM_PREFERENCES = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/EnabledSystemPreferencesWhiteList'
        ALLOW_APP_STORE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowAppStore'
        ALLOW_BLUETOOTH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowBluetooth'
        ALLOW_CD_DVD = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowCDsAndDVDs'
        ALLOW_DATE_TIME = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowDateAndTime'
        ALLOW_DESKTOP = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowDesktopAndScreenSaver'
        ALLOW_DISPLAYS = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowDisplays'
        ALLOW_DOCK = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowDock'
        ALLOW_ENERGY_SAVER = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowEnergySaver'
        ALLOW_EXTENSIONS = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowExtensions'
        ALLOW_FIBER_CHANNEL = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowFibreChannel'
        ALLOW_GENERAL = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowGeneral'
        ALLOW_iCLOUD = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowiCloud'
        ALLOW_INK = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowInk'
        ALLOW_INTERNET = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowMailContactsAndCalendars'
        ALLOW_KEYBOARD = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowKeyboard'
        ALLOW_LANGUAGE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowLanguageAndText'
        ALLOW_MISSION_CONTROL = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowMissionControl'
        ALLOW_MOBILE_ME = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowMobileMe'
        ALLOW_MOUSE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowMouse'
        ALLOW_NETWORK = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowNetwork'
        ALLOW_NOTIFICATIONS = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowNotifications'
        ALLOW_PARENTAL_CONTROLS = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowParentalControls'
        ALLOW_PRINT_SCAN = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowPrintAndScan'
        ALLOW_PROFILES = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowProfiles'
        ALLOW_SECURITY = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowSecurityAndPrivacy'
        ALLOW_SHARING = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowSharing'
        ALLOW_SOFTWARE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowSoftwareUpdate'
        ALLOW_SOUND = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowSound'
        ALLOW_SPEECH = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowSpeech'
        ALLOW_SPOTLIGHT = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowSpotlight'
        ALLOW_STARTUP_DISK = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowStartupDisk'
        ALLOW_TIME_MACHINE = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowTimeMachine'
        ALLOW_TRACKPAD = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowTrackpad'
        ALLOW_UNIVERSAL_ACCESS = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowUniversalAccess'
        ALLOW_USERS_GROUPS = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowUsersAndGroups'
        ALLOW_XSAN = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/systemPreferencesAllowXsan'

    class TextConstants:
        HEADER = 'Preferences'
        ADD = 'Add'
        SYSTEM_PREFERENCES = 'Allow built-in System Preferences'
        ALLOW_APP_STORE = 'App Store (10.9 or later)'
        ALLOW_BLUETOOTH = 'Bluetooth'
        ALLOW_CD_DVD = 'CDs & DVDs'
        ALLOW_DATE_TIME = 'Date & Time'
        ALLOW_DESKTOP = 'Desktop & Screen Saver'
        ALLOW_DISPLAYS = 'Displays'
        ALLOW_DOCK = 'Dock'
        ALLOW_ENERGY_SAVER = 'Energy Saver'
        ALLOW_EXTENSIONS = 'Extensions'
        ALLOW_FIBER_CHANNEL = 'FibreChannel'
        ALLOW_GENERAL = 'General'
        ALLOW_iCLOUD = 'iCloud'
        ALLOW_INK = 'Ink'
        ALLOW_INTERNET = 'Internet Accounts'
        ALLOW_KEYBOARD = 'Keyboard'
        ALLOW_LANGUAGE = 'Language & Text'
        ALLOW_MISSION_CONTROL = 'Mission Control'
        ALLOW_MOBILE_ME = 'Mobile Me'
        ALLOW_MOUSE = 'Mouse'
        ALLOW_NETWORK = 'Network'
        ALLOW_NOTIFICATIONS = 'Notifications'
        ALLOW_PARENTAL_CONTROLS = 'Parental Controls'
        ALLOW_PRINT_SCAN = 'Print & Scan'
        ALLOW_PROFILES = 'Profiles'
        ALLOW_SECURITY = 'Security & Privacy'
        ALLOW_SHARING = 'Sharing'
        ALLOW_SOFTWARE = 'Software Update'
        ALLOW_SOUND = 'Sound'
        ALLOW_SPEECH = 'Speech'
        ALLOW_SPOTLIGHT = 'Spotlight'
        ALLOW_STARTUP_DISK = 'Startup Disk'
        ALLOW_TIME_MACHINE = 'Time Machine'
        ALLOW_TRACKPAD = 'Trackpad'
        ALLOW_UNIVERSAL_ACCESS = 'Universal Access'
        ALLOW_USERS_GROUPS = 'Users & Groups'
        ALLOW_XSAN = 'Xsan'


class OsxRestrictionsSettingsRestrictPreferences:
    class ElementNames:
        HEADER = 'Restrict preferences'
        ENABLE_PREFERENCES = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/EnabledPreferencePanes'

    class TextConstants:
        HEADER = 'Restrict preferences'
        ENABLE_PREFERENCES = 'Restrict preferences'


class OsxRestrictionsSettingsRestrictApplications:
    class ElementNames:
        HEADER = 'Restrict applications'
        APP_RESTRICTION = '/Mobile/Software/Policies/Centrify/OSXSettings/Restrictions/appRestriction'

    class TextConstants:
        HEADER = 'Restrict applications'
        APP_RESTRICTION = 'Restrict applications'


class OsxSettingsOpenfiles:
    class ElementNames:
        HEADER = 'Open files, folders and items when user logs in'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Open files, folders and items when user logs in'
        ADD = 'Add'


class CommonButtons:
    class TextConstants:
        ADD = "Add"

    class ElementNames:
        ADD = "Add"


class AndroidManagementSettingsRestrictions:
    class TextConstants:
        HEADER = 'Restrictions'
        LIMIT_COPY_PASTE = 'Limit copy/paste to managed profile'
        PERMIT_DATA_SHARING = 'Permit data sharing from Work Profile'
        PERMIT_DEBUGGING = 'Permit debugging'
        PERMIT_INSTALLATION = 'Permit installation of apps from unknown sources'
        PERMIT_SCREEN_CAPTURE = 'Permit screen capture'

    class ElementNames:
        HEADER = 'Restrictions'
        LIMIT_COPY_PASTE = '/Mobile/Software/Policies/Centrify/AndroidForWork/Restrictions/LimitCrossProfileCopyPaste'
        PERMIT_DATA_SHARING = '/Mobile/Software/Policies/Centrify/AndroidForWork/Restrictions/PermitDataSharingFromWorkToPersonal'
        PERMIT_DEBUGGING = '/Mobile/Software/Policies/Centrify/AndroidForWork/Restrictions/PermitUSBDebugging'
        PERMIT_INSTALLATION = '/Mobile/Software/Policies/Centrify/AndroidForWork/Restrictions/PermitUnknownSources'
        PERMIT_SCREEN_CAPTURE = '/Mobile/Software/Policies/Centrify/AndroidForWork/Restrictions/PermitScreenCapture'


class AndroidManagementSettingsSystemApps:
    class TextConstants:
        HEADER = 'System Apps'
        ADD = 'Add'

    class ElementNames:
        HEADER = 'System Apps'
        ADD = 'Add'


class AndroidManagementSettingsVPNSettings:
    class TextConstants:
        HEADER = 'VPN Settings'
        ENABLE_ALWAYS = 'Enable Always-on VPN Settings'
        PACKAGE_NAME = 'Package Name *'
        LOCKDOWN_ENABLED = 'Lockdown enabled'

    class ElementNames:
        HEADER = 'VPN Settings'
        ENABLE_ALWAYS = '/Mobile/Software/Policies/Centrify/AndroidForWork/VPNSettings/AlwaysOnVPNSettings'
        PACKAGE_NAME = '/Mobile/Software/Policies/Centrify/AndroidForWork/VPNSettings/AlwaysOnVPNSettings/VPNClientPackage'
        LOCKDOWN_ENABLED = '/Mobile/Software/Policies/Centrify/AndroidForWork/VPNSettings/AlwaysOnVPNSettings/LockdownEnabled'


class AndroidManagementSettingsDeviceOwner:
    class TextConstants:
        HEADER = 'Device Owner'
        ALLOW_PROVISIONING = 'Allow Provisioning mode'

    class ElementNames:
        HEADER = 'Device Owner'
        ALLOW_PROVISIONING = '/Mobile/Software/Policies/Centrify/AndroidForWork/AllowProvisioningMode'


class UserSecurityPoliciesUserAccountSettings:
    class TextConstants:
        HEADER = 'User Account Settings'
        ENABLE_USERS_CHANGE_PWD = 'Enable users to change their passwords'
        REQ_USERS_SETUP_MOBILE = 'Prompt users to set up mobile number on login'
        ENABLE_USERS_ENROLL_FIDO = 'Enable users to enroll FIDO2 Authenticators'
        ENABLE_USERS_CONFIG_OATH = 'Enable users to configure an OATH OTP client (requires enabling OATH OTP policy)'
        ENABLE_USERS_REDIRECT_MFA = 'Enable users to redirect multi factor authentication to a different user account'
        ENABLE_USERS_CONFIG_SECURITY = 'Enable users to configure Security Questions'
        AUTH_PROFILE_MODIFY_PERSONAL = 'Authentication Profile required to modify Personal Profile'
        DEFAULT_LANGUAGE = 'Default Language'
        AUTH_PROFILE_CHANGE_PWD = 'Authentication Profile required to change password'
        REQ_USERS_SETUP_FIDO = 'Prompt users to setup FIDO2 Authenticator on login'
        FIDO_U2F_DISPLAY_NAME = 'FIDO2 Security Key Display Name *'
        AUTH_PROFILE_CONFIG_FIDO = 'Authentication Profile required to configure FIDO2 Authenticators'
        REQ_USERS_CONFIG_OATH = 'Prompt users to configure an OATH OTP client on login'
        OATH_OTP_DISPLAY_NAME = 'OATH OTP Display Name *'
        AUTH_PROFILE_CONFIG_OATH = 'Authentication Profile required to configure OATH OTP client'
        REQ_USERS_CONFIG_SECURITY = 'Prompt users to configure Security Questions on login'
        ALLOW_DUPLICATE_SECURITY = 'Allow duplicate security question answers'
        REQ_USER_DEFINED_QUESTIONS = 'Required number of user-defined questions *'
        REQ_ADMIN_DEFINED_QUESTIONS = 'Required number of admin-defined questions *'
        MIN_CHAR_REQ_ANSWERS = 'Minimum number of characters required in answers *'
        AUTH_PROFILE_SECURITY = 'Authentication Profile required to set Security Questions'
        NUMBER_AUTH_FACTORS_REQ = 'Number of authentication factors user is required to configure upon login.'

    class ElementNames:
        HEADER = 'User Account Settings'
        ENABLE_USERS_CHANGE_PWD = '/Core/PasswordChange/UserChangeAllow'
        REQ_USERS_SETUP_MOBILE = '/Core/Authentication/SmsMessagePromptInMfaSetupWizard'
        ENABLE_USERS_ENROLL_FIDO = '/Core/Security/CDS/ExternalMFA/ShowU2f'
        ENABLE_USERS_CONFIG_OATH = '/Core/Security/CDS/ExternalMFA/ShowQRCodeForSelfService'
        ENABLE_USERS_REDIRECT_MFA = '/Core/Security/CDS/AllowUserChangeMFARedirect'
        ENABLE_USERS_CONFIG_SECURITY = '/Core/Authentication/ConfigureSecurityQuestions'
        AUTH_PROFILE_MODIFY_PERSONAL = '/Core/Authentication/UserUpdateProfile/Profile'
        DEFAULT_LANGUAGE = '/Core/Policy/Culture'
        AUTH_PROFILE_CHANGE_PWD = '/Core/Authentication/UserUpdateProfile/Password'
        REQ_USERS_SETUP_FIDO = '/Core/Authentication/U2fPromptInMfaSetupWizard'
        FIDO_U2F_DISPLAY_NAME = '/Core/Security/CDS/ExternalMFA/U2fUiPrompt'
        AUTH_PROFILE_CONFIG_FIDO = '/Core/Authentication/UserUpdateProfile/U2F'
        REQ_USERS_CONFIG_OATH = '/Core/Authentication/OathPassCodePromptInMfaSetupWizard'
        OATH_OTP_DISPLAY_NAME = '/Core/Security/CDS/ExternalMFA/UiPrompt'
        AUTH_PROFILE_CONFIG_OATH = '/Core/Authentication/UserUpdateProfile/OathProfile'
        REQ_USERS_CONFIG_SECURITY = '/Core/Authentication/SecurityQuestionPromptInMfaSetupWizard'
        ALLOW_DUPLICATE_SECURITY = '/Core/Authentication/SecurityQuestionPreventDupAnswers'
        REQ_USER_DEFINED_QUESTIONS = '/Core/Authentication/UserSecurityQuestionsPerUser'
        REQ_ADMIN_DEFINED_QUESTIONS = '/Core/Authentication/AdminSecurityQuestionsPerUser'
        MIN_CHAR_REQ_ANSWERS = '/Core/Authentication/SecurityQuestionAnswerMinLength'
        AUTH_PROFILE_SECURITY = '/Core/Authentication/UserUpdateProfile/SecurityQuestion'
        NUMBER_AUTH_FACTORS_REQ = '/Core/Authentication/RequiredFactorSetupCount'


class UserSecurityPoliciesSelfService:
    class TextConstants:
        HEADER = 'Self Service'
        # PASSWORD RESET
        ENABLE_ACCOUNT_SELF_SERVICE = 'Enable account self service controls'
        ENABLE_PWD_RESET = 'Enable password reset'
        ALLOW_ACTIVE_DIRECTORY_USERS_PR = 'Allow for Active Directory users'
        ONLY_ALLOW_BROWSERS_PR = 'Only allow from browsers with identity cookie'
        USER_MUST_LOGIN = 'User must log in after successful password reset'
        PWD_RESET_AUTH_PROFILE = 'Password Reset Authentication Profile*'
        MAX_CONSEC_PWD_RESET_ATTEMPTS = 'Maximum consecutive password reset attempts per session'

        # ACCOUNT UNLOCK
        ENABLE_ACCOUNT_UNLOCK = 'Enable account unlock'
        ALLOW_ACTIVE_DIRECTORY_USERS_AU = 'Allow for Active Directory users'
        ONLY_ALLOW_BROWSERS_AU = 'Only allow from browsers with identity cookie'
        ACCOUNT_UNLOCK_AUTH_PROFILE = 'Account Unlock Authentication Profile*'

        # ACTIVE DIRECTORY SELF SERVICE SETTINGS
        USE_CONNECTOR_RUNNING = 'Use connector running on privileged account'
        USE_CREDENTIALS = 'Use these credentials'
        ADMIN_USERNAME = 'Admin User Name: *'
        ADMIN_PWD = 'Admin User Password: *'

        # ADDITIONAL POLICY PARAMETERS
        MAX_FORGOTTEN_PWD_RESETS = 'Maximum forgotten password resets allowed within window (default 10)'
        CAPTURE_WINDOW_FORGOTTEN_PWD_RESETS = 'Capture window for forgotten password resets (default 60 minutes)'

    class ElementNames:
        HEADER = 'Self Service'
        # PASSWORD RESET
        ENABLE_ACCOUNT_SELF_SERVICE = 'PasswordResetEnabled'
        ENABLE_PWD_RESET = '/Core/PasswordReset/PasswordResetEnabled'
        ALLOW_ACTIVE_DIRECTORY_USERS_PR = '/Core/PasswordReset/PasswordResetADEnabled'
        ONLY_ALLOW_BROWSERS_PR = '/Core/PasswordReset/PasswordResetIdentityCookieOnly'
        USER_MUST_LOGIN = '/Core/PasswordReset/PasswordResetRequiresMfaRestart'
        PWD_RESET_AUTH_PROFILE = '/Core/PasswordReset/PasswordResetAuthProfile'
        MAX_CONSEC_PWD_RESET_ATTEMPTS = '/Core/PasswordReset/PasswordResetMaxAttemptsPerSession'

        # ACCOUNT UNLOCK
        ENABLE_ACCOUNT_UNLOCK = '/Core/PasswordReset/AccountUnlockEnabled'
        ALLOW_ACTIVE_DIRECTORY_USERS_AU = '/Core/PasswordReset/AccountUnlockADEnabled'
        ONLY_ALLOW_BROWSERS_AU = '/Core/PasswordReset/AccountUnlockIdentityCookieOnly'
        ACCOUNT_UNLOCK_AUTH_PROFILE = '/Core/PasswordReset/AccountUnlockAuthProfile'

        # ACTIVE DIRECTORY SELF SERVICE SETTINGS
        USE_CONNECTOR_RUNNING = '/Core/PasswordReset/UseADAdmin'
        USE_CREDENTIALS = '/Core/PasswordReset/UseADAdmin'
        ADMIN_USERNAME = '/Core/PasswordReset/ADAdminUser'
        ADMIN_PWD = '/Core/PasswordReset/ADAdminPass'

        # ADDITIONAL POLICY PARAMETERS
        MAX_FORGOTTEN_PWD_RESETS = '/Core/PasswordReset/Max'
        CAPTURE_WINDOW_FORGOTTEN_PWD_RESETS = '/Core/PasswordReset/MaxTime'


class SamsungKNOXWorkspaceDeviceEnableCertificate:
    class ElementNames:
        HEADER = 'Enable certificate validation before installation'
        ENABLE_CERTIFICATE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Certificate/CertificateValidationBeforeInstall'

    class TextConstants:
        HEADER = 'Enable certificate validation before installation'
        ENABLE_CERTIFICATE = 'Enable certificate validation before installation'


class SamsungKNOXWorkspaceDeviceEnableRevocation:
    class ElementNames:
        HEADER = 'Enable revocation check for application SSL connections'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Enable revocation check for application SSL connections'
        ADD = 'Add'


class SamsungKNOXWorkspaceDeviceTrustedCer:
    class ElementNames:
        HEADER = 'Trusted certificate authorities'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Trusted certificate authorities'
        ADD = 'Add'


class SamsungKNOXWorkspaceDevicePerAppVpn:
    class ElementNames:
        HEADER = 'Per-App VPN settings'
        DEVICE_APP_VPN = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perDeviceAppVpn/perDeviceAppVpn'
        VPN_APP = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perDeviceAppVpn/AutoStartVPNSelection'
        VPN_MAPPING = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perDeviceAppVpn/AutoStartVPNSelection'
        VPN_CONNECTION = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perDeviceAppVpn/AllDeviceAppVpn'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Per-App VPN settings'
        DEVICE_APP_VPN = 'Per app VPN settings'
        VPN_APP = 'Connect via this VPN for all applications'
        VPN_MAPPING = 'Connect via VPN based on the following mapping'
        VPN_CONNECTION = 'VPN connection *'
        ADD = 'Add'


class SamsungKNOXWorkspaceDeviceEnableAuditLog:
    class ElementNames:
        HEADER = 'Enable Audit Log'
        ENABLE_AUDIT = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/AuditLogEnabled'

    class TextConstants:
        HEADER = 'Enable Audit Log'
        ENABLE_AUDIT = 'Enable Audit Log'


class SamsungKNOXWorkspaceDeviceRestrictionSettings:
    class ElementNames:
        HEADER = 'Restriction Settings'
        ALLOW_ADMIN_APP = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/DeviceSettings/RestrictionSettings/AllowOtherAdminAppInstallation'

    class TextConstants:
        HEADER = 'Restriction Settings'
        ALLOW_ADMIN_APP = 'Allow Other Admin App Installation'


class SamgKNOXDeviceSettingsEmailAccountSettings:
    class ElementNames:
        HEADER = 'Email Account Settings'
        ENABLE_EMAIL_ACCOUNT = 'emailImapPop'
        EMAIL_BASIC = 'Basic'
        EMAIL_GENERAL = 'General'

    class TextConstants:
        HEADER = 'Email Account Settings'
        ENABLE_EMAIL_ACCOUNT = 'Enable email account settings'
        EMAIL_BASIC = 'Basic'
        EMAIL_GENERAL = 'General'


class SamsungKNOXDeviceSettingsVPNSettings:
    class TextConstants:
        HEADER = 'VPN Settings'
        ADD = 'Add'

    class ElementNames:
        HEADER = 'VPN Settings'
        ADD = 'Add'


class SamsungKNOXDeviceSettingsAPNSettings:
    class TextConstants:
        HEADER = 'APN Settings'
        ADD = 'Add'

    class ElementNames:
        HEADER = 'APN Settings'
        ADD = 'Add'


class SamsungKNOXDeviceSettingsWifiSettings:
    class TextConstants:
        HEADER = 'Wi-Fi Settings'
        ADD = 'Add'

    class ElementNames:
        HEADER = 'Wi-Fi Settings'
        ADD = 'Add'


class SamsungKNOXDeviceSettingsFirewallLegacy:
    class TextConstants:
        HEADER = 'Legacy'
        ADD = 'Add'
        PROXY_RULES = 'Proxy rules'
        IP_ADDRESS = 'IP Address *'
        PORT = 'Port *'
        TYPE_OF_NETWORK = 'Type of network for accessing Google Play'

    class ElementNames:
        HEADER = 'Legacy'
        ADD = 'Add'
        PROXY_RULES = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Firewall/IptablesProxyRules'
        IP_ADDRESS = 'IpAddress'
        PORT = 'Port'
        TYPE_OF_NETWORK = '/Mobile/Software/Policies/Centrify/SamsungSafeSettings/Firewall/NetworkForMarket'


class SamsungKNOXDeviceSettingsFirewallKnox:
    class TextConstants:
        HEADER = 'Knox 2.6+'
        ADD = 'Add'

    class ElementNames:
        HEADER = 'Knox 2.6+'
        ADD = 'Add'


class SamsungKNOXWorkspaceContainerBrowserSettings:
    class TextConstants:
        HEADER = 'Browser Settings'
        ENABLE_AUTOFILL = 'Enable auto fill setting'
        ENABLE_COOKIES = 'Enable cookies setting'
        ENABLE_FORCE_FRAUD = 'Enable force fraud warning setting'
        ENABLE_JAVASCRIPT = 'Enable JavaScript setting'
        ENABLE_POPUPS = 'Enable popups setting'
        ENABLE_SMARTCARD = 'Enable smart card authentication'

    class ElementNames:
        HEADER = 'Browser Settings'
        ENABLE_AUTOFILL = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Browser/SetAutoFillSetting'
        ENABLE_COOKIES = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Browser/SetCookiesSetting'
        ENABLE_FORCE_FRAUD = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Browser/SetForceFraudWarningSetting'
        ENABLE_JAVASCRIPT = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Browser/SetJavaScriptSetting'
        ENABLE_POPUPS = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Browser/SetPopupsSetting'
        ENABLE_SMARTCARD = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Browser/SmartCardAuth'


class SamsungKNOXWorkspaceContainerFirewallSettings:
    class TextConstants:
        HEADER = 'Firewall Settings'
        ADD = 'Add'

    class ElementNames:
        HEADER = 'Firewall Settings'
        ADD = 'Add'


class SamsungKNOXWorkspaceContainerEnableGoogleApps:
    class TextConstants:
        HEADER = 'Enable Google Apps'
        ALLOW_GOOGLE = 'Allow Google apps in the container'

    class ElementNames:
        HEADER = 'Enable Google Apps'
        ALLOW_GOOGLE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/AllowPlayStore'


class SamsungKNOXWorkspaceContainerRestrictionSettings:
    class TextConstants:
        HEADER = 'Restriction Settings'
        ALLOW_OTHER = 'Allow Other Admin App Installation'
        ADD = 'Add'
        FORCE_SECURE = 'Force secure keypad'
        PERMIT_BLUETOOTH = 'Permit Bluetooth'
        PERMIT_BLUETOOTH_DEVICE_ACCESS = 'Permit Bluetooth devices access to contacts via PBAP'
        PERMIT_CAMERA_USE = 'Permit camera use'
        PERMIT_DISPLAY = 'Permit display of share via list'
        PERMIT_MOVING_FILES_INTO_CONTAINER = 'Permit moving files into the container'
        PERMIT_MOVING_FILES_OUT_OF_CONTAINER = 'Permit moving files out of the container'
        PERMIT_NFC = 'Permit NFC'
        PERMIT_SCREEN_CAPTURE = 'Permit screen capture'
        PERMIT_USB_ACCESS = 'Permit USB access'
        PERMIT_USER_FROM_CHANGING_APPDATA = 'Permit user from changing app data sync setting'
        PERMIT_USER_DELETE_KNOX = 'Permit user to delete the KNOX container'
        PREVIEW_KNOX = 'Preview KNOX notifications'
        CONTACTS_EXPORT = 'Contacts'
        SPLANNER_EXPORT = 'S Planner (Calendar)'
        CONTACTS_IMPORT = 'Contacts'
        SPLANNER_IMPORT = 'S Planner (Calendar)'

    class ElementNames:
        HEADER = 'Restriction Settings'
        ALLOW_OTHER = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowOtherAdminAppInstallation'
        ADD = 'Add'
        FORCE_SECURE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/UseSecureKeypad'
        PERMIT_BLUETOOTH = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/EnableBluetooth'
        PERMIT_BLUETOOTH_DEVICE_ACCESS = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowContactsSharing'
        PERMIT_CAMERA_USE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowCamera'
        PERMIT_DISPLAY = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowShareList'
        PERMIT_MOVING_FILES_INTO_CONTAINER = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowMoveFilesToContainer'
        PERMIT_MOVING_FILES_OUT_OF_CONTAINER = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowMoveFilesToOwner'
        PERMIT_NFC = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/EnableNFC'
        PERMIT_SCREEN_CAPTURE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/SetScreenCapture'
        PERMIT_USB_ACCESS = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/EnableUSBAccess'
        PERMIT_USER_FROM_CHANGING_APPDATA = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowChangeDataSync'
        PERMIT_USER_DELETE_KNOX = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Restrictions/AllowKnoxContainerDeleteByUser'
        PREVIEW_KNOX = 'preview_notifications_allow'
        CONTACTS_EXPORT = 'export_contacts_allow'
        SPLANNER_EXPORT = 'export_splanner_allow'
        CONTACTS_IMPORT = 'import_contacts_allow'
        SPLANNER_IMPORT = 'import_splanner_allow'


class SamsungKNOXWorkspaceContainerPerAppVpn:
    class ElementNames:
        HEADER = 'Per-App VPN settings'
        CONTAINER_APP_VPN = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perAppVpn/perAppVpn'
        VPN_APP = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perAppVpn/AutoStartVPNSelection'
        VPN_MAPPING = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perAppVpn/AutoStartVPNSelection'
        VPN_CONNECTION = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/perAppVpn/AllAppVpn'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Per-App VPN settings'
        CONTAINER_APP_VPN = 'Per app VPN settings'
        VPN_APP = 'Connect via this VPN for all applications'
        VPN_MAPPING = 'Connect via VPN based on the following mapping'
        VPN_CONNECTION = 'VPN connection *'
        ADD = 'Add'


class SamsungKNOXWorkspaceContainerPasscodeSettings:
    class ElementNames:
        HEADER = 'Passcode Settings'
        PASSWORD_VISIBLE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/visible'
        MAX_FAILED_ATTEMPTS = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/maxFailedAttempts'
        PASSCODE_AGE = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/maxPINAgeInDays'
        CHANGE_LENGTH = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/minChangeLength'
        PASSCODE_HISTORY = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/pinHistory'
        PASSWORD_LOCK = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/maxInactivity'
        COMPLEX_CHAR = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/minComplexChars'
        FINGERPRINT_AUTHENTICATION = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/FingerprintAuthEnabled'
        PASSCODE_QUALITY = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/pinQuality'
        MIN_PASS_LENGTH = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/minPasswordLength'
        MAX_CHAR_SEQ = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/maxCharSeq'
        MAX_NUM_SEQ = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/maxNumSeq'
        MAX_CHAR_OCCUR = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Passcode/maxCharOccur'
        FACTOR_AUTHENTICATION = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/EnforceMultifactorAuthentication'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Passcode Settings'
        PASSWORD_VISIBLE = 'Enable password visibility'
        MAX_FAILED_ATTEMPTS = 'Maximum number of failed attempts'
        PASSCODE_AGE = 'Maximum passcode age (days)'
        CHANGE_LENGTH = 'Minimum password change length'
        PASSCODE_HISTORY = 'Passcode history'
        PASSWORD_LOCK = 'Maximum password lock delay (seconds)'
        COMPLEX_CHAR = 'Minimum number of complex characters'
        FINGERPRINT_AUTHENTICATION = 'Enable fingerprint authentication'
        PASSCODE_QUALITY = 'Minimum passcode quality'
        MIN_PASS_LENGTH = 'Minimum password length'
        MAX_CHAR_SEQ = 'Maximum character sequence length'
        MAX_NUM_SEQ = 'Maximum numerical sequence length'
        MAX_CHAR_OCCUR = 'Maximum character occurrence'
        FACTOR_AUTHENTICATION = 'Require two factor authentication'
        ADD = 'Add'


class AuthenticationPoliciesIdaptiveServices:
    class ElementNames:
        HEADER = 'Authentication Policy for CyberArk Identity'
        ENABLE_AUTH = 'AuthenticationEnabled'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = '/Core/Authentication/AuthenticationRulesDefaultProfileId'
        SESSION_HOURS = '/Core/Authentication/CookieSessionLifespanHours'
        KEEP_ME_SIGNED = '/Core/Authentication/CookieAllowPersist'
        DEFAULT = '/Core/Authentication/CookiePersistDefault'
        SESSION_EXPIRES = '/Core/Authentication/CookiePersistLifespanHours'
        ALLOW_IWA = '/Core/Authentication/AllowIwa'
        SET_IWA = '/Core/Authentication/IwaSetKnownEndpoint'
        IWA_MECHS = '/Core/Authentication/IwaSatisfiesAllMechs'
        USE_CERTIFICATES = '/Core/Authentication/AllowZso'
        SET_USE = '/Core/Authentication/ZsoSetKnownEndpoint'
        USE_MECHS = '/Core/Authentication/ZsoSatisfiesAllMechs'
        NO_MFA = '/Core/Authentication/NoMfaMechLogin'
        FEDERATED_USERS = '/Core/Authentication/FederatedLoginAllowsMfa'
        FEDERATED_MECHS = '/Core/Authentication/FederatedLoginSatisfiesAllMechs'
        SAME_DEVICE = '/Core/MfaRestrictions/BlockMobileMechsOnMobileLogin'
        FAILED_CHALLENGE = '/Core/Authentication/ContinueFailedSessions'
        PREVIOUS_CHALLENGE = '/Core/Authentication/SkipMechsInFalseAdvance'

    class TextConstants:
        HEADER = 'Authentication Policy for CyberArk Identity'
        ENABLE_AUTH = 'Enable authentication policy controls'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = 'Default Profile (used if no conditions matched)*'
        SESSION_HOURS = 'Hours until session expires (default 12)'
        KEEP_ME_SIGNED = "Allow 'Keep me signed in' checkbox option at login (session spans browser sessions)"
        DEFAULT = "Default 'Keep me signed in' checkbox option to enabled"
        SESSION_EXPIRES = "Hours until session expires when 'Keep me signed in' option enabled (default 2 weeks)"
        ALLOW_IWA = 'Allow IWA connections (bypasses authentication rules and default profile)'
        SET_IWA = 'Set identity cookie for IWA connections'
        IWA_MECHS = 'IWA connections satisfy all MFA mechanisms'
        USE_CERTIFICATES = 'Use certificates for authentication'
        SET_USE = 'Set identity cookie for connections using certificate authentication'
        USE_MECHS = 'Connections using certificate authentication satisfy all MFA mechanisms'
        NO_MFA = 'Allow users without a valid authentication factor to log in'
        FEDERATED_USERS = 'Apply additional authentication rules to federated users'
        FEDERATED_MECHS = 'Connections via Federation satisfy all MFA mechanisms'
        SAME_DEVICE = 'Allow additional authentication from same device'
        FAILED_CHALLENGE = 'Continue with additional challenges after failed challenge'
        PREVIOUS_CHALLENGE = 'Do not send challenge request when previous challenge response failed'


class AuthenticationPoliciesIdaptiveAdminPortal:
    class ElementNames:
        ENABLE_AUTH = '/Core/Authentication/AdminService/Portal/Strong/Authentication/Enabled'
        DEFAULT_PROFILE = '/Core/Authentication/AdminService/Portal/Strong/Authentication/DefaultProfileId'
        IWA_MECHS = '/Core/Authentication/AdminService/Portal/Strong/Authentication/DefaultProfileId'

    class TextConstants:
        HEADER = 'Authentication Policy for CyberArk Identity Admin Portal'
        ENABLE_AUTH = 'Enable authentication policy controls'
        DISCLAIMER_TEXT = 'Important: These policies only apply to the Admin Portal web interface, and do not restrict access to the underlying data or APIs.'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = 'Default Profile (used if no conditions matched)*'


class AuthenticationPoliciesWindowsWorkstations:
    class ElementNames:
        HEADER = 'Authentication Policy for Windows Workstations'
        ENABLE_AUTH_POLICY = '/Core/Css/WindowsEndpointAuthenticationEnabled'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = '/Core/Css/WinClient/AuthenticationRulesDefaultProfileId'

    class TextConstants:
        HEADER = 'Authentication Policy for Windows Workstations'
        ENABLE_AUTH_POLICY = 'Enable authentication policy controls'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = 'Default Profile (used if no conditions matched)*'


class AuthenticationPoliciesEndpointAuthentication:
    class ElementNames:
        HEADER = 'Endpoint Authentication'
        ENABLE_AUTH = '/Core/__centrify_cagent/AuthenticationEnabled'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = '/Core/__centrify_cagent/Authentication/AuthenticationRulesDefaultProfileId'
        NO_MFA = '/Core/__centrify_cagent/Authentication/NoMfaMechLogin'

    class TextConstants:
        HEADER = 'Endpoint Authentication'
        ENABLE_AUTH = 'Enable authentication policy controls'
        ADD_RULE = 'Add Rule'
        DEFAULT_PROFILE = 'Default Profile (used if no conditions matched)*'
        NO_MFA = 'Allow users without a valid authentication factor to log in'


class SamsungKnoxWorkspaceContainerAppSettings:
    class ElementNames:
        HEADER = 'Application Settings'
        ALLOW_APP_MOVE_CONTAINER = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Application/AllowMoveAppToContainer'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Application Settings'
        ALLOW_APP_MOVE_CONTAINER = 'Allow applications to be moved into container'
        ADD = 'Add'


class SamsungKnoxWorkspaceContainerCertSettings:
    class ElementNames:
        HEADER = 'Certificate Settings'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Certificate Settings'
        ADD = 'Add'


class SamsungKnoxWorkspaceContainerAccSettings:
    class ElementNames:
        HEADER = 'Container Account Settings'
        ADD = 'Add'

    class TextConstants:
        HEADER = 'Container Account Settings'
        ADD = 'Add'


class SamsungKnoxWorkspaceContainerEmailSettings:
    class ElementNames:
        HEADER = 'Email Settings'
        ADD = 'Add'
        PERMIT_ACC_ADD = '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/Email/AccountAddition'

    class TextConstants:
        HEADER = 'Email Settings'
        ADD = 'Add'
        PERMIT_ACC_ADD = 'Permit account addition'


class SamsungKnoxWorkspaceContainerEmailAccSettings:
    class ElementNames:
        HEADER = 'Email Account Settings'
        ENABLE_EMAIL_ACCOUNT = 'emailImapPop'
        EMAIL_BASIC = 'Basic'
        EMAIL_GENERAL = 'General'
        INCOMING_SERVER = 'Incoming Server'
        OUTGOING_SERVER = 'Outgoing Server'

    class TextConstants:
        HEADER = 'Email Account Settings'
        ENABLE_EMAIL_ACCOUNT = 'Enable email account settings'
        EMAIL_BASIC = 'Basic'
        EMAIL_GENERAL = 'General'
        INCOMING_SERVER = 'Incoming Server'
        OUTGOING_SERVER = 'Outgoing Server'


class SamsungKnoxWorkspaceContainerExchangeSettings:
    class ElementNames:
        HEADER = 'Exchange Settings'
        ENABLE_EXCHANGE_ACTSYNC = 'ExchangeActiveSync'
        EXCH_BASIC = 'Basic'
        EXCH_GENERAL = 'General'
        SYNC_OPTIONS = 'Sync Options'
        SYNC_SCHEDULE = 'Sync Schedule'

    class TextConstants:
        HEADER = 'Exchange Settings'
        ENABLE_EXCHANGE_ACTSYNC = 'Enable Exchange ActiveSync settings'
        EMAIL_BASIC = 'Basic'
        EMAIL_GENERAL = 'General'
        SYNC_OPTIONS = 'Sync Options'
        SYNC_SCHEDULE = 'Sync Schedule'


class OSXSettingsOpenNetworkMounts:
    class TextConstants:
        HEADER = "Open network mounts when user logs in"

    class ElementNames:
        HEADER = "Open network mounts when user logs in"


class SamsungKNOXDeviceSettingsBookmarkSettings:
    class TextConstants:
        HEADER = "Bookmark Settings"

    class ElementNames:
        HEADER = "Bookmark Settings"


class CommonAgentLockScreen:
    class ElementNames:
        HEADER = 'Lock Screen'
        DISABLE_MFA = '/Mobile/EndpointAgent/disableMfaLockScreen'

    class TextConstants:
        HEADER = 'Lock Screen'
        DISABLE_MFA = 'Disable MFA for OS X lock screen'


class LocalAccountLinkingPage:
    class ElementNames:
        HEADER = 'Local Account Linking'
        MAP_LOCAL_DIRECTORY_SERVICES = '/Core/Authentication/LocalAccountLinking/MapLocalAccounts'
        SOURCE_DIRECTORY_SERVICE = '/Core/Authentication/LocalAccountLinking/SourceDirectoryService'
        TARGET_DIRECTORY_SERVICE = '/Core/Authentication/LocalAccountLinking/TargetDirectoryService'
        DIRECTORY_USER_MAPPING_ATTRIBUTE = '/Core/Authentication/LocalAccountLinking/MapUserBy'


    class TextConstants:
        HEADER = 'Local Account Linking'
        MAP_LOCAL_DIRECTORY_SERVICES = 'Map local directory services'
        SOURCE_DIRECTORY_SERVICE = 'Source directory service'
        TARGET_DIRECTORY_SERVICE = 'Target directory service'
        DIRECTORY_USER_MAPPING_ATTRIBUTE = 'Directory user mapping attribute'
