from idaptive_automation.ui_automation.pages.ui_page import UIPage


class IBEHelpPage(UIPage):
    def __init__(self, driver):
        self.elements = {}
        super().__init__(driver, self.elements)

    def validate_all_elements(self):
        raise NotImplementedError
