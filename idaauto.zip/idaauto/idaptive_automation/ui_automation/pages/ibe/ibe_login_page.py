from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class IBELoginPage(UIPage):
    logo = {'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//*[@id="popoverApp"]/div[1]/div[1]/div/div[2]/img'))
            }

    sign_in = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, f'//button[.="Sign In"]'))
               }

    version = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@class,"versionSpan")]'))
       }

    help = {'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@title="Help"]'))
            }

    settings = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//div[@title="Settings"]'))
                }

    update_avail = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Update Available"]')),
                    'supports_validation': False
                    }

    def __init__(self, driver, version):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.sign_in),
            'logo': ElementFactory(driver).define_ui_image(self.logo),
            'sign_in': ElementFactory(driver).define_element(self.sign_in),
            'version': ElementFactory(driver).define_displayed_text(version, {
                    'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(., "Ver: ")]'))
                }
            ),
            'help': ElementFactory(driver).define_element(self.help),
            'settings': ElementFactory(driver).define_element(self.settings),
            'update_avail': ElementFactory(driver).define_element(self.update_avail),
        }
        super().__init__(driver, self.elements)

    def open_settings(self):
        self.elements['settings'].click()
        return self

    def open_help(self):
        self.elements['help'].click()
        return self

    def click_signin(self):
        self.elements['sign_in'].click()
