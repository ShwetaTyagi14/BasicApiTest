from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class IBESettingsPage(UIPage):
    advanced = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Advanced"]')),
                'inner_text': 'Advanced'
                }

    host_name = {
        'locator':
        ElementSetLocator(element_locator=(By.ID, 'setting_portalHostname'),
                          label_text_locator=(By.XPATH, '//*[@id="setting_portalHostname"]/parent::*/preceding-sibling::p')),
     }

    export_log = {'locator':
                  ElementSetLocator(element_locator=(By.ID, 'menuDiagLog'),
                                    label_text_locator=(By.XPATH, '//*[@id="setting_portalHostname"]/parent::*/preceding-sibling::p')),
                  'inner_text': 'Export Diagnostics Log'
                  }

    open_apps_in_tab_chk = {'locator':
                            ElementSetLocator(element_locator=(By.XPATH, '//*[@title="Opens the app in current active tab or new tab"]'))
                            }

    def __init__(self, driver):

        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.advanced),
            'advanced': ElementFactory(driver).define_expandable_element(self.advanced),
            'host': ElementFactory(driver).define_text_input(self.host_name),
            'export_log': ElementFactory(driver).define_element(self.export_log),
            'open_apps_in_tab_check': ElementFactory(driver).define_element(self.open_apps_in_tab_chk),
            }
        super().__init__(driver, self.elements)

    def click_advanced(self):
        self.elements['advanced'].click()
        return self

    def clear_hostname(self,):
        self.elements['host'].clear()

    def set_hostname(self, host):
        self.elements['host'].clear().type(host)
        self.elements['advanced'].click()

    def toggle_apps_in_tabs(self):
        self.elements['open_apps_in_tab_check'].click()

    def get_export_diagnostics_displayed(self):
        return self.elements['export_log'].is_displayed()

    def get_hostname_input_displayed(self):
        return self.elements['host'].is_displayed()

    def validate_all_elements(self):
        self.elements['advanced'].click()

        return super().validate_all_elements()
