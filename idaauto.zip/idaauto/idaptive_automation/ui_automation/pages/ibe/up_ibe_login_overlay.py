from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UPIBELoginOverlayPage(UIPage):
    loaded = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//div[starts-with(.,"Would you like to sign in the CyberArk Browser Extension for: ")]'))
    }

    sign_in = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//button[.="Sign In"]'))
    }

    cancel = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//button[.="Cancel"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded),
            'sign_in': ElementFactory(driver).define_element(self.sign_in),
            'cancel': ElementFactory(driver).define_element(self.cancel)
        }
        super().__init__(driver, self.elements)

    def get_displayed_text(self):
        return self.elements[self.LOADED_ELEMENT].get_text()

    def click_cancel(self):
        self.wait_for_page_to_load()
        self.elements['cancel'].click()
        return self

    def click_signin(self):
        self.wait_for_page_to_load()
        self.elements['sign_in'].click()
