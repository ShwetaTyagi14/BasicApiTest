from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from time import sleep


class IBEMainPage(UIPage):
    refresh_apps_elem = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//div[@class="appsPanelHead"]/button[@title="Refresh all apps"]'))
    }
    select_apps_filter = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//div[@class="appsPanelHead"]//select[@class="appsFilterSelect"]'))
    }
    apps_filter_options = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//div[@class="appsPanelHead"]//select[@class="appsFilterSelect"]//option'))
    }
    search_apps_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//div[@class="appsPanelHead"]//input[@id="AppSearchBar"]'))
    }
    search_apps_btn = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//div[@class="appsPanelHead"]//button[@type="submit" and @class="appSearchBarBtn"]'))
    }
    sign_out = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,
                                           f'//button[.="Sign Out"]'))
    }
    apps = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//div[@title="Apps"]'))
    }
    user_portal = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//div[@title="User Portal"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_ui_image(self.sign_out),
            'refresh_apps': ElementFactory(driver).define_element(self.refresh_apps_elem),
            'select_apps_filter': ElementFactory(driver).define_element(self.select_apps_filter),
            'apps_filter_options': ElementFactory(driver).define_element(self.apps_filter_options),
            'search_apps_input': ElementFactory(driver).define_element(self.search_apps_input),
            'search_apps_btn': ElementFactory(driver).define_element(self.search_apps_btn),
            'apps': ElementFactory(driver).define_element(self.apps),
            'user_portal': ElementFactory(driver).define_element(self.user_portal),
            'sign_out': ElementFactory(driver).define_element(self.sign_out),
        }
        super().__init__(driver, self.elements)

    def open_apps(self):
        self.elements['apps'].click()
        return self

    def open_user_portal(self):
        self.elements['user_portal'].click()

    def click_sign_out(self):
        self.elements['sign_out'].click()

    def open_ibe_main_page(self, wait_time=UIPage.SHORT_DELAY):
        self.driver.navigate_to(self.driver.ibe_url)
        self.wait_for_page_to_load(wait_time)
        return self

    def refresh_apps(self, wait_time=UIPage.SHORT_DELAY):
        self.elements['refresh_apps'].click()
        sleep(wait_time)
        return self

    def select_app(self, app_name):
        app = {
                'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@title,"{app_name}")]'))
              }
        app_element = ElementFactory(self.driver).define_element(app)
        app_element.click()
