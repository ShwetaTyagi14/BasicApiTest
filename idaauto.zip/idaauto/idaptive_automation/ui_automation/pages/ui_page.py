from selenium.common.exceptions import ElementNotInteractableException
from time import sleep
import json
import os


class UIPage:
    SHORT_DELAY = os.environ.get('AUTOMATION_SHORT_DELAY')
    if SHORT_DELAY is None:
        SHORT_DELAY = 5
    else:
        SHORT_DELAY = int(SHORT_DELAY)
    MEDIUM_DELAY = os.environ.get('AUTOMATION_MEDIUM_DELAY')
    if MEDIUM_DELAY is None:
        MEDIUM_DELAY = 12
    else:
        MEDIUM_DELAY = int(MEDIUM_DELAY)
    LONG_DELAY = os.environ.get('AUTOMATION_LONG_DELAY')
    if LONG_DELAY is None:
        LONG_DELAY = 45
    else:
        LONG_DELAY = int(LONG_DELAY)

    LOADED_ELEMENT = 'loaded'

    def __init__(self, driver, elements):
        self.driver = driver
        self.elements = elements

    @staticmethod
    def __persistent_click_element__(element):
        try:
            element.click()
        except ElementNotInteractableException:
            sleep(2)
            element.click()

    def is_loaded(self):
        return self.wait_for_page_to_load(1, required=False, wait_for_ready=False)

    def wait_for_page_to_load(self, wait_time=SHORT_DELAY, required=True, wait_for_ready=True):
        if wait_for_ready is True:
            self.driver.wait_for_page_ready_state(self.LONG_DELAY)
        elem = None
        if self.LOADED_ELEMENT in self.elements.keys():
            elem = self.elements[self.LOADED_ELEMENT].wait_for_visible(wait_time)

        if required:
            if elem is None:
                query = self.driver.get_screenshot_as_png()
            assert elem is not None, 'Page failed to load' if not isinstance(query, str) else f'Page failed to load. Query: {query}'
            return self

        return elem is not None

    def refresh_page(self):
        self.driver.refresh()
        return self

    def get_window_handles(self):
        return self.driver.window_handles

    def validate_all_elements(self):
        for k, v in self.elements.items():
            try:
                self.elements[k].validate()
            except Exception as e:
                assert False, \
                    f'Validation failed for {json.dumps(self.elements[k].definition.locator.element_locator)}'
        return self

    def validate_all_child_elements(self):
        for k, v in self.elements.items():
            if self.elements[k].definition.children is not None:
                try:
                    self.elements[k].validate_all_children()
                except Exception as e:
                    assert False, \
                        f'Validation of child elements failed for {json.dumps(self.elements[k].definition.locator.element_locator)}'

    def get_clipboard_contents(self):
        return self.driver.get_clipboard_contents().columns[0]

    def switch_to_new_tab(self, handles, wait_time=LONG_DELAY):
        self.driver.switch_to_new_tab(handles)

    def open_new_tab(self):
        return self.driver.execute_script("window.open('');")

    def get_page_source(self):
        return self.driver.page_source

    def switch_to_tab(self, handle):
        self.driver.switch_to_window(handle)

    def driver_get(self, url):
        self.driver.get(url)
