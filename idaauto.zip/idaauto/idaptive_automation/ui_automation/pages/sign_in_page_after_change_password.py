from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class SignInWithNewPassword(UIPage):

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[@id="usernameForm"]//div[text()="Sign In"]')),
              'inner_text': 'Sign In'}

    username = {'locator':
                ElementSetLocator(element_locator=(By.NAME, 'username'),
                                  label_text_locator=(By.XPATH, '//input[@name="username"]/preceding-sibling::label'))}

    password = {'locator':
                ElementSetLocator(element_locator=(By.CSS_SELECTOR, '#passwordForm>div.form-field-container>div>input[type="password"]'),
                                  label_text_locator=(By.XPATH, '//input[@name="username"]/preceding-sibling::label'))}
    user_next_button = {'locator':
                        ElementSetLocator(element_locator=(By.CSS_SELECTOR, '#usernameForm>div.button-wrapper>button'))}

    password_next_button = {'locator':
                            ElementSetLocator(element_locator=(By.CSS_SELECTOR, '#passwordForm > div.button-wrapper > button'))}

    def __init__(self, driver):

        self.elements = {
             self.LOADED_ELEMENT: factory(driver).define_element(self.username),
             'username': factory(driver).define_text_input(self.username),
             'user_next_button': factory(driver).define_element(self.user_next_button),
             'password': factory(driver).define_text_input(self.password),
             'password_next_button': factory(driver).define_element(self.password_next_button)
         }

        super().__init__(driver, self.elements)

    def wait_for_page_to_load(self, wait_time=UIPage.SHORT_DELAY, required=True, wait_for_ready=False):
        super().wait_for_page_to_load(wait_time=wait_time, required=required, wait_for_ready=wait_for_ready)

    def get_username_text(self):
        return self.elements['username'].get_text()

    def set_password(self, reset_password):
        self.elements['password'].clear()
        self.elements['password'].type(reset_password)

    def click_user_next_button(self):
        self.elements['user_next_button'].wait_for_visible()
        self.elements['user_next_button'].click()

    def click_password_next_button(self):
        self.elements['password_next_button'].wait_for_visible()
        self.elements['password_next_button'].click()
