import time

from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.pages.jobhistory.job_history_page import JobHistoryPage
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class OutboundProvisioningPage(UIPage):
    source_xpath = f'//input[@testname="DailySyncHour"]'
    toggle_xpath = Xpaths.SELECT_TOGGLE

    view_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Outbound Provisioning"]'))}
    save_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))}
    enable_daily_sync_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="DailySync"]'),
                                                               label_text_locator=(By.XPATH, '//input[@testname="DailySync"]/following-sibling::label'),
                                                               parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="DailySync"]]'))}
    sync_info_icon = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="I"]'))}
    sync_info_tooltip = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="//div[text()="Synchronization starts within the time range specified"]'))}
    daily_sync_start_time_dropdown = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="DailySyncHour"]'))}
    modal = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'modal-window'))}
    job_history_link = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[text()="View Synchronization Job Status and Reports"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.view_title),
            'view_title': ElementFactory(driver).define_element(self.view_title),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'enable_daily_sync_checkbox': ElementFactory(driver).define_checkbox(self.enable_daily_sync_checkbox),
            'sync_info_icon': ElementFactory(driver).define_element(self.sync_info_icon),
            'sync_info_tooltip': ElementFactory(driver).define_element(self.sync_info_tooltip),
            'daily_sync_start_time_dropdown': ElementFactory(driver).define_element(self.daily_sync_start_time_dropdown),
            'modal': ElementFactory(driver).define_element(self.modal),
            'job_history_link': ElementFactory(driver).define_element(self.job_history_link)
        }
        super().__init__(driver, self.elements)

    def daily_sync_enabled(self):
        return self.elements['enable_daily_sync_checkbox'].is_checked()

    def check_enable_daily_sync_checkbox(self):
        time.sleep(1)
        self.elements['enable_daily_sync_checkbox'].check()
        time.sleep(1)
        return self

    def is_daily_sync_tooltip_visible(self):
        icon = self.driver.wait_for_visible_element((By.XPATH, '//div[text()="I"]'))
        self.driver.hover_over_element(by=(By.XPATH, '//div[text()="I"]'))
        tool_tip_id = icon.get_attribute('id').replace('innterCt', '')
        return self, 'x-hide-offsets' not in self.driver.wait_for_visible_element((By.ID, tool_tip_id)).get_attribute('class')

    def validate_start_time_dropdown_contents_available(self, check_value):
        self.elements['daily_sync_start_time_dropdown'].wait_for_visible(2).click()
        li = self.driver.wait_for_visible_element((By.XPATH, f'//li[contains(text(), "{check_value}")]'))
        return self, li.is_displayed()

    def click_save_button(self):
        self.elements['save_button'].wait_for_visible(2).click()
        return self

    def is_modal_visible(self):
        return self, self.elements['modal'].wait_for_visible(2) is not None

    def close_modal(self):
        warning_dialog = self.elements['modal'].wait_for_visible(2)
        warning_dialog.find_element_by_xpath('//a[@buttontext="Close"]').click()
        return self

    def clear_enable_daily_sync_checkbox(self):
        time.sleep(1)
        self.elements['enable_daily_sync_checkbox'].check()
        return self

    def select_start_time_dropdown_contents_available(self, check_value):
        self.elements['daily_sync_start_time_dropdown'].wait_for_visible(2).click()
        self.driver.find_element_by_xpath(f'//li[contains(text(), "{check_value}")]').click()
        return self

    def get_sync_start_time_value(self):
        time.sleep(2)
        value_attr = self.elements['daily_sync_start_time_dropdown'].get_attribute_value('value')
        return '02:00 - 03:00 (08:00 - 09:00 IST)' in value_attr

    def open_job_history_page(self):
        self.elements['job_history_link'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('Job History')
        assert self.driver.title == 'Job History'
        return JobHistoryPage(self.driver).wait_for_page_to_load()
