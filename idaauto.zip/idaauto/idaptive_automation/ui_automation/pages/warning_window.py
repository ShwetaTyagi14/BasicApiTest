from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class WarningWindow(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"warningwindow")]'))}

    close_button = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"warningwindow")]//a[@buttontext="Close"]')),
                    'inner_text': 'Close'}

    warning_text = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"dialog-window-body")]/descendant::span//div'))}

    def __init__(self, driver):
        self.driver = driver
        dialog = UIElement(ElementDefinition(driver, **WarningWindow.dialog))
        self.elements = {
            self.LOADED_ELEMENT: dialog,
            'dialog': dialog,
            'close': UIElement(ElementDefinition(driver, **WarningWindow.close_button)),
            'warning_text': UIElement(ElementDefinition(driver, **WarningWindow.warning_text))
        }

        super().__init__(self.driver, self.elements)

    def close(self):
        self.elements['close'].click()

    def warning_message_text(self):
        return self.elements['warning_text'].get_text()
