from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddWebAppDialog(UIPage):
    dialog = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'modal-window') and @viewparttitle='Add Web App']"))}
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Add Web App')]"))}
    yes = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Yes"]'))}
    no = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="No"]'))}
    close = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"x-tool-after-title")]'))}
    continue_msg = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"subheader")]'))}
    app_image = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'quickstart-wizard')]/descendant::img"))}
    app_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'quickstart-wizard')]/descendant::span[@class='app-name']"))}
    description_label = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//descendant::label[text()='Description']"))}
    app_description = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//label[text()='Description']/following-sibling::div[contains(@class,'tag-tip')]"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.continue_msg),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'yes': factory(driver).define_element(self.yes),
            'no': factory(driver).define_element(self.no),
            'close': factory(driver).define_element(self.close),
            'continue_msg': factory(driver).define_element(self.continue_msg),
            'app_image': factory(driver).define_element(self.app_image),
            'app_title': factory(driver).define_element(self.app_title),
            'description_label': factory(driver).define_element(self.description_label),
            'app_description': factory(driver).define_element(self.app_description)
        }

        super().__init__(driver, self.elements)

    def press_yes(self):
        self.elements['yes'].click()

    def press_no(self):
        self.elements['no'].click()

    def press_close(self):
        self.elements['close'].click()

    def get_app_description(self):
        return self.elements['app_description'].get_text()

    def get_continue_msg(self):
        return self.elements['continue_msg'].get_text()