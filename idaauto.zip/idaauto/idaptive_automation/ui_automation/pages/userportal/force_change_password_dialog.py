from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ForceChangePasswordDialog(UIPage):

    _header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//span[.="Change Your Password"]')),
              'inner_text': 'Change Your Password'}

    _new_password = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="NewPassword"]'),
                                      label_text_locator=(By.XPATH, f'//label[contains(text(),"New Password") and not(contains(text(),"Confirm"))]'))}

    _confirm_password = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="ConfirmPassword"]'),
                                          label_text_locator=(By.XPATH, f'//label[contains(text(),"Confirm New Password")]'))}

    _save_button = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]'))}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
             self.LOADED_ELEMENT: factory(driver).define_element(self._header),
             'new_password': factory(driver).define_text_input(self._new_password),
             'confirm_password': factory(driver).define_text_input(self._confirm_password),
             'save_button': factory(driver).define_element(self._save_button)
        }

        super().__init__(driver, self.elements)

    def set_new_password(self, password):
        self.elements['new_password'].clear().type(password)
        return self

    def set_confirm_password(self, password):
        self.elements['confirm_password'].clear().type(password)
        return self

    def click_save_button(self):
        self.elements['save_button'].click()
