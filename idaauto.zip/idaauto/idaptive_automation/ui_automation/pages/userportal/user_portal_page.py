from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.userportal.shared_app_settings_page import SharedAppSettingsPage
from idaptive_automation.ui_automation.pages.profilemenu.user_profile_menu import UserProfileMenu
from idaptive_automation.ui_automation.pages.userportal.account_page import UserPortalAccountPage
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains


class UserPortalPage(UIPage):
    account = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[text()="Account"]')),
               'inner_text': 'Account'}
    _pwd_expire_banner = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(.,"Your password is about to expire in")][./a[.="here"]]')),
        'supports_validation': False
    }

    organization_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Organization"]')),
                        'inner_text': 'Organization'}

    manager = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="ReportsTo"]'),
                                            label_text_locator=(
                                            By.XPATH, '//input[@testname="ReportsTo"]/preceding-sibling::div/label')),
               'label_text': 'Manager'}

    add_apps_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add Apps"]'))
                       }
    apps = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@class='app-name-text']"))}

    user_display_name = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//span[contains(@class,"x-btn-inner-center") and contains(@id,"splitbutton")]'))}

    group_icon = {'locator': ElementSetLocator(element_locator=(By.CSS_SELECTOR, 'span.shared-icon'))}

    new_green_icons = {'locator': ElementSetLocator(element_locator=(By.CSS_SELECTOR, 'span.new-icon'))}

    new_green_icon = {'locator': ElementSetLocator(element_locator=(By.XPATH, "(//span[@class='new-icon'])[1]"))}

    valid_user_text = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[text()='Log In as Colby Apps']"))}

    valid_zip_code = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[contains(@id,"delivery-postal-label")]/span'))}

    email_error = {'locator': ElementSetLocator(element_locator=(By.XPATH, ' //label[@class="error"]'))}

    app_creds_username_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@id="logonId"]'))}

    app_creds_password_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@id="logonPassword"]'))}

    search_box = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//input[@name='search-field-input' and @placeholder='Search Apps']"),
        parent_container_locator=(By.XPATH,
                                  f'//input[@name="search-field-input" and @placeholder="Search Apps"]/ancestor::div[contains(@class,"search-field")]'),
        toggle_locator=(By.XPATH,
                        f'//input[@name="search-field-input" and @placeholder="Search Apps"]/ancestor::div[contains(@class,"search-field")]/descendant::a'))}

    displayed_items = {'locator': ElementSetLocator(element_locator=(By.CSS_SELECTOR, f'div.x-boundlist-item'))
                    }

    tagged_set_dropdown = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f'//table[contains(@id,"tagged-set-combo")]/descendant::div[contains(@class,"arrow-trigger")]'))
                     }
    
    get_started_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Get Started"]'))
                    }

    authentication_setup_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Authentication Setup"]'))
                    }

    sq_questions_label = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Security Questions"]'))
                    }

    sq_question_text = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Enter a question"]'))
                    }

    sq_question_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="CellEditorInputQuestion"]'))
                    }

    sq_answer_text = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Enter an answer"]'))
                    }

    sq_answer_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="CellEditorInputAnswer"]'))
                    }

    save_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]'))
                    }

    congratulations_text = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(text(),"Congratulations! You are done configuring")]'))
                    }

    done_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Done"]'))
                    }

    sws_icon = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[@class='sws-icon']"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_search_box(self.search_box),
            'account': factory(driver).define_element(self.account),
            'apps': factory(driver).define_element_group(self.apps),
            'add_apps_button': factory(driver).define_element(self.add_apps_button),
            'search_box': factory(driver).define_search_box(self.search_box),
            'organization': factory(driver).define_element(self.organization_tab),
            'user_display_name': factory(driver).define_element(self.user_display_name),
            'group_icon': factory(driver).define_element(self.group_icon),
            'new_green_icon': factory(driver).define_element(self.new_green_icon),
            'new_green_icons': factory(driver).define_element_group(self.new_green_icons),
            'manager': factory(driver).define_text_input(self.manager),
            'valid_user_text': factory(driver).define_element(self.valid_user_text),
            'valid_zip_code': factory(driver).define_element(self.valid_zip_code),
            'email_error': factory(driver).define_element(self.email_error),
            'app_creds_username_input': factory(driver).define_text_input(self.app_creds_username_input),
            'app_creds_password_input': factory(driver).define_text_input(self.app_creds_password_input),
            'tagged_set_dropdown': factory(driver).define_element(self.tagged_set_dropdown),
            'pwd_expire_banner': factory(driver).define_element(self._pwd_expire_banner),
            'get_started_button': factory(driver).define_element(self.get_started_button),
            'authentication_setup_title': factory(driver).define_element(self.authentication_setup_title),
            'sq_questions_label': factory(driver).define_element(self.sq_questions_label),
            'sq_question_text': factory(driver).define_element(self.sq_question_text),
            'sq_question_input': factory(driver).define_element(self.sq_question_input),
            'sq_answer_text': factory(driver).define_element(self.sq_answer_text),
            'sq_answer_input': factory(driver).define_element(self.sq_answer_input),
            'save_button': factory(driver).define_element(self.save_button),
            'congratulations_text': factory(driver).define_element(self.congratulations_text),
            'done_button': factory(driver).define_element(self.done_button),
            'sws_icon': factory(driver).define_element(self.sws_icon)
        }

        super().__init__(driver, self.elements)

    def wait_for_page_to_load(self, wait_time=UIPage.SHORT_DELAY, required=True, wait_for_ready=True):
        return UserProfileMenu(self.driver).wait_for_page_to_load(wait_time, required, wait_for_ready=wait_for_ready)

    def _get_tile_element(self, app_name):
        xpath = f'//div[starts-with(@class,"ux-view-thumb-wrap")]//a[@class="app-name-text" and contains(text(),"{app_name}")]'

        definition = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, xpath)),
                      'inner_text': app_name}
        return factory(self.driver).define_element(definition)

    def hover_over_app_tile(self, app_name):
        xpath = f'//div[starts-with(@class,"ux-view-thumb-wrap")][//a[@class="app-name-text" and .="{app_name}"]]'
        script = f"xp = '{xpath}'; " + '''function getElementByXpath(path) {
  return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}
elem = getElementByXpath(xp)

if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); 
elem.dispatchEvent(evObj);} else if(document.createEventObject) { elem.fireEvent('onmouseover');}'''
        self.driver.hover_over_element((By.XPATH, xpath), pause_for=2)
        self.driver.execute_script(script)

    def get_app_tile_tooltip(self, app_name):
        xpath = f'//div[contains(@id,"tooltip")][contains(., "{app_name}")]'
        definition = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        if element.get_element() is None:
            assert False, f'Tool tip for {app_name} app tile not found'
        return element.get_text()

    def open_app_tile_settings(self, app_name):
        definition = {'locator':
                          ElementSetLocator(element_locator=(By.ID, f'{app_name}-application setup'))}
        element = factory(self.driver).define_element(definition)
        if element.get_element() is None:
            assert False, f'App settings icon for {app_name} app tile not found'
        element.click()
        dialog = SharedAppSettingsPage(self.driver)
        dialog.wait_for_page_to_load()
        return dialog

    def launch_app(self, app_name, wait_time=UIPage.LONG_DELAY):
        cur_handles = self.get_window_handles()
        element = self._get_tile_element(app_name)
        element.click()
        self.switch_to_new_tab(cur_handles)
        self.__wait_for_app_launch_to_complete(wait_time)

    def switch_to_new_tab_after_app_launch(self, handles, wait_time=UIPage.LONG_DELAY):
        self.wait_for_page_to_load(required=False)
        self.switch_to_new_tab(handles, wait_time)
        self.__wait_for_app_launch_to_complete(wait_time)

    def __wait_for_app_launch_to_complete(self, wait_time):
        sleep_time = wait_time
        definition = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(.,"Failed to launch")]'))}
        element = factory(self.driver).define_element(definition)
        while 'HandleAppClick' in self.driver.current_url and sleep_time > 0:
            assert element.get_element() is None, f'App launch failed'
            sleep(1)
            sleep_time -= 1

    def is_app_tile_displayed(self, app_name):
        element = self._get_tile_element(app_name)
        if element.get_element() is None:
            return False
        try:
            return element.is_displayed()
        except AttributeError:
            return False

    def launch_app_up(self, app_name):
        element = self._get_tile_element(app_name)
        element.click()
        self.driver.wait_for_loading_mask_to_disappear()

    def get_app_url(self):
        return self.driver.current_url

    def click_add_apps_button(self):
        self.elements['add_apps_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def get_apps(self):
        apps = self.elements['apps'].get_element()
        return apps

    def search_app_input(self, app_name):
        self.elements['search_box'].wait_for_visible()
        self.elements['search_box'].clear()
        self.elements['search_box'].search_for(app_name)
        return self

    def click_account_tab(self):
        self.elements['account'].wait_for_visible()
        self.elements['account'].click()
        return UserPortalAccountPage(self.driver).wait_for_page_to_load()

    def click_organization_tab(self):
        self.elements['organization'].wait_for_visible()
        self.elements['organization'].click()
        return self

    def get_manager_text(self):
        return self.elements['manager'].get_text()

    def get_user_display_text(self):
        return self.elements['user_display_name'].get_text()

    def is_group_icon_displayed(self):
        return self.elements['group_icon'].is_displayed()

    def is_new_icon_displayed(self):
        return self.elements['new_green_icon'].is_displayed()

    def is_sws_icon_displayed(self):
        return self.elements['sws_icon'].is_displayed()

    def get_group_icon_tooltip(self, app_name):
        element = self.driver.find_element_by_xpath("//span[text()='G']")
        self.driver.scroll_element_into_view(element)
        self.driver.hover_over_element(by=(By.XPATH, '//span[text()="G"]'), pause_for=3)
        xpath = f'//div[contains(@class,"dark-tooltip")]//div//span' \
                f'//div[ contains(@id,"tooltip") and not(contains(text(),"Application Settings")) and not(contains(text(),"{app_name}"))]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        if element.get_element() is None:
            assert False, f'Tool tip for {app_name} group icon not found'
        return element.get_text()

    def get_new_icons(self):
        new_apps = self.elements['new_green_icons'].get_element()
        return new_apps

    def launch_new_app(self):
        self.elements['new_green_icon'].wait_for_visible()
        self.elements['new_green_icon'].click()
        return self

    def get_title(self):
        return self.driver.title

    def is_login_user_displayed(self):
        self.elements['valid_user_text'].wait_for_visible()
        return self.elements['valid_user_text'].is_displayed()

    def get_zip_code(self):
        self.elements['valid_zip_code'].wait_for_visible()
        return self.elements['valid_zip_code'].get_text()

    def is_email_error_displayed(self):
        self.elements['email_error'].wait_for_visible()
        return self.elements['email_error'].is_displayed()

    def set_app_creds_username(self, username):
        self.elements['app_creds_username_input'].wait_for_visible()
        self.elements['app_creds_username_input'].clear()
        self.elements['app_creds_username_input'].type(username)
        return self

    def set_app_creds_password(self, password):
        self.elements['app_creds_password_input'].wait_for_visible()
        self.elements['app_creds_password_input'].clear()
        self.elements['app_creds_password_input'].type(password)
        return self

    def click_tagged_set_dropdown(self):
        self.driver.hover_over_element((By.XPATH, '//table[contains(@id,"tagged-set-combo")]/descendant::div[contains(@class,"arrow-trigger")]'))
        self.elements['tagged_set_dropdown'].click()

    def verify_tag_item(self, tag_item_name):
        self.driver.wait_for_visible_element(f'//div[text()="{tag_item_name}"]')
        element = self.driver.find_element_by_xpath(f'//hr/following-sibling::div[text()="{tag_item_name}"]')
        return element.is_displayed()

    def select_tag_name(self, tag_item_name):
        self.driver.wait_for_visible_element(f'//div[text()="{tag_item_name}"]')
        element = self.driver.find_element_by_xpath(f'//hr/following-sibling::div[text()="{tag_item_name}"]')
        element.click()
        return self

    def get_password_expire_banner_text(self):
        return self.elements['pwd_expire_banner'].get_text()

    def is_pwd_change_banner_displayed(self):
        return self.elements['pwd_expire_banner'].get_element() is not None
    
    def click_sq_questions_label(self):
        self.elements['sq_questions_label'].click()

    def click_get_started_button(self):
        self.elements['get_started_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def is_authentication_setup_title_displayed(self):
        return self.elements['authentication_setup_title'].is_displayed()

    def set_sq_question(self, question):
        self.elements['sq_question_text'].click()
        # This does not work, using ActionChains as workaround
        #self.elements['sq_question_input'].send_keys(question)
        actions = ActionChains(self.driver)
        actions.send_keys(question)
        actions.perform()

    def set_sq_answer(self, answer):
        self.elements['sq_answer_text'].click()
        # This does not work, using ActionChains as workaround
        #self.elements['sq_answer_input'].send_keys(answer)
        actions = ActionChains(self.driver)
        actions.send_keys(answer)
        actions.perform()

    def click_save_button(self):
        self.elements['save_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def is_congratulations_text_displayed(self):
        return self.elements['congratulations_text'].is_displayed()

    def click_done_button(self):
        self.elements['done_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def is_get_started_button_displayed(self):
        return self.elements['get_started_button'].is_displayed()
    
    def is_sign_in_experience_notice_displayed(self):
        element = self.driver.wait_for_visible_element((By.XPATH, 
            f'//div[contains(text(), "Your sign in experience was different")]'))
        return element != None
