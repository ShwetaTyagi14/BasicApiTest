from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.userportal.change_password_dialog import ChangePasswordDialog
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UserPortalAccountPage(UIPage):
    edit_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Edit"]')),
                   'inner_text': 'Edit'}
    _last_changed_ = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(.,"Last changed: ")][not(.//*)]')),
        'supports_validation': False
    }
    success_toaster = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[text()='Success']"))}

    personal_profile = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Personal Profile"]'))}

    login_name = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="LoginName"]'),
                                               label_text_locator=(By.XPATH, f'//input[@testname="LoginName"]/preceding-sibling::div/label')),
                  'label_text': 'Login Name'}

    display_name = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text()="Display Name"]/../following-sibling::input'),
                                                 label_text_locator=(By.XPATH, f'//label[text()="Display Name]')),
                    'label_text': 'Display Name'}

    ad_mail = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="mail"]'),
                                            label_text_locator=(By.XPATH, f'//input[@testname="mail"]/preceding-sibling::div/label')),
               'label_text': 'Email Address',
               'supports_validation': False}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.edit_button),
            'edit_button': factory(driver).define_element(self.edit_button),
            'last_changed': factory(driver).define_element(self._last_changed_),
            'success_toaster': factory(driver).define_element(self.success_toaster),
            'personal_profile': factory(driver).define_element(self.personal_profile),
            'login_name': factory(driver).define_text_input(self.login_name),
            'display_name': factory(driver).define_text_input(self.display_name),
            'ad_mail': factory(driver).define_text_input(self.ad_mail)
        }

        super().__init__(driver, self.elements)

    def click_password_edit_button(self):
        self.elements['edit_button'].wait_for_visible()
        self.elements['edit_button'].click()
        return ChangePasswordDialog(self.driver).wait_for_page_to_load()

    def validate_success_toaster(self):
        return self.elements['success_toaster'].is_displayed()

    def click_personal_profile_tab(self):
        self.elements['personal_profile'].wait_for_visible()
        self.elements['personal_profile'].click()
        self.is_loaded()

    def get_login_name_text(self):
        return self.elements['login_name'].get_text()

    def get_display_name_text(self):
        return self.elements['display_name'].get_text()

    def get_ad_mail_text(self):
        return self.elements['ad_mail'].get_text()

    def get_pwd_last_changed_date(self):
        return self.elements['last_changed'].get_text()
