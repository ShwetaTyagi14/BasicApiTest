from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AppCatalogDialog(UIPage):
    app_catalog_dialog = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@viewparttitle='App Catalog']"))
               }
    main_container = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"main-content")]'))
                      }
    search_apps_input= {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, f"//input[@name='search-field-input' and @placeholder='Search']"))
               }
    search_results = {'locator':
                      ElementSetLocator(element_locator=(By.CSS_SELECTOR, "div.app-text"))
               }
    apps_add_buttons = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'grid-body')]/descendant::span[text()='Add']"))}
    apps_first_add_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'grid-body')]/descendant::span[text()='Add'][1]"))}
    search_tab = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH,"//a[@buttontext='Search']"))
    }
    recommended_tab = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Recommended']"))
    }
    recommended_grid_body = {'locator':
                             ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'grid-body')]"))
               }
    close_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Close']"))}
    remove_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//descendant::span[text()='Remove']"))}
    toaster_msg = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[text()='Application Added']"))}

    apps_recommended_msg = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"x-grid-empty")]//b'))}
    app_added = {'locator': ElementSetLocator(By.XPATH, f'//div[text()="Application Added"]')}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.search_tab),
            'app_catalog_dialog': factory(driver).define_element(self.app_catalog_dialog),
            'main_container': factory(driver).define_element(self.main_container),
            'search_apps_input': factory(driver).define_text_input(self.search_apps_input),
            'search_results': factory(driver).define_element_group(self.search_results),
            'search_tab': factory(driver).define_element(self.search_tab),
            'recommended_tab': factory(driver).define_element(self.recommended_tab),
            'recommended_grid_body': factory(driver).define_element(self.recommended_grid_body),
            'apps_add_buttons': factory(driver).define_element_group(self.apps_add_buttons),
            'apps_first_add_button': factory(driver).define_element(self.apps_first_add_button),
            'close_btn': factory(driver).define_element(self.close_btn),
            'toaster_msg': factory(driver).define_element(self.toaster_msg),
            'remove_button': factory(driver).define_element(self.remove_button),
            'apps_recommended_msg': factory(driver).define_element(self.apps_recommended_msg),
            'app_added': factory(driver).define_element(self.app_added)

        }

        super().__init__(driver, self.elements)

    def search_app_input(self,app_name):
        self.driver.wait_for_loading_mask_to_disappear(15)
        self.elements['search_apps_input'].wait_for_visible()
        self.elements['search_apps_input'].type(app_name)
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def get_search_string_count(self):
        self.driver.wait_for_loading_mask_to_disappear(15)
        results = self.elements['search_results'].get_element()
        return results

    def click_search_tab(self):
        self.elements['search_tab'].click()
        return self

    def click_recommended_tab(self):
        self.elements['recommended_tab'].click()
        return self

    def get_recommended_tab_msg(self):
        return self.elements['recommended_grid_body'].get_text()

    def click_first_add_apps_button(self):
        self.elements['apps_first_add_button'].wait_for_visible()
        self.elements['apps_first_add_button'].click()
        return self

    def close_app_catalog_dialog(self):
        self.driver.wait_for_loading_mask_to_disappear(15)
        self.elements['remove_button'].wait_for_visible()
        self.elements['close_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def validate_toaster(self):
        self.driver.wait_for_loading_mask_to_disappear(15)
        return self.elements['toaster_msg'].get_text()

    def validate_apps_recommended_message(self):
        return self.elements['apps_recommended_msg'].get_text()

    def is_app_added(self):
        """ Use to validate the 'Application added' text """
        return self.elements['app_added'].is_displayed()

    def is_remove_button_displayed(self):
        return self.elements['remove_button'].is_displayed()