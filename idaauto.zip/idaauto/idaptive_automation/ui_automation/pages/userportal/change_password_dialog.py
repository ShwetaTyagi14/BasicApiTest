from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ChangePasswordDialog(UIPage):

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Change Your Password"]')),
              'inner_text': 'Change Your Password'}

    current_password = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="cur-pwd"]'),
                                          label_text_locator=(By.XPATH, f'//input[@testname="cur-pwd"]/preceding-sibling::div/label')),
                        'validation_error_class': 'x-form-error-msg x-lbl-top-err-icon x-form-invalid-icon'}

    new_password = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="new-pwd"]'),
                                      label_text_locator=(By.XPATH, f'//label[contains(text(),"New Password") and not(contains(text(),"Confirm"))]')),
                    'validation_error_class': 'x-form-error-msg x-lbl-top-err-icon x-form-invalid-icon'}

    confirm_password = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="cfm-pwd"]'),
                                          label_text_locator=(By.XPATH, f'//label[contains(text(),"Confirm New Password")]')),
                        'validation_error_class': 'x-form-error-msg x-lbl-top-err-icon x-form-invalid-icon'}

    ok_button = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="OK"]')),
                 'inner_text': 'OK'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
             self.LOADED_ELEMENT: factory(driver).define_element(self.header),
             'current_password': factory(driver).define_text_input(self.current_password),
             'new_password': factory(driver).define_text_input(self.new_password),
             'confirm_password': factory(driver).define_text_input(self.confirm_password),
             'ok_button': factory(driver).define_element(self.ok_button),
             'cancel_button': factory(driver).define_element(self.cancel_button)
        }

        super().__init__(driver, self.elements)

    def set_current_password(self, password):
        self.elements['current_password'].clear()
        self.elements['current_password'].type(password)
        return self

    def set_new_password(self, password):
        self.elements['new_password'].clear()
        self.elements['new_password'].type(password)
        return self

    def set_confirm_password(self, confirm_password):
        self.elements['confirm_password'].clear()
        self.elements['confirm_password'].type(confirm_password)
        return self

    def click_ok_button(self):
        self.elements['ok_button'].wait_for_visible()
        ready = self.is_ok_button_enabled()
        if ready:
            self.elements['ok_button'].click()
        else:
            self.elements['ok_button'].wait_for_visible(wait_time=5)
            self.elements['ok_button'].click()

    def is_ok_button_enabled(self):
        return self.elements['ok_button'].is_enabled()

    def click_cancel_button(self):
        self.elements['cancel_button'].wait_for_visible()
        self.elements['cancel_button'].click()
