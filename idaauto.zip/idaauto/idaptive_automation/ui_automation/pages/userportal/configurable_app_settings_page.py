from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.userportal.shared_app_settings_page import SharedAppSettingsPage
from selenium.webdriver.common.keys import Keys
from time import sleep


class ConfigurableAppSettingsPage(SharedAppSettingsPage):
    user_identity = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//span[.="User Identity"]')),
                     'inner_text': 'User Identity'}

    username_label = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f'//label[contains(text(),"User Name")]')),
                      'inner_text': 'User Name:'}

    password_label = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f'//label[contains(text(),"Password")]')),
                      'inner_text': 'Password:'}

    username = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="Username"]'))}

    password = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="Password"]'))}

    show_password = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class, "show-password")]'))}

    copy_password = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class, "copy-password")]'))}

    save_btn = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                'inner_text': 'Save'}

    cancel_btn = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel"]')),
                  'inner_text': 'Cancel'}

    show_password_icon = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'(//td[@class=" x-trigger-cell x-unselectable"])[3]'))
                    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.password_label),
            'user_identity': factory(driver).define_element(self.user_identity),
            'username_label': factory(driver).define_element(self.username_label),
            'password_label': factory(driver).define_element(self.password_label),
            'username': factory(driver).define_text_input(self.username),
            'password': factory(driver).define_text_input(self.password),
            'show_password': factory(driver).define_element(self.show_password),
            'copy_password': factory(driver).define_element(self.copy_password),
            'save': factory(driver).define_element(self.save_button),
            'cancel_btn': factory(driver).define_element(self.cancel_btn),
            'save_btn': factory(driver).define_element(self.save_btn),
            'show_password_icon': factory(driver).define_element(self.show_password_icon)
        }

        super().__init__(driver, self.elements)

    def is_user_identity_displayed(self):
        return self.elements['user_identity'].is_displayed()

    def get_username(self):
        return self.elements['username'].get_attribute_value('value')

    def set_username(self, username):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['username'].clear()
        self.elements['username'].type(username)

    def is_show_password_icon_displayed(self):
        raise Exception('this method has not been implemented')

    def is_copy_password_icon_displayed(self):
        raise Exception('this method has not been implemented')

    def get_password_text(self):
        return self.elements['password'].get_attribute_value('value')

    def set_password(self, password):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['password'].clear()
        self.elements['password'].type(password)

    def copy_password_to_clipboard(self):
        self.elements['copy_password'].click()
        self.driver.wait_for_visible_element((By.XPATH, '//td[./table[starts-with(@id,"passwordfield")]]/div[@class="bright-green"]'),
                                             wait_time=5)
        self.driver.find_element_by_tag_name('body').send_keys(Keys.LEFT_CONTROL + 'c')
        return self.driver.get_clipboard_contents()

    def click_save_button(self):
        self.elements['save_btn'].wait_for_visible()
        if not self.elements['save_btn'].is_enabled():
            self.driver.wait_for_loading_mask_to_disappear()
            self.elements['save_btn'].click()
        else:
            self.elements['save_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def click_user_identity(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['user_identity'].click()

    def is_save_button_disabled(self):
        class_attr_value = self.elements['save_btn'].get_attribute_value('class')
        return 'disabled' in class_attr_value

    def click_cancel_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['cancel_btn'].click()

    def is_username_displayed(self):
        return self.elements['username'].is_displayed()

    def is_password_displayed(self):
        return self.elements['password'].is_displayed()

    def click_show_password_icon(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['show_password_icon'].click()
