from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class SharedAppSettingsPage(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Application Settings"]'))}
    heading = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Application Settings"]')),
               'inner_text': 'Application Settings'}

    app_name = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="app-name"]'))}

    app_desc = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="app-desc"]'))}

    add_tags = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//label[.="Add Tags"]')),
                'inner_text': 'Add Tags'}

    add_tags_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="tagComboInput"]'))
                     }

    existing_tag = {
        'locator':
            ElementSetLocator(element_locator=(By.CSS_SELECTOR, f'div.deletable-tag')),
        'supports_validation': False
       }

    tags_dropdown = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//table[@itemid="tagCombo"]/descendant::div[contains(@class,"arrow-trigger")]'))
       }

    save_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                   'inner_text': 'Save'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver, elements=None):
        if elements is None:
            self.elements = {
                self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
                'heading': factory(driver).define_element(self.heading),
                'app_name': factory(driver).define_element(self.app_name),
                'app_desc': factory(driver).define_element(self.app_desc),
                'add_tags': factory(driver).define_element(self.add_tags),
                'add_tags_input': factory(driver).define_text_input(self.add_tags_input),
                'existing_tag': factory(driver).define_element(self.existing_tag),
                'tags_dropdown': factory(driver).define_element(self.tags_dropdown),
                'save': factory(driver).define_element(self.save_button),
                'cancel': factory(driver).define_element(self.cancel_button),
            }
        else:
            elements.update({
                self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
                'dialog': factory(driver).define_element(self.dialog),
                'heading': factory(driver).define_element(self.heading),
                'app_name': factory(driver).define_element(self.app_name),
                'app_desc': factory(driver).define_element(self.app_desc),
                'add_tags': factory(driver).define_element(self.add_tags),
                'add_tags_input': factory(driver).define_text_input(self.add_tags_input),
                'existing_tag': factory(driver).define_element(self.existing_tag),
                'tags_dropdown': factory(driver).define_element(self.tags_dropdown),
                'save': factory(driver).define_element(self.save_button),
                'cancel': factory(driver).define_element(self.cancel_button),
            })
        self.driver = driver
        super().__init__(self.driver, self.elements)

    def get_app_name(self):
        return self.elements['app_name'].get_text()

    def get_app_description(self):
        return self.elements['app_desc'].get_text()

    def is_save_button_disabled(self):
        class_attr_text = self.elements['save'].get_attribute_value('class')
        return "disabled" in class_attr_text

    def click_cancel_button(self):
        self.elements['cancel'].click()

    def click_save_button(self):
        self.elements['save'].click()

    def is_add_tags_displayed(self):
        return self.elements['add_tags'].is_displayed()

    def set_tag_name(self,tag_name):
        self.elements['add_tags_input'].wait_for_visible()
        self.elements['add_tags_input'].type(tag_name)

    def get_tag_name(self):
        return self.elements['existing_tag'].get_text()

    def click_tags_drop_down(self):
        self.elements['tags_dropdown'].click()

    def verify_tags_displayed(self,tag_name):
        self.driver.wait_for_visible_element(f'//div[text()="{tag_name}"]')
        element = self.driver.find_element_by_xpath(f'//div[text()="{tag_name}"]')
        return element.is_displayed()