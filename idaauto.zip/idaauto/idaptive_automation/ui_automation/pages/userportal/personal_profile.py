from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class PersonalProfile(UIPage):
    edit_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Edit"]')),
                   'inner_text': 'Edit'}
    proceed_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Proceed"]'))}

    save_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))}

    mobile_number = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                     '//label[text()="Mobile Number"]/../following-sibling::input'),  label_text_locator=
                     (By.XPATH, f'//label[text()="Mobile Number]')), 'label_text': 'Mobile Number'}
    password = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[contains(@name, "password")]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.edit_button),
            'edit_button': factory(driver).define_element(self.edit_button),
            'proceed_button': factory(driver).define_element(self.proceed_button),
            'mobile_number': factory(driver).define_text_input(self.mobile_number),
            'save_button': factory(driver).define_element(self.save_button),
            'password': factory(driver).define_text_input(self.password)
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def get_display_name_text(self):
        return self.elements['display_name'].get_text()

    def click_edit_profile(self, password):
        self.elements['edit_button'].wait_for_visible()
        self.elements['edit_button'].click()
        self.elements['password'].get_element()
        self.elements['password'].clear()
        self.elements['password'].type(password)
        self.click_proceed_button()
        return True

    def edit_mobile_number(self, number):
        self.elements['mobile_number'].wait_for_visible()
        self.elements['mobile_number'].click()
        self.elements['mobile_number'].get_element()
        self.elements['mobile_number'].clear()
        self.elements['mobile_number'].type(number)
        self.click_save_button()
        return True

    def click_save_button(self):
        self.elements['save_button'].wait_for_visible()
        self.hover_and_click(element_text='Save')
        self.driver.wait_for_loading_mask_to_disappear()

    def click_proceed_button(self):
        self.elements['proceed_button'].wait_for_visible()
        self.hover_and_click(element_text='Proceed')
        self.driver.wait_for_loading_mask_to_disappear()

    def hover_and_click(self, element_text):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='{element_text}']"))
        self.driver.hover_over_element(by=(By.XPATH, f"//a[@buttontext='{element_text}']"))
        element.click()
        return self

