from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ace_text_input import AceTextInput


class PatternDialog(UIPage):

    dialog_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(), 'Add Pattern')]"))}

    pattern_name_input_textbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[@value='']"))}
    pattern_name_input_textbox_disabled = {'locator': ElementSetLocator(element_locator=
                                                                        (By.CSS_SELECTOR, ".ant-input-disabled"))}
    pattern_name_error_msg = \
        {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                       '//span[contains(text(),"Please input valid pattern name.")]'))}
    pattern_payload_error_msg = \
        {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                       '//span[contains(text(),"Please input valid payload.")]'))}

    pattern_description_input_textbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//textarea'))}

    close_icon_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-close close-icon']"))}

    ok_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[contains(.,'OK')]"))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[contains(.,'Cancel')]"))}

    def __init__(self, driver):
        self.elements = {
            'pattern_name_input_textbox': ElementFactory(driver).define_text_input(self.pattern_name_input_textbox),
            'pattern_name_input_textbox_disabled':
                ElementFactory(driver).define_text_input(self.pattern_name_input_textbox_disabled),
            'pattern_description_input_textbox':
                ElementFactory(driver).define_text_input(self.pattern_description_input_textbox),
            'pattern_query_input_textbox': AceTextInput(driver),
            'pattern_name_error_msg': ElementFactory(driver).define_displayed_text("Please input valid pattern name.",
                                                                                   self.pattern_name_error_msg),
            'pattern_payload_error_msg': ElementFactory(driver).define_displayed_text("Please input valid payload.",
                                                                                      self.pattern_payload_error_msg),
            'ok_button': ElementFactory(driver).define_element(self.ok_button),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button),
            'close_icon_button': ElementFactory(driver).define_element(self.close_icon_button),
            'pattern_payload_input_textbox': AceTextInput(driver)
        }

        super().__init__(driver, self.elements)

    def input_name(self, name):
        self.elements['pattern_name_input_textbox'].clear()
        self.elements['pattern_name_input_textbox'].type(name)
        self.elements['pattern_name_input_textbox'].type(Keys.ENTER)

    def input_description(self, desc):
        self.elements['pattern_name_input_textbox'].clear()
        self.elements['pattern_description_input_textbox'].type(desc)
        self.elements['pattern_description_input_textbox'].type(Keys.ENTER)

    def input_payload(self, payload):
        self.elements['pattern_payload_input_textbox'].type_ace_input(payload)

    def click_button(self, button):
        if button == 'OK':
            element = 'ok_button'
        elif button == 'Cancel':
            element = 'cancel_button'
        elif button == 'Icon_Close':
            element = 'close_icon_button'
        else:
            return None

        self.elements[element].click()

    def check_error_message(self, error_message):
        self.elements[error_message].validate()

    def check_name_input_box(self):
        assert self.elements['pattern_name_input_textbox_disabled'].is_enabled() is False

    def add_new_custom_pattern(self, name, payload, description=None):
        self.input_name(name)
        self.input_description(description)
        self.input_payload(payload)
        self.click_button('OK')
