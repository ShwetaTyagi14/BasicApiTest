from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class PatternExportDialog(UIPage):

    dialog_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(), 'Export')]"))}
    export_name_input_box = {'locator': ElementSetLocator(element_locator=(
        By.CSS_SELECTOR, '.ant-col-18 > .ant-input'))}

    export_ok_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//button[.='OK']"))}

    export_cancel_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//button[.='Cancel']"))}

    pattern_name_error_msg = \
        {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                       '//span[contains(text(),"Please input the file name.")]'))}

    def __init__(self, driver):
        self.elements = {
            'export_name_input_box': ElementFactory(driver).define_text_input(self.export_name_input_box),
            'ok_button': ElementFactory(driver).define_element(self.export_ok_button),
            'cancel_button': ElementFactory(driver).define_element(self.export_cancel_button),
            'name_error_msg': ElementFactory(driver).define_displayed_text("Please input valid pattern name.",
                                                                           self.pattern_name_error_msg),
        }

        super().__init__(driver, self.elements)

    def input_name(self, name):
        self.elements['export_name_input_box'].clear()
        self.elements['export_name_input_box'].type(name)
        self.elements['export_name_input_box'].type(Keys.ENTER)

    def click_button(self, button):
        if button == 'OK':
            element = 'ok_button'
        elif button == 'Cancel':
            element = 'cancel_button'
        else:
            return None

        self.elements[element].click()

    def check_error_message(self, error_message):
        self.elements[error_message].validate()
