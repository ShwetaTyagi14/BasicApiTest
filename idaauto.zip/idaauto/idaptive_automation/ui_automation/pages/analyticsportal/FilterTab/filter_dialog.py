from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class FilterDialog(UIPage):

    dialog_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(), 'Edit Filter')]"))}

    filter_name_input_textbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[@value='']"))}

    filter_name_error_msg = \
        {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                       '//span[contains(text(),"Please input valid filter name.")]'))}
    filter_payload_error_msg = \
        {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                       '//span[contains(text(),"Please input valid payload.")]'))}

    filter_description_input_textbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//textarea'))}

    filter_pattern_library_input_textbox = \
        {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, "ant-select ant-select-disabled"))}

    filter_payload_input_textbox = \
        {'locator': ElementSetLocator(element_locator=(By.XPATH, '//*[@id="brace-editor"]/textarea'))}

    close_icon_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class = 'anticon anticon-close close-icon']"))}

    ok_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[.='OK']"))}
    cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[.='Cancel']"))}
    edit_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[contains(.,'Edit')]"))}
    variable_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[contains(.,'Variable')]"))}
    simulator_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[contains(.,'Simulator')"))}

    def __init__(self, driver):
        self.elements = {
            'filter_name_input_textbox': ElementFactory(driver).define_text_input(self.filter_name_input_textbox),
            'filter_description_input_textbox':
                ElementFactory(driver).define_text_input(self.filter_description_input_textbox),
            'filter_payload_input_textbox': ElementFactory(driver).define_text_input(self.filter_payload_input_textbox),
            'filter_name_error_msg': ElementFactory(driver).define_displayed_text("Please input valid filter name.",
                                                                                  self.filter_name_error_msg),
            'filter_payload_error_msg': ElementFactory(driver).define_displayed_text("Please input valid payload.",
                                                                                     self.filter_payload_error_msg),
            'ok_button': ElementFactory(driver).define_element(self.ok_button),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button),
            'close_icon_button': ElementFactory(driver).define_element(self.close_icon_button),
            'edit_button': ElementFactory(driver).define_element(self.edit_button),
            'variable_button': ElementFactory(driver).define_element(self.variable_button),
            'simulator_button': ElementFactory(driver).define_element(self.simulator_button),
            'filter_pattern_library_input_textbox':
                ElementFactory(driver).define_text_input(self.filter_pattern_library_input_textbox)
        }

        super().__init__(driver, self.elements)

    def input_filter_name(self, name):
        self.elements['filter_name_input_textbox'].clear()
        self.elements['filter_name_input_textbox'].type(name)
        self.elements['filter_name_input_textbox'].type(Keys.ENTER)

    def input_description(self, desc):
        self.elements['filter_description_input_textbox'].clear()
        self.elements['filter_description_input_textbox'].type(desc)
        self.elements['filter_description_input_textbox'].type(Keys.ENTER)

    def input_pattern_library(self, desc):
        self.elements['filter_pattern_library_input_textbox'].clear()
        self.elements['filter_pattern_library_input_textbox'].type(desc)
        self.elements['filter_pattern_library_input_textbox'].type(Keys.ENTER)

    def input_query(self, payload):
        self.elements['filter_payload_input_textbox'].clear()
        self.elements['filter_payload_input_textbox'].type(payload)
        self.elements['filter_payload_input_textbox'].type(Keys.ENTER)

    def click_button(self, button):
        if button == 'OK':
            element = 'ok_button'
        elif button == 'Cancel':
            element = 'cancel_button'
        elif button == 'Icon_Close':
            element = 'close_icon_button'
        else:
            return None

        self.elements[element].click()

    def check_error_message(self, error_message):
        self.elements[error_message].validate()

    def is_name_input_box_disabled(self):
        return self.elements['filter_name_input_textbox'].is_displayed()

    def is_filter_description_input_textbox_disabled(self):
        return self.elements['filter_description_input_textbox'].is_displayed()

    def is_filter_pattern_library_input_textbox_disabled(self):
        return self.elements['filter_pattern_library_input_textbox'].is_displayed()


