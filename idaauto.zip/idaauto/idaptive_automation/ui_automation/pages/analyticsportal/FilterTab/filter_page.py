from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.analyticsportal.FilterTab.filter_dialog import FilterDialog
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
from idaptive_automation.ui_automation.pages.analyticsportal.FilterTab.pattern_lib_page import PatternLibraryPage
import time


class FilterPage(UIPage):

    name_input_box = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'ant-input'))}
    new_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[contains(.,'New')]"))}
    action_button = {'locator': ElementSetLocator(element_locator=(By.CSS_SELECTOR, ".label-style"))}
    action_delete = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//li[contains(.,'Delete')]"))}
    action_export = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//li[contains(.,'Export')]"))}
    custom_filter_pagination = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[.='Custom Filter']//parent::div//following::ul[contains(@class,"
                  "'ant-pagination ant-table-pagination')]//li"))}

    def __init__(self, driver):
        self.elements = {
            'name_input_box': ElementFactory(driver).define_text_input(self.name_input_box),
            'new_button': ElementFactory(driver).define_element(self.new_button),
            'action_button': ElementFactory(driver).define_element(self.action_button),
            'action_delete': ElementFactory(driver).define_element(self.action_delete),
            'action_export': ElementFactory(driver).define_element(self.action_export),
            'custom_filter_pagination': ElementFactory(driver).define_element_group(self.custom_filter_pagination)
        }

        super().__init__(driver, self.elements)

        self.builtin_filter_table = AnalyticTable(driver, 'Built-in Filter')
        self.custom_filter_table = AnalyticTable(driver, 'Custom Filter')

    def search_name(self, name):
        self.elements['name_input_box'].type(name)
        self.elements['name_input_box'].type(Keys.ENTER)

    def select_delete_button(self):
        self.elements['action_button'].click()
        self.elements['action_delete'].click()

    def select_export_button(self):
        self.elements['action_button'].click()
        self.elements['action_export'].click()

    def add_new_button(self):
        self.elements['new_button'].click()
        return FilterDialog(self.driver)

    def get_table_header(self, table_title):
        if table_title == 'Custom Filter':
            header = self.custom_filter_table.analytic_table_columns
        else:
            header = self.builtin_filter_table.analytic_table_columns

        return header

    def get_table_rows(self, table_title):
        if table_title == 'Custom Filter':
            rows = self.custom_filter_table.analytic_table_rows
        else:
            rows = self.builtin_filter_table.analytic_table_rows

        return rows

    def get_refreshed_rows(self, table_title):
        if table_title == 'Custom Filter':
            rows = self.custom_filter_table.get_refreshed_table_rows()
        else:
            rows = self.builtin_filter_table.get_refreshed_table_rows()

        return rows
