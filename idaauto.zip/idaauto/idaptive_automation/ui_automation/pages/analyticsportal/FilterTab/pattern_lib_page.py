from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.analyticsportal.FilterTab.pattern_lib_dialog import PatternDialog
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
import time


class PatternLibraryPage(UIPage):

    new_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "(//button[@type='button'])[4]"))}
    action_button = {'locator': ElementSetLocator(element_locator=(By.CSS_SELECTOR, ".label-style"))}
    action_delete = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//li[contains(.,'Delete')]"))}
    action_export = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//li[contains(.,'Export')]"))}
    name_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='ant-row'][.//span[.='Built-in Pattern']]/preceding-sibling::div//input[@class='ant-input']"))}

    def __init__(self, driver):
        self.elements = {
            'name_input_box': ElementFactory(driver).define_text_input(self.name_input_box),
            'new_button': ElementFactory(driver).define_text_input(self.new_button),
            'action_button': ElementFactory(driver).define_element(self.action_button),
            'action_delete': ElementFactory(driver).define_element(self.action_delete),
            'action_export': ElementFactory(driver).define_element(self.action_export),
        }

        super().__init__(driver, self.elements)

        self.builtin_pattern_table = AnalyticTable(driver, 'Built-in Pattern')
        self.custom_pattern_table = AnalyticTable(driver, 'Custom Pattern')

    def explorer_page_loaded(self):
        self.elements['explorer_is_loaded'].wait_for_visible(wait_time=10)

    def search_name(self, name):
        self.elements['name_input_box'].type(name)
        self.elements['name_input_box'].type(Keys.ENTER)

    def select_action(self):
        self.elements['pattern_lib_tab'].click()
        self.elements['action_button'].click()

    def click_new_button(self):
        self.elements['new_button'].click()
        return PatternDialog(self.driver)

    def get_table_header(self, table_title):
        if table_title == 'Custom Pattern':
            header = self.custom_pattern_table.analytic_table_columns
        else:
            header = self.builtin_pattern_table.analytic_table_columns

        return header

    def get_table_rows(self, table_title):
        if table_title == 'Custom Pattern':
            rows = self.custom_pattern_table.analytic_table_rows
        else:
            rows = self.builtin_pattern_table.analytic_table_rows

        return rows

    def get_refreshed_rows(self, table_title):
        if table_title == 'Custom Pattern':
            rows = self.custom_pattern_table.get_refreshed_table_rows()
        else:
            rows = self.builtin_pattern_table.get_refreshed_table_rows()

        return rows