from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
import time


class FilterTopNavMenu(UIPage):

    top_nav_menus_locator = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='ant-tabs-nav-wrap']//div[@role='tab']"))}

    def __init__(self, driver):
        self.elements = {
            'top_nav_menus': ElementFactory(driver).define_element_group(self.top_nav_menus_locator)
        }

        super().__init__(driver, self.elements)
        self.top_nav_menus = self.elements['top_nav_menus'].get_elements()

    def nav_menu_click(self, menu_name):
        for menu in self.top_nav_menus:
            if menu.get_text() == menu_name:
                menu.click()
                break
