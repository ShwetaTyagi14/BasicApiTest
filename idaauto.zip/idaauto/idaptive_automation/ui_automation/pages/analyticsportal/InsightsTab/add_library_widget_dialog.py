from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
import time


class AddLibraryWidgetDialog(UIPage):

    search_input_box = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//input[@placeholder='Search...']"))}

    import_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//button[.='Import']"))}

    export_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//button[.='Export']"))}

    def __init__(self, driver):
        self.elements = {
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box),
            'import_button': ElementFactory(driver).define_element(self.import_button),
            'export_button': ElementFactory(driver).define_element(self.export_button),
        }

        super().__init__(driver, self.elements)

    def search_name(self, name):
        self.elements['search_input_box'].clear()
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def get_search_result_row(self, name):
        _row = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f'//div[contains(@class, "item-row")][.="{name}"]'))}

        row_group = ElementFactory(self.driver).define_element_group(_row)
        _elem = row_group.get_elements()
        _row_locator = _elem[0].definition.locator.element_locator[1]
        elements_in_row = _elem[0].find_elements_by_xpath(By.XPATH, f'{_row_locator}//div')
        return elements_in_row
