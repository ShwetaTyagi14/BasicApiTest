from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable


class NewCollectionDialog(UIPage):

    close_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[contains(@class, "ant-modal-close-x")]'))}

    empty_name_error_msg = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[contains(text(), "Name should not be empty.")]'))}

    long_name_error_msg = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[contains(text(), "Name should not be greater than 100")]'))}

    name_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@placeholder="Enter name"]'))}
    cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[.="Cancel"]//parent::button'))}
    save_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[.="Save"]//parent::button'))}

    def __init__(self, driver):
        self.elements = {
            'name_input_box': ElementFactory(driver).define_text_input(self.name_input_box),
            'close_button': ElementFactory(driver).define_element(self.close_button),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'empty_name_error_msg': ElementFactory(driver).define_element(self.empty_name_error_msg),
            'long_name_error_msg': ElementFactory(driver).define_element(self.long_name_error_msg),
        }

        super().__init__(driver, self.elements)

    def input_name(self, name):
        self.elements['name_input_box'].clear()
        self.elements['name_input_box'].type(name)
        self.elements['name_input_box'].type(Keys.ENTER)

    def click_close_button(self):
        self.elements['close_button'].click()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()

    def click_save_button(self):
        self.elements['save_button'].click()

    def check_empty_name_error_msg(self):
        self.elements['empty_name_error_msg'].wait_for_visible()
        return self.elements['empty_name_error_msg'].is_displayed()

    def check_long_name_error_msg(self):
        return self.elements['long_name_error_msg'].is_displayed()
