import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
from idaptive_automation.ui_automation import NewCollectionDialog


class InsightsPage(UIPage):
    page_loading_indicator = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[contains(@class, "ant-spin-dot")]'))}

    search_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//input[@placeholder="Search Name"]'))}

    create_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[.="Create"]//parent::button'))}

    import_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[.="Import"]//parent::button'))}

    create_collection_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//span[.="Create Collection"]//parent::button'))}

    dialog_mask = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//div[contains(@class, "ant-modal-mask")]'))}

    def __init__(self, driver):
        self.elements = {
            'page_loading_indicator': ElementFactory(driver).define_element(self.search_input_box),
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box),
            'create_button': ElementFactory(driver).define_element(self.create_button),
            'import_button': ElementFactory(driver).define_element(self.import_button),
            'create_collection_button': ElementFactory(driver).define_element(self.create_collection_button),
            'dialog_mask': ElementFactory(driver).define_element(self.dialog_mask),
        }

        super().__init__(driver, self.elements)

    def search_name(self, name):
        self.elements['search_input_box'].clear()
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def click_create_button(self):
        self.elements['create_button'].click()

    def click_import_button(self):
        self.elements['import_button'].click()

    def click_create_collection_button(self):
        self.elements['page_loading_indicator'].wait_for_not_visible(wait_time=10)
        self.elements['create_collection_button'].click()
        self.elements['dialog_mask'].wait_for_visible()
        return NewCollectionDialog(self.driver)
