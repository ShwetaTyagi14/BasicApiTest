from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.analyticsportal.InsightsTab.add_library_widget_dialog import AddLibraryWidgetDialog
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
import time


class DashboardPage(UIPage):

    search_input_box = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//input[@placeholder='Search Name']"))}

    create_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//span[.='Create']//parent::button"))}

    import_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//span[.='Import']//parent::button"))}

    create_collection_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//span[.='Create Collection']//parent::button"))}

    builtin_dash_view_switch = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[.='Built-in Dashboards']//following-sibling::div//span[@class='view-switch']"))}

    custom_dash_view_switch = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[.='Custom Dashboards']//following-sibling::div//span[@class='view-switch']"))}

    add_widget_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-plus-circle-o pannel-icon']"))}

    add_widget_from_library = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//p[.='From Library']"))}
    add_widget_from_new_widget = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//p[.='New Widget']"))}

    def __init__(self, driver):
        self.elements = {
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box),
            'create_button': ElementFactory(driver).define_element(self.create_button),
            'import_button': ElementFactory(driver).define_element(self.import_button),
            'create_collection_button': ElementFactory(driver).define_element(self.create_collection_button),
            'builtin_dash_view_switch': ElementFactory(driver).define_element_group(self.builtin_dash_view_switch),
            'custom_dash_view_switch': ElementFactory(driver).define_element_group(self.custom_dash_view_switch),
            'add_widget_button': ElementFactory(driver).define_element(self.add_widget_button),
            'add_widget_from_library': ElementFactory(driver).define_element(self.add_widget_from_library),
            'add_widget_from_new_widget': ElementFactory(driver).define_element(self.add_widget_from_new_widget),
        }

        super().__init__(driver, self.elements)

    def search_name(self, name):
        self.elements['search_input_box'].clear()
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def switch_builtin_dash_view(self, view_option='bars'):

        _elem = self.elements['builtin_dash_view_switch'].get_elements()
        _row_locator = _elem[0].definition.locator.element_locator[1]
        buttons = _elem[0].find_elements_by_xpath(By.XPATH, f'{_row_locator}//i')

        if view_option == 'appstore':
            buttons[0].click()
        else:
            buttons[1].click()

    def switch_custom_dash_view(self, view_option='List'):
        _elem = self.elements['custom_dash_view_switch'].get_elements()
        _row_locator = _elem[0].definition.locator.element_locator[1]
        buttons = _elem[0].find_elements_by_xpath(By.XPATH, f'{_row_locator}//i')

        if view_option == 'appstore':
            buttons[0].click()
        else:
            buttons[1].click()

    def open_dashboard(self, name):
        _action_button_group = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f'//td[.="{name}"]//following-sibling::td[2]'))}

        button_group = ElementFactory(self.driver).define_element_group(_action_button_group)
        _elem = button_group.get_elements()
        _row_locator = _elem[0].definition.locator.element_locator[1]
        buttons = _elem[0].find_elements_by_xpath(By.XPATH, f'{_row_locator}//a')
        buttons[0].click()

    def click_add_widget_from_library(self):
        self.elements['add_widget_button'].click()
        self.driver.hover_over_element((By.XPATH,
                                        self.add_widget_from_new_widget['locator'].element_locator[1]), pause_for=2)
        self.elements['add_widget_from_library'].click()
        dialog = AddLibraryWidgetDialog(self.driver)
        return dialog