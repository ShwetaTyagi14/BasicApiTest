from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ace_text_input import AceTextInput


class ModelMapViewDialog(UIPage):

    dialog_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class = 'ant-modal-title']"))}

    name_input_box = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[@class = 'ant-input ant-input-disabled']"))}

    description_input_box = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, "//textarea[@class = 'ant-input ant-input-disabled']"))}

    definition_combo_box = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='ant-select ant-select-disabled']"))}

    close_icon_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-close close-icon']"))}

    def __init__(self, driver):
        self.elements = {
            'dialog_title': ElementFactory(driver).define_element(self.dialog_title),
            'name_input_box': ElementFactory(driver).define_text_input(self.name_input_box),
            'description_input_box': ElementFactory(driver).define_text_input(self.description_input_box),
            'definition_combo_box': ElementFactory(driver).define_element(self.definition_combo_box),
            'close_icon_button': ElementFactory(driver).define_element(self.close_icon_button),
            'model_payload_input_textbox': AceTextInput(driver),
        }

        super().__init__(driver, self.elements)

    def is_name_input_box_enabled(self):
        return self.elements['name_input_box'].is_enabled()

    def is_description_input_box_enabled(self):
        return self.elements['description_input_box'].is_enabled()

    def is_model_def_combo_box_enabled(self):
        return self.elements['definition_combo_box'].is_enabled()

    def type_payload(self, payload):
        self.elements['model_payload_input_textbox'].type_ace_input(payload)

    def click_close_button(self):
        self.elements['close_icon_button'].click()