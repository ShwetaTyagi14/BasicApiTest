from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
import time


class ModelMapPage(UIPage):

    search_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='ant-row'][.//span[.='Built-in Model Map']]//preceding-sibling::div//input[@placeholder='Search name']"))}

    def __init__(self, driver):
        self.elements = {
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box)
        }

        super().__init__(driver, self.elements)

        self.builtin_model_map_table = AnalyticTable(driver, 'Built-in Model Map')
        self.custom_model_map_table = AnalyticTable(driver, 'Custom Model Map')

    def search_name(self, name):
        self.elements['search_input_box'].clear()
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def get_table_header(self, table_title):
        if table_title == 'Custom Model Map':
            header = self.custom_model_map_table.analytic_table_columns
        else:
            header = self.builtin_model_map_table.analytic_table_columns

        return header

    def get_table_rows(self, table_title):
        if table_title == 'Custom Model Map':
            rows = self.custom_model_map_table.analytic_table_rows
        else:
            rows = self.builtin_model_map_table.analytic_table_rows

        return rows

    def get_refreshed_rows(self, table_title):
        if table_title == 'Custom Model Map':
            rows = self.custom_model_map_table.get_refreshed_table_rows()
        else:
            rows = self.builtin_model_map_table.get_refreshed_table_rows()

        return rows