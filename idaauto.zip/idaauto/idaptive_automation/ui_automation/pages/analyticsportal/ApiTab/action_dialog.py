from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class ApiActionDialog(UIPage):

    yes_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[contains(@class,'ant-popover ant-popover-placement-top')]//button[contains(.,'Yes')]"))}

    no_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[contains(@class,'ant-popover ant-popover-placement-top')]//button[contains(.,'No')]"))}

    message = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[contains(@class,'ant-popover ant-popover-placement-top')]//i//following-sibling::div"))}

    def __init__(self, driver):
        self.elements = {
            'yes_button': ElementFactory(driver).define_element(self.yes_button),
            'no_button': ElementFactory(driver).define_element(self.no_button),
            'message': ElementFactory(driver).define_element(self.message)
        }

        super().__init__(driver, self.elements)

    def click_yes_button(self):
        self.elements['yes_button'].click()

    def click_no_button(self):
        self.elements['no_button'].click()

    def verify_message(self, message):
        assert self.elements['message'].get_text() == message

