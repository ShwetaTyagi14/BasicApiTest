from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
import time


class IntegrationPage(UIPage):

    search_input_box = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'ant-input'))}

    def __init__(self, driver):
        self.elements = {
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box)
        }

        super().__init__(driver, self.elements)

        self.integration_table = AnalyticTable(driver)

    def search_name(self, name):
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def get_table_header(self):
        return self.integration_table.analytic_table_columns

    def get_table_rows(self):
        return self.integration_table.analytic_table_rows

    def get_refreshed_rows(self):
        return self.integration_table.get_refreshed_table_rows()