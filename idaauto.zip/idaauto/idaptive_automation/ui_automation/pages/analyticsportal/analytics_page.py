import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.analyticsportal.ExplorerTab.explorer_page import ExplorerPage


class AnalyticsPortalPage(UIPage):

    explorer_is_loaded = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                               '//*[@id="exploreLoadedDone"][contains(@value,"yes")]'))}
    insights_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Insights')]"))}
    explorer_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Explorer')]"))}
    settings_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Settings')]"))}
    api_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(),'API')]"))}
    integration_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(),'Integration')]"))}
    filter_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(),'Filter')]"))}
    sensor_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(),'Sensor')]"))}
    response_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(text(),'Response')]"))}
    model_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[(text()='Model')]"))}
    threat_intelligence_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                                      "//div[contains(text(),'Threat Intelligence')]"))}
    company_logo = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='company-logo']"))}
    pinned_icon = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//img[@class='pinned']"))}
    uba_icon = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//img[@class='idapIcon']"))}
    popover_grid = {'locator': ElementSetLocator(element_locator=(By.ID, "popoverGrid"))}
    alero_link = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//img[@src='favicons/alero-portal.png']"))}

    def __init__(self, driver):
        self.elements = {
            'explorer_is_loaded': ElementFactory(driver).define_element(self.explorer_is_loaded),
            'insights_tab': ElementFactory(driver).define_element(self.insights_tab),
            'explorer_tab': ElementFactory(driver).define_element(self.explorer_tab),
            'settings_tab': ElementFactory(driver).define_element(self.settings_tab),
            'api_tab': ElementFactory(driver).define_element(self.api_tab),
            'integration_tab': ElementFactory(driver).define_element(self.integration_tab),
            'filter_tab': ElementFactory(driver).define_element(self.filter_tab),
            'sensor_tab': ElementFactory(driver).define_element(self.sensor_tab),
            'response_tab': ElementFactory(driver).define_element(self.response_tab),
            'model_tab': ElementFactory(driver).define_element(self.model_tab),
            'threat_intelligence_tab': ElementFactory(driver).define_element(self.threat_intelligence_tab),
            'company_logo': ElementFactory(driver).define_element(self.company_logo),
            'pinned_icon': ElementFactory(driver).define_element(self.pinned_icon),
            'uba_icon': ElementFactory(driver).define_element(self.uba_icon),
            'popover_grid': ElementFactory(driver).define_element(self.popover_grid),
            'alero_link': ElementFactory(driver).define_element(self.alero_link)
        }

        super().__init__(driver, self.elements)
        self.elements['uba_icon'].wait_for_visible()
        self.mouse_hover_on_nav()

    def click_explorer_tab(self):
        self.elements['explorer_tab'].click()
        ExplorerPage(self.driver).explorer_page_loaded()
        return ExplorerPage(self.driver)

    def mouse_hover_on_nav(self):
        self.driver.hover_over_element((By.XPATH,
                                        self.company_logo['locator'].element_locator[1]), pause_for=2)
        self.elements['pinned_icon'].click()

    def click_alero_link(self):
        self.elements['popover_grid'].click()
        self.elements['alero_link'].wait_for_visible()
        self.elements['alero_link'].click()
        ExplorerPage(self.driver).explorer_page_loaded()
        return ExplorerPage(self.driver)
