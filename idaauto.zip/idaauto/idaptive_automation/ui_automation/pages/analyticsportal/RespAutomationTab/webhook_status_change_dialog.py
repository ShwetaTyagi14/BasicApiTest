from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ace_text_input import AceTextInput


class WebhookStatusChangeDialog(UIPage):

    dialog_message = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[contains(@class, 'ant-popover-message-title')]"))}

    button_yes = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[.='Yes']"))}
    button_no = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button[.='No']"))}

    def __init__(self, driver):
        self.elements = {
            'dialog_message': ElementFactory(driver).define_element(self.dialog_message),
            'button_yes': ElementFactory(driver).define_element(self.button_yes),
            'button_no': ElementFactory(driver).define_element(self.button_no)
        }

        super().__init__(driver, self.elements)

    def get_dialog_message(self):
        self.elements['dialog_message'].wait_for_visible(wait_time=10)
        return self.elements['dialog_message'].get_text()

    def click_yes_button(self):
        self.elements['button_yes'].click()

    def click_no_button(self):
        self.elements['button_no'].click()

    def is_message_displayed(self):
        self.elements['dialog_message'].wait_for_element_to_disappear(wait_time=10)
