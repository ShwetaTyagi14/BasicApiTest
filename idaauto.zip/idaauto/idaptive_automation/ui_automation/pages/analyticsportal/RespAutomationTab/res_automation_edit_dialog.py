from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ace_text_input import AceTextInput


class ResAutomationEditDialog(UIPage):

    dialog_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class = 'ant-modal-title']"))}

    name_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Name:']//input[@type='text']"))}

    desc_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Description:']//input[@type='text']"))}

    event_category_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Trigger Event Category:']"
                  "//following-sibling::div[@class='inline-input']"))}

    event_category__list_items = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Trigger Event Category:']"
                  "//following-sibling::div[@class='inline-input']//li"))}

    trigger_event_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Trigger Event']"
                  "//following-sibling::div[@class='inline-input']"))}

    trigger_event_list_items = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Trigger Event']"
                  "//following-sibling::div[@class='inline-input']//li"))}

    url_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='URL:']//following-sibling::div[@class='inline-input']"
                  "//textarea[@class='ant-input']"))}

    http_method_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Http Method:']"
                  "//following-sibling::div[@class='inline-input']"))}

    http_method_list_items = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Http Method:']"
                  "//following-sibling::div[@class='inline-input']//li"))}

    content_type_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Content Type:']"
                  "//following-sibling::div[@class='inline-input']"))}

    content_type_list_items = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Content Type:']"
                  "//following-sibling::div[@class='inline-input']//li"))}

    auth_header_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//div[.='Authorization Header:']"
                  "//following-sibling::div[@class='inline-input']//textarea[@class='ant-input']"))}

    active_switch = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//span[contains(@class, 'ant-switch')]"))}

    test_connection_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//button[contains(.,'Test Connection')]"))}

    ok_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//button[contains(.,'OK')]"))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//button[contains(.,'Cancel')]"))}

    icon_close_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='webhook-modal']//i[contains(@class, 'close-icon')]"))}

    def __init__(self, driver):
        self.elements = {
            'dialog_title': ElementFactory(driver).define_element(self.dialog_title),
            'name_input_box': ElementFactory(driver).define_text_input(self.name_input_box),
            'desc_input_box': ElementFactory(driver).define_text_input(self.desc_input_box),
            'event_category_input_box': ElementFactory(driver).define_element(self.event_category_input_box),
            'event_category__list_items': ElementFactory(driver).define_element_group(self.event_category__list_items),
            'trigger_event_input_box': ElementFactory(driver).define_element(self.trigger_event_input_box),
            'trigger_event_list_items': ElementFactory(driver).define_element_group(self.trigger_event_list_items),
            'url_input_box': ElementFactory(driver).define_text_input(self.url_input_box),
            'http_method_input_box': ElementFactory(driver).define_element(self.http_method_input_box),
            'http_method_list_items': ElementFactory(driver).define_element_group(self.http_method_list_items),
            'content_type_input_box': ElementFactory(driver).define_element(self.content_type_input_box),
            'content_type_list_items': ElementFactory(driver).define_element_group(self.content_type_list_items),
            'auth_header_input_box': ElementFactory(driver).define_text_input(self.auth_header_input_box),
            'active_switch': ElementFactory(driver).define_element(self.active_switch),
            'test_connection_button': ElementFactory(driver).define_element(self.test_connection_button),
            'ok_button': ElementFactory(driver).define_element(self.ok_button),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button),
            'icon_close_button': ElementFactory(driver).define_element(self.icon_close_button),
            'payload_input_textbox': AceTextInput(driver),
        }

        super().__init__(driver, self.elements)

    def click_event_category_input_box(self):
        self.elements['event_category_input_box'].click()
        return self.elements['event_category__list_items'].get_elements()

    def click_trigger_event_input_box(self):
        self.elements['trigger_event_input_box'].click()
        return self.elements['trigger_event_list_items'].get_elements()

    def click_http_method_input_box(self):
        self.elements['http_method_input_box'].click()
        return self.elements['http_method_list_items'].get_elements()

    def click_content_type_input_box(self):
        self.elements['content_type_input_box'].click()
        return self.elements['content_type_list_items'].get_elements()

    def click_active_toggle_switch(self):
        self.elements['active_switch'].click()

    def click_ok_button(self):
        self.elements['ok_button'].click()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()

    def click_close_button(self):
        self.elements['icon_close_button'].click()