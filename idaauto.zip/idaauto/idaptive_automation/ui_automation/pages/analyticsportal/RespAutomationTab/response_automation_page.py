import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
from idaptive_automation.ui_automation.pages.analyticsportal.RespAutomationTab.webhook_status_change_dialog \
    import WebhookStatusChangeDialog


class ResponseAutomationPage(UIPage):

    search_input_box = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'ant-input'))}
    filter_dropdown = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='ant-select-selection-selected-value']"))}

    filter_items = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='panel-container']//li"))}
    new_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button//span[text()='New ']"))}
    import_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//button//span[text()='Import']"))}

    def __init__(self, driver):
        self.elements = {
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box),
            'filter_dropdown': ElementFactory(driver).define_element(self.filter_dropdown),
            'new_button': ElementFactory(driver).define_element(self.new_button),
            'import_button': ElementFactory(driver).define_element(self.import_button),
            'filter_items': ElementFactory(driver).define_element_group(self.filter_items),
        }

        super().__init__(driver, self.elements)

        self.res_automation_table = AnalyticTable(driver)
        self.status_change_dialog = None

    def search_name(self, name):
        self.elements['search_input_box'].clear()
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def select_filter_dropdown_item(self, item_name):
        time.sleep(5)
        self.elements['filter_dropdown'].click()
        self.elements['filter_items'].wait_for_visible(wait_time=10)
        items = self.elements['filter_items'].get_elements()

        for item in items:
            if item.get_text() == item_name:
                item.click()
                break

    def get_table_header(self):
        return self.res_automation_table.analytic_table_columns

    def get_table_rows(self):
        return self.res_automation_table.analytic_table_rows

    def get_refreshed_rows(self):
        return self.res_automation_table.get_refreshed_table_rows()

    def get_status_change_dialog(self):
        self.status_change_dialog = WebhookStatusChangeDialog(self.driver)
        return self.status_change_dialog
