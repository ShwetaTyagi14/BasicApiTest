from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ant_table import AntTable


class DatasetSaveDialog(UIPage):

    save_button = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                                    "//button[@class='ant-btn ant-btn-primary']"))}


    name_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[contains(@placeholder, 'Input name')]"))}

    def __init__(self, driver):
        self.elements = {
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'name_input_box': ElementFactory(driver).define_text_input(self.name_input_box),
        }
        self.ant_table = AntTable(driver)
        super().__init__(driver, self.elements)

    def save_new_dataset(self, dataset_name):
        self.elements['name_input_box'].type(dataset_name)
        self.elements['save_button'].click()



