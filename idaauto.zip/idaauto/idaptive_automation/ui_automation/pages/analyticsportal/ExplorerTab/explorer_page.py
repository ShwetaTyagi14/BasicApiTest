import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.pages.analyticsportal.ExplorerTab.dataset_dialog import DatasetDialog
from idaptive_automation.ui_automation.pages.analyticsportal.ExplorerTab.view_dialog import ViewDialog
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.analyticsportal.ExplorerTab.dataset_save_dialog import DatasetSaveDialog
from idaptive_automation.ui_automation.pages.analyticsportal.ExplorerTab.query_dialog import QueryDialog
from idaptive_automation.ui_automation.pages.analyticsportal.ExplorerTab.dataset_manage_page import DatasetManagePage


class ExplorerPage(UIPage):

    explorer_is_loaded = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//*[@id="exploreLoadedDone"][contains(@value,"yes")]'))}

    sql_input_box = {'locator': ElementSetLocator(element_locator=(By.CSS_SELECTOR, '#sql-search-textarea'))}

    calendar_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//span[@class='ant-calendar-picker']"))}

    share_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-qrcode pannel-icon']"))}

    pdf_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-hdd pannel-icon']"))}

    reset_filters_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-reload pannel-icon']"))}

    current_dataset_name = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//a[text()="Dataset"]/parent::b/following-sibling::span'))}

    dataset_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-hdd pannel-icon']"))}

    dataset_select = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//div[@class="dataset-mgmt-pop"]//p[contains(text(),"Select")]'))}

    dataset_manage = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//div[@class="dataset-mgmt-pop"]//p[contains(text(),"Manage")]'))}

    dataset_save_as = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, '//div[@class="dataset-mgmt-pop"]//p[contains(text(),"Save As...")]'))}

    query_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-export pannel-icon']"))}

    view_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-eye-o pannel-icon']"))}

    view_open_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[@class='ant-popover-inner-content']//p[contains(text(),'Open')]"))}

    add_widget_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-plus-circle-o pannel-icon']"))}

    def __init__(self, driver):
        self.elements = {
            'explorer_is_loaded': ElementFactory(driver).define_element(self.explorer_is_loaded),
            'sql_input_box': ElementFactory(driver).define_text_input(self.sql_input_box),
            'calendar_button': ElementFactory(driver).define_element(self.calendar_button),
            'share_button': ElementFactory(driver).define_element(self.share_button),
            'pdf_button': ElementFactory(driver).define_element(self.pdf_button),
            'reset_filters_button': ElementFactory(driver).define_element(self.reset_filters_button),
            'current_dataset_name': ElementFactory(driver).define_element(self.current_dataset_name),
            'dataset_button': ElementFactory(driver).define_element(self.dataset_button),
            'dataset_select': ElementFactory(driver).define_element(self.dataset_select),
            'dataset_manage': ElementFactory(driver).define_element(self.dataset_manage),
            'dataset_save_as': ElementFactory(driver).define_element(self.dataset_save_as),
            'query_button': ElementFactory(driver).define_element(self.query_button),
            'view_button': ElementFactory(driver).define_element(self.view_button),
            'view_open_button': ElementFactory(driver).define_element(self.view_open_button),
            'add_widget_button': ElementFactory(driver).define_element(self.add_widget_button),
        }

        super().__init__(driver, self.elements)

    def explorer_page_loaded(self):
        self.elements['explorer_is_loaded'].wait_for_visible(wait_time=10)

    def search_query(self, query):
        self.elements['sql_input_box'].clear()
        self.elements['sql_input_box'].type(query)
        self.elements['sql_input_box'].type(Keys.ENTER)

    def click_view_open_button(self):
        self.elements['view_button'].click()
        self.elements['view_open_button'].click()
        return ViewDialog(self.driver)

    def click_select_button(self):
        self.elements['dataset_button'].click()
        self.elements['dataset_select'].click()
        return DatasetDialog(self.driver)

    def click_dataset_manage_button(self):
        self.elements['dataset_button'].click()
        self.elements['dataset_manage'].wait_for_visible(wait_time=10)
        self.elements['dataset_manage'].click()
        return DatasetManagePage(self.driver)

    def click_save_as_button(self):
        self.elements['dataset_button'].click()
        self.elements['dataset_save_as'].click()
        return DatasetSaveDialog(self.driver)

    def get_dataset_name(self):
        return self.elements['current_dataset_name'].get_text()

    def click_query_open_button(self):
        self.elements['query_button'].click()
        self.elements['view_open_button'].click()
        return QueryDialog(self.driver)

    def check_column_error_message(self, column_name, expected=True):
        column_existence_error_msg = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f'//span[contains(text(),"{column_name}")]'))}

        my_element = ElementFactory(self.driver).define_element(column_existence_error_msg)

        if my_element.is_displayed() == expected:
            result = True
        else:
            result = False

        return result
