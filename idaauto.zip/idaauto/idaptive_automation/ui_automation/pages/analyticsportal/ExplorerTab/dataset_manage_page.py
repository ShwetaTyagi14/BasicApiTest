from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.analytics_table import AnalyticTable
import time


class DatasetManagePage(UIPage):

    search_input_box = {'locator': ElementSetLocator(
        element_locator=(
            By.XPATH, "//div[@class='ant-row']//span[@class='ant-input-search ant-input-affix-wrapper']//input"))}

    custom_dataset_pagination = {'locator': ElementSetLocator(
        element_locator=(
            By.XPATH, "//div[.='Custom Dataset']//parent::div//following::ul[contains(@class, 'ant-pagination ant-table-pagination')]//li"))}

    new_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[.='New']//parent::button"))}
    action_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[.='Action ']//parent::button"))}
    import_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[.='Import']//parent::button"))}

    def __init__(self, driver):
        self.elements = {
            'search_input_box': ElementFactory(driver).define_text_input(self.search_input_box),
            'custom_dataset_pagination': ElementFactory(driver).define_element_group(self.custom_dataset_pagination),
            'new_button': ElementFactory(driver).define_element(self.new_button),
            'action_button': ElementFactory(driver).define_element(self.action_button),
            'import_button': ElementFactory(driver).define_element(self.import_button)
        }

        super().__init__(driver, self.elements)

        self.builtin_dataset_table = AnalyticTable(driver, 'Built-in Dataset')
        self.custom_dataset_table = AnalyticTable(driver, 'Custom Dataset')

    def search_name(self, name):
        self.elements['search_input_box'].clear()
        self.elements['search_input_box'].type(name)
        self.elements['search_input_box'].type(Keys.ENTER)

    def click_new_button(self):
        self.elements['new_button'].click()

    def click_action_button(self):
        self.elements['action_button'].click()

    def click_import_button(self):
        self.elements['import_button'].click()

    def get_table_header(self, table_title):
        if table_title == 'Custom Dataset':
            header = self.custom_dataset_table.analytic_table_columns
        else:
            header = self.builtin_dataset_table.analytic_table_columns

        return header

    def get_table_rows(self, table_title):
        if table_title == 'Custom Dataset':
            rows = self.custom_dataset_table.analytic_table_rows
        else:
            rows = self.builtin_dataset_table.analytic_table_rows

        return rows

    def get_refreshed_rows(self, table_title):
        if table_title == 'Custom Dataset':
            rows = self.custom_dataset_table.get_refreshed_table_rows()
        else:
            rows = self.builtin_dataset_table.get_refreshed_table_rows()

        return rows
