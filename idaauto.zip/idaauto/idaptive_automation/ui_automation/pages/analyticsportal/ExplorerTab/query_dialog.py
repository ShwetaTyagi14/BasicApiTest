from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.ant_table import AntTable
from idaptive_automation.ui_automation.uielements.analytics_expandable_table import AnalyticExpandableTable


class QueryDialog(UIPage):
    search_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[@class='ant-input ant-input-sm modal-search-query']"))}

    close_icon_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//i[@class='anticon anticon-close close-icon']"))}

    def __init__(self, driver):
        self.elements = {
            'search_box': ElementFactory(driver).define_text_input(self.search_box),
            'close_icon_button': ElementFactory(driver).define_element(self.close_icon_button),
        }
        self.ant_table = AntTable(driver)
        self.builtin_queries_table = AnalyticExpandableTable(driver, 'Built-in Queries')
        self.custom_queries_table = AnalyticExpandableTable(driver, 'Custom Queries')
        super().__init__(driver, self.elements)

    def open_query(self, query_name):
        self.ant_table.get_row_button_element(row_name=query_name, button_name='Open').click()

    def export_query(self, query_name):
        self.ant_table.get_row_button_element(row_name=query_name, button_name='Export').click()

    def delete_query(self, query_name):
        self.ant_table.get_row_button_element(row_name=query_name, button_name='Delete').click()

    def click_close_button(self):
        self.elements['close_icon_button'].click()

    def search_name(self, name):
        self.elements['search_box'].type(name)
        self.elements['search_box'].type(Keys.ENTER)

    def get_table_rows(self, table_title):
        if table_title == 'Custom Queries':
            rows = self.custom_queries_table.analytic_table_rows
        else:
            rows = self.builtin_queries_table.analytic_table_rows

        return rows

    def get_refreshed_rows(self, table_title):
        if table_title == 'Custom Queries':
            rows = self.custom_queries_table.get_refreshed_table_rows()
        else:
            rows = self.builtin_queries_table.get_refreshed_table_rows()

        return rows
