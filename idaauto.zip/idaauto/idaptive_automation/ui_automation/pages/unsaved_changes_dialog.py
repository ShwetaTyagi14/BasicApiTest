from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class UnsavedChangesDialog(UIPage):
    yes_button = {'locator':
                    ElementSetLocator(element_locator=
                                     (By.XPATH,f'//a[@buttontext="Yes" and @itemid="yes"]')),
                  'inner_text': 'Yes'}

    no_button = {'locator':
                    ElementSetLocator(element_locator=
                                     (By.XPATH,f'//a[@buttontext="No" and @itemid="discard"]')),
                 'inner_text': 'No'}

    cancel_button = {'locator':
                        ElementSetLocator(element_locator=
                                        (By.XPATH, f'//a[@buttontext="Cancel" and @itemid="cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self,driver):
        self.driver = driver
        self.elements = {
            'yes' : UIElement(ElementDefinition(driver, **UnsavedChangesDialog.yes_button)),
            'no' : UIElement(ElementDefinition(driver, **UnsavedChangesDialog.no_button)),
            'cancel' : UIElement(ElementDefinition(driver, **UnsavedChangesDialog.cancel_button))
        }

        super().__init__(self.driver,self.elements)

    def save_changes(self):
        self.elements['yes'].click()

    def discard_changes(self):
        self.elements['no'].click()

    def cancel_dialog(self):
        self.elements['cancel'].click()
