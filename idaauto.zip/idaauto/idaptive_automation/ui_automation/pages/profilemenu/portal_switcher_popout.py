from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
import time


class PortalSwitcherPopout(UIPage):
    portal_picker_button = {
        'locator':
        ElementSetLocator(
            element_locator=
            (By.XPATH, '//a[@itemid="portalPicker"]'))
    }
    user_portal = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="User Portal"]'))
    }
    admin_portal = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Admin Portal"]'))
    }
    alero_portal = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Remote Access"]/..'))
    }
    alero_portal_launch_anchor = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Remote Access"]//ancestor::a'))
    }
    analytics_portal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[.="User Behavior Analytics"]//ancestor::a'))
    }
    portal_buttons = {'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Admin Portal"]//ancestor::div[1] | //span[.="User Portal"]//ancestor::div[1]'))}

    sws_portal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Secure Web Session Portal"]/..'))
    }

    sws_portal_launch_anchor = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Secure Web Session Portal"]//ancestor::a'))
    }

    def __init__(self, driver, elements=None):
        elems = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.portal_picker_button),
            'portal_picker_button': factory(driver).define_element(self.portal_picker_button),
            'user_portal': factory(driver).define_element(self.user_portal),
            'admin_portal': factory(driver).define_element(self.admin_portal),
            'alero_portal': factory(driver).define_element(self.alero_portal),
            'alero_portal_launch_anchor': factory(driver).define_element(self.alero_portal_launch_anchor),
            'analytics_portal': factory(driver).define_element(self.analytics_portal),
            'portal_buttons': factory(driver).define_element(self.portal_buttons),
            'sws_portal': factory(driver).define_element(self.sws_portal),
            'sws_portal_launch_anchor': factory(driver).define_element(self.sws_portal_launch_anchor)
        }

        self.elements = elems
        super().__init__(driver, self.elements)

    def click_portal_picker(self):
        self.elements['portal_picker_button'].wait_for_visible()
        self.elements['portal_picker_button'].click()
        time.sleep(.25)

    def switch_to_admin_portal(self):
        self.click_portal_picker()
        self.elements['admin_portal'].wait_for_visible()
        self.elements['admin_portal'].click()
        return self

    def switch_to_user_portal(self):
        self.click_portal_picker()
        self.elements['user_portal'].wait_for_visible()
        self.elements['user_portal'].click()
        return self

    def switch_to_alero_portal(self):
        self.click_portal_picker()
        self.elements['alero_portal'].wait_for_visible()
        self.elements['alero_portal'].click()
        return self

    def switch_to_sws_portal(self):
        self.click_portal_picker()
        self.elements['sws_portal'].wait_for_visible()
        self.elements['sws_portal'].click()
        return self

    def get_alero_portal_launch_url(self):
        self.click_portal_picker()
        self.elements['alero_portal_launch_anchor'].wait_for_visible()
        url = self.elements['alero_portal_launch_anchor'].get_attribute_value("href")
        self.click_portal_picker()
        return url

    def get_sws_portal_launch_url(self):
        self.click_portal_picker()
        self.elements['sws_portal_launch_anchor'].wait_for_visible()
        url = self.elements['sws_portal_launch_anchor'].get_attribute_value("href")
        self.click_portal_picker()
        return url

    def switch_to_analytics_portal(self):
        self.click_portal_picker()
        self.elements['analytics_portal'].wait_for_visible()
        self.elements['analytics_portal'].click()
        return self

    def get_switcher_options(self):
        self.click_portal_picker()
        options = self.elements['portal_buttons'].get_text().split('\n')
        for items in options:
            if len(items) <= 2:
                options.remove(items)
        self.click_portal_picker()
        self.elements['portal_buttons'].wait_for_not_visible()
        return options

    def get_alero_tab_current_url(self):
        self.driver.switch_to_active_tab()
        url = self.driver.current_url
        return url

    def get_sws_tab_current_url(self):
        self.driver.switch_to_active_tab()
        url = self.driver.current_url
        return url
