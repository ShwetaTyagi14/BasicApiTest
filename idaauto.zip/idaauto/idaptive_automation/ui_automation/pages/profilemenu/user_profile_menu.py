from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UserProfileMenu(UIPage):
    profile_button = {
        'locator':
        ElementSetLocator(
            element_locator=
            (By.XPATH, '//a[contains(@class,"username-dropdown-menu") and contains(@id,"splitbutton")]'))
    }
    about = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="About"]'))
    }
    reload = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="Reload Rights"]'))
    }
    sign_out_option = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[.="Sign Out"]'))
    }
    support = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[.="Support"]'))
    }
    portal_picker_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="portalPicker"]'))
    }
    admin_portal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//span[.="Admin Portal"]'))
    }

    def __init__(self, driver, elements=None):
        elems = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.profile_button),
            'portal_picker_button': factory(driver).define_element(self.portal_picker_button),
            'profile': factory(driver).define_element(self.profile_button),
            'about': factory(driver).define_element(self.about),
            'reload': factory(driver).define_element(self.reload),
            'admin_portal': factory(driver).define_element(self.admin_portal),
            'sign_out': factory(driver).define_element(self.sign_out_option),
            'support': factory(driver).define_element(self.support)
        }

        if elements is not None:
            del elems['admin_portal']
            elements.update(elems)
            self.elements = elements
        else:
            self.elements = elems

        super().__init__(driver, self.elements)

    def click_about(self):
        self.elements['profile'].click()
        self.elements['about'].click()

    def reload_rights(self):
        self.elements['profile'].click()
        self.elements['reload'].click()

    def click_support(self):
        self.elements['profile'].click()
        self.elements['support'].click()

    def switch_to_admin_portal(self):
        self.elements['portal_picker_button'].click()
        self.elements['admin_portal'].click()
        return self

    def sign_out(self):
        self.elements['profile'].click()
        self.elements['sign_out'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def get_displayed_username(self):
        return self.elements['profile'].get_attribute_value('buttontext')

    def validate_all_elements(self):
        self.elements['profile'].click()

        super().validate_all_elements()
        return self

    def click_profile(self):
        self.elements['profile'].click()
