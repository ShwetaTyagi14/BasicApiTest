from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import  ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AboutPage(UIPage):
    base_xpath = '//div[@class="x-window modal-window null x-layer x-ltr x-window-modal x-closable x-window-closable x-window-modal-closable x-border-box"]'

    close = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'{base_xpath}//a[@buttontext="Close"]'))
    }
    copyright = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'{base_xpath}//a[@buttontext="Close"]/following-sibling::div[1]'))
    }
    terms_of_use = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'{base_xpath}//a[@buttontext="Close"]/following-sibling::div[2]'))
    }
    privacy_policy = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'{base_xpath}//a[@buttontext="Close"]/following-sibling::div[3]'))
    }
    large_logo = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'{base_xpath}//img[contains(@src,"cyberark-logo") and contains(@style, "height: 48px")]')),
        'supports_validation': False
    }
    small_logo = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'{base_xpath}//img[contains(@src,"cyberark-logo") and contains(@style, "height:20px")]')),
        'supports_validation': False
    }

    def __init__(self, driver, version, region, tenant):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.close),
            'version': ElementFactory(driver).define_element({
                    'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'{self.base_xpath}//td[.="{version}"]'))
                }),
            'region': ElementFactory(driver).define_element({
                    'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'{self.base_xpath}//td[.="{region}"]'))
                }),
            'tenant': ElementFactory(driver).define_element({
                    'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'{self.base_xpath}//td[.="{tenant.upper()}"]'))
                }),
            'close': ElementFactory(driver).define_element(self.close),
            'copyright': ElementFactory(driver).define_element(self.copyright),
            'terms': ElementFactory(driver).define_element(self.terms_of_use),
            'privacy': ElementFactory(driver).define_element(self.privacy_policy),
            'large_logo': ElementFactory(driver).define_element(self.large_logo),
            'small_logo': ElementFactory(driver).define_element(self.small_logo)
        }
        super().__init__(driver, self.elements)
