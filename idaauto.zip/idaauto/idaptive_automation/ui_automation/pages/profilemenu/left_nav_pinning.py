from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class LeftNavPinning(UIPage):
    portal_picker_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="portalPicker"]'))
    }

    pin_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"navigation-container")][1]//a[contains(@class,"pin-button")]'))
    }

    left_nav_panel = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"navigation-container")][1]'))
    }

    online_help = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"navigation-container")][1]//a[@buttontext="Online help"]'))
    }

    floating_nav = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@itemid,"floatingNavigationContainer")]'))
    }

    def __init__(self, driver, elements=None):
        elems = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.portal_picker_button),
            'portal_picker_button': factory(driver).define_element(self.portal_picker_button),
            'pin_button': factory(driver).define_element(self.pin_button),
            'left_nav_panel': factory(driver).define_expandable_element(self.left_nav_panel),
            'online_help': factory(driver).define_element(self.online_help),
            'floating_nav': factory(driver).define_expandable_element(self.floating_nav)
        }

        self.elements = elems
        super().__init__(driver, self.elements)

    def get_left_nav_size(self):
        style_val = self.elements['left_nav_panel'].get_attribute_value("style")[:-1]
        style_val_dict = dict(x.split(": ") for x in style_val.split(";"))
        return style_val_dict

    def click_pin_button(self):
        self.elements['pin_button'].wait_for_visible()
        self.elements['pin_button'].click()

    def is_pin_button_clicked(self):
        style_val = self.elements['pin_button'].get_attribute_value("style")[:-1]
        style_val_dict = dict(x.split(": ") for x in style_val.split(";"))
        is_pinned = True
        if 'display' in style_val_dict and style_val_dict['display'] == 'none':
            is_pinned = False
        return is_pinned

    def set_to_pinned(self):
        pinned_val = self.is_pin_button_clicked()
        if not pinned_val:
            self.driver.wait_for_visible_element((By.XPATH, '//div[contains(@class,"navigation-container")][1]'))
            self.driver.hover_over_element(by=(By.XPATH, '//div[contains(@class,"navigation-container")][1]'))
            self.click_pin_button()

    def set_to_unpinned(self):
        pinned_val = self.is_pin_button_clicked()
        if pinned_val:
            self.click_pin_button()

    def expand_pinned_nav(self):
        self.driver.wait_for_visible_element((By.XPATH, '//div[contains(@class,"navigation-container")][1]//a[@buttontext="Online help"]'))
        self.driver.hover_over_element(by=(By.XPATH, '//div[contains(@class,"navigation-container")][1]//a[@buttontext="Online help"]'))

    def is_floating_nav_displayed(self):
        try:
            style_val = self.elements['floating_nav'].get_attribute_value("style")[:-1]
            style_val_dict = dict(x.split(": ") for x in style_val.split(";"))
            is_pinned = True
            return is_pinned
        except AttributeError:
            return False
