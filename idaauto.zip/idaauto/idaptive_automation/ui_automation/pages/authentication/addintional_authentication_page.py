from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory


class AdditionalAuthenticationPage(UIPage):
    additional_auth = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@id="mechanismSelectionForm"]//div[.="Additional authentication required to continue with this action."]'))
    }

    auth_method_toggle = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                      '//div[@id="mechanismSelectionForm"]//span[@class="trigger-icon"]'))
    }

    mfa_question = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//label[@name="mfaAnswerLabel"]'))
    }

    mfa_answer = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//input[@name="mfaAnswer"]'))
    }

    mfa_form_next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//button[@type="submit" and .="Next"]'))
    }

    mfa_challenge_failed = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@class="error-message" and .="Authentication (login or challenge) has failed. Please try again or contact your system administrator."]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.additional_auth),
            'auth_method_toggle': ElementFactory(driver).define_element(self.auth_method_toggle),
            'mfa_question': ElementFactory(driver).define_element(self.mfa_question),
            'mfa_answer': ElementFactory(driver).define_text_input(self.mfa_answer),
            'mfa_next': ElementFactory(driver).define_element(self.mfa_form_next),
            'mfa_challenge_failed': ElementFactory(driver).define_element(self.mfa_challenge_failed),
        }

        super().__init__(driver, self.elements)

    def open_mfa_select_box(self):
        self.elements['auth_method_toggle'].click()

    def select_mfa_challenge(self, challenge):
        elem = ElementFactory(self.driver).define_element(
            {'locator':
                ElementSetLocator(
                    element_locator=(By.XPATH, f'//div[@id="mechanismSelectionForm"]//span[.="{challenge}"]'))})
        elem.click()
        return self

    def get_mfa_question(self):
        return self.elements['mfa_question'].get_text()

    def set_mfa_response(self, response):
        self.elements['mfa_answer'].clear().type(response)

    def click_mfa_next(self):
        self.elements['mfa_next'].click()

    def answer_mfa_challenge(self, challenge, responses):
        self.open_mfa_select_box()
        self.select_mfa_challenge(challenge)
        question = self.get_mfa_question()
        response = [r for r in responses if r['question'] == question]
        assert len(response) != 0, f'No response found for question {question}'
        self.set_mfa_response(response[0]['answer'])
        self.click_mfa_next()
        return self
