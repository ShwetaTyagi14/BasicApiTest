from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory


class SelectAuthenticationMethodPage(UIPage):
    loaded = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                      '//div[@id="mechanismSelectionForm"]//div[.="Additional authentication required to continue with this action."]'))
    }

    loading_mask = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//div[@id="mechanismSelectionForm" and @class="login-form masked"]')),
                    'supports_validation': False}

    mfa_select_toggle = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//span[@class="trigger-icon"]'))
    }

    next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//button[@type="submit" and .="Next"]'))
    }

    def __init__(self, driver, challenges):
        self.challenges = dict([(challenge,
                                 ElementFactory(driver).define_element(
                                     {'locator':
                                      ElementSetLocator(
                                         element_locator=(By.XPATH, f'//div[@id="mechanismSelectionForm"]//span[.="{challenge}"]'))}))
                                for challenge in challenges])
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded),
            'mfa_select_toggle': ElementFactory(driver).define_element(self.mfa_select_toggle),
            'loading_mask': ElementFactory(driver).define_element(self.loading_mask),
            'next': ElementFactory(driver).define_element(self.next),
        }
        super().__init__(driver, self.elements)

    def open_mfa_select_box(self):
        self.elements['mfa_select_toggle'].click()

    def select_mfa_challenge(self, challenge):
        self.wait_for_page_to_load(wait_for_ready=False)
        self.open_mfa_select_box()
        self.challenges[challenge].click()
        self.elements['next'].click()
        return self
