from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class PasswordLoginPage(UIPage):
    loaded = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//div[@class="username-display"]'))
    }
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//div[@class="form-title" and .="Authentication"]'))
    }
    password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//input[@name="answer" and @type="password"]'))
    }
    forgot = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//button[.="Forgot password?"]'))
    }
    remember_me = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//input[@name="rememberMe" and @type="checkbox"]'))
    }
    start_over = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//button[@type="button" and .="Start Over"]'))
    }
    next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordForm"]//button[@type="submit" and .="Next"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded),
            'header': ElementFactory(driver).define_element(self.header),
            'password': ElementFactory(driver).define_text_input(self.password),
            'forgot': ElementFactory(driver).define_element(self.forgot),
            'remember_me': ElementFactory(driver).define_element(self.remember_me),
            'start_over': ElementFactory(driver).define_element(self.start_over),
            'next': ElementFactory(driver).define_element(self.next)
        }

        super().__init__(driver, self.elements)

    def is_forgot_password_link_displayed(self):
        return self.elements['forgot'].is_displayed()

    def set_password(self, password):
        self.wait_for_page_to_load()
        self.elements['password'].clear().type(password)
        return self

    def advance(self):
        self.elements['next'].click()
