from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UserNameLoginPage(UIPage):
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="usernameForm"]//div[@class="form-title" and .="Sign In"]'))
    }
    username = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="usernameForm"]//input[@name="username"]'))
    }
    next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="usernameForm"]//button[@type="submit" and .="Next"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            'username': ElementFactory(driver).define_text_input(self.username),
            'next': ElementFactory(driver).define_element(self.next)
        }

        super().__init__(driver, self.elements)

    def set_username(self, password):
        self.wait_for_page_to_load()
        self.elements['username'].clear().type(password)
        return self

    def advance(self):
        self.elements['next'].click()
