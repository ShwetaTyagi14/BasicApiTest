from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class EnterAuthenticationCodePage(UIPage):
    loaded = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//button[@type="submit" and .="Next"]'))
    }

    next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="answerInputForm"]//button[@type="submit"]'))
    }

    mfa_answer = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="answerInputForm"]//input[@name="answer"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded),
            'mfa_next': ElementFactory(driver).define_element(self.next),
            'mfa_answer': ElementFactory(driver).define_text_input(self.mfa_answer)
        }

        super().__init__(driver, self.elements)

    def set_mfa_response(self, response):
        self.elements['mfa_answer'].type(response)

    def click_next(self):
        self.elements['mfa_next'].click()

    def answer_mfa_challenge(self, response):
        self.set_mfa_response(response)
        self.click_next()
