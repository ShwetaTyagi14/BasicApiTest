from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AdditionalAuthRequiredPage(UIPage):
    def __init__(self, driver):
        self.elements = {

        }

        super().__init__(driver, self.elements)
