from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory


class MfaAuthFailedPage(UIPage):

    mfa_challenge_failed = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@class="error-message" and .="Authentication (login or challenge) has failed. Please try again or contact your system administrator."]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.mfa_challenge_failed)
        }

        super().__init__(driver, self.elements)
