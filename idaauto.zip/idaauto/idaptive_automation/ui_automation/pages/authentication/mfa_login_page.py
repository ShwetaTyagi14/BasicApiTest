from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from selenium.webdriver.common.action_chains import ActionChains

class MfaAuthenticationPage(UIPage):
    additional_auth = {
        'locator': ElementSetLocator(element_locator=(By.ID, ''))
    }

    authentication = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                              '//div[@id="passwordForm"]//div[@class="form-title" and .="Authentication"]'))
    }

    auth_method = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                      '//div[@id="passwordAndMechanismForm"]//input[@class="combo-input"]'))
    }

    password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordAndMechanismForm"]//label[.="Password"]/following-sibling::input[@name="answer" and @type="password"]'))
    }

    password_form_next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordAndMechanismForm"]//button[@type="submit" and .="Next"]'))
    }

    mfa_form_next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordAndMechanismForm"]//button[@type="submit" and .="Next"]'))
    }

    mfa_answer = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordAndMechanismForm"]//input[@name="mfaAnswer"]'))
    }

    mfa_answer_v2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//input[@name="mfaAnswer"]'))
    }

    mfa_challenge_failed = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@class="error-message" and .="Authentication (login or challenge) has failed. Please try again or contact your system administrator."]'))
    }

    mfa_question = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordAndMechanismForm"]//label[@name="mfaAnswerLabel"]'))
    }

    mfa_select_toggle = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="passwordAndMechanismForm"]//span[@class="trigger-icon"]'))
    }

    authentication_method_combobox = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@id="mechanismSelectionForm"]//input[@class="combo-input"]'))
    }
    
    security_question_option = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="combo-list"]//span[text()="Security Question"]'))
    }

    password_option = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="combo-list"]//span[text()="Password"]'))
    }

    selected_mechanism = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="combo-list"]//span[contains(@class, "selected")]'))
    }

    security_question_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//label[text()="Case number"]/following-sibling::input'))
    }

    sms_option = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="combo-list"]//span[contains(text(), "Text Message")]'))
    }

    sms_form_next = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@id="mechanismSelectionForm"]//button[@type="submit" and .="Next"]'))
    }
    mfa_input = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[@id="answerInputForm"]//input[@name="answer"]'))
    }
    
    mfa_next_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[@id="answerInputForm"]//button[.="Next"]'))
    }
    
    mechanism_selection_start_over_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, 
                                                '//div[@id="mechanismSelectionForm"]//button[.="Start Over"]'))
    }

    answer_input_start_over_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, 
                                                '//div[@id="answerInputForm"]//button[.="Start Over"]'))
    }

    email_option = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="combo-list"]//span[contains(text(), "Email")]'))
    }

    def __init__(self, driver, challenges):
        self.challenges = dict([(challenge,
                                 factory(driver).define_element(
                                     {'locator':
                                      ElementSetLocator(
                                         element_locator=(By.XPATH, f'//div[@id="passwordAndMechanismForm"]//span[.="{challenge}"]'))}))
                                for challenge in challenges])
        self.elements = {
            'loaded': factory(driver).define_element(self.auth_method),
            'authentication': factory(driver).define_element(self.authentication),
            'auth_method': factory(driver).define_element(self.auth_method),
            'password': factory(driver).define_text_input(self.password),
            'password_next': factory(driver).define_element(self.password_form_next),
            'mfa_next': factory(driver).define_element(self.mfa_form_next),
            'mfa_question': factory(driver).define_element(self.mfa_question),
            'mfa_answer': factory(driver).define_text_input(self.mfa_answer),
            'mfa_challenge_failed': factory(driver).define_element(self.mfa_challenge_failed),
            'mfa_select_toggle': factory(driver).define_element(self.mfa_select_toggle),
            'authentication_method_combobox': factory(driver).define_element(self.authentication_method_combobox),
            'security_question_option': factory(driver).define_element(self.security_question_option),
            'security_question_input': factory(driver).define_text_input(self.security_question_input),
            'password_option': factory(driver).define_element(self.password_option),
            'selected_mechanism': factory(driver).define_element(self.selected_mechanism),
            'sms_option': factory(driver).define_element(self.sms_option),
            'sms_form_next': factory(driver).define_element(self.sms_form_next),
            'mfa_input': factory(driver).define_element(self.mfa_input),
            'mfa_next_button': factory(driver).define_element(self.mfa_next_button),
            'mechanism_selection_start_over_button': factory(driver).define_element(self.mechanism_selection_start_over_button),
            'answer_input_start_over_button': factory(driver).define_element(self.answer_input_start_over_button),
            'email_option': factory(driver).define_element(self.email_option),
            'mfa_answer_v2': factory(driver).define_text_input(self.mfa_answer_v2),
        }

        super().__init__(driver, self.elements)

    def wait_for_page_to_load(self, wait_time=UIPage.SHORT_DELAY, required=True, wait_for_ready=False):
        super().wait_for_page_to_load(wait_time=wait_time, required=required, wait_for_ready=wait_for_ready)

    def set_password(self, password):
        self.elements['password'].type(password)
        return self

    def open_mfa_select_box(self):
        self.elements['mfa_select_toggle'].click()

    def select_mfa_challenge(self, challenge):
        self.challenges[challenge].click()
        return self

    def get_mfa_question(self):
        return self.elements['mfa_question'].get_text()

    def set_mfa_response(self, response):
        self.elements['mfa_answer'].type(response)

    def set_mfa_response_v2(self, response):
        self.elements['mfa_answer_v2'].wait_for_visible()
        self.elements['mfa_answer_v2'].type(response)
        self.elements['sms_form_next'].click()

    def verify_challenge_failed(self):
        assert self.elements['mfa_challenge_failed'].get_element() is not None

    def click_password_next(self):
        self.elements['password_next'].click()

    def click_mfa_next(self):
        self.elements['mfa_next'].click()

    def login(self, password, challenge, responses):
        self.set_password(password)
        return self.answer_security_question(challenge, responses)

    def answer_security_question(self, challenge, responses):
        self.open_mfa_select_box()
        self.select_mfa_challenge(challenge)
        question = self.get_mfa_question()
        response = [r for r in responses if r['question'] == question]
        assert len(response) != 0, f'No response found for question {question}'
        self.set_mfa_response(response[0]['answer'])
        self.click_mfa_next()
        return self

    def select_security_question(self):
        self.elements['authentication_method_combobox'].click()
        self.elements['security_question_option'].click()
        return self
    
    def select_password(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['authentication_method_combobox'].click()
        self.elements['password_option'].click()
        return self
    
    def get_selected_mechanism(self):
        self.elements['authentication_method_combobox'].click()
        text = self.elements['selected_mechanism'].get_text()
        self.elements['authentication_method_combobox'].click()
        return text
    
    def select_sms_mechanism(self):
        self.elements['authentication_method_combobox'].click()
        self.elements['sms_option'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['sms_form_next'].click()
        return self
    
    def set_sms_anwser(self, answer):
        self.elements['mfa_input'].click()
        # Unable to type
        actions = ActionChains(self.driver)
        actions.send_keys(answer)
        actions.perform()
        self.elements['mfa_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self
    
    def click_answer_input_start_over_button(self):
        self.elements['answer_input_start_over_button'].click()

    def click_mechanism_selection_start_over_button(self):
        self.elements['mechanism_selection_start_over_button'].click()

    def is_start_over_button_present(self):
        return self.elements['answer_input_start_over_button'] != None

    def select_email_mechanism(self):
        self.elements['authentication_method_combobox'].click()
        self.elements['email_option'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['sms_form_next'].click()
        return self
    
