from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.sign_in_page_after_change_password import SignInWithNewPassword
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ResetYourPasswordWindow(UIPage):

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Reset Your Password"]')),
              'inner_text': 'Reset Your Password'}

    new_password = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="New Password"]/..//input[@name="answer"]'),
                                      label_text_locator=(By.XPATH, '//label[text()="New Password"]'))}

    confirm_password = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Confirm New Password"]/..//input[@name="confirmPassword"]'),
                                          label_text_locator=(By.XPATH, '//label[text()="Confirm New Password"]'))}

    next_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Confirm New Password"]/../../..//button[text()="Next"]')),
                   'inner_text': 'Next'}

    start_over = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Authentication (+)"]/following-sibling::button')),
                  'inner_text': 'Next'}

    def __init__(self, driver):
        self.elements = {
             self.LOADED_ELEMENT: factory(driver).define_element(self.header),
             'new_password': factory(driver).define_text_input(self.new_password),
             'confirm_password': factory(driver).define_text_input(self.confirm_password),
             'next_button': factory(driver).define_element(self.next_button),
             'start_over': factory(driver).define_element(self.start_over)
        }

        super().__init__(driver, self.elements)

    def wait_for_page_to_load(self, wait_time=UIPage.SHORT_DELAY, required=True, wait_for_ready=False):
        super().wait_for_page_to_load(wait_time=wait_time, required=required, wait_for_ready=wait_for_ready)

    def set_new_password(self, password):
        self.elements['new_password'].clear()
        self.elements['new_password'].type(password)

    def set_confirm_password(self, confirm_password):
        self.elements['confirm_password'].clear()
        self.elements['confirm_password'].type(confirm_password)

    def click_next_button(self):
        self.elements['next_button'].wait_for_visible()
        self.elements['next_button'].click()

    def click_start_over(self):
        self.elements['start_over'].wait_for_visible()
        self.elements['start_over'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return SignInWithNewPassword(self.driver).wait_for_page_to_load()

    def get_change_password_successfully_message(self):
        xpath = f'//label[contains(text(),"Password change")]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element.get_text()

    def close_browser(self):
        self.driver.close()