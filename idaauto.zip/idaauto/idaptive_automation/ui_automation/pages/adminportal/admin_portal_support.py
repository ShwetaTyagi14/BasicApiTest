from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AdminPortalSupport(UIPage):
    loaded = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text() = "Admin Portal Support"]'))}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Admin Portal Support"]//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self.loaded),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button)
        }
        super().__init__(driver, self.elements)

    def is_page_loaded(self):
        return self.elements['loaded'].wait_for_visible() is not None

    def validate_blank_company_text(self):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH,
                                        f'//span[text() = "Contact company support"]'))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        return element.is_displayed()

    def validate_new_company_text(self, company_name):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH,
                                        f'//span[text() = "Use this link to contact the support of {company_name}"]'))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        return element.is_displayed()

    def validate_new_company_link(self, company_name, company_url):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH,
                                        f'//span[text() = "Contact {company_name} support"]/..'))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        new_url = element.get_attribute_value('href')
        if element.is_displayed() and new_url == company_url:
            return True
        else:
            return False

    def validate_new_company_url(self, company_url):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH,
                            f'//a[@href="{company_url}"]'))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        return element.is_displayed()

    def click_cancel(self):
        self.elements['cancel_button'].wait_for_visible()
        self.elements['cancel_button'].click()
