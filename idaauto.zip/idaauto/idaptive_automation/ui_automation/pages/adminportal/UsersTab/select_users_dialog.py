from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class SelectUsersDialog(UIPage):

    example = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Select Users"]')),
               'inner_text': 'Select Users'}

    search_box = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search Users, Roles and Groups" )]',),
                                    parent_container_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search Users, Roles and Groups" )]/ancestor::div[3]'),
                                    toggle_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search Users, Roles and Groups" )]/ancestor::div[3]/div/div/a')),
                  'inner_text': ''}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.example),
            'example': factory(driver).define_element(self.example),
        }

        super().__init__(driver, self.elements)