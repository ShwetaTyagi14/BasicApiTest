from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class SetUserPasswordWindow(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Set User Password"]'))}

    manual = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//label[normalize-space(.)="Manual"]/preceding-sibling::input'),
                                label_text_locator=(By.XPATH, '//label[normalize-space(.)="Manual"]'),
                                parent_container_locator=(By.XPATH, '//table[tbody/tr/td[2]/div/label[normalize-space(.)="Manual"]]')),
              'label_text': 'Manual',
              'checked': True}

    generated = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, '//label[normalize-space(.)="Generated"]/preceding-sibling::input'),
                                   label_text_locator=(By.XPATH, '//label[normalize-space(.)="Generated"]'),
                                   parent_container_locator=(By.XPATH, '//table[tbody/tr/td[2]/div/label[normalize-space(.)="Generated"]]')),
                 'label_text': 'Generated',
                 'checked': False}

    password = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Password"]'),
                                  label_text_locator=(By.XPATH, '//input[@name="Password"]/ancestor::div[2]//label')),
                'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    confirm_password = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="confirmPassword"]',),
                                          label_text_locator=(By.XPATH, '//input[@name="confirmPassword"]/preceding-sibling::div//label')),
                        'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    save_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                   'inner_text': 'Save'}

    copy_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Copy"]')),
                   'inner_text': 'Copy'}
    success_toaster = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[text()='Success']"))}

    def __init__(self, driver):
        self.driver = driver
        dialog = factory(driver).define_element(self.dialog)
        self.elements = {
            self.LOADED_ELEMENT: dialog,
            'dialog': dialog,
            'manual': factory(driver).define_checkbox(self.manual),
            'generated': factory(driver).define_checkbox(self.generated),
            'password': factory(driver).define_text_input(self.password),
            'confirm_password': factory(driver).define_text_input(self.confirm_password),
            'save_button': factory(driver).define_element(self.save_button),
            'copy_button': factory(driver).define_element(self.copy_button),
            'success_toaster': factory(driver).define_element(self.success_toaster)
        }

        super().__init__(self.driver, self.elements)

    def set_password(self, password):
        self.elements['password'].type(password)

    def set_confirm_password(self, password):
        self.elements['confirm_password'].type(password)

    def is_save_button_disabled(self):
        class_attr_value = self.elements['save_button'].get_attribute_value('class')
        return 'disabled' in class_attr_value

    def is_confirm_error_icon_displayed(self):
        xpath = f'//li//ancestor::div[@role="alert" and @aria-live="polite"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element.is_displayed()

    def click_copy_button(self):
        # definition = {'locator':
        #                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Copy"]'))}
        # element = factory(self.driver).define_element(definition)
        # if element.get_element() is None:
        #     assert False, f'Copy button not found'
        self.elements['copy_button'].wait_for_visible()
        self.elements['copy_button'].click()

    def copy_password_to_clipboard(self):
        self.click_copy_button()
        self.driver.find_element_by_tag_name('body').send_keys(Keys.LEFT_CONTROL + 'c')
        return self.driver.get_clipboard_contents()

    def click_save_button(self):
        self.elements['save_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def select_generated_radio_button(self):
        self.elements['generated'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def is_manual_radio_button_selected(self):
        return self.elements['manual'].is_checked()

    def is_generated_password_displayed(self):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="GeneratedPassword"]')),
                      'validation_error_class': 'x-form-field x-form-text x-trigger-noedit'}
        element = factory(self.driver).define_text_input(definition)
        if element.get_element() is None:
            assert False, f'Generated password field is not visible'

    def validate_success_toaster(self):
        return self.elements['success_toaster'].is_displayed()