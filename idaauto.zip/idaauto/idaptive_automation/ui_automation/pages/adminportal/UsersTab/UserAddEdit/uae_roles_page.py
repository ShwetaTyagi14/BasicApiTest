from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UAERolesTabPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="TabbedFormTabTree"]/following-sibling::div[@viewparttitle="Roles"]/descendant::div[text()="Roles"]')),
              'inner_text': 'Roles'}

    learn_more = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Learn more"]')),
                  'inner_text': 'Learn more'}

    roles_grid_name_column = {'locator':
                              ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Name"]')),
                              'inner_text': 'Name'}

    roles_grid_admin_rights_column = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Administrative Rights"]')),
                                      'inner_text': 'Administrative Rights'}
    existing_roles_rows = {'locator':
                           ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@id,"basicGrid") and contains(@class,"multi-line-grid")]//tbody//tr'))}

    roles_row_names = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@id,"basicGrid") and contains(@class,"multi-line-grid")]//tbody//td[contains(@class,"x-grid-cell-first")]/div'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.roles_grid_admin_rights_column),
            'header': factory(driver).define_element(self.header),
            'learn_more': factory(driver).define_element(self.learn_more),
            'name': factory(driver).define_element(self.roles_grid_name_column),
            'admin_rights': factory(driver).define_element(self.roles_grid_admin_rights_column),
            'roles_rows': factory(driver).define_element_group(self.existing_roles_rows),
            'roles_row_names': factory(driver).define_element_group(self.roles_row_names)
        }

        super().__init__(driver, self.elements)

    def get_displayed_role_rows(self):
        rows = self.elements['roles_rows'].get_element()
        return rows

    def get_roles_names(self):
        rows = self.elements['roles_row_names'].get_element()
        row_list = []
        for row in rows:
            row_list.append(row.text)
        return [val.strip(' ') for val in row_list]