from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class SelectUsersWindow(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Select Users" and contains(@class,"modal-window")]'))}

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"window-header-body-modal")]/descendant::span[text()="Select Users"]'))}

    search_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search Users, Roles and Groups")]',),
                                               parent_container_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search Users, Roles and Groups")]/ancestor::div[contains(@class,"search-field")]'),
                                               toggle_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search Users, Roles and Groups")]/ancestor::div[contains(@class,"search-field")]/div/div/a'))
                 }
    grid_rows = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr'))}

    column_headers = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"modal-window")]//div[contains(@class,"x-column-header-default") and contains(@id,"datagridcolumn")]'))}

    invite_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Invite"]'))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]'))}

    search_box_loading_mask = \
        (By.XPATH,
         '//div[contains(@class, "white-loadmask-indicator") and not(contains(@style, "display: none"))]')

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.invite_button),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'search_box': factory(driver).define_search_box(self.search_box),
            'grid_rows': factory(driver).define_element_group(self.grid_rows),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'invite_button': factory(driver).define_element(self.invite_button),
            'column_headers': factory(driver).define_element_group(self.column_headers)
        }

        super().__init__(driver, self.elements)

    def click_invite_button(self):
        self.elements['invite_button'].wait_for_visible()
        self.elements['invite_button'].click()

    def click_cancel_button(self):
        self.elements['cancel_button'].wait_for_visible()
        self.elements['cancel_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def search_to_invite(self, name):
        self.elements['search_box'].search_for(name)
        self.wait_for_search_mask_to_disappear()
        return self

    def wait_for_search_mask_to_disappear(self, wait_for_appearance=UIPage.SHORT_DELAY,
                                          wait_for_disappearance=UIPage.LONG_DELAY):
        self.driver.wait_for_transient_element_to_come_and_go(self.search_box_loading_mask,
                                                              wait_for_appearance_time=wait_for_appearance,
                                                              wait_for_disappearance_time=wait_for_disappearance)

    def select_checkbox_for_user(self, user_name):
        self.wait_for_search_mask_to_disappear()
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[starts-with(@test-text,'{user_name}')]/td[1]"))}
        factory(self.driver).define_element(elem_def).click()
