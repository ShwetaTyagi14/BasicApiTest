from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UAEAddtnlAttributesTabPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Additional Attributes"]')),
              'inner_text': 'Additional Attributes'}

    additional_attributes_grid_name_column = {'locator':
                                              ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Name"]')),
                                              'inner_text': 'Name'}

    additional_attributes_grid_value_column = {'locator':
                                               ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Value"]')),
                                               'inner_text': 'Value'}

    additional_attributes_grid_desc_column = {'locator':
                                              ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Description"]')),
                                              'inner_text': 'Description'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'name': factory(driver).define_element(self.additional_attributes_grid_name_column),
            'value': factory(driver).define_element(self.additional_attributes_grid_value_column),
            'description': factory(driver).define_element(self.additional_attributes_grid_desc_column)
        }

        super().__init__(driver, self.elements)
