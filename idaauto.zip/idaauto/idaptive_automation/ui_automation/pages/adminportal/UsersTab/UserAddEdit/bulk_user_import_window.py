from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class BulkUserImportWindow(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Bulk User Import" and contains(@class,"modal-window")]'))}

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[contains(@class,"window-header-body-modal")]/descendant::span[text()="Bulk User Import"]'))}

    learn_more = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[text()="Learn more"]')),
                  'inner_text': 'Learn more'}

    bulk_user_import_template_link = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, '//a[text()="Bulk User Import Template"]'))}

    file_name = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@name="FileName"]'))}

    file_input = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Icon"]')),
                  'supports_validation': False}

    browse_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//td[contains(@id,"browseButtonWrap")]'))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="cancelButton"]'))}

    next_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="nextButton"]'))}

    confirm_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="doneButton"]')),
                      'supports_validation': False}

    send_email_invite_chk = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Send email invite for user portal setup"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, '//label[.="Send email invite for user portal setup"]'),
                              parent_container_locator=(By.XPATH, '//label[.="Send email invite for user portal setup"]/ancestor::table[1]')),
            'label_text': 'Send email invite for user portal setup',
            'checked': True,
            'supports_validation': False
        }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'learn_more': factory(driver).define_element(self.learn_more),
            'bulk_user_import_template_link': factory(driver).define_element(self.bulk_user_import_template_link),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'browse_button': factory(driver).define_element(self.browse_button),
            'next_button': factory(driver).define_element(self.next_button),
            'file_name': factory(driver).define_text_input(self.file_name),
            'file_input': factory(driver).define_text_input(self.file_input),
            'send_email_invite': factory(driver).define_checkbox(self.send_email_invite_chk),
            'confirm_button': factory(driver).define_element(self.confirm_button)
        }

        super().__init__(driver, self.elements)

    def download_bulk_user_template(self):
        self.elements['bulk_user_import_template_link'].wait_for_visible()
        self.elements['bulk_user_import_template_link'].click(10)

    def click_cancel(self):
        self.elements['cancel_button'].wait_for_visible()
        self.elements['cancel_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def click_confirm_button(self):
        self.elements['confirm_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def browse_to_upload_file(self):
        self.elements['browse_button'].wait_for_visible()
        self.elements['browse_button'].click()

    def set_filename(self, filename):
        script = '(function(){var element = document.getElementsByName("Icon")[0];element.classList.remove("x-form-file-input");})()'
        self.driver.execute_script(script)
        self.elements['file_input'].clear().type(filename)
        return self

    def uncheck_send_email_invite_chk(self):
        if self.elements['send_email_invite'].is_checked():
            self.elements['send_email_invite'].click()

    def get_is_user_in_import_list(self, user):
        elem = factory(self.driver).define_element({
            'locator':
            ElementSetLocator((By.XPATH, f'//div[contains(text(), "{user}")]'))
        }).wait_for_visible()
        return elem.is_displayed()

    def click_next(self):
        self.elements['next_button'].wait_for_visible()
        self.elements['next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()