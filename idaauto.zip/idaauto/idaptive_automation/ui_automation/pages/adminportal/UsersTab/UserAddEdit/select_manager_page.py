from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UAESelectManagerPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Select User"]'))}
    heading = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Select User"]')),
               'inner_text': 'Select User'}

    search_box = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//input[starts-with(@placeholder,"User Name Starts")]',),
                                    parent_container_locator=(By.XPATH, '//input[starts-with(@placeholder,"User Name Starts")]/ancestor::div[3]'),
                                    toggle_locator=(By.XPATH, '//input[starts-with(@placeholder,"User Name Starts")]/ancestor::div[3]/div/div/a')),
                  'inner_text': ''}

    source_idap_directory = {'locator':
                             ElementSetLocator(element_locator=(By.XPATH, '//label[.="CyberArk Cloud Directory"]/preceding-sibling::input'),
                                               label_text_locator=(By.XPATH, '//label[.="CyberArk Cloud Directory"]'),
                                               parent_container_locator=(By.XPATH, '//label[.="CyberArk Cloud Directory"]/ancestor::table[1]')),
                             'label_text': 'CyberArk Cloud Directory',
                             'checked': True}

    source_fds = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//label[.="FDS"]/preceding-sibling::input'),
                                    label_text_locator=(By.XPATH, '//label[.="FDS"]'),
                                    parent_container_locator=(By.XPATH, '//label[.="FDS"]/ancestor::table[1]')),
                  'label_text': 'FDS',
                  'checked': True}

    ok_button = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Select User"]//a[@buttontext="OK"]')),
                 'inner_text': 'OK'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Select User"]//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'heading': factory(driver).define_element(self.heading),
            'search_box': factory(driver).define_search_box(self.search_box),
            'idap_directory': factory(driver).define_checkbox(self.source_idap_directory),
            'fds': factory(driver).define_checkbox(self.source_fds),
            'ok_button': factory(driver).define_element(self.ok_button),
            'cancel_button': factory(driver).define_element(self.cancel_button)
        }

        super().__init__(driver, self.elements)

    def search_for_user(self, username):
        self.elements['search_box'].search_for(username)
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_on_user(self, username):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window")]//tr[td[2][.="{username}"]]'))}
        factory(self.driver).define_element(elem_def).click()
        return self

    def press_ok_button(self):
        self.elements['ok_button'].wait_for_visible()
        self.elements['ok_button'].click()
        return self

