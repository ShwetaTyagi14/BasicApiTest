from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UAEAppSettingsTabPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Application Settings"]')),
              'inner_text': 'Application Settings'}

    learn_more = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Learn more"]')),
                  'inner_text': 'Learn more'}

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    app_settings_grid_name_column = {'locator':
                                     ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Name"]')),
                                     'inner_text': 'Name'}

    app_settings_grid_username_column = {'locator':
                                         ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="User Name"]')),
                                         'inner_text': 'User Name'}

    app_settings_grid_password_column = {'locator':
                                         ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Password"]')),
                                         'inner_text': 'Password'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'learn_more': factory(driver).define_element(self.learn_more),
            'add_button': factory(driver).define_element(self.add_button),
            'name': factory(driver).define_element(self.app_settings_grid_name_column),
            'user_name': factory(driver).define_element(self.app_settings_grid_username_column),
            'password': factory(driver).define_element(self.app_settings_grid_password_column)
        }

        super().__init__(driver, self.elements)
