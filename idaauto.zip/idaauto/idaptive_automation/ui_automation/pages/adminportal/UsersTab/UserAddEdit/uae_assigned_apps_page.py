from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UAEAssignedAppsTabPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Assigned Applications"]')),
              'inner_text': 'Assigned Applications'}

    assigned_apps_grid_name_column = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Name"]')),
                                      'inner_text': 'Name'}

    assigned_apps_grid_type_column = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Type"]')),
                                      'inner_text': 'Type'}

    assigned_apps_grid_desc_column = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Description"]')),
                                      'inner_text': 'Description'}

    assigned_apps_grid_assigned_to_column = {'locator':
                                             ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Assigned to"]')),
                                             'inner_text': 'Assigned to'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'name': factory(driver).define_element(self.assigned_apps_grid_name_column),
            'type': factory(driver).define_element(self.assigned_apps_grid_type_column),
            'description': factory(driver).define_element(self.assigned_apps_grid_desc_column),
            'assigned_to': factory(driver).define_element(self.assigned_apps_grid_assigned_to_column)
        }

        super().__init__(driver, self.elements)
