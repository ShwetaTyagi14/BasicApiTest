from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class UAEActivityTabPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Activity"]')),
              'inner_text': 'Activity'}

    learn_more = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Learn more"]')),
                  'inner_text': 'Learn more'}

    activity_grid_when_column = {'locator':
                                 ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text()="When"]')),
                                 'inner_text': 'When'}

    activity_grid_detail_column = {'locator':
                                   ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text()="Detail"]')),
                                   'inner_text': 'Detail'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'learn_more': factory(driver).define_element(self.learn_more),
            'when': factory(driver).define_element(self.activity_grid_when_column),
            'detail': factory(driver).define_element(self.activity_grid_detail_column)

        }

        super().__init__(driver, self.elements)
