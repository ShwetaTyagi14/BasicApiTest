from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class SendInvitesWindow(UIPage):

    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div/span[text()="Send Invites"]'))}

    send_invites_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Send Invites"]'))}

    send_invites_toaster_msg = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Inviting Users Submitted"]'))}

    def __init__(self, driver):

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'send_invites_button': factory(driver).define_element(self.send_invites_button),
            'send_invites_toaster_msg': factory(driver).define_element(self.send_invites_toaster_msg)
        }

        super().__init__(driver, self.elements)

    def click_send_invites_button(self):
        self.elements['send_invites_button'].wait_for_visible()
        self.elements['send_invites_button'].click()

    def validate_send_invites_toaster_msg(self):
        return self.elements['send_invites_toaster_msg'].is_displayed()