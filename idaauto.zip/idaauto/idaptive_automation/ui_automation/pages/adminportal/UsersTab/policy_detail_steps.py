from idaptive_automation.ui_automation import LeftNavBar
from Helpers.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation import PolicySettingsPage, PolicyDetailLandingPage,\
    UnsavedChangesDialog, WarningWindow


class PolicyDetailSteps:
    def __init__(self,driver):
        self.driver = driver
        self.leftNavBar = LeftNavBar(self.driver)

    def navigate(self, path):
        if path is None:
            return
        self.leftNavBar.navigate(path)

    def validate_policy_settings_ui(self):
        self.leftNavBar.navigate([pdc.POLICY_SETTINGS])
        PolicyDetailLandingPage(self.driver).validate_all_elements()
        PolicySettingsPage(self.driver).validate_all_elements()
        return self

    def discard_changes(self):
        PolicyDetailLandingPage(self.driver).cancel_changes()
        UnsavedChangesDialog(self.driver).discard_changes()

    def save_changes(self):
        return self, PolicyDetailLandingPage(self.driver).save_changes()[1]

    def try_save_changes(self):
        page = PolicyDetailLandingPage(self.driver).save_changes()
        WarningWindow(self.driver).wait_for_page_to_load().close()
        return self

    def set_policy_name(self,name):
        PolicySettingsPage(self.driver).set_name(name)
        return self

    def save_changes_with_specified_roles(self):
        PolicySettingsPage(self.driver).assign_policy_to_specified_roles()
        return self, PolicyDetailLandingPage(self.driver).save_changes()[1]
