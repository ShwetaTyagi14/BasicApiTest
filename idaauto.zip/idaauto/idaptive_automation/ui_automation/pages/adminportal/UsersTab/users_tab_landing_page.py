import email
import poplib

from selenium.webdriver.common.by import By
from selenium.common.exceptions import ElementNotInteractableException

from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.bulk_user_import_window import \
    BulkUserImportWindow
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.select_users_window import \
    SelectUsersWindow
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.uielements.element_definition import ElementDefinition
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_group import UiElementGroup
from idaptive_automation.ui_automation.uielements.user_set_filter import UserSetFilter
from idaptive_automation.ui_automation.uielements.search_box import SearchBox
from idaptive_automation.ui_automation.uielements.multi_select_button import MultiSelectButton
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from .user_add_edit_window import UserAddEditWindow
import time


class UsersTab(UIPage):
    users_header = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//div[.="Users"]')),
                    'inner_text': 'Users'}

    users_grid_login_name_column = {'locator':
                                    ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Login Name"]')),
                                    'inner_text': 'Login Name'}

    users_grid_display_name_column = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Display Name"]')),
                                      'inner_text': 'Display Name'}

    policies_grid_email_column = {'locator':
                                  ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Email"]')),
                                  'inner_text': 'Email'}

    policies_grid_source_column = {'locator':
                                   ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Source"]')),
                                   'inner_text': 'Source'}

    policies_grid_status_column = {'locator':
                                   ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Status"]')),
                                   'inner_text': 'Status'}

    policies_grid_last_invite_column = {'locator':
                                        ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Last Invite"]')),
                                        'inner_text': 'Last Invite'}

    policies_grid_last_login_column = {'locator':
                                       ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Last Login"]')),
                                       'inner_text': 'Last Login'}

    search_box = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search") and contains(@placeholder,"Users")]'),
                                    parent_container_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search") and contains(@placeholder,"Users")]/ancestor::div[contains(@class,"search-field")]'),
                                    toggle_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search") and contains(@placeholder,"Users")]/ancestor::div[contains(@class,"search-field")]/descendant::a'))}

    search_input = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search") and contains(@placeholder,"Users")]'))}

    search_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search") and contains(@placeholder,"Users")]/ancestor::div[contains(@class,"search-field")]/descendant::a'))}

    add_user_button = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add User"]')),
                       'inner_text': 'Add User'}

    bulk_user_btn = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Bulk User Import"]')),
                     'inner_text': 'Bulk User Import'}

    invite_user_btn = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Invite Users"]')),
                       'inner_text': 'Invite Users'}

    interactive_users = {'locator':
                         ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Interactive Users"]'),
                                           parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Interactive Users"]/ancestor::div[1]')),
                         'inner_text': 'All Interactive Users'}

    all_users = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Users"]'),
                                   parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Users"]/ancestor::div[1]')),
                 'inner_text': 'All Users'}

    ad_users = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="Active Directory Users"]'),
                                  parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="Active Directory Users"]/ancestor::div[1]')),
                'inner_text': 'Active Directory Users'}

    active_users = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Active Users"]'),
                                      parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Active Users"]/ancestor::div[1]')),
                    'inner_text': 'All Active Users'}

    invited_users = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Invited Users"]'),
                                       parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Invited Users"]/ancestor::div[1]')),
                     'inner_text': 'All Invited Users'}

    non_active_users = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Non-Active Users"]'),
                                          parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Non-Active Users"]/ancestor::div[1]')),
                        'inner_text': 'All Non-Active Users'}

    service_users = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Service Users"]'),
                                       parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="All Service Users"]/ancestor::div[1]')),
                     'inner_text': 'All Service Users'}

    federated_users = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="Federated Users"]'),
                                         parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="Federated Users"]/ancestor::div[1]')),
                       'inner_text': 'Federated Users'}

    google_users = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="Google Directory Users"]'),
                                      parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="Google Directory Users"]/ancestor::div[1]')),
                    'inner_text': 'Google Directory Users'}

    idaptive_users = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="CyberArk Cloud Users"]'),
                                        parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="CyberArk Cloud Directory Users"]/ancestor::div[1]')),
                      'inner_text': 'CyberArk Cloud Directory Users'}

    ldap_users = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="LDAP Users"]'),
                                    parent_container_locator=(By.XPATH, '//div[starts-with(@class,"ellipsis set-name") and .="LDAP Users"]/ancestor::div[1]')),
                  'inner_text': 'LDAP Users'}

    user_rows = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"headercontainer")][div/div/div[2]/div//span[text()="Login Name"]]/following-sibling::div/div/table//tr')),
                 'supports_validation': False}

    users_grid = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                                '//div[starts-with(@id,"headercontainer")][div/div/div[2]/div//span[text()="Login Name"]]/following-sibling::div/div[contains(@class,"grid-view")]')),
                  'supports_validation': False}

    actions = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, '//div[@itemId="mainContainer"]//a[@buttontext="Actions"]')),
               'inner_text': 'Actions',
               'supports_validation': False}

    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    _mfa_unlock = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[.="MFA Unlock"]')),
        'supports_validation': False
    }

    set_password = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Set Password"]'))}

    _add_to_organization = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//a[.="Add to Organization"]')),
        'supports_validation': False
    }

    ou_warning_popup = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[.="One or more selected users are already in an Organization. This operation will move all selected users to another Organization."]'))}

    ou_unauthorized_popup = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[.="You are not authorized to modify any existing Organizations."]'))}

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.users_header),
            'search_box': factory(driver).define_search_box(self.search_box),
            'login_name': factory(driver).define_element(self.users_grid_login_name_column),
            'display_name': factory(driver).define_element(self.users_grid_display_name_column),
            'email': factory(driver).define_element(self.policies_grid_email_column),
            'source': factory(driver).define_element(self.policies_grid_source_column),
            'status': factory(driver).define_element(self.policies_grid_status_column),
            'last_invite': factory(driver).define_element(self.policies_grid_last_invite_column),
            'last_login': factory(driver).define_element(self.policies_grid_last_login_column),
            'add_user_btn': factory(driver).define_element(self.add_user_button),
            'bulk_user_btn': factory(driver).define_element(self.bulk_user_btn),
            'invite_user_btn': factory(driver).define_element(self.invite_user_btn),
            'interactive_users': factory(driver).define_user_set_filter(self.interactive_users),
            'all_users': factory(driver).define_user_set_filter(self.all_users),
            'ad_users': factory(driver).define_user_set_filter(self.ad_users),
            'active_users': factory(driver).define_user_set_filter(self.active_users),
            'invited_users': factory(driver).define_user_set_filter(self.invited_users),
            'non_active_users': factory(driver).define_user_set_filter(self.non_active_users),
            'service_users': factory(driver).define_user_set_filter(self.service_users),
            'fed_users': factory(driver).define_user_set_filter(self.federated_users),
            'google_users': factory(driver).define_user_set_filter(self.google_users),
            'idaptive_users': factory(driver).define_user_set_filter(self.idaptive_users),
            'ldap_users': factory(driver).define_user_set_filter(self.ldap_users),
            'users_grid': factory(driver).define_element_group(self.users_grid),
            'user_rows': factory(driver).define_element_group(self.user_rows),
            'actions_btn': factory(driver).define_element(self.actions),
            'set_password': factory(driver).define_element(self.set_password),
            'delete_btn': factory(driver).define_element(self.delete),
            'mfa_unlock': factory(driver).define_element(self._mfa_unlock),
            'search_input': factory(driver).define_text_input(self.search_input),
            'search_btn': factory(driver).define_element(self.search_btn),
            'add_to_organization': factory(driver).define_element(self._add_to_organization),
            'ou_warning_popup': factory(driver).define_element(self.ou_warning_popup),
            'ou_unauthorized_popup': factory(driver).define_element(self.ou_unauthorized_popup)
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def validate_users_tab_is_loaded(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['search_box'].wait_for_visible()
        self.elements['add_user_btn'].wait_for_visible()
        self.elements['bulk_user_btn'].wait_for_visible()
        self.elements['invite_user_btn'].wait_for_visible()
        self.elements['users_grid'].wait_for_visible()
        return self

    def get_displayed_users(self):
        return self.elements['user_rows'].get_text()

    def select_user_checkbox(self, username):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                                  f'//div[starts-with(@id,"basicGrid")]//tr//div[contains(text(),"{username}")]/../../td[1]//div/div'))}
        factory(self.driver).define_element(elem_def).click()

    def open_user_detail_window_for_user(self, username):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[starts-with(@id,"basicGrid")]//tr//div[contains(text(),"{username}")]'))}
        factory(self.driver).define_element(elem_def).click()
        self.driver.wait_for_loading_mask_to_disappear()

    def get_user_risk_level(self, username, risk_level):

        elem_def = None
        if risk_level == 'High':
            elem_def = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//td[@data-content="{username}"]//following-sibling::td//span[@class="state-high"]'
                          f'[text()="{risk_level}"]'))}
        elif risk_level == 'Medium':
            elem_def = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//td[@data-content="{username}"]//following-sibling::td//span[@class="state-medium"]'
                          f'[text()="{risk_level}"]'))}
        elif risk_level == 'Low':
            elem_def = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//td[@data-content="{username}"]//following-sibling::td//span[@class="state-low"]'
                          f'[text()="{risk_level}"]'))}
        elif risk_level == 'No Risk':
            elem_def = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//td[@data-content="{username}"]//following-sibling::td//span[@class="state-active"]'
                          f'[text()="{risk_level}"]'))}
        elif risk_level == 'Unknown':
            elem_def = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f'//td[@data-content="{username}"]//following-sibling::td//span[@class="state-unreachable"]'
                          f'[text()="{risk_level}"]'))}

        try:
            _risk_level = factory(self.driver).define_element(elem_def).get_text()
        except AttributeError:
            _risk_level = None

        return _risk_level

    def open_actions_menu(self):
        self.elements['actions_btn'].click()
        return self

    def click_delete(self):
        self.elements['delete_btn'].click()

    def click_mfa_unlock(self):
        self.elements['mfa_unlock'].click()

    def click_add_to_organization(self):
        self.elements['add_to_organization'].click()

    def open_add_user_window(self):
        self.elements['add_user_btn'].click()
        detail_window = UserAddEditWindow(self.driver)
        detail_window.validate_window_is_loaded()
        return detail_window

    def search_for_user(self, username):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['search_box'].clear()
        self.elements['search_box'].search_for(username)
        self.driver.wait_for_loading_mask_to_disappear()

    def select_interactive_user_set(self):
        self.elements['interactive_users'].select()
        time.sleep(1)

    def select_all_users_set(self):
        self.elements['all_users'].select()
        time.sleep(1)

    def select_ad_users_set(self):
        self.elements['ad_users'].select()
        time.sleep(1)

    def select_active_users_set(self):
        self.elements['active_users'].select()
        time.sleep(1)

    def select_invited_users_set(self):
        self.elements['invited_users'].select()
        time.sleep(1)

    def select_non_active_users_set(self):
        self.elements['non_active_users'].select()
        time.sleep(1)

    def select_service_users_set(self):
        self.elements['service_users'].select()
        time.sleep(1)

    def select_federated_users_set(self):
        self.elements['fed_users'].select()
        time.sleep(1)

    def select_google_users_set(self):
        self.elements['google_users'].select()
        time.sleep(1)

    def select_idaptive_users_set(self):
        self.elements['idaptive_users'].select()
        time.sleep(1)

    def select_ldap_users_set(self):
        self.elements['ldap_users'].select()
        time.sleep(1)

    def click_set_password(self):
        self.elements['set_password'].click()

    def open_bulk_user_import_window(self):
        self.elements['bulk_user_btn'].click()
        return BulkUserImportWindow(self.driver).wait_for_page_to_load()

    def open_invite_user_window(self):
        self.elements['invite_user_btn'].click()
        return SelectUsersWindow(self.driver).wait_for_page_to_load()

    @staticmethod
    def validate_email(validate_messages):
        content_found = 0
        SERVER = "pop.gmail.com"
        USER = "idaptiveprovisioning"
        PASSWORD = "testTEST1234"

        server = poplib.POP3_SSL(SERVER)
        server.user(USER)
        server.pass_(PASSWORD)

        resp, mails, octets = server.list()
        index = len(mails)
        resp, lines, octets = server.retr(index)

        message = email.message_from_bytes(b'\n'.join(lines))
        payload = message.get_payload(decode=True)

        for part in message.walk():
            message_part = part.get_payload(decode=True)
            if message_part is not None:
                for validation in validate_messages:
                    if str.encode(validation) in message_part:
                        content_found += 1

        assert content_found >= validate_messages.__len__()
        server.dele(index)
        server.quit()

    def press_cancel_button(self):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='Cancel']"))
        UIPage.__persistent_click_element__(element)

    def press_add_button(self):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='Add']"))
        UIPage.__persistent_click_element__(element)

    def validate_ou_warning(self):
        return self.elements['ou_warning_popup'].is_displayed()

    def press_ok_on_warning(self):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='OK']"))
        UIPage.__persistent_click_element__(element)

    def validate_ou_unauthorized_popup(self):
        return self.elements['ou_unauthorized_popup'].is_displayed()
