from idaptive_automation.ui_automation.pages.error_dialog import ErrorDialog
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.uae_roles_page import UAERolesTabPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.select_manager_page import UAESelectManagerPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.uae_assigned_apps_page import UAEAssignedAppsTabPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.uae_app_settings_page import UAEAppSettingsTabPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.uae_addtnl_attribs_page import UAEAddtnlAttributesTabPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.uae_activity_page import UAEActivityTabPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.constants import AddEditUser as aeu


class UserAddEditWindow(UIPage):
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//label[.="Create CyberArk Cloud Directory User"]')),
              'inner_text': 'Create CyberArk Cloud Directory User'}

    loading_mask = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//div[@class="white-loadmask"]')),
                    'supports_validation': False}

    login_name = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="LoginName"]'),
                                    label_text_locator=(By.XPATH, '//input[@testname="LoginName"]/preceding-sibling::div/label')),
                  'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    lgs_xpath = '//input[starts-with(@id,"loginsuffixfield")]'
    suffix = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, lgs_xpath),
                                label_text_locator=(By.XPATH, f'//label[starts-with(@id,"loginsuffixfield")]'),
                                toggle_locator=(By.XPATH, f'{lgs_xpath}{toggle_xpath}')),
              'label_text': aeu.TextConstants.SUFFIX,
              # 'options': Options.YES_NO
              }

    email = {'locator':
             ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="Mail"]'),
                               label_text_locator=(By.XPATH, '//input[@testname="Mail"]/preceding-sibling::div/label')),
             'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    display_name = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="DisplayName"]'),
                                      label_text_locator=(By.XPATH, '//input[@testname="DisplayName"]/preceding-sibling::div/label')),
                    'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    manual = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//label[normalize-space(.)="Manual"]/preceding-sibling::input'),
                                label_text_locator=(By.XPATH, '//label[normalize-space(.)="Manual"]'),
                                parent_container_locator=(By.XPATH, '//table[tbody/tr/td[2]/div/label[normalize-space(.)="Manual"]]')),
              'label_text': 'Manual',
              'checked': True}

    generated = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, '//label[normalize-space(.)="Generated"]/preceding-sibling::input'),
                                   label_text_locator=(By.XPATH, '//label[normalize-space(.)="Generated"]'),
                                   parent_container_locator=(By.XPATH, '//table[tbody/tr/td[2]/div/label[normalize-space(.)="Generated"]]')),
                 'label_text': 'Generated',
                 'checked': False}

    password = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Password"]'),
                                  label_text_locator=(By.XPATH, '//input[@name="Password"]/ancestor::div[2]//label')),
                'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    confirm_password = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="confirmPassword"]',),
                                          label_text_locator=(By.XPATH, '//input[@name="confirmPassword"]/preceding-sibling::div//label')),
                        'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    locked = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="CloudState"]'),
                                label_text_locator=(By.XPATH, '//input[@testname="CloudState"]/following-sibling::label'),
                                parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="CloudState"]]')),
              'label_text': 'Locked',
              'checked': False,
              'enabled': False}

    never_expires = {'locator':
                     ElementSetLocator(element_locator=
                                       (By.XPATH, '//input[@testname="PasswordNeverExpire"]'),
                                       label_text_locator=(By.XPATH, '//input[@testname="PasswordNeverExpire"]/following-sibling::label'),
                                       parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="PasswordNeverExpire"]]')),
                     'label_text': 'Password never expires',
                     'checked': False}

    require_pwd_change = {'locator':
                          ElementSetLocator(element_locator=
                                            (By.XPATH, '//input[@testname="ForcePasswordChangeNext"]'),
                                            label_text_locator=(By.XPATH, '//input[@testname="ForcePasswordChangeNext"]/following-sibling::label'),
                                            parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="ForcePasswordChangeNext"]]')),
                          'label_text': 'Require password change at next login (recommended)',
                          'checked': True}

    is_service_user = {'locator':
                       ElementSetLocator(element_locator=
                                         (By.XPATH, '//input[@testname="InEverybodyRole"]'),
                                         label_text_locator=(By.XPATH, '//input[@testname="InEverybodyRole"]/following-sibling::label'),
                                         parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="InEverybodyRole"]]')),
                       'label_text': 'Is Service User',
                       'checked': False}

    is_oauth = {'locator':
                ElementSetLocator(element_locator=
                                  (By.XPATH, '//input[@testname="OauthClient"]'),
                                  label_text_locator=(By.XPATH, '//input[@testname="OauthClient"]/following-sibling::label'),
                                  parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="OauthClient"]]')),
                'label_text': 'Is OAuth confidential client',
                'checked': False}

    send_email_invite = {'locator':
                         ElementSetLocator(element_locator=
                                           (By.XPATH, '//input[@testname="SendEmailInvite"]'),
                                           label_text_locator=(By.XPATH, '//input[@testname="SendEmailInvite"]/following-sibling::label'),
                                           parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="SendEmailInvite"]]')),
                         'label_text': 'Send email invite for user portal setup',
                         'checked': True}

    send_sms_invite = {'locator':
                       ElementSetLocator(element_locator=
                                         (By.XPATH, '//input[@testname="SendSmsInvite"]'),
                                         label_text_locator=(By.XPATH, '//input[@testname="SendSmsInvite"]/following-sibling::label'),
                                         parent_container_locator=(By.XPATH, '//input[@testname="SendSmsInvite"]')),
                       'label_text': 'Send SMS invite for device enrollment',
                       'checked': False,
                       'supports_validation': False}

    redirect_mfa = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//label[.="Redirect multi factor authentication to a different user account"]/preceding-sibling::input'),
                                      label_text_locator=(By.XPATH, '//label[.="Redirect multi factor authentication to a different user account"]'),
                                      parent_container_locator=(By.XPATH, '//label[.="Redirect multi factor authentication to a different user account"]/ancestor::table')),
                    'label_text': 'Redirect multi factor authentication to a different user account',
                    'checked': False}

    redirect_to_account = {'locator':
                           ElementSetLocator(element_locator=
                                             (By.XPATH, '//input[@testname="SendSmsInvite"]'),
                                             label_text_locator=(By.XPATH, '//input[@testname="SendSmsInvite"]/following-sibling::label'),
                                             parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="SendSmsInvite"]]')),
                           'label_text': 'Redirect multi factor authentication to a different user account',
                           'checked': False,
                           'supports_validation': False}

    select_redirect_user_btn = {'locator':
                                ElementSetLocator(element_locator=(By.XPATH, '//div[@class="ellipsis set-name" and .="All Non-Active Users"]'),
                                                  parent_container_locator=(By.XPATH, '//div[@class="ellipsis set-name" and .="All Non-Active Users"]/ancestor::div[1]')),
                                'inner_text': 'All Non-Active Users'}

    manager = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="ReportsTo"]'),
                                 label_text_locator=(By.XPATH, '//input[@testname="ReportsTo"]/preceding-sibling::div/label')),
               'label_text': 'Manager'}

    select_manager_btn = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="_managedBySelectBtn" and .="Select"]')),
                          'inner_text': 'Select'}

    clear_manager_btn = {'locator':
                         ElementSetLocator(element_locator=(By.XPATH, '//div[@class="ellipsis set-name" and .="Google Directory Users"]'),
                                           parent_container_locator=(By.XPATH, '//div[@class="ellipsis set-name" and .="Google Directory Users"]/ancestor::div[1]')),
                         'inner_text': 'Google Directory Users'}

    create_user_btn = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Create User"]')),
                       'inner_text': 'Create User'}

    cancel_btn = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]')),
                  'inner_text': 'Cancel'}

    activity_tab = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Activity"]')),
                    'inner_text': 'Activity',
                   'supports_validation': False}

    account_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Account"]')),
                   'inner_text': 'Account',
                   'supports_validation': False}

    app_settings_tab = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Application Settings"]')),
                        'inner_text': 'Application Settings',
                   'supports_validation': False}

    assigned_apps_tab = {'locator':
                         ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Assigned Applications"]')),
                         'inner_text': 'Assigned Applications',
                   'supports_validation': False}

    roles_tab = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Roles"]')),
                 'inner_text': 'Roles',
                   'supports_validation': False}

    additional_attributes_tab = {'locator':
                                 ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Additional Attributes"]')),
                                 'inner_text': 'Additional Attributes',
                   'supports_validation': False}

    save_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]')),
                   'inner_text': 'Save',
                   'supports_validation': False}

    user_status = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[@itemid="status"]')),
                   'supports_validation': False}

    mobile_number = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="MobileNumber"]'),
                                       label_text_locator=(By.XPATH, '//input[@testname="MobileNumber"]/preceding-sibling::div/label')),
                     'label_text': 'Mobile Number'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.save_button),
            'header': factory(driver).define_element(self.header),
            'loading_mask': factory(driver).define_element(self.loading_mask),
            'login_name': factory(driver).define_text_input(self.login_name),
            'suffix': factory(driver).define_select(self.suffix),
            'email': factory(driver).define_text_input(self.email),
            'display_name': factory(driver).define_text_input(self.display_name),
            'manual': factory(driver).define_checkbox(self.manual),
            'generated': factory(driver).define_checkbox(self.generated),
            'password': factory(driver).define_text_input(self.password),
            'confirm_password': factory(driver).define_text_input(self.confirm_password),
            'locked': factory(driver).define_checkbox(self.locked),
            'never_expires': factory(driver).define_checkbox(self.never_expires),
            'require_pwd_change': factory(driver).define_checkbox(self.require_pwd_change),
            'is_service_user': factory(driver).define_checkbox(self.is_service_user),
            'is_oauth': factory(driver).define_checkbox(self.is_oauth),
            'send_email': factory(driver).define_checkbox(self.send_email_invite),
            'send_sms': factory(driver).define_checkbox(self.send_sms_invite),
            'redirect_mfa': factory(driver).define_checkbox(self.redirect_mfa),
            # UNCOMPLETED:
            # 'redirect_to_acct': factory(driver).define_text_input(**self.redirect_to_account),
            # 'select_redirect_user': factory(driver).define_element(**self.select_redirect_user_btn),
            'manager': factory(driver).define_text_input(self.manager),
            'select_manager': factory(driver).define_element(self.select_manager_btn),
            # 'clear_manager': factory(driver).define_element(**self.clear_manager_btn),
            'create_user': factory(driver).define_element(self.create_user_btn),
            'cancel_user': factory(driver).define_element(self.cancel_btn),
            'activity': factory(driver).define_element(self.activity_tab),
            'app_settings': factory(driver).define_element(self.app_settings_tab),
            'assigned_apps': factory(driver).define_element(self.assigned_apps_tab),
            'roles_tab': factory(driver).define_element(self.roles_tab),
            'account_tab': factory(driver).define_element(self.account_tab),
            'additional_attributes': factory(driver).define_element(self.additional_attributes_tab),
            'save_button': factory(driver).define_element(self.save_button),
            'user_status': factory(driver).define_element(self.user_status),
            'mobile_number': factory(driver).define_text_input(self.mobile_number)
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def set_login(self, login):
        self.elements['login_name'].type(login)

    def set_email(self, email):
        self.elements['email'].clear()
        self.elements['email'].type(email)

    def set_display_name(self, name):
        self.elements['display_name'].type(name)

    def set_password(self, password):
        self.elements['password'].type(password)

    def set_confirm_password(self, password):
        self.elements['confirm_password'].type(password)

    def validate_window_is_loaded(self):
        self.elements['login_name'].wait_for_visible()
        return self

    def press_cancel_button(self):
        self.elements['cancel_user'].click()

    def press_create_user_button(self):
        self.elements['create_user'].click()
        self.elements['loading_mask'].wait_for_element_to_disappear(wait_time=UIPage.LONG_DELAY)

    def press_create_user_button_with_error(self):
        self.elements['create_user'].click()
        return ErrorDialog(self.driver).wait_for_page_to_load()

    def press_select_manager(self):
        self.elements['select_manager'].click()
        return UAESelectManagerPage(self.driver).wait_for_page_to_load()

    def click_account_tab(self):
        self.elements['account_tab'].click()

    def click_activity_tab(self):
        self.elements['activity'].click()
        return UAEActivityTabPage(self.driver).wait_for_page_to_load()

    def click_app_settings_tab(self):
        self.elements['app_settings'].click()
        return UAEAppSettingsTabPage(self.driver).wait_for_page_to_load()

    def click_assigned_apps_tab(self):
        self.elements['assigned_apps'].click()
        return UAEAssignedAppsTabPage(self.driver).wait_for_page_to_load()

    def click_endpoints_tab(self):
        # click the endpoints element in the side tab
        raise Exception('this method has not been implemented yet')

    def click_roles_tab(self):
        self.elements['roles_tab'].wait_for_visible()
        self.elements['roles_tab'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return UAERolesTabPage(self.driver).wait_for_page_to_load()

    def click_provisioned_apps_tab(self):
        # click the provisioned apps element in the side tab
        raise Exception('this method has not been implemented yet')

    def click_additional_attributes_tab(self):
        self.elements['additional_attributes'].click()
        return UAEAddtnlAttributesTabPage(self.driver).wait_for_page_to_load()

    def click_summary_tab(self):
        # click the policy summary element in the side tab
        raise Exception('this method has not been implemented yet')

    def set_manager(self, username):
        self.elements['manager'].clear()
        self.elements['manager'].type(username)

    def get_manager_text(self):
        return self.elements['manager'].get_text()

    def click_require_password_change_at_login(self):
        self.elements['require_pwd_change'].wait_for_visible()
        return self.elements['require_pwd_change'].check()

    def click_password_never_expires(self):
        self.elements['never_expires'].wait_for_visible()
        self.elements['never_expires'].click()

    def validate_require_pwd_change_checked(self):
        self.elements['require_pwd_change'].wait_for_visible()
        return self.elements['require_pwd_change'].is_selected()

    def validate_never_expires_checked(self):
        self.elements['never_expires'].wait_for_visible()
        return self.elements['never_expires'].is_selected()

    def click_save_button(self):
        self.elements['save_button'].wait_for_visible()
        self.hover_and_click(element_text='Save')
        self.driver.wait_for_loading_mask_to_disappear()

    def hover_and_click(self, element_text):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='{element_text}']"))
        self.driver.hover_over_element(by=(By.XPATH, f"//a[@buttontext='{element_text}']"))
        element.click()
        return self

    def select_suffix(self, suffix):
        self.elements['suffix'].click()
        xpath = f'//ul[@class="x-list-plain"]//li[text()="{suffix}"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        element.click()

    def click_send_email(self):
        self.elements['send_email'].click()

    def get_user_display_status(self):
        self.elements['user_status'].wait_for_visible()
        return self.elements['user_status'].get_text()

    def validate_locked_checked(self):
        self.elements['locked'].wait_for_visible()
        return self.elements['locked'].is_checked()

    def is_service_user_checked(self):
        self.elements['is_service_user'].wait_for_visible()
        return self.elements['is_service_user'].is_checked()

    def edit_mobile_when_editable(self, number):
        self.elements['mobile_number'].get_element()
        read_only_value = self.elements['mobile_number'].get_attribute_value('readonly')
        if read_only_value:
            return False
        else:
            self.elements['mobile_number'].clear()
            self.elements['mobile_number'].type(number)
            self.click_save_button()
            return True
