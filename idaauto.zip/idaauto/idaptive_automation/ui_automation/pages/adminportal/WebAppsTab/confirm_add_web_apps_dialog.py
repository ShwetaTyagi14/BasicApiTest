from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class ConfirmAddWebAppsDialog(UIPage):
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[.="Add Web App"]'))}

    dialog_xpath = '//div[contains(@class,"modal-window") and .//span[.="Add Web App"]]'
    app_name = {
        'locator':
            ElementSetLocator((By.XPATH, f'{dialog_xpath}//span[@class="app-name"]'))
    }

    description = {
        'locator':
            ElementSetLocator((By.XPATH, f'{dialog_xpath}//div[./preceding-sibling::label[.="Description"]][1]'))
    }

    yes_button = {
        'locator':
            ElementSetLocator((By.XPATH, f'{dialog_xpath}//a[@buttontext="Yes"]'))
    }

    no_button = {
        'locator':
            ElementSetLocator((By.XPATH, f'{dialog_xpath}//a[@buttontext="No"]'))
    }

    toaster = (By.XPATH, '//div[contains(@class,"x-window-body")]/following-sibling::div[@class="x-css-shadow" ]')

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self.header),
            'app_name': ElementFactory(driver).define_search_box(self.app_name),
            'description': ElementFactory(driver).define_element(self.description),
            'yes_button': ElementFactory(driver).define_element(self.yes_button),
            'no_button': ElementFactory(driver).define_element(self.no_button)
        }

        super().__init__(driver, self.elements)

    def get_app_name(self):
        self.elements['app_name'].get_text()

    def get_description(self):
        self.elements['description'].get_text()

    def click_yes(self):
        self.elements['yes_button'].click()
        self.driver.wait_for_transient_element_to_come_and_go(self.toaster)

    def click_no(self):
        self.elements['no_button'].click()
