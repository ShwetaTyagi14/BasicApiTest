from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.Common.add_permissions_dialog import AddPermissionsDialog
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SAMLAppGatewayPermissionsPage(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[.="Permissions" and not(.//*)]'))
    }
    _add_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//a[@buttontext="Add"]'))
    }
    _name_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Name" and contains(@id,"datagridcolumn")]'))
    }
    _grant_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Grant"]'))
    }
    _view_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="View"]'))
    }
    _run_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Run"]'))
    }
    _auto_deploy_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Automatically Deploy"]'))
    }
    _starts_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Starts"]'))
    }
    _expires_column = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Expires"]'))
    }
    _user_rows = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@id,"headercontainer") and .//span[.="Grant"]]/following-sibling::div//table//tr'))
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self._header),
            'add_button': ElementFactory(driver).define_element(self._add_button),
            'name_column': ElementFactory(driver).define_element(self._name_column),
            'grant_column': ElementFactory(driver).define_element(self._grant_column),
            'view_column': ElementFactory(driver).define_element(self._view_column),
            'run_column': ElementFactory(driver).define_element(self._run_column),
            'auto_deploy_column': ElementFactory(driver).define_element(self._auto_deploy_column),
            'starts_column': ElementFactory(driver).define_element(self._starts_column),
            'expires_column': ElementFactory(driver).define_element(self._expires_column),
            'user_rows': ElementFactory(driver).define_element_group(self._user_rows),
        }

        super().__init__(driver, self.elements)

    def click_add_button(self):
        self.elements['add_button'].click()
        return AddPermissionsDialog(self.driver).wait_for_page_to_load()

    def get_displayed_users(self):
        self.elements['user_rows'].get_text().split('\r\n')
