from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator

class WSFedSettingsPage(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[.="Application Settings" and not(.//*)]'))
    }
    _app_url_input = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@name="Url"]'))
    }

    _certificate_dropdown = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@testname="Thumbprint"]/../../../..'))
    }

    _save_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext = "Save"]'))
    }

    _actions = {'locator':
                   ElementSetLocator(element_locator=(
                   By.XPATH, '//a[.="Application Configuration Help"]/..//span[.="Actions" and @class = "x-btn-button"]')),
               'inner_text': 'Actions',
               'supports_validation': False}

    _delete = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    _certificate_rows = {'locator': ElementSetLocator((By.XPATH, f'//li[contains(text(),"- Upload")]/../li'))}

    _cert_table_text = {'locator': ElementSetLocator((By.XPATH, f'//table//input[@name = "Thumbprint"]'))}

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self._header),
            'app_url_input': ElementFactory(driver).define_text_input(self._app_url_input),
            'certificate_dropdown': ElementFactory(driver).define_element(self._certificate_dropdown),
            'save_button': ElementFactory(driver).define_element(self._save_button),
            'actions_btn': ElementFactory(driver).define_multi_select(self._actions),
            'delete_btn': ElementFactory(driver).define_element(self._delete),
            'certificate_rows': ElementFactory(driver).define_element_group(self._certificate_rows),
            'cert_table_text': ElementFactory(driver).define_element(self._cert_table_text)
        }

        super().__init__(driver, self.elements)

    def set_app_url(self, name):
        self.elements['app_url_input'].clear().type(name)

    def get_url(self):
        self.elements['app_url_input'].get_attribute_value('value')

    def get_cert_value(self):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[@itemid="_signingCertDisplay"]//span'))}
        result = ElementFactory(self.driver).define_element(elem_def)
        result.wait_for_visible()
        result = result.get_element()
        return result

    def change_app_cert(self, desired_cert):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['certificate_dropdown'].wait_for_visible()
        self.__persistent_click_element__(self.elements['certificate_dropdown'])
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//ul/li[contains(text(),"{desired_cert}")]'))}
        result = ElementFactory(self.driver).define_element(elem_def)
        result.wait_for_visible()
        self.__persistent_click_element__(result)
        self.click_save_button()
        self.driver.wait_for_loading_mask_to_disappear()

    def click_save_button(self):
        self.elements['save_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def open_actions_menu(self):
        self.__persistent_click_element__(self.elements['actions_btn'])

    def delete_application(self):
        self.open_actions_menu()
        self.elements['delete_btn'].wait_for_visible()
        self.__persistent_click_element__(self.elements['delete_btn'])

    def get_cert_list_from_dropdown(self):
        self.elements['certificate_dropdown'].click()
        rows = self.elements['certificate_rows'].get_element()
        row_results = []
        for row in rows:
            cert_names = row.text.split("\n")[0].lstrip()
            row_results.append(cert_names)
        return row_results

    def get_specific_cert_from_dropdown(self, cert_name):
        results = self.get_cert_list_from_dropdown()
        matching_cert = [s for s in results if f"{cert_name}" in s]
        matching_cert = matching_cert[0]
        return matching_cert

    def get_certificate_table_text(self):
        test_cert_name = self.elements['cert_table_text'].get_attribute_value('value')
        return test_cert_name









