from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SecureWebSessionPage(UIPage):
    view_title = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Secure Web Session"]'))}

    sws_checkbox = {
        'locator':
            ElementSetLocator((By.XPATH, '//input/following-sibling::label[.="Enable Secure Web Session"]'),
                              parent_container_locator=(By.XPATH, f'//label[.="Enable Secure Web Session"]'))
    }

    save_button = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f"//a[@buttontext='Save']"))}

    ok_button = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@dialog_type = "confirm"]//a/span[.="OK"]'))}

    cancel_button = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@dialog_type = "confirm"]//a/span[.="Cancel"]'))}

    configure_sws_link = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[.="Configure SWS policies"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.view_title),
            'view_title': ElementFactory(driver).define_element(self.view_title),
            'sws_checkbox': ElementFactory(driver).define_checkbox(self.sws_checkbox),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'ok_button': ElementFactory(driver).define_element(self.ok_button),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button),
            'configure_sws_link': ElementFactory(driver).define_element(self.configure_sws_link)
        }

        super().__init__(driver, self.elements)

    def check_enable_sws_box(self):
        is_sws_enabled = self.elements['sws_checkbox'].is_checked()
        if not is_sws_enabled:
            self.elements['sws_checkbox'].click()
            self.wait_for_page_to_load()
            self.click_ok_enable_sws()
            self.wait_for_page_to_load()

    def click_save_button(self):
        self.elements['save_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=10)

    def click_ok_enable_sws(self):
        self.elements['ok_button'].click()

    def click_cancel_enable_sws(self):
        self.elements['cancel_button'].click()

    def click_configure_sws_link(self):
        self.elements['configure_sws_link'].click()

    def switch_to_configure_sws_link_tab(self, handle):
        self.driver.switch_to_window(handle)
