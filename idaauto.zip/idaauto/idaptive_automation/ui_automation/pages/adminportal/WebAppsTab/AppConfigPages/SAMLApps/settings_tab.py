from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SAMLAppGatewaySettingsPage(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[.="Settings" and not(.//*)]'))
    }
    _app_name_input = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@name="Name"]'))
    }
    _description = {
        'locator':
            ElementSetLocator((By.XPATH, '//textarea[@name="Description"]'))
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self._header),
            'app_name_input': ElementFactory(driver).define_text_input(self._app_name_input),
            'description': ElementFactory(driver).define_element(self._description),
        }

        super().__init__(driver, self.elements)

    def set_app_name(self, name):
        self.elements['app_name_input'].clear().type(name)

    def get_name(self):
        self.elements['app_name_input'].get_attribute_value('value')

    def get_description(self):
        self.elements['description'].get_text()
