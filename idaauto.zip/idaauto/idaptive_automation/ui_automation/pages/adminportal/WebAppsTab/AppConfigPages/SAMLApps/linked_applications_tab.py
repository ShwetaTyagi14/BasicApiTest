from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SAMLAppGatewayLinkedAppsPage(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Settings"]'))
    }

    _add_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[.="Linked Applications"]/../../../..//a[.="Add"]'))
    }

    _app_name = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@name="DisplayName"]'))
    }

    _app_url = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@name="DeepLinkUrl"]'))
    }

    _finish_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[.="Finish"]'))
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self._header),
            'add_button': ElementFactory(driver).define_element(self._add_button),
            'app_name': ElementFactory(driver).define_text_input(self._app_name),
            'app_url': ElementFactory(driver).define_text_input(self._app_url),
            'finish_button': ElementFactory(driver).define_element(self._finish_button),
        }

        super().__init__(driver, self.elements)

    def click_add_linked_app(self):
        self.elements['add_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def set_linked_app_name(self, app_name):
        self.elements['app_name'].wait_for_visible()
        self.elements['app_name'].clear().type(app_name)

    def set_linked_app_url(self, app_url):
        self.elements['app_url'].wait_for_visible()
        self.elements['app_url'].clear().type(app_url)

    def click_finish_button(self):
        self.elements['finish_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def get_linked_app_status(self, app_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//td[.="{app_name}"]/following-sibling::td//div'))}
        status = ElementFactory(self.driver).define_element(elem_def)
        status = status.get_element()
        return status.text