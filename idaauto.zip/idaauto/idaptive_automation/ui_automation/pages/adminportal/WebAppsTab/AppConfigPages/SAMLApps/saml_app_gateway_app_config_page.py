from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.act_mapping_tab import SAMLAppGatewayAccountMappingPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.app_gateway_tab import SAMLAppGatewayAppGatewayPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.changelog_tab import SAMLAppGatewayChangelogPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.linked_applications_tab import SAMLAppGatewayLinkedAppsPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.permissions_tab import SAMLAppGatewayPermissionsPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.policy_tab import SAMLAppGatewayPolicyPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.provisioning_tab import SAMLAppGatewayProvisioningPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.saml_response_tab import SAMLAppGatewaySAMLResponsePage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.settings_tab import SAMLAppGatewaySettingsPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.workflow_tab import SAMLAppGatewayWorkflowPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.trust_tab import SAMLAppGatewayTrustPage


class SAMLAppGatewayConfigPage(UIPage):
    _settings_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Settings"]'))
    }

    _trust_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Trust"]'))
    }

    _saml_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="SAML Response"]'))
    }

    _permissions_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Permissions"]'))
    }

    _policy_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Policy"]'))
    }

    _act_mapping_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Account Mapping"]'))
    }

    _linked_apps_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Linked Applications"]'))
    }

    _provisioning_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Provisioning"]'))
    }

    _app_gateway_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="App Gateway"]'))
    }

    _workflow_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Workflow"]'))
    }

    _changelog_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Changelog"]'))
    }

    _save_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Save"]'))
    }

    _cancel_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Cancel"]'))
    }

    _status_label = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[preceding-sibling::label[.="Status:"]]'))
    }

    def __init__(self, driver, app_name):
        header = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//label[.="{app_name}"]'))}
        self.elements = {
            'loaded': ElementFactory(driver).define_element(header),
            'status_label': ElementFactory(driver).define_element(self._status_label),
            'settings_tab': ElementFactory(driver).define_search_box(self._settings_tab),
            'trust_tab': ElementFactory(driver).define_element(self._trust_tab),
            'saml_tab': ElementFactory(driver).define_element(self._saml_tab),
            'permissions_tab': ElementFactory(driver).define_element(self._permissions_tab),
            'policy_tab': ElementFactory(driver).define_element(self._policy_tab),
            'act_mapping_tab': ElementFactory(driver).define_element(self._act_mapping_tab),
            'linked_apps_tab': ElementFactory(driver).define_element(self._linked_apps_tab),
            'provisioning_tab': ElementFactory(driver).define_element(self._provisioning_tab),
            'app_gateway_tab': ElementFactory(driver).define_element_group(self._app_gateway_tab),
            'workflow_tab': ElementFactory(driver).define_element_group(self._workflow_tab),
            'changelog_tab': ElementFactory(driver).define_element_group(self._changelog_tab),
            'save_button': ElementFactory(driver).define_element(self._save_button),
            'cancel_button': ElementFactory(driver).define_element(self._cancel_button),
        }

        super().__init__(driver, self.elements)

    def click_settings_tab(self):
        self.elements['settings_tab'].click()
        return SAMLAppGatewaySettingsPage(self.driver).wait_for_page_to_load()

    def click_trust_tab(self):
        self.elements['trust_tab'].click()
        return SAMLAppGatewayTrustPage(self.driver).wait_for_page_to_load()

    def click_saml_response_tab(self):
        self.elements['saml_tab'].click()
        return SAMLAppGatewaySAMLResponsePage(self.driver).wait_for_page_to_load()

    def click_permissions_tab(self):
        self.elements['permissions_tab'].click()
        return SAMLAppGatewayPermissionsPage(self.driver).wait_for_page_to_load()

    def click_policy_tab(self):
        self.elements['policy_tab'].click()
        return SAMLAppGatewayPolicyPage(self.driver).wait_for_page_to_load()

    def click_account_mapping_tab(self):
        self.elements['act_mapping_tab'].click()
        return SAMLAppGatewayAccountMappingPage(self.driver).wait_for_page_to_load()

    def click_linked_apps_tab(self):
        self.elements['linked_apps_tab'].click()
        return SAMLAppGatewayLinkedAppsPage(self.driver).wait_for_page_to_load()

    def click_provisioning_tab(self):
        self.elements['provisioning_tab'].click()
        return SAMLAppGatewayProvisioningPage(self.driver).wait_for_page_to_load()

    def click_app_gateway_tab(self):
        self.elements['app_gateway_tab'].click()
        return SAMLAppGatewayAppGatewayPage(self.driver).wait_for_page_to_load()

    def click_workflow_tab(self):
        self.elements['workflow_tab'].click()
        return SAMLAppGatewayWorkflowPage(self.driver).wait_for_page_to_load()

    def click_changelog_tab(self):
        self.elements['changelog_tab'].click()
        return SAMLAppGatewayChangelogPage(self.driver).wait_for_page_to_load()

    def click_save_button(self):
        self.elements['save_button'].click()
        self.driver.wait_for_transient_element_to_come_and_go((By.XPATH, '//body/div[@class="x-css-shadow" and contains(.,"Modified")]'))
        return self

    def click_cancel_button(self):
        self.elements['cancel_button'].click()
        return self

    def get_app_status(self):
        return self.elements['status_label'].get_text()
