from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from time import sleep


class SAMLAppGatewayTrustPage(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[.="Trust" and not(.//*)]'))
    }
    _idp_metadata_radio = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[./label[.="Identity Provider Configuration"]]//div[3]//input[./following-sibling::label[.="Metadata"]]'))
    }
    _idp_manual_config_radio = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[./label[.="Identity Provider Configuration"]]//div[3]//input[./following-sibling::label[.="Manual Configuration"]]'))
    }
    _sp_metadata_radio = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[./label[.="Service Provider Configuration"]]//div[3]//input[./following-sibling::label[.="Metadata"]]'))
    }
    _sp_manual_config_radio = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Service Provider Configuration"]/following-sibling::div//input[./following-sibling::label[.="Manual Configuration"]]'))
    }
    _copy_idp_url = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//a[@buttontext="Copy URL"]'))
    }
    _sp_md_url = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@name="SpMetadataUrl"]'))
    }
    _sp_md_xml = {
        'locator':
            ElementSetLocator((By.XPATH, '//textarea[@name="SpMetadataXml"]'))
    }
    _load_sp_md_url = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Load"]'))
    }

    _sp_entity_id_url = {'locator': ElementSetLocator((By.XPATH, '//input[@name="Audience"]'))}

    _sp_acs_url = {'locator':ElementSetLocator((By.XPATH, '//input[@name="Url"]'))}

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self._header),
            'idp_metadata_radio': ElementFactory(driver).define_element(self._idp_metadata_radio),
            'idp_manual_config_radio': ElementFactory(driver).define_element(self._idp_manual_config_radio),
            'sp_metadata_radio': ElementFactory(driver).define_element(self._sp_metadata_radio),
            'sp_manual_config_radio': ElementFactory(driver).define_element(self._sp_manual_config_radio),
            'copy_idp_url': ElementFactory(driver).define_element(self._copy_idp_url),
            'sp_md_url': ElementFactory(driver).define_text_input(self._sp_md_url),
            'load_sp_md_url': ElementFactory(driver).define_element(self._load_sp_md_url),
            'sp_md_xml': ElementFactory(driver).define_element(self._sp_md_xml),
            'sp_entity_id_url': ElementFactory(driver).define_text_input(self._sp_entity_id_url),
            'sp_acs_url': ElementFactory(driver).define_text_input(self._sp_acs_url),
        }

        super().__init__(driver, self.elements)

    def copy_idp_md_url(self):
        self.elements['copy_idp_url'].click()
        return self.get_clipboard_contents()

    def set_sp_md_url(self, url):
        self.elements['sp_md_url'].clear().type(url)
        return self

    def load_sp_metadata(self, wait_time=UIPage.SHORT_DELAY):
        self.elements['load_sp_md_url'].click()
        sleep(wait_time)
        return self.elements['sp_md_xml'].get_attribute_value('value')

    def click_sp_manual_config(self):
        self.elements['sp_manual_config_radio'].click()

    def input_sp_urls(self, url):
        self.elements['sp_entity_id_url'].clear().type(url)
        self.elements['sp_acs_url'].clear().type(url)

