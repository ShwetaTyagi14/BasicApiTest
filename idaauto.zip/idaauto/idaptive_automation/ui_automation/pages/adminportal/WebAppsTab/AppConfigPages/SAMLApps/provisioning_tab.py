from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SAMLAppGatewayProvisioningPage(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//span[.="Settings"]'))
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self._header),
        }

        super().__init__(driver, self.elements)
