from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.add_web_apps_dialog import AddWebAppsDialog


class WebAppsPage(UIPage):
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[.="Web Apps" and not(.//*)]'))}

    search_box = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@placeholder="Search All Web Applications"]'),
            parent_container_locator=(
                By.XPATH, '//input[starts-with(@placeholder,"Search All Web Applications" )]/ancestor::div[3]'),
            toggle_locator=(
            By.XPATH, '//input[starts-with(@placeholder,"Search All Web Applications" )]/ancestor::div[3]/div/div/a')),
                          'inner_text': ''}

    add_web_apps_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Add Web Apps"]'))
    }

    column_container_xpath = '//div[contains(@class,"x-panel dataGrid")]/div[.//span[.="Name"] and .//span[.="Type"] ]/ancestor::div[1]'

    name_column = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}//span[.="Name"]'))
    }

    type_column = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}//span[.="Type"]'))
    }

    description_column = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}//span[.="Description"]'))
    }

    provisioning_column = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}//span[.="Provisioning"]'))
    }

    app_gateway_column = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}//span[.="App Gateway"]'))
    }

    status_column = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}//span[.="Status"]'))
    }

    displayed_apps = {
        'locator':
            ElementSetLocator((By.XPATH, f'{column_container_xpath}/div[3]//tbody//tr'))
    }

    actions_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[@itemId="mainContainer"]//a[@buttontext="Actions"]')),
        'supports_validation': False
    }

    clone_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//span[@class="x-menu-item-text " and contains(text(),"Clone")]')),
        'supports_validation': False
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self.header),
            'search_box': ElementFactory(driver).define_search_box(self.search_box),
            'add_web_apps_button': ElementFactory(driver).define_element(self.add_web_apps_button),
            'name_column': ElementFactory(driver).define_element(self.name_column),
            'type_column': ElementFactory(driver).define_element(self.type_column),
            'description_column': ElementFactory(driver).define_element(self.description_column),
            'provisioning_column': ElementFactory(driver).define_element(self.provisioning_column),
            'app_gateway_column': ElementFactory(driver).define_element(self.app_gateway_column),
            'status_column': ElementFactory(driver).define_element(self.status_column),
            'actions_button': ElementFactory(driver).define_element(self.actions_button),
            'clone_button': ElementFactory(driver).define_element(self.clone_button),
            'displayed_apps': ElementFactory(driver).define_element_group(self.displayed_apps),
        }

        super().__init__(driver, self.elements)

    def click_add_web_apps(self):
        self.elements['add_web_apps_button'].click()
        return AddWebAppsDialog(self.driver).wait_for_page_to_load()

    def get_displayed_apps(self):
        return self.elements['displayed_apps'].get_text()

    def click_specific_app(self, app_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//td[.="{app_name}"]/..'))}
        result = ElementFactory(self.driver).define_element(elem_def)
        result.click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def select_specific_app(self, app_name):
        elem_def = {
            'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//td[.="{app_name}"]/preceding-sibling::td'))
        }
        result = ElementFactory(self.driver).define_element(elem_def)
        result.click()
        return self

    def search_for_app(self, app_name):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['search_box'].search_for(app_name)
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_actions_button(self):
        self.elements['actions_button'].click()
        return self

    def click_clone(self):
        self.elements['clone_button'].click()
        elem = (By.XPATH, '//div[starts-with(., "Completed Clone on")]')
        self.driver.wait_for_transient_element_to_come_and_go(elem, wait_for_appearance_time=UIPage.LONG_DELAY)
        return self
