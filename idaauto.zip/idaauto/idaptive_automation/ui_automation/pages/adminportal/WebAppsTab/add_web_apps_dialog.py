from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.confirm_add_web_apps_dialog import ConfirmAddWebAppsDialog
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class AddWebAppsDialog(UIPage):
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[.="Add Web Apps"]'))}

    search_box = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[@placeholder="Search"]'),
                              toggle_locator=(By.XPATH, '//input[@placeholder="Search"]/ancestor::div[3]/div/div/a'))
    }

    close_button = {
        'locator': ElementSetLocator((By.XPATH, '//a[@buttontext="Close"]'))
    }

    base_xpath = '//div[contains(@class,"x-container search-results")]//tr'

    displayed_apps = {
        'locator':
            ElementSetLocator((By.XPATH, f'{base_xpath}//span[@class="app-name"]'))
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self.header),
            'search_box': ElementFactory(driver).define_search_box(self.search_box),
            'displayed_apps': ElementFactory(driver).define_element_group(self.displayed_apps),
            'close_button': ElementFactory(driver).define_element(self.close_button)
        }

        super().__init__(driver, self.elements)

    def add_web_app_by_name(self, name, wait_time=UIPage.MEDIUM_DELAY):
        self.search_for_app(name)
        app = {
            'locator':
                ElementSetLocator((By.XPATH, f'{self.base_xpath}//div[@class="app-result" and .//span[@class="app-name" and @title="{name}"]]/a'))
        }
        ElementFactory(self.driver).define_element(app).click(wait_time)
        return ConfirmAddWebAppsDialog(self.driver).wait_for_page_to_load()

    def search_for_app(self, name):
        self.elements['search_box'].search_for(name)

    def get_displayed_apps(self):
        self.elements['displayed_apps'].get_text().split('\r\n')

    def click_close(self):
        self.elements['close_button'].click()

    def wait_for_apps_page_to_load(self):
        while self.elements['displayed_apps'].get_text() == 0:
            self.wait_for_page_to_load(required=False)

