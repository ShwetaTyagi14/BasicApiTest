from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddMembersDialog(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Add Members"]'))}

    heading = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Add Members"]')),
               'inner_text': 'Add Members'}

    search_box = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search User & Group Start With")]',),
                                    parent_container_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search User & Group Start With")]/ancestor::div[3]'),
                                    toggle_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search User & Group Start With")]/ancestor::div[3]/div/div/a')),
                  'inner_text': ''}

    search_filter_users = {'locator':
                           ElementSetLocator(element_locator=(By.XPATH, '//label[.="Users"]/preceding-sibling::input'),
                                             label_text_locator=(By.XPATH, '//label[.="Users"]'),
                                             parent_container_locator=(By.XPATH, '//label[.="Users"]/ancestor::table[1]')),
                           'label_text': 'Users',
                           'checked': True}

    search_filter_groups = {'locator':
                            ElementSetLocator(element_locator=(By.XPATH, '//label[.="Groups"]/preceding-sibling::input'),
                                              label_text_locator=(By.XPATH, '//label[.="Groups"]'),
                                              parent_container_locator=(By.XPATH, '//label[.="Groups"]/ancestor::table[1]')),
                            'label_text': 'Groups',
                            'checked': True}

    search_filter_roles = {'locator':
                           ElementSetLocator(element_locator=(By.XPATH, '//label[.="Roles"]/preceding-sibling::input'),
                                             label_text_locator=(By.XPATH, '//label[.="Roles"]'),
                                             parent_container_locator=(By.XPATH, '//label[.="Roles"]/ancestor::table[1]')),
                           'label_text': 'Roles',
                           'checked': True}

    search_filter_computers = {'locator':
                               ElementSetLocator(element_locator=(By.XPATH, '//label[.="Computers"]/preceding-sibling::input'),
                                                 label_text_locator=(By.XPATH, '//label[.="Computers"]'),
                                                 parent_container_locator=(By.XPATH, '//label[.="Computers"]/ancestor::table[1]')),
                               'label_text': 'Computers',
                               'checked': False}

    source_idap_directory = {'locator':
                             ElementSetLocator(element_locator=(By.XPATH, '//label[.="CyberArk Cloud Directory"]/preceding-sibling::input'),
                                               label_text_locator=(By.XPATH, '//label[.="CyberArk Cloud Directory"]'),
                                               parent_container_locator=(By.XPATH, '//label[.="CyberArk Cloud Directory"]/ancestor::table[1]')),
                             'label_text': 'CyberArk Cloud Directory',
                             'checked': True}

    source_fds = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//label[.="FDS"]/preceding-sibling::input'),
                                    label_text_locator=(By.XPATH, '//label[.="FDS"]'),
                                    parent_container_locator=(By.XPATH, '//label[.="FDS"]/ancestor::table[1]')),
                  'label_text': 'FDS',
                  'checked': True}

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Add Members"]//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Add Members"]//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    search_box_loading_mask = \
        (By.XPATH,
         '//div[contains(@class, "white-loadmask-indicator") and not(contains(@style, "display: none"))]')

    _search_results = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr')),
        'supports_validation': False
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.heading),
            'search_box': factory(driver).define_search_box(self.search_box),
            'users': factory(driver).define_checkbox(self.search_filter_users),
            'groups': factory(driver).define_checkbox(self.search_filter_groups),
            'roles': factory(driver).define_checkbox(self.search_filter_roles),
            'computers': factory(driver).define_checkbox(self.search_filter_computers),
            'idap_directory': factory(driver).define_checkbox(self.source_idap_directory),
            'fds': factory(driver).define_checkbox(self.source_fds),
            'add_button': factory(driver).define_element(self.add_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'search_results': factory(driver).define_element_group(self._search_results)
        }

        super().__init__(driver, self.elements)

    def select_search_filter(self, filter_name):
        raise NotImplementedError('this method has not been implemented yet')

    def select_source_filter(self, filter_name):
        raise NotImplementedError('this method has not been implemented yet')

    def search_for_user(self, username):
        self.elements['search_box'].clear()
        self.elements['search_box'].search_for(username)
        self.driver.wait_for_loading_mask_to_disappear()

    def wait_for_search_mask_to_disappear(self, wait_for_appearance=UIPage.SHORT_DELAY,
                                          wait_for_disappearance=UIPage.LONG_DELAY):
        self.driver.wait_for_transient_element_to_come_and_go(self.search_box_loading_mask,
                                                              wait_for_appearance_time=wait_for_appearance,
                                                              wait_for_disappearance_time=wait_for_disappearance)

    def select_user_checkbox(self):
        elem_def = {
            'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[contains(@itemid,"resultsView")]//descendant::tr[1]/td[1]'))}
        elem = factory(self.driver).define_element(elem_def)
        try:
            elem.click()
        except AttributeError:
            try:
                self.wait_for_search_mask_to_disappear(wait_for_appearance=UIPage.LONG_DELAY,
                                                       wait_for_disappearance=UIPage.LONG_DELAY)
                elem.click()
            except Exception:
                query = self.driver.get_screenshot_as_png()
                print(f'Intermittent error capture attempted: {query}')
                raise

    def get_search_results(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=2)
        return self.elements['search_results'].get_text()

    def select_search_result_by_name(self, name):
        raise NotImplementedError('this method has not been implemented yet')

    def select_search_result_by_email(self, email):
        raise NotImplementedError('this method has not been implemented yet')

    def is_add_button_disabled(self, name):
        raise NotImplementedError('this method has not been implemented yet')

    def press_add_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['add_button'].wait_for_visible()
        self.elements['add_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def press_cancel_button(self):
        self.elements['cancel_button'].wait_for_visible()
        self.elements['cancel_button'].click()
        self.elements['cancel_button'].wait_for_not_visible()

