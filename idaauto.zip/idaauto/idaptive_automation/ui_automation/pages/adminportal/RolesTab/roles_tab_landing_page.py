from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_add_edit_window import RolesAddEditWindow


class RolesTabPage(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # The UsersTab page is very similar to this page, and would be a good resource for himts

    roles_header = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Roles"]')),
                    'inner_text': 'Roles'}

    search_box = {'locator':
                  ElementSetLocator(
                    element_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search All Roles")]'),
                    parent_container_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search All Roles")]/ancestor::div[3]'),
                    toggle_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search All Roles")]/ancestor::div[3]/div/div/a')),
    }

    add_role_button = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add Role"]')),
                       'inner_text': 'Add Role'}

    add_success_notification = {'locator': ElementSetLocator(
                                        element_locator=(By.XPATH, '//div[contains(text(),"Add role succeeded.")]'))}

    delete_success_notification = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[contains(text(),"Completed Delete on 1 role")]'))}

    toaster_msg = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'top-toast')]"))}

    # this element represents the list of roles displayed
    role_rows = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                               f'//div[starts-with(@id,"headercontainer")][div/div/div[2]/div//span[text()="Name"]]/following-sibling::div/div/table//tr')),
                 'supports_validation': False}

    # this is the Actions button that displays once a role is selected
    actions_btn = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//div[a[@buttontext="Actions"]]')),
                   'inner_text': 'Actions',
                   'supports_validation': False}

    # this is one of the options in the Actions button
    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    no_actions_available = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@id,'menuitem')]"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.roles_header),
            'roles_header': factory(driver).define_element(self.roles_header),
            'search_box': factory(driver).define_search_box(self.search_box),
            'add_role_button': factory(driver).define_element(self.add_role_button),
            'role_rows': factory(driver).define_element_group(self.role_rows),
            'actions_btn': factory(driver).define_multi_select(self.actions_btn),
            'delete': factory(driver).define_element(self.delete),
            'toaster_msg': factory(driver).define_element(self.toaster_msg),
            'add_success_notification': factory(driver).define_element(self.add_success_notification),
            'delete_success_notification': factory(driver).define_element(self.delete_success_notification),
            'no_actions_available': factory(driver).define_element(self.no_actions_available)
        }

        self.driver = driver
        super().__init__(driver, self.elements)

    def get_displayed_roles(self):
        rows = self.elements['role_rows'].get_element()
        return rows

    def select_role_checkbox(self, role_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[td[2][.="{role_name}"]]/td[1]'))}
        factory(self.driver).define_element(elem_def).click()

    def open_role_detail_window_for_role(self, role_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[td[2][.="{role_name}"]]'))}
        factory(self.driver).define_element(elem_def).click()
        return RolesAddEditWindow(self.driver).wait_for_page_to_load()

    def open_actions_menu(self):
        elements = self.driver.find_elements_by_xpath('//a[@buttontext="Actions"]')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
        return self

    def click_delete(self):
        self.elements['delete'].click()

    def open_add_role_window(self):
        self.elements['add_role_button'].click()
        return RolesAddEditWindow(self.driver).wait_for_page_to_load()

    def search_for_role(self, role_name):
        self.elements['search_box'].search_for(role_name)

    def is_role_checked(self, role_name):
        xpath = f'//tr[@test-text="{role_name}"]'
        definition = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        elem_class = element.get_attribute_value('class')
        return 'selected' in elem_class

    def get_no_actions_available_text(self):
        return self.elements['no_actions_available'].get_text()

    def validate_toaster_msg(self):
        self.elements['toaster_msg'].wait_for_visible()
        return self.elements['toaster_msg'].get_text()