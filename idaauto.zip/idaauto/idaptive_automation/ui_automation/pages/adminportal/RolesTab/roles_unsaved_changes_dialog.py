from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class RolesUnsavedChangesDialog(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[@dialog_type="confirm"]'))}

    dialog_text = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'dialog-window-body')]/descendant::span[contains(@id,'container')]"))}

    cancel = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="No"]//following-sibling::a')),
              'inner_text': 'Cancel'}
    yes = {'locator':
           ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Yes"]')),
           'inner_text': 'Yes'}
    no = {'locator':
          ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="No"]')),
          'inner_text': 'No'}
    close = {'locator':
             ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="xclose"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'dialog_text': factory(driver).define_element(self.dialog_text),
            'cancel': factory(driver).define_element(self.cancel),
            'yes': factory(driver).define_element(self.yes),
            'no': factory(driver).define_element(self.no),
            'close': factory(driver).define_element(self.close)
        }

        self.driver = driver
        super().__init__(driver, self.elements)

    def get_unsaved_changes_dialog_text(self):
        return self.elements['dialog_text'].get_text()

    def press_yes(self):
        self.elements['yes'].click()

    def press_no(self):
        self.elements['no'].wait_for_visible()
        self.elements['no'].click()

    def press_cancel(self):
        self.elements['cancel'].click()

    def press_close(self):
        self.elements['close'].click()