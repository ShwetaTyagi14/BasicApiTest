from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation import ElementSetLocator, UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class RolesDeleteDialog(UIPage):
    confirm_delete_dialog = {'locator':
                             ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@id,'confirmwindow') and @dialog_type='confirm']"))
    }
    delete_confirm_dialog_text = {'locator':
                                  ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'x-box-inner') and contains(@id,'confirmwindow')]//span[contains(@id,'container')]/div"))
                                  }
    yes = {'locator':
           ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Yes']"))
           }
    no = {'locator':
          ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='No']"))
          }

    def __init__(self, driver):
        self.driver = driver
        confirm_delete_dialog = factory(driver).define_element(self.confirm_delete_dialog)
        self.elements = {
            self.LOADED_ELEMENT: confirm_delete_dialog,
            'confirm_delete_dialog': factory(driver).define_element(self.confirm_delete_dialog),
            'yes': factory(driver).define_element(self.yes),
            'no': factory(driver).define_element(self.no),
            'delete_confirm_dialog_text': factory(driver).define_element(self.delete_confirm_dialog_text)
        }

        super().__init__(self.driver, self.elements)

    def get_delete_dialog_text(self):
        return self.elements['delete_confirm_dialog_text'].get_text()

    def press_yes(self):
        self.elements['yes'].click()
        self.driver.wait_for_invisible_element(self.confirm_delete_dialog)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def press_no(self):
        self.elements['no'].click()
        self.driver.wait_for_invisible_element(self.confirm_delete_dialog)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def is_yes_enabled(self):
        return self.elements['yes'].is_enabled()

    def is_no_enabled(self):
        return self.elements['no'].is_enabled()