from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.add_members_dialog import AddMembersDialog
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.add_admin_rights_dialog import AddAdminRightsDialog
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.add_assigned_app_dialog import AddAssignedAppsDialog


class RolesAddEditWindow(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # The UserAddEditWindow page is very similar to this page, and would be a good resource for himts
    # You will need an element to represent every element displayed in all 4 tabs in this window, including
    # headers, descriptions, 'learn more' links, etc

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//label[.="Add Role"]')),
              'inner_text': 'Add Role'}

    descr_header = {'locator':
                    ElementSetLocator(element_locator=(
                        By.XPATH, f"//div[contains(@class,'x-component-default') and text()='Description']")),
                    'inner_text': 'Description'}

    name = {'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="Name"]'),
                              label_text_locator=(By.XPATH, '//input[@testname="Name"]/preceding-sibling::div/label')),
            'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    description_field = {'locator':
                         ElementSetLocator(element_locator=(By.XPATH, '//textarea[@testname="Description"]'),
                                           label_text_locator=(By.XPATH, '//textarea[@testname="Description"]/preceding-sibling::div/label')),
                         'validation_error_class': 'x-form-field x-form-text x-form-textarea'}

    members_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//span[contains(@class,'x-tree-node-text') and text()='Members']"),
                                                parent_container_locator=(By.XPATH, f"//span[contains(@class,'x-tree-node-text') and text()='Assigned Applications']/ancestor::td")),
                   'inner_text': 'Members'}

    members_header = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f"//div[contains(@class,'x-component') and .='Members']"))}

    assigned_apps_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//span[contains(@class,'x-tree-node-text') and text()='Assigned Applications']"),
                                                      parent_container_locator=(By.XPATH, f"//span[contains(@class,'x-tree-node-text') and text()='Assigned Applications']/ancestor::td"))
                                 }

    admin_rights_tab = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, '//span[contains(text(),"Administrative Rights")]')),
                        'inner_text': 'Administrative Rights'}

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    save = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//a[@buttontext='Save']"))}

    cancel = {'locator': ElementSetLocator(By.XPATH, f'//a[@buttontext="Cancel"]'),
              'inner_text': 'Cancel'}

    add = {'locator': ElementSetLocator(By.XPATH, f"//a[@buttontext='Add']")}

    toaster_msg = {'locator': ElementSetLocator(By.XPATH, f"//div[contains(@class,'top-toast')]")}

    grid_rows = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f"//div[contains(@id,'jsutil-Form')]//tr[contains(@class,'x-grid-data-row')]"))}

    # this is the Actions button that displays once a role is selected
    actions_btn = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//div[contains(@id,'jsutil-Form')]//a[@buttontext='Actions']")),
                   'inner_text': 'Actions',
                   'supports_validation': False}

    # this is one of the options in the Actions button
    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    # members_header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Members"]')),
    #                   'inner_text': 'Members'}

    members_grid_login_name_column = {'locator':
                                          ElementSetLocator(element_locator=(By.XPATH,
                                                                             f'//span[starts-with(@id, "datagridcolumn") and text() = "Login Name"]')),
                                      'inner_text': 'Login Name'}

    members_grid_member_column = {'locator':
                                      ElementSetLocator(element_locator=(
                                      By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text() = "Member"]')),
                                  'inner_text': 'Member'}

    admin_rights_header = {'locator':
                               ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Administrative Rights"]')),
                           'inner_text': 'Administrative Rights'}

    admin_rights_grid_desc_column = {'locator':
                                         ElementSetLocator(element_locator=(By.XPATH,
                                                                            f'(//span[starts-with(@id, "datagridcolumn") and text()="Description"])')),
                                     'inner_text': 'Description'}

    assigned_apps_header = {'locator':
                                ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Assigned Applications"]')),
                            'inner_text': 'Assigned Applications'}

    assigned_apps_grid_name_column = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, f'(//span[starts-with(@id, "datagridcolumn") and text()="Name"])')),
                                      'inner_text': 'Name'}

    assigned_apps_grid_type_column = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text()="Type"]')),
                                      'inner_text': 'Type'}

    assigned_apps_grid_desc_column = {'locator': ElementSetLocator(element_locator=(By.XPATH,f'(//span[starts-with(@id, "datagridcolumn") and text()="Description"])[2]')),
                                      'inner_text': 'Description'}

    learn_more = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//span[contains(text(),"Learn more")]')),
                  'inner_text': 'Learn more'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.descr_header),
            'header': factory(driver).define_element(self.header),
            'name': factory(driver).define_text_input(self.name),
            'description_field': factory(driver).define_text_input(self.description_field),
            'assigned_apps_tab': factory(driver).define_user_set_filter(self.assigned_apps_tab),
            'add_button': factory(driver).define_element(self.add_button),
            'save': factory(driver).define_element(self.save),
            'cancel': factory(driver).define_element(self.cancel),
            'add': factory(driver).define_element(self.add),
            # 'toaster_msg': factory(driver).define_element(self.toaster_msg),
            'members_header': factory(driver).define_element(self.members_header),
            'actions_btn': factory(driver).define_element(self.actions_btn),
            'delete': factory(driver).define_element(self.delete),
            'grid_rows': factory(driver).define_element_group(self.grid_rows),

            'members': factory(driver).define_element(self.members_tab),
            'admin_rights': factory(driver).define_element(self.admin_rights_tab),
            'learn_more': factory(driver).define_element(self.learn_more),
            'login_name_column': factory(driver).define_element(self.members_grid_login_name_column),
            'member_column': factory(driver).define_element(self.members_grid_member_column),
            'admin_rights_header': factory(driver).define_element(self.admin_rights_header),
            'admin_rights_grid_desc_column': factory(driver).define_element(self.admin_rights_grid_desc_column),
            'assigned_apps_header': factory(driver).define_element(self.assigned_apps_header),
            'type_column': factory(driver).define_element(self.assigned_apps_grid_type_column),
            'assigned_apps_grid_name_column': factory(driver).define_element(self.assigned_apps_grid_name_column),
            'assigned_apps_grid_desc_column': factory(driver).define_element(self.assigned_apps_grid_desc_column)
        }

        super().__init__(driver, self.elements)

    def select_description_tab(self):
        raise NotImplementedError('this method has not been implemented yet')

    def set_role_name(self, name):
        self.elements['name'].clear()
        self.elements['name'].type(name)

    def set_description(self, description):
        raise NotImplementedError('this method has not been implemented yet')

    def select_members_tab(self):
        self.elements['members'].wait_for_visible()
        self.elements['members'].click()

    def open_add_members_window(self):
        self.elements['add_button'].wait_for_visible()
        self.driver.wait_for_clickable_element(self.add_button)
        self.elements['add_button'].click()
        return AddMembersDialog(self.driver).wait_for_page_to_load()

    def get_displayed_members(self, name):
        members = self.elements['grid_rows'].get_element()
        return members

    def select_admin_rights_tab(self):
        self.elements['admin_rights'].click()

    def open_add_admin_rights_window(self):
        self.elements['add_button'].click()
        return AddAdminRightsDialog(self.driver).wait_for_page_to_load()

    def get_displayed_admin_rights(self, name):
        raise NotImplementedError('this method has not been implemented yet')

    def select_assigned_apps_tab(self):
        self.elements['assigned_apps_tab'].click()

    def open_add_apps_window(self):
        self.elements['add_button'].click()
        return AddAssignedAppsDialog(self.driver).wait_for_page_to_load()

    def get_displayed_apps(self, name):
        raise NotImplementedError('this method has not been implemented yet')

    def press_save_button(self):
        self.hover_and_click(element_text='Save')
        self.driver.wait_for_loading_mask_to_disappear()

    def press_cancel_button(self):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='Cancel']"))
        UIPage.__persistent_click_element__(element)

    def hover_and_click(self, element_text):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='{element_text}']"))
        self.driver.hover_over_element(by=(By.XPATH, f"//a[@buttontext='{element_text}']"))
        element.click()
        return self

    def select_checkbox_for_user(self, user_name):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[starts-with(@test-text,'{user_name}')]/td[1]"))}
        factory(self.driver).define_element(elem_def).click()

    def open_actions_menu(self):
        self.elements['actions_btn'].click()

    def click_delete(self):
        self.elements['delete'].click()

    def validate_members_tab_is_loaded(self):
        self.elements['members_header'].wait_for_visible()
        self.elements['learn_more'].wait_for_visible()
        self.elements['add_button'].wait_for_visible()
        self.elements['login_name_column'].wait_for_visible()
        self.elements['member_column'].wait_for_visible()
        return self

    def validate_admin_rights_tab_is_loaded(self):
        self.elements['admin_rights_header'].wait_for_visible()
        self.elements['learn_more'].wait_for_visible()
        self.elements['add_button'].wait_for_visible()
        self.elements['admin_rights_grid_desc_column'].wait_for_visible()
        return self

    def validate_assigned_apps_tab_is_loaded(self):
        self.elements['assigned_apps_header'].wait_for_visible()
        self.elements['add_button'].wait_for_visible()
        self.elements['assigned_apps_grid_name_column'].wait_for_visible()
        self.elements['type_column'].wait_for_visible()
        self.elements['assigned_apps_grid_desc_column'].wait_for_visible()
        return self

    def validate_name_input_text_is_read_only(self, value):
        self.elements[f'{value}'].wait_for_visible()
        read_only = self.elements[f'{value}'].get_attribute_value("readonly")
        return read_only

    def validate_add_button_is_read_only(self):
        self.elements['add_button'].wait_for_visible()
        self.driver.wait_for_clickable_element(self.add_button, wait_time=2)
        self.driver.hover_over_element((By.XPATH, f"//a[@buttontext='Add']"))
        class_text = self.elements['add_button'].get_attribute_value("class")
        if "x-disabled" and "x-item-disabled" and "x-btn-disabled" in class_text:
            return True
        else:
            return class_text
