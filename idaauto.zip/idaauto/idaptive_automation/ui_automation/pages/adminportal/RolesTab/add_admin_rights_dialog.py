from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddAdminRightsDialog(UIPage):
    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Add Rights"]'))}

    heading = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Add Rights"]')),
               'inner_text': 'Add Rights'}

    add_rights_rows = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'//div[starts-with(@id,"headercontainer")][div/div/div[2]/div//span[text()="Description"]]/following-sibling::div/div/table//tr')),
                       'supports_validation': False}
    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Add Rights"]//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Add Rights"]//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.heading),
            'add_rights_rows': factory(driver).define_element_group(self.add_rights_rows),
            'add_button': factory(driver).define_element(self.add_button),
            'cancel_button': factory(driver).define_element(self.cancel_button)
        }

        super().__init__(driver, self.elements)

    def select_admin_right(self, name):
        raise NotImplementedError('this method has not been implemented yet')

    def get_displayed_admin_rights(self):
        rows = self.elements['add_rights_rows'].get_element()
        row_list = []
        for row in rows:
            row_list.append(row.text)
        return [val.strip(' ') for val in row_list]

    def is_add_button_disabled(self):
        raise NotImplementedError('this method has not been implemented yet')

    def press_add_button(self):
        raise NotImplementedError('this method has not been implemented yet')

    def press_cancel_button(self):
        raise NotImplementedError('this method has not been implemented yet')