from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddAssignedAppsDialog(UIPage):

    # These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
    # All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'modal-window') and @viewparttitle='Add Applications']"))}

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f"//span[contains(text(),'Add Applications')]")),
              'inner_text': 'Add Applications'}

    search_app = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f"//input[contains(@placeholder,'Search Applications')]")),
                 }

    magnifier_icon = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH,
                                                         f'//input[@placeholder="Search Applications"]//ancestor::div//a[contains(@class,"search-button")]')),
                 }

    add_apps = {'locator':
                ElementSetLocator(
                          element_locator=(By.XPATH, f"//div[contains(@class,'modal-window') and @viewparttitle='Add Applications']//a[@buttontext='Add']")),
                  }

    cancel_apps = {'locator':
                   ElementSetLocator(
                          element_locator=(By.XPATH, f"//div[contains(@class,'modal-window') and @viewparttitle='Add Applications']//a[@buttontext='Cancel']")),
                  }

    close_modal = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'modal-window') and @viewparttitle='Add Applications']//div[contains(@class,'x-tool-after-title')]"))}

    column_header_name = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'results-grid')]//div[contains(@class,'column-header-last')]"))}

    grid = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'results-grid')]")),
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'search_app': factory(driver).define_text_input(self.search_app),
            'magnifier_icon': factory(driver).define_element(self.magnifier_icon),
            'add_apps': factory(driver).define_element(self.add_apps),
            'cancel_apps': factory(driver).define_element(self.cancel_apps),
            'close_modal': factory(driver).define_element(self.close_modal),
            'column_header_name': factory(driver).define_element(self.column_header_name),
            'grid': factory(driver).define_element(self.grid)
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def search_for_application(self, name):
        self.elements['search_app'].search_for(name)

    def select_application(self, name):
        xpath = f"//tr[contains(@test-text,'{name}')]//div[contains(@class,'x-grid-row-checker')]"
        definition = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        element.click()

    def get_search_results(self, name):
        results = self.driver.find_element(By.XPATH, f"//tr[contains(@test-text,'{name}')]")
        return len(results)

    def is_add_button_enabled(self):
        return self.elements['add_apps'].is_enabled()

    def is_add_button_disabled(self):
        return not self.elements['add_apps'].is_enabled()

    def press_add_button(self):
        self.elements['add_apps'].click()

    def press_cancel_button(self):
        self.elements['cancel_apps'].click()