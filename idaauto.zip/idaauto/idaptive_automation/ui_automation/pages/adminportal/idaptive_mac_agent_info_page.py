from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class IdaptiveMacAgentInfoPage(UIPage):
    title = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[@dialog_type="dialog"]//div[.="Idaptive Mac Cloud Agent"]'))
    }
    text = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[@dialog_type="dialog"]//div[contains(@class,"jsutil-form-paragraph")]//div[contains(.,"Idaptive Mac Cloud Agent version 19.5 or higher")]')),
    }
    close = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[@dialog_type="dialog"]//a[@buttontext="Close"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.title),
            'title': factory(driver).define_element(self.title),
            'text': factory(driver).define_element(self.text),
            'close': factory(driver).define_element(self.close)
        }

        super().__init__(driver, self.elements)

    def get_main_text(self):
        return self.elements['text'].get_text()
