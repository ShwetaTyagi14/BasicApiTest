from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class MappingsDialog(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @viewparttitle="Test Mappings"]'))}

    submit_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Submit"]')),
                     'inner_text': 'Submit'}

    close_button = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Close"]')),
                    'inner_text': 'Close'}

    user_login_name_input = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="TestUserName"]'),
                                     label_text_locator=(By.XPATH, f'//label[contains(text(),"User Login Name")]')),
        'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_text_input(self.user_login_name_input),
            'submit_button': factory(driver).define_element(self.submit_button),
            'dialog': factory(driver).define_element(self.dialog),
            'close_button': factory(driver).define_element(self.close_button),
            'user_login_name_input': factory(driver).define_text_input(self.user_login_name_input),
        }

        super().__init__(driver, self.elements)

    def get_text_message(self):
        return self.elements['text_message'].get_text()

    def click_close(self):
        self.elements['close_button'].click()

    def click_submit(self):
        self.elements['submit_button'].click()

    def get_attribute_value(self, attr_name):
        xpath = f'//div[contains(@class,"modal-window") and @viewparttitle="Test Mappings"]//td[contains(@data-content,"{attr_name}")]/following-sibling::td/div'
        self.driver.wait_for_visible_element(xpath)
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, xpath))}
        return factory(self.driver).define_element(elem_def).get_text()

    def set_user_name_login(self,text):
        self.elements['user_login_name_input'].wait_for_visible()
        self.elements['user_login_name_input'].clear().type(text)