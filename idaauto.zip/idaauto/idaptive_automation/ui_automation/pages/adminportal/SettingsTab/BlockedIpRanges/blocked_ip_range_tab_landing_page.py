from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.CorporateIpRange.add_modify_ip_range_dialog import \
     AddModifyIpRangeDialog
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class BlockedIpRangesPage(UIPage):

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Blocked IP Ranges"]'))}

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    grid_ip_range_column = {'locator':
                            ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text() = "IP Range"]')),
                            'inner_text': 'IP Range'}

    grid_name_column = {'locator':
                        ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text() = "Name"]')),
                        'inner_text': 'Name'}

    ip_range_rows = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[starts-with(@itemid,"basicGrid")]//following-sibling::table//tr'))}

    modify = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Modify"]'))}

    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Delete"]'))}

    actions = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, '//div[a[@buttontext="Actions"]]')),
               'inner_text': 'Actions',
               'supports_validation': False}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.grid_ip_range_column),
            'header': factory(driver).define_element(self.header),
            'add_button': factory(driver).define_element(self.add_button),
            'grid_ip_range_column': factory(driver).define_element(self.grid_ip_range_column),
            'grid_name_column': factory(driver).define_element(self.grid_name_column),
            'ip_range_rows': factory(driver).define_element_group(self.ip_range_rows),
            'modify': factory(driver).define_element(self.modify),
            'delete': factory(driver).define_element(self.delete),
            'actions_btn': factory(driver).define_multi_select(self.actions)
        }

        super().__init__(driver, self.elements)

    def press_add_button(self):
        self.elements['add_button'].click()
        return AddModifyIpRangeDialog(self.driver).wait_for_page_to_load()

    def get_ip_ranges_name(self, ip_range):
        self.driver.wait_for_loading_mask_to_disappear()
        xpath = f'//div[starts-with(@itemid,"basicGrid")]//following-sibling::table//tr//td[@data-content="{ip_range}"]/following-sibling::td/div'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element.get_text()

    def get_ip_ranges_address(self, ip_range):
        xpath = f'//div[starts-with(@itemid,"basicGrid")]//following-sibling::table//tr//td[@data-content="{ip_range}"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element.get_text()

    def select_ip_range_checkbox(self, ip_range):
        elem_def = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f'//div[starts-with(@itemid,"basicGrid")]//'
                      f'following-sibling::table//tr//td[@data-content = "{ip_range}"]//preceding-sibling::td'))}
        factory(self.driver).define_element(elem_def).click()

    def open_actions_menu(self):
        elements = self.driver.find_elements_by_xpath('//a[@buttontext="Actions"]')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
        return self

    def click_modify(self):
        self.elements['modify'].wait_for_visible()
        self.elements['modify'].click()

    def click_delete(self):
        self.elements['delete'].wait_for_visible()
        self.elements['delete'].click()