from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation import UserNameLoginPage
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SettingsCustomizationTenantURLsPage(UIPage):
    add_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add"]'))
    }
    header = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[.="Tenant URLs" and not(.//*)]'))
    }
    description = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//div[.="Use these settings to define an Identity Services URL that is more specific to your organization."]'))
    }
    grid_rows = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[@viewparttitle='Tenant URLs']//table//tr"))}
    grid_first_row = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[@viewparttitle='Tenant URLs']//table//tr[1]/td[1]"))}
    actions_btn = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//div[@viewparttitle='Tenant URLs']//a[@buttontext='Actions']")),
        'inner_text': 'Actions',
        'supports_validation': False}

    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.add_button),
            'header': ElementFactory(driver).define_element(self.header),
            'add_button': ElementFactory(driver).define_element(self.add_button),
            'description': ElementFactory(driver).define_element(self.description),
            'grid_rows': ElementFactory(driver).define_element_group(self.grid_rows),
            'grid_first_row': ElementFactory(driver).define_checkbox(self.grid_first_row),
            'actions_btn': ElementFactory(driver).define_element(self.actions_btn),
            'delete': ElementFactory(driver).define_element(self.delete)
        }
        super().__init__(driver, self.elements)

    def click_add_button(self):
        self.elements['add_button'].wait_for_visible()
        self.elements['add_button'].click()

    def open_specific_tab_actions_menu(self):
        self.elements['actions_btn'].click()

    def click_delete(self):
        self.elements['delete'].click()

    def select_checkbox_for_tenant(self, tenant_name):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[starts-with(@test-text,'{tenant_name}')]/td[1]"))}
        ElementFactory(self.driver).define_element(elem_def).click()

    def set_default_url(self, tenant_name):
        tenant_row = self.driver.wait_for_visible_element((By.XPATH, f"//tr[starts-with(@test-text,'{tenant_name}')]"))
        ActionChains(self.driver).context_click(tenant_row).perform()
        self.driver.click_element((By.XPATH, '//span[text() = "Set as Default URL"]'))
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def get_default_tenant(self, tenant_name):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[starts-with(@test-text,'{tenant_name}')]"))}
        return ElementFactory(self.driver).define_element(elem_def).get_attribute_value('test-id')
