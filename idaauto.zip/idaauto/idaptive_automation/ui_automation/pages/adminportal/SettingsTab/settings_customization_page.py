from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.adminportal.suffix_landing_page import SuffixLandingPage
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.account_customization_page import \
    SettingsAccountCustomizationPage


class SettingsCustomizationPage(UIPage):
    tenant_urls = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Tenant URLs"]'))
    }
    suffix = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Suffix"]'))
    }
    additional_attributes = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Additional Attributes"]'))
    }
    account_customization = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Account Customization"]'))
    }
    system_configuration = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="System Configuration"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.tenant_urls),
            'account_customization': ElementFactory(driver).define_element(self.account_customization),
            'system_configuration': ElementFactory(driver).define_element(self.system_configuration),
            'additional_attributes': ElementFactory(driver).define_element(self.additional_attributes),
            'suffix': ElementFactory(driver).define_element(self.suffix),
            'tenant_urls': ElementFactory(driver).define_element(self.tenant_urls)
        }
        super().__init__(driver, self.elements)

    def click_tenant_urls(self):
        self.elements['tenant_urls'].click()

    def click_account_customization(self):
        self.elements['account_customization'].click()
        return SettingsAccountCustomizationPage(self.driver).wait_for_page_to_load()

    def click_system_configuration(self):
        self.elements['system_configuration'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_additional_attributes(self):
        self.elements['additional_attributes'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_suffix(self):
        self.elements['suffix'].wait_for_visible()
        self.elements['suffix'].click()
        return SuffixLandingPage(self.driver)