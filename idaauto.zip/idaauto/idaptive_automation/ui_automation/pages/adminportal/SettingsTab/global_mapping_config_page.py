from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.google_directory_service_config_page import SettingsUsersGoogleDirectoryServiceConfigPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.ldap_directory_service_config_page import SettingsUsersLDAPDirectoryServiceConfigPage


class GlobalMappingConfigPage(UIPage):
    header = {
        'locator':
        ElementSetLocator((By.XPATH, ''))
    }

    def __init__(self, driver):
        raise NotImplementedError()
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            'group_attribute_value': ElementFactory(driver).define_element(self.group_attribute_value),
            'group_name': ElementFactory(driver).define_element(self.group_name),
            'global_mappings_tab': ElementFactory(driver).define_element(self.global_mappings_tab),
            'add_button': ElementFactory(driver).define_element(self.add_button)
        }
        super().__init__(driver, self.elements)
