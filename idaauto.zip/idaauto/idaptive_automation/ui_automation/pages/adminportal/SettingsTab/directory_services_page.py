from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.google_directory_service_config_page import SettingsUsersGoogleDirectoryServiceConfigPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.ldap_directory_service_config_page import SettingsUsersLDAPDirectoryServiceConfigPage


class SettingsUsersDirectoryServicesPage(UIPage):
    header = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Directory Services" and not(.//*)]'))
    }
    description = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Use these settings to add LDAP or Google as a directory service. Directory services are listed in order of lookup."]'))
    }
    add_ldap_button = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Add LDAP Directory"]'))
    }
    add_google_button = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Add Google Directory"]'))
    }
    change_lookup_order_button = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Change Lookup Order"]'))
    }
    actions_btn = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//div[@viewparttitle='Directory Services']//a[@buttontext='Actions']")),
        'inner_text': 'Actions',
        'supports_validation': False}
    save_lookup_order_button = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Save Lookup Order"]'))
    }
    lookup_order_updated = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[text()="Lookup order updated."]'))
    }
    lookup_order_update_failed = {
        'locator':
        ElementSetLocator((By.XPATH,
                           f'//div[text()="Failed to update lookup order. Changing the lookup order for federated directory service is not supported."]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            'description': ElementFactory(driver).define_element(self.description),
            'add_ldap_button': ElementFactory(driver).define_element(self.add_ldap_button),
            'add_google_button': ElementFactory(driver).define_element(self.add_google_button),
            'actions_btn': ElementFactory(driver).define_element(self.actions_btn),
            'change_lookup_order_button': ElementFactory(driver).define_element(self.change_lookup_order_button),
            'save_lookup_order_button': ElementFactory(driver).define_element(self.save_lookup_order_button),
            'lookup_order_updated': ElementFactory(driver).define_element(self.lookup_order_updated),
            'lookup_order_update_failed': ElementFactory(driver).define_element(self.lookup_order_update_failed)
        }
        super().__init__(driver, self.elements)

    def click_add_ldap_directory(self):
        self.elements['add_ldap_button'].click()
        return SettingsUsersLDAPDirectoryServiceConfigPage(self.driver).wait_for_page_to_load()

    def click_add_google_directory(self):
        self.elements['add_google_button'].click()
        return SettingsUsersGoogleDirectoryServiceConfigPage(self.driver).wait_for_page_to_load()

    def click_change_lookup_order(self):
        self.elements['change_lookup_order_button'].click()

    def click_save_lookup_order(self):
        self.elements['save_lookup_order_button'].click()

    def drag_and_drop_the_directories(self, source, destination):
        source_element = self.driver.find_element_by_xpath(f'//div[text()="{source}"]/parent::td')
        dest_element = self.driver.find_element_by_xpath(f'//div[text()="{destination}"]/parent::td')
        ActionChains(self.driver).click_and_hold(source_element).pause(seconds=10)\
            .move_to_element(dest_element)\
            .pause(seconds=10)\
            .release(dest_element)\
            .perform()

    def select_directory_service(self, directory_service):
        ElementFactory(self.driver).define_element({
            'locator':
            ElementSetLocator((By.XPATH, f'//tr[@test-text="{directory_service}"]/td[1]'))
        }).click()

    def validate_no_actions_displayed(self):
        self.elements['actions_btn'].click()
        return ElementFactory(self.driver).define_element({
            'locator':
            ElementSetLocator((By.XPATH, f'//div[@test-text="No actions available."]'))
        }).is_displayed()

    def validate_all_actions_displayed(self):
        self.elements['actions_btn'].click()
        modify_visible = ElementFactory(self.driver).define_element({
            'locator':
            ElementSetLocator((By.XPATH, f'//div[@test-text="Modify"]'))
        }).is_displayed()

        delete_visible = ElementFactory(self.driver).define_element({
            'locator':
            ElementSetLocator((By.XPATH, f'//div[@test-text="Delete"]'))
        }).is_displayed()
        return [modify_visible, delete_visible]

    def open_directory_service_config_dialog(self, name):
        ElementFactory(self.driver).define_element({
            'locator':
            ElementSetLocator((By.XPATH, f'//div[.="{name}"]'))
        }).click()
        return SettingsUsersLDAPDirectoryServiceConfigPage(self.driver).wait_for_page_to_load()

    def is_add_ldap_directory_displayed(self):
        return self.elements['add_ldap_button'].is_displayed()

    def is_save_lookup_enabled(self):
        return self.elements['save_lookup_order_button'].is_enabled()

    def is_look_up_order_updated_toaster_displayed(self):
        return self.elements['lookup_order_updated'].is_displayed()

    def is_look_up_order_update_failed_toaster_displayed(self, text_msg):
        return ElementFactory(self.driver).define_element({
            'locator':
                ElementSetLocator((By.XPATH, f'//div[.="{text_msg}"]'))
        }).is_displayed()