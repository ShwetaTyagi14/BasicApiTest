from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SettingsUsersLDAPDirectoryServiceConfigPage(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="LDAP Directory Service"]'
    rows_xpath = '//tr'
    header = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[text()="LDAP Directory Service"]'))
    }
    dir_service_name_input = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="serviceInstanceName"]'),
                                     label_text_locator=(By.XPATH, f'//label[contains(text(),"Name")]')),
        'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}
    description = {
        'locator':
        ElementSetLocator((By.XPATH, '//textarea[@name="description"]'))
    }
    dns_host_name_input = {
        'locator':
        ElementSetLocator((By.XPATH, '//input[@name="hostName"]'))
    }
    base_dn_name_input = {
        'locator':
        ElementSetLocator((By.XPATH, '//input[@name="baseDn"]'))
    }
    bind_dn_name_input = {
        'locator':
        ElementSetLocator((By.XPATH, '//input[@name="userName"]'))
    }
    bind_dn_pwd_input = {
        'locator':
        ElementSetLocator((By.XPATH, '//input[@name="password"]'))
    }
    verify_server_cert = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//label[text()="Verify Server Certificate"]/preceding-sibling::input'),
                label_text_locator=(By.XPATH, f'//label[text()="Verify Server Certificate"]'),
                parent_container_locator=(
                    By.XPATH, f'//table[1][tbody/tr/td/div[2]/label[text()="Verify Server Certificate"]]')),
        'label_text': 'Verify Server Certificate',
        'checked': True
    }
    test_conn_btn = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Test Connection"]'))
    }
    save_btn = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Save"]'))
    }
    cancel_btn = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Cancel"]'))
    }
    setting_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//tr[@test-text="Setting"]/descendant::span[text()="Setting"]'))
    }
    mapping_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//tr[@test-text="Mapping"]/descendant::span[text()="Mapping"]'))
    }
    connectors_tab = {
        'locator':
            ElementSetLocator((By.XPATH, '//tr[@test-text="Connectors"]/descendant::span[text()="Connectors"]'))
    }
    learn_more_btn = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[contains(@class,"learn-more-button")]'))
    }
    test_btn = {
        'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Test"]'))
    }
    mapping_editable_attr_value_div = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}{rows_xpath}/td[contains(@class,"editor-column")]/descendant::div'))
    }
    mapping_editable_attr_value_input = {
        'locator':
            ElementSetLocator((By.XPATH, f'//input[@name="attribute"]')),
        'validation_error_class': 'x-form-field x-form-text x-form-focus x-field-form-focus x-field-default-form-focus'
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.dir_service_name_input),
            'header': ElementFactory(driver).define_element(self.header),
            'setting_tab': ElementFactory(driver).define_element(self.setting_tab),
            'mapping_tab': ElementFactory(driver).define_element(self.mapping_tab),
            'connectors_tab': ElementFactory(driver).define_element(self.connectors_tab),
            'dir_service_name_input': ElementFactory(driver).define_text_input(self.dir_service_name_input),
            'description': ElementFactory(driver).define_text_input(self.description),
            'dns_host_name_input': ElementFactory(driver).define_text_input(self.dns_host_name_input),
            'base_dn_name_input': ElementFactory(driver).define_text_input(self.base_dn_name_input),
            'bind_dn_name_input': ElementFactory(driver).define_text_input(self.bind_dn_name_input),
            'bind_dn_pwd_input': ElementFactory(driver).define_text_input(self.bind_dn_pwd_input),
            'verify_server_cert': ElementFactory(driver).define_checkbox(self.verify_server_cert),
            'test_conn_btn': ElementFactory(driver).define_element(self.test_conn_btn),
            'save_btn': ElementFactory(driver).define_element(self.save_btn),
            'cancel_btn': ElementFactory(driver).define_element(self.cancel_btn),
            'learn_more_btn': ElementFactory(driver).define_element(self.learn_more_btn),
            'test_btn': ElementFactory(driver).define_element(self.test_btn),
            'mapping_editable_attr_value_div': ElementFactory(driver).define_element(self.mapping_editable_attr_value_div),
            'mapping_editable_attr_value_input': ElementFactory(driver).define_text_input(self.mapping_editable_attr_value_input)
        }
        super().__init__(driver, self.elements)

    def set_name(self, dsn_name):
        self.elements['dir_service_name_input'].wait_for_visible()
        self.elements['dir_service_name_input'].clear().type(dsn_name)

    def set_description(self, description):
        self.elements['description'].wait_for_visible()
        self.elements['description'].clear().type(description)

    def set_dns_host_name(self, dns_host_name):
        self.elements['dns_host_name_input'].wait_for_visible()
        self.elements['dns_host_name_input'].clear().type(dns_host_name)

    def set_base_dn_name(self, base_dn_name):
        self.elements['base_dn_name_input'].wait_for_visible()
        self.elements['base_dn_name_input'].clear().type(base_dn_name)

    def set_bind_dn_name(self, bind_dn_name):
        self.elements['bind_dn_name_input'].wait_for_visible()
        self.elements['bind_dn_name_input'].clear().type(bind_dn_name)

    def set_bind_dn_pwd(self, bind_dn_pwd):
        self.elements['bind_dn_pwd_input'].wait_for_visible()
        self.elements['bind_dn_pwd_input'].clear().type(bind_dn_pwd)

    def is_server_certificate_checked(self):
        self.elements['verify_server_cert'].wait_for_visible()
        return self.elements['verify_server_cert'].is_checked()

    def click_save(self):
        self.elements['save_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def click_cancel(self):
        self.elements['cancel_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def click_test_connection_button(self):
        self.elements['test_conn_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def is_save_btn_disabled(self):
        cls_atrr_value = self.elements['save_btn'].get_attribute_value('class')
        return 'disabled' in cls_atrr_value

    def is_tab_displayed(self,tab_name):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.driver.wait_for_visible_element(f'//tr[@test-text="{tab_name}"]')
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[@test-text='{tab_name}']"))}
        return ElementFactory(self.driver).define_element(elem_def).get_element() is not None

    def is_tab_focused(self,tab_name):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.driver.wait_for_visible_element(f'//tr[@test-text="{tab_name}"]')
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[@test-text='{tab_name}']"))}
        atr_text = ElementFactory(self.driver).define_element(elem_def).get_attribute_value('class')
        return "row-focused" in atr_text

    def is_setting_tab_focused(self):
        self.is_tab_focused(tab_name='Setting')

    def is_mapping_tab_focused(self):
        self.is_tab_focused(tab_name='Mapping')

    def is_connectors_tab_focused(self):
        self.is_tab_focused(tab_name='Connectors')

    def click_setting_tab(self):
        self.elements['setting_tab'].wait_for_visible()
        self.elements['setting_tab'].click()

    def click_mapping_tab(self):
        self.elements['mapping_tab'].wait_for_visible()
        self.elements['mapping_tab'].click()

    def click_connectors_tab(self):
        self.elements['connectors_tab'].wait_for_visible()
        self.elements['connectors_tab'].click()

    def click_mapping_test_button(self):
        self.elements['test_btn'].wait_for_visible()
        self.elements['test_btn'].click()

    def set_attr_value_to_attribute_name(self, mapping_attr_name, mapping_attr_value):
        unique_rows_xpath = f'//td[contains(@data-content,"{mapping_attr_name}")]/following-sibling::td[contains(@class,"editor-column")]/div'
        self.driver.wait_for_visible_element(unique_rows_xpath)
        div_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, unique_rows_xpath))}
        if ElementFactory(self.driver).define_element(div_def).is_displayed() is True:
            ElementFactory(self.driver).define_element(div_def).click()
            self.elements['mapping_editable_attr_value_input'].wait_for_visible()
            self.elements['mapping_editable_attr_value_input'].clear()
        ElementFactory(self.driver).define_element(div_def).click()
        self.elements['mapping_editable_attr_value_input'].type(mapping_attr_value)

    def get_attr_value_from_attribute_name(self, mapping_attr_name):
        unique_rows_xpath = f'//td[contains(@data-content,"{mapping_attr_name}")]/following-sibling::td[contains(@class,"editor-column")]/div'
        self.driver.wait_for_visible_element(unique_rows_xpath)
        div_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, unique_rows_xpath))}
        if ElementFactory(self.driver).define_element(div_def).is_displayed() is True:
            return ElementFactory(self.driver).define_element(div_def).get_text()

    def click_mapping_tab_learn_more_link(self):
        self.elements['learn_more_btn'].click()
        self.driver.wait_for_new_window()

    def validate_configure_ldap_directory_services_window(self):
        self.driver.switch_to_window_by_title('Configuring LDAP Directory Service')
        return self.driver.title

    def validate_attribute_name_present(self, mapping_attr_name):
        unique_rows_xpath = f'//td[contains(@data-content,"{mapping_attr_name}")]/following-sibling::td[contains(@class,"editor-column")]/div'
        self.driver.wait_for_visible_element(unique_rows_xpath)
        div_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, unique_rows_xpath))}
        return ElementFactory(self.driver).define_element(div_def).is_displayed()