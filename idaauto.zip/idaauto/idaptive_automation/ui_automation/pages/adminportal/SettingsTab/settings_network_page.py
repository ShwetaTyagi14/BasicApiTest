from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.BlockedIpRanges.blocked_ip_range_tab_landing_page import \
    BlockedIpRangesPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.CorporateIpRange.corporate_ip_range_tab_landing_page import \
    CorporateIpRangePage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.IdaptiveConnectors.add_idaptive_connector_dialog import \
    AddIdaptiveConnectorDialog
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SettingsNetworkPage(UIPage):
    cyberark_connectors = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="CyberArk Identity Connectors"]'))
    }
    corporate_ip_range = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Corporate IP Range"]'))
    }
    blocked_ip_ranges = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Blocked IP Ranges"]'))
    }

    add_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add CyberArk Identity Connector"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.cyberark_connectors),
            'cyberark_connectors': ElementFactory(driver).define_element(self.cyberark_connectors),
            'corporate_ip_range': ElementFactory(driver).define_element(self.corporate_ip_range),
            'blocked_ip_ranges': ElementFactory(driver).define_element(self.blocked_ip_ranges),
            'add_button': ElementFactory(driver).define_element(self.add_button)
        }
        super().__init__(driver, self.elements)

    def click_cyberark_connectors(self):
        self.elements['cyberark_connectors'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_corporate_ip_range(self):
        self.elements['corporate_ip_range'].click()
        return CorporateIpRangePage(self.driver).wait_for_page_to_load()

    def click_blocked_ip_ranges(self):
        self.elements['blocked_ip_ranges'].click()
        return BlockedIpRangesPage(self.driver).wait_for_page_to_load()

    def press_add_button(self):
        self.elements['add_button'].click()
        return AddIdaptiveConnectorDialog(self.driver).wait_for_page_to_load()