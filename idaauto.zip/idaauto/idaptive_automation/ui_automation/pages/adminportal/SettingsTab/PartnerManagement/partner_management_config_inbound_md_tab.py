from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.google_directory_service_config_page import SettingsUsersGoogleDirectoryServiceConfigPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.ldap_directory_service_config_page import SettingsUsersLDAPDirectoryServiceConfigPage


class PartnerManagementConfigInboundMDTab(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    loaded_elem = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[.="Use one of the following options to configure IDP settings for this partner." and not(.//*)]'))
    }
    idp_md_url = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[@name="IDPMetadataUrl"]'))
    }
    idp_config_option1 = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[contains(@itemid,"_inboundmeta")]//span[text()="Option 1: Upload IDP configuration from URL"]'))
    }
    idp_config_option2 = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[contains(@itemid,"_inboundmeta")]//span[text()="Option 2: Upload IDP configuration from a file"]'))
    }
    idp_config_option3 = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[contains(@itemid,"_inboundmeta")]//span[text()="Option 3: Manual Configuration"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded_elem),
            'idp_md_url': ElementFactory(driver).define_text_input(self.idp_md_url),
            'idp_config_option1': ElementFactory(driver).define_element(self.idp_config_option1),
            'idp_config_option2': ElementFactory(driver).define_element(self.idp_config_option2),
            'idp_config_option3': ElementFactory(driver).define_element(self.idp_config_option3),
        }
        super().__init__(driver, self.elements)

    def input_idp_config_from_url(self, url):
        self.elements['idp_md_url'].clear().type(url)
        return self

    def validate_idp_config_options_present(self):
        self.elements['idp_config_option1'].wait_for_visible()
        self.elements['idp_config_option2'].wait_for_visible()
        self.elements['idp_config_option3'].wait_for_visible()
        return self

    def get_idp_md_url_state(self):
        class_attr_text = self.elements['idp_md_url'].get_attribute_value('class')
        return "invalid" in class_attr_text
