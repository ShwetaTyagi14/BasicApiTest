from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class PartnerManagementConfigGroupMappingsTab(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    grid_xpath = '//div[@itemid="gridTitle" and contains(text(),"Group Mappings")]'
    rows_xpath = '//tbody/tr[contains(@id,"gridview") and contains(@id,"record") and not(contains(@test-text,"test"))]'
    loaded_elem = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}{grid_xpath}'))
    }
    _add_button = {
        'locator':
            ElementSetLocator((By.XPATH, f'{grid_xpath}//ancestor::div[contains(@class,"dataGrid")]//a[@buttontext="Add"]'))
    }
    group_rows = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}{rows_xpath}'))
    }
    group_attr_value_span = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}{rows_xpath}//td[1]/descendant::span'))
    }
    group_attr_value_input = {
        'locator':
            ElementSetLocator((By.XPATH, f'//input[@name="AttributeValue"]')),
        'validation_error_class': 'x-form-field.x-form-required-field.x-form-text.x-form-invalid-field'
    }
    group_attr_name_span = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}{rows_xpath}//td[2]/descendant::span'))
    }
    group_attr_name_input = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="GroupName"]')),
        'validation_error_class': 'x-form-field.x-form-required-field.x-form-text.x-form-invalid-field'
    }
    group_delete_icon = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}{rows_xpath}'
                                         f'//td[contains(@class,"deletecolumn") and contains(@class,"last")]/descendant::img[contains(@class,"delete-close")]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded_elem),
            'add_button': ElementFactory(driver).define_element(self._add_button),
            'group_rows': ElementFactory(driver).define_element_group(self.group_rows),
            'group_attr_value_input': ElementFactory(driver).define_text_input(self.group_attr_value_input),
            'group_attr_value_span': ElementFactory(driver).define_element(self.group_attr_value_span),
            'group_attr_name_input': ElementFactory(driver).define_text_input(self.group_attr_name_input),
            'group_attr_name_span': ElementFactory(driver).define_element(self.group_attr_name_span),
            'group_delete_icon': ElementFactory(driver).define_ui_image(self.group_delete_icon),
        }

        super().__init__(driver, self.elements)

    def click_add_group(self):
        if self.elements['add_button'].is_displayed() is True:
            self.elements['add_button'].click()
        else:
            elements = self.driver.find_elements_by_xpath('//a[@buttontext="Add"]')
            for item in elements:
                if item.is_displayed() is True:
                    item.click()
        return self

    def set_group_value(self, group_attr_value):
        self.elements['group_attr_value_span'].wait_for_visible()
        if self.elements['group_attr_value_span'].is_displayed() is True:
            self.elements['group_attr_value_span'].click()
        self.elements['group_attr_value_input'].wait_for_visible()
        self.elements['group_attr_value_input'].clear().type(group_attr_value)

    def set_group_name(self, group_name):
        self.elements['group_attr_name_span'].wait_for_visible()
        if self.elements['group_attr_name_span'].is_displayed() is True:
            self.elements['group_attr_name_span'].click()
        self.elements['group_attr_name_input'].wait_for_visible()
        self.elements['group_attr_name_input'].clear().type(group_name)

    def delete_group_field(self):
        self.elements['group_delete_icon'].wait_for_visible()
        self.elements['group_delete_icon'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)