from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.google_directory_service_config_page import SettingsUsersGoogleDirectoryServiceConfigPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.ldap_directory_service_config_page import SettingsUsersLDAPDirectoryServiceConfigPage
from time import sleep


class PartnerManagementConfigSettingTab(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    loaded_elem = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//a[@buttontext="Cancel"]'))
    }
    name_input = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[@name="FederationName"]'))
    }
    federation_type_select = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[ancestor::table[preceding-sibling::div/label[contains(.,"Federation Type")]]]'),
                          label_text_locator=(By.XPATH, f'{modal_xpath}//label[contains(.,"Federation Type")]'),
                          toggle_locator =(By.XPATH, f'{modal_xpath}//td[.//input[@name="FederationType"] and not(.//table)]/following-sibling::td')),
        'options': ['SAML 2.0']
    }
    active_checkbox = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[following-sibling::label[.="Active"]]'))
    }
    domain_name_input = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[@name="Name"]'))
    }
    fed_domains_label = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[contains(.,"Federation Domains") and not(.//div)]'))
    }
    add_fed_domain_button = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//a[@buttontext="Add" and contains(@style,"right: auto")]'))
    }
    add_fed_domain_button2 = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//a[@buttontext="Add" and ./preceding-sibling::table]'))
    }
    domain_name_column = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[contains(@id,"datagridcolumn") and .="Name"]'))
    }
    displayed_fed_domains = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[div/div/div/div/span[contains(@id,"datagridcolumn") and .="Name"]]/following-sibling::div[contains(@class,"x-panel-body")]//table//tr'))
    }
    save_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                   'inner_text': 'Save'}

    nothing_configured = {
        'locator':
            ElementSetLocator((By.XPATH, f'{modal_xpath}//div[contains(text(),"Nothing configured")]'))
    }
    unauthorized_message = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(text(), "You are not authorized to perform this operation. Please contact your IT helpdesk."'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded_elem),
            'name_input': ElementFactory(driver).define_text_input(self.name_input),
            'domain_name_input': ElementFactory(driver).define_text_input(self.domain_name_input),
            'add_fed_domain_button': ElementFactory(driver).define_element(self.add_fed_domain_button),
            'add_fed_domain_button2': ElementFactory(driver).define_element(self.add_fed_domain_button2),
            'federation_type_select': ElementFactory(driver).define_select(self.federation_type_select),
            'active_checkbox': ElementFactory(driver).define_checkbox(self.active_checkbox),
            'displayed_fed_domains': ElementFactory(driver).define_element_group(self.displayed_fed_domains),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'nothing_configured': ElementFactory(driver).define_element(self.nothing_configured),
            'unauthorized_msg':  ElementFactory(driver).define_element(self.unauthorized_message)

        }
        super().__init__(driver, self.elements)

    def enter_partner_name(self, name):
        self.elements['name_input'].clear().type(name)
        return self

    def add_federated_domain(self, name):
        self.elements['add_fed_domain_button'].click()
        self.elements['domain_name_input'].clear().type(name)
        self.elements['add_fed_domain_button2'].click()
        sleep(1)
        return self

    def get_displayed_fed_domains(self):
        return [elem for elem in self.elements['displayed_fed_domains'].get_text().split('\r\n')]


    def is_save_button_disabled(self):
        class_attr_value = self.elements['save_button'].get_attribute_value('class')
        return 'disabled' in class_attr_value

    def validate_fed_type_select_displayed(self):
        self.elements['federation_type_select'].open()
        return self.elements['federation_type_select'].get_options()

    def set_federation_type(self, value):
        if value not in self.federation_type_select['options']:
            raise Exception(f'Option: {value} not found in options: {self.federation_type_select["options"]}')
        self.elements['federation_type_select'].select_option(value)

    def click_save(self):
        self.elements['save_button'].wait_for_visible()
        self.elements['save_button'].click()

    def check_partner_name_invalid(self):
        class_attr_text = self.elements['name_input'].get_attribute_value('class')
        return "invalid" in class_attr_text

    def check_domain_name_invalid(self):
        class_attr_text = self.elements['domain_name_input'].get_attribute_value('class')
        return "invalid" in class_attr_text

    def domain_name_not_configured(self):
        return self.elements['nothing_configured'].is_displayed()

    def validate_permission_error(self):
        self.elements['unauthorized_msg'].wait_for_visible()

    def get_partner_name(self):
        self.elements['name_input'].wait_for_visible()
        return self.elements['name_input'].get_text()
