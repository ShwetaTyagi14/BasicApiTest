from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.error_dialog import ErrorDialog
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_settings_tab import PartnerManagementConfigSettingTab
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_gmappings_tab import PartnerManagementConfigGroupMappingsTab
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_inbound_md_tab import PartnerManagementConfigInboundMDTab
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_outbound_md_tab import PartnerManagementConfigOutboundMDTab
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_authentication_tab import PartnerManagementConfigAuthenticationTab
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_device_os_tab import PartnerManagementConfigDeviceOSTab


class PartnerManagementConfigDialog(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    loaded_elem = {
        'locator':
        ElementSetLocator((By.XPATH, modal_xpath))
    }
    settings_tab = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[.="Settings"]'))
    }
    group_mappings_tab = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[.="Group Mappings"]'))
    }
    inbound_md_tab = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[.="Inbound Metadata"]'))
    }
    outbound_md_tab = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[.="Outbound Metadata"]'))
    }
    authentication_tab = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[.="Authentication"]'))
    }
    device_os_tab = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//span[.="Device OS"]'))
    }
    save_button = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//a[@buttontext="Save"]'))
    }
    cancel_button = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//a[@buttontext="Cancel"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded_elem),
            'settings_tab': ElementFactory(driver).define_element(self.settings_tab),
            'group_mappings_tab': ElementFactory(driver).define_element(self.group_mappings_tab),
            'inbound_md_tab': ElementFactory(driver).define_element(self.inbound_md_tab),
            'outbound_md_tab': ElementFactory(driver).define_element(self.outbound_md_tab),
            'authentication_tab': ElementFactory(driver).define_element(self.authentication_tab),
            'device_os_tab': ElementFactory(driver).define_element(self.device_os_tab),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'cancel_button': ElementFactory(driver).define_element(self.cancel_button),
        }
        super().__init__(driver, self.elements)

    def click_settings_tab(self):
        self.elements['settings_tab'].click()
        return PartnerManagementConfigSettingTab(self.driver).wait_for_page_to_load()

    def click_group_mappings_tab(self):
        self.elements['group_mappings_tab'].click()
        return PartnerManagementConfigGroupMappingsTab(self.driver).wait_for_page_to_load()

    def click_inbound_md_tab(self):
        self.elements['inbound_md_tab'].click()
        return PartnerManagementConfigInboundMDTab(self.driver).wait_for_page_to_load()

    def click_outbound_md_tab(self):
        self.elements['outbound_md_tab'].click()
        return PartnerManagementConfigOutboundMDTab(self.driver).wait_for_page_to_load()

    def click_authentication_tab(self):
        self.elements['authentication_tab'].click()
        return PartnerManagementConfigAuthenticationTab(self.driver).wait_for_page_to_load()

    def click_device_os_tab(self):
        self.elements['device_os_tab'].click()
        return PartnerManagementConfigDeviceOSTab(self.driver).wait_for_page_to_load()

    def click_save(self):
        self.elements['save_button'].click()

    def try_click_save(self):
        self.elements['save_button'].click()
        return ErrorDialog(self.driver).wait_for_page_to_load()

    def click_cancel(self):
        self.elements['cancel_button'].click()

    def switching_from_settings_tab_to_group_mappings(self):
        """ case specific without filling data in Settings tab """
        self.elements['group_mappings_tab'].click()

    def switching_from_inbound_tab_to_outbound_md(self):
        """ case specific without filling data in Settings tab """
        self.elements['outbound_md_tab'].click()