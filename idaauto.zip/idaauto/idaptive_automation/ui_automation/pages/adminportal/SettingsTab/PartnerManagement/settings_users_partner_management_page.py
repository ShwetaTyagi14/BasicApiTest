from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_page import PartnerManagementConfigDialog
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partners_tab import SettingsUsersPartnersTab
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.global_mappings_tab import SettingsUsersGlobalMappingsTab


class SettingsUsersPartnerManagementPage(UIPage):
    header = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Partner Management" and not(.//*)]'))
    }
    description = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Use these settings to define and manage partner federation (sharing your Identity Services tenant with your business partners)."]'))
    }
    partners_tab = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Partners"]'))
    }
    global_mappings_tab = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Global Mappings"]'))
    }
    learn_more_link = {
        'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Learn more'))
    }

    partner_rows = {
        'locator':
            ElementSetLocator((By.XPATH,
                               '//div[contains(@class,"tab-root")]//table//tbody[contains(@id,"body")]//tr')),
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            'description': ElementFactory(driver).define_element(self.description),
            'partners_tab': ElementFactory(driver).define_element(self.partners_tab),
            'global_mappings_tab': ElementFactory(driver).define_element(self.global_mappings_tab),
            'learn_more_link': ElementFactory(driver).define_element(self.learn_more_link),
            'partner_rows': ElementFactory(driver).define_element_group(self.partner_rows)
        }
        super().__init__(driver, self.elements)

    def click_partners_tab(self):
        self.elements['partners_tab'].click()
        return SettingsUsersPartnersTab(self.driver).wait_for_page_to_load()[0]

    def click_global_mappings_tab(self):
        self.elements['global_mappings_tab'].click()
        return SettingsUsersGlobalMappingsTab(self.driver).wait_for_page_to_load()[0]

    def click_learn_more_link(self):
        self.elements['learn_more_link'].click()
        self.driver.wait_for_new_window()

    def validate_adding_partner_window(self):
        self.driver.switch_to_window_by_title('Adding a partner')
        return self.driver.title

    def get_displayed_partners(self):
        rows = self.elements['partner_rows'].get_element()
        return rows
