from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.google_directory_service_config_page import SettingsUsersGoogleDirectoryServiceConfigPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.ldap_directory_service_config_page import SettingsUsersLDAPDirectoryServiceConfigPage


class PartnerManagementConfigOutboundMDTab(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    loaded_elem = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//div[.="Use one of the following options to provide IDP configuration settings to partners with whom you will federate." and not(.//*)]'))
    }
    idp_config_option1 = {
        'locator':
            ElementSetLocator((By.XPATH,
                               f'{modal_xpath}//div[contains(@itemid,"_outboundmeta")]//span[text()="Option 1: Service Provider Metadata URL"]'))
    }
    idp_config_option2 = {
        'locator':
            ElementSetLocator((By.XPATH,
                               f'{modal_xpath}//div[contains(@itemid,"_outboundmeta")]//span[text()="Option 2: Download Service Provider Metadata"]'))
    }
    idp_config_option3 = {
        'locator':
            ElementSetLocator((By.XPATH,
                               f'{modal_xpath}//div[contains(@itemid,"_outboundmeta")]//span[text()="Option 3: Manual Configuration"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded_elem),
            'idp_config_option1': ElementFactory(driver).define_element(self.idp_config_option1),
            'idp_config_option2': ElementFactory(driver).define_element(self.idp_config_option2),
            'idp_config_option3': ElementFactory(driver).define_element(self.idp_config_option3),
        }
        super().__init__(driver, self.elements)

    def validate_idp_config_options_present(self):
        self.elements['idp_config_option1'].wait_for_visible()
        self.elements['idp_config_option2'].wait_for_visible()
        self.elements['idp_config_option3'].wait_for_visible()
        return self

