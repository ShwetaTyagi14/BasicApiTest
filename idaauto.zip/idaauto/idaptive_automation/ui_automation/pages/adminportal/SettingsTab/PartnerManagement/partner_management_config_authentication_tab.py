from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class PartnerManagementConfigAuthenticationTab(UIPage):
    _modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    _loaded_elem = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//label[.="Map federated user to existing directory user"]'))
    }
    _map_fed_user_select = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//input[@name="MapUsers"]'),
                              label_text_locator=(
                              By.XPATH, f'{_modal_xpath}//label[.="Map federated user to existing directory user"]'),
                              toggle_locator=(By.XPATH,
                                              '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//td[.//input[@name="MapUsers"] and not(.//table)]/following-sibling::td')),
        'options': ['Disabled', 'Optional', 'Required']
    }
    _map_directory_user_select = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//input[@name="MapUserBy"]'),
                              label_text_locator=(
                              By.XPATH, f'{_modal_xpath}//label[.="Directory user mapping attribute"]'),
                              toggle_locator=(By.XPATH,
                                              '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//td[.//input[@name="MapUserBy"] and not(.//table)]/following-sibling::td')),
        'options': ['Name', 'Uuid']
    }
    _fed_user_map_attr = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//input[@name="MapUserAttribute"]'))
    }
    _url_pattern_field = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//input[@testname="UrlPattern"]'))
    }
    _map_preferred_directory_service_select = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//input[@name="MapUserDirectoryService"]'),
                              label_text_locator=(By.XPATH, f'{_modal_xpath}//label[.="Preferred Directory Service"]'),
                              toggle_locator=(By.XPATH,
                                              f'//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//td[.//input[@name="MapUserDirectoryService"] and not(.//table)]/following-sibling::td')),
        'options': ['Any Directory Service', 'CyberArk Cloud Directory', 'LDAP: AppsLDAP5']
    }
    _url_directing = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Enable URL Redirecting"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, '//label[.="Enable URL Redirecting"]'),
                              parent_container_locator=(By.XPATH, '//label[.="Enable URL Redirecting"]/ancestor::table[1]')),
            'label_text': 'Enable URL Redirecting',
            'checked': False
    }
    _update_cloud_users_with_fed_user_attr = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Update cloud users with federated user attributes"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, '//label[.="Update cloud users with federated user attributes"]'),
                              parent_container_locator=(By.XPATH, '//label[.="Update cloud users with federated user attributes"]/ancestor::table[1]')),
            'label_text': 'Update cloud users with federated user attributes',
            'checked': False
    }
    _add_mapped_users_to_fed_group = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Add mapped users to federated groups"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, '//label[.="Add mapped users to federated groups"]'),
                              parent_container_locator=(By.XPATH, '//label[.="Add mapped users to federated groups"]/ancestor::table[1]')),
            'label_text': 'Add mapped users to federated groups',
            'checked': False
    }
    _allow_users_to_map_in_other_feds = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Allow mapping to users in other federations"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, '//label[.="Allow mapping to users in other federations"]'),
                              parent_container_locator=(By.XPATH, '//label[.="Allow mapping to users in other federations"]/ancestor::table[1]')),
            'label_text': 'Allow mapping to users in other federations',
            'checked': False
    }
    _create_cloud_user_if_unable_to_map = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Create cloud user if unable to map"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, '//label[.="Create cloud user if unable to map"]'),
                              parent_container_locator=(By.XPATH, '//label[.="Create cloud user if unable to map"]/ancestor::table[1]')),
            'label_text': 'Create cloud user if unable to map',
            'checked': False
    }
    save = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//a[@buttontext="Save"]'))
    }
    cancel = {
        'locator':
            ElementSetLocator((By.XPATH, f'{_modal_xpath}//a[@buttontext="Cancel"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self._loaded_elem),
            'fed_user_map_attr': ElementFactory(driver).define_text_input(self._fed_user_map_attr),
            'url_directing': ElementFactory(driver).define_checkbox(self._url_directing),
            'url_pattern_field': ElementFactory(driver).define_text_input(self._url_pattern_field),
            'update_cloud_users_with_fed_user_attr': ElementFactory(driver).define_checkbox(
                self._update_cloud_users_with_fed_user_attr),
            'add_mapped_users_to_fed_group': ElementFactory(driver).define_checkbox(
                self._add_mapped_users_to_fed_group),
            'create_cloud_user_if_unable_to_map': ElementFactory(driver).define_checkbox(
                self._create_cloud_user_if_unable_to_map),
            'allow_users_to_map_in_other_feds': ElementFactory(driver).define_checkbox(
                self._allow_users_to_map_in_other_feds),
            'map_fed_user_select': ElementFactory(driver).define_select(self._map_fed_user_select),
            'map_directory_user_select': ElementFactory(driver).define_select(self._map_directory_user_select),
            'map_preferred_directory_service': ElementFactory(driver).define_select(
                self._map_preferred_directory_service_select),
            'save': ElementFactory(driver).define_element(self.save),
            'cancel': ElementFactory(driver).define_element(self.cancel),
        }
        super().__init__(driver, self.elements)

    def set_map_federated_user(self, value):
        if value not in self._map_fed_user_select['options']:
            raise Exception(f'Option: {value} not found in options: {self._map_fed_user_select["options"]}')
        self.elements['map_fed_user_select'].select_option(value)

    def set_map_directory_user(self, value):
        if value not in self._map_directory_user_select['options']:
            raise Exception(f'Option: {value} not found in options: {self._map_directory_user_select["options"]}')
        self.elements['map_directory_user_select'].select_option(value)

    def set_map_preferred_directory_service(self, value):
        if value not in self._map_preferred_directory_service_select['options']:
            raise Exception(
                f'Option: {value} not found in options: {self._map_preferred_directory_service_select["options"]}')
        self.elements['map_preferred_directory_service'].select_option(value)

    def map_preferred_dir_service_displayed(self):
        self.elements['map_preferred_directory_service'].open()
        return self.elements['map_preferred_directory_service'].get_options()

    def fed_user_map_attr_displayed(self):
        return self.elements['fed_user_map_attr'].is_displayed()

    def directory_user_attr_displayed(self):
        return self.elements['map_directory_user_select'].is_displayed()

    def map_directory_user_attr_displayed(self):
        self.elements['map_directory_user_select'].open()
        return self.elements['map_directory_user_select'].get_options()

    def map_fed_user_select_displayed(self):
        self.elements['map_fed_user_select'].open()
        return self.elements['map_fed_user_select'].get_options()

    def preferred_directory_service_displayed(self):
        self.elements['map_preferred_directory_service'].wait_for_visible()
        return self.elements['map_preferred_directory_service'].is_displayed()

    def set_fed_user_map_attr(self, value):
        self.elements['fed_user_map_attr'].wait_for_visible()
        self.elements['fed_user_map_attr'].clear().type(value)

    def is_save_button_disabled(self):
        class_attr_text = self.elements['save'].get_attribute_value('class')
        return "disabled" in class_attr_text

    def validate_url_pattern_field_shown(self):
        self.elements['url_directing'].wait_for_visible()
        self.elements['url_directing'].check()
        return self.elements['url_pattern_field'].is_displayed()

    def set_url_pattern_field_value(self, value):
        self.validate_url_pattern_field_shown()
        self.elements['url_pattern_field'].clear().type(value)

    def validate_update_cloud_users_with_fed_user_attr_shown(self, value):
        self.set_map_federated_user(value)
        return self.elements['update_cloud_users_with_fed_user_attr'].is_displayed()

    def validate_create_cloud_user_if_unable_to_map_shown(self, value):
        self.set_map_federated_user(value)
        return self.elements['create_cloud_user_if_unable_to_map'].is_displayed()

    def get_fed_user_map_attr_value(self):
        return self.elements['fed_user_map_attr'].get_attribute_value('value')

    def is_fed_user_map_attr_editable(self):
        self.elements['fed_user_map_attr'].click()
        class_attr_text = self.elements['fed_user_map_attr'].get_attribute_value('class')
        return "focus" in class_attr_text



