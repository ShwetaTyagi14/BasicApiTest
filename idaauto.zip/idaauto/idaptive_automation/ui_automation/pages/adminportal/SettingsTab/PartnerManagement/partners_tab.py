from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_config_page import PartnerManagementConfigDialog


class SettingsUsersPartnersTab(UIPage):
    _container = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Partners"]'))
    }
    _name_column = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Partners"]//span[contains(.,"Name")]'))
    }
    _type_column = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Partners"]//span[contains(.,"Type")]'))
    }
    _domain_column = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Partners"]//span[contains(.,"Domain")]'))
    }
    _status_column = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Partners"]//span[contains(.,"Status")]'))
    }
    _add_button = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Add"]'))
    }
    _dp_xpath = '//div[@viewparttitle="Partners"]//table[contains(@id,"gridview")]//tr'
    _displayed_partners = {
        'locator':
            ElementSetLocator((By.XPATH, _dp_xpath))
    }
    delete = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Delete"]'))}

    modify = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Modify"]'))}

    nothing_configured = {
        'locator':
            ElementSetLocator((By.XPATH, f'//div[contains(text(),"No federations configured.")]'))
    }
    delete_toaster = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[text()='Completed Delete on 1 partner.']"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self._container),
            'name_column': ElementFactory(driver).define_element(self._name_column),
            'type_column': ElementFactory(driver).define_element(self._type_column),
            'domain_column': ElementFactory(driver).define_element(self._domain_column),
            'status_column': ElementFactory(driver).define_element(self._status_column),
            'displayed_partners': ElementFactory(driver).define_element_group(self._displayed_partners),
            'add_button': ElementFactory(driver).define_element(self._add_button),
            'delete': ElementFactory(driver).define_element(self.delete),
            'modify': ElementFactory(driver).define_element(self.modify),
            'nothing_configured': ElementFactory(driver).define_element(self.nothing_configured),
            'delete_toaster': ElementFactory(driver).define_element(self.delete_toaster)
        }
        super().__init__(driver, self.elements)

    def click_add_partner(self):
        self.elements['add_button'].click()
        return PartnerManagementConfigDialog(self.driver).wait_for_page_to_load()

    def get_displayed_partners(self):
        elems = self.elements['displayed_partners'].get_element()
        partners = {}
        if elems is None:
            return partners
        for elem in elems:
            partner = elem.text.split('\n')
            name = partner[0].strip()
            partners[name] = {
                'name': name,
                'type': partner[1].strip(),
                'domain': partner[2].strip(),
                'status': partner[3].strip()
            }
        return partners

    def select_partner_by_name(self, name):
        elem = ElementFactory(self.driver).define_td_checkbox({
            'locator':
                ElementSetLocator((By.XPATH, f'//div[@viewparttitle="Partners"]//table[contains(@id,"gridview")]//tr//td[.="{name}"]/preceding-sibling::td'),
                                  parent_container_locator=(By.XPATH, f'//div[@viewparttitle="Partners"]//table[contains(@id,"gridview")]//tr[.//td[.="{name}"]]'))
        })
        elem.select()

    def open_partner_config_by_name(self, name):
        elem = ElementFactory(self.driver).define_element({
            'locator':
                ElementSetLocator((By.XPATH, f'//div[@viewparttitle="Partners"]//table[contains(@id,"gridview")]//tr//td[.="{name}"]'))
        })
        elem.click()

    def click_actions_button(self):
        elements = self.driver.find_elements_by_xpath('//a[@buttontext="Actions"]')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
        return self

    def click_delete(self):
        self.elements['delete'].wait_for_visible()
        self.elements['delete'].click()

    def click_modify(self):
        self.elements['modify'].wait_for_visible()
        self.elements['modify'].click()

    def partner_name_not_configured(self):
        return self.elements['nothing_configured'].is_displayed()

    def validate_delete_partner_toaster(self):
        return self.elements['delete_toaster'].is_displayed()