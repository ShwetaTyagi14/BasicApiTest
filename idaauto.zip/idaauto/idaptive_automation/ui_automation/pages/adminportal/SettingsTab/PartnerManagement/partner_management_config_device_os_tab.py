from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.google_directory_service_config_page import SettingsUsersGoogleDirectoryServiceConfigPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.ldap_directory_service_config_page import SettingsUsersLDAPDirectoryServiceConfigPage


class PartnerManagementConfigDeviceOSTab(UIPage):
    modal_xpath = '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]'
    loaded_elem = {
        'locator':
        ElementSetLocator((By.XPATH, f'//div[.="Select which device operating systems this federation applies to." and not(.//*)]'))
    }
    any_device = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[following-sibling::label[.="Any Device"]]'),
                          label_text_locator=(By.XPATH, f'{modal_xpath}//label[contains(.,"Any Device")]'),
                          parent_container_locator=(By.XPATH, '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//table[contains(@class,"checkboxgroup-form") and .//input[following-sibling::label[.="Any Device"]]]')),
        'label_text': 'Any Device',
        'checked': True
    }
    specific_device_types = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[following-sibling::label[.="Specific Device Types"]]'),
                          label_text_locator=(By.XPATH, f'{modal_xpath}//label[contains(.,"Specific Device Types")]'),
                          parent_container_locator=(By.XPATH, '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//table[contains(@class,"checkboxgroup-form") and .//input[following-sibling::label[.="Specific Device Types"]]]')),
        'label_text': 'Specific Device Types',
        'checked': False
    }
    android = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[following-sibling::label[.="Android"]]'),
                          label_text_locator=(By.XPATH, f'{modal_xpath}//label[.="Android"]'),
                          parent_container_locator=(By.XPATH, '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//table[contains(@class,"checkboxgroup-form") and .//input[following-sibling::label[.="Android"]]]')),
        'label_text': 'Specific Device Types'
    }
    iOS = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[following-sibling::label[.="iOS"]]'),
                          label_text_locator=(By.XPATH, f'{modal_xpath}//label[.="iOS"]'),
                          parent_container_locator=(By.XPATH, '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//table[contains(@class,"checkboxgroup-form") and .//input[following-sibling::label[.="iOS"]]]')),
        'label_text': 'Specific Device Types'
    }
    all_others = {
        'locator':
        ElementSetLocator((By.XPATH, f'{modal_xpath}//input[following-sibling::label[.="All Others"]]'),
                          label_text_locator=(By.XPATH, f'{modal_xpath}//label[.="All Others"]'),
                          parent_container_locator=(By.XPATH, '//div[contains(@class,"modal-window") and @viewparttitle="Partner Management"]//table[contains(@class,"checkboxgroup-form") and .//input[following-sibling::label[.="All Others"]]]')),
        'label_text': 'Specific Device Types'
    }

    def __init__(self, driver):
        self.specific_device_types['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    ElementFactory(driver).define_checkbox(self.android),
                    ElementFactory(driver).define_checkbox(self.iOS),
                    ElementFactory(driver).define_checkbox(self.all_others)
                ]
            }
        ]
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.loaded_elem),
            'any_device': ElementFactory(driver).define_checkbox(self.any_device),
            'specific_device_types': ElementFactory(driver).define_checkbox(self.specific_device_types),
        }
        super().__init__(driver, self.elements)

    def select_any_device(self):
        self.elements['any_device'].check()
        return self

    def select_specific_device_types(self):
        self.elements['specific_device_types'].check()
        return self

    def select_android(self):
        self.elements['specific_device_types'].grandchild(0, 0).check()
        return self

    def select_ios(self):
        self.elements['specific_device_types'].grandchild(0, 1).check()
        return self

    def select_all_others(self):
        self.elements['specific_device_types'].grandchild(0, 2).check()
        return self

    def get_selected_device_types(self):
        return {
            'Any Device': self.elements['any_device'].is_checked(),
            'Specific Device Types': self.elements['specific_device_types'].is_checked(),
            'Android': self.elements['specific_device_types'].grandchild(0, 0).is_checked(),
            'iOS': self.elements['specific_device_types'].grandchild(0, 1).is_checked(),
            'All Others': self.elements['specific_device_types'].grandchild(0, 2).is_checked(),
        }
