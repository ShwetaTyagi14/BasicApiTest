from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SettingsCustomizationAddTenantURLsPage(UIPage):
    dialog = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[contains(@class,"modal-window")]'))
    }
    url_name = {
        'locator':
        ElementSetLocator((By.XPATH, '//input[@name="cnamePrefix" and @placeholder="enter-a-unique-name"]'))
    }
    header = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Create Tenant URL"]'))
    }
    complete_url_label = {
        'locator':
            ElementSetLocator((By.XPATH, '//label[.="Complete URL will be:" and not(.//*)]'))
    }
    display_url = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[@testname="displayURL"]'))
    }
    complete_url = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="https://enter-a-unique-name.my-qa.centrify.com" and not(.//*)]'))
    }
    description = {'locator':
                   ElementSetLocator((By.XPATH, '//div[.="Enter a name in the field below to create a tenant specific URL. The URL will be validated during save to ensure it is not already in use (note: please allow up to 20 minutes for DNS replication)." and not(.//*)]'))
    }
    save = {'locator':
            ElementSetLocator((By.XPATH, '//a[@buttontext="Save"]'))
    }
    cancel = {'locator':
              ElementSetLocator((By.XPATH, '//a[@buttontext="Cancel"]'))
            }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.complete_url_label),
            'dialog': ElementFactory(driver).define_element(self.dialog),
            'description': ElementFactory(driver).define_element(self.description),
            'header': ElementFactory(driver).define_element(self.header),
            'url_name': ElementFactory(driver).define_text_input(self.url_name),
            'complete_url_label': ElementFactory(driver).define_element(self.complete_url_label),
            'complete_url': ElementFactory(driver).define_element(self.complete_url),
            'display_url': ElementFactory(driver).define_element(self.display_url),
            'save': ElementFactory(driver).define_element(self.save),
            'cancel': ElementFactory(driver).define_element(self.cancel)
        }
        super().__init__(driver, self.elements)

    def set_url_name(self, url_name):
        self.elements['url_name'].clear()
        self.elements['url_name'].type(url_name)

    def press_save(self):
        self.driver.wait_for_clickable_element(self.save)
        self.elements['save'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def get_display_url(self):
        self.elements['display_url'].wait_for_visible()
        return self.elements['display_url'].get_text()