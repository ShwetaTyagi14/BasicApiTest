from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.global_mapping_config_page import GlobalMappingConfigPage


class SettingsUsersGlobalMappingsTab(UIPage):
    container = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Global Mappings"]'))
    }
    value_column = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Global Mappings"]//span[contains(.,"Group Attribute Value")]'))
    }
    name_column = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[@viewparttitle="Global Mappings"]//span[contains(.,"Group Name")]'))
    }
    add_button = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[@buttontext="Add"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.name_column),
            'value_column': ElementFactory(driver).define_element(self.value_column),
            'name_column': ElementFactory(driver).define_element(self.name_column),
            'add_button': ElementFactory(driver).define_element(self.add_button),
        }
        super().__init__(driver, self.elements)

    def click_add_global_mapping(self):
        self.elements['add_button'].click()
        return GlobalMappingConfigPage(self.driver).wait_for_page_to_load()
