from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ConnectionErrorDialog(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window") and @dialog_type="wait"]'))}

    close_button = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Close"]')),
                    'inner_text': 'Close'}

    text_message = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//descendant::div[contains(@class,"state-text")]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.text_message),
            'dialog': factory(driver).define_element(self.dialog),
            'close_button': factory(driver).define_element(self.close_button),
            'text_message': factory(driver).define_element(self.text_message),
        }

        super().__init__(driver, self.elements)

    def get_text_message(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.driver.wait_for_invisible_element((By.XPATH, '//div[contains(text(),"Please wait while the connection is tested...")]'), wait_time=UIPage.LONG_DELAY)
        return self.elements['text_message'].get_text()

    def click_close(self):
        self.elements['close_button'].click()

    def validate_text_message(self):
        self.elements['text_message'].wait_for_visible()
        return self.elements['text_message'].is_displayed()