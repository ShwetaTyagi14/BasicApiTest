from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddModifyIpRangeDialog(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Add IP Range"]')),
              'inner_text': 'Add IP Range'}

    name = {'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Label"]'),
                              label_text_locator=(By.XPATH, '//input[@name="Label"]/preceding-sibling::div'))}

    ip_range = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, '//input[@name="value"]'),
                                  label_text_locator=(By.XPATH, '//input[@name="value"]/ancestor::div[2]//label')),
                'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    ok_button = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="OK"]')),
                 'inner_text': 'OK'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'name': factory(driver).define_text_input(self.name),
            'ip_range': factory(driver).define_text_input(self.ip_range),
            'ok_button': factory(driver).define_element(self.ok_button),
            'cancel_button': factory(driver).define_element(self.cancel_button)
        }

        super().__init__(driver, self.elements)

    def set_ip_range_name(self, name):
        self.elements['name'].clear()
        self.elements['name'].type(name)

    def set_ip_range_address(self, ip_address):
        self.elements['ip_range'].clear()
        self.elements['ip_range'].type(ip_address)

    def press_ok_button(self):
        self.elements['ok_button'].wait_for_visible()
        self.elements['ok_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def press_cancel_button(self):
        self.elements['cancel_button'].click()

    def is_confirm_error_icon_displayed(self):
        xpath = f'//li//ancestor::div[@role="alert" and @aria-live="polite"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element.is_displayed()

    def set_name_as_balnk_space(self, value=Keys.SPACE):
        self.elements['name'].clear()
        self.elements['name'].type(value)
