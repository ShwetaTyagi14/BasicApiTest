from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ModifyIpRangeDialog(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Modify IP Range"]')),
              'inner_text': 'Modify IP Range'}

    name = {'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Label"]'),
                              label_text_locator=(By.XPATH, '//input[@name="Label"]/preceding-sibling::div'))}

    ip_range = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, '//input[@name="value"]'),
                                  label_text_locator=(By.XPATH, '//input[@name="value"]/ancestor::div[2]//label')),
                'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    ok_button = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="OK"]')), 'inner_text': 'OK'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]')), 'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'name': factory(driver).define_text_input(self.name),
            'ip_range': factory(driver).define_text_input(self.ip_range),
            'ok_button': factory(driver).define_element(self.ok_button),
            'cancel_button': factory(driver).define_element(self.cancel_button)
        }

        super().__init__(driver, self.elements)

    def set_ip_range_name(self, name):
        """

        Args:
            name: name of ip range
        """
        self.elements['name'].clear()
        self.elements['name'].type(name)

    def set_ip_range_address(self, ip_address):
        """

        Args:
            ip_address: ip address
        """
        self.elements['ip_range'].clear()
        self.elements['ip_range'].type(ip_address)

    def press_ok_button(self):
        """
        N/A
        """
        self.elements['ok_button'].wait_for_visible()
        self.elements['ok_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def press_cancel_button(self):
        """
        N/A
        """
        self.elements['cancel_button'].click()

    def is_confirm_error_icon_displayed(self):
        """

        Returns:boolean

        """
        xpath = '//li//ancestor::div[@role="alert" and @aria-live="polite"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element.is_displayed()

    def set_name_as_balnk_space(self, value=Keys.SPACE):
        """

        Args:
            value: white space key stroke
        """
        self.elements['name'].clear()
        self.elements['name'].type(value)

    def verify_ip_in_table(self, ip_address):
        """

        Args:
            ip_address: the ip address in table grid

        Returns:

        """
        xpath = f'//table/tbody/tr/td[.="{ip_address}"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        return element is not None

    def get_ip_range_address(self):
        """

        Returns: ip address

        """
        return self.elements['ip_range'].get_text()
