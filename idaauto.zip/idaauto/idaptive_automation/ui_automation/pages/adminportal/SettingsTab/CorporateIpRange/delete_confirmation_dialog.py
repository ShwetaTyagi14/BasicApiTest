from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ConfirmDeleteDialog(UIPage):

    dialog = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[contains(@id,'confirmwindow') and @dialog_type='confirm']"))
    }

    delete_confirm_dialog_text = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[contains(@class,'x-box-inner') and contains(@id,'confirmwindow')]"
                  "//span[contains(@id,'container')]/div"))
    }

    yes_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Yes']"))}
    no_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='No']"))}

    def __init__(self, driver):
        """

        Args:
            driver: driver
        """
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'delete_confirm_dialog_text': factory(driver).define_text_input(self.delete_confirm_dialog_text),
            'yes_button': factory(driver).define_element(self.yes_button),
            'no_button': factory(driver).define_element(self.no_button)
        }

        super().__init__(driver, self.elements)

    def get_delete_dialog_text(self):
        """

        Returns: text

        """
        return self.elements['delete_confirm_dialog_text'].get_text()

    def press_yes(self):
        """
        N/A
        """
        self.elements['yes_button'].click()
        self.driver.wait_for_invisible_element(self.dialog)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def press_no(self):
        """
        N/A
        """
        self.elements['no_button'].click()
        self.driver.wait_for_invisible_element(self.dialog)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def is_yes_enabled(self):
        """

        Returns: boolean

        """
        return self.elements['yes_button'].is_enabled()

    @property
    def is_no_enabled(self):
        """

        Returns: boolean

        """
        return self.elements['no_button'].is_enabled()
