from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddIdaptiveConnectorDialog(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//span[@class="x-header-text x-window-header-text x-window-header-text-modal"]')),
              }

    download_connector_link = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//a[@href="https://edge.idap.qa/ProxyDownload/CyberArk-Identity-Management-Suite-win64.zip"]')),
            }

    view_help = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//a[text()="View Help"]')),
              }

    close_button = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Close"]'))
                }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'download_connector_link': factory(driver).define_element(self.download_connector_link),
            'view_help': factory(driver).define_element(self.view_help),
            'close_button': factory(driver).define_element(self.close_button)
        }

        super().__init__(driver, self.elements)

    def press_close_button(self):
        self.elements['close_button'].click()

    def is_confirm_download_link_displayed(self):
        return self.elements['download_connector_link'].is_displayed()
