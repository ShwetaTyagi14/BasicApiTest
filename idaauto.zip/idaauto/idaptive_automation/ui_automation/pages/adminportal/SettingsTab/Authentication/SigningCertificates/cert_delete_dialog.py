from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class CertDeleteDialog(UIPage):
    confirm_delete_dialog = {'locator':
                             ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@id,'confirmwindow') and @dialog_type='confirm']"))
    }
    delete_confirm_dialog_text = {'locator':
                                  ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'x-box-inner') and contains(@id,'confirmwindow')]//span[contains(@id,'container')]/div"))
                                  }
    yes = {'locator':
           ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Yes']"))
           }
    no = {'locator':
          ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='No']"))
          }

    delete_warning_dialog_text = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'x-box-inner') and contains(@id,'warning')]//span[contains(@id,'container')]/div"))
                                  }

    delete_error_dialog_text = {'locator':
                                      ElementSetLocator(element_locator=(By.XPATH,
                                                                         f"//div[contains(@class,'x-box-inner') and contains(@id,'error')]//span[contains(@id,'container')]/div"))
                                  }

    close = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Close']"))}

    def __init__(self, driver):
        self.driver = driver
        confirm_delete_dialog = factory(driver).define_element(self.confirm_delete_dialog)
        self.elements = {
            self.LOADED_ELEMENT: confirm_delete_dialog,
            'confirm_delete_dialog': factory(driver).define_element(self.confirm_delete_dialog),
            'yes': factory(driver).define_element(self.yes),
            'no': factory(driver).define_element(self.no),
            'delete_confirm_dialog_text': factory(driver).define_element(self.delete_confirm_dialog_text),
            'delete_warning_dialog_text': factory(driver).define_element(self.delete_warning_dialog_text),
            'delete_error_dialog_text': factory(driver).define_element(self.delete_error_dialog_text),
            'close': factory(driver).define_element(self.close)
        }

        super().__init__(self.driver, self.elements)

    def get_delete_dialog_text(self):
        return self.elements['delete_confirm_dialog_text'].get_text()

    def get_delete_warning_dialog_text(self):
        return self.elements['delete_warning_dialog_text'].get_text()

    def get_delete_error_dialog_text(self):
        return self.elements['delete_error_dialog_text'].get_text()

    def press_yes(self):
        self.elements['yes'].click()
        self.driver.wait_for_invisible_element(self.confirm_delete_dialog)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def press_no(self):
        self.elements['no'].click()
        self.driver.wait_for_invisible_element(self.confirm_delete_dialog)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def press_close(self):
        self.elements['close'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def is_yes_enabled(self):
        return self.elements['yes'].is_enabled()

    def is_no_enabled(self):
        return self.elements['no'].is_enabled()

    def verify_window_closed(self):
        self.elements['confirm_delete_dialog'].wait_for_not_visible()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)