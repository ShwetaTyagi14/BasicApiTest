from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from selenium.common.exceptions import StaleElementReferenceException
import time


class SigningCertificatesPage(UIPage):
    search_certificates = {'locator': ElementSetLocator((By.XPATH, '//div[contains(text(),"Upload your")]//..//input[@role="textbox"]'))}

    search_box = {'locator':
                      ElementSetLocator(
                          element_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search Certificates")]',),
                          parent_container_locator=(
                          By.XPATH, f'//input[starts-with(@placeholder,"Search Certificates")]/ancestor::div[3]'),
                          toggle_locator=(By.XPATH,
                                          f'//input[starts-with(@placeholder,"Search Certificates")]/ancestor::div[3]/div/div/a')),
                  'inner_text': ''}

    certificate_rows = {'locator': ElementSetLocator(
        (By.XPATH, f'//div[contains(@class,"tab-root")]//table//tbody[contains(@id,"body")]//tr'))}

    signing_certificate_default = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Default"]'))}

    signing_certificate_subject = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Subject"]'))}

    signing_certificate_thumbprint = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Thumbprint"]'))}

    signing_certificate_algorithm = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Algorithm"]'))}

    signing_certificate_issued_by = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Issued By"]'))}

    signing_certificate_expire_date = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Expires"]'))}

    signing_certificate_uploaded = {'locator': ElementSetLocator((By.XPATH, '//span[text()="Uploaded"]'))}

    add_button = {'locator': ElementSetLocator((By.XPATH, '//div[contains(text(),"Upload your")]//..//a[@buttontext="Add"]'))}

    actions = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//div[contains(text(),"Upload your organization")]/..//div[a[@buttontext="Actions"]]')),
               'inner_text': 'Actions',
               'supports_validation': False}
    delete = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    set_default = {
        'locator': ElementSetLocator((By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Set as Default"]'))}

    rename = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Rename"]')),
              'supports_validation': False}

    rename_warning = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Warning"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_text_input(self.search_certificates),
            'search_certificates': ElementFactory(driver).define_text_input(self.search_certificates),
            'search_box': ElementFactory(driver).define_search_box(self.search_box),
            'certificate_rows': ElementFactory(driver).define_element_group(self.certificate_rows),
            'signing_certificate_default': ElementFactory(driver).define_element(self.signing_certificate_default),
            'signing_certificate_subject': ElementFactory(driver).define_element(self.signing_certificate_subject),
            'signing_certificate_thumbprint': ElementFactory(driver).define_element(
                self.signing_certificate_thumbprint),
            'signing_certificate_algorithm': ElementFactory(driver).define_element(self.signing_certificate_algorithm),
            'signing_certificate_issued_by': ElementFactory(driver).define_element(self.signing_certificate_issued_by),
            'signing_certificate_expire_date': ElementFactory(driver).define_element(
                self.signing_certificate_expire_date),
            'signing_certificate_uploaded': ElementFactory(driver).define_element(self.signing_certificate_uploaded),
            'add_button': ElementFactory(driver).define_element(self.add_button),
            'actions_btn': ElementFactory(driver).define_multi_select(self.actions),
            'delete_btn': ElementFactory(driver).define_element(self.delete),
            'set_default': ElementFactory(driver).define_element(self.set_default),
            'rename_btn': ElementFactory(driver).define_element(self.rename),
            'rename_warning': ElementFactory(driver).define_element(self.rename_warning)

        }
        super().__init__(driver, self.elements)

    def search_for_certificates(self, key):
        self.elements['search_box'].clear()
        self.elements['search_box'].search_for(key)
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def get_displayed_certs(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        rows = self.elements['certificate_rows'].get_element()
        return rows

    def get_all_cert_names(self):
        rows = self.elements['certificate_rows'].get_element()
        row_results = []
        for row in rows:
            cert_names = row.text.split("\n")[0].lstrip()
            row_results.append(cert_names)
        return row_results

    def get_specific_cert(self, cert_name):
        try:
            results = self.get_all_cert_names()
            matching_cert = [s for s in results if f"{cert_name}" in s]
            matching_cert = matching_cert[0]
            return matching_cert
        except IndexError:
            time.sleep(2)
            results = self.get_all_cert_names()
            matching_cert = [s for s in results if f"{cert_name}" in s]
            matching_cert = matching_cert[0]
            return matching_cert

    def click_add_button(self):
        self.elements['add_button'].wait_for_visible()
        self.elements['add_button'].click()
        return self

    def select_certificate_checkbox(self, cert_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[./td[2][.="{cert_name}"]]/td[1]'))}
        checkbox = ElementFactory(self.driver).define_element(elem_def)
        try:
            checkbox.wait_for_visible()
            self.__persistent_click_element__(checkbox)
            if not self.elements['actions_btn'].is_displayed():
                time.sleep(2)
                checkbox.click()
        except StaleElementReferenceException:
            time.sleep(2)
            self.__persistent_click_element__(checkbox)

    def open_actions_menu(self):
        result = self.__persistent_click_element__(self.elements['actions_btn'])

    def delete_cert(self, cert_name):
        cert_name = self.get_specific_cert(cert_name)
        self.elements['certificate_rows'].wait_for_visible()
        self.select_certificate_checkbox(cert_name)
        self.elements['actions_btn'].wait_for_visible()
        self.open_actions_menu()
        self.elements['delete_btn'].wait_for_visible()
        self.__persistent_click_element__(self.elements['delete_btn'])

    def set_default_cert(self, cert_name):
        cert_name = self.get_specific_cert(cert_name)
        self.elements['certificate_rows'].wait_for_visible()
        self.select_certificate_checkbox(cert_name)
        self.open_actions_menu()
        self.elements['set_default'].wait_for_visible()
        self.__persistent_click_element__(self.elements['set_default'])

    def check_is_default(self, cert_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[@test-text="{cert_name}"]//img'))}
        result = ElementFactory(self.driver).define_element(elem_def).is_displayed()
        return result

    def open_rename_cert(self, cert_name):
        try:
            cert_name = self.get_specific_cert(cert_name)
            self.elements['certificate_rows'].wait_for_visible()
            self.select_certificate_checkbox(cert_name)
            self.open_actions_menu()
            self.elements['rename_btn'].click()
            return self
        except StaleElementReferenceException:
            time.sleep(2)
            cert_name = self.get_specific_cert(cert_name)
            self.select_certificate_checkbox(cert_name)
            self.open_actions_menu()
            self.elements['rename_btn'].click()
            return self

    def rename_warning_present(self):
        result = self.elements['rename_warning'].is_displayed()
        return result

    def get_all_cert_details(self):
        rows = self.elements['certificate_rows'].get_element()
        row_results = []
        for row in rows:
            cert_thumbprints = row.text.split("\n")
            row_results.append(cert_thumbprints)
        return row_results

    def get_specific_cert_thumbprints(self, cert_name):
        try:
            results = self.get_all_cert_details()
            if results[0][0].lstrip() == cert_name:
                return results[0][2]
            else:
                return results[1][2]
        except IndexError:
            time.sleep(2)
            results = self.get_all_cert_details()
            if results[0][0] == cert_name:
                return results[0][2]
            else:
                return results[1][2]