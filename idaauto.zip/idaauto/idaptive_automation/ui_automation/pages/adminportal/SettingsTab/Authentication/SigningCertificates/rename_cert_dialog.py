from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
import time

class RenameCertDialog(UIPage):
    confirm_rename_dialog = {'locator':
                             ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@viewparttitle,'Rename')]"))
                             }

    save = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Save']"))}

    cancel = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Cancel']"))}

    rename_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//label[text()='Name']/../..//input"))}

    def __init__(self, driver):
        self.driver = driver
        confirm_rename_dialog = factory(driver).define_element(self.confirm_rename_dialog)
        self.elements = {
            self.LOADED_ELEMENT: confirm_rename_dialog,
            'confirm_rename_dialog': factory(driver).define_element(self.confirm_rename_dialog),
            'save': factory(driver).define_element(self.save),
            'cancel': factory(driver).define_element(self.cancel),
            'rename_input': factory(driver).define_text_input(self.rename_input)
        }

        super().__init__(self.driver, self.elements)

    def press_save(self):
        is_disabled = self.elements['save'].get_attribute_value('class')
        while "x-item-disabled" in is_disabled:
            self.elements['save'].wait_for_visible(wait_time=1)
            is_disabled = self.elements['save'].get_attribute_value('class')
        self.elements['save'].click()

    def press_cancel(self):
        self.elements['cancel'].click()

    def rename_cert(self, cert_name):
        self.elements['rename_input'].clear()
        self.elements['rename_input'].type(cert_name)
        self.press_save()
        self.verify_window_closed()
        return self

    def verify_window_closed(self):
        self.elements['confirm_rename_dialog'].wait_for_not_visible()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

