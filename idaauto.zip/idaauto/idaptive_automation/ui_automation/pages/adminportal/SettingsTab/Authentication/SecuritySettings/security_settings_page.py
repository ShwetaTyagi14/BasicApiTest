from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SecuritySettingsPage(UIPage):
    heading = {'locator': ElementSetLocator((By.XPATH, f'//div[contains(text(),"Use these settings to define security related settings.")]'))}

    corporate_pvwa_checkbox = {'locator':
            ElementSetLocator((By.XPATH, f'//label[contains(text(),"corporate apps in the password vault")]/..//input'),
            parent_container_locator=(By.XPATH, f'//label[contains(text(),"corporate apps in the password vault")]/ancestor::table[1]'))}

    personal_pvwa_checkbox = {'locator':
            ElementSetLocator((By.XPATH, f'//label[contains(text(),"personal apps in the password vault")]/..//input'),
            parent_container_locator=(By.XPATH, f'//label[contains(text(),"personal apps in the password vault")]/ancestor::table[1]'))}

    save_button = {'locator': ElementSetLocator((By.XPATH, '//a[@buttontext="Save"]'))}

    disabled_save_button = {'locator': ElementSetLocator((By.XPATH, '//a[@buttontext="Save" and contains(@class,"disabled")]'))}

    recaptcha_threshold = {'locator': ElementSetLocator((By.XPATH, '//input[@testname="RecaptchaThreshold"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.heading),
            'heading': ElementFactory(driver).define_element(self.heading),
            'corporate_pvwa_checkbox': ElementFactory(driver).define_checkbox(self.corporate_pvwa_checkbox),
            'personal_pvwa_checkbox': ElementFactory(driver).define_checkbox(self.personal_pvwa_checkbox),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'disabled_save_button': ElementFactory(driver).define_element(self.disabled_save_button),
            'recaptcha_threshold': ElementFactory(driver).define_element(self.recaptcha_threshold),
        }
        super().__init__(driver, self.elements)

    def verify_page(self):
        text = self.elements['heading'].get_element()
        text = text.text
        return text

    def select_corporate_pvwa_checkbox(self, unselect=False):
        if unselect:
            self.elements['corporate_pvwa_checkbox'].unselect()
        else:
            self.elements['corporate_pvwa_checkbox'].select()

    def select_personal_pvwa_checkbox(self, unselect=False):
        if unselect:
            self.elements['personal_pvwa_checkbox'].unselect()
        else:
            self.elements['personal_pvwa_checkbox'].select()

    def personal_pvwa_status(self):
        return self.elements['personal_pvwa_checkbox'].is_checked()

    def corporate_pvwa_status(self):
        return self.elements['corporate_pvwa_checkbox'].is_checked()

    def click_save(self):
        self.elements['disabled_save_button'].wait_for_not_visible()
        self.elements['save_button'].wait_for_visible()
        self.elements['save_button'].click()
        self.elements['disabled_save_button'].wait_for_visible()

    def get_pvwa_element_text(self, search):
        text_element = {'locator': ElementSetLocator((By.XPATH, f'//label[contains(text(),"{search}")]'))}
        pvwa_text = ElementFactory(self.driver).define_element(text_element)
        text = pvwa_text.get_element()
        return text.text

    def verify_captcha_caption(self, caption):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//label[contains(text(),'{caption}')]"))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()

    def click_captcha_threshold(self):
        self.elements['recaptcha_threshold'].wait_for_visible(3).click()

    def select_captcha_threshold(self, threshold):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//ul/li[.='{threshold}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()

    def get_captcha_threshold(self):
        text = self.elements['recaptcha_threshold'].get_attribute_value('value')
        return text
