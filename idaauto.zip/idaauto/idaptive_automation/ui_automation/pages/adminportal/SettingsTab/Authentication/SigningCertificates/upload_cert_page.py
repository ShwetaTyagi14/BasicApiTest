from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class UploadCertificatePage(UIPage):
    _header = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="Certificate Settings"]'))
    }
    _description = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[contains(.,"Enter a name and, if required by this certificate, a password below.") and not(.//div)]'))
    }
    _name_field = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Name"]'))
    }
    _password_field = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="CertificatePwd"]')),
        'inner_text': 'Reset'
    }
    _file_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Certificate"]'))
    }
    _save_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))
    }
    _cancel_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]'))
    }

    _error = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[.="Error"]'))
    }

    _close_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[.="Close"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self._header),
            'header': ElementFactory(driver).define_element(self._header),
            'description': ElementFactory(driver).define_element(self._description),
            'name': ElementFactory(driver).define_text_input(self._name_field),
            'password': ElementFactory(driver).define_text_input(self._password_field),
            'file_input': ElementFactory(driver).define_text_input(self._file_input),
            'save_button': ElementFactory(driver).define_element(self._save_button),
            'cancel_button': ElementFactory(driver).define_element(self._cancel_button),
            'error': ElementFactory(driver).define_element(self._error),
            'close_button': ElementFactory(driver).define_element(self._close_button)
        }
        super().__init__(driver, self.elements)

    def set_name(self, name):
        self.elements['name'].clear().type(name)
        return self

    def set_password(self, password):
        self.elements['password'].clear().type(password)
        return self

    def set_filename(self, filename):
        script = '(function(){var element = document.getElementsByName("Certificate")[0];element.classList.remove("x-form-file-input");})()'
        self.driver.execute_script(script)
        self.elements['file_input'].clear().type(filename)
        return self

    def click_save(self):
        self.elements['save_button'].click()

    def click_cancel(self):
        self.elements['cancel_button'].click()

    def verify_window_closed(self):
        self.elements['header'].wait_for_not_visible()

    def verify_error_displayed_and_close(self):
        self.elements['error'].wait_for_visible()
        result = self.elements['error'].is_displayed()
        self.elements['close_button'].click()
        self.elements['error'].wait_for_not_visible()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        return result
