from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.idaptive_mac_agent_info_page import IdaptiveMacAgentInfoPage


class SettingsUsersGoogleDirectoryServiceConfigPage(UIPage):
    header = {
        'locator':
        ElementSetLocator((By.XPATH, ''))
    }

    def __init__(self, driver):
        raise NotImplementedError()
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header)
        }
        super().__init__(driver, self.elements)
