from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.directory_services_page import SettingsUsersDirectoryServicesPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.PartnerManagement.partner_management_page import SettingsUsersPartnerManagementPage


class SettingsUsersPage(UIPage):
    directory_services = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Directory Services"]'))
    }
    social_login = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Social Login"]'))
    }
    partner_management = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Partner Management"]'))
    }
    admin_accounts = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Administrative Accounts"]'))
    }
    inbound_provisioning = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Inbound Provisioning"]'))
    }
    outbound_provisioning = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Outbound Provisioning"]'))
    }
    idle_user_session_timeout = {
        'locator':
        ElementSetLocator((By.XPATH, '//span[.="Idle User Session Timeout"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.directory_services),
            'directory_services': ElementFactory(driver).define_element(self.directory_services),
            'social_login': ElementFactory(driver).define_element(self.social_login),
            'partner_management': ElementFactory(driver).define_element(self.partner_management),
            'admin_accounts': ElementFactory(driver).define_element(self.admin_accounts),
            'inbound_provisioning': ElementFactory(driver).define_element(self.inbound_provisioning),
            'outbound_provisioning': ElementFactory(driver).define_element(self.outbound_provisioning),
            'idle_user_session_timeout': ElementFactory(driver).define_element(self.idle_user_session_timeout)
        }
        super().__init__(driver, self.elements)

    def click_directory_services(self):
        self.elements['directory_services'].click()
        return SettingsUsersDirectoryServicesPage(self.driver).wait_for_page_to_load()

    def click_social_login(self):
        self.elements['social_login'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_partner_management(self):
        self.elements['partner_management'].click()
        return SettingsUsersPartnerManagementPage(self.driver).wait_for_page_to_load()

    def click_admin_accounts(self):
        self.elements['admin_accounts'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_inbound_provisioning(self):
        self.elements['inbound_provisioning'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_outbound_provisioning(self):
        self.elements['outbound_provisioning'].click()
        raise NotImplementedError('Need to wait for correct page to load')

    def click_idle_user_session_timeout(self):
        self.elements['idle_user_session_timeout'].click()
        raise NotImplementedError('Need to wait for correct page to load')
