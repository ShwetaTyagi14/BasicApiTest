from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SettingsAccountCustomizationPage(UIPage):
    save_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))
    }
    reset_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]/following-sibling::a')),
        'inner_text': 'Reset'
    }
    header = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[.="Account Customization" and not(.//*)]'))
    }
    description = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//div[.="Use these settings to define an Identity Services URL that is more specific to your organization."]'))
    }
    terms_of_use = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//input[@name="TermsOfUseLink"]'))
    }
    privacy_policy = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//input[@name="PrivacyPolicyLink"]'))
    }
    company_name = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//input[@name="CompanyName"]'))
    }
    company_support_link = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, '//input[@name="CompanySupportLink"]'))
    }
    error_icon = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//li//ancestor::div[@role="alert" and @aria-live="polite"]'))
    }

    login_experience_checkbox = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//input[@type="button"][@testname="Core.UI.NGLoginExperience"]'))
    }

    login_experience_label = {'locator': ElementSetLocator(element_locator=(
                      By.XPATH, '//input[@type="button"][@testname="Core.UI.NGLoginExperience"]'
                                '//following-sibling::label'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            'header': ElementFactory(driver).define_element(self.header),
            'save_button': ElementFactory(driver).define_element(self.save_button),
            'reset_button': ElementFactory(driver).define_element(self.reset_button),
            'description': ElementFactory(driver).define_element(self.description),
            'error_icon': ElementFactory(driver).define_element(self.error_icon),
            'terms_of_use': ElementFactory(driver).define_text_input(self.terms_of_use),
            'privacy_policy': ElementFactory(driver).define_text_input(self.privacy_policy),
            'company_name': ElementFactory(driver).define_text_input(self.company_name),
            'company_support_link': ElementFactory(driver).define_text_input(self.company_support_link),
            'login_experience_checkbox': ElementFactory(driver).define_checkbox(self.login_experience_checkbox),
            'login_experience_label': ElementFactory(driver).define_element(self.login_experience_label),
        }
        super().__init__(driver, self.elements)

    def click_save(self):
        self.elements['save_button'].wait_for_visible()
        self.driver.wait_for_clickable_element(self.save_button)
        self.elements['save_button'].click()

    def click_reset(self):
        self.elements['reset_button'].wait_for_visible()
        self.elements['reset_button'].click()

    def set_terms_of_use(self, link):
        self.elements['terms_of_use'].wait_for_visible()
        self.elements['terms_of_use'].clear().type(link)
        return self

    def set_privacy_policy(self, link):
        self.elements['privacy_policy'].wait_for_visible()
        self.elements['privacy_policy'].clear().type(link)

    def set_company_name(self, company):
        self.elements['company_name'].wait_for_visible()
        self.elements['company_name'].clear().type(company)

    def set_company_support_link(self, link):
        self.elements['company_support_link'].wait_for_visible()
        self.elements['company_support_link'].clear().type(link)

    def clear_company_name(self):
        self.elements['company_name'].wait_for_visible()
        self.elements['company_name'].clear()

    def clear_company_support_link(self):
        self.elements['company_support_link'].wait_for_visible()
        self.elements['company_support_link'].clear()

    def clear_input_field(self, element):
        self.elements[f'{element}'].clear()

    def is_error_icon_displayed(self):
        xpath = f'//li//ancestor::div[@role="alert" and @aria-live="polite"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()

    def get_error_icon_text(self):
        self.elements['error_icon'].wait_for_visible(wait_time=UIPage.MEDIUM_DELAY)
        return self.elements['error_icon'].get_attribute_value("data-errorqtip")

    def is_login_experience_checkbox_checked(self):
        xpath = '//table[contains(@class, "x-form-cb-checked")]' \
                '//input[@type="button"][@testname="Core.UI.NGLoginExperience"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()

    def select_login_experience_checkbox(self):
        self.elements['login_experience_checkbox'].click()

    def verify_login_experience_checkbox_label(self):
        return self.elements['login_experience_label'].get_text()