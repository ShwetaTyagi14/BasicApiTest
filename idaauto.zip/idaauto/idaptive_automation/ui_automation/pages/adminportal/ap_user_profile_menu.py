from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.userportal.user_portal_page import UserPortalPage
from idaptive_automation.ui_automation.pages.profilemenu.user_profile_menu import UserProfileMenu


class APUserProfileMenu(UserProfileMenu):
    support = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="Support"]')),
        'supports_validation': True
    }
    # license_info = {
    #     'locator':
    #     ElementSetLocator(element_locator=(By.XPATH, '//span[.="License Information"]')),
    #     'supports_validation': True
    # }
    getting_started = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="Getting Started Wizard"]')),
        'supports_validation': True
    }
    user_portal = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="Switch to User Portal"]')),
        'supports_validation': False
    }
    analytics_portal = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//span[.="Analytics Portal"]')),
        'supports_validation': False
    }



    def __init__(self, driver):
        self.elements = {
            'support': ElementFactory(driver).define_element(self.support),
            'getting_started': ElementFactory(driver).define_element(self.getting_started),
            'user_portal': ElementFactory(driver).define_element(self.user_portal),
            'analytics_portal': ElementFactory(driver).define_element(self.analytics_portal),
            # 'license_info': ElementFactory(driver).define_element(self.license_info)
        }

        super().__init__(driver, self.elements)

    def click_support(self):
        self.elements['profile'].click()
        self.elements['support'].click()

    def open_getting_started_wizard(self):
        self.elements['profile'].click()
        self.elements['getting_started'].click()

    def switch_to_user_portal(self, wait_for_portal_to_load=True):
        self.elements['profile'].click()
        self.elements['user_portal'].click()
        if wait_for_portal_to_load:
            UserPortalPage(self.driver).wait_for_page_to_load()
