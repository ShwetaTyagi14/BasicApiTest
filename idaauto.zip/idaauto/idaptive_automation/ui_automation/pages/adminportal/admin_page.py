from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.Authentication.SigningCertificates.signingcertificates_page import \
    SigningCertificatesPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.Authentication.SecuritySettings.security_settings_page import\
    SecuritySettingsPage
from idaptive_automation.ui_automation import SettingsUsersPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_customization_page import \
    SettingsCustomizationPage
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_tab_landing_page import RolesTabPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_network_page import SettingsNetworkPage
from idaptive_automation.ui_automation.pages.outboundprovisioning.outbound_provisioning_page import OutboundProvisioningPage
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.admin_policies_tab import AdminPagePoliciesTab
from idaptive_automation.ui_automation.pages.adminportal.downloads_page import DownloadsPage
from idaptive_automation.ui_automation.pages.inboundprovisioning.inbound_provisioning_page import InboundProvisioningPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.users_tab_landing_page import UsersTab
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.web_apps_page import WebAppsPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.reports_tab_landing_page import ReportsTabPage
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_tab_landing_page import OUSTab


class AdminPortalPage(UIPage):
    dashboard = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//tr[starts-with(@id, "nav-part-Dashboards-Dashboards")]'))}

    dashboard_row = {'locator':
                     ElementSetLocator((By.ID, 'nav-part-Dashboards-Dashboards'))}

    users_tab = {'locator':
                 ElementSetLocator((By.XPATH, '//*[@id="nav-part-UserList-Users"]/td/div/a'))}

    roles_tab = {'locator':
                 ElementSetLocator((By.XPATH, '//*[@id="nav-part-RoleList-Roles"]/td/div/a'))}

    requests_tab = {'locator':
                     ElementSetLocator((By.XPATH, '//*[@id="nav-part-Jobs-Requests"]/td/div/a'))}

    web_apps_tab = {'locator':
                     ElementSetLocator((By.XPATH, '//*[@id="nav-part-ApplicationList-Web-Apps"]/td/div/a'))}

    mobile_apps_tab = {'locator':
                     ElementSetLocator((By.XPATH, '//*[@id="nav-part-MobileApplicationList-Mobile-Apps"]/td/div/a'))}

    settings_item = {'locator':
                     ElementSetLocator((By.XPATH, '//span[text() = "Settings"]'))}

    settings_customization_item = {'locator': ElementSetLocator((By.XPATH, '//a[text() = "Customization"]'))}

    settings_user_item = {'locator':
                          ElementSetLocator((By.ID, 'nav-part-UserSettings-Users'))}

    settings_network_item = {'locator':
                             ElementSetLocator((By.ID, 'nav-part-NetworkSettings-Network'))}

    user_menu = {'locator':
                 ElementSetLocator((By.XPATH, '//*[@id="nav-part-UserSettings-Users"]/td/div/a'))}

    ou_tab = {'locator':
                 ElementSetLocator((By.XPATH, '//*[@id="nav-part-Organizations-Organizations"]/td/div/a'))}

    apps_menu = {'locator':
                 ElementSetLocator((By.XPATH, '//span[text() = "Apps"]'))}

    top_user_menu = {'locator':
                     ElementSetLocator((By.XPATH, '//*[@id="nav-part-UserList-Users"]/td/div/a'))}

    core_services_root = {'locator':
                          ElementSetLocator((By.XPATH, '//*[@id="nav-part-Core-Services"]'))}

    welcome_wizard = {'locator':
                      ElementSetLocator((By.XPATH, '//div[contains(@class,"idaptive-welcome-wizard")]'))}

    _welcome_wiz_close_btn = {'locator':
                      ElementSetLocator((By.XPATH, '//div[contains(@class,"idaptive-welcome-wizard")]//a[contains(@class,"close-btn")]')),
                      'supports_validation': False}

    inbound_provisioning_item = {'locator':
                                 ElementSetLocator((By.XPATH, '//span[text() = "Inbound Provisioning"]'))}

    outbound_provisioning_item = {'locator':
                                  ElementSetLocator((By.XPATH, '//span[text() = "Outbound Provisioning"]'))}

    policies_item = {'locator':
                     ElementSetLocator((By.XPATH, '//a[text() = "Policies"]'))}

    reports_tab = {'locator': ElementSetLocator((By.XPATH, '//*[@id="nav-part-Reporting-Reports"]/td/div/a'))}

    web_apps_item = {'locator':
                     ElementSetLocator((By.LINK_TEXT, 'Web Apps'))}

    loading_dialog = {'locator':
                      ElementSetLocator((By.ID, 'ext-gen1303'))}

    downloads = {'locator':
                 ElementSetLocator((By.XPATH, '//a[.="Downloads"]'))}

    settings_authentication = {'locator':
                     ElementSetLocator((By.XPATH, '//*[@id="nav-part-AuthenticationSettings-Authentication"]/td/div/a '))}

    authentication_signing_certificates = {
        'locator':
            ElementSetLocator((By.XPATH, '//span[text()="Signing Certificates"]'))
    }

    authentication_security_settings = {
        'locator':
            ElementSetLocator((By.XPATH, '//span[text()="Security Settings"]'))
    }

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self.dashboard),
            'dashboard': ElementFactory(driver).define_element(self.dashboard),
            'users': ElementFactory(driver).define_element(self.users_tab),
            'settings': ElementFactory(driver).define_element(self.settings_item),
            'settings_customization_item': ElementFactory(driver).define_element(self.settings_customization_item),
            'settings_network': ElementFactory(driver).define_element(self.settings_network_item),
            'settings_user': ElementFactory(driver).define_element(self.settings_user_item),
            'user_menu': ElementFactory(driver).define_element(self.user_menu),
            'ou_tab': ElementFactory(driver).define_element(self.ou_tab),
            'apps_menu': ElementFactory(driver).define_element(self.apps_menu),
            'top_user_menu': ElementFactory(driver).define_element(self.top_user_menu),
            'core_services': ElementFactory(driver).define_element(self.core_services_root),
            'welcome_wiz': ElementFactory(driver).define_element(self.welcome_wizard),
            'welcome_wiz_close_btn': ElementFactory(driver).define_element(self._welcome_wiz_close_btn),
            'inbound_prov': ElementFactory(driver).define_element(self.inbound_provisioning_item),
            'outbound_prov': ElementFactory(driver).define_element(self.outbound_provisioning_item),
            'policies_item': ElementFactory(driver).define_element(self.policies_item),
            'reports_tab': ElementFactory(driver).define_element(self.reports_tab),
            'web_apps': ElementFactory(driver).define_element(self.web_apps_item),
            'loading_dialog': ElementFactory(driver).define_element(self.loading_dialog),
            'downloads': ElementFactory(driver).define_element(self.downloads),
            'roles': ElementFactory(driver).define_element(self.roles_tab),
            'settings_authentication': ElementFactory(driver).define_element(self.settings_authentication),
            'authentication_signing_certificates': ElementFactory(driver).define_element(self.authentication_signing_certificates),
            'authentication_security_settings': ElementFactory(driver).define_element(self.authentication_security_settings),
            'requests_tab': ElementFactory(driver).define_element(self.requests_tab),
            'web_apps_tab': ElementFactory(driver).define_element(self.web_apps_tab),
            'mobile_apps_tab': ElementFactory(driver).define_element(self.mobile_apps_tab)
        }

        super().__init__(driver, self.elements)

    def is_page_loaded(self):
        return self.elements['loaded'].wait_for_visible() is not None

    def select_web_apps(self):
        if self.elements['web_apps'].get_element() is None:
            self.elements['apps_menu'].click()

        self.elements['web_apps'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        return WebAppsPage(self.driver).wait_for_page_to_load(UIPage.LONG_DELAY)

    def select_policies(self):
        self.elements['policies_item'].click()
        return AdminPagePoliciesTab(self.driver)

    def select_users(self):
        self.elements['users'].click()
        return UsersTab(self.driver)

    def select_roles(self):
        self.elements['roles'].click()
        return RolesTabPage(self.driver)

    def select_organizations(self):
        self.elements['ou_tab'].click()
        return OUSTab(self.driver).wait_for_page_to_load()

    def select_downloads(self):
        self.elements['downloads'].click()
        return DownloadsPage(self.driver).wait_for_page_to_load()

    def select_inbound_provisioning(self):
        self.driver.wait_for_invisible_element(self.loading_dialog)

        if self.elements['settings_user'].wait_for_visible() is None:
            self.elements['settings'].click()

        self.driver.wait_for_invisible_element(self.loading_dialog)
        self.elements['user_menu'].click()
        self.elements['inbound_prov'].click()
        return InboundProvisioningPage(self.driver).wait_for_page_to_load()

    def select_outbound_provisioning(self):
        self.driver.wait_for_invisible_element(self.loading_dialog)

        if self.elements['settings_user'].wait_for_visible() is None:
            self.elements['settings'].click()

        self.driver.wait_for_invisible_element(self.loading_dialog)
        self.elements['user_menu'].click()
        self.elements['outbound_prov'].click()
        return OutboundProvisioningPage(self.driver).wait_for_page_to_load()

    def select_settings_customization(self):
        if not self.elements['settings_customization_item'].is_displayed():
            self.elements['settings'].click()
        self.elements['settings_customization_item'].click()
        return SettingsCustomizationPage(self.driver).wait_for_page_to_load()

    def select_settings_network(self):
        if not self.elements['settings_network'].is_displayed():
            self.elements['settings'].click()
        self.elements['settings_network'].click()
        return SettingsNetworkPage(self.driver).wait_for_page_to_load()

    def select_authentication_security_settings(self):
        self.elements['settings_authentication'].click()
        self.elements['authentication_security_settings'].click()
        return SecuritySettingsPage(self.driver).wait_for_page_to_load()

    def select_authentication_signing_certificates(self):
        self.elements['settings_authentication'].click()
        self.elements['authentication_signing_certificates'].click()
        return SigningCertificatesPage(self.driver).wait_for_page_to_load()

    def select_settings_users(self):
        if not self.elements['settings_user'].is_displayed():
            self.elements['settings'].click()
        self.elements['settings_user'].click()
        return SettingsUsersPage(self.driver).wait_for_page_to_load()

    def validate_admin_welcome_page(self):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(text()," Welcome to CyberArk Idaptive!")]'))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        return element.is_displayed()

    def close_welcome_wizard(self, required=True):
        if self.elements['welcome_wiz'].get_element() is None:
            if required:
                assert False, 'Welcome wizard not displayed'
            else:
                return self
        self.elements['welcome_wiz_close_btn'].click()
        return self

    def close_admin_welcome_page(self):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"window-body-modal")]//descendant::span[text()="x"]'))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()
        self.driver.wait_for_loading_mask_to_disappear()

    def is_admin_portal_displayed(self):
        return self.elements['dashboard'].is_displayed()

    def select_reports(self):
        self.elements['reports_tab'].click()
        return ReportsTabPage(self.driver).wait_for_page_to_load()

    def is_available(self, element):
        return self.elements[element].is_displayed()

