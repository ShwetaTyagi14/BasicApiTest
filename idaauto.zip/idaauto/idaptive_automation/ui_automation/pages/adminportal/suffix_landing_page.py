from selenium.webdriver.common.by import By
from selenium.common.exceptions import StaleElementReferenceException
from idaptive_automation.ui_automation.pages.adminportal.add_login_suffix_dialog import AddLoginSuffixDialog
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SuffixLandingPage(UIPage):
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[text() = "Suffix"]')),
              'inner_text': 'Suffix'}

    learn_more = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//span[text() = "Learn more"]')),
                  'inner_text': 'Learn more'}

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext = "Add"]')),
                  'inner_text': 'Add'}

    suffix_grid_suffix_column = {'locator':
                                 ElementSetLocator(element_locator=(By.XPATH, f'//span[starts-with(@id, "datagridcolumn") and text() = "Suffix"]')),
                                 'inner_text': 'Suffix'}

    modify = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Modify"]'))}

    delete = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Delete"]'))}

    modified_suffix_toaster = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Login suffix modified."]'))}

    actions = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, '//div[a[@buttontext="Actions"]]')),
               'inner_text': 'Actions',
               'supports_validation': False}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'learn_more': factory(driver).define_element(self.learn_more),
            'add_button': factory(driver).define_element(self.add_button),
            'suffix_column': factory(driver).define_element(self.suffix_grid_suffix_column),
            'modify': factory(driver).define_element(self.modify),
            'delete': factory(driver).define_element(self.delete),
            'modified_suffix_toaster': factory(driver).define_element(self.modified_suffix_toaster),
            'actions_btn': factory(driver).define_multi_select(self.actions)
        }

        super().__init__(driver, self.elements)

    def press_suffix_add_button(self):
        self.elements['add_button'].click()
        return AddLoginSuffixDialog(self.driver).wait_for_page_to_load()

    def select_suffix_checkbox(self, suffix):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[td[2][.="{suffix}"]]/td[1]'))}
        factory(self.driver).define_element(elem_def).click()

    def open_actions_menu(self):
        elements = self.driver.find_elements_by_xpath('//a[@buttontext="Actions"]')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
        return self

    def click_modify(self):
        self.elements['modify'].click()

    def validate_modified_suffix_toaster(self):
        try:
            return self.elements['modified_suffix_toaster'].is_displayed()
        except StaleElementReferenceException:
            return True
