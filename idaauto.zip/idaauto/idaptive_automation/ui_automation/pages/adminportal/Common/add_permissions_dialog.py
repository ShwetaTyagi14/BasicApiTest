from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddPermissionsDialog(UIPage):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"modal-window")]//span[contains(.,"Select")]'))
    }
    _search_box = {
        'locator':
            ElementSetLocator((By.XPATH, '//input[starts-with(@placeholder,"Search User & Group")]'),
                              toggle_locator=(By.XPATH, '//table[.//input[starts-with(@placeholder,"Search User & Group")]]/following-sibling::a'))
    }
    _users_filter = {
        'locator':
            ElementSetLocator((By.XPATH, '//input/following-sibling::label[.="Users"]'))
    }
    _groups_filter = {
        'locator':
            ElementSetLocator((By.XPATH, '//input/following-sibling::label[.="Groups"]'))
    }
    _roles_filter = {
        'locator':
            ElementSetLocator((By.XPATH, '//input/following-sibling::label[.="Roles"]'))
    }
    _idaptive_directory = {
        'locator':
            ElementSetLocator((By.XPATH, '//input/following-sibling::label[.="CyberArk Cloud Directory"]'))
    }
    _fds_directory = {
        'locator':
            ElementSetLocator((By.XPATH, '//input/following-sibling::label[.="FDS"]'))
    }
    _search_results = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr'))
    }
    _add_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"modal-window")]//a[@buttontext="Add"]'))
    }
    _cancel_button = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"modal-window")]//a[@buttontext="Cancel"]'))
    }

    search_box_loading_mask = \
        (By.XPATH,
         '//div[contains(@class, "white-loadmask-indicator") and not(contains(@style, "display: none"))]')

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self._header),
            'search_box': factory(driver).define_search_box(self._search_box),
            'users_filter': factory(driver).define_checkbox(self._users_filter),
            'groups_filter': factory(driver).define_checkbox(self._groups_filter),
            'roles_filter': factory(driver).define_checkbox(self._roles_filter),
            'idaptive_directory': factory(driver).define_checkbox(self._idaptive_directory),
            'fds_directory': factory(driver).define_checkbox(self._fds_directory),
            'search_results': factory(driver).define_element_group(self._search_results),
            'add_button': factory(driver).define_element(self._add_button),
            'cancel_button': factory(driver).define_element(self._cancel_button),
        }

        super().__init__(driver, self.elements)

    def select_source_filter(self, filter_name):
        elem_name = f'{filter_name.lower()}_filter'
        if elem_name not in self.elements.keys():
            raise Exception(f'Unknown source filter: {filter_name}')
        self.elements[elem_name].check()

    def search_for_user(self, search_string):
        self.elements['search_box'].search_for(search_string)
        self.wait_for_search_mask_to_disappear()
        return self

    def wait_for_search_mask_to_disappear(self, wait_for_appearance=UIPage.SHORT_DELAY,
                                          wait_for_disappearance=UIPage.LONG_DELAY):
        self.driver.wait_for_transient_element_to_come_and_go(self.search_box_loading_mask,
                                                              wait_for_appearance_time=wait_for_appearance,
                                                              wait_for_disappearance_time=wait_for_disappearance)

    def get_search_results(self):
        self.wait_for_search_mask_to_disappear()
        return self.elements['search_results'].get_text().split('\r\n')

    def select_search_result_by_name(self, name):
        self.wait_for_search_mask_to_disappear()
        elem = factory(self.driver).define_td_checkbox({
            'locator':
                ElementSetLocator((By.XPATH, f'//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr//td[.="{name}"]/preceding-sibling::td[2]'),
                                  parent_container_locator=(By.XPATH, f'//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr[.//td[.="{name}"]]'))
        })
        elem.select()

    def select_search_result_by_email(self, email):
        elem = factory(self.driver).define_td_checkbox({
            'locator':
                ElementSetLocator((By.XPATH, f'//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr//td[.="{email}"]/preceding-sibling::td[3]'),
                                  parent_container_locator=(By.XPATH, f'//div[contains(@class,"modal-window")]//table[contains(@id,"gridview")]//tr[.//td[.="{email}"]]'))
        })
        elem.select()

    def is_add_button_disabled(self):
        return not self.elements['add_button'].is_enabled()

    def press_add_button(self):
        self.elements['add_button'].click()

    def press_cancel_button(self):
        self.elements['cancel_button'].click()
