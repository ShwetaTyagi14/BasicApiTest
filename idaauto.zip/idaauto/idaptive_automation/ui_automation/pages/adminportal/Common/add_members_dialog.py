from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.Common.add_permissions_dialog import AddPermissionsDialog


class AddMembersDialog(AddPermissionsDialog):
    _header = {
        'locator':
            ElementSetLocator((By.XPATH, '//div[contains(@class,"viewpart-grid")]//div[.="Trust" and not(.//*)]'))
    }

    def __init__(self, driver):
        raise  NotImplementedError()
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self._header),
        }

        super().__init__(driver, self.elements)
