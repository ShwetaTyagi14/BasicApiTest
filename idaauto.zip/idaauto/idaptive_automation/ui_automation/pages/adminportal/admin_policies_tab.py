from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AdminPagePoliciesTab(UIPage):
    policies_header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text() = "Policies"]')),
                       'inner_text': 'Policies'}

    policies_grid_name_column = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Name"]')),
                                 'inner_text': 'Name'}

    policies_grid_status_column = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Status"]')),
                                   'inner_text': 'Status'}

    policies_grid_description_column = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[starts-with(@id, "datagridcolumn") and text() = "Description"]')),
                                        'inner_text': 'Description'}

    add_policy_set_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add Policy Set"]')),
                          'inner_text': 'Add Policy Set'}

    push_policy_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Push Policy"]')),
                       'inner_text': 'Push Policy'}

    drag_to_set_order = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(.,"Drag policy set to specify order")]')),
                         'inner_text': 'Drag policy set to specify order. The highest priority is on top.'}

    policy_rows = {'locator': ElementSetLocator(element_locator=(By.XPATH,'//div[starts-with(@id,"headercontainer")][div/div/div[2]/div//span[text()="Name"]]/following-sibling::div/div/table//tr')),
                   'supports_validation': False}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.add_policy_set_btn),
            'header': factory(driver).define_element(self.policies_header),
            'name_column': factory(driver).define_element(self.policies_grid_name_column),
            'status_column': factory(driver).define_element(self.policies_grid_status_column),
            'descr_column': factory(driver).define_element(self.policies_grid_description_column),
            'add_policy_btn': factory(driver).define_element(self.add_policy_set_btn),
            'push_policy_btn': factory(driver).define_element(self.push_policy_btn),
            'drag': factory(driver).define_element(self.drag_to_set_order),
            'policy_rows': factory(driver).define_element_group(self.policy_rows)
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def get_displayed_policies(self):
        rows = self.elements['policy_rows'].get_element()
        return rows

    def open_add_policy_window(self):
        self.elements['add_policy_btn'].click()
