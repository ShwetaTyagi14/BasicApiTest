from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.error_dialog import ErrorDialog
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.add_members_dialog import AddMembersDialog
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from selenium.webdriver.common.by import By


class OUAddEditWindow(UIPage):
    name = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="Name"]'),
                                      label_text_locator=(By.XPATH,
                                                          '//input[@testname="Name"]/preceding-sibling::div/label')),
                    'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    description = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="Description"]'),
                                      label_text_locator=(By.XPATH,
                                                          '//input[@testname=""Description"]/preceding-sibling::div/label')),
                    'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    save_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]')),
                   'inner_text': 'Save',
                   'supports_validation': False}

    cancel_btn = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]')),
                  'inner_text': 'Cancel'}

    actions_btn = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Actions"]')),
               'inner_text': 'Actions',
               'supports_validation': False}

    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    description_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Description"]')),
                   'inner_text': 'Description',
                   'supports_validation': False}

    roles_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Roles"]')),
                   'inner_text': 'Role',
                   'supports_validation': False}

    members_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Members"]')),
                   'inner_text': 'Role',
                   'supports_validation': False}

    administrators_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Administrators"]')),
                   'inner_text': 'Role',
                   'supports_validation': False}

    add_btn = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    grid_rows = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f"//div[contains(@id,'jsutil-Form')]//tr[contains(@class,'x-grid-data-row')]"))}

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_text_input(self.name),
            'name': ElementFactory(driver).define_text_input(self.name),
            'description': ElementFactory(driver).define_element(self.description),
            'save_btn': ElementFactory(driver).define_element(self.save_btn),
            'cancel_btn': ElementFactory(driver).define_element(self.cancel_btn),
            'actions_btn': ElementFactory(driver).define_element(self.actions_btn),
            'delete': ElementFactory(driver).define_element(self.delete),
            'description_tab': ElementFactory(driver).define_element(self.description_tab),
            'role_tab': ElementFactory(driver).define_element(self.roles_tab),
            'add_btn': ElementFactory(driver).define_element(self.add_btn),
            'grid_rows': ElementFactory(driver).define_element_group(self.grid_rows)
        }

        super().__init__(driver, self.elements)

    def set_ou_name(self, name):
        self.elements['name'].wait_for_visible()
        self.elements['name'].get_element().send_keys(name)

    def set_description(self, description):
        self.elements['description'].wait_for_visible()
        self.elements['description'].get_element().send_keys(description)

    def open_add_members_window(self):
        self.elements['add_btn'].wait_for_visible()
        self.driver.wait_for_clickable_element(self.add_btn)
        self.elements['add_btn'].click()
        return AddMembersDialog(self.driver).wait_for_page_to_load()

    def get_displayed_members(self):
        members = self.elements['grid_rows'].get_element()
        return members

    def press_save_button(self):
        self.hover_and_click(element_text='Save')
        self.driver.wait_for_loading_mask_to_disappear()

    def press_cancel_button(self):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='Cancel']"))
        UIPage.__persistent_click_element__(element)

    def hover_and_click(self, element_text):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//a[@buttontext='{element_text}']"))
        self.driver.hover_over_element(by=(By.XPATH, f"//a[@buttontext='{element_text}']"))
        element.click()
        return self

    def open_actions_menu(self):
        self.elements['actions_btn'].click()

    def click_delete(self):
        self.elements['delete'].click()

    def open_roles_window(self):
        self.elements['role_tab'].wait_for_visible()
        self.driver.wait_for_clickable_element(self.roles_tab)
        self.elements['role_tab'].click()

    def select_checkbox_for_unit(self, unit_name):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[starts-with(@test-text,'{unit_name}')]/td[1]"))}
        ElementFactory(self.driver).define_element(elem_def).click()
