from selenium.webdriver.common.by import By
from selenium.common.exceptions import ElementNotInteractableException
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.ui_element import UIElement
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_add_edit_window import OUAddEditWindow


class OUSTab(UIPage):
    add_ou_btn = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add Organization"]')),
                       'inner_text': 'Add Organization'}

    bulk_ou_update_btn = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Bulk Organization Update"]')),
                       'inner_text': 'Bulk Organization Update'}

    actions_btn = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Actions"]')),
               'inner_text': 'Actions',
               'supports_validation': False}

    delete = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
              'supports_validation': False}

    def __init__(self, driver):
        self.elements = {
            'loaded': ElementFactory(driver).define_element(self.add_ou_btn),
            'add_ou_btn': ElementFactory(driver).define_element(self.add_ou_btn),
            'bulk_ou_update_btn': ElementFactory(driver).define_element(self.bulk_ou_update_btn),
            'actions_btn': ElementFactory(driver).define_element(self.actions_btn),
            'delete': ElementFactory(driver).define_element(self.delete)
        }

        super().__init__(driver, self.elements)

    def is_page_loaded(self):
        return self.elements['loaded'].wait_for_visible() is not None

    def validate_ou_tab_is_loaded(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['add_ou_btn'].wait_for_visible()
        self.elements['bulk_ou_update_btn'].wait_for_visible()
        return self

    def click_add_ou(self):
        self.driver.wait_for_clickable_element(self.add_ou_btn)
        self.elements['add_ou_btn'].click()

    def select_ou_checkbox(self, ou_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[td[2][.="{ou_name}"]]/td[1]'))}
        ElementFactory(self.driver).define_element(elem_def).click()

    def open_ou_detail_window_for_ou(self, ou_name):
        elem_def = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//tr[td[2][.="{ou_name}"]]'))}
        ElementFactory(self.driver).define_element(elem_def).click()
        return OUAddEditWindow(self.driver).wait_for_page_to_load()

    def open_actions_menu(self):
        elements = self.driver.find_elements_by_xpath('//a[@buttontext="Actions"]')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
        return self

    def click_delete(self):
        self.elements['delete'].click()

