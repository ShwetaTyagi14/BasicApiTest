from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class AddLoginSuffixDialog(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Add Login Suffix"]'))}

    heading = {'locator':
               ElementSetLocator(element_locator=(By.XPATH, f'//span[.="Add Login Suffix"]')),
               'inner_text': 'Add Login Suffix'}

    input_suffix = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//input[starts-with(@class,"beLowerCase") and @testname="alias"]'),
                                      label_text_locator=(By.XPATH, f'//input[starts-with(@class,"beLowerCase") and @testname="alias"]//ancestor::div[3]/preceding-sibling::div[1]')),
                    'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    save_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                   'inner_text': 'Save'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel"]')),
                     'inner_text': 'Cancel'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.save_button),
            'heading': factory(driver).define_element(self.heading),
            'input_suffix': factory(driver).define_text_input(self.input_suffix),
            'save': factory(driver).define_element(self.save_button),
            'cancel': factory(driver).define_element(self.cancel_button)
        }

        super().__init__(driver, self.elements)

    def set_login_suffix(self, suffix):
        self.elements['input_suffix'].clear()
        self.elements['input_suffix'].type(suffix)

    def press_suffix_save_button(self):
        self.elements['save'].click()
        self.elements['save'].wait_for_not_visible()
        self.driver.wait_for_loading_mask_to_disappear()