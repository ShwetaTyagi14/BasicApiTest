from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.adminportal.idaptive_mac_agent_info_page import IdaptiveMacAgentInfoPage


class DownloadsPage(UIPage):
    header = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="CyberArk Identity Downloads"]'))
    }
    # mac_agent = {
    #     'locator':
    #     ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="Idaptive Mac Cloud Agent"]]'))
    # }
    # mac_agent_download = {
    #     'locator':
    #     ElementSetLocator((By.XPATH, '//a[contains(@href,"Idaptive-Mac-Agent.dmg")]'))
    # }
    # mac_agent_info = {
    #     'locator':
    #     ElementSetLocator((By.XPATH, '//tr[contains(.,"Idaptive Mac Cloud Agent")]/td[5]/div/div/a'))
    # }
    ibes = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Browser Extensions"]'))
    }
    cli_tools = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="CLI Tools"]'))
    }
    connectors = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Connectors"]'))
    }
    mac_tools = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Mac Tools"]'))
    }
    plugins = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="MFA Plugins & Clients"]'))
    }
    windows_agent = {
        'locator':
        ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="Windows Cloud Agent"]]'))
    }
    windows_agent_download = {
        'locator':
        ElementSetLocator((By.XPATH, '//a[contains(@href,"IdaptiveAgentinstaller.msi")]'))
    }
    chrome = {
        'locator':
        ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="Chrome"]]/td[6]'))
    }
    firefox = {
        'locator':
        ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="Firefox"]]/td[6]'))
    }
    ie64 = {
        'locator':
        ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="IEx64"]]/td[6]')),
        'supports_validation': False
    }
    ie86 = {
        'locator':
        ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="IEx86"]]/td[6]')),
        'supports_validation': False
    }
    safari = {
        'locator':
        ElementSetLocator((By.XPATH, '//tr[td[3]/div[.="Safari"]]/td[6]')),
        'supports_validation': False
    }
    connector_download = {
        'locator':
        ElementSetLocator((By.XPATH, '//div[.="Connectors"]/following-sibling::table//a[@buttontext="Download"]'))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            # 'mac_agent': ElementFactory(driver).define_element(self.mac_agent),
            # 'mac_agent_download': ElementFactory(driver).define_element(self.mac_agent_download),
            # 'mac_agent_info': ElementFactory(driver).define_element(self.mac_agent_info),
            'windows_agent': ElementFactory(driver).define_element(self.windows_agent),
            'windows_agent_download': ElementFactory(driver).define_element(self.windows_agent_download),
            'ibes': ElementFactory(driver).define_element(self.ibes),
            'cli': ElementFactory(driver).define_element(self.cli_tools),
            'connectors': ElementFactory(driver).define_element(self.connectors),
            'connector_download': ElementFactory(driver).define_element(self.connector_download),
            'mac': ElementFactory(driver).define_element(self.mac_tools),
            'plugins': ElementFactory(driver).define_element(self.plugins),
            'chrome': ElementFactory(driver).define_element(self.chrome),
            'firefox': ElementFactory(driver).define_element(self.firefox),
            'ie64': ElementFactory(driver).define_element(self.ie64),
            'ie86': ElementFactory(driver).define_element(self.ie86),
            'safari': ElementFactory(driver).define_element(self.safari)
        }
        super().__init__(driver, self.elements)

    def get_all_browser_extension_versions(self):
        versions = self.get_chrome_extension_version()
        versions.update(self.get_firefox_extension_version())
        # versions.update(self.get_ie64_extension_version())
        # versions.update(self.get_ie86_extension_version())
        # versions.update(self.get_safari_extension_version())
        return versions

    def get_chrome_extension_version(self):
        return {'Chrome': self.elements['chrome'].get_text().strip()}

    def get_firefox_extension_version(self):
        return {'Firefox': self.elements['firefox'].get_text().strip()}

    def get_ie64_extension_version(self):
        return {'IEx64': self.elements['ie64'].get_text().strip()}

    def get_ie86_extension_version(self):
        return {'IEx86': self.elements['ie86'].get_text().strip()}

    def get_safari_extension_version(self):
        return {'Safari': self.elements['safari'].get_text().strip()}

    def download_connector(self):
        self.elements['connector_download'].click()

    def get_connector_href(self):
        return self.elements['connector_download'].get_attribute_value('href')

    def get_windows_agent_href(self):
        return self.elements['windows_agent_download'].get_attribute_value('href')

    def get_mac_agent_href(self):
        return self.elements['mac_agent_download'].get_attribute_value('href')

    def open_mac_agent_info_dialog(self):
        self.elements['mac_agent_info'].click()
        return IdaptiveMacAgentInfoPage(self.driver).wait_for_page_to_load()
