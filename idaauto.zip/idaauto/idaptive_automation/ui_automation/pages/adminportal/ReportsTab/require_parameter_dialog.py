from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.select_role_dialog import SelectRoleDialog


class RequireParameterDialog(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(
                  By.XPATH, "//div[contains(@class,'modal-window') and @viewparttitle='Required Parameters']"))}

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Required Parameters')]"))}

    select_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//span[@class='x-btn-inner x-btn-inner-center'][.='Select']"))}

    ok_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//span[@class='x-btn-inner x-btn-inner-center'][.='OK']"))}

    cancel_button = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//span[@class='x-btn-inner x-btn-inner-center'][.='Cancel']"))}

    close_icon = {'locator': ElementSetLocator(
        element_locator=(
            By.XPATH, "//div[@class='x-tool x-tool-close x-box-item x-ltr x-tool-default x-tool-after-title']"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'select_button': factory(driver).define_element(self.select_button),
            'ok_button': factory(driver).define_element(self.ok_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'close_icon': factory(driver).define_element(self.close_icon),
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def is_add_button_enabled(self):
        return self.elements['add_apps'].is_enabled()

    def is_add_button_disabled(self):
        return not self.elements['add_apps'].is_enabled()

    def click_select_button(self):
        self.elements['select_button'].click()
        select_role_dialog = SelectRoleDialog(self.driver)
        select_role_dialog.wait_for_page_to_load(wait_time=10)
        return select_role_dialog

    def click_ok_button(self):
        self.elements['ok_button'].click()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()

    def click_close_icon_button(self):
        self.elements['close_icon'].click()