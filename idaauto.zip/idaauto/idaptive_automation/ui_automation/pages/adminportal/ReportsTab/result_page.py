from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_add_edit_window import RolesAddEditWindow
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.copy_report_dialog import CopyReportDialog
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.reports_tab_landing_page import ReportsTabPage


class ReportResultPage(UIPage):

    back_to_reports_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[.='Back to Reports']"))}

    def __init__(self, driver, report_title):
        self.report_title = report_title
        self.header = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//label[.="{self.report_title}"]'))}
        self.current_param_link_button = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//label[.='{self.report_title}']//ancestor::div[contains(@class, "
                      f"'x-container header-panel-title-bar')]//following-sibling::div//a[.='Current Parameters']"))}

        self.action_button = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//label[.='{self.report_title}']//ancestor::div[contains(@class, "
                      f"'x-container x-box-item')]//following-sibling::div//a[.='Actions']"))}

        self.action_copy = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[.='Copy']"))}

        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.header),
            'current_param_link_button': ElementFactory(driver).define_element(self.current_param_link_button),
            'action_button': ElementFactory(driver).define_element(self.action_button),
            'action_copy': ElementFactory(driver).define_element(self.action_copy),
            'back_to_reports_button': ElementFactory(driver).define_element(self.back_to_reports_button),
        }

        self.driver = driver
        super().__init__(driver, self.elements)

    def click_current_param_link_button(self):
        self.elements['current_param_link_button'].click()

    def click_action_button(self):
        self.elements['action_button'].click()

    def get_phone_pin_status(self, user_name):
        # TODO: We need a generic method to access table cells to avoid using hardcoded index
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//td[@data-content='{user_name}']//following-sibling::td[3]"))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.get_text()

    def get_phone_status(self, user_name):
        # TODO: We need a generic method to access table cells to avoid using hardcoded index
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//td[@data-content='{user_name}']//following-sibling::td[4]"))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.get_text()

    def get_security_question_count(self, user_name):
        # TODO: We need a generic method to access table cells to avoid using hardcoded index
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//td[@data-content='{user_name}']//following-sibling::td[5]"))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.get_text()

    def click_action_copy(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['action_copy'].wait_for_visible()
        self.elements['action_copy'].click()
        return CopyReportDialog(self.driver, self.report_title)

    def click_back_to_reports(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['back_to_reports_button'].wait_for_visible()
        self.elements['back_to_reports_button'].click()
        self.elements['back_to_reports_button'].wait_for_not_visible()
        return ReportsTabPage(self.driver).wait_for_page_to_load()

