from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from selenium.webdriver.common.keys import Keys


class SelectRoleDialog(UIPage):

    dialog = {'locator':
              ElementSetLocator(element_locator=(
                  By.XPATH, "//div[contains(@class,'modal-window') and @viewparttitle='Select Role']"))}

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Select Role')]"))}

    search_role = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//span[contains(text(),'Select Role')]/ancestor::div[contains(@class, "
                                   "'x-window-header-modal')]//following-sibling::div//input[contains(@placeholder,"
                                   "'Search All Roles')]"))}

    role_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[@name='$__roleId']"))}

    select_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//span[@class='x-btn-inner x-btn-inner-center']"
                  "[.='Close']//ancestor::a//preceding-sibling::a[.='Select']"))}

    close_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//span[@class='x-btn-inner x-btn-inner-center'][.='Close']"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'search_role': factory(driver).define_text_input(self.search_role),
            'select_button': factory(driver).define_element(self.select_button),
            'close_button': factory(driver).define_element(self.close_button)
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def search_for_role(self, name):
        self.elements['search_role'].clear()
        self.elements['search_role'].type(name)
        self.elements['search_role'].type(Keys.ENTER)

    def select_role(self, name):
        xpath = f"//td[@data-content='{name}']//preceding-sibling::td//div[contains(@class, 'x-grid-row-checker')]"
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = factory(self.driver).define_element(definition)
        element.click()

    def click_select_button(self):
        self.elements['select_button'].click()

    def click_close_button(self):
        self.elements['close_button'].click()