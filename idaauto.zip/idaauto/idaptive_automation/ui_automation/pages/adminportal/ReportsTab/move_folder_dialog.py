from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.select_role_dialog import SelectRoleDialog
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.folder_move_error_dialog import FolderMoveErrorDialog
from selenium.webdriver.common.keys import Keys


class MoveFolderDialog(UIPage):

    move_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//a[.='Move'][contains(@class, 'x-btn')]"))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//a[.='Cancel'][contains(@class, 'x-btn')]"))}

    def __init__(self, driver):

        self.dialog = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, "//div[contains(@class,'modal-window') "
                          "and contains(@viewparttitle,'Select the target directory')]"))}

        self.header = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, "//span[contains(text(),'Select the target directory for')]"))}

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'move_button': factory(driver).define_element(self.move_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def select_folder_by_name(self, name):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//span[contains(text(),'Select')]"
                      f"//ancestor::div[contains(@class, 'modal-window')]//div[.='{name}']"))}
        element = factory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()

    def click_move_button(self):
        self.elements['move_button'].wait_for_visible()
        self.elements['move_button'].click()
        self.elements['dialog'].wait_for_not_visible()
        return FolderMoveErrorDialog(self.driver).wait_for_page_to_load()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()
        self.elements['dialog'].wait_for_not_visible()
