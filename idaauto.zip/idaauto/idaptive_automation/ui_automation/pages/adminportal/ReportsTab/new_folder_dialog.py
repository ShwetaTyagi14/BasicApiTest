from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.select_role_dialog import SelectRoleDialog
from selenium.webdriver.common.keys import Keys


class NewFolderDialog(UIPage):

    folder_name_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[@name='file-name']"))}

    invalid_folder_name_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[@name='file-name'][contains(@class, 'x-form-invalid-field')]"))}

    save_file_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//a[.='Save'][contains(@class, 'x-btn')]"))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//a[.='Cancel'][contains(@class, 'x-btn')]"))}

    def __init__(self, driver):

        self.dialog = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f"//div[contains(@class,'modal-window') and @viewparttitle='Create new folder']"))}

        self.header = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//span[contains(text(),'Create new folder')]"))}

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'folder_name_input_box': factory(driver).define_text_input(self.folder_name_input_box),
            'save_file_button': factory(driver).define_element(self.save_file_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'invalid_folder_name_input_box': factory(driver).define_element(self.invalid_folder_name_input_box),
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def enter_folder_name(self, name):
        self.elements['folder_name_input_box'].clear()
        self.elements['folder_name_input_box'].type(name)

    def click_save_file_button(self):
        self.elements['save_file_button'].wait_for_visible()
        self.elements['save_file_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def check_field_validation_error(self):
        return self.elements['invalid_folder_name_input_box'].is_displayed()
