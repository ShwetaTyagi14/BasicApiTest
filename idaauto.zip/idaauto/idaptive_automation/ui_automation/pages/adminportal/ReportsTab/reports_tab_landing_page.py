from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_add_edit_window import RolesAddEditWindow
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.new_folder_dialog import NewFolderDialog
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.copy_report_dialog import CopyReportDialog
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.export_report_dialog import ExportReportDialog
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.email_report_dialog import EmailReportDialog
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.move_folder_dialog import MoveFolderDialog


class ReportsTabPage(UIPage):

    reports_header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Reports"]')),
                      'inner_text': 'Reports'}

    new_report_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[.='New Report']"))}
    new_folder_menu = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[.='New folder']"))}

    action_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[.='Reports'][contains(@class, 'x-component')]//ancestor::div[contains(@class, 'title-row')]"
                  "//following-sibling::div[contains(@class, 'x-container')]//a[.='Actions']"))}

    no_action_available = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//div[.='No actions available.'][contains(@class, 'x-box-item')]"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.reports_header),
            'reports_header': ElementFactory(driver).define_element(self.reports_header),
            'new_report_button': ElementFactory(driver).define_element(self.new_report_button),
            'new_folder_menu': ElementFactory(driver).define_element(self.new_folder_menu),
            'action_button': ElementFactory(driver).define_element(self.action_button),
            'no_action_available': ElementFactory(driver).define_element(self.no_action_available),
        }

        self.driver = driver
        super().__init__(driver, self.elements)

    def click_new_report_button(self):
        self.elements['new_report_button'].click()

    def select_report_tab_by_name(self, name):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f"//span[.='{name}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()

    def select_sub_category_tab_by_name(self, name):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f"//span[.='{name}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()

    def select_shared_report_tab(self):
        self.elements['shared_reports_tab'].click()

    def select_security_tab(self):
        self.elements['security_tab'].click()

    def select_report_by_name(self, name):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f"//div[.='{name}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()

    def validate_report_name(self, name):
        definition = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f"//div[.='{name}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()

    def right_click_on_report(self, name):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//span[.='{name}']"))
        action = ActionChains(self.driver)
        action.context_click(element).perform()

    def click_new_folder_menu(self):
        self.elements['new_folder_menu'].wait_for_visible()
        self.elements['new_folder_menu'].click()
        return NewFolderDialog(self.driver).wait_for_page_to_load()

    def select_checkbox_by_report_name(self, name):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//tr[td[2][.='{name}']]/td[1]"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.click()

    def click_action_button(self):
        self.elements['action_button'].wait_for_visible()
        self.elements['action_button'].click()

    def validate_no_action_available_msg(self):
        self.elements['no_action_available'].wait_for_visible(wait_time=10)
        return self.elements['no_action_available'].is_displayed()

    def select_action_item_by_name(self, action_name, report_name):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//div[.='{action_name}'][contains(@class, 'x-box-item')]"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible(wait_time=5)
        element.click()

        if action_name == 'Copy':
            return CopyReportDialog(self.driver, report_name)
        elif action_name == 'Export Report':
            return ExportReportDialog(self.driver)
        elif action_name == 'Email Report':
            return EmailReportDialog(self.driver).wait_for_page_to_load(wait_time=10)

    def select_folder_command_by_name(self, command):
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[@test-text='{command}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible(wait_time=2)
        element.click()

        if command == 'Move':
            mfd = MoveFolderDialog(self.driver).wait_for_page_to_load(wait_time=10)
            mfd.elements['cancel_button'].wait_for_visible(wait_time=10)
            return mfd
        elif command == 'Modify':
            # TODO: Modify dialog to be defined
            return None
        elif command == 'New Folder':
            # TODO: New Folder dialog to be defined
            return None
        elif command == 'Delete':
            # TODO: Delete dialog to be defined
            return None

