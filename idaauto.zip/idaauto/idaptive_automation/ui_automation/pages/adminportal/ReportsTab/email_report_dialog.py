from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.select_role_dialog import SelectRoleDialog
from selenium.webdriver.common.keys import Keys


class EmailReportDialog(UIPage):

    email_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[@name='emailTo']"))}
    ok_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[.='OK'][contains(@class, 'x-btn')]"))}
    html_radio_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@inputvalue, 'HTML')]"))}

    excel_radio_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@inputvalue, 'EXCEL')]"))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//a[.='Cancel'][contains(@class, 'x-btn')]"))}

    invalid_email_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@class, 'x-form-invalid-field')]"))}

    invalid_email_icon = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@class, 'x-form-invalid-field')]"
                  "//ancestor::td//following-sibling::td//div[contains(@class,'x-form-invalid-icon')]"))}

    def __init__(self, driver):

        self.dialog = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, "//div[contains(@class,'modal-window') and @viewparttitle='Email Report']"))}

        self.header = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, "//span[contains(text(),'Email Report')]"))}

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'email_input_box': factory(driver).define_text_input(self.email_input_box),
            'ok_button': factory(driver).define_element(self.ok_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'invalid_email_input_box': factory(driver).define_element(self.invalid_email_input_box),
            'html_radio_button': factory(driver).define_element(self.html_radio_button),
            'excel_radio_button': factory(driver).define_element(self.excel_radio_button),
            'invalid_email_icon': factory(driver).define_element(self.invalid_email_icon),
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def enter_email_address(self, name):
        self.elements['email_input_box'].wait_for_visible()
        self.elements['email_input_box'].clear()
        self.elements['email_input_box'].type(name)

    def click_ok_button(self):
        self.elements['ok_button'].wait_for_visible()
        self.elements['ok_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def validate_invalid_email_input_box(self):
        self.elements['invalid_email_input_box'].wait_for_visible()
        return self.elements['invalid_email_input_box'].is_displayed()

    def select_html(self):
        self.elements['html_radio_button'].click()

    def select_excel(self):
        self.elements['excel_radio_button'].click()

    def validate_invalid_email_error_icon(self):
        return self.elements['invalid_email_icon'].is_displayed()

