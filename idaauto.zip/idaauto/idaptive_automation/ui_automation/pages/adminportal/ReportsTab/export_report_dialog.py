from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.select_role_dialog import SelectRoleDialog
from selenium.webdriver.common.keys import Keys


class ExportReportDialog(UIPage):

    file_name_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//input[@name='fileName']"))}
    ok_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//a[.='OK'][contains(@class, 'x-btn')]"))}
    csv_radio_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@inputvalue, 'CSV')]"))}

    excel_radio_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@inputvalue, 'Excel')]"))}

    cancel_button = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//a[.='Cancel'][contains(@class, 'x-btn')]"))}

    invalid_file_name_input_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, "//input[contains(@class, 'x-form-invalid-field')]"))}

    def __init__(self, driver):

        self.dialog = {'locator': ElementSetLocator(element_locator=(
                By.XPATH, f"//div[contains(@class,'modal-window') and @viewparttitle='Export Report']"))}

        self.header = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//span[contains(text(),'Export Report')]"))}

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'fine_name_input_box': factory(driver).define_text_input(self.file_name_input_box),
            'ok_button': factory(driver).define_element(self.ok_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'invalid_file_name_input_box': factory(driver).define_element(self.invalid_file_name_input_box),
            'csv_radio_button': factory(driver).define_element(self.csv_radio_button),
            'excel_radio_button': factory(driver).define_element(self.excel_radio_button),
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def select_reports_by_name(self, name):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//div[contains(@class, 'x-window modal-window')]//div[.='{name}']"))}
        element = factory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()

    def enter_file_name(self, name):
        self.elements['fine_name_input_box'].wait_for_visible()
        self.elements['fine_name_input_box'].clear()
        self.elements['fine_name_input_box'].type(name)

    def click_ok_button(self):
        self.elements['ok_button'].wait_for_visible()
        self.elements['ok_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def click_cancel_button(self):
        self.elements['cancel_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def validate_invalid_file_name_input_box(self):
        self.elements['invalid_file_name_input_box'].wait_for_visible(wait_time=10)
        return self.elements['invalid_file_name_input_box'].is_displayed()

    def select_excel(self):
        self.elements['excel_radio_button'].click()

    def select_csv(self):
        self.elements['csv_radio_button'].click()