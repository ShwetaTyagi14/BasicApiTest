from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.pages.adminportal.ReportsTab.select_role_dialog import SelectRoleDialog
from selenium.webdriver.common.keys import Keys


class FolderMoveErrorDialog(UIPage):

    def __init__(self, driver):

        self.dialog = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, "//div[contains(@class,'modal-window') and @dialog_type='error']"))}

        self.header = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, "//div[.='Error']"))}

        self.error_message = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, "//div[.='A Folder with that name already exists.' and @role='presentation']"))}

        self.close_button = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, "//a[.='Close'][contains(@class, 'x-btn')]"))}

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'close_button': factory(driver).define_element(self.close_button),
            'error_message': factory(driver).define_element(self.error_message),
        }
        self.driver = driver
        super().__init__(driver, self.elements)

    def click_close_button(self):
        self.elements['close_button'].wait_for_visible()
        self.elements['close_button'].click()
        self.elements['dialog'].wait_for_not_visible()

    def verify_error_message(self, error_msg):
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[.='{error_msg}']"))}
        element = factory(self.driver).define_element(definition)
        return element.is_displayed()
