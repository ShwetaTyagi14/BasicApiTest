from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from time import sleep

class DashboardsPage(UIPage):

    user_logins_tile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@title="User Logins"]'))
    }

    user_logins_by_directory_service_header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="User Logins by Directory Service"]'))
    }

    detail_header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Detail"]'))
    }

    event_detail_table = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@itemid="detailsGrid"]//tbody'))
    }

    event_detail_table_rows = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[@itemid="detailsGrid"]//tr'))
    }

    close_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Close"]'))
    }

    dashboard_selector = {
        'locator':
            ElementSetLocator(element_locator=(
                By.XPATH, '//label[.="Dashboards"]//ancestor::div[contains(@class, '
                          '"x-container x-ltr x-container-default")]//following-sibling::div'
                          '//table[@class="x-form-trigger-wrap"]'))
    }

    loading_identifier = {
        'locator':
            ElementSetLocator(element_locator=(
                By.XPATH, '//div[contains(text(),"ipsum")]'))
    }

    def __init__(self, driver):
        self.elements = {
            'user_logins_tile': ElementFactory(driver).define_element(self.user_logins_tile),
            'user_logins_by_directory_service_header': ElementFactory(driver).define_element(self.user_logins_by_directory_service_header),
            'event_detail_table': ElementFactory(driver).define_element(self.event_detail_table),
            'event_detail_table_rows': ElementFactory(driver).define_element_group(self.event_detail_table_rows),
            'detail_header': ElementFactory(driver).define_element(self.detail_header),
            'close_button': ElementFactory(driver).define_element(self.close_button),
            'dashboard_selector': ElementFactory(driver).define_element(self.dashboard_selector),
            'loading_identifier': ElementFactory(driver).define_element(self.loading_identifier),
        }

        super().__init__(driver, self.elements)

    def select_user_logins(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['user_logins_tile'].wait_for_visible()
        if self.elements['user_logins_tile'].is_displayed():
            self.elements['user_logins_tile'].click()
        else:
            self.elements['dashboard_selector'].click()
            self.select_dashboard('User Logins')

        self.elements['loading_identifier'].wait_for_not_visible(wait_time=10)

    def click_current_user(self, username):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        self.elements['user_logins_by_directory_service_header'].wait_for_visible()
        self._wait_for_events_table(username, 30)
        user_link = self.driver.find_elements(By.XPATH, '//td[.="' + username + '"]')
        user_link[2].click()

        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        
    def sort_by_detail(self, direction = False):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        self._wait_for_user_events_table(30)
        self.elements['detail_header'].click()
        row_builder = []
        rows = self.driver.find_elements(By.XPATH, '//div[@itemid="detailsGrid"]//tr')
        for i in range(len(rows)):
            row_builder.append(rows[i].text.split('\n')[1])
            
        expected_row_order = row_builder.copy()
        expected_row_order.sort(reverse=direction)

        result = True
        for idx in range(len(row_builder)):
            if row_builder[idx] != expected_row_order[idx]:
                result = False
            break

        return result
    
    
    def _wait_for_events_table(self, username, timeout = 60):
        i = 0
        rows = self.driver.find_elements(By.XPATH, '//td[.="' + username + '"]')
        while len(rows) == 0 and i < timeout:
            sleep(1)
            rows = self.driver.find_elements(By.XPATH, '//td[.="' + username + '"]')
            i = i + 1
            
    def _wait_for_user_events_table(self, timeout = 60):
        i = 0
        rows = self.driver.find_elements(By.XPATH, '//div[@itemid="detailsGrid"]//tr')
        while len(rows) == 0 and i < timeout:
            sleep(1)
            rows = self.driver.find_elements(By.XPATH, '//div[@itemid="detailsGrid"]//tr')
            i = i + 1

    def select_dashboard(self, dashboard_name):
        definition = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, f"//body/div[contains(@class, 'x-boundlist')]//li[@data-text='{dashboard_name}']"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.wait_for_visible()
        element.click()
