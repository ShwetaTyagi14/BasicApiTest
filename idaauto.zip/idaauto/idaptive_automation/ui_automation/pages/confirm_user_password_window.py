from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class ConfirmUsernamePasswordWindow(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"confirmwindow")]'))}

    user_pwd_dialog_text = {'locator':
                            ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@id,'confirmwindow') and contains(@id,'body')]"))}

    dont_continue = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, "//a[contains(@buttontext,'t continue')]"))}

    yes_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, "//a[@buttontext='Yes']")),
                  'inner_text': 'Yes'}

    def __init__(self, driver):
        self.driver = driver
        dialog = factory(driver).define_element(self.dialog)
        self.elements = {
            self.LOADED_ELEMENT: dialog,
            'dialog': dialog,
            'user_pwd_dialog_text': factory(driver).define_element(self.user_pwd_dialog_text),
            'dont_continue': factory(driver).define_element(self.dont_continue),
            'yes_button': factory(driver).define_element(self.yes_button)
        }

        super().__init__(self.driver, self.elements)

    def user_password_dialog(self):
        return self.elements['user_pwd_dialog_text'].get_text()

    def click_dont_continue(self):
        self.elements['dont_continue'].click()

    def click_yes_button(self):
        self.elements['yes_button'].click()
