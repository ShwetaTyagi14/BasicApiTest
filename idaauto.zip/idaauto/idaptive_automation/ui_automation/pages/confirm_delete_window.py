from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class ConfirmDeleteWindow(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"confirmwindow")]'))}

    yes = {'locator':
           ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"confirmwindow")]//a[@buttontext="Yes"]')),
           'inner_text': 'Yes'}

    no = {'locator':
          ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"confirmwindow")]//a[@buttontext="No"]')),
          'inner_text': 'No'}

    def __init__(self,driver):
        self.driver = driver
        dialog = factory(driver).define_element(self.dialog)
        self.elements = {
            self.LOADED_ELEMENT: dialog,
            'dialog': dialog,
            'yes_btn': factory(driver).define_element(self.yes),
            'no_btn': factory(driver).define_element(self.no)
        }

        super().__init__(self.driver,self.elements)

    def press_yes(self):
        self.elements['yes_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def press_no(self):
        self.elements['no_btn'].click()
