from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class AddAppsDialog(UIPage):
    custom_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Custom"]'))}
    add_yes_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Yes"]'))}
    close_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Close"]'))}
    saml_app_icon = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//span[@tip-text="This template enables you to provide single sign-on to a web application that uses SAML (Security Assertion Markup Language) for authentication."]')
    )}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.custom_tab),
            'custom_tab': ElementFactory(driver).define_element(self.custom_tab),
            'add_yes_button': ElementFactory(driver).define_text_input(self.add_yes_button),
            'close_btn': ElementFactory(driver).define_element(self.close_btn),
            'saml_app_icon': ElementFactory(driver).define_element(self.saml_app_icon),
        }
        super().__init__(driver, self.elements)

    def click_custom_tab(self):
        self.elements['custom_tab'].click()
        return self

    def add_featured_app(self, app):
        app_element = self.driver.wait_for_visible_element((By.XPATH, f'//span[@title="{app}"]'))
        div_parent = app_element.find_element_by_xpath('..').find_element_by_xpath('..')
        div_parent.find_element_by_link_text('Add').click()

        self.elements['add_yes_button'].wait_for_visible()
        self.elements['add_yes_button'].click()

        self.elements['close_btn'].wait_for_visible()
        self.elements['close_btn'].click()
        return self
