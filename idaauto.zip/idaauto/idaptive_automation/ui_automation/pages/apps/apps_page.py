from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.add_web_apps_dialog import AddWebAppsDialog
from idaptive_automation.ui_automation.pages.apps.app_details_page import AppDetailsPage
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class AppsPage(UIPage):
    view_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Web Apps"]'))}
    search_apps_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'search-field-input'))}
    search_apps_button = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'search-button'))}
    add_web_apps_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add Web Apps"]'))}
    provisioning_cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]'))}
    modal = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'modal-window'))}

    search_web_app = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//input[starts-with(@placeholder,"Search All Web Applications" )]',),
        parent_container_locator=(
            By.XPATH, '//input[starts-with(@placeholder,"Search All Web Applications" )]/ancestor::div[3]'),
        toggle_locator=(
        By.XPATH, '//input[starts-with(@placeholder,"Search All Web Applications" )]/ancestor::div[3]/div/div/a')),
                      'inner_text': ''}

    apps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, "//div[@class='x-grid-view x-fit-item x-ltr x-grid-view-default']//tr"))
    }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.view_title),
            'view_title': ElementFactory(driver).define_element(self.view_title),
            'search_apps_input': ElementFactory(driver).define_text_input(self.search_apps_input),
            'search_apps_button': ElementFactory(driver).define_element(self.search_apps_button),
            'add_web_apps_button': ElementFactory(driver).define_element(self.add_web_apps_button),
            'modal': ElementFactory(driver).define_element(self.modal),
            'provisioning_cancel_button': ElementFactory(driver).define_element(self.provisioning_cancel_button),
            'search_web_app': ElementFactory(driver).define_search_box(self.search_web_app),
            'apps': ElementFactory(driver).define_element_group(self.apps),
        }
        super().__init__(driver, self.elements)

    def delete_web_app(self, app):
        app_row = self.driver.wait_for_visible_element((By.XPATH, f'//div[text()="{app}"'))
        ActionChains(self.driver).context_click(app_row).perform()
        self.driver.click_element((By.XPATH, '//span[text() = "Delete"]'))
        self.elements['modal'].wait_for_visible()
        self.elements['modal'].get_element().send_keys(Keys.ENTER)

    def select_web_app(self, web_app):
        app_element = self.driver.wait_for_visible_element((By.XPATH, f'//div[text()="{web_app}"]'))
        app_element.click()
        return AppDetailsPage(self.driver)

    def click_add_web_apps_button(self):
        self.elements['add_web_apps_button'].click()
        return AddWebAppsDialog(self.driver)

    def refresh_page(self):
        self.driver.refresh()
        return self

    def cancel_provisioning(self):
        self.elements['provisioning_cancel_button'].wait_for_visible()
        self.elements['provisioning_cancel_button'].click()
        self.driver.click_element((By.XPATH, '//a[@itemid="discard"]'))
        return self

    def search_for_app(self, appname):
        self.elements['search_web_app'].search_for(appname)
        self.driver.wait_for_loading_mask_to_disappear()

    def get_apps(self):
        apps = self.elements['apps'].get_element()
        return apps
