from idaptive_automation.ui_automation.pages.apps.preview_saml_response import PreviewSAMLResponseDialog
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class SelectUserSamlResponseDialog(UIPage):

    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Select User"]')),
              'inner_text': 'Select User'}

    next_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Next"]'))}

    search_box = {'locator': ElementSetLocator(element_locator=(
        By.XPATH, f'//input[starts-with(@placeholder,"Search Users" )]',),
        parent_container_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search Users" )]/ancestor::div[3]'),
        toggle_locator=(By.XPATH, f'//input[starts-with(@placeholder,"Search Users" )]/ancestor::div[3]/div/div/a')),
        'inner_text': ''}

    cancel_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel"]'))}

    def __init__(self, driver):

        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'next_button': factory(driver).define_element(self.next_button),
            'search_box': factory(driver).define_search_box(self.search_box),
            'cancel_button': factory(driver).define_element(self.next_button)
        }

        super().__init__(driver, self.elements)

    def click_on_user(self, username):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//div[contains(@class,"modal-window")]//tr[td[2][.="{username}"]]'))}
        factory(self.driver).define_element(elem_def).click()

    def click_next_button(self):
        self.elements['next_button'].wait_for_visible()
        self.elements['next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return PreviewSAMLResponseDialog(self.driver).wait_for_page_to_load()

    def search_for_user(self, username):
        self.elements['search_box'].search_for(username)
        self.elements['cancel_button'].click()
