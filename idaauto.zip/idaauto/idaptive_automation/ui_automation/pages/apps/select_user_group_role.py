from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SelectUserGroupRolePage(UIPage):
    select_heading_link = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Select User, Group, or Role"]'))}
    search_box = {'locator': ElementSetLocator(element_locator=(
            By.XPATH, '//input[starts-with(@placeholder,"Search User & Group & Role Start With")]',),
            parent_container_locator=(
                By.XPATH,
                '//input[starts-with(@placeholder,"Search User & Group & Role Start With")]/ancestor::div[3]'),
            toggle_locator=(By.XPATH,
                            '//input[starts-with(@placeholder,"Search User & Group & Role Start With")]/ancestor::div[3]/div/div/a')),
        'inner_text': ''}
    add_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '(//a[@buttontext="Add" and @test-text="Add"])[2]'))}

    search_box_loading_mask = \
        (By.XPATH,
         '//div[contains(@class, "white-loadmask-indicator") and not(contains(@style, "display: none"))]')

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.select_heading_link),
            'select_heading_link': ElementFactory(driver).define_element(self.select_heading_link),
            'add_button': ElementFactory(driver).define_element(self.add_button),
            'search_box': ElementFactory(driver).define_search_box(self.search_box),

        }
        super().__init__(driver, self.elements)

    def search_for_role(self, rolename):
        self.elements['search_box'].search_for(rolename)
        self.wait_for_search_mask_to_disappear()

    def wait_for_search_mask_to_disappear(self, wait_for_appearance=UIPage.SHORT_DELAY,
                                          wait_for_disappearance=UIPage.LONG_DELAY):
        self.driver.wait_for_transient_element_to_come_and_go(self.search_box_loading_mask,
                                                              wait_for_appearance_time=wait_for_appearance,
                                                              wait_for_disappearance_time=wait_for_disappearance)

    def select_role_checkbox(self):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, '//div[contains(@itemid,"resultsView")]//descendant::tr[1]/td[1]'))}
        elem = ElementFactory(self.driver).define_element(elem_def)
        try:
            elem.click()
        except AttributeError:
            try:
                self.wait_for_search_mask_to_disappear(wait_for_appearance=UIPage.LONG_DELAY,
                                                       wait_for_disappearance=UIPage.LONG_DELAY)
                elem.click()
            except Exception:
                query = self.driver.get_screenshot_as_png()
                print(f'Intermittent error capture attempted: {query}')
                raise

    def click_on_add_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['add_button'].wait_for_visible()
        self.elements['add_button'].click()
        return self
