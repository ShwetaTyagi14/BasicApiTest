from idaptive_automation.ui_automation.pages.apps.select_user_for_saml_response import SelectUserSamlResponseDialog
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.select_users_dialog import SelectUsersDialog
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from selenium.webdriver.common.action_chains import ActionChains


class AppDetailsPage(UIPage):
    description_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//tr//div/span[text()="Description"]'))}

    app_name_as_title = {'locator': ElementSetLocator(element_locator=
                                                      (By.XPATH,
                                                       "//label[contains(@class,'first-row-header')]"))}

    application_name_field = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@name="Name"]'))}

    application_settings_tab = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Application Settings"]'))}

    settings_tab = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, '//tr[@test-text="Settings" and contains(@class,"tree-node-leaf")]'))}

    provisioning_tab = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, '//tr[@test-text="Provisioning" and contains(@class,"tree-node-leaf")]'))}

    application_settings_url = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="Url"]'))}

    linked_apps_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Linked Applications"]'))}

    learn_more_link = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Learn more"]'))}

    app_not_available_label = {'locator': ElementSetLocator(
        element_locator=(By.XPATH,
                         '//label[text()="User account mapping for this app is not available when provisioning is enabled."]'))}

    enable_provisioning_checkbox = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="enabled"]'))}

    enable_localization_checkbox = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="LocalizationEnabled"]'))}

    loading_dialog = {'locator': ElementSetLocator(element_locator=(By.ID, 'ext-gen1303'))}

    authorize_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Authorize"]'))}

    add_button = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add" and @itemid="addButton"]'))}

    linked_apps_rows = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[@viewparttitle='Linked Applications']//table//tr"))}

    linked_apps_first_row = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[@viewparttitle='Linked Applications']//table//tr[1]"))}

    linked_apps_first_input = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//div[@viewparttitle='Linked Applications']//table//tr[1]/td[1]"))}

    linked_apps_actions_btn = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f"//div[@viewparttitle='Linked Applications']//a[@buttontext='Actions']")),
        'inner_text': 'Actions',
        'supports_validation': False}

    linked_application_settings_url = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="DeepLinkUrl"]')),
        'supports_validation': False}

    delete = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//div[starts-with(@id,"tippedmenu-")]//a[.="Delete"]')),
        'supports_validation': False}

    grid_rows = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//table[starts-with(@id,'gridview') and contains(@id,'table')]//tr//td[2]"))}

    save_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))}

    permissions_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Permissions"]'))}

    default_permission = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                                        '//div[not(contains(@class,"set-driven")) and contains(@class,"dataGrid")]/descendant::tr[contains(@class,"row-disabled")]'))}

    permission_rows = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//descendant::tr[contains(@class,"row-disabled")]/..//tr'))}

    account_mapping = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Account Mapping"]'))}

    hostname = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="HostNameSuffix"]'))}

    changelog = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Changelog"]'))}

    add_updated = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Add"]'))}

    username = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="Username" and @name="Username"]'))}

    password = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="Password"]'))}

    rolename = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@name="RoleName"]'))}

    done = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Done"]'))}

    cancel = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'(//a[@test-text="Cancel"])'))}

    checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'(//div[@class="x-grid-row-checker"])[4]'))}

    advanced_username = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f'//input[@testname="UsernameField" and @name="UsernameField"]'))}

    advanced_password = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f'//input[@testname="PasswordField" and @name="PasswordField"]'))}

    all_users_share_one_name = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//label[normalize-space(.)="All users share one name"]/preceding-sibling::input'),
        label_text_locator=(By.XPATH, '//label[normalize-space(.)="All users share one name"]'),
        parent_container_locator=(
            By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="All users share one name"]]')),
        'label_text': 'All users share one name',
        'checked': True}

    dir_field_name = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//label[normalize-space(.)="Directory Service Field"]/preceding-sibling::input'),
        label_text_locator=(By.XPATH, '//label[normalize-space(.)="Directory Service Field"]'),
        parent_container_locator=(
            By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="Directory Service Field"]]')),
        'label_text': 'Directory Service Field',
        'checked': True}

    prompt_for_username = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//label[normalize-space(.)="Prompt for user name"]/preceding-sibling::input'),
        label_text_locator=(By.XPATH, '//label[normalize-space(.)="Prompt for user name"]'),
        parent_container_locator=(
            By.XPATH, '//table[tbody/tr/td[2]/div/label[normalize-space(.)="Prompt for user name"]]')),
        'label_text': 'Prompt for user name',
        'checked': True}

    advanced_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Advanced"]'))}

    app_status = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, "//label[@itemid='status' and contains(@class,'status-value')]"))}

    actions_menu = {'locator': ElementSetLocator(element_locator=(
        By.XPATH,
        f"//a[@buttontext='Actions' and contains(@class,'btn-blue-link')]/descendant::span[text()='Actions']")),
        'inner_text': 'Actions',
        'supports_validation': False}

    clone = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//span[@class="x-menu-item-text " and contains(text(),"Clone")]'))}

    toaster_msg = {'locator': ElementSetLocator(By.XPATH, f"//div[contains(@class,'top-toast')]")}

    change_log_add = {'locator': ElementSetLocator(By.XPATH,
                                                   f"//td[@data-content='Cloud.Saas.Application.AppAdd']//div[text()='Add']")}

    input_directory_service = {'locator':
                                   ElementSetLocator(element_locator=(By.XPATH, '//input[@name="ADAttribute"]'),
                                                     label_text_locator=(By.XPATH,
                                                                         '//input[@name="ADAttribute"]/preceding-sibling::div/label')),
                               'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    saml_response_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="SAML Response"]'))}

    count_label = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//label[contains(@class,'count-label')]"))}

    previous_page = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="previous"]'))}

    next_page = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@itemid="next"]'))}

    preview_saml_response_button = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Preview SAML Response"]'))}

    modified_toaster = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[text()='Modified.']"))}

    inherit_parent_permissions_chk = {'locator':
                                          ElementSetLocator(element_locator=(By.XPATH,
                                                                             f'//label[contains(text(),"Inherit Permissions from Parent")]/preceding-sibling::input'),
                                                            label_text_locator=(By.XPATH,
                                                                                f'//label[contains(text(),"Inherit Permissions from Parent")]'),
                                                            parent_container_locator=(By.XPATH,
                                                                                      f'//table[tbody//label[text()="Inherit Permissions from Parent"]]')),
                                      'checked': True
                                      }

    script_tag = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Provisioning Script"]'))}

    code_block = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'CodeMirror'))}

    provisioning_warning_window = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"x-window dialog")]'))}

    warning_window_close_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Close"]'))}

    licence_summary = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="License Summary"]'))}

    objects_to_provision = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Objects to provision"]'))}

    provisioning_script = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Provisioning Script"]'))}

    app_configuration_help_link = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Application Configuration Help"]'))}

    admin_username = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f'//input[@testname="AdminUserName" and @name="AdminUserName"]'))}

    admin_password = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f'//input[@testname="AdminPassword" and @name="AdminPassword"]'))}

    event_select = {
        'locator':
            ElementSetLocator((By.XPATH,
                               f'//input[ancestor::table[preceding-sibling::div] and @testname="Prop"]'),
                              toggle_locator=(By.XPATH,
                                              f'//td[.//input[@name="Prop"] and not(.//table)]/following-sibling::td')),
        'options': ['User Deleted in Active Directory',
                    'User Removed from Role or Provisioning', 'Contact Deleted in Active Directory',
                    'Contact Unselected from Provisioning', 'Group Deleted in Active Directory',
                    'Group Unselected from Provisioning', 'Resource Deleted in Active Directory',
                    'Resource Unselected from Provisioning'
                    ]
    }
    deprov_action_select = {
        'locator':
            ElementSetLocator((By.XPATH,
                               f'//input[ancestor::table[preceding-sibling::div] and @testname="Op"]'),
                              toggle_locator=(By.XPATH,
                                              f'//td[.//input[@name="Op"] and not(.//table)]/following-sibling::td')),
        'options': ['Delete Office 365 Account',
                    'Leave User Unmodified', 'Remove User Licenses',
                    'Delete Office 365 Object Account'
                    ]
    }

    inline_add_btn = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, f'//a[@itemid="inlineAddButton"]'))}

    objects_to_provision = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Objects to provision"]'))}

    app_configuration_help_link = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Application Configuration Help"]'))}

    test_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Test"]'))}

    script_editor = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Provisioning Script Editor"]'))}

    script_help = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Script Help"]'))}

    script_source_help = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Source"]//parent::div'))}

    script_destination_help = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Destination"]//parent::div'))}

    trust_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Trust"]'))}

    add_rule_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add Rule"]'))}

    event_drop_down = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@placeholder="Event"]'),
                                     toggle_locator=(By.XPATH, f'//input[@placeholder="Event"]/ancestor::td/following-sibling::td/div'))}

    de_prov_action_drop_down = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@placeholder="Deprovisioning Action"]'),
                                     toggle_locator=(By.XPATH, f'//input[@placeholder="Deprovisioning Action"]/ancestor::td/following-sibling::td/div'))}

    event_add_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@itemid="inlineAddButton"]'))}

    application_id_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text()="Application ID"]//ancestor::div[contains(@class, "x-box-item x-ltr x-container-default")]//following-sibling::table//input'))}
    category_input_box = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text()="Category "]//ancestor::div[contains(@class, "x-container x-box-item")]//following-sibling::table//input'))}
    app_key = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Copy Key"]//preceding-sibling::div//input'))}
    app_key_copy_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Copy Key"]'))}

    policy_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//tr//div/span[text()="Policy"]'))}

    policy_editor = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//pre[@class=" CodeMirror-line "]'))}

    fail_to_retrive_auth_profile_error = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Failed to retrieve authentication policy."]'))}

    corporate_pvwa_checkbox = {
        'locator': ElementSetLocator((By.XPATH, f'//label[contains(text(),"in the Password Vault")]/..//input'),
                                    parent_container_locator=(By.XPATH, f'//label[contains(text(),"in the Password Vault")]/ancestor::table[1]'))}

    bypass_login_mfa_checkbox = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//label[.="Bypass Login MFA when launching this app"]//preceding-sibling::input'))}

    bypass_login_mfa_ui_validation_rule = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//input[contains(@class,"x-form-invalid-field")]'))}

    secure_web_session_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//tr//div/span[text()="Secure Web Session"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.app_name_as_title),
            'learn_more_link': ElementFactory(driver).define_element(self.learn_more_link),
            'app_name_as_title': ElementFactory(driver).define_element(self.app_name_as_title),
            'enable_provisioning_checkbox': ElementFactory(driver).define_element(self.enable_provisioning_checkbox),
            'enable_localization_checkbox': ElementFactory(driver).define_element(self.enable_localization_checkbox),
            'loading_dialog': ElementFactory(driver).define_element(self.loading_dialog),
            'authorize_btn': ElementFactory(driver).define_element(self.authorize_btn),
            'linked_apps_tab': ElementFactory(driver).define_element(self.linked_apps_tab),
            'description_tab': ElementFactory(driver).define_element(self.description_tab),
            'application_settings_tab': ElementFactory(driver).define_element(self.application_settings_tab),
            'application_settings_url': ElementFactory(driver).define_text_input(self.application_settings_url),
            'add_button': ElementFactory(driver).define_element(self.add_button),
            'linked_apps_rows': ElementFactory(driver).define_element_group(self.linked_apps_rows),
            'linked_apps_first_input': ElementFactory(driver).define_checkbox(self.linked_apps_first_input),
            'linked_apps_first_row': ElementFactory(driver).define_element(self.linked_apps_first_row),
            'linked_apps_actions_btn': ElementFactory(driver).define_element(self.linked_apps_actions_btn),
            'linked_application_settings_url': ElementFactory(driver).define_text_input(self.linked_application_settings_url),
            'actions_menu': ElementFactory(driver).define_element(self.actions_menu),
            'delete': ElementFactory(driver).define_element(self.delete),
            'grid_rows': ElementFactory(driver).define_element_group(self.grid_rows),
            'save_btn': ElementFactory(driver).define_element(self.save_btn),
            'permissions_tab': ElementFactory(driver).define_element(self.permissions_tab),
            'advanced_tab': ElementFactory(driver).define_element(self.advanced_tab),
            'account_mapping': ElementFactory(driver).define_element(self.account_mapping),
            'hostname': ElementFactory(driver).define_text_input(self.hostname),
            'changelog': ElementFactory(driver).define_element(self.changelog),
            'add_updated': ElementFactory(driver).define_element(self.add_updated),
            'change_log_add': ElementFactory(driver).define_element(self.change_log_add),
            'prompt_for_username': ElementFactory(driver).define_checkbox(self.prompt_for_username),
            'dir_field_name': ElementFactory(driver).define_checkbox(self.dir_field_name),
            'all_users_share_one_name': ElementFactory(driver).define_checkbox(self.all_users_share_one_name),
            'app_status': ElementFactory(driver).define_element(self.app_status),
            'username': ElementFactory(driver).define_text_input(self.username),
            'password': ElementFactory(driver).define_text_input(self.password),
            'rolename': ElementFactory(driver).define_text_input(self.rolename),
            'done': ElementFactory(driver).define_element(self.done),
            'cancel': ElementFactory(driver).define_element(self.cancel),
            'checkbox': ElementFactory(driver).define_element(self.checkbox),
            'advanced_username': ElementFactory(driver).define_text_input(self.advanced_username),
            'advanced_password': ElementFactory(driver).define_text_input(self.advanced_password),
            'application_name_field': ElementFactory(driver).define_text_input(self.application_name_field),
            'clone': ElementFactory(driver).define_element(self.clone),
            'directory_service': ElementFactory(driver).define_text_input(self.input_directory_service),
            'toaster_msg': ElementFactory(driver).define_element(self.toaster_msg),
            'settings_tab': ElementFactory(driver).define_element(self.settings_tab),
            'saml_response_tab': ElementFactory(driver).define_element(self.saml_response_tab),
            'preview_saml_response_button': ElementFactory(driver).define_element(self.preview_saml_response_button),
            'modified_toaster': ElementFactory(driver).define_element(self.modified_toaster),
            'count_label': ElementFactory(driver).define_element(self.count_label),
            'previous_page': ElementFactory(driver).define_element(self.previous_page),
            'next_page': ElementFactory(driver).define_element(self.next_page),
            'default_permission': ElementFactory(driver).define_element(self.default_permission),
            'permission_rows': ElementFactory(driver).define_element_group(self.permission_rows),
            'inherit_parent_permissions_chk': ElementFactory(driver).define_checkbox(self.inherit_parent_permissions_chk),
            'app_not_available_label': ElementFactory(driver).define_element(self.app_not_available_label),
            'script_tag': ElementFactory(driver).define_element(self.script_tag),
            'code_block': ElementFactory(driver).define_element(self.code_block),
            'provisioning_tab': ElementFactory(driver).define_element(self.provisioning_tab),
            'warning_window': ElementFactory(driver).define_element(self.provisioning_warning_window),
            'close_button': ElementFactory(driver).define_element(self.warning_window_close_button),
            'licence_summary': ElementFactory(driver).define_element(self.licence_summary),
            'objects_to_provision': ElementFactory(driver).define_element(self.objects_to_provision),
            'provisioning_script': ElementFactory(driver).define_element(self.provisioning_script),
            'app_configuration_help_link': ElementFactory(driver).define_element(self.app_configuration_help_link),
            'admin_username': ElementFactory(driver).define_text_input(self.admin_username),
            'admin_password': ElementFactory(driver).define_text_input(self.admin_password),
            'event_select': ElementFactory(driver).define_select(self.event_select),
            'deprov_action_select': ElementFactory(driver).define_select(self.deprov_action_select),
            'inline_add_btn': ElementFactory(driver).define_element(self.inline_add_btn),
            'test_button': ElementFactory(driver).define_element(self.test_button),
            'script_editor': ElementFactory(driver).define_element(self.script_editor),
            'script_help': ElementFactory(driver).define_element(self.script_help),
            'script_source_help': ElementFactory(driver).define_element(self.script_source_help),
            'script_destination_help': ElementFactory(driver).define_element(self.script_destination_help),
            'trust_tab': ElementFactory(driver).define_element(self.trust_tab),
            'add_rule_button': ElementFactory(driver).define_element(self.add_rule_button),
            'event_drop_down': ElementFactory(driver).define_element(self.event_drop_down),
            'de_prov_action_drop_down': ElementFactory(driver).define_element(self.de_prov_action_drop_down),
            'event_add_button': ElementFactory(driver).define_element(self.event_add_button),
            'application_id_input_box': ElementFactory(driver).define_text_input(self.application_id_input_box),
            'category_input_box': ElementFactory(driver).define_text_input(self.category_input_box),
            'app_key': ElementFactory(driver).define_text_input(self.app_key),
            'app_key_copy_button': ElementFactory(driver).define_element(self.app_key_copy_button),
            'policy_tab': ElementFactory(driver).define_element(self.policy_tab),
            'policy_editor': ElementFactory(driver).define_element(self.policy_editor),
            'fail_to_retrive_auth_profile_error': ElementFactory(driver).define_element(self.fail_to_retrive_auth_profile_error),
            'corporate_pvwa_checkbox': ElementFactory(driver).define_checkbox(self.corporate_pvwa_checkbox),
            'bypass_login_mfa_checkbox': ElementFactory(driver).define_checkbox(self.bypass_login_mfa_checkbox),
            'bypass_login_mfa_ui_validation_rule': ElementFactory(driver).define_element(
                self.bypass_login_mfa_ui_validation_rule),
            'secure_web_session_tab': ElementFactory(driver).define_element(self.secure_web_session_tab)

        }
        super().__init__(driver, self.elements)

    def open_provisioning_tab(self):
        self.elements['provisioning_tab'].click()
        self.elements['loading_dialog'].wait_for_visible()
        self.elements['loading_dialog'].wait_for_element_to_disappear()

    def open_script_block(self):
        self.elements['script_tag'].click()
        self.elements['code_block'].wait_for_visible()
        return self

    def enable_provisioning(self):
        self.elements['enable_provisioning_checkbox'].wait_for_visible()
        self.elements['enable_provisioning_checkbox'].click()
        return self

    def click_authorize_button(self):
        self.elements['authorize_btn'].click()

    def click_linked_applications_tab(self):
        self.driver.wait_for_loading_mask_to_disappear()
        if self.elements['linked_apps_tab'].is_displayed() is True:
            self.elements['linked_apps_tab'].click()
            self.driver.wait_for_loading_mask_to_disappear()
        else:
            self.hover_and_click(element_text="Linked Applications")
            self.driver.wait_for_loading_mask_to_disappear()

    def click_description_tab(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['description_tab'].wait_for_visible()
        self.elements['description_tab'].click()

    def set_app_url(self, app_url):
        self.elements['application_settings_url'].wait_for_visible()
        self.elements['application_settings_url'].clear()
        self.elements['application_settings_url'].type(app_url)

    def click_add_button(self):
        self.driver.wait_for_visible_element(self.add_button)
        self.elements['add_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def open_linked_apps_actions_menu(self):
        self.elements['linked_apps_actions_btn'].click()

    def click_delete(self):
        self.elements['delete'].click()

    def enable_localization(self):
        self.elements['enable_localization_checkbox'].wait_for_visible()
        self.elements['enable_localization_checkbox'].click()

    def select_checkbox_for_app(self, app_name):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//tr[starts-with(@test-text,'{app_name}')]/td[1]"))}
        ElementFactory(self.driver).define_element(elem_def).click()

    def click_header_on_grid(self, header_name):
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//span[starts-with(text(),'{header_name}')]"))}
        ElementFactory(self.driver).define_element(elem_def).click()

    def get_language_list(self):
        self.elements['grid_rows'].wait_for_visible()
        language_list = self.elements['grid_rows'].get_element()
        return language_list

    def click_on_permissions_tab(self):
        self.elements['permissions_tab'].wait_for_visible()
        if self.elements['permissions_tab'].is_displayed() is True:
            self.elements['permissions_tab'].click()
        else:
            self.hover_and_click(element_text="Permissions")
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def entering_application_name_field(self, name):
        self.elements['application_name_field'].wait_for_visible()
        self.elements['application_name_field'].clear().type(name)
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_on_account_mapping(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['account_mapping'].wait_for_visible()
        self.hover_and_click(element_text='Account Mapping')
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_on_advanced(self):
        self.elements['advanced_tab'].wait_for_visible()
        self.elements['advanced_tab'].click()
        return self

    def set_hostname_suffix(self, hostname):
        self.elements['hostname'].wait_for_visible()
        self.elements['hostname'].clear()
        self.elements['hostname'].type(hostname)

    def click_all_users_share_one_name(self):
        self.elements['all_users_share_one_name'].wait_for_visible()
        self.elements['all_users_share_one_name'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def validate_app_status(self):
        return self.elements['app_status'].get_text()

    def validate_learn_more_link(self, expected_app):
        self.elements['learn_more_link'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title(expected_app)
        assert self.driver.title == expected_app
        self.driver.close()
        self.driver.switch_to_window_by_title('Admin Portal')
        return self

    def click_on_changelog(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['changelog'].wait_for_visible()
        self.hover_and_click(element_text='Changelog')
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def is_changelog_add_displayed(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['add_updated'].wait_for_visible(10)
        return self.elements['add_updated'].is_displayed()

    def is_prompt_for_username_selected(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['prompt_for_username'].wait_for_visible()
        return self.elements['prompt_for_username'].is_checked()

    def set_username(self, username):
        self.elements['username'].wait_for_visible()
        self.elements['username'].clear()
        self.elements['username'].type(username)

    def set_password(self, password):
        self.elements['password'].wait_for_visible()
        self.elements['password'].clear()
        self.elements['password'].type(password)

    def set_advanced_username(self, username):
        self.elements['advanced_username'].wait_for_visible()
        self.elements['advanced_username'].clear()
        self.elements['advanced_username'].type(username)

    def set_advanced_password(self, password):
        self.elements['advanced_password'].wait_for_visible()
        self.elements['advanced_password'].clear()
        self.elements['advanced_password'].type(password)

    def click_actions_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        elements = self.driver.find_elements_by_xpath('(//a[.="Application Configuration Help"]/..//a[.="Actions"])')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
                self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_on_clone(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['clone'].wait_for_visible()
        self.elements['clone'].click()
        self.driver.wait_for_loading_mask_to_disappear(15)
        return self

    def click_save_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['save_btn'].wait_for_visible(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['save_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)

    def checked_directory_service_field(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['dir_field_name'].wait_for_visible()
        self.elements['dir_field_name'].click()

    def set_directory_service_field(self, attribute):
        self.elements['directory_service'].clear()
        self.elements['directory_service'].type(attribute)

    def clear_directory_service_field(self):
        self.elements['directory_service'].clear()

    def is_confirm_error_icon_displayed(self):
        xpath = f'//li//ancestor::div[@role="alert" and @aria-live="polite"]'
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()

    def get_app_status(self):
        """ Use to validate the 'Toaster' text """
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['toaster_msg'].wait_for_visible()
        return self.elements['toaster_msg'].get_text()

    def get_app_name_as_title(self):
        """ Use to retrieve the 'app name' text on title """
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['app_name_as_title'].wait_for_visible()
        return self.elements['app_name_as_title'].get_text()

    def is_directory_field_name_selected(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['dir_field_name'].wait_for_visible()
        return self.elements['dir_field_name'].is_checked()

    def is_all_users_share_one_name_selected(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['all_users_share_one_name'].wait_for_visible()
        return self.elements['all_users_share_one_name'].is_checked()

    def hover_and_click(self, element_text):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//span[text()='{element_text}']"))
        self.driver.hover_over_element(by=(By.XPATH, f"//span[text()='{element_text}']"))
        element.click()
        return self

    def is_settings_tab_focused(self):
        self.driver.wait_for_loading_mask_to_disappear()
        class_attr_value = self.elements['settings_tab'].get_attribute_value('class')
        return 'focused' in class_attr_value

    def open_settings_tab(self):
        self.elements['settings_tab'].click()
        return self

    def select_prompt_for_username(self):
        self.elements['prompt_for_username'].wait_for_visible()
        if self.elements['prompt_for_username'].is_selected() is False:
            self.elements['prompt_for_username'].click()
            self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_on_saml_response_tab(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['saml_response_tab'].wait_for_visible()
        self.elements['saml_response_tab'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def click_on_preview_saml_response_button(self):
        self.elements['preview_saml_response_button'].wait_for_visible()
        self.elements['preview_saml_response_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return SelectUserSamlResponseDialog(self.driver).wait_for_page_to_load()

    def validate_modified_toaster(self):
        return self.elements['modified_toaster'].is_displayed()

    def is_default_permission_displayed(self):
        return self.elements['default_permission'].is_displayed()

    def get_permissions(self):
        self.elements['permission_rows'].wait_for_visible()
        permissions = self.elements['permission_rows'].get_element()
        return permissions

    def validate_linked_app_window(self):
        self.elements['linked_apps_first_row'].wait_for_visible()
        handles = self.get_window_handles()
        self.elements['linked_apps_first_row'].click()
        self.driver.switch_to_new_tab(handles)
        self.driver.set_page_load_timeout(time_to_wait=30)
        return

    def verify_permission_name(self, name):
        self.driver.wait_for_loading_mask_to_disappear()
        definition = {'locator': ElementSetLocator
        (element_locator=(By.XPATH,
                          f'//descendant::tr[contains(@class,"row-disabled")]/..//tr//td[contains(@data-content,"{name}")]'))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()

    def is_inherit_parent_permission_checked(self):
        self.elements['inherit_parent_permissions_chk'].wait_for_visible()
        return self.elements['inherit_parent_permissions_chk'].is_checked()

    def is_app_not_available_label_displayed(self):
        return self.elements['app_not_available_label'].is_displayed()

    def get_counter_label_text(self):
        self.driver.wait_for_visible_element(self.count_label)
        return self.elements['count_label'].get_text()

    def click_previous_page(self):
        self.elements['previous_page'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def click_next_page(self):
        self.elements['next_page'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def verify_provisioning_warning_window_displayed(self):
        return self.elements['warning_window'].is_displayed()

    def close_warning_window(self):
        self.elements['close_button'].click()

    def validate_provisioning_tab_is_loaded(self):
        self.elements['licence_summary'].wait_for_visible()
        self.elements['objects_to_provision'].wait_for_visible()
        self.elements['script_tag'].wait_for_visible()
        return self

    def validate_app_configuration_help_link(self):
        self.elements['app_configuration_help_link'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('Configuring Office 365 in the Admin Portal')
        expected_url = 'https://dev-docs.idaptive.com/Content/Applications/AppsWeb/Office365/O365_ConfigInAdmin.htm?cshid=1049'
        assert self.driver.current_url == expected_url
        self.driver.close()
        self.driver.switch_to_window_by_title('Admin Portal')
        return self

    def validate_101domain_configuration_help_link(self):
        self.elements['app_configuration_help_link'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('Add user password applications | CyberArk Docs')
        current_url = self.driver.current_url
        self.driver.close()
        self.driver.switch_to_window_by_title('Admin Portal')
        return current_url

    def set_rolename(self, rolename):
        self.elements['rolename'].wait_for_visible()
        self.elements['rolename'].clear()
        self.elements['rolename'].type(rolename)

    def click_done(self):
        self.elements['done'].click()

    def click_cancel(self):
        self.elements['cancel'].click()

    def click_checkbox(self):
        self.elements['checkbox'].click()

    def set_admin_username(self, admin_username):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['admin_username'].wait_for_visible(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['admin_username'].clear()
        self.elements['admin_username'].type(admin_username)

    def set_admin_password(self, admin_password):
        self.elements['admin_password'].wait_for_visible()
        self.elements['admin_password'].clear()
        self.elements['admin_password'].type(admin_password)

    def click_add_rule(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['add_rule_button'].scroll_into_view()
        self.elements['add_rule_button'].click()
        return self

    def select_event(self, event_name):
        if event_name not in self.event_select['options']:
            raise Exception(f'Option: {event_name} not found in options: {self.event_select["options"]}')
        self.elements['event_select'].select_option(event_name)

    def select_deprov_action(self, action_name):
        if action_name not in self.deprov_action_select['options']:
            raise Exception(f'Option: {action_name} not found in options: {self.deprov_action_select["options"]}')
        self.elements['deprov_action_select'].select_option(action_name)

    def click_inline_add(self):
        self.elements['inline_add_btn'].click()

    def delete_deprov_action(self, action_name):
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH,
                                                                    f"//*[contains(text(),'{action_name}')]/ancestor::tr/descendant::img"))}
        element = ElementFactory(self.driver).define_element(definition)
        element.click()
        return self

    def is_deprov_action_displayed_after_deletion(self, action_name):
        xpath = f"//*[contains(text(),'{action_name}')]/ancestor::tr/descendant::img"
        definition = {'locator': ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.is_displayed()


    def validate_provisioning_script_is_loaded(self):
        self.elements['script_tag'].click()
        self.elements['test_button'].wait_for_visible()
        self.elements['script_editor'].wait_for_visible()
        self.elements['script_help'].wait_for_visible()
        self.elements['script_source_help'].click()
        self.elements['script_destination_help'].click()

    def click_test_button(self):
        self.elements['test_button'].click()
        return SelectUserSamlResponseDialog(self.driver).wait_for_page_to_load()

    def click_trust_tab(self):
        self.elements['trust_tab'].click()

    def is_linked_app_available(self):
        return self.elements['linked_apps_tab'].is_displayed()

    def select_de_provisioning_event(self, event):
        self.elements['add_rule_button'].wait_for_visible()
        self.elements['add_rule_button'].click()
        self.elements['event_drop_down'].wait_for_visible(2).click()
        self.driver.find_element_by_xpath(f'//li[contains(text(), "{event}")]').click()
        return self

    def select_de_provisioning_action(self, action):
        self.elements['de_prov_action_drop_down'].wait_for_visible(2).click()
        self.driver.find_element_by_xpath(f'//li[contains(text(), "{action}")]').click()
        self.elements['event_add_button'].wait_for_visible(2).click()
        return self

    def is_save_button_disabled(self):
        class_attr_value = self.elements['save_btn'].get_attribute_value('class')
        return 'disabled' in class_attr_value

    def click_app_key_copy(self):
        self.elements['app_key_copy_button'].click()

    def get_app_key(self):
        return self.elements['app_key'].get_text()

    def click_policy_tab(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['policy_tab'].wait_for_visible()
        self.elements['policy_tab'].click()

    def set_policy(self, policy):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['policy_editor'].wait_for_visible()
        #self.elements['policy_editor'].click()
        # Unable to type
        actions = ActionChains(self.driver)
        actions.send_keys(policy)
        actions.perform()

    def is_fail_to_retrive_auth_profile_error_displayed(self):
        self.elements['fail_to_retrive_auth_profile_error'].wait_for_visible()
        return self.elements['fail_to_retrive_auth_profile_error'].is_displayed()

    def get_pvwa_status(self):
        self.elements['corporate_pvwa_checkbox'].wait_for_visible()
        visible = self.elements['corporate_pvwa_checkbox'].is_displayed()
        checked = False
        if visible: checked = self.elements['corporate_pvwa_checkbox'].is_checked()
        return visible, checked

    def get_pvwa_text(self):
        definition = {'locator': ElementSetLocator((By.XPATH, f'//label[contains(text(),"in the Password Vault")]'))}
        element = ElementFactory(self.driver).define_element(definition)
        return element.get_text()

    def click_bypass_login_mfa_checkbox(self):
        self.elements['bypass_login_mfa_checkbox'].wait_for_visible()
        self.elements['bypass_login_mfa_checkbox'].click()

    def verify_bypass_login_mfa_ui_validation_rule(self):
        self.elements['bypass_login_mfa_ui_validation_rule'].wait_for_visible()
        return self.elements['bypass_login_mfa_ui_validation_rule'].is_displayed()

    def validate_input_text_is_read_only(self, value):
        self.elements[f'{value}'].wait_for_visible()
        read_only = self.elements[f'{value}'].get_attribute_value("readonly")
        return read_only

    def click_secure_web_session_tab(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['secure_web_session_tab'].wait_for_visible()
        self.elements['secure_web_session_tab'].click()