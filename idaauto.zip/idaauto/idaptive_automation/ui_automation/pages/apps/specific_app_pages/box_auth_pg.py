from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from idaptive_automation.ui_automation.pages.apps.add_web_apps_dialog import AddAppsDialog
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class BoxAuthPage(UIPage):
    login_input = {'locator': ElementSetLocator(element_locator=(By.ID, 'login'))}
    password_input = {'locator': ElementSetLocator(element_locator=(By.ID, 'password'))}
    authorize_btn = {'locator': ElementSetLocator(element_locator=(By.NAME, 'login_submit'))}
    grant_access_btn = {'locator': ElementSetLocator(element_locator=(By.ID, 'consent_accept_button'))}
    authorization_sucess_div = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text() = "Authorization Success"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.login_input),
            'login_input': ElementFactory(driver).define_text_input(self.login_input),
            'password_input': ElementFactory(driver).define_text_input(self.password_input),
            'authorize_btn': ElementFactory(driver).define_element(self.authorize_btn),
            'grant_access_btn': ElementFactory(driver).define_element(self.grant_access_btn),
            'authorization_sucess_div' : ElementFactory(driver).define_element(self.authorization_sucess_div)
        }
        super().__init__(driver, self.elements)

    def authorize_box(self, username, password):
        self.elements['login_input'].type(username)
        self.elements['password_input'].type(password)
        self.elements['authorize_btn'].click()
        self.elements['grant_access_btn'].wait_for_visible()
        self.elements['grant_access_btn'].click()

        return self.elements['authorization_sucess_div'].wait_for_visible() is not None
