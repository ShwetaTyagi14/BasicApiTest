from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class PreviewSAMLResponseDialog(UIPage):

    preview_header = {'locator':
                      ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"modal-window")]//span[text()="Preview SAML Response"]')),
                      'inner_text': 'Preview SAML Response'}

    preview_text = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'(//textarea[starts-with(@id,"jsutil-textarea-") and @name="script-output"])[1]'))}

    close_button = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Close"]')),
                    'inner_text': 'Close'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.preview_header),
            'preview_header': factory(driver).define_element(self.preview_header),
            'preview_text': factory(driver).define_element(self.preview_text),
            'close_button': factory(driver).define_element(self.close_button)
        }

        super().__init__(driver, self.elements)

    def is_confirm_preview_saml_response_xml_displayed(self):
        return self.elements['preview_text'].is_displayed()

    def close_preview_saml_response_window(self):
        self.elements['close_button'].wait_for_visible()
        self.elements['close_button'].click()
