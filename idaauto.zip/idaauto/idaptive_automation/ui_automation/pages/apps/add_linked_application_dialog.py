from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class AddLinkedAppDialog(UIPage):
    dialog = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'modal-window') and @viewparttitle='Add Linked Application']"))}
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//span[contains(text(),'Add Linked Application')]"))}
    cancel = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Cancel" and @itemid="cancelButton"]'))}
    next = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Next >" and @itemid="nextButton"]'))}
    close = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'modal-window')]/descendant::img[contains(@class,'close')]"))}
    finish = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Finish" and @itemid="nextButton"]'))}
    grid = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@itemid,'resultsView')]"))}
    grid_rows = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@itemid,'resultsView')]//descendant::tr"))}
    first_row_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@itemid,'resultsView')]//descendant::tr[1]/td[1]"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.dialog),
            'dialog': factory(driver).define_element(self.dialog),
            'header': factory(driver).define_element(self.header),
            'cancel': factory(driver).define_element(self.cancel),
            'next': factory(driver).define_element(self.next),
            'close': factory(driver).define_element(self.close),
            'finish': factory(driver).define_element(self.finish),
            'grid': factory(driver).define_element(self.grid),
            'grid_rows': factory(driver).define_element_group(self.grid_rows),
            'first_row_checkbox': factory(driver).define_checkbox(self.first_row_checkbox)
        }

        super().__init__(driver, self.elements)

    def press_cancel(self):
        self.elements['cancel'].click()

    def press_next(self):
        self.elements['next'].click()

    def press_close(self):
        self.elements['close'].click()

    def press_finish(self):
        self.elements['finish'].wait_for_visible()
        self.elements['finish'].click()

    def get_child_apps(self):
        apps = self.elements['grid_rows'].get_element()
        return apps

    def select_first_row(self):
        self.elements['first_row_checkbox'].click()