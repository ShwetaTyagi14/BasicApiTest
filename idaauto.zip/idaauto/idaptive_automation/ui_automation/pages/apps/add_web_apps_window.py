from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class AddWebAppsWindow(UIPage):
    custom_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Custom"]'))}
    add_web_apps_header = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[text()="Add Web Apps"]'))}
    search_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Search"]'))}
    import_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Import"]'))}
    upload_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@id,'filefield') and @buttontext='Upload']"))}
    apps_add_buttons = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'grid-body')]/descendant::span[text()='Add']"))}
    apps_remove_buttons = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'grid-body')]/descendant::span[text()='Remove']"))}
    first_add_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[contains(@class,'grid-body')]/descendant::span[text()='Add'][1]"))}
    remove_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//descendant::span[text()='Remove']"))}
    add_yes_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Yes"]'))}
    close_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Close"]'))}
    saml_app_icon = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//span[@tip-text="This template enables you to provide single sign-on to a web application that uses SAML (Security Assertion Markup Language) for authentication."]')
    )}
    search_apps_input = {'locator':
                         ElementSetLocator(element_locator=(
                             By.XPATH, f"//input[@name='search-field-input' and @placeholder='Search']"))}
    loading_mask = {'locator':
                    ElementSetLocator(element_locator=(
                        By.XPATH, '//div[@id="mechanismSelectionForm" and @class="login-form masked"]')),
                    'supports_validation': False}

    save_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))}
    add_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Add"]'))}
    browser_extension_add_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Browser Extension"]/parent::div/preceding-sibling::a/span[text()="Add"]'))}
    add_ntlm_app = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="NTLM and Basic"]/parent::div/preceding-sibling::a/span[text()="Add"]'))}
    search_web_app = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@placeholder="Search"]',),
                                                   parent_container_locator=(By.XPATH, '//input[@placeholder="Search"]/ancestor::div[3]'),
                                                   toggle_locator=(By.XPATH,'//input[@placeholder="Search"]/ancestor::div[3]/div/div/a')),
                      'inner_text': 'Search'}
    apps = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//div[@class='x-grid-view x-fit-item x-ltr x-grid-view-default x-unselectable']"))}

    invalid_search_message = {'locator':ElementSetLocator(element_locator=(By.XPATH, "//div[@class='x-grid-empty']"))}

    toaster_msg = {'locator': ElementSetLocator(By.XPATH, f"//div[contains(@class,'top-toast')]")}

    app_added = {'locator': ElementSetLocator(By.XPATH, f'//div[text()="Application Added"]')}

    app_categories = {'locator': ElementSetLocator(By.XPATH, f'//div[contains(@itemid,"categoryList")]/span[contains(@class,"category")]')}

    _file_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="file"]'))
    }

    _add_generic_saml = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//tr[@test-id = "Generic SAML"]//a//span'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.first_add_button),
            'custom_tab': ElementFactory(driver).define_element(self.custom_tab),
            'add_web_apps_header': ElementFactory(driver).define_element(self.add_web_apps_header),
            'search_tab': ElementFactory(driver).define_element(self.search_tab),
            'import_tab': ElementFactory(driver).define_element(self.import_tab),
            'upload_button': ElementFactory(driver).define_element(self.upload_button),
            'apps_add_buttons': ElementFactory(driver).define_element_group(self.apps_add_buttons),
            'first_add_button': ElementFactory(driver).define_element(self.first_add_button),
            'apps_remove_buttons': ElementFactory(driver).define_element_group(self.apps_remove_buttons),
            'add_yes_button': ElementFactory(driver).define_element(self.add_yes_button),
            'remove_button': ElementFactory(driver).define_element(self.remove_button),
            'close_btn': ElementFactory(driver).define_element(self.close_btn),
            'saml_app_icon': ElementFactory(driver).define_element(self.saml_app_icon),
            'loading_mask': ElementFactory(driver).define_element(self.loading_mask),
            'search_apps_input': ElementFactory(driver).define_text_input(self.search_apps_input),
            'browser_extension_add_btn': ElementFactory(driver).define_element(self.browser_extension_add_btn),
            'add_ntlm_app': ElementFactory(driver).define_element(self.add_ntlm_app),
            'save_btn': ElementFactory(driver).define_element(self.save_btn),
            'add_button': ElementFactory(driver).define_element(self.add_button),
            'search_web_app': ElementFactory(driver).define_search_box(self.search_web_app),
            'apps': ElementFactory(driver).define_element_group(self.apps),
            'invalid_search_message': ElementFactory(driver).define_element(self.invalid_search_message),
            'toaster_msg': ElementFactory(driver).define_element(self.toaster_msg),
            'app_added': ElementFactory(driver).define_element(self.app_added),
            'app_categories': ElementFactory(driver).define_element_group(self.app_categories),
            'file_input': ElementFactory(driver).define_text_input(self._file_input),
            'add_generic_saml_button': ElementFactory(driver).define_element(self._add_generic_saml)
        }
        super().__init__(driver, self.elements)

    def click_custom_tab(self):
        self.elements['custom_tab'].click()
        return self

    def click_import_tab(self):
        self.elements['import_tab'].click()
        return self

    def add_featured_app(self, app):
        app_element = self.driver.wait_for_visible_element((By.XPATH, f'//span[text()="{app}"]'))
        div_parent = app_element.find_element_by_xpath('..').find_element_by_xpath('..')
        div_parent.find_element_by_link_text('Add').click()

        self.elements['add_yes_button'].wait_for_visible()
        self.elements['add_yes_button'].click()
        self.elements['remove_button'].wait_for_visible()
        self.elements['close_btn'].wait_for_visible()
        self.elements['close_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def get_add_buttons(self):
        add_buttons = self.elements['apps_add_buttons'].get_element()
        return add_buttons

    def get_remove_buttons(self):
        remove_buttons = self.elements['apps_remove_buttons'].get_element()
        return remove_buttons

    def click_first_apps_add_button(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        self.elements['first_add_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def click_remove_button(self):
        self.elements['remove_button'].wait_for_visible()
        self.elements['remove_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def search_app_input(self, app_name):
        self.elements['search_apps_input'].type(app_name)
        self.elements['search_apps_input'].wait_for_not_visible()

    def click_close_button(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['close_btn'].wait_for_visible()
        self.elements['close_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    # new copy
    def click_add_ntlm_and_basic_app(self):
        self.elements['add_ntlm_app'].wait_for_visible()
        self.elements['add_ntlm_app'].click()
        self.driver.wait_for_loading_mask_to_disappear()
        return self

    def click_close_and_save_button(self):
        self.elements['save_btn'].click()
        self.elements['close_btn'].wait_for_visible()
        self.elements['close_btn'].click()
        self.elements['save_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def click_save_button(self):
        self.elements['save_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def click_on_add_button(self):
        self.elements['add_button'].wait_for_visible()
        self.elements['add_button'].click()
        return self

    def is_remove_button_displayed(self):
        return self.elements['remove_button'].is_displayed()

    def is_first_add_button_displayed(self):
        return self.elements['first_add_button'].is_displayed()

    def search_for_app(self, appname):
        self.elements['search_web_app'].clear()
        self.elements['search_web_app'].search_for(appname)
        self.driver.wait_for_loading_mask_to_disappear(30)

    def get_apps(self):
        apps = self.elements['apps'].get_element()
        return apps

    def get_apps_help_list(self):
        apps_help_list = self.driver.find_elements_by_xpath("//span[text()='I']")
        return apps_help_list

    def get_app_categories(self):
        app_categories = self.driver.find_elements_by_xpath("//div[contains(@itemid,'categoryList')]/span[contains(@class,'category')]")
        return app_categories

    def get_app_category_names(self):
        app_category_names = self.driver.find_elements_by_xpath(
            "//div[contains(@itemid,'categoryList')]/span[contains(@class,'category')]")
        category_names = [el.text for el in app_category_names]
        return category_names

    def get_invalid_search_message(self):
        return self.elements['invalid_search_message'].get_text()

    def is_tab_active(self, tab_name):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.driver.wait_for_visible_element(f"//a[@buttontext='{tab_name}']")
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//a[@buttontext='{tab_name}']"))}
        atr_text = ElementFactory(self.driver).define_element(elem_def).get_attribute_value('class')
        return "active" in atr_text

    def is_search_tab_active(self):
        return self.is_tab_active(tab_name='Search')

    def is_category_selected(self,app_category_name):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.driver.wait_for_visible_element(f"//span[text()='{app_category_name}']")
        elem_def = {'locator': ElementSetLocator(
            element_locator=(By.XPATH, f"//span[text()='{app_category_name}']"))}
        atr_text = ElementFactory(self.driver).define_element(elem_def).get_attribute_value('class')
        return "selected" in atr_text

    def is_add_button_clickable(self):
        return self.driver.wait_for_clickable_element(self.first_add_button)

    def is_upload_button_clickable(self):
        self.driver.hover_over_element(by=(By.XPATH, f"//div[contains(@id,'filefield') and @buttontext='Upload']"))
        upload_btn_class_attr = self.elements['upload_button'].get_attribute_value('class')
        return 'btn-over' in upload_btn_class_attr

    def is_add_web_apps_header_displayed(self):
        return self.elements['add_web_apps_header'].is_displayed()
    
    def is_app_added(self):
        """ Use to validate the 'Application added' text """
        return self.elements['app_added'].is_displayed()

    def get_app_status(self):
        """ Use to validate the 'Toaster' text """
        return self.elements['toaster_msg'].get_text()

    def set_filename(self, filename):
        script = '(function(){var element = document.querySelector("input[name=\'file\']");element.classList.remove("x-form-file-input");})()'
        self.driver.execute_script(script)
        self.elements['file_input'].clear().type(filename)
        return self

    def click_add_generic_saml_app(self):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        self.elements['add_generic_saml_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)

    def click_add_for_app_type_from_search(self, type):
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        xpath = f'//span[.= "{type}"]/ancestor::div[contains(@class,"app-result")]//a/span[.="Add"]'
        definition = {'locator':
                          ElementSetLocator(element_locator=(By.XPATH, xpath))}
        element = ElementFactory(self.driver).define_element(definition)
        element.click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)


