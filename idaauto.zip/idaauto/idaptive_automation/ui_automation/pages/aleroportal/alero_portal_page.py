from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator

class AleroPortalPage(UIPage):
    tenant_logo = {'locator': ElementSetLocator(element_locator=(By.XPATH, "//img[@class='tenants-page__top-container__logo']"))}

    def __init__(self, driver):
        self.elements = {
            'tenant_logo': ElementFactory(driver).define_element(self.tenant_logo)
        }

        super().__init__(driver, self.elements)

    def is_page_loaded(self):
        return self.elements['tenant_logo'].wait_for_visible() is not None
