import time
from idaptive_automation.ui_automation.pages.jobhistory.job_history_page import JobHistoryPage
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.pages.inboundprovisioning.inbound_documentation import InboundDocumentation
from idaptive_automation.ui_automation.pages.inboundprovisioning.provisioning_source_dialog import ProvisioningSourceDialog


class InboundProvisioningPage(UIPage):
    source_xpath = f'//input[@value="All Sources"]'
    toggle_xpath = Xpaths.SELECT_TOGGLE

    view_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Inbound Provisioning"]'))}
    inbound_modal = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'modal-window'))}
    del_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Delete"]'))}
    yes_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Yes"]'))}
    add_source_button = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Add Source'))}
    learn_more_link = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Learn more'))}
    sync_options_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Sync Options"]'))}
    full_sync_option = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//input[@testname="manualSyncType" and @inputvalue="FullSync"]'))}
    incremental_sync_option = {'locator': ElementSetLocator(
        element_locator=(By.XPATH, '//input[@testname="manualSyncType" and @inputvalue="IncrementalSync"]'))}
    sources_select = {
        'locator':
            ElementSetLocator((By.XPATH,
                               f'//input[@placeholder="Source"]'),
                              toggle_locator=(By.XPATH,
                                              f'//td[.//input[@placeholder="Source"] and not(.//table)]/following-sibling::td'))
    }
    run_sync = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Run Sync"]'))}
    view_job_reports_link = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'View Synchronization Job Status and Reports'))}
    disabled_txt = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//*[contains(text(), "Disabled")]'))}
    modify = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Modify"]'))}
    all_sources_drop_down = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@value="All Sources"]'),
    toggle_locator=(By.XPATH, f'{source_xpath}{toggle_xpath}'))}
    add_rule = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Add Rule"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.view_title),
            'view_title': ElementFactory(driver).define_element(self.view_title),
            'inbound_modal': ElementFactory(driver).define_element(self.inbound_modal),
            'del_button': ElementFactory(driver).define_element(self.del_button),
            'yes_button': ElementFactory(driver).define_element(self.yes_button),
            'add_source_button': ElementFactory(driver).define_element(self.add_source_button),
            'learn_more_link': ElementFactory(driver).define_element(self.learn_more_link),
            'sync_options_tab': ElementFactory(driver).define_element(self.sync_options_tab),
            'view_job_reports_link': ElementFactory(driver).define_element(self.view_job_reports_link),
            'disabled_txt': ElementFactory(driver).define_element(self.disabled_txt),
            'full_sync_option': ElementFactory(driver).define_element(self.full_sync_option),
            'incremental_sync_option': ElementFactory(driver).define_element(self.incremental_sync_option),
            'run_sync': ElementFactory(driver).define_element(self.run_sync),
            'sources_select': ElementFactory(driver).define_select(self.sources_select),
            'modify': ElementFactory(driver).define_element(self.modify),
            'all_sources_drop_down': ElementFactory(driver).define_select(self.all_sources_drop_down),
            'add_rule': ElementFactory(driver).define_element(self.add_rule)
        }
        super().__init__(driver, self.elements)

    def add_inbound_source(self):
        self.elements['add_source_button'].click()
        return ProvisioningSourceDialog(self.driver).wait_for_page_to_load()

    def click_learn_more_link(self):
        self.elements['learn_more_link'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('Inbound provisioning')
        return InboundDocumentation(self.driver)

    def click_sync_options_tab(self):
        self.elements['sync_options_tab'].click()
        return self

    def click_view_reports_link(self):
        self.elements['view_job_reports_link'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('Job History')
        return JobHistoryPage(self.driver)

    def check_inbound_source(self, source):
        source_row = self.driver.find_element_by_xpath(f'//span[contains(text(), "{source}")]').find_element_by_xpath('..')
        source_row.find_element_by_class_name('x-tree-checkbox').click()
        return self

    def refresh_page(self):
        self.driver.refresh()
        time.sleep(3)

    def click_actions_button(self):
        elements = self.driver.find_elements_by_xpath('//a[@buttontext="Actions"]')
        for item in elements:
            if item.is_displayed() is True:
                item.click()
        return self

    def is_no_actions_visible(self):
        element = self.driver.wait_for_visible_element((By.XPATH, '//div[contains(text(), "No actions available")]'))
        return self, element

    def click_delete_item(self):
        self.elements['del_button'].click()

    def press_yes_btn(self):
        self.elements['yes_button'].click()

    def is_disabled_displayed(self):
        return self.elements['disabled_txt'].is_displayed()

    def Search_inbound_source(self, source):
        source_row = self.driver.find_element_by_xpath(f'//span[contains(text(), "{source}")]').find_element_by_xpath('..')
        assert source_row.is_displayed() is True

    def click_full_syc_option(self):
        self.elements['full_sync_option'].wait_for_visible()
        self.elements['full_sync_option'].click()

    def set_source_type(self,value):
        self.elements['sources_select'].select_option(value)

    def click_run_syc_button(self):
        self.elements['run_sync'].wait_for_visible()
        self.elements['run_sync'].click()

    def double_click_run_syc_button(self):
        element = self.elements['run_sync'].get_element()
        ActionChains(self.driver).double_click(element).perform()

    def click_modify_item(self):
        self.elements['modify'].click()
        return ProvisioningSourceDialog(self.driver).wait_for_page_to_load()

    def get_all_sources_drop_down_list(self):
        self.elements['all_sources_drop_down'].click()
        options = self.elements['all_sources_drop_down'].get_options()
        return options

    def click_add_rule_item(self):
        self.elements['add_rule'].click()
        return self
