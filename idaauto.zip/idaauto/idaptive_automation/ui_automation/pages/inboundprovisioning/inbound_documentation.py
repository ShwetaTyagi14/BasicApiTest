from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class InboundDocumentation(UIPage):
    page_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//h1[text()="Inbound Provisioning"]'))}
    submenu_inbound_provisioning = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Inbound provisioning'))}
    submenu_bamboohr_provisioning = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Inbound Provisioning from BambooHR'))}
    submenu_successfactors_provisioning = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Inbound Provisioning from SAP SuccessFactors'))}
    submenu_ultipro_provisioning = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Inbound Provisioning from UltiPro'))}
    submenu_workday_provisioning = {'locator': ElementSetLocator(element_locator=(By.LINK_TEXT, 'Inbound Provisioning from Workday'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.page_title),
            'page_title': ElementFactory(driver).define_element(self.page_title),
            'submenu_inbound_provisioning': ElementFactory(driver).define_element(self.submenu_inbound_provisioning),
            'submenu_bamboohr_provisioning': ElementFactory(driver).define_element(self.submenu_bamboohr_provisioning),
            'submenu_successfactors_provisioning': ElementFactory(driver).define_element(self.submenu_successfactors_provisioning),
            'submenu_ultipro_provisioning': ElementFactory(driver).define_element(self.submenu_ultipro_provisioning),
            'submenu_workday_provisioning': ElementFactory(driver).define_element(self.submenu_workday_provisioning)
        }
        super().__init__(driver, self.elements)

    def is_page_loaded(self):
        return self.elements['page_title'].wait_for_visible() is not None

    def close_inbound_documentation(self):
        if self.driver.title == 'Inbound provisioning':
            self.driver.close()
            self.driver.switch_to_window_by_title('Admin Portal')
            return True
        return False
