import time

from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class ProvisioningSourceDialog(UIPage):
    source_xpath = f'//input[@testname="SourceName"]'
    toggle_xpath = Xpaths.SELECT_TOGGLE

    #region Settings
    view_title = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//div[@viewparttitle="Provisioning Source"]'))}
    source_drop_down = {'locator': ElementSetLocator(element_locator=(By.NAME, 'SourceName'),
                                                     toggle_locator=(By.XPATH, f'{source_xpath}{toggle_xpath}'))}
    enable_instance_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="IsInstanceEnabled"]'),
                                                             label_text_locator=(By.XPATH, '//input[@testname="IsInstanceEnabled"]/following-sibling::label'),
                                                             parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="IsInstanceEnabled"]]'))}
    enable_write_back_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="IsSourceWriteEnabled"]'),
                                                               label_text_locator=(By.XPATH, '//input[@testname="IsSourceWriteEnabled"]/following-sibling::label'),
                                                               parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="IsSourceWriteEnabled"]]'))}
    name_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="Name"]'))}
    workday_url_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'WorkdayUrl'))}
    auth_username_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'Auth_UserName'))}
    auth_encrypted_password = {'locator': ElementSetLocator(element_locator=(By.NAME, 'Auth_Encrypted_Password'))}
    show_password_button = {'locator': ElementSetLocator(element_locator=(By.CLASS_NAME, 'show-password'))}
    verify_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Verify"]'))}
    #endregion

    #region Report Integration Tab
    enable_report_integration_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="EnableCustomAttributes"]'),
                                                                       label_text_locator=(By.XPATH, '//input[@testname="EnableCustomAttributes"]/following-sibling::label'),
                                                                       parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="EnableCustomAttributes"]]'))}
    base_report_url_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'BaseReportUrl'))}
    relative_schema_url_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'CustomReportXmlSchemaUrl'))}
    relative_json_data_url_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'CustomReportJsonDataUrl'))}
    worker_unique_id_field_name_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'CustomReportWorkdayIdField'))}
    report_query_timeout_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'CustomReportQueryTimeoutMinutes'))}
    #endregion

    #region Sync Settings Tab
    enable_new_hire_pre_provisioning_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="EnableNewUserPreProvisioning"]'),
                                                                              label_text_locator=(By.XPATH, '//input[@testname="EnableNewUserPreProvisioning"]/following-sibling::label'),
                                                                              parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="EnableNewUserPreProvisioning"]]'))}
    enable_new_hire_pre_provisioning_interval_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="NewUserPreProvisionIntervalHours"]'))}
    run_incremental_sync_automatically_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="EnableIncrementalSyncs"]'))}
    run_incremental_sync_automatically_frequency_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="IncrementalSyncRepeatIntervalInMinutes"]'))}
    tenant_utc_offset_input = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="InboundProvTenantUtcOffset"]'))}
    do_not_create_new_users_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="UpdateExistingUsersOnly"]'))}
    ignore_sync_cache_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="IgnoreUuidFromCacheIfCacheIgnored"]'))}
    discard_directory_identifiers_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="IgnoreFromCacheIfCacheIgnored"]'))}
    #endregion

    #region Sync Reports Tab
    send_report_on_completion_checkbox = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="EnableSyncNotificationEmails"]'),
                                                                       label_text_locator=(By.XPATH, '//input[@testname="EnableSyncNotificationEmails"]/following-sibling::label'),
                                                                       parent_container_locator=(By.XPATH, '//table[tbody/tr/td/div[2]/input[@testname="EnableSyncNotificationEmails"]]'))}
    sync_report_type_dropdown = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="NotificationOptions"]'))}
    distribution_add_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Add"]'))}
    sync_report_email_input = {'locator': ElementSetLocator(element_locator=(By.NAME, 'email'))}
    #endregion

    #region Tab Menu
    report_integration_menu = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Report Integration"]'))}
    sync_settings_menu = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Sync Settings"]'))}
    sync_reports_menu = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Sync Reports"]'))}
    #endregion

    save_provisioning_source_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Save"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.view_title),
            'view_title': ElementFactory(driver).define_element(self.view_title),
            'source_drop_down': ElementFactory(driver).define_select(self.source_drop_down),
            'enable_instance_checkbox': ElementFactory(driver).define_checkbox(self.enable_instance_checkbox),
            'enable_write_back_checkbox': ElementFactory(driver).define_element(self.enable_write_back_checkbox),
            'name_input': ElementFactory(driver).define_text_input(self.name_input),
            'workday_url_input': ElementFactory(driver).define_text_input(self.workday_url_input),
            'auth_username_input': ElementFactory(driver).define_text_input(self.auth_username_input),
            'auth_encrypted_password': ElementFactory(driver).define_text_input(self.auth_encrypted_password),
            'show_password_button': ElementFactory(driver).define_element(self.show_password_button),
            'verify_button': ElementFactory(driver).define_element(self.verify_button),
            'enable_report_integration_checkbox': ElementFactory(driver).define_checkbox(self.enable_report_integration_checkbox),
            'base_report_url_input': ElementFactory(driver).define_text_input(self.base_report_url_input),
            'relative_schema_url_input': ElementFactory(driver).define_text_input(self.relative_schema_url_input),
            'relative_json_data_url_input': ElementFactory(driver).define_text_input(self.relative_json_data_url_input),
            'worker_unique_id_field_name_input': ElementFactory(driver).define_text_input(self.worker_unique_id_field_name_input),
            'report_query_timeout_input': ElementFactory(driver).define_text_input(self.report_query_timeout_input),
            'enable_new_hire_pre_provisioning_checkbox': ElementFactory(driver).define_checkbox(self.enable_new_hire_pre_provisioning_checkbox),
            'enable_new_hire_pre_provisioning_interval_input': ElementFactory(driver).define_text_input(self.enable_new_hire_pre_provisioning_interval_input),
            'run_incremental_sync_automatically_checkbox': ElementFactory(driver).define_element(self.run_incremental_sync_automatically_checkbox),
            'run_incremental_sync_automatically_frequency_input': ElementFactory(driver).define_element(self.run_incremental_sync_automatically_frequency_input),
            'tenant_utc_offset_input': ElementFactory(driver).define_text_input(self.tenant_utc_offset_input),
            'do_not_create_new_users_checkbox': ElementFactory(driver).define_element(self.do_not_create_new_users_checkbox),
            'ignore_sync_cache_checkbox': ElementFactory(driver).define_element(self.ignore_sync_cache_checkbox),
            'discard_directory_identifiers_checkbox': ElementFactory(driver).define_element(self.discard_directory_identifiers_checkbox),
            'send_report_on_completion_checkbox': ElementFactory(driver).define_checkbox(self.send_report_on_completion_checkbox),
            'sync_report_type_dropdown': ElementFactory(driver).define_element(self.sync_report_type_dropdown),
            'distribution_add_button': ElementFactory(driver).define_element(self.distribution_add_button),
            'sync_report_email_input': ElementFactory(driver).define_element(self.sync_report_email_input),
            'report_integration_menu': ElementFactory(driver).define_element(self.report_integration_menu),
            'sync_settings_menu': ElementFactory(driver).define_element(self.sync_settings_menu),
            'sync_reports_menu': ElementFactory(driver).define_element(self.sync_reports_menu),
            'save_provisioning_source_button': ElementFactory(driver).define_element(self.save_provisioning_source_button)
        }
        super().__init__(driver, self.elements)

    def click_report_integration_menu(self):
        self.elements['report_integration_menu'].click()
        return self

    def click_sync_settings_menu(self):
        self.elements['sync_settings_menu'].click()
        return self

    def click_sync_reports_menu(self):
        self.elements['sync_reports_menu'].click()
        return self

    def select_inbound_source(self, value):
        self.elements['source_drop_down'].select_option(value)
        return self

    def input_source_name(self, value):
        self.elements['name_input'].clear()
        self.elements['name_input'].type(value)
        return self

    def input_source_url(self, value):
        self.elements['workday_url_input'].clear()
        self.elements['workday_url_input'].type(value)
        return self

    def input_source_username(self, value):
        self.elements['auth_username_input'].clear()
        self.elements['auth_username_input'].type(value)
        return self

    def input_source_password(self, value):
        self.elements['auth_encrypted_password'].clear()
        self.elements['auth_encrypted_password'].type(value)
        return self

    def get_instance_enabled(self):
        return self, self.elements['enable_instance_checkbox'].is_enabled()

    def get_name_input_enabled(self):
        return self, self.elements['name_input'].is_enabled()

    def get_verify_button_enabled(self):
        return self, 'x-btn-disabled' not in self.elements['verify_button'].get_class()

    def get_write_back_enabled(self):
        return self, self.elements['enable_write_back_checkbox'].is_enabled()

    def get_workday_url_enabled(self):
        return self, self.elements['workday_url_input'].is_enabled()

    def get_username_input_enabled(self):
        return self, self.elements['auth_username_input'].is_enabled()

    def get_password_input_enabled(self):
        return self, self.elements['auth_encrypted_password'].is_enabled()

    def get_password_mask(self):
        return self, self.elements['auth_encrypted_password'].get_attribute_value('type')

    def click_show_password(self):
        self.elements['show_password_button'].click()
        return self

    def get_report_integration_enabled(self):
        return self, self.elements['enable_report_integration_checkbox'].is_enabled()

    def click_report_integration(self):
        self.elements['enable_report_integration_checkbox'].check()
        return self

    def get_base_report_url_enabled(self):
        return self, self.elements['base_report_url_input'].is_enabled()

    def get_relative_schema_url_enabled(self):
        return self, self.elements['relative_schema_url_input'].is_enabled()

    def get_relative_json_url_enabled(self):
        return self, self.elements['relative_json_data_url_input'].is_enabled()

    def get_worker_field_name_enabled(self):
        return self, self.elements['worker_unique_id_field_name_input'].is_enabled()

    def get_worker_field_name_value(self):
        return self, self.elements['worker_unique_id_field_name_input'].get_text()

    def get_query_timeout_enabled(self):
        return self, self.elements['report_query_timeout_input'].is_enabled()

    def input_query_timeout_value(self, value):
        self.elements['report_query_timeout_input'].clear()
        self.elements['report_query_timeout_input'].type(value)
        time.sleep(1)
        valid = 'x-form-invalid-field' in self.elements['report_query_timeout_input'].get_class()
        return self, not valid

    def get_new_hire_pre_provisioning_interval_enabled(self):
        return self, self.elements['enable_new_hire_pre_provisioning_interval_input'].is_enabled()

    def get_new_hire_pre_provisioning_interval_value(self):
        return self, self.elements['enable_new_hire_pre_provisioning_interval_input'].get_text()

    def input_new_hire_pre_provisioning_interval_value(self, value):
        self.elements['enable_new_hire_pre_provisioning_interval_input'].clear()
        self.elements['enable_new_hire_pre_provisioning_interval_input'].type(value)
        time.sleep(1)
        valid = 'x-form-invalid-field' in self.elements['enable_new_hire_pre_provisioning_interval_input'].get_class()
        return self, not valid

    def click_new_hire_pre_provision(self):
        self.elements['enable_new_hire_pre_provisioning_checkbox'].check()
        return self

    def input_tenant_utc_offset_value(self, value):
        self.elements['tenant_utc_offset_input'].clear()
        self.elements['tenant_utc_offset_input'].type(value)
        time.sleep(1)
        valid = 'x-form-invalid-field' in self.elements['tenant_utc_offset_input'].get_class()
        return self, not valid

    def get_sync_report_type_dropdown_enabled(self):
        return self, self.elements['sync_report_type_dropdown'].is_enabled()

    def get_distribution_add_button_enabled(self):
        return self, 'x-btn-disabled' not in self.elements['distribution_add_button'].get_class()

    def click_add_distribution_button(self):
        self.elements['distribution_add_button'].click()
        return self

    def click_send_report_on_completion(self):
        self.elements['send_report_on_completion_checkbox'].check()
        return self

    def get_email_input_visibility(self):
        email_input = self.elements['sync_report_email_input'].wait_for_visible()
        return self, email_input is not None

    def is_confirm_provisioning_source_dialog_box_displayed(self):
        return self.elements['view_title'].is_displayed()