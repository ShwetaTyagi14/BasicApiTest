from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.constants import Xpaths


class InboundProvisioningRulePage(UIPage):
    rule_xpath = f'//input[@testname="RuleSelectionType"]'
    toggle_xpath = Xpaths.SELECT_TOGGLE

    target_xpath = f'//input[@testname="DirectoryServiceUuid"]'

    inactive_rule_label = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text() = "Inactive"]'))}
    source_selection_rule_drop_down = {'locator': ElementSetLocator(element_locator=(By.NAME, 'RuleSelectionType'),
                                                                    toggle_locator=(By.XPATH, f'{rule_xpath}{toggle_xpath}'))}
    rule_name = {'locator': ElementSetLocator(element_locator=(By.NAME, 'Name'))}
    all_users_item = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//li[@data-text="All Users"]'))}
    next_btn = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Next >"]'))}
    target_drop_down = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="DirectoryServiceUuid"]'),
                                                     toggle_locator=(By.XPATH, f'{target_xpath}{toggle_xpath}'))}
    idaptive_directory_item = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//li[contains(text(),"CyberArk Cloud Directory")]'))}
    idaptive_checkbox = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[contains(text(),"Disable user in CyberArk Cloud ")]'))}
    domain_label = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text() = "Domain"]'))}

    dc_label = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text() = "Domain Controller"]'))}
    target_ou_label = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text() = "Target OU (select one)"]'))}
    provisioning_group_checkbox = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text() = "Provisioning Group Options"]'))}
    user_termination_checkbox = {
        'locator': ElementSetLocator(element_locator= (By.XPATH, '//label[text() = "User Termination Options"]'))}
    idaptive_role_label = {
        'locator': ElementSetLocator(element_locator= (By.XPATH, '//label[text() = "CyberArk Identity role Options"]'))}
    idaptive_role_checkbox = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, '//label[text() = "Add users to roles"]'))}
    reevaluate_role_checkbox = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, ' // label[text() = "Re-evaluate Role Memberships"]'))}
    reevaluate_role_tooltip = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, ' // div[text() = "I"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.inactive_rule_label),
            'inactive_rule_label': ElementFactory(driver).define_element(self.inactive_rule_label),
            'rule_name': ElementFactory(driver).define_text_input(self.rule_name),
            'source_selection_rule_drop_down': ElementFactory(driver).define_select(self.source_selection_rule_drop_down),
            'all_users_item': ElementFactory(driver).define_element(self.all_users_item),
            'next_btn': ElementFactory(driver).define_element(self.next_btn),
            'target_drop_down': ElementFactory(driver).define_select(self.target_drop_down),
            'idaptive_directory_item': ElementFactory(driver).define_element(self.idaptive_directory_item),
            'idaptive_checkbox': ElementFactory(driver).define_checkbox(self.idaptive_checkbox),
            'domain_label': ElementFactory(driver).define_element(self.domain_label),
            'dc_label': ElementFactory(driver).define_element(self.dc_label),
            'target_ou_label': ElementFactory(driver).define_element(self.target_ou_label),
            'provisioning_group_checkbox': ElementFactory(driver).define_checkbox(self.provisioning_group_checkbox),
            'user_termination_checkbox': ElementFactory(driver).define_checkbox(self.user_termination_checkbox),
            'idaptive_role_label': ElementFactory(driver).define_element(self.idaptive_role_label),
            'idaptive_role_checkbox': ElementFactory(driver).define_checkbox(self.idaptive_role_checkbox),
            'reevaluate_role_checkbox': ElementFactory(driver).define_checkbox(self.reevaluate_role_checkbox),
            'reevaluate_role_tooltip': ElementFactory(driver).define_element(self.reevaluate_role_tooltip)

        }
        super().__init__(driver, self.elements)

    def is_confirm_provisioning_rule_page_displayed(self):
        return self.elements['rule_name'].is_displayed()

    def enter_rule_name(self, name):
        self.elements['rule_name'].clear()
        self.elements['rule_name'].type(name)
        return self

    def select_option_from_selection_rule(self, value):
        self.elements['source_selection_rule_drop_down'].wait_for_visible()
        self.elements['source_selection_rule_drop_down'].select_option(value)
        return self

    def click_next_btn(self):
        self.elements['next_btn'].click()
        return self

    def select_idaptive_directory_as_option(self, value):
        self.elements['target_drop_down'].wait_for_visible()
        self.elements['target_drop_down'].select_option(value)
        return self

    def is_confirm_disable_user_in_idaptive_checkbox_displayed(self):
        return self.elements['idaptive_checkbox'].is_displayed()

    def is_confirm_domain_dropdown_label_displayed(self):
        return self.elements['domain_label'].is_displayed()

    def is_confirm_domain_controller_dropdown_label_displayed(self):
        return self.elements['dc_label'].is_displayed()

    def is_confirm_target_ou_label_displayed(self):
        return self.elements['target_ou_label'].is_displayed()

    def is_confirm_provisioning_group_checkbox_option_displayed(self):
        return self.elements['provisioning_group_checkbox'].is_displayed()

    def is_confirm_user_termination_checkbox_option_displayed(self):
        return self.elements['user_termination_checkbox'].is_displayed()

    def is_confirm_idaptive_role_options_label_displayed(self):
        return self.elements['idaptive_role_label'].is_displayed()

    def is_confirm_add_user_to_idaptive_role_checkbox_displayed(self):
        return self.elements['idaptive_role_checkbox'].is_displayed()

    def is_confirm_reevaluate_role_memberships_checkbox_displayed(self):
        return self.elements['reevaluate_role_checkbox'].is_displayed()

    def is_confirm_reevaluate_role_memberships_tooltip_displayed(self):
        return self.elements['reevaluate_role_tooltip'].is_displayed()
