from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc, \
    DeviceManagementSettings as dms, \
    Xpaths,\
    Options


class DeviceManagementSettingsPage(UIPage):
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,f'//div[text()="{pdc.DEVICE_MANAGEMENT_SEWTTINGS}"]')),
              'inner_text': pdc.DEVICE_MANAGEMENT_SEWTTINGS
    }

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE

    usmdmd_xpath = f'//input[@testname="{dms.ElementNames.USE_CENTRIFY_AS_MDM}"]'
    use_centrify_as_mdm = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, usmdmd_xpath),
                              label_text_locator=(By.XPATH, f'{usmdmd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{usmdmd_xpath}{toggle_xpath}')),
        'label_text': dms.TextConstants.USE_CENTRIFY_AS_MDM,
        'options': Options.YES_NO
    }

    bif_xpath = f'//input[@testname="{dms.ElementNames.DEVICE_BASIC_INFO_FREQUENCY}"]'
    basic_info_freq = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, bif_xpath),
                              label_text_locator=(By.XPATH,f'{bif_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{bif_xpath}{toggle_xpath}')),
        'label_text': dms.TextConstants.DEVICE_BASIC_INFO_FREQUENCY,
        'options': ['--', '4', '8', '12', '24', '48', '72']
    }

    du_xpath = f'//input[@testname="{dms.ElementNames.DEVICE_UNREACHABLE_THRESHOLD}"]'
    device_unreachable = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, du_xpath),
                              label_text_locator=(By.XPATH,f'{du_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{du_xpath}{toggle_xpath}')),
        'label_text': dms.TextConstants.DEVICE_UNREACHABLE_THRESHOLD,
        'options': ['--', '3', '7', '14', '30', '60']
    }

    duc_xpath = f'//input[@testname="{dms.ElementNames.DISABLE_UNREACHABLE_CLIENTS}"]'
    disable_unreachable = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, duc_xpath),
                              label_text_locator=(By.XPATH,f'{duc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{duc_xpath}{toggle_xpath}')),
        'label_text': dms.TextConstants.DISABLE_UNREACHABLE_CLIENTS,
        'options': Options.YES_NO
    }

    da_xpath = f'//input[@testname="{dms.ElementNames.DISABLE_ACTION}"]'
    disable_action = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, da_xpath),
                              label_text_locator=(By.XPATH,f'{da_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{da_xpath}{toggle_xpath}')),
        'label_text': dms.TextConstants.DISABLE_ACTION,
        'options': ['Admin lock', 'Unenroll']
    }
    dtd_xpath = f'//input[@testname="{dms.ElementNames.DAYS_UNTIL_DISABLE}"]'
    days_to_disable = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dtd_xpath),
                              label_text_locator=(By.XPATH,f'{dtd_xpath}/ancestor::table/following-sibling::label'),
                              parent_container_locator=(By.XPATH,f'{dtd_xpath}/ancestor::table')),
        'label_text': dms.TextConstants.DAYS_UNTIL_DISABLE
    }

    ei_xpath = f'//input[@testname="{dms.ElementNames.ENABLE_INTERCEDE}"]'
    enable_intercede = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ei_xpath),
                              label_text_locator=(By.XPATH,f'{ei_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{ei_xpath}{toggle_xpath}')),
        'label_text': dms.TextConstants.ENABLE_INTERCEDE,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.disable_unreachable['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.disable_action),
                    factory(driver).define_element(self.days_to_disable),
                ]
            }
        ]
        self.elements = {
            pdc.DEVICE_MANAGEMENT_SEWTTINGS: factory(driver).define_element(self.header),
            dms.ElementNames.USE_CENTRIFY_AS_MDM: factory(driver).define_select(self.use_centrify_as_mdm),
            dms.ElementNames.DEVICE_BASIC_INFO_FREQUENCY: factory(driver).define_select(self.basic_info_freq),
            dms.ElementNames.DEVICE_UNREACHABLE_THRESHOLD: factory(driver).define_select(self.device_unreachable),
            dms.ElementNames.DISABLE_UNREACHABLE_CLIENTS: factory(driver).define_select(self.disable_unreachable),
            dms.ElementNames.ENABLE_INTERCEDE: factory(driver).define_select(self.enable_intercede)
        }
        super().__init__(driver, self.elements)
