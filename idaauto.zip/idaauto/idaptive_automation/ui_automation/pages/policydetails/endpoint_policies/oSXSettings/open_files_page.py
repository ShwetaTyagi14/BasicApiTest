from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxSettingsOpenfiles as osxof


class OpenFilesPage(UIPage):
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osxof.ElementNames.HEADER}"]')),
        'inner_text': osxof.TextConstants.HEADER
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{osxof.ElementNames.ADD}"]')),
        'label_text': osxof.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osxof.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button)
        }
        super().__init__(driver, self.elements)
