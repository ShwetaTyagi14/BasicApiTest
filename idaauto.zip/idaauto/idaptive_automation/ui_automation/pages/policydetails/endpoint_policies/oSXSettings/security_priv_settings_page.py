from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import OsxSettingsSecurityPrivacySettings as ossps


class SecurityPrivacySettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{ossps.ElementNames.HEADER}"]')),
        'inner_text': ossps.TextConstants.HEADER
    }
    efve_xpath = f'//input[@testname="{ossps.ElementNames.FILE_VAULT_ENCRYPTION}"]'
    enable_file_vault_encryption = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, efve_xpath),
                              label_text_locator=(By.XPATH, f'{efve_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{efve_xpath}{toggle_xpath}')),
        'label_text': ossps.TextConstants.FILE_VAULT_ENCRYPTION,
        'options': Options.YES_NO
    }
    saps_xpath = f'//input[@testname="{ossps.ElementNames.SECURITY_PRIVACY}"]'
    security_privacy_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, saps_xpath),
                              label_text_locator=(By.XPATH, f'{saps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{saps_xpath}{toggle_xpath}')),
        'label_text': ossps.TextConstants.SECURITY_PRIVACY,
        'options': Options.YES_NO
    }
    pdrk_xpath = f'//input[@testname="{ossps.ElementNames.RECOVERY_KEY}"]'
    permit_recovery_key = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pdrk_xpath),
                              label_text_locator=(By.XPATH, f'{pdrk_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{pdrk_xpath}/ancestor::table')),
        'label_text': ossps.TextConstants.RECOVERY_KEY,
        'checked': False
    }
    augs_xpath = f'//input[@testname="{ossps.ElementNames.GATEKEEPER_SETTINGS}"]'
    allow_gatekeeper_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, augs_xpath),
                              label_text_locator=(By.XPATH, f'{augs_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{augs_xpath}/ancestor::table')),
        'label_text': ossps.TextConstants.GATEKEEPER_SETTINGS,
        'checked': False
    }
    aucp_xpath = f'//input[@testname="{ossps.ElementNames.CHANGE_PASSWORD}"]'
    allow_change_password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aucp_xpath),
                              label_text_locator=(By.XPATH, f'{aucp_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aucp_xpath}/ancestor::table')),
        'label_text': ossps.TextConstants.CHANGE_PASSWORD,
        'checked': False
    }
    rpsb_xpath = f'//input[@testname="{ossps.ElementNames.SCREEN_SAVER}"]'
    required_screen_saver = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpsb_xpath),
                              label_text_locator=(By.XPATH, f'{rpsb_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{rpsb_xpath}/ancestor::table')),
        'label_text': ossps.TextConstants.SCREEN_SAVER,
        'checked': False
    }
    auslm_xpath = f'//input[@testname="{ossps.ElementNames.SET_LOCK_MESSAGE}"]'
    allow_set_lock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auslm_xpath),
                              label_text_locator=(By.XPATH, f'{auslm_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{auslm_xpath}/ancestor::table')),
        'label_text': ossps.TextConstants.SET_LOCK_MESSAGE,
        'checked': False
    }

    def __init__(self, driver):
        self.enable_file_vault_encryption['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.permit_recovery_key),

                ]
            }
        ]
        self.security_privacy_settings['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.allow_gatekeeper_settings),
                    factory(driver).define_checkbox(self.allow_change_password),
                    factory(driver).define_checkbox(self.required_screen_saver),
                    factory(driver).define_checkbox(self.allow_set_lock)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            ossps.ElementNames.FILE_VAULT_ENCRYPTION: factory(driver).define_select(self.enable_file_vault_encryption),
            ossps.ElementNames.SECURITY_PRIVACY: factory(driver).define_select(self.security_privacy_settings)
        }
        super().__init__(driver, self.elements)
