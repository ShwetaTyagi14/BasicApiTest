from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxSettingsManageLocalAdminAccount as osmlaa
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class ManageLocalAdminPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osmlaa.ElementNames.HEADER}"]')),
        'inner_text': osmlaa.TextConstants.HEADER
    }
    cmla_xpath = f'//input[@testname="{osmlaa.ElementNames.LOCAL_ADMIN_ACCOUNT}"]'
    create_manage_local_admin = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, cmla_xpath),
                              label_text_locator=(By.XPATH, f'{cmla_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{cmla_xpath}{toggle_xpath}')),
        'label_text': osmlaa.TextConstants.LOCAL_ADMIN_ACCOUNT,
        'options': Options.YES_NO
    }
    acn_xpath = f'//input[@testname="{osmlaa.ElementNames.ACCOUNT_NAME}"]'
    account_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, acn_xpath),
                              label_text_locator=(By.XPATH, f'{acn_xpath}/ancestor::table/following-sibling::label')),
        'label_text': osmlaa.TextConstants.ACCOUNT_NAME
    }
    ppri_xpath = f'//input[@testname="{osmlaa.ElementNames.ROTATION_INTERVAL}"]'
    password_rotation_interval = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ppri_xpath),
                              label_text_locator=(By.XPATH, f'{ppri_xpath}/ancestor::table/following-sibling::label')),
        'label_text': osmlaa.TextConstants.ROTATION_INTERVAL
    }
    colt_xpath = f'//input[@testname="{osmlaa.ElementNames.CHECKOUT_LIFETIME}"]'
    checkout_lifetime = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, colt_xpath),
                              label_text_locator=(By.XPATH, f'{colt_xpath}/ancestor::table/following-sibling::label')),
        'label_text': osmlaa.TextConstants.CHECKOUT_LIFETIME
    }
    auclap_xpath = f'//input[@testname="{osmlaa.ElementNames.ENROLLED_USER_CHECKOUT}"]'
    allow_enrolled_user_checkout = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auclap_xpath),
                              label_text_locator=(By.XPATH, f'{auclap_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{auclap_xpath}/parent::td/following-sibling::td')),
        'label_text': osmlaa.TextConstants.ENROLLED_USER_CHECKOUT,
        'options': Options.YES_NO
    }
    pgp_xpath = f'//input[@name="{osmlaa.ElementNames.PASSWORD_GENERATION_PROFILE}"]'
    password_generation_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pgp_xpath),
                              label_text_locator=(By.XPATH, f'{pgp_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{pgp_xpath}/parent::td/following-sibling::td')),
        'label_text': osmlaa.TextConstants.PASSWORD_GENERATION_PROFILE,
        'options': ['Mac Profile', '- Add New Profile -']
    }

    def __init__(self, driver):

        self.create_manage_local_admin['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.account_name),
                    factory(driver).define_text_input(self.password_rotation_interval),
                    factory(driver).define_text_input(self.checkout_lifetime),
                    factory(driver).define_select(self.allow_enrolled_user_checkout),
                    factory(driver).define_select(self.password_generation_profile)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osmlaa.ElementNames.LOCAL_ADMIN_ACCOUNT: factory(driver).define_select(self.create_manage_local_admin)
        }
        super().__init__(driver, self.elements)
