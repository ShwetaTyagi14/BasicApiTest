from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import OsxSettingsApplicationManagement as osam


class AppManagementPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osam.ElementNames.HEADER}"]')),
        'inner_text': osam.TextConstants.HEADER
    }
    emsc_xpath = f'//input[@testname="{osam.ElementNames.APPLICATION_MANAGEMENT}"]'
    enable_managed_software = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, emsc_xpath),
                              label_text_locator=(By.XPATH, f'{emsc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{emsc_xpath}{toggle_xpath}')),
        'label_text': osam.TextConstants.APPLICATION_MANAGEMENT,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osam.ElementNames.APPLICATION_MANAGEMENT: factory(driver).define_select(self.enable_managed_software)
        }
        super().__init__(driver, self.elements)
