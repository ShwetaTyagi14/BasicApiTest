from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxRestrictionsSettingsApplications as orsa


class ApplicationsPage(UIPage):
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{orsa.ElementNames.HEADER}"]')),
        'inner_text': orsa.TextConstants.HEADER
    }
    add_button1 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{orsa.ElementNames.ADD}"])[1]')),
        'label_text': orsa.TextConstants.ADD
    }
    add_button2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{orsa.ElementNames.ADD}"])[2]')),
        'label_text': orsa.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'add_button1': factory(driver).define_modify_delete_grid(self.add_button1),
            'add_button2': factory(driver).define_modify_delete_grid(self.add_button2)
        }
        super().__init__(driver, self.elements)
