from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxRestrictionsSettingsMedia as osrsm
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class MediaPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osrsm.ElementNames.HEADER}"]')),
        'inner_text': osrsm.TextConstants.HEADER
    }
    aatad_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_AIRDROP}"]'
    allow_airdrop = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatad_xpath),
                              label_text_locator=(By.XPATH, f'{aatad_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatad_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_AIRDROP,
        'options': Options.YES_NO
    }
    aatcr_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_CD}"]'
    allow_cd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatcr_xpath),
                              label_text_locator=(By.XPATH, f'{aatcr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatcr_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_CD,
        'options': Options.YES_NO
    }
    aatdi_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_DISK_IMAGE}"]'
    allow_disk_image = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdi_xpath),
                              label_text_locator=(By.XPATH, f'{aatdi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatdi_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_DISK_IMAGE,
        'options': Options.YES_NO
    }
    aatdr_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_DVDRAM}"]'
    allow_dvdram = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdr_xpath),
                              label_text_locator=(By.XPATH, f'{aatdr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatdr_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_DVDRAM,
        'options': Options.YES_NO
    }
    aatds_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_DVD}"]'
    allow_dvd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatds_xpath),
                              label_text_locator=(By.XPATH, f'{aatds_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatds_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_DVD,
        'options': Options.YES_NO
    }
    aated_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_EXTERNAL_DISK}"]'
    allow_external_disk = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aated_xpath),
                              label_text_locator=(By.XPATH, f'{aated_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aated_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_EXTERNAL_DISK,
        'options': Options.YES_NO
    }
    aatid_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_INTERNAL_DISK}"]'
    allow_internal_disk = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatid_xpath),
                              label_text_locator=(By.XPATH, f'{aatid_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatid_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_INTERNAL_DISK,
        'options': Options.YES_NO
    }
    aatrd_xpath = f'//input[@testname="{osrsm.ElementNames.ALLOW_RECORDABLE}"]'
    allow_recordable = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatrd_xpath),
                              label_text_locator=(By.XPATH, f'{aatrd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aatrd_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.ALLOW_RECORDABLE,
        'options': Options.YES_NO
    }
    earml_xpath = f'//input[@testname="{osrsm.ElementNames.EJECT_MEDIA}"]'
    eject_media = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, earml_xpath),
                              label_text_locator=(By.XPATH, f'{earml_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{earml_xpath}{toggle_xpath}')),
        'label_text': osrsm.TextConstants.EJECT_MEDIA,
        'options': Options.YES_NO
    }
    aatcdra_xpath = f'//input[@testname="{osrsm.ElementNames.CD_REQ_AUTH}"]'
    cd_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatcdra_xpath),
                              label_text_locator=(By.XPATH, f'{aatcdra_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatcdra_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.CD_REQ_AUTH,
        'checked': False
    }
    aatdira_xpath = f'//input[@testname="{osrsm.ElementNames.DISK_IMAGE_REQ_AUTH}"]'
    disk_image_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdira_xpath),
                              label_text_locator=(By.XPATH, f'{aatdira_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatdira_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.DISK_IMAGE_REQ_AUTH,
        'checked': False
    }
    aatdiro_xpath = f'//input[@testname="{osrsm.ElementNames.DISK_IMAGE_READONLY}"]'
    disk_image_redonly = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdiro_xpath),
                              label_text_locator=(By.XPATH, f'{aatdiro_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatdiro_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.DISK_IMAGE_READONLY,
        'checked': False
    }
    aatdrra_xpath = f'//input[@testname="{osrsm.ElementNames.DVDRAM_REQ_AUTH}"]'
    dvdram_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdrra_xpath),
                              label_text_locator=(By.XPATH, f'{aatdrra_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatdrra_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.DVDRAM_REQ_AUTH,
        'checked': False
    }
    aatdrro_xpath = f'//input[@testname="{osrsm.ElementNames.DVDRAM_READONLY}"]'
    dvdram_readonly = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdrro_xpath),
                              label_text_locator=(By.XPATH, f'{aatdrro_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatdrro_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.DVDRAM_READONLY,
        'checked': False
    }
    aatdra_xpath = f'//input[@testname="{osrsm.ElementNames.DVD_REQ_AUTH}"]'
    dvd_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatdra_xpath),
                              label_text_locator=(By.XPATH, f'{aatdra_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatdra_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.DVD_REQ_AUTH,
        'checked': False
    }
    aatedra_xpath = f'//input[@testname="{osrsm.ElementNames.EXTERNAL_REQ_AUTH}"]'
    external_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatedra_xpath),
                              label_text_locator=(By.XPATH, f'{aatedra_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatedra_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.EXTERNAL_REQ_AUTH,
        'checked': False
    }
    aatedro_xpath = f'//input[@testname="{osrsm.ElementNames.EXTERNAL_READONLY}"]'
    external_readonly = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatedro_xpath),
                              label_text_locator=(By.XPATH, f'{aatedro_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatedro_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.EXTERNAL_READONLY,
        'checked': False
    }
    aatidra_xpath = f'//input[@testname="{osrsm.ElementNames.INTERNAL_REQ_AUTH}"]'
    internal_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatidra_xpath),
                              label_text_locator=(By.XPATH, f'{aatidra_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatidra_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.INTERNAL_REQ_AUTH,
        'checked': False
    }
    aatidro_xpath = f'//input[@testname="{osrsm.ElementNames.INTERNAL_READONLY}"]'
    internal_readonly = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatidro_xpath),
                              label_text_locator=(By.XPATH, f'{aatidro_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatidro_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.INTERNAL_READONLY,
        'checked': False
    }
    aatrdra_xpath = f'//input[@testname="{osrsm.ElementNames.RECORDABLE_REQ_AUTH}"]'
    recordable_req_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aatrdra_xpath),
                              label_text_locator=(By.XPATH, f'{aatrdra_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aatrdra_xpath}/ancestor::table')),
        'label_text': osrsm.TextConstants.RECORDABLE_REQ_AUTH,
        'checked': False
    }

    def __init__(self, driver):
        self.allow_cd['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.cd_req_auth)
                ]
            }
        ]
        self.allow_disk_image['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.disk_image_req_auth),
                    factory(driver).define_checkbox(self.disk_image_redonly)
                ]
            }
        ]
        self.allow_dvdram['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.dvdram_req_auth),
                    factory(driver).define_checkbox(self.dvdram_readonly)
                ]
            }
        ]
        self.allow_dvd['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.dvd_req_auth)
                ]
            }
        ]
        self.allow_external_disk['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.external_req_auth),
                    factory(driver).define_checkbox(self.external_readonly)
                ]
            }
        ]
        self.allow_internal_disk['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.internal_req_auth),
                    factory(driver).define_checkbox(self.internal_readonly)
                ]
            }
        ]
        self.allow_recordable['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.recordable_req_auth)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osrsm.ElementNames.ALLOW_AIRDROP: factory(driver).define_select(self.allow_airdrop),
            osrsm.ElementNames.ALLOW_CD: factory(driver).define_select(self.allow_cd),
            osrsm.ElementNames.ALLOW_DISK_IMAGE: factory(driver).define_select(self.allow_disk_image),
            osrsm.ElementNames.ALLOW_DVDRAM: factory(driver).define_select(self.allow_dvdram),
            osrsm.ElementNames.ALLOW_DVD: factory(driver).define_select(self.allow_dvd),
            osrsm.ElementNames.ALLOW_EXTERNAL_DISK: factory(driver).define_select(self.allow_external_disk),
            osrsm.ElementNames.ALLOW_INTERNAL_DISK: factory(driver).define_select(self.allow_internal_disk),
            osrsm.ElementNames.ALLOW_RECORDABLE: factory(driver).define_select(self.allow_recordable),
            osrsm.ElementNames.EJECT_MEDIA: factory(driver).define_select(self.eject_media)
        }
        super().__init__(driver, self.elements)
