from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxRestrictionsSettingsPreferences as osrsp
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class PreferencesPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osrsp.ElementNames.HEADER}"]')),
        'inner_text': osrsp.TextConstants.HEADER
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{osrsp.ElementNames.ADD}"]')),
        'label_text': osrsp.TextConstants.ADD
    }
    absp_xpath = f'//input[@testname="{osrsp.ElementNames.SYSTEM_PREFERENCES}"]'
    system_preferences = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, absp_xpath),
                              label_text_locator=(By.XPATH, f'{absp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{absp_xpath}{toggle_xpath}')),
        'label_text': osrsp.TextConstants.SYSTEM_PREFERENCES,
        'options': Options.YES_NO
    }
    aaps_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_APP_STORE}"]'
    allow_app_store = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aaps_xpath),
                              label_text_locator=(By.XPATH, f'{aaps_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aaps_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_APP_STORE,
        'checked': True
    }
    abt_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_BLUETOOTH}"]'
    allow_bluetooth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, abt_xpath),
                              label_text_locator=(By.XPATH, f'{abt_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{abt_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_BLUETOOTH,
        'checked': True
    }
    acd_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_CD_DVD}"]'
    allow_cd_dvd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, acd_xpath),
                              label_text_locator=(By.XPATH, f'{acd_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{acd_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_CD_DVD,
        'checked': True
    }
    adt_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_DATE_TIME}"]'
    allow_date_time = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adt_xpath),
                              label_text_locator=(By.XPATH, f'{adt_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{adt_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_DATE_TIME,
        'checked': True
    }
    adtp_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_DESKTOP}"]'
    allow_desktop = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adtp_xpath),
                              label_text_locator=(By.XPATH, f'{adtp_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{adtp_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_DESKTOP,
        'checked': True
    }
    ads_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_DISPLAYS}"]'
    allow_displays = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ads_xpath),
                              label_text_locator=(By.XPATH, f'{ads_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ads_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_DISPLAYS,
        'checked': True
    }
    adk_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_DOCK}"]'
    allow_dock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adk_xpath),
                              label_text_locator=(By.XPATH, f'{adk_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{adk_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_DOCK,
        'checked': True
    }
    aes_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_ENERGY_SAVER}"]'
    allow_energy_saver = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aes_xpath),
                              label_text_locator=(By.XPATH, f'{aes_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aes_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_ENERGY_SAVER,
        'checked': True
    }
    aet_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_EXTENSIONS}"]'
    allow_extensions = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aet_xpath),
                              label_text_locator=(By.XPATH, f'{aet_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aet_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_EXTENSIONS,
        'checked': True
    }
    afc_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_FIBER_CHANNEL}"]'
    allow_fiber_channel = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, afc_xpath),
                              label_text_locator=(By.XPATH, f'{afc_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{afc_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_FIBER_CHANNEL,
        'checked': True
    }
    agl_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_GENERAL}"]'
    allow_general = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, agl_xpath),
                              label_text_locator=(By.XPATH, f'{agl_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{agl_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_GENERAL,
        'checked': True
    }
    aic_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_iCLOUD}"]'
    allow_icloud = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aic_xpath),
                              label_text_locator=(By.XPATH, f'{aic_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aic_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_iCLOUD,
        'checked': True
    }
    aik_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_INK}"]'
    allow_ink = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aik_xpath),
                              label_text_locator=(By.XPATH, f'{aik_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aik_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_INK,
        'checked': True
    }
    aia_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_INTERNET}"]'
    allow_internet = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aia_xpath),
                              label_text_locator=(By.XPATH, f'{aia_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aia_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_INTERNET,
        'checked': True
    }
    akb_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_KEYBOARD}"]'
    allow_keyboard = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, akb_xpath),
                              label_text_locator=(By.XPATH, f'{akb_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{akb_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_KEYBOARD,
        'checked': True
    }
    alt_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_LANGUAGE}"]'
    allow_language = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, alt_xpath),
                              label_text_locator=(By.XPATH, f'{alt_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{alt_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_LANGUAGE,
        'checked': True
    }
    amc_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_MISSION_CONTROL}"]'
    allow_mission_control = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, amc_xpath),
                              label_text_locator=(By.XPATH, f'{amc_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{amc_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_MISSION_CONTROL,
        'checked': True
    }
    amm_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_MOBILE_ME}"]'
    allow_mobile_me = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, amm_xpath),
                              label_text_locator=(By.XPATH, f'{amm_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{amm_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_MOBILE_ME,
        'checked': True
    }
    am_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_MOUSE}"]'
    allow_mouse = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, am_xpath),
                              label_text_locator=(By.XPATH, f'{am_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{am_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_MOUSE,
        'checked': True
    }
    an_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_NETWORK}"]'
    allow_network = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, an_xpath),
                              label_text_locator=(By.XPATH, f'{an_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{an_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_NETWORK,
        'checked': True
    }
    ans_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_NOTIFICATIONS}"]'
    allow_notifications = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ans_xpath),
                              label_text_locator=(By.XPATH, f'{ans_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ans_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_NOTIFICATIONS,
        'checked': True
    }
    apc_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_PARENTAL_CONTROLS}"]'
    allow_perental_control = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apc_xpath),
                              label_text_locator=(By.XPATH, f'{apc_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{apc_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_PARENTAL_CONTROLS,
        'checked': True
    }
    aps_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_PRINT_SCAN}"]'
    allow_print_scan = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aps_xpath),
                              label_text_locator=(By.XPATH, f'{aps_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aps_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_PRINT_SCAN,
        'checked': True
    }
    ap_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_PROFILES}"]'
    allow_pofiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ap_xpath),
                              label_text_locator=(By.XPATH, f'{ap_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ap_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_PROFILES,
        'checked': True
    }
    asp_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_SECURITY}"]'
    allow_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asp_xpath),
                              label_text_locator=(By.XPATH, f'{asp_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asp_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_SECURITY,
        'checked': True
    }
    asg_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_SHARING}"]'
    allow_sharing = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asg_xpath),
                              label_text_locator=(By.XPATH, f'{asg_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asg_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_SHARING,
        'checked': True
    }
    asu_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_SOFTWARE}"]'
    allow_software = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asu_xpath),
                              label_text_locator=(By.XPATH, f'{asu_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asu_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_SOFTWARE,
        'checked': True
    }
    asd_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_SOUND}"]'
    allow_sound = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asd_xpath),
                              label_text_locator=(By.XPATH, f'{asd_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asd_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_SOUND,
        'checked': True
    }
    ash_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_SPEECH}"]'
    allow_speech = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ash_xpath),
                              label_text_locator=(By.XPATH, f'{ash_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ash_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_SPEECH,
        'checked': True
    }
    asl_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_SPOTLIGHT}"]'
    allow_spotlight = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asl_xpath),
                              label_text_locator=(By.XPATH, f'{asl_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asl_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_SPOTLIGHT,
        'checked': True
    }
    asud_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_STARTUP_DISK}"]'
    allow_startup_disk = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asud_xpath),
                              label_text_locator=(By.XPATH, f'{asud_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asud_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_STARTUP_DISK,
        'checked': True
    }
    atm_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_TIME_MACHINE}"]'
    allow_time_machine = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, atm_xpath),
                              label_text_locator=(By.XPATH, f'{atm_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{atm_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_TIME_MACHINE,
        'checked': True
    }
    atpd_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_TRACKPAD}"]'
    allow_trackpad = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, atpd_xpath),
                              label_text_locator=(By.XPATH, f'{atpd_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{atpd_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_TRACKPAD,
        'checked': True
    }
    auas_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_UNIVERSAL_ACCESS}"]'
    allow_universal_access = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auas_xpath),
                              label_text_locator=(By.XPATH, f'{auas_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{auas_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_UNIVERSAL_ACCESS,
        'checked': True
    }
    auag_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_USERS_GROUPS}"]'
    allow_users_groups = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auas_xpath),
                              label_text_locator=(By.XPATH, f'{auas_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{auas_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_UNIVERSAL_ACCESS,
        'checked': True
    }
    axs_xpath = f'//input[@testname="{osrsp.ElementNames.ALLOW_XSAN}"]'
    allow_xsan = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, axs_xpath),
                              label_text_locator=(By.XPATH, f'{axs_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{axs_xpath}/ancestor::table')),
        'label_text': osrsp.TextConstants.ALLOW_XSAN,
        'checked': True
    }

    def __init__(self, driver):
        self.system_preferences['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.allow_app_store),
                    factory(driver).define_checkbox(self.allow_bluetooth),
                    factory(driver).define_checkbox(self.allow_cd_dvd),
                    factory(driver).define_checkbox(self.allow_date_time),
                    factory(driver).define_checkbox(self.allow_desktop),
                    factory(driver).define_checkbox(self.allow_displays),
                    factory(driver).define_checkbox(self.allow_dock),
                    factory(driver).define_checkbox(self.allow_energy_saver),
                    factory(driver).define_checkbox(self.allow_extensions),
                    factory(driver).define_checkbox(self.allow_fiber_channel),
                    factory(driver).define_checkbox(self.allow_general),
                    factory(driver).define_checkbox(self.allow_icloud),
                    factory(driver).define_checkbox(self.allow_ink),
                    factory(driver).define_checkbox(self.allow_internet),
                    factory(driver).define_checkbox(self.allow_keyboard),
                    factory(driver).define_checkbox(self.allow_language),
                    factory(driver).define_checkbox(self.allow_mission_control),
                    factory(driver).define_checkbox(self.allow_mobile_me),
                    factory(driver).define_checkbox(self.allow_mouse),
                    factory(driver).define_checkbox(self.allow_network),
                    factory(driver).define_checkbox(self.allow_notifications),
                    factory(driver).define_checkbox(self.allow_perental_control),
                    factory(driver).define_checkbox(self.allow_print_scan),
                    factory(driver).define_checkbox(self.allow_pofiles),
                    factory(driver).define_checkbox(self.allow_security),
                    factory(driver).define_checkbox(self.allow_sharing),
                    factory(driver).define_checkbox(self.allow_software),
                    factory(driver).define_checkbox(self.allow_sound),
                    factory(driver).define_checkbox(self.allow_speech),
                    factory(driver).define_checkbox(self.allow_spotlight),
                    factory(driver).define_checkbox(self.allow_startup_disk),
                    factory(driver).define_checkbox(self.allow_time_machine),
                    factory(driver).define_checkbox(self.allow_trackpad),
                    factory(driver).define_checkbox(self.allow_universal_access),
                    factory(driver).define_checkbox(self.allow_users_groups),
                    factory(driver).define_checkbox(self.allow_xsan),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osrsp.ElementNames.SYSTEM_PREFERENCES: factory(driver).define_select(self.system_preferences),
            osrsp.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button)
        }
        super().__init__(driver, self.elements)
