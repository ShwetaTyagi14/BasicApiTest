from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxRestrictionsSettingsRestrictApplications as osrsra
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictApplicationsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osrsra.ElementNames.HEADER}"]')),
        'inner_text': osrsra.TextConstants.HEADER
    }
    rtap_xpath = f'//input[@testname="{osrsra.ElementNames.APP_RESTRICTION}"]'
    app_restriction = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rtap_xpath),
                              label_text_locator=(By.XPATH, f'{rtap_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rtap_xpath}{toggle_xpath}')),
        'label_text': osrsra.TextConstants.APP_RESTRICTION,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osrsra.ElementNames.APP_RESTRICTION: factory(driver).define_select(self.app_restriction)
        }
        super().__init__(driver, self.elements)
