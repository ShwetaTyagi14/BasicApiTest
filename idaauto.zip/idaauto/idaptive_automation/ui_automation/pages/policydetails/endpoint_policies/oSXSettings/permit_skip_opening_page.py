from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import OsxSettingsPermitSkipOpeningItem as ospsoi


class PermitSkipOpeningItemsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{ospsoi.ElementNames.HEADER}"]')),
        'inner_text': ospsoi.TextConstants.HEADER
    }
    psksoi_xpath = f'//input[@testname="{ospsoi.ElementNames.PERMIT_KEY}"]'
    permit_shift_key = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, psksoi_xpath),
                              label_text_locator=(By.XPATH, f'{psksoi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{psksoi_xpath}{toggle_xpath}')),
        'label_text': ospsoi.TextConstants.PERMIT_KEY,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            ospsoi.ElementNames.PERMIT_KEY: factory(driver).define_select(self.permit_shift_key)
        }
        super().__init__(driver, self.elements)
