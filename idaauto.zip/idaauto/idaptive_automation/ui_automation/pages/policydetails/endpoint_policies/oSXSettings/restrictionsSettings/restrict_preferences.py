from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import OsxRestrictionsSettingsRestrictPreferences as osrsrf
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictPreferencesPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{osrsrf.ElementNames.HEADER}"]')),
        'inner_text': osrsrf.TextConstants.HEADER
    }
    rtps_xpath = f'//input[@testname="{osrsrf.ElementNames.ENABLE_PREFERENCES}"]'
    enable_preferences = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rtps_xpath),
                              label_text_locator=(By.XPATH, f'{rtps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rtps_xpath}{toggle_xpath}')),
        'label_text': osrsrf.TextConstants.ENABLE_PREFERENCES,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            osrsrf.ElementNames.ENABLE_PREFERENCES: factory(driver).define_select(self.enable_preferences)
        }
        super().__init__(driver, self.elements)
