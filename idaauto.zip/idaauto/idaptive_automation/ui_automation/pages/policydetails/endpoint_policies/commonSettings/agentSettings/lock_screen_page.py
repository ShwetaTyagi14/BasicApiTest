from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import CommonAgentLockScreen as cals
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class LockScreenPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{cals.ElementNames.HEADER}"]')),
              'inner_text': cals.TextConstants.HEADER
    }
    dmfa_xpath = f'//input[@testname="{cals.ElementNames.DISABLE_MFA}"]'
    lock_screen = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dmfa_xpath),
                              label_text_locator=(By.XPATH, f'{dmfa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dmfa_xpath}{toggle_xpath}')),
        'label_text': cals.TextConstants.DISABLE_MFA,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            cals.ElementNames.DISABLE_MFA: factory(driver).define_select(self.lock_screen)
        }
        super().__init__(driver, self.elements)
