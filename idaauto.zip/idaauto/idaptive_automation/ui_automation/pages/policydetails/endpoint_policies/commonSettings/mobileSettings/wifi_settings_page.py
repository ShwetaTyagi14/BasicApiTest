from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import CommonMobileWifiSettings as cmwf


class WifiSettingsPage(UIPage):
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{cmwf.ElementNames.HEADER}"]')),
        'inner_text': cmwf.TextConstants.HEADER
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{cmwf.ElementNames.ADD}"]')),
        'label_text': cmwf.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            cmwf.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button),
        }
        self.driver = driver
        super().__init__(driver, self.elements)











