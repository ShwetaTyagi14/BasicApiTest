from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import CommonMobileRestrictions as cmr
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictionsSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{cmr.ElementNames.HEADER}"]')),
        'inner_text': cmr.TextConstants.HEADER
    }

    pcu_xpath = f'//input[@testname="{cmr.ElementNames.PERMIT_CAMERA_USE}"]'
    permit_camera_use = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pcu_xpath),
                              label_text_locator=(By.XPATH, f'{pcu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pcu_xpath}{toggle_xpath}')),
        'label_text': cmr.TextConstants.PERMIT_CAMERA_USE,
        'options': Options.YES_NO
    }

    puu_xpath = f'//input[@testname="{cmr.ElementNames.PERMIT_USER_UNENROLL}"]'
    permit_user_unenroll = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, puu_xpath),
                              label_text_locator=(By.XPATH, f'{puu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{puu_xpath}{toggle_xpath}')),
        'label_text': cmr.TextConstants.PERMIT_USER_UNENROLL,
        'options': Options.YES_NO
    }

    puw_xpath = f'//input[@testname="{cmr.ElementNames.PERMIT_USER_WIPE}"]'
    permit_user_wipe = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, puw_xpath),
                              label_text_locator=(By.XPATH, f'{puw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{puw_xpath}{toggle_xpath}')),
        'label_text': cmr.TextConstants.PERMIT_USER_WIPE,
        'options': Options.YES_NO
    }

    rml_xpath = f'//input[@testname="{cmr.ElementNames.REPORT_MOB_LOC}"]'
    report_mobile_location = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rml_xpath),
                              label_text_locator=(By.XPATH, f'{rml_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rml_xpath}{toggle_xpath}')),
        'label_text': cmr.TextConstants.REPORT_MOB_LOC,
        'options': Options.YES_NO
    }

    padl_xpath = f'//input[@testname="{cmr.ElementNames.PERMIT_ADMIN}"]'
    permit_admin_device_location = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, padl_xpath),
                              label_text_locator=(By.XPATH, f'{padl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{padl_xpath}{toggle_xpath}')),
        'label_text': cmr.TextConstants.PERMIT_ADMIN,
        'options': ['Disable', 'Opt-In', 'Force']
    }

    aft_xpath = f'//input[@testname="{cmr.ElementNames.ALLOW_FACETIME}"]'
    allow_face_time = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aft_xpath),
                              label_text_locator=(By.XPATH, f'{aft_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aft_xpath}/ancestor::table')),
        'label_text': cmr.TextConstants.ALLOW_FACETIME,
        'checked': True
    }

    def __init__(self, driver):
        self.permit_camera_use['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.allow_face_time),
                ]
            }
        ]
        self.report_mobile_location['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.permit_admin_device_location),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'permit_camera_use': factory(driver).define_select(self.permit_camera_use),
            'permit_user_unenroll': factory(driver).define_select(self.permit_user_unenroll),
            'permit_user_wipe': factory(driver).define_select(self.permit_user_wipe),
            'report_mobile_location': factory(driver).define_select(self.report_mobile_location)
        }
        super().__init__(driver, self.elements)
