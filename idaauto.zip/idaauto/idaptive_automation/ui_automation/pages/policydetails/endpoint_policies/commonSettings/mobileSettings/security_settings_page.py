from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import CommonMobileSecurity as cms
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options

class SecuritySettingsPage(UIPage):

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,f'//div[text()="{cms.ElementNames.HEADER}"]')),
              'inner_text': cms.TextConstants.HEADER
    }

    sma_xpath = f'//input[@testname="{cms.ElementNames.SHOW_MOBILEAUTH}"]'
    show_mobile_authenticator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sma_xpath),
                              label_text_locator=(By.XPATH, f'{sma_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{sma_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.SHOW_MOBILEAUTH,
        'options': Options.YES_NO
    }

    efm_xpath = f'//input[@testname="{cms.ElementNames.ENFORCE_FINGERPRINT}"]'
    enforce_fingerpeint_mobile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, efm_xpath),
                              label_text_locator=(By.XPATH, f'{efm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{efm_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.ENFORCE_FINGERPRINT,
        'options': Options.YES_NO
    }

    ap_xpath = f'//input[@testname="{cms.ElementNames.ALLOW_APP_PIN}"]'
    allow_pin = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ap_xpath),
                              label_text_locator=(By.XPATH, f'{ap_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ap_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.ALLOW_APP_PIN,
        'options': Options.YES_NO
    }

    rap_xpath = f'//input[@testname="{cms.ElementNames.REQ_CLIENT_APP_PASSCODE}"]'
    req_app_passcode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rap_xpath),
                              label_text_locator=(By.XPATH, f'{rap_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rap_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.REQ_CLIENT_APP_PASSCODE,
        'options': Options.YES_NO
    }

    rap_al_xpath = f'//input[@testname="{cms.ElementNames.AUTO_LOCK}"]'
    req_auto_lock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rap_al_xpath),
                              label_text_locator=(By.XPATH, f'{rap_al_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rap_al_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.AUTO_LOCK,
        'options': Options.AUTO_LOCK
    }

    rap_ale_xpath = f'//input[@testname="{cms.ElementNames.LOCK_ON_EXIT}"]'
    req_auto_lockexit = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rap_ale_xpath),
                              label_text_locator=(By.XPATH, f'{rap_ale_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rap_ale_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.LOCK_ON_EXIT,
        'options': Options.YES_NO
    }

    rpd_xpath = f'//input[@testname="{cms.ElementNames.REQ_PASSCODE}"]'
    req_passcode_device = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.REQ_PASSCODE,
        'options': Options.YES_NO
    }

    rpd_ps_xpath = f'//input[@testname="{cms.ElementNames.PERMIT_SIMPLE}"]'
    rpd_permit_simple = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_ps_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_ps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_ps_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.PERMIT_SIMPLE,
        'options': Options.YES_NO
    }

    rpd_alt_xpath = f'//input[@testname="{cms.ElementNames.AUTO_LOCK_TIME}"]'
    rpd_alt = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_alt_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_alt_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_alt_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.AUTO_LOCK_TIME,
        'options': Options.AUTO_LOCK_TIME
    }

    rpd_mfa_xpath = f'//input[@testname="{cms.ElementNames.MAX_FAILED_ATTEMPTS}"]'
    rpd_mfa = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_mfa_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_mfa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_mfa_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.MAX_FAILED_ATTEMPTS,
        'options': Options.MAX_FAILED_ATTEMPTS
    }

    rpd_gpl_xpath = f'//input[@testname="{cms.ElementNames.GRACE_PERIOD_DEVICE_LOCK}"]'
    rpd_gpl = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_gpl_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_gpl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_gpl_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.GRACE_PERIOD_DEVICE_LOCK,
        'options': Options.GRACE_PERIOD_DEVICE_LOCK
    }

    rpd_psh_xpath = f'//input[@testname="{cms.ElementNames.PASSCODE_HISTORY}"]'
    rpd_psh = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_psh_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_psh_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_psh_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.PASSCODE_HISTORY,
    }

    rpd_mpa_xpath = f'//input[@testname="{cms.ElementNames.MAX_PASSCODE_AGE}"]'
    rpd_mpa = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_mpa_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_mpa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_mpa_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.MAX_PASSCODE_AGE,
    }

    rpd_mcc_xpath = f'//input[@testname="{cms.ElementNames.MIN_COMPLEX_CHARS}"]'
    rpd_mcc = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_mcc_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_mcc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_mcc_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.MIN_COMPLEX_CHARS,
        'options': Options.MIN_COMPLEX_CHARS
    }

    rpd_mpl_xpath = f'//input[@testname="{cms.ElementNames.MIN_PASSCODE_LEN}"]'
    rpd_mpl = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_mpl_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_mpl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_mpl_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.MIN_PASSCODE_LEN,
        'options': Options.MIN_PASSCODE_LEN
    }

    rpd_rav_xpath = f'//input[@testname="{cms.ElementNames.REQ_ALPHANUM_VALUE}"]'
    rpd_rav = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rpd_rav_xpath),
                              label_text_locator=(By.XPATH, f'{rpd_rav_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rpd_rav_xpath}{toggle_xpath}')),
        'label_text': cms.TextConstants.REQ_ALPHANUM_VALUE,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.enforce_fingerpeint_mobile['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.allow_pin),
                ]
            }
        ]

        self.req_app_passcode['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.req_auto_lock),
                    factory(driver).define_select(self.req_auto_lockexit),
                ]
            }
        ]

        self.req_passcode_device['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.rpd_permit_simple),
                    factory(driver).define_select(self.rpd_alt),
                    factory(driver).define_select(self.rpd_mfa),
                    factory(driver).define_select(self.rpd_gpl),
                    factory(driver).define_text_input(self.rpd_psh),
                    factory(driver).define_text_input(self.rpd_mpa),
                    factory(driver).define_select(self.rpd_mcc),
                    factory(driver).define_select(self.rpd_mpl),
                    factory(driver).define_select(self.rpd_rav),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'show_mobile_authenticator':factory(driver).define_select(self.show_mobile_authenticator),
            'enforce_fingerpeint_mobile':factory(driver).define_select(self.enforce_fingerpeint_mobile),
            'req_app_passcode':factory(driver).define_select(self.req_app_passcode),
            'req_passcode_device':factory(driver).define_select(self.req_passcode_device),
        }
        super().__init__(driver, self.elements)
