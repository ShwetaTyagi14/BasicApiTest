from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import CommonMobileCommon as cmc
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class CommonPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{cmc.ElementNames.HEADER}"]')),
              'inner_text': cmc.TextConstants.HEADER
              }

    aun_xpath = f'//input[@testname="{cmc.ElementNames.ALLOW_USER_NOTIFICATIONS}"]'
    allow_user_notifications = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aun_xpath),
                              label_text_locator=(By.XPATH, f'{aun_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aun_xpath}{toggle_xpath}')),
        'label_text': cmc.TextConstants.ALLOW_USER_NOTIFICATIONS,
        'options': Options.YES_NO
    }

    ed_xpath = f'//input[@testname="{cmc.ElementNames.ENABLE_DEBUG}"]'
    enable_debug = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ed_xpath),
                              label_text_locator=(By.XPATH, f'{ed_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ed_xpath}{toggle_xpath}')),
        'label_text': cmc.TextConstants.ENABLE_DEBUG,
        'options': Options.YES_NO
    }

    ei_xpath = f'//input[@testname="{cmc.ElementNames.ENCRYPT_INTERNAL}"]'
    encrypt_internal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ei_xpath),
                              label_text_locator=(By.XPATH, f'{ei_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ei_xpath}{toggle_xpath}')),
        'label_text': cmc.TextConstants.ENCRYPT_INTERNAL,
        'options': Options.YES_NO
    }

    rd_xpath = f'//input[@testname="{cmc.ElementNames.REPORT_DEVICE}"]'
    report_device = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rd_xpath),
                              label_text_locator=(By.XPATH, f'{rd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rd_xpath}{toggle_xpath}')),
        'label_text': cmc.TextConstants.REPORT_DEVICE,
        'options': Options.YES_NO
    }

    sp_xpath = f'//input[@testname="{cmc.ElementNames.SHOW_PASSCODES}"]'
    show_passcodes = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sp_xpath),
                              label_text_locator=(By.XPATH, f'{sp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{sp_xpath}{toggle_xpath}')),
        'label_text': cmc.TextConstants.SHOW_PASSCODES,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'allow_user_notifications': factory(driver).define_select(self.allow_user_notifications),
            'enable_debug': factory(driver).define_select(self.enable_debug),
            'encrypt_internal': factory(driver).define_select(self.encrypt_internal),
            'report_device': factory(driver).define_select(self.report_device),
            'show_passcodes': factory(driver).define_select(self.show_passcodes),
        }
        super().__init__(driver, self.elements)
