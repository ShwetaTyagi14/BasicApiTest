from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceContainerPerAppVpn as skwspav
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class PerAppVPNPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwspav.ElementNames.HEADER}"]')),
        'inner_text': skwspav.TextConstants.HEADER
    }
    pavs_xpath = f'//input[@testname="{skwspav.ElementNames.CONTAINER_APP_VPN}"]'
    container_app_vpn = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pavs_xpath),
                              label_text_locator=(By.XPATH, f'{pavs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pavs_xpath}{toggle_xpath}')),
        'label_text': skwspav.TextConstants.CONTAINER_APP_VPN,
        'options': Options.YES_NO
    }
    vpn_application = {
        'locator':
            ElementSetLocator(element_locator=(
                By.XPATH, f'//label[normalize-space(.)="{skwspav.TextConstants.VPN_APP}"]/preceding-sibling::input'),
                label_text_locator=(
                    By.XPATH, f'//label[normalize-space(.)="{skwspav.TextConstants.VPN_APP}"]'),
                parent_container_locator=(By.XPATH,
                                          f'//table[tbody/tr/td[1]/div/label[normalize-space(.)="{skwspav.TextConstants.VPN_APP}"]]')),
        'label_text': skwspav.TextConstants.VPN_APP,
        'checked': False,
    }
    vpn_mapping = {
        'locator':
            ElementSetLocator(element_locator=(
                By.XPATH,
                f'//label[normalize-space(.)="{skwspav.TextConstants.VPN_MAPPING}"]/preceding-sibling::input'),
                label_text_locator=(
                    By.XPATH, f'//label[normalize-space(.)="{skwspav.TextConstants.VPN_MAPPING}"]'),
                parent_container_locator=(By.XPATH,
                                          f'//table[tbody/tr/td[1]/div/label[normalize-space(.)="{skwspav.TextConstants.VPN_MAPPING}"]]')),
        'label_text': skwspav.TextConstants.VPN_MAPPING,
        'checked': False,
    }
    vpnc_xpath = f'//input[@testname="{skwspav.ElementNames.VPN_CONNECTION}"]'
    vpn_connection = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, vpnc_xpath),
                              label_text_locator=(By.XPATH, f'{vpnc_xpath}/parent::td/div/label')),
        'label_text': skwspav.TextConstants.VPN_CONNECTION
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{skwspav.ElementNames.ADD}"]')),
        'label_text': skwspav.TextConstants.ADD
    }

    def __init__(self, driver):
        self.vpn_mapping['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_modify_delete_grid(self.add_button)
                ]
            }
        ]
        self.vpn_application['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.vpn_connection)
                ]
            }
        ]
        self.container_app_vpn['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.vpn_application),
                    factory(driver).define_checkbox(self.vpn_mapping)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwspav.ElementNames.CONTAINER_APP_VPN: factory(driver).define_select(self.container_app_vpn)
        }
        super().__init__(driver, self.elements)
