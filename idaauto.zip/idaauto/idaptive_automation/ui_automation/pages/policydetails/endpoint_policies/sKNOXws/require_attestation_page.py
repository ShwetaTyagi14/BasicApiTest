from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceRequireAttestationVerification as skwrav
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RequireAttestationPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{skwrav.ElementNames.HEADER}"]')),
        'inner_text': skwrav.TextConstants.HEADER
    }
    rav_xpath = f'//input[@testname="{skwrav.ElementNames.ATTESTATION_VERIFICATION}"]'
    attestation_verification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rav_xpath),
                              label_text_locator=(By.XPATH, f'{rav_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rav_xpath}{toggle_xpath}')),
        'label_text': skwrav.TextConstants.ATTESTATION_VERIFICATION,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwrav.ElementNames.ATTESTATION_VERIFICATION: factory(driver).define_select(self.attestation_verification)
        }
        super().__init__(driver, self.elements)
