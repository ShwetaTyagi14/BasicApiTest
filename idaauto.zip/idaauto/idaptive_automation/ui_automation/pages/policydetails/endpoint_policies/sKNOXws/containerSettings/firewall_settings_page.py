from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceContainerFirewallSettings as skwcfs
from idaptive_automation.ui_automation.constants import Xpaths


class FirewallSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwcfs.ElementNames.HEADER}"]')),
              'inner_text': skwcfs.TextConstants.HEADER
              }

    ara_xpath = f'(//a[@buttontext="{skwcfs.ElementNames.ADD}"])[1]'
    allow_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ara_xpath)),
        'label_text': skwcfs.TextConstants.ADD
    }

    dra_xpath = f'(//a[@buttontext="{skwcfs.ElementNames.ADD}"])[2]'
    deny_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dra_xpath)),
        'label_text': skwcfs.TextConstants.ADD
    }

    rera_xpath = f'(//a[@buttontext="{skwcfs.ElementNames.ADD}"])[3]'
    redirect_exception_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rera_xpath)),
        'label_text': skwcfs.TextConstants.ADD
    }

    rra_xpath = f'(//a[@buttontext="{skwcfs.ElementNames.ADD}"])[4]'
    reroute_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rra_xpath)),
        'label_text': skwcfs.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'allow_rules_add': factory(driver).define_modify_delete_grid(self.allow_rules_add),
            'deny_rules_add': factory(driver).define_modify_delete_grid(self.deny_rules_add),
            'redirect_exception_rules_add': factory(driver).define_modify_delete_grid(self.redirect_exception_rules_add),
            'reroute_rules_add': factory(driver).define_modify_delete_grid(self.reroute_rules_add),
        }
        super().__init__(driver, self.elements)
