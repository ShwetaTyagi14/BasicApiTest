from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceContainerRestrictionSettings as skwcrs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictionsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwcrs.ElementNames.HEADER}"]')),
              'inner_text': skwcrs.TextConstants.HEADER
              }

    ao_xpath = f'//input[@testname="{skwcrs.ElementNames.ALLOW_OTHER}"]'
    allow_other = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ao_xpath),
                              label_text_locator=(By.XPATH, f'{ao_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ao_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.ALLOW_OTHER,
        'options': Options.YES_NO
    }

    ad_xpath = f'//a[@buttontext="{skwcrs.ElementNames.ADD}"]'
    add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ad_xpath)),
        'label_text': skwcrs.TextConstants.ADD
    }

    fs_xpath = f'//input[@testname="{skwcrs.ElementNames.FORCE_SECURE}"]'
    force_secure = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, fs_xpath),
                              label_text_locator=(By.XPATH, f'{fs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{fs_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.FORCE_SECURE,
        'options': Options.YES_NO
    }

    pb_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_BLUETOOTH}"]'
    permit_bluetooth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pb_xpath),
                              label_text_locator=(By.XPATH, f'{pb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pb_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_BLUETOOTH,
        'options': Options.YES_NO
    }

    pbda_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_BLUETOOTH_DEVICE_ACCESS}"]'
    permit_bluetooth_device_access = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pbda_xpath),
                              label_text_locator=(By.XPATH, f'{pbda_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pbda_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_BLUETOOTH_DEVICE_ACCESS,
        'options': Options.YES_NO
    }

    pcu_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_CAMERA_USE}"]'
    permit_camera_use = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pcu_xpath),
                              label_text_locator=(By.XPATH, f'{pcu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pcu_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_CAMERA_USE,
        'options': Options.YES_NO
    }

    pd_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_DISPLAY}"]'
    permit_display = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pd_xpath),
                              label_text_locator=(By.XPATH, f'{pd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pd_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_DISPLAY,
        'options': Options.YES_NO
    }

    pmfic_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_MOVING_FILES_INTO_CONTAINER}"]'
    permit_moving_files_into_container = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pmfic_xpath),
                              label_text_locator=(By.XPATH, f'{pmfic_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pmfic_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_MOVING_FILES_INTO_CONTAINER,
        'options': Options.YES_NO
    }

    pmfoc_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_MOVING_FILES_OUT_OF_CONTAINER}"]'
    permit_moving_files_outof_container = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pmfoc_xpath),
                              label_text_locator=(By.XPATH, f'{pmfoc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pmfoc_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_MOVING_FILES_OUT_OF_CONTAINER,
        'options': Options.YES_NO
    }

    pnfc_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_NFC}"]'
    permit_nfc = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pnfc_xpath),
                              label_text_locator=(By.XPATH, f'{pnfc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pnfc_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_NFC,
        'options': Options.YES_NO
    }

    psc_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_SCREEN_CAPTURE}"]'
    permit_screen_capture = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, psc_xpath),
                              label_text_locator=(By.XPATH, f'{psc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{psc_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_SCREEN_CAPTURE,
        'options': Options.YES_NO
    }

    pua_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_USB_ACCESS}"]'
    permit_usb_access = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pua_xpath),
                              label_text_locator=(By.XPATH, f'{pua_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pua_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_USB_ACCESS,
        'options': Options.YES_NO
    }

    pufca_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_USER_FROM_CHANGING_APPDATA}"]'
    permit_user_from_changing_appdata = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pufca_xpath),
                              label_text_locator=(By.XPATH, f'{pufca_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pufca_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_USER_FROM_CHANGING_APPDATA,
        'options': Options.YES_NO
    }

    pudk_xpath = f'//input[@testname="{skwcrs.ElementNames.PERMIT_USER_DELETE_KNOX}"]'
    permit_user_delete_knox = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pudk_xpath),
                              label_text_locator=(By.XPATH, f'{pudk_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pudk_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PERMIT_USER_DELETE_KNOX,
        'options': Options.YES_NO
    }

    pk_xpath = f'//input[@testname="{skwcrs.ElementNames.PREVIEW_KNOX}"]'
    preview_knox = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pk_xpath),
                              label_text_locator=(By.XPATH, f'{pk_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pk_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.PREVIEW_KNOX,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }

    ce_xpath = f'//input[@testname="{skwcrs.ElementNames.CONTACTS_EXPORT}"]'
    contacts_export = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ce_xpath),
                              label_text_locator=(By.XPATH, f'{ce_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ce_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.CONTACTS_EXPORT,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }

    spe_xpath = f'//input[@testname="{skwcrs.ElementNames.SPLANNER_EXPORT}"]'
    splanner_export = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, spe_xpath),
                              label_text_locator=(By.XPATH, f'{spe_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{spe_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.SPLANNER_EXPORT,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }

    ci_xpath = f'//input[@testname="{skwcrs.ElementNames.CONTACTS_IMPORT}"]'
    contacts_import = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ci_xpath),
                              label_text_locator=(By.XPATH, f'{ci_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ci_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.CONTACTS_IMPORT,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }

    spi_xpath = f'//input[@testname="{skwcrs.ElementNames.SPLANNER_IMPORT}"]'
    splanner_import = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, spi_xpath),
                              label_text_locator=(By.XPATH, f'{spi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{spi_xpath}{toggle_xpath}')),
        'label_text': skwcrs.TextConstants.SPLANNER_IMPORT,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }


    def __init__(self, driver):
        self.permit_user_from_changing_appdata['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.preview_knox),
                    factory(driver).define_select(self.contacts_export),
                    factory(driver).define_select(self.splanner_export),
                    factory(driver).define_select(self.contacts_import),
                    factory(driver).define_select(self.splanner_import),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'allow_other': factory(driver).define_select(self.allow_other),
            'add': factory(driver).define_modify_delete_grid(self.add),
            'force_secure': factory(driver).define_select(self.force_secure),
            'permit_bluetooth': factory(driver).define_select(self.permit_bluetooth),
            'permit_bluetooth_device_access': factory(driver).define_select(self.permit_bluetooth_device_access),
            'permit_camera_use': factory(driver).define_select(self.permit_camera_use),
            'permit_display': factory(driver).define_select(self.permit_display),
            'permit_moving_files_into_container': factory(driver).define_select(self.permit_moving_files_into_container),
            'permit_moving_files_outof_container': factory(driver).define_select(self.permit_moving_files_outof_container),
            'permit_nfc': factory(driver).define_select(self.permit_nfc),
            'permit_screen_capture': factory(driver).define_select(self.permit_screen_capture),
            'permit_usb_access': factory(driver).define_select(self.permit_usb_access),
            'permit_user_from_changing_appdata': factory(driver).define_select(self.permit_user_from_changing_appdata),
            'permit_user_delete_knox': factory(driver).define_select(self.permit_user_delete_knox),

        }
        super().__init__(driver, self.elements)
