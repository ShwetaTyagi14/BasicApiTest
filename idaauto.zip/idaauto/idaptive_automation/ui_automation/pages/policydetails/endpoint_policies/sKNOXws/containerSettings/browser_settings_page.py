from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceContainerBrowserSettings as skwcbs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class BrowserSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwcbs.ElementNames.HEADER}"]')),
              'inner_text': skwcbs.TextConstants.HEADER
    }

    ea_xpath = f'//input[@testname="{skwcbs.ElementNames.ENABLE_AUTOFILL}"]'
    enable_autofill = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ea_xpath),
                              label_text_locator=(By.XPATH, f'{ea_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ea_xpath}{toggle_xpath}')),
        'label_text': skwcbs.TextConstants.ENABLE_AUTOFILL,
        'options': Options.YES_NO
    }

    ec_xpath = f'//input[@testname="{skwcbs.ElementNames.ENABLE_COOKIES}"]'
    enable_cookies = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ec_xpath),
                              label_text_locator=(By.XPATH, f'{ec_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ec_xpath}{toggle_xpath}')),
        'label_text': skwcbs.TextConstants.ENABLE_COOKIES,
        'options': Options.YES_NO
    }

    eff_xpath = f'//input[@testname="{skwcbs.ElementNames.ENABLE_FORCE_FRAUD}"]'
    enable_force_fraud = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eff_xpath),
                              label_text_locator=(By.XPATH, f'{eff_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eff_xpath}{toggle_xpath}')),
        'label_text': skwcbs.TextConstants.ENABLE_FORCE_FRAUD,
        'options': Options.YES_NO
    }

    ej_xpath = f'//input[@testname="{skwcbs.ElementNames.ENABLE_JAVASCRIPT}"]'
    enable_javascript = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ej_xpath),
                              label_text_locator=(By.XPATH, f'{ej_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ej_xpath}{toggle_xpath}')),
        'label_text': skwcbs.TextConstants.ENABLE_JAVASCRIPT,
        'options': Options.YES_NO
    }

    ep_xpath = f'//input[@testname="{skwcbs.ElementNames.ENABLE_POPUPS}"]'
    enable_popups = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ep_xpath),
                              label_text_locator=(By.XPATH, f'{ep_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ep_xpath}{toggle_xpath}')),
        'label_text': skwcbs.TextConstants.ENABLE_POPUPS,
        'options': Options.YES_NO
    }

    es_xpath = f'//input[@testname="{skwcbs.ElementNames.ENABLE_SMARTCARD}"]'
    enable_smartcard = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, es_xpath),
                              label_text_locator=(By.XPATH, f'{es_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{es_xpath}{toggle_xpath}')),
        'label_text': skwcbs.TextConstants.ENABLE_SMARTCARD,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_autofill': factory(driver).define_select(self.enable_autofill),
            'enable_cookies': factory(driver).define_select(self.enable_cookies),
            'enable_force_fraud': factory(driver).define_select(self.enable_force_fraud),
            'enable_javascript': factory(driver).define_select(self.enable_javascript),
            'enable_popups': factory(driver).define_select(self.enable_popups),
            'enable_smartcard': factory(driver).define_select(self.enable_smartcard),
        }
        super().__init__(driver, self.elements)
