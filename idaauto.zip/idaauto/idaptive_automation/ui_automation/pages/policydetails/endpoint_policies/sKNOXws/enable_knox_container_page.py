from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceEnableKNOXContainer as skwekc
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EnableKNOXContainerPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwekc.ElementNames.HEADER}"]')),
        'inner_text': skwekc.TextConstants.HEADER
    }
    enkc_xpath = f'//input[@testname="{skwekc.ElementNames.CONTAINER_CREATE}"]'
    container_create = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, enkc_xpath),
                              label_text_locator=(By.XPATH, f'{enkc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{enkc_xpath}{toggle_xpath}')),
        'label_text': skwekc.TextConstants.CONTAINER_CREATE,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwekc.ElementNames.CONTAINER_CREATE: factory(driver).define_select(self.container_create)
        }
        super().__init__(driver, self.elements)
