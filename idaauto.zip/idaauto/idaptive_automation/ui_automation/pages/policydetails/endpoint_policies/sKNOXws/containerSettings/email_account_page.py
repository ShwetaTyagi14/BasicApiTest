from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKnoxWorkspaceContainerEmailAccSettings as skweas
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EmailAccountPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skweas.ElementNames.HEADER}"]')),
              'inner_text': skweas.TextConstants.HEADER
    }

    skweas_enable_email = f'//input[@testname="{skweas.ElementNames.ENABLE_EMAIL_ACCOUNT}"]'
    enable_email_ac_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skweas_enable_email),
                              label_text_locator=(By.XPATH, f'{skweas_enable_email}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skweas_enable_email}{toggle_xpath}')),
        'label_text': skweas.TextConstants.ENABLE_EMAIL_ACCOUNT,
        'options': Options.YES_NO
    }

    skweas_basic = f'//div[text()="{skweas.ElementNames.EMAIL_BASIC}"]'
    email_basic = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skweas_basic)),
            'label_text': skweas.TextConstants.EMAIL_BASIC,
    }

    skweas_general = f'//div[text()="{skweas.ElementNames.EMAIL_GENERAL}"]'
    email_general = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skweas_general)),
            'label_text': skweas.TextConstants.EMAIL_GENERAL,
    }

    skweas_incoming = f'//div[text()="{skweas.ElementNames.INCOMING_SERVER}"]'
    email_incoming = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skweas_basic)),
            'label_text': skweas.TextConstants.INCOMING_SERVER,
    }

    skweas_outgoing = f'//div[text()="{skweas.ElementNames.OUTGOING_SERVER}"]'
    email_outgoing = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skweas_general)),
            'label_text': skweas.TextConstants.OUTGOING_SERVER,
    }

    def __init__(self, driver):

        self.enable_email_ac_settings['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_exchange_settings(self.email_basic),
                    factory(driver).define_exchange_settings(self.email_general),
                    factory(driver).define_exchange_settings(self.email_incoming),
                    factory(driver).define_exchange_settings(self.email_outgoing)
                ]
            }
        ]
        self.elements = {
            skweas.TextConstants.HEADER: factory(driver).define_element(self.header),
            skweas.TextConstants.ENABLE_EMAIL_ACCOUNT:factory(driver).define_select(self.enable_email_ac_settings),
        }
        super().__init__(driver, self.elements)
