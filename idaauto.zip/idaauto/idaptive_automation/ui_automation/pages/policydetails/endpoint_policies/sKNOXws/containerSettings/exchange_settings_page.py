from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKnoxWorkspaceContainerExchangeSettings as skwces
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class ExchangeSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwces.ElementNames.HEADER}"]')),
              'inner_text': skwces.TextConstants.HEADER
    }

    skwces_enable_exch = f'//input[@testname="{skwces.ElementNames.ENABLE_EXCHANGE_ACTSYNC}"]'
    enable_exch_activesync = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skwces_enable_exch),
                              label_text_locator=(By.XPATH, f'{skwces_enable_exch}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skwces_enable_exch}{toggle_xpath}')),
        'label_text': skwces.TextConstants.ENABLE_EXCHANGE_ACTSYNC,
        'options': Options.YES_NO
    }

    skwces_basic = f'//div[text()="{skwces.ElementNames.EXCH_BASIC}"]'
    exch_basic = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skwces_basic)),
            'label_text': skwces.TextConstants.EMAIL_BASIC,
    }

    skwces_general = f'//div[text()="{skwces.ElementNames.EXCH_GENERAL}"]'
    exch_general = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skwces_general)),
            'label_text': skwces.TextConstants.EMAIL_GENERAL,
    }

    skwces_sync_options = f'//div[text()="{skwces.ElementNames.SYNC_OPTIONS}"]'
    exch_sync_options = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skwces_sync_options)),
            'label_text': skwces.TextConstants.SYNC_OPTIONS,
    }

    skweas_sync_schedule = f'//div[text()="{skwces.ElementNames.SYNC_SCHEDULE}"]'
    exch_sync_schedule = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skweas_sync_schedule)),
            'label_text': skwces.TextConstants.SYNC_SCHEDULE,
    }

    def __init__(self, driver):

        self.enable_exch_activesync['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_exchange_settings(self.exch_basic),
                    factory(driver).define_exchange_settings(self.exch_general),
                    factory(driver).define_exchange_settings(self.exch_sync_options),
                    factory(driver).define_exchange_settings(self.exch_sync_schedule)
                ]
            }
        ]
        self.elements = {
            skwces.TextConstants.HEADER: factory(driver).define_element(self.header),
            skwces.TextConstants.ENABLE_EXCHANGE_ACTSYNC:factory(driver).define_select(self.enable_exch_activesync),
        }
        super().__init__(driver, self.elements)
