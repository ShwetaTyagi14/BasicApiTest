from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKnoxWorkspaceContainerCertSettings as skwcs
from idaptive_automation.ui_automation.constants import Xpaths


class CertificateSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwcs.ElementNames.HEADER}"]')),
              'inner_text': skwcs.TextConstants.HEADER
    }

    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])')),
            'label_text': skwcs.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            skwcs.ElementNames.HEADER: factory(driver).define_element(self.header),
            'add_button': factory(driver).define_modify_delete_grid(self.add_button),
        }
        super().__init__(driver, self.elements)
