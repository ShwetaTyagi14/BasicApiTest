from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceEnableCommonCriteriaMode as skweccm
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EnableCommonCriteriaPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(
                      element_locator=(By.XPATH, f'//span[normalize-space(.)="{skweccm.ElementNames.HEADER}"]')),
        'inner_text': skweccm.TextConstants.HEADER
              }
    eccm_xpath = f'//input[@testname="{skweccm.ElementNames.CCMODE_ENABLE}"]'
    enable_common_criteria = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eccm_xpath),
                              label_text_locator=(By.XPATH, f'{eccm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eccm_xpath}{toggle_xpath}')),
        'label_text': skweccm.TextConstants.CCMODE_ENABLE,
        'options': Options.YES_NO
    }
    mnfa_xpath = f'//input[@testname="{skweccm.ElementNames.MAXIMUM_ATTEMPTS}"]'
    maximum_attempts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mnfa_xpath),
                              label_text_locator=(By.XPATH, f'{mnfa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mnfa_xpath}{toggle_xpath}')),
        'label_text': skweccm.TextConstants.MAXIMUM_ATTEMPTS,
        'options': ['4', '5', '6', '7', '8', '9', '10']
    }

    def __init__(self, driver):
        self.enable_common_criteria['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.maximum_attempts),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skweccm.ElementNames.CCMODE_ENABLE: factory(driver).define_select(self.enable_common_criteria)
        }
        super().__init__(driver, self.elements)
