from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceConfigureApplicationContainer as skwcac
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class ConfigureAppsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{skwcac.ElementNames.HEADER}"]')),
        'inner_text': skwcac.TextConstants.HEADER
    }
    casc_xpath = f'//input[@testname="{skwcac.ElementNames.ALLOW_DATA_SYNC}"]'
    allow_data_sync = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, casc_xpath),
                              label_text_locator=(By.XPATH, f'{casc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{casc_xpath}{toggle_xpath}')),
        'label_text': skwcac.TextConstants.ALLOW_DATA_SYNC,
        'options': Options.YES_NO
    }
    pkn_xpath = f'//input[@testname="{skwcac.ElementNames.PREVIEW_NOTIFICATIONS}"]'
    preview_notifications = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pkn_xpath),
                              label_text_locator=(By.XPATH, f'{pkn_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pkn_xpath}{toggle_xpath}')),
        'label_text': skwcac.TextConstants.PREVIEW_NOTIFICATIONS,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }
    epmc_xpath = f'//input[@testname="{skwcac.ElementNames.EXPORT_CONTACTS}"]'
    export_contacts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, epmc_xpath),
                              label_text_locator=(By.XPATH, f'{epmc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{epmc_xpath}{toggle_xpath}')),
        'label_text': skwcac.TextConstants.EXPORT_CONTACTS,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }
    epmsp_xpath = f'//input[@testname="{skwcac.ElementNames.EXPORT_S_PLANNER}"]'
    export_s_planner = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, epmsp_xpath),
                              label_text_locator=(By.XPATH, f'{epmsp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{epmsp_xpath}{toggle_xpath}')),
        'label_text': skwcac.TextConstants.EXPORT_S_PLANNER,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }
    ikmc_xpath = f'//input[@testname="{skwcac.ElementNames.IMPORT_CONTACTS}"]'
    import_contacts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ikmc_xpath),
                              label_text_locator=(By.XPATH, f'{ikmc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ikmc_xpath}{toggle_xpath}')),
        'label_text': skwcac.TextConstants.IMPORT_CONTACTS,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }
    ikmsp_xpath = f'//input[@testname="{skwcac.ElementNames.IMPORT_S_PLANNER}"]'
    import_s_planner = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ikmsp_xpath),
                              label_text_locator=(By.XPATH, f'{ikmsp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ikmsp_xpath}{toggle_xpath}')),
        'label_text': skwcac.TextConstants.IMPORT_S_PLANNER,
        'options': ['Not defined', 'Allowed', 'Disallowed']
    }

    def __init__(self, driver):
        self.allow_data_sync['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.preview_notifications),
                    factory(driver).define_select(self.export_contacts),
                    factory(driver).define_select(self.export_s_planner),
                    factory(driver).define_select(self.import_contacts),
                    factory(driver).define_select(self.import_s_planner)

                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwcac.ElementNames.ALLOW_DATA_SYNC: factory(driver).define_select(self.allow_data_sync)
        }
        super().__init__(driver, self.elements)
