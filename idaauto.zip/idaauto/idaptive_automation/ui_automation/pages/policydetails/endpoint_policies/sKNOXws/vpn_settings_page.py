from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceVPNSettings as skwvs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class VPNSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwvs.ElementNames.HEADER}"]')),
        'inner_text': skwvs.TextConstants.HEADER
    }
    vmo_xpath = f'//input[@testname="{skwvs.ElementNames.VPN_MODE_OPERATION}"]'
    vpn_mode_operation = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, vmo_xpath),
                              label_text_locator=(By.XPATH, f'{vmo_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{vmo_xpath}{toggle_xpath}')),
        'label_text': skwvs.TextConstants.VPN_MODE_OPERATION,
        'options': ['--', 'Non-FIPS mode', 'FIPS mode']
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{skwvs.ElementNames.ADD}"]')),
        'label_text': skwvs.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwvs.ElementNames.VPN_MODE_OPERATION: factory(driver).define_select(self.vpn_mode_operation),
            skwvs.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button)
        }
        super().__init__(driver, self.elements)
