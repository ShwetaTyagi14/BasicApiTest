from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceEnableODE as skweod


class EnableODEVeificationPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{skweod.ElementNames.HEADER}"]')),
        'inner_text': skweod.TextConstants.HEADER
    }
    eotbv_xpath = f'//input[@testname="{skweod.ElementNames.ODE_TRUSTED_BOOT}"]'
    enable_ode_trusted = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eotbv_xpath),
                              label_text_locator=(By.XPATH, f'{eotbv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eotbv_xpath}{toggle_xpath}')),
        'label_text': skweod.TextConstants.ODE_TRUSTED_BOOT,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skweod.ElementNames.ODE_TRUSTED_BOOT: factory(driver).define_select(self.enable_ode_trusted)
        }
        super().__init__(driver, self.elements)
