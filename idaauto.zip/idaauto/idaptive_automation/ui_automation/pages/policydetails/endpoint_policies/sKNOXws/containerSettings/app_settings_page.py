from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKnoxWorkspaceContainerAppSettings as skwas
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class AppSettingsPage(UIPage):

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,f'//div[text()="{skwas.ElementNames.HEADER}"]')),
              'inner_text': skwas.TextConstants.HEADER
    }

    skwas_apps_cont = f'//input[@testname="{skwas.ElementNames.ALLOW_APP_MOVE_CONTAINER}"]'
    skwas_app_cont = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skwas_apps_cont),
                              label_text_locator=(By.XPATH, f'{skwas_apps_cont}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skwas_apps_cont}{toggle_xpath}')),
        'label_text': skwas.TextConstants.ALLOW_APP_MOVE_CONTAINER,
        'options': Options.YES_NO
    }

    add_button1 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[1]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[2]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button3 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[3]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button4 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[4]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button5 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[5]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button6 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[6]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button7 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[7]')),
            'label_text': skwas.TextConstants.ADD
    }

    add_button8 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[8]')),
            'label_text': skwas.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            skwas.ElementNames.HEADER: factory(driver).define_element(self.header),
            skwas.ElementNames.ALLOW_APP_MOVE_CONTAINER: factory(driver).define_select(self.skwas_app_cont),
            'add_button1': factory(driver).define_modify_delete_grid(self.add_button1),
            'add_button2': factory(driver).define_modify_delete_grid(self.add_button2),
            'add_button3': factory(driver).define_modify_delete_grid(self.add_button3),
            'add_button4': factory(driver).define_modify_delete_grid(self.add_button4),
            'add_button5': factory(driver).define_modify_delete_grid(self.add_button5),
            'add_button6': factory(driver).define_modify_delete_grid(self.add_button6),
            'add_button7': factory(driver).define_modify_delete_grid(self.add_button7),
            'add_button8': factory(driver).define_modify_delete_grid(self.add_button8),
        }
        super().__init__(driver, self.elements)
