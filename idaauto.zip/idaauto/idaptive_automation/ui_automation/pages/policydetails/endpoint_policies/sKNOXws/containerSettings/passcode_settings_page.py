from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceContainerPasscodeSettings as skwcps
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class PasscodeSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwcps.ElementNames.HEADER}"]')),
        'inner_text': skwcps.TextConstants.HEADER
    }
    epv_xpath = f'//input[@testname="{skwcps.ElementNames.PASSWORD_VISIBLE}"]'
    password_visible = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, epv_xpath),
                              label_text_locator=(By.XPATH, f'{epv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{epv_xpath}{toggle_xpath}')),
        'label_text': skwcps.TextConstants.PASSWORD_VISIBLE,
        'options': Options.YES_NO
    }
    mnfa_xpath = f'//input[@testname="{skwcps.ElementNames.MAX_FAILED_ATTEMPTS}"]'
    max_failed_attempts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mnfa_xpath),
                              label_text_locator=(By.XPATH, f'{mnfa_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.PASSWORD_VISIBLE
    }
    mpca_xpath = f'//input[@testname="{skwcps.ElementNames.PASSCODE_AGE}"]'
    passcode_age = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mpca_xpath),
                              label_text_locator=(By.XPATH, f'{mpca_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.PASSCODE_AGE
    }
    mpcl_xpath = f'//input[@testname="{skwcps.ElementNames.CHANGE_LENGTH}"]'
    change_length = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mpcl_xpath),
                              label_text_locator=(By.XPATH, f'{mpcl_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.CHANGE_LENGTH
    }
    pch_xpath = f'//input[@testname="{skwcps.ElementNames.PASSCODE_HISTORY}"]'
    passcode_history = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pch_xpath),
                              label_text_locator=(By.XPATH, f'{pch_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.PASSCODE_HISTORY
    }
    mpld_xpath = f'//input[@testname="{skwcps.ElementNames.PASSWORD_LOCK}"]'
    password_lock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mpld_xpath),
                              label_text_locator=(By.XPATH, f'{mpld_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.PASSWORD_LOCK
    }
    mncc_xpath = f'//input[@testname="{skwcps.ElementNames.COMPLEX_CHAR}"]'
    complex_char = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mncc_xpath),
                              label_text_locator=(By.XPATH, f'{mncc_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.COMPLEX_CHAR
    }
    efpa_xpath = f'//input[@testname="{skwcps.ElementNames.FINGERPRINT_AUTHENTICATION}"]'
    fingerprint_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, efpa_xpath),
                              label_text_locator=(By.XPATH, f'{efpa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{efpa_xpath}{toggle_xpath}')),
        'label_text': skwcps.TextConstants.FINGERPRINT_AUTHENTICATION,
        'options': Options.YES_NO
    }
    mpcq_xpath = f'//input[@testname="{skwcps.ElementNames.PASSCODE_QUALITY}"]'
    passcode_quality = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mpcq_xpath),
                              label_text_locator=(By.XPATH, f'{mpcq_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mpcq_xpath}{toggle_xpath}')),
        'label_text': skwcps.TextConstants.PASSCODE_QUALITY,
        'options': ['--', 'Complex', 'Alphanumeric', 'PIN', 'Pattern']
    }
    mpl_xpath = f'//input[@testname="{skwcps.ElementNames.MIN_PASS_LENGTH}"]'
    min_pass_length = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mpl_xpath),
                              label_text_locator=(By.XPATH, f'{mpl_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.MIN_PASS_LENGTH
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{skwcps.ElementNames.ADD}"]')),
        'label_text': skwcps.TextConstants.ADD
    }
    mcsl_xpath = f'//input[@testname="{skwcps.ElementNames.MAX_CHAR_SEQ}"]'
    max_char_seq = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mcsl_xpath),
                              label_text_locator=(By.XPATH, f'{mcsl_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.MAX_CHAR_SEQ
    }
    mnsl_xpath = f'//input[@testname="{skwcps.ElementNames.MAX_NUM_SEQ}"]'
    max_num_seq = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mnsl_xpath),
                              label_text_locator=(By.XPATH, f'{mnsl_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.MAX_NUM_SEQ
    }
    mco_xpath = f'//input[@testname="{skwcps.ElementNames.MAX_CHAR_OCCUR}"]'
    max_char_occur = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mco_xpath),
                              label_text_locator=(By.XPATH, f'{mco_xpath}{label_xpath}')),
        'label_text': skwcps.TextConstants.MAX_CHAR_OCCUR
    }
    rtfa_xpath = f'//input[@testname="{skwcps.ElementNames.FACTOR_AUTHENTICATION}"]'
    factor_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rtfa_xpath),
                              label_text_locator=(By.XPATH, f'{rtfa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rtfa_xpath}{toggle_xpath}')),
        'label_text': skwcps.TextConstants.FACTOR_AUTHENTICATION,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwcps.ElementNames.PASSWORD_VISIBLE: factory(driver).define_select(self.password_visible),
            skwcps.ElementNames.MAX_FAILED_ATTEMPTS: factory(driver).define_text_input(self.max_failed_attempts),
            skwcps.ElementNames.PASSCODE_AGE: factory(driver).define_text_input(self.passcode_age),
            skwcps.ElementNames.CHANGE_LENGTH: factory(driver).define_text_input(self.change_length),
            skwcps.ElementNames.PASSCODE_HISTORY: factory(driver).define_text_input(self.passcode_history),
            skwcps.ElementNames.PASSWORD_LOCK: factory(driver).define_text_input(self.password_lock),
            skwcps.ElementNames.COMPLEX_CHAR: factory(driver).define_text_input(self.complex_char),
            skwcps.ElementNames.FINGERPRINT_AUTHENTICATION: factory(driver).define_select(self.fingerprint_auth),
            skwcps.ElementNames.PASSCODE_QUALITY: factory(driver).define_select(self.passcode_quality),
            skwcps.ElementNames.MIN_PASS_LENGTH: factory(driver).define_text_input(self.min_pass_length),
            skwcps.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button),
            skwcps.ElementNames.MAX_CHAR_SEQ: factory(driver).define_text_input(self.max_char_seq),
            skwcps.ElementNames.MAX_NUM_SEQ: factory(driver).define_text_input(self.max_num_seq),
            skwcps.ElementNames.MAX_CHAR_OCCUR: factory(driver).define_text_input(self.max_char_occur),
            skwcps.ElementNames.FACTOR_AUTHENTICATION: factory(driver).define_select(self.factor_auth)
        }
        super().__init__(driver, self.elements)
