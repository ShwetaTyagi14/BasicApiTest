from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceDeviceEnableAuditLog as skwdeal
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EnableAuditLogPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwdeal.ElementNames.HEADER}"]')),
        'inner_text': skwdeal.TextConstants.HEADER
    }
    eal_xpath = f'//input[@testname="{skwdeal.ElementNames.ENABLE_AUDIT}"]'
    enable_audit = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eal_xpath),
                              label_text_locator=(By.XPATH, f'{eal_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eal_xpath}{toggle_xpath}')),
        'label_text': skwdeal.TextConstants.ENABLE_AUDIT,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwdeal.ElementNames.ENABLE_AUDIT: factory(driver).define_select(self.enable_audit)
        }
        super().__init__(driver, self.elements)
