from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceDeviceRestrictionSettings as skwdrs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictionsSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwdrs.ElementNames.HEADER}"]')),
        'inner_text': skwdrs.TextConstants.HEADER
    }
    aoaai_xpath = f'//input[@testname="{skwdrs.ElementNames.ALLOW_ADMIN_APP}"]'
    allow_admin_app = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aoaai_xpath),
                              label_text_locator=(By.XPATH, f'{aoaai_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aoaai_xpath}{toggle_xpath}')),
        'label_text': skwdrs.TextConstants.ALLOW_ADMIN_APP,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwdrs.ElementNames.ALLOW_ADMIN_APP: factory(driver).define_select(self.allow_admin_app)
        }
        super().__init__(driver, self.elements)
