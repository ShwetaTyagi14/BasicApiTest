from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceDeviceEnableCertificate as skwdec
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EnableCertValidationPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwdec.ElementNames.HEADER}"]')),
        'inner_text': skwdec.TextConstants.HEADER
    }
    ecvbi_xpath = f'//input[@testname="{skwdec.ElementNames.ENABLE_CERTIFICATE}"]'
    enable_certificate = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ecvbi_xpath),
                              label_text_locator=(By.XPATH, f'{ecvbi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ecvbi_xpath}{toggle_xpath}')),
        'label_text': skwdec.TextConstants.ENABLE_CERTIFICATE,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwdec.ElementNames.ENABLE_CERTIFICATE: factory(driver).define_select(self.enable_certificate)
        }
        super().__init__(driver, self.elements)
