from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceEnableTIMAKeyStore as skwetks
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EnableTIMAStorePage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skwetks.ElementNames.HEADER}"]')),
        'inner_text': skwetks.TextConstants.HEADER
    }
    etms_xpath = f'//input[@testname="{skwetks.ElementNames.ENABLE_TIMA_KEY}"]'
    enable_tima_key = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, etms_xpath),
                              label_text_locator=(By.XPATH, f'{etms_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{etms_xpath}{toggle_xpath}')),
        'label_text': skwetks.TextConstants.ENABLE_TIMA_KEY,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skwetks.ElementNames.ENABLE_TIMA_KEY: factory(driver).define_select(self.enable_tima_key)
        }
        super().__init__(driver, self.elements)
