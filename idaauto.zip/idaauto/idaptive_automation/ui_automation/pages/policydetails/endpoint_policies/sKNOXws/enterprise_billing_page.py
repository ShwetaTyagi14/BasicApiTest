from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXWorkspaceEnterpriseBilling as skweb
from idaptive_automation.ui_automation.constants import Xpaths


class EnterpriseBillingPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skweb.ElementNames.HEADER}"]')),
        'inner_text': skweb.TextConstants.HEADER
    }
    eeb_xpath = f'//input[@testname="{skweb.ElementNames.ENABLE_ENTERPRISE}"]'
    enable_enterprise = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eeb_xpath),
                              label_text_locator=(By.XPATH, f'{eeb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eeb_xpath}{toggle_xpath}')),
        'label_text': skweb.TextConstants.ENABLE_ENTERPRISE,
        'options': ['--', 'Yes']
    }
    pfn_xpath = f'//input[@testname="{skweb.ElementNames.PROFILE_NAME}"]'
    profile_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pfn_xpath),
                              label_text_locator=(By.XPATH, f'{pfn_xpath}/ancestor::td/div/label')),
        'label_text': skweb.TextConstants.PROFILE_NAME
    }
    apn_xpath = f'//input[@testname="{skweb.ElementNames.ACCESS_POINT_NAME}"]'
    access_point_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apn_xpath),
                              label_text_locator=(By.XPATH, f'{apn_xpath}/ancestor::td/div/label')),
        'label_text': skweb.TextConstants.ACCESS_POINT_NAME
    }
    mcc_xpath = f'//input[@testname="{skweb.ElementNames.MOBILE_COUNTRY_CODE}"]'
    mobile_country_code = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mcc_xpath),
                              label_text_locator=(By.XPATH, f'{mcc_xpath}/ancestor::td/div/label')),
        'label_text': skweb.TextConstants.MOBILE_COUNTRY_CODE
    }
    mnc_xpath = f'//input[@testname="{skweb.ElementNames.MOBILE_NETWORK_CODE}"]'
    mobile_network_code = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mnc_xpath),
                              label_text_locator=(By.XPATH, f'{mnc_xpath}/ancestor::td/div/label')),
        'label_text': skweb.TextConstants.MOBILE_NETWORK_CODE
    }

    def __init__(self, driver):
        self.enable_enterprise['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.profile_name),
                    factory(driver).define_text_input(self.access_point_name),
                    factory(driver).define_text_input(self.mobile_country_code),
                    factory(driver).define_text_input(self.mobile_network_code)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skweb.ElementNames.ENABLE_ENTERPRISE: factory(driver).define_select(self.enable_enterprise)
        }
        super().__init__(driver, self.elements)
