from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import EndpointPoliciesTouchdownSettings as epts

class TouchdownSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{epts.ElementNames.HEADER}"]')),
        'inner_text': epts.TextConstants.HEADER
    }
    etd_xpath = f'//input[@testname="{epts.ElementNames.ENABLE_TOUCHDOWN}"]'
    enable_touchdown = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, etd_xpath),
                              label_text_locator=(By.XPATH, f'{etd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{etd_xpath}{toggle_xpath}')),
        'label_text': epts.TextConstants.ENABLE_TOUCHDOWN,
        'options': Options.YES_NO
    }

    pd_xpath = f'//input[@testname="{epts.ElementNames.PAST_DAYS}"]'
    past_days = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,pd_xpath),
                              label_text_locator=(By.XPATH, f'{pd_xpath}/ancestor::table/parent::td/child::div'),
                              toggle_locator=(By.XPATH, f'{pd_xpath}/parent::td/following-sibling::td')),
        'label_text': epts.TextConstants.PAST_DAYS,
        'options': ['No limit', '1 day', '3 days', '1 week', '2 weeks', '1 month']
    }

    def __init__(self, driver):
        self.enable_touchdown['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_exchange_settings(self.past_days)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_touchdown': factory(driver).define_select(self.enable_touchdown)

        }
        super().__init__(driver, self.elements)
