from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsWifiRestrictions as skdswr
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class WiFiRestrictionsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdswr.ElementNames.HEADER}"]')),
        'inner_text': skdswr.TextConstants.HEADER
    }
    mcsl_xpath = f'//input[@testname="{skdswr.ElementNames.CERTIFICATE_SECURITY_LEVEL}"]'
    certificate_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mcsl_xpath),
                              label_text_locator=(By.XPATH, f'{mcsl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mcsl_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.CERTIFICATE_SECURITY_LEVEL,
        'options': ['--', 'Low', 'High']
    }
    mslc_xpath = f'//input[@testname="{skdswr.ElementNames.MINIMUM_REQUIRED_SECURITY}"]'
    minimum_required_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mslc_xpath),
                              label_text_locator=(By.XPATH, f'{mslc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mslc_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.MINIMUM_REQUIRED_SECURITY,
        'options': ['--', 'Open', 'WEP', 'WPA/WPA2-PSK', '802.1x EAP-LEAP', '802.1x EAP-FAST', '802.1x EAP-PEAP', '802.1x EAP-TTLS', '802.1x EAP-TLS']
    }
    puawn_xpath = f'//input[@testname="{skdswr.ElementNames.ALLOW_USER_PROFILES}"]'
    allow_user_profiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, puawn_xpath),
                              label_text_locator=(By.XPATH, f'{puawn_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{puawn_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.ALLOW_USER_PROFILES,
        'options': Options.YES_NO
    }
    pucws_xpath = f'//input[@testname="{skdswr.ElementNames.ALLOW_WIFI_STATE_CHANGE}"]'
    allow_wifi_state_change = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pucws_xpath),
                              label_text_locator=(By.XPATH, f'{pucws_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pucws_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.ALLOW_WIFI_STATE_CHANGE,
        'options': Options.YES_NO
    }
    pucakw_xpath = f'//input[@testname="{skdswr.ElementNames.ALLOW_AUTOMATIC_CONNECTION}"]'
    automatic_connection = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pucakw_xpath),
                              label_text_locator=(By.XPATH, f'{pucakw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pucakw_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.ALLOW_AUTOMATIC_CONNECTION,
        'options': Options.YES_NO
    }
    puewa_xpath = f'//input[@testname="{skdswr.ElementNames.ALLOW_WIFI_AP_SETTING}"]'
    allow_wifi_change = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, puewa_xpath),
                              label_text_locator=(By.XPATH, f'{puewa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{puewa_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.ALLOW_WIFI_AP_SETTING,
        'options': Options.YES_NO
    }
    pumws_xpath = f'//input[@testname="{skdswr.ElementNames.ALLOW_USER_POLICY_CHANGE}"]'
    allow_user_policy_change = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pumws_xpath),
                              label_text_locator=(By.XPATH, f'{pumws_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pumws_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.ALLOW_USER_POLICY_CHANGE,
        'options': Options.YES_NO
    }
    pusoh_xpath = f'//input[@testname="{skdswr.ElementNames.ALLOW_OPEN_WIFI_AP}"]'
    allow_open_wifi = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pusoh_xpath),
                              label_text_locator=(By.XPATH, f'{pusoh_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pusoh_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.ALLOW_OPEN_WIFI_AP,
        'options': Options.YES_NO
    }
    purca_xpath = f'//input[@testname="{skdswr.ElementNames.PROMPT_CREDENTIALS_ENABLED}"]'
    prompt_credentials = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, purca_xpath),
                              label_text_locator=(By.XPATH, f'{purca_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{purca_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.PROMPT_CREDENTIALS_ENABLED,
        'options': Options.YES_NO
    }
    spwnd_xpath = f'//input[@testname="{skdswr.ElementNames.PASSWORD_HIDDEN}"]'
    password_hidden = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, spwnd_xpath),
                              label_text_locator=(By.XPATH, f'{spwnd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{spwnd_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.PASSWORD_HIDDEN,
        'options': Options.YES_NO
    }
    waps_xpath = f'//input[@testname="{skdswr.ElementNames.WIFI_AP_SETTINGS}"]'
    wifi_ap_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, waps_xpath),
                              label_text_locator=(By.XPATH, f'{waps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{waps_xpath}{toggle_xpath}')),
        'label_text': skdswr.TextConstants.WIFI_AP_SETTINGS,
        'options': ['--', 'Yes']
    }
    ssid_xpath = f'//input[@testname="{skdswr.ElementNames.SSID}"]'
    ssid_textbox = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ssid_xpath),
                              label_text_locator=(By.XPATH, f'{ssid_xpath}/ancestor::table/following-sibling::label')),
        'label_text': skdswr.TextConstants.SSID
    }
    sectp_xpath = f'//input[@testname="{skdswr.ElementNames.SECURITY_TYPE}"]'
    security_type = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sectp_xpath),
                              label_text_locator=(By.XPATH, f'{sectp_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{sectp_xpath}/parent::td/following-sibling::td')),
        'label_text': skdswr.TextConstants.SECURITY_TYPE,
        'options': ['Open', 'WPA/PSK']
    }
    pwd_xpath = f'//input[@testname="{skdswr.ElementNames.PASSWORD}"]'
    pwd_textbox = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pwd_xpath),
                              label_text_locator=(By.XPATH, f'{pwd_xpath}/ancestor::table/following-sibling::label')),
        'label_text': skdswr.TextConstants.SSID
    }
    add_button1 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{skdswr.ElementNames.ADD}"])[1]')),
        'label_text': skdswr.TextConstants.ADD
    }
    add_button2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{skdswr.ElementNames.ADD}"])[2]')),
        'label_text': skdswr.TextConstants.ADD
    }
    add_button3 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{skdswr.ElementNames.ADD}"])[3]')),
        'label_text': skdswr.TextConstants.ADD
    }

    def __init__(self, driver):
        self.wifi_ap_settings['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.ssid_textbox),
                    factory(driver).define_select(self.security_type),
                    factory(driver).define_text_input(self.pwd_textbox)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skdswr.ElementNames.CERTIFICATE_SECURITY_LEVEL: factory(driver).define_select(self.certificate_security),
            skdswr.ElementNames.MINIMUM_REQUIRED_SECURITY: factory(driver).define_select(self.minimum_required_security),
            skdswr.ElementNames.ALLOW_USER_PROFILES: factory(driver).define_select(self.allow_user_profiles),
            skdswr.ElementNames.ALLOW_WIFI_STATE_CHANGE: factory(driver).define_select(self.allow_wifi_state_change),
            skdswr.ElementNames.ALLOW_AUTOMATIC_CONNECTION: factory(driver).define_select(self.automatic_connection),
            skdswr.ElementNames.ALLOW_WIFI_AP_SETTING: factory(driver).define_select(self.allow_wifi_change),
            skdswr.ElementNames.ALLOW_USER_POLICY_CHANGE: factory(driver).define_select(self.allow_user_policy_change),
            skdswr.ElementNames.ALLOW_OPEN_WIFI_AP: factory(driver).define_select(self.allow_open_wifi),
            skdswr.ElementNames.PROMPT_CREDENTIALS_ENABLED: factory(driver).define_select(self.prompt_credentials),
            skdswr.ElementNames.PASSWORD_HIDDEN: factory(driver).define_select(self.password_hidden),
            skdswr.ElementNames.WIFI_AP_SETTINGS: factory(driver).define_select(self.wifi_ap_settings),
            'add_button1': factory(driver).define_modify_delete_grid(self.add_button1),
            'add_button2': factory(driver).define_modify_delete_grid(self.add_button2),
            'add_button3': factory(driver).define_modify_delete_grid(self.add_button3)
        }
        super().__init__(driver, self.elements)
