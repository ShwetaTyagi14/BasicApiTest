from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXDeviceSettingsVPNSettings as skdsvs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class VPNSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsvs.ElementNames.HEADER}"]')),
        'inner_text': skdsvs.TextConstants.HEADER
    }

    ad_xpath = f'//a[@buttontext="{skdsvs.ElementNames.ADD}"]'
    add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ad_xpath)),
        'label_text': skdsvs.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'add': factory(driver).define_modify_delete_grid(self.add)
        }
        super().__init__(driver, self.elements)
