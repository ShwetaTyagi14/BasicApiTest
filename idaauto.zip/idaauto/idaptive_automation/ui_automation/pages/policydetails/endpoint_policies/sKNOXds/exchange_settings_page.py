from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import ExchangeSettings as skes
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class ExchangeSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    skes_xpath = f'//input[@testname="{skes.ElementNames.ENABLE_EXC_SYNC}"]'
    enable_active_sync = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skes_xpath),
                              label_text_locator=(By.XPATH, f'{skes_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skes_xpath}{toggle_xpath}')),
        'label_text': skes.TextConstants.ENABLE_EXC_SYNC,
        'options': Options.YES_NO
    }

    skes_basic_xpath = f'//div[text()="{skes.ElementNames.BASIC}"]'
    basic = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skes_basic_xpath),
                              label_text_locator=(By.XPATH, f'{skes_basic_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skes_basic_xpath}{toggle_xpath}')),
            'label_text': skes.TextConstants.BASIC,
    }

    def __init__(self, driver):

        self.enable_active_sync['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_exchange_settings(self.basic),
                ]
            }
        ]
        self.elements = {
            'enable_active_sync': factory(driver).define_select(self.enable_active_sync),
        }
        super().__init__(driver, self.elements)
