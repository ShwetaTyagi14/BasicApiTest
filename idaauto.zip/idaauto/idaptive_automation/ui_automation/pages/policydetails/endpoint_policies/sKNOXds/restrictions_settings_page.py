from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsRestrictionsSettings as skdsrs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictionsSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsrs.ElementNames.HEADER}"]')),
        'inner_text': skdsrs.TextConstants.HEADER
    }
    fgps_xpath = f'//input[@testname="{skdsrs.ElementNames.FORCE_GPS}"]'
    force_gps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, fgps_xpath),
                              label_text_locator=(By.XPATH, f'{fgps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{fgps_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.FORCE_GPS,
        'options': Options.YES_NO
    }
    abdu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_BACKGROUND_DATA}"]'
    allow_background_data = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, abdu_xpath),
                              label_text_locator=(By.XPATH, f'{abdu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{abdu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_BACKGROUND_DATA,
        'options': Options.YES_NO
    }
    aac_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_CLIPBOARD}"]'
    allow_clipboard = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aac_xpath),
                              label_text_locator=(By.XPATH, f'{aac_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aac_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_CLIPBOARD,
        'options': Options.YES_NO
    }
    aabu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_ANDROID_BEAM}"]'
    allow_android_beam = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aabu_xpath),
                              label_text_locator=(By.XPATH, f'{aabu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aabu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_ANDROID_BEAM,
        'options': Options.YES_NO
    }
    aarc_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_AUDIO_RECORD}"]'
    allow_audio_record = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aarc_xpath),
                              label_text_locator=(By.XPATH, f'{aarc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aarc_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_AUDIO_RECORD,
        'options': Options.YES_NO
    }
    abc_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_BLUETOOTH}"]'
    allow_bluetooth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, abc_xpath),
                              label_text_locator=(By.XPATH, f'{abc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{abc_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_BLUETOOTH,
        'options': Options.YES_NO
    }
    acdu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_CELLULAR_DATA}"]'
    allow_cellular_data = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, acdu_xpath),
                              label_text_locator=(By.XPATH, f'{acdu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{acdu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_CELLULAR_DATA,
        'options': Options.YES_NO
    }
    acw_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_WALLPAPER_CHANGE}"]'
    allow_change_wallpaper = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, acw_xpath),
                              label_text_locator=(By.XPATH, f'{acw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{acw_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_WALLPAPER_CHANGE,
        'options': Options.YES_NO
    }
    adtc_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_DATETIME_CHANGE}"]'
    allow_datetime_change = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adtc_xpath),
                              label_text_locator=(By.XPATH, f'{adtc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{adtc_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_DATETIME_CHANGE,
        'options': Options.YES_NO
    }
    aump_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_USB_MEDIA}"]'
    allow_usb_media = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aump_xpath),
                              label_text_locator=(By.XPATH, f'{aump_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aump_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_USB_MEDIA,
        'options': Options.YES_NO
    }
    aesb_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_STATUSBAR_EXPANSION}"]'
    allow_statusbar_expansion = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aesb_xpath),
                              label_text_locator=(By.XPATH, f'{aesb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aesb_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_STATUSBAR_EXPANSION,
        'options': Options.YES_NO
    }
    afr_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_FIRMWARE_RECOVERY}"]'
    allow_firmware_recovery = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, afr_xpath),
                              label_text_locator=(By.XPATH, f'{afr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{afr_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_FIRMWARE_RECOVERY,
        'options': Options.YES_NO
    }
    agb_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_BACKUP}"]'
    allow_google_backup = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, agb_xpath),
                              label_text_locator=(By.XPATH, f'{agb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{agb_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_BACKUP,
        'options': Options.YES_NO
    }
    ahkf_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_HOMEKEY}"]'
    allow_homekey_functionality = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ahkf_xpath),
                              label_text_locator=(By.XPATH, f'{ahkf_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ahkf_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_HOMEKEY,
        'options': Options.YES_NO
    }
    picc_xpath = f'//input[@testname="{skdsrs.ElementNames.PERMIT_INCOMING_CALLS}"]'
    permit_incoming_calls = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, picc_xpath),
                              label_text_locator=(By.XPATH, f'{picc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{picc_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.PERMIT_INCOMING_CALLS,
        'options': Options.YES_NO
    }
    aingp_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_NONMARKET_APPS}"]'
    allow_nonmarket_apps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aingp_xpath),
                              label_text_locator=(By.XPATH, f'{aingp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aingp_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_NONMARKET_APPS,
        'options': Options.YES_NO
    }
    akaul_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_KILLING_ACTIVITIES}"]'
    allow_killing_activities = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, akaul_xpath),
                              label_text_locator=(By.XPATH, f'{akaul_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{akaul_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_KILLING_ACTIVITIES,
        'options': Options.YES_NO
    }
    ampu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_MICROPHONE}"]'
    allow_microphone_use = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ampu_xpath),
                              label_text_locator=(By.XPATH, f'{ampu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ampu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_MICROPHONE,
        'options': Options.YES_NO
    }
    amgl_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_MOCK_LOCATION}"]'
    allow_mock_location = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, amgl_xpath),
                              label_text_locator=(By.XPATH, f'{amgl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{amgl_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_MOCK_LOCATION,
        'options': Options.YES_NO
    }
    emu_xpath = f'//input[@testname="{skdsrs.ElementNames.ENABLE_MULTI_USERS}"]'
    enable_multi_users = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, emu_xpath),
                              label_text_locator=(By.XPATH, f'{emu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{emu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ENABLE_MULTI_USERS,
        'options': Options.YES_NO
    }
    anfcu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_ENABLE_NFC}"]'
    allow_enable_nfc = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, anfcu_xpath),
                              label_text_locator=(By.XPATH, f'{anfcu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{anfcu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_ENABLE_NFC,
        'options': Options.YES_NO
    }
    apwro_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_POWER_OFF}"]'
    allow_power_off = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apwro_xpath),
                              label_text_locator=(By.XPATH, f'{apwro_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{apwro_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_POWER_OFF,
        'options': Options.YES_NO
    }
    asbu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SBEAM}"]'
    allow_sbeam = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asbu_xpath),
                              label_text_locator=(By.XPATH, f'{asbu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asbu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_SBEAM,
        'options': Options.YES_NO
    }
    asvau_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SVOICE}"]'
    allow_svoice = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asvau_xpath),
                              label_text_locator=(By.XPATH, f'{asvau_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asvau_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_SVOICE,
        'options': Options.YES_NO
    }
    asml_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SAFE_MODE}"]'
    allow_safe_mode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asml_xpath),
                              label_text_locator=(By.XPATH, f'{asml_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asml_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_SAFE_MODE,
        'options': Options.YES_NO
    }
    ascp_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SCREEN_CAPTURE}"]'
    allow_screen_capture = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ascp_xpath),
                              label_text_locator=(By.XPATH, f'{ascp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ascp_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_SCREEN_CAPTURE,
        'options': Options.YES_NO
    }
    asca_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SDCARD}"]'
    allow_sdcard_access = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asca_xpath),
                              label_text_locator=(By.XPATH, f'{asca_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asca_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_SDCARD,
        'options': Options.YES_NO
    }
    ascrg_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_CRASH_REPORT}"]'
    allow_crash_report = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ascrg_xpath),
                              label_text_locator=(By.XPATH, f'{ascrg_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ascrg_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_CRASH_REPORT,
        'options': Options.YES_NO
    }
    asbpl_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_BACKGROUND_PROCESS}"]'
    allow_backgroung_process = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asbpl_xpath),
                              label_text_locator=(By.XPATH, f'{asbpl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asbpl_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_BACKGROUND_PROCESS,
        'options': Options.YES_NO
    }
    asmdl_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_USER_MOBILE_DATA}"]'
    allow_user_mobile_data = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asmdl_xpath),
                              label_text_locator=(By.XPATH, f'{asmdl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asmdl_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_USER_MOBILE_DATA,
        'options': Options.YES_NO
    }
    asc_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SETTINGS_CHANGE}"]'
    allow_settings_change = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asc_xpath),
                              label_text_locator=(By.XPATH, f'{asc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{asc_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_SETTINGS_CHANGE,
        'options': Options.YES_NO
    }
    ascba_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_CLIPBOARD_SHARE}"]'
    allow_clipboard_share = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ascba_xpath),
                              label_text_locator=(By.XPATH, f'{ascba_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ascba_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_CLIPBOARD_SHARE,
        'options': Options.YES_NO
    }
    assa_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_STOP_SYSTEM_APP}"]'
    allow_stop_system_app = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, assa_xpath),
                              label_text_locator=(By.XPATH, f'{assa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{assa_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_STOP_SYSTEM_APP,
        'options': Options.YES_NO
    }
    attr_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_TETHERING}"]'
    allow_tethering = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, attr_xpath),
                              label_text_locator=(By.XPATH, f'{attr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{attr_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_TETHERING,
        'options': Options.YES_NO
    }
    aota_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_OTA_UPGRADE}"]'
    allow_ota_upgrade = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aota_xpath),
                              label_text_locator=(By.XPATH, f'{aota_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aota_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_OTA_UPGRADE,
        'options': Options.YES_NO
    }
    ausbd_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_USB_DEBUGGING}"]'
    allow_usb_debugging = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ausbd_xpath),
                              label_text_locator=(By.XPATH, f'{ausbd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ausbd_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_USB_DEBUGGING,
        'options': Options.YES_NO
    }
    ausbhs_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_USB_HOST_STORAGE}"]'
    allow_usb_host_storage = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ausbhs_xpath),
                              label_text_locator=(By.XPATH, f'{ausbhs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ausbhs_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_USB_HOST_STORAGE,
        'options': Options.YES_NO
    }
    avr_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_VIDEO_RECORD}"]'
    allow_video_record = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, avr_xpath),
                              label_text_locator=(By.XPATH, f'{avr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{avr_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_VIDEO_RECORD,
        'options': Options.YES_NO
    }
    avpn_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_VPN}"]'
    allow_vpn = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, avpn_xpath),
                              label_text_locator=(By.XPATH, f'{avpn_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{avpn_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_VPN,
        'options': Options.YES_NO
    }
    awfu_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_WIFI}"]'
    allow_wifi = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, awfu_xpath),
                              label_text_locator=(By.XPATH, f'{awfu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{awfu_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ALLOW_WIFI,
        'options': Options.YES_NO
    }
    asdcw_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_SDCARD_WRITE}"]'
    allow_sdcard_write = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, asdcw_xpath),
                              label_text_locator=(By.XPATH, f'{asdcw_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{asdcw_xpath}/ancestor::table')),
        'label_text': skdsrs.TextConstants.ALLOW_SDCARD_WRITE,
        'checked': True
    }
    ausbt_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_USB_TETHERING}"]'
    allow_usb_tethering = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ausbt_xpath),
                              label_text_locator=(By.XPATH, f'{ausbt_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ausbt_xpath}/ancestor::table')),
        'label_text': skdsrs.TextConstants.ALLOW_USB_TETHERING,
        'checked': True
    }
    awifit_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_WIFI_TETHERING}"]'
    allow_wifi_tethering = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, awifit_xpath),
                              label_text_locator=(By.XPATH, f'{awifit_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{awifit_xpath}/ancestor::table')),
        'label_text': skdsrs.TextConstants.ALLOW_WIFI_TETHERING,
        'checked': True
    }
    abltt_xpath = f'//input[@testname="{skdsrs.ElementNames.ALLOW_BLUETOOTH_TETHERING}"]'
    allow_bluetooth_tethering = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, abltt_xpath),
                              label_text_locator=(By.XPATH, f'{abltt_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{abltt_xpath}/ancestor::table')),
        'label_text': skdsrs.TextConstants.ALLOW_BLUETOOTH_TETHERING,
        'checked': True
    }

    def __init__(self, driver):
        self.allow_sdcard_access['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.allow_sdcard_write),
                ]
            }
        ]
        self.allow_tethering['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.allow_usb_tethering),
                    factory(driver).define_checkbox(self.allow_wifi_tethering),
                    factory(driver).define_checkbox(self.allow_bluetooth_tethering),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skdsrs.ElementNames.FORCE_GPS: factory(driver).define_select(self.force_gps),
            skdsrs.ElementNames.ALLOW_BACKGROUND_DATA: factory(driver).define_select(self.allow_background_data),
            skdsrs.ElementNames.ALLOW_CLIPBOARD: factory(driver).define_select(self.allow_clipboard),
            skdsrs.ElementNames.ALLOW_ANDROID_BEAM: factory(driver).define_select(self.allow_android_beam),
            skdsrs.ElementNames.ALLOW_AUDIO_RECORD: factory(driver).define_select(self.allow_audio_record),
            skdsrs.ElementNames.ALLOW_BLUETOOTH: factory(driver).define_select(self.allow_bluetooth),
            skdsrs.ElementNames.ALLOW_CELLULAR_DATA: factory(driver).define_select(self.allow_cellular_data),
            skdsrs.ElementNames.ALLOW_WALLPAPER_CHANGE: factory(driver).define_select(self.allow_change_wallpaper),
            skdsrs.ElementNames.ALLOW_DATETIME_CHANGE: factory(driver).define_select(self.allow_datetime_change),
            skdsrs.ElementNames.ALLOW_USB_MEDIA: factory(driver).define_select(self.allow_usb_media),
            skdsrs.ElementNames.ALLOW_STATUSBAR_EXPANSION: factory(driver).define_select(self.allow_statusbar_expansion),
            skdsrs.ElementNames.ALLOW_FIRMWARE_RECOVERY: factory(driver).define_select(self.allow_firmware_recovery),
            skdsrs.ElementNames.ALLOW_BACKUP: factory(driver).define_select(self.allow_google_backup),
            skdsrs.ElementNames.ALLOW_HOMEKEY: factory(driver).define_select(self.allow_homekey_functionality),
            skdsrs.ElementNames.PERMIT_INCOMING_CALLS: factory(driver).define_select(self.permit_incoming_calls),
            skdsrs.ElementNames.ALLOW_NONMARKET_APPS: factory(driver).define_select(self.allow_nonmarket_apps),
            skdsrs.ElementNames.ALLOW_KILLING_ACTIVITIES: factory(driver).define_select(self.allow_killing_activities),
            skdsrs.ElementNames.ALLOW_MICROPHONE: factory(driver).define_select(self.allow_microphone_use),
            skdsrs.ElementNames.ALLOW_MOCK_LOCATION: factory(driver).define_select(self.allow_mock_location),
            skdsrs.ElementNames.ENABLE_MULTI_USERS: factory(driver).define_select(self.enable_multi_users),
            skdsrs.ElementNames.ALLOW_ENABLE_NFC: factory(driver).define_select(self.allow_enable_nfc),
            skdsrs.ElementNames.ALLOW_POWER_OFF: factory(driver).define_select(self.allow_power_off),
            skdsrs.ElementNames.ALLOW_SBEAM: factory(driver).define_select(self.allow_sbeam),
            skdsrs.ElementNames.ALLOW_SVOICE: factory(driver).define_select(self.allow_svoice),
            skdsrs.ElementNames.ALLOW_SAFE_MODE: factory(driver).define_select(self.allow_safe_mode),
            skdsrs.ElementNames.ALLOW_SCREEN_CAPTURE: factory(driver).define_select(self.allow_screen_capture),
            skdsrs.ElementNames.ALLOW_SDCARD: factory(driver).define_select(self.allow_sdcard_access),
            skdsrs.ElementNames.ALLOW_CRASH_REPORT: factory(driver).define_select(self.allow_crash_report),
            skdsrs.ElementNames.ALLOW_BACKGROUND_PROCESS: factory(driver).define_select(self.allow_backgroung_process),
            skdsrs.ElementNames.ALLOW_USER_MOBILE_DATA: factory(driver).define_select(self.allow_user_mobile_data),
            skdsrs.ElementNames.ALLOW_SETTINGS_CHANGE: factory(driver).define_select(self.allow_settings_change),
            skdsrs.ElementNames.ALLOW_CLIPBOARD_SHARE: factory(driver).define_select(self.allow_clipboard_share),
            skdsrs.ElementNames.ALLOW_STOP_SYSTEM_APP: factory(driver).define_select(self.allow_stop_system_app),
            skdsrs.ElementNames.ALLOW_TETHERING: factory(driver).define_select(self.allow_tethering),
            skdsrs.ElementNames.ALLOW_OTA_UPGRADE: factory(driver).define_select(self.allow_ota_upgrade),
            skdsrs.ElementNames.ALLOW_USB_DEBUGGING: factory(driver).define_select(self.allow_usb_debugging),
            skdsrs.ElementNames.ALLOW_USB_HOST_STORAGE: factory(driver).define_select(self.allow_usb_host_storage),
            skdsrs.ElementNames.ALLOW_VIDEO_RECORD: factory(driver).define_select(self.allow_video_record),
            skdsrs.ElementNames.ALLOW_VPN: factory(driver).define_select(self.allow_vpn),
            skdsrs.ElementNames.ALLOW_WIFI: factory(driver).define_select(self.allow_wifi)
        }
        super().__init__(driver, self.elements)
