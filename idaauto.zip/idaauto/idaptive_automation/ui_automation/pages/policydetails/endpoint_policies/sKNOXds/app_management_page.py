from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsunKnoxApplicationManagement as skam
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class ApplicationManagementPage(UIPage):

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,f'//div[text()="{skam.ElementNames.HEADER}"]')),
              'inner_text': skam.TextConstants.HEADER
    }

    add_button1 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[1]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[4]')),
            'label_text': skam.TextConstants.ADD
    }

    skam_apps_block = f'//input[@testname="{skam.ElementNames.BLOCK_APPS_NOTIFICATIONS}"]'
    skam_block_apps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skam_apps_block),
                              label_text_locator=(By.XPATH, f'{skam_apps_block}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skam_apps_block}{toggle_xpath}')),
        'label_text': skam.TextConstants.BLOCK_APPS_NOTIFICATIONS,
        'options': Options.BLOCK_APPS_NOTIFICATIONS
    }

    skam_pre_apps = f'//input[@testname="{skam.ElementNames.PREVENT_APPS_INSTALL}"]'
    skam_pre_apps_ins = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, skam_pre_apps),
                              label_text_locator=(By.XPATH, f'{skam_pre_apps}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{skam_pre_apps}{toggle_xpath}')),
        'label_text': skam.TextConstants.PREVENT_APPS_INSTALL,
        'options': Options.PREVENT_APPS_INSTALL
    }

    add_button3 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[5]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button4 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[6]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button5 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[7]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button6 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[8]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button7 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[9]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button8 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[10]')),
            'label_text': skam.TextConstants.ADD
    }

    add_button9 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[11]')),
            'label_text': skam.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button1),
            skam.ElementNames.BLOCK_APPS_NOTIFICATIONS: factory(driver).define_select(self.skam_block_apps),
            skam.ElementNames.PREVENT_APPS_INSTALL:factory(driver).define_select(self.skam_pre_apps_ins),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button2),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button3),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button4),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button5),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button6),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button7),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button8),
            skam.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button9),

        }
        super().__init__(driver, self.elements)
