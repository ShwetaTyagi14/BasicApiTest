from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsVpnRestrictions as skdsvs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class VPNRestrictionsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsvs.ElementNames.HEADER}"]')),
        'inner_text': skdsvs.TextConstants.HEADER
    }
    avc_xpath = f'//input[@testname="{skdsvs.ElementNames.VPN_CONNECTIONS}"]'
    allow_vpn_connections = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, avc_xpath),
                              label_text_locator=(By.XPATH, f'{avc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{avc_xpath}{toggle_xpath}')),
        'label_text': skdsvs.TextConstants.VPN_CONNECTIONS,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skdsvs.ElementNames.VPN_CONNECTIONS: factory(driver).define_select(self.allow_vpn_connections)
        }
        super().__init__(driver, self.elements)
