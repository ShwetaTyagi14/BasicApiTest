from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsSecuritySettings as skdss


class SecuritySettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdss.ElementNames.HEADER}"]')),
        'inner_text': skdss.TextConstants.HEADER
    }
    ebm_xpath = f'//input[@testname="{skdss.ElementNames.BANNER_MESSAGE}"]'
    enable_banner_message = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ebm_xpath),
                              label_text_locator=(By.XPATH, f'{ebm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ebm_xpath}{toggle_xpath}')),
        'label_text': skdss.TextConstants.BANNER_MESSAGE,
        'options': Options.YES_NO
    }
    escl_xpath = f'//input[@testname="{skdss.ElementNames.SIM_CARD_LOCK}"]'
    enable_sim_card_lock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, escl_xpath),
                              label_text_locator=(By.XPATH, f'{escl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{escl_xpath}{toggle_xpath}')),
        'label_text': skdss.TextConstants.SIM_CARD_LOCK,
        'options': ['--', 'Yes']
    }
    escr_xpath = f'//input[@testname="{skdss.ElementNames.SIM_CARD_REMOVAL}"]'
    enable_sim_card_removal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, escr_xpath),
                              label_text_locator=(By.XPATH, f'{escr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{escr_xpath}{toggle_xpath}')),
        'label_text': skdss.TextConstants.SIM_CARD_REMOVAL,
        'options': Options.YES_NO
    }
    ers_xpath = f'//input[@testname="{skdss.ElementNames.REMOVABLE_STORAGE}"]'
    encrypt_removable_storage = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ers_xpath),
                              label_text_locator=(By.XPATH, f'{ers_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ers_xpath}{toggle_xpath}')),
        'label_text': skdss.TextConstants.REMOVABLE_STORAGE,
        'options': Options.YES_NO
    }
    dsp_xpath = f'//input[@testname="{skdss.ElementNames.SIM_PIN}"]'
    default_sim_pin = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dsp_xpath),
                              label_text_locator=(By.XPATH, f'{dsp_xpath}/ancestor::table/following-sibling::label')),
        'label_text': skdss.TextConstants.SIM_PIN
    }
    nsp_xpath = f'//input[@testname="{skdss.ElementNames.NEW_SIM_PIN}"]'
    new_sim_pin = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, nsp_xpath),
                              label_text_locator=(By.XPATH, f'{nsp_xpath}/ancestor::table/following-sibling::label')),
        'label_text': skdss.TextConstants.NEW_SIM_PIN
    }

    def __init__(self, driver):
        self.enable_sim_card_lock['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.default_sim_pin),
                    factory(driver).define_text_input(self.new_sim_pin)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skdss.ElementNames.BANNER_MESSAGE: factory(driver).define_select(self.enable_banner_message),
            skdss.ElementNames.SIM_CARD_LOCK: factory(driver).define_select(self.enable_sim_card_lock),
            skdss.ElementNames.SIM_CARD_REMOVAL: factory(driver).define_select(self.enable_sim_card_removal),
            skdss.ElementNames.REMOVABLE_STORAGE: factory(driver).define_select(self.encrypt_removable_storage)
        }
        super().__init__(driver, self.elements)
