from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXDeviceSettingsWifiSettings as skdsws
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class WiFiSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsws.ElementNames.HEADER}"]')),
        'inner_text': skdsws.TextConstants.HEADER
    }

    ad_xpath = f'//a[@buttontext="{skdsws.ElementNames.ADD}"]'
    add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ad_xpath)),
        'label_text': skdsws.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'add': factory(driver).define_modify_delete_grid(self.add)
        }
        super().__init__(driver, self.elements)