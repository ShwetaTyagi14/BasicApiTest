from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKnoxKioskMode as snkm
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class KioskModePage(UIPage):

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{snkm.ElementNames.HEADER}"]')),
              'inner_text': snkm.TextConstants.HEADER
    }

    enable_kiosk_xpath = f'//input[@testname="{snkm.ElementNames.ENABLE_KIOSK}"]'
    enable_kiosk = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, enable_kiosk_xpath),
                              label_text_locator=(By.XPATH, f'{enable_kiosk_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{enable_kiosk_xpath}{toggle_xpath}')),
        'label_text': snkm.TextConstants.ENABLE_KIOSK,
        'options': Options.YES_NO
    }

    use_default_home = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.USE_DEFAULT_HOME}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.USE_DEFAULT_HOME}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="{snkm.TextConstants.USE_DEFAULT_HOME}"]]')),
        'label_text': snkm.TextConstants.USE_DEFAULT_HOME,
        'checked': True,
    }

    use_custom_launcher = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.USE_CUSTOM_LAUNCHER}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.USE_CUSTOM_LAUNCHER}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="{snkm.TextConstants.USE_CUSTOM_LAUNCHER}"]]')),
            'label_text': snkm.TextConstants.USE_CUSTOM_LAUNCHER,
            'checked': False,
    }

    package_name_xpath = f'//input[@testname="{snkm.ElementNames.PACKAGE_NAME}"]'
    package_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, package_name_xpath),
                              label_text_locator=(By.XPATH, f'{package_name_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{package_name_xpath}{toggle_xpath}')),
        'label_text': snkm.TextConstants.PACKAGE_NAME,
    }

    use_mdm_client = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.USE_MDM_CLIENT}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.USE_MDM_CLIENT}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="{snkm.TextConstants.USE_MDM_CLIENT}"]]')),
            'label_text': snkm.TextConstants.USE_MDM_CLIENT,
            'checked': False,
    }

    enable_auto_update = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.ENABLE_AUTO_UPDATE}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.ENABLE_AUTO_UPDATE}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[1]/div/label[normalize-space(.)="{snkm.TextConstants.ENABLE_AUTO_UPDATE}"]]')),
        'label_text': snkm.TextConstants.ENABLE_AUTO_UPDATE,
        'checked': False,
    }

    enable_auto_update_time = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.ENABLE_AUTO_UPDATE_TIME}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{snkm.TextConstants.ENABLE_AUTO_UPDATE_TIME}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[1]/div/label[normalize-space(.)="{snkm.TextConstants.ENABLE_AUTO_UPDATE_TIME}"]]')),
        'label_text': snkm.TextConstants.ENABLE_AUTO_UPDATE_TIME,
        'checked': True,
    }

    per_multi_win_xpath = f'//input[@testname="{snkm.ElementNames.PER_MULTI_WIN}"]'
    per_multi_win = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, per_multi_win_xpath),
                              label_text_locator=(By.XPATH, f'{per_multi_win_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{per_multi_win_xpath}{toggle_xpath}')),
        'label_text': snkm.TextConstants.PER_MULTI_WIN,
        'options': Options.YES_NO
    }

    per_navbar_xpath = f'//input[@testname="{snkm.ElementNames.PER_NAVBAR_VISIBILITY}"]'
    per_navbar = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, per_navbar_xpath),
                              label_text_locator=(By.XPATH, f'{per_navbar_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{per_navbar_xpath}{toggle_xpath}')),
        'label_text': snkm.TextConstants.PER_NAVBAR_VISIBILITY,
        'options': Options.YES_NO
    }

    per_statusbar_xpath = f'//input[@testname="{snkm.ElementNames.PER_STATUSBAR_VISIBILITY}"]'
    per_statusbar = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, per_statusbar_xpath),
                              label_text_locator=(By.XPATH, f'{per_statusbar_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{per_statusbar_xpath}{toggle_xpath}')),
        'label_text': snkm.TextConstants.PER_STATUSBAR_VISIBILITY,
        'options': Options.YES_NO
    }

    per_taskman_xpath = f'//input[@testname="{snkm.ElementNames.PER_TASK_MANAGER}"]'
    per_taskman = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, per_taskman_xpath),
                              label_text_locator=(By.XPATH, f'{per_taskman_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{per_taskman_xpath}{toggle_xpath}')),
        'label_text': snkm.TextConstants.PER_TASK_MANAGER,
        'options': Options.YES_NO
    }

    auto_time_xpath = f'//input[@testname="{snkm.ElementNames.AUTO_UPDATE_TIME}"]'
    auto_up_time = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auto_time_xpath),
                              label_text_locator=(By.XPATH, f'{auto_time_xpath}/parent::td/parent::tr/parent::tbody/parent::table/parent::td/div/label'),
                              toggle_locator=(By.XPATH, f'{auto_time_xpath}/parent::td/following-sibling::td/div[2]')),
        'label_text': snkm.TextConstants.AUTO_UPDATE_TIME,
    }

    def __init__(self, driver):

        self.use_custom_launcher['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.package_name),
                ]
            }
        ]

        self.use_mdm_client['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.enable_auto_update),
                    factory(driver).define_checkbox(self.enable_auto_update_time),
                    factory(driver).define_select(self.auto_up_time),
                ]
            }
        ]

        self.enable_kiosk['children'] = [
            {
                'supports_validation': True,
                'depends_on': "Yes",
                'elements': [
                    factory(driver).define_checkbox(self.use_default_home),
                    factory(driver).define_checkbox(self.use_custom_launcher),
                    factory(driver).define_checkbox(self.use_mdm_client),
                ]
            }
        ]

        self.elements = {
            snkm.TextConstants.HEADER: factory(driver).define_element(self.header),
            snkm.TextConstants.ENABLE_KIOSK: factory(driver).define_select(self.enable_kiosk),
            snkm.TextConstants.PER_MULTI_WIN: factory(driver).define_select(self.per_multi_win),
            snkm.TextConstants.PER_NAVBAR_VISIBILITY: factory(driver).define_select(self.per_navbar),
            snkm.TextConstants.PER_STATUSBAR_VISIBILITY: factory(driver).define_select(self.per_statusbar),
            snkm.TextConstants.PER_TASK_MANAGER: factory(driver).define_select(self.per_taskman),
        }
        super().__init__(driver, self.elements)
