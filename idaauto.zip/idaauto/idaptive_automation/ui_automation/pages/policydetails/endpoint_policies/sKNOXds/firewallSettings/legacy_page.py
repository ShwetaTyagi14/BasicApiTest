from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXDeviceSettingsFirewallLegacy as skdsfl
from idaptive_automation.ui_automation.constants import Xpaths


class LegacyPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsfl.ElementNames.HEADER}"]')),
              'inner_text': skdsfl.TextConstants.HEADER
    }

    ara_xpath = f'(//a[@buttontext="{skdsfl.ElementNames.ADD}"])[1]'
    allow_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ara_xpath)),
        'label_text': skdsfl.TextConstants.ADD
    }

    dra_xpath = f'(//a[@buttontext="{skdsfl.ElementNames.ADD}"])[2]'
    deny_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dra_xpath)),
        'label_text': skdsfl.TextConstants.ADD
    }

    pr_xpath = f'//input[@testname="{skdsfl.ElementNames.PROXY_RULES}"]'
    proxy_rules = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pr_xpath),
                              label_text_locator=(By.XPATH, f'{pr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pr_xpath}{toggle_xpath}')),
        'label_text': skdsfl.TextConstants.PROXY_RULES,
        'options': ['--', 'Yes']
    }

    ipa_xpath = f'//input[@testname="{skdsfl.ElementNames.IP_ADDRESS}"]'
    ip_address = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ipa_xpath),
                              label_text_locator=(By.XPATH, f'{ipa_xpath}/ancestor::table/following-sibling::label')),
        'label_text': skdsfl.TextConstants.IP_ADDRESS
    }

    po_xpath = f'//input[@testname="{skdsfl.ElementNames.PORT}"]'
    port = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, po_xpath),
                              label_text_locator=(By.XPATH, f'{po_xpath}/ancestor::table/following-sibling::label')),
        'label_text': skdsfl.TextConstants.PORT
    }

    rera_xpath = f'(//a[@buttontext="{skdsfl.ElementNames.ADD}"])[3]'
    redirect_exception_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rera_xpath)),
        'label_text': skdsfl.TextConstants.ADD
    }

    rra_xpath = f'(//a[@buttontext="{skdsfl.ElementNames.ADD}"])[4]'
    reroute_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rra_xpath)),
        'label_text': skdsfl.TextConstants.ADD
    }

    ton_xpath = f'//input[@testname="{skdsfl.ElementNames.TYPE_OF_NETWORK}"]'
    type_of_network = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ton_xpath),
                              label_text_locator=(By.XPATH, f'{ton_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ton_xpath}{toggle_xpath}')),
        'label_text': skdsfl.TextConstants.TYPE_OF_NETWORK,
        'options': ['--', 'Any connection', 'Wi-fi Only']
    }

    def __init__(self, driver):
        self.proxy_rules['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.ip_address),
                    factory(driver).define_text_input(self.port)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'allow_rules_add': factory(driver).define_modify_delete_grid(self.allow_rules_add),
            'deny_rules_add': factory(driver).define_modify_delete_grid(self.deny_rules_add),
            'proxy_rules': factory(driver).define_select(self.proxy_rules),
            'redirect_exception_rules_add': factory(driver).define_modify_delete_grid(self.redirect_exception_rules_add),
            'reroute_rules_add': factory(driver).define_modify_delete_grid(self.reroute_rules_add),
            'type_of_network': factory(driver).define_select(self.type_of_network),
        }
        super().__init__(driver, self.elements)
