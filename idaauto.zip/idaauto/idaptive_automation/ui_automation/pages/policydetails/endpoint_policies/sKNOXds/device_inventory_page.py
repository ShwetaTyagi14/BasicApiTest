from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsDeviceInventorySettings as skdsdis
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class DeviceInventoryPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsdis.ElementNames.HEADER}"]')),
        'inner_text': skdsdis.TextConstants.HEADER
    }

    elci_xpath = f'//input[@testname="{skdsdis.ElementNames.ENABLE_LOG_CALL_INFO}"]'
    enable_log_call_info = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, elci_xpath),
                              label_text_locator=(By.XPATH, f'{elci_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{elci_xpath}{toggle_xpath}')),
        'label_text': skdsdis.TextConstants.ENABLE_LOG_CALL_INFO,
        'options': Options.YES_NO
    }

    elcd_xpath = f'//input[@testname="{skdsdis.ElementNames.ENABLE_LOG_CELLULAR_DATA}"]'
    enable_log_cellular_data = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, elcd_xpath),
                              label_text_locator=(By.XPATH, f'{elcd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{elcd_xpath}{toggle_xpath}')),
        'label_text': skdsdis.TextConstants.ENABLE_LOG_CELLULAR_DATA,
        'options': Options.YES_NO
    }

    elw_xpath = f'//input[@testname="{skdsdis.ElementNames.ENABLE_LOG_WIFI}"]'
    enable_log_wifi = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, elw_xpath),
                              label_text_locator=(By.XPATH, f'{elw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{elw_xpath}{toggle_xpath}')),
        'label_text': skdsdis.TextConstants.ENABLE_LOG_WIFI,
        'options': Options.YES_NO
    }

    tbu_xpath = f'//input[@testname="{skdsdis.ElementNames.TIME_BETWEEN_UPDATES}"]'
    time_between_updates = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, elw_xpath),
                              label_text_locator=(By.XPATH, f'{tbu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{tbu_xpath}')),
        'label_text': skdsdis.TextConstants.TIME_BETWEEN_UPDATES,
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_log_call_info': factory(driver).define_select(self.enable_log_call_info),
            'enable_log_cellular_data': factory(driver).define_select(self.enable_log_cellular_data),
            'enable_log_wifi': factory(driver).define_select(self.enable_log_wifi),
            'time_between_updates': factory(driver).define_text_input(self.time_between_updates)
        }
        super().__init__(driver, self.elements)
