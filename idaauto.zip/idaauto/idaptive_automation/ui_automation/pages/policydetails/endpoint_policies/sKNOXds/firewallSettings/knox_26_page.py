from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamsungKNOXDeviceSettingsFirewallKnox as skdsfk
from idaptive_automation.ui_automation.constants import Xpaths


class Knox26Page(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsfk.ElementNames.HEADER}"]')),
              'inner_text': skdsfk.TextConstants.HEADER
              }

    ara_xpath = f'(//a[@buttontext="{skdsfk.ElementNames.ADD}"])[1]'
    allow_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ara_xpath)),
        'label_text': skdsfk.TextConstants.ADD
    }

    dra_xpath = f'(//a[@buttontext="{skdsfk.ElementNames.ADD}"])[2]'
    deny_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dra_xpath)),
        'label_text': skdsfk.TextConstants.ADD
    }

    dfra_xpath = f'(//a[@buttontext="{skdsfk.ElementNames.ADD}"])[3]'
    domain_filter_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dfra_xpath)),
        'label_text': skdsfk.TextConstants.ADD
    }

    rera_xpath = f'(//a[@buttontext="{skdsfk.ElementNames.ADD}"])[4]'
    redirect_exception_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rera_xpath)),
        'label_text': skdsfk.TextConstants.ADD
    }

    rra_xpath = f'(//a[@buttontext="{skdsfk.ElementNames.ADD}"])[5]'
    reroute_rules_add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rra_xpath)),
        'label_text': skdsfk.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'allow_rules_add': factory(driver).define_modify_delete_grid(self.allow_rules_add),
            'deny_rules_add': factory(driver).define_modify_delete_grid(self.deny_rules_add),
            'domain_filter_rules_add': factory(driver).define_modify_delete_grid(self.domain_filter_rules_add),
            'redirect_exception_rules_add': factory(driver).define_modify_delete_grid(self.redirect_exception_rules_add),
            'reroute_rules_add': factory(driver).define_modify_delete_grid(self.reroute_rules_add),
        }
        super().__init__(driver, self.elements)
