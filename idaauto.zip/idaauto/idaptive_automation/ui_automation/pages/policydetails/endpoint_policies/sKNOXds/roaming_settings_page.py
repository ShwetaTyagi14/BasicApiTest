from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsRoamingSettings as skdsrs


class RoamingSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsrs.ElementNames.HEADER}"]')),
        'inner_text': skdsrs.TextConstants.HEADER
    }
    erca_xpath = f'//input[@testname="{skdsrs.ElementNames.ROAMING_CELLULAR}"]'
    enable_roaming_cellular = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, erca_xpath),
                              label_text_locator=(By.XPATH, f'{erca_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{erca_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ROAMING_CELLULAR,
        'options': Options.YES_NO
    }
    ers_xpath = f'//input[@testname="{skdsrs.ElementNames.ROAMING_SYNC}"]'
    enable_roaming_sync = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ers_xpath),
                              label_text_locator=(By.XPATH, f'{ers_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ers_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ROAMING_SYNC,
        'options': Options.YES_NO
    }
    ervc_xpath = f'//input[@testname="{skdsrs.ElementNames.ROAMING_VOICE_CALL}"]'
    enable_roaming_voice_call = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ervc_xpath),
                              label_text_locator=(By.XPATH, f'{ervc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ervc_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ROAMING_VOICE_CALL,
        'options': Options.YES_NO
    }
    ervp_xpath = f'//input[@testname="{skdsrs.ElementNames.ROAMING_WAP}"]'
    enable_roaming_wap = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ervp_xpath),
                              label_text_locator=(By.XPATH, f'{ervp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ervp_xpath}{toggle_xpath}')),
        'label_text': skdsrs.TextConstants.ROAMING_WAP,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skdsrs.ElementNames.ROAMING_CELLULAR: factory(driver).define_select(self.enable_roaming_cellular),
            skdsrs.ElementNames.ROAMING_SYNC: factory(driver).define_select(self.enable_roaming_sync),
            skdsrs.ElementNames.ROAMING_VOICE_CALL: factory(driver).define_select(self.enable_roaming_voice_call),
            skdsrs.ElementNames.ROAMING_WAP: factory(driver).define_select(self.enable_roaming_wap)
        }
        super().__init__(driver, self.elements)
