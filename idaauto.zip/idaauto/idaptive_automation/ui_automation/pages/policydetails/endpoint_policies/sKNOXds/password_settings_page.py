from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsPasswordSettings as skdsps
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class PasswordSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsps.ElementNames.HEADER}"]')),
        'inner_text': skdsps.TextConstants.HEADER
    }
    epv_xpath = f'//input[@testname="{skdsps.ElementNames.PASSWORD_VISIBILITY}"]'
    password_visibility = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, epv_xpath),
                              label_text_locator=(By.XPATH, f'{epv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{epv_xpath}{toggle_xpath}')),
        'label_text': skdsps.TextConstants.PASSWORD_VISIBILITY,
        'options': Options.YES_NO
    }
    eslpv_xpath = f'//input[@testname="{skdsps.ElementNames.PATTERN_VISIBILITY}"]'
    pattern_visibility = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eslpv_xpath),
                              label_text_locator=(By.XPATH, f'{eslpv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eslpv_xpath}{toggle_xpath}')),
        'label_text': skdsps.TextConstants.PATTERN_VISIBILITY,
        'options': Options.YES_NO
    }
    elsfa_xpath = f'//input[@testname="{skdsps.ElementNames.FINGERPRINT_AUTHENTICATION}"]'
    fingerprint_authentication = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, elsfa_xpath),
                              label_text_locator=(By.XPATH, f'{elsfa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{elsfa_xpath}{toggle_xpath}')),
        'label_text': skdsps.TextConstants.FINGERPRINT_AUTHENTICATION,
        'options': Options.YES_NO
    }
    esfpw_xpath = f'//input[@testname="{skdsps.ElementNames.FAILED_PASSWORD_WIPE}"]'
    failed_password_wipe = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, esfpw_xpath),
                              label_text_locator=(By.XPATH, f'{esfpw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{esfpw_xpath}{toggle_xpath}')),
        'label_text': skdsps.TextConstants.FAILED_PASSWORD_WIPE,
        'options': Options.YES_NO
    }
    mpadd_xpath = f'//input[@testname="{skdsps.ElementNames.DEVICE_DISABLE}"]'
    device_disable = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mpadd_xpath),
                              label_text_locator=(By.XPATH, f'{mpadd_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.DEVICE_DISABLE
    }
    mnccp_xpath = f'//input[@testname="{skdsps.ElementNames.CHANGED_CHARACTER}"]'
    changed_character = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mnccp_xpath),
                              label_text_locator=(By.XPATH, f'{mnccp_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.CHANGED_CHARACTER
    }
    tpce_xpath = f'//input[@testname="{skdsps.ElementNames.PASSWORD_CHANGE}"]'
    password_change = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, tpce_xpath),
                              label_text_locator=(By.XPATH, f'{tpce_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.PASSWORD_CHANGE
    }
    add_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{skdsps.ElementNames.ADD}"]')),
        'label_text': skdsps.TextConstants.ADD
    }
    mcslp_xpath = f'//input[@testname="{skdsps.ElementNames.MAXIMUM_CHARACTER_SEQUENCE}"]'
    character_sequence = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mcslp_xpath),
                              label_text_locator=(By.XPATH, f'{mcslp_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.MAXIMUM_CHARACTER_SEQUENCE
    }
    mnslp_xpath = f'//input[@testname="{skdsps.ElementNames.MAXIMUM_NUMERIC_SEQUENCE}"]'
    numeric_sequence = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mnslp_xpath),
                              label_text_locator=(By.XPATH, f'{mnslp_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.MAXIMUM_NUMERIC_SEQUENCE
    }
    mocp_xpath = f'//input[@testname="{skdsps.ElementNames.MAXIMUM_OCCURANCE}"]'
    maximum_occurance = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mocp_xpath),
                              label_text_locator=(By.XPATH, f'{mocp_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.MAXIMUM_OCCURANCE
    }
    ppe_xpath = f'//input[@testname="{skdsps.ElementNames.PASSWORD_PATTERN}"]'
    password_pattern = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ppe_xpath),
                              label_text_locator=(By.XPATH, f'{ppe_xpath}{label_xpath}')),
        'label_text': skdsps.TextConstants.PASSWORD_PATTERN
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            skdsps.ElementNames.PASSWORD_VISIBILITY: factory(driver).define_select(self.password_visibility),
            skdsps.ElementNames.PATTERN_VISIBILITY: factory(driver).define_select(self.pattern_visibility),
            skdsps.ElementNames.FINGERPRINT_AUTHENTICATION: factory(driver).define_select(self.fingerprint_authentication),
            skdsps.ElementNames.FAILED_PASSWORD_WIPE: factory(driver).define_select(self.failed_password_wipe),
            skdsps.ElementNames.DEVICE_DISABLE: factory(driver).define_text_input(self.device_disable),
            skdsps.ElementNames.CHANGED_CHARACTER: factory(driver).define_text_input(self.changed_character),
            skdsps.ElementNames.PASSWORD_CHANGE: factory(driver).define_text_input(self.password_change),
            skdsps.ElementNames.ADD: factory(driver).define_modify_delete_grid(self.add_button),
            skdsps.ElementNames.MAXIMUM_CHARACTER_SEQUENCE: factory(driver).define_text_input(self.character_sequence),
            skdsps.ElementNames.MAXIMUM_NUMERIC_SEQUENCE: factory(driver).define_text_input(self.numeric_sequence),
            skdsps.ElementNames.MAXIMUM_OCCURANCE: factory(driver).define_text_input(self.maximum_occurance),
            skdsps.ElementNames.PASSWORD_PATTERN: factory(driver).define_text_input(self.password_pattern)
        }
        super().__init__(driver, self.elements)
