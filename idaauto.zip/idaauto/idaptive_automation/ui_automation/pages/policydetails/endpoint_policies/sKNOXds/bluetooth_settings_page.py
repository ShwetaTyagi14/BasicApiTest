from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import SamgKNOXDeviceSettingsBluetoothSettings as skdsbs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class BluetoothSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{skdsbs.ElementNames.HEADER}"]')),
        'inner_text': skdsbs.TextConstants.HEADER
    }
    ebdm_xpath = f'//input[@testname="{skdsbs.ElementNames.BLUETOOTH_MODE}"]'
    bluetooth_mode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ebdm_xpath),
                              label_text_locator=(By.XPATH, f'{ebdm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ebdm_xpath}{toggle_xpath}')),
        'label_text': skdsbs.TextConstants.BLUETOOTH_MODE,
        'options': Options.YES_NO
    }
    eldm_xpath = f'//input[@testname="{skdsbs.ElementNames.LIMITED_MODE}"]'
    limited_mode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eldm_xpath),
                              label_text_locator=(By.XPATH, f'{eldm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eldm_xpath}{toggle_xpath}')),
        'label_text': skdsbs.TextConstants.LIMITED_MODE,
        'options': Options.YES_NO
    }
    pdtvb_xpath = f'//input[@testname="{skdsbs.ElementNames.DATA_TRANSFER}"]'
    data_transfer = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pdtvb_xpath),
                              label_text_locator=(By.XPATH, f'{pdtvb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pdtvb_xpath}{toggle_xpath}')),
        'label_text': skdsbs.TextConstants.DATA_TRANSFER,
        'options': Options.YES_NO
    }
    pdcvb_xpath = f'//input[@testname="{skdsbs.ElementNames.DESKTOP_CONNECTION}"]'
    desktop_connection = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pdcvb_xpath),
                              label_text_locator=(By.XPATH, f'{pdcvb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pdcvb_xpath}{toggle_xpath}')),
        'label_text': skdsbs.TextConstants.DESKTOP_CONNECTION,
        'options': Options.YES_NO
    }
    pocvb_xpath = f'//input[@testname="{skdsbs.ElementNames.OUTGOING_CALLS}"]'
    outgoing_calls = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pocvb_xpath),
                              label_text_locator=(By.XPATH, f'{pocvb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pocvb_xpath}{toggle_xpath}')),
        'label_text': skdsbs.TextConstants.OUTGOING_CALLS,
        'options': Options.YES_NO
    }
    ppwob_xpath = f'//input[@testname="{skdsbs.ElementNames.PAIRING_STATE}"]'
    pairing_state = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ppwob_xpath),
                              label_text_locator=(By.XPATH, f'{ppwob_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ppwob_xpath}{toggle_xpath}')),
        'label_text': skdsbs.TextConstants.PAIRING_STATE,
        'options': Options.YES_NO
    }
    add_button1 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{skdsbs.ElementNames.ADD}"])[1]')),
        'label_text': skdsbs.TextConstants.ADD
    }
    add_button2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{skdsbs.ElementNames.ADD}"])[2]')),
        'label_text': skdsbs.TextConstants.ADD
    }
    add_button3 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{skdsbs.ElementNames.ADD}"])[3]')),
        'label_text': skdsbs.TextConstants.ADD
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'add_button1': factory(driver).define_modify_delete_grid(self.add_button1),
            skdsbs.ElementNames.BLUETOOTH_MODE: factory(driver).define_select(self.bluetooth_mode),
            skdsbs.ElementNames.LIMITED_MODE: factory(driver).define_select(self.limited_mode),
            'add_button2': factory(driver).define_modify_delete_grid(self.add_button2),
            skdsbs.ElementNames.DATA_TRANSFER: factory(driver).define_select(self.data_transfer),
            skdsbs.ElementNames.DESKTOP_CONNECTION: factory(driver).define_select(self.desktop_connection),
            skdsbs.ElementNames.OUTGOING_CALLS: factory(driver).define_select(self.outgoing_calls),
            skdsbs.ElementNames.PAIRING_STATE: factory(driver).define_select(self.pairing_state),
            'add_button3': factory(driver).define_modify_delete_grid(self.add_button3)
        }
        super().__init__(driver, self.elements)
