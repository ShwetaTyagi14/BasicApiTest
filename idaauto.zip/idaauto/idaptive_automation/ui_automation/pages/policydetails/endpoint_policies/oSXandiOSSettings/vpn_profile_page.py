from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class VpnProfilePage(UIPage):
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="VPN Profile"]'))
                        }

    connection_name = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="UserDefinedName"]'),
                                         label_text_locator=(By.XPATH, '//input[@testname="UserDefinedName"]/preceding-sibling::div/label'))}

    server = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, '//input[@testname="CommRemoteAddress"]'),
                                label_text_locator=(By.XPATH, '//input[@testname="CommRemoteAddress"]/preceding-sibling::div/label'))}

    whole_device = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//label[text()="VPN is for whole device"]/preceding-sibling::input'),
                label_text_locator=(By.XPATH, f'//label[text()="VPN is for whole device"]'),
                parent_container_locator=(
                    By.XPATH, f'//table[1][tbody/tr/td/div[2]/label[text()="VPN is for whole device"]]')),
        'label_text': 'VPN is for whole device',
        'checked': True,
    }
    selected_only = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//label[text()="VPN is for selected applications only"]/preceding-sibling::input'),
                label_text_locator=(By.XPATH, f'//label[text()="VPN is for selected applications only"]'),
                parent_container_locator=(By.XPATH, f'//table[2][tbody/tr/td/div[2]/label[text()="VPN is for selected applications only"]]')),
        'label_text': 'VPN is for selected applications only',
        'checked': False
    }
    vpn_type = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="VpnType"]'),
                              label_text_locator=(By.XPATH,f'//input[@testname="VpnType"]//ancestor::table[contains(@class,"table-plain")]//label'),
                              toggle_locator=(By.XPATH, f'//input[@testname="VpnType"]/ancestor::td/following-sibling::td/div')),
        'label_text': 'Enable authentication policy controls',
        'options': ['PPTP', 'IPSEC (Cisco)', 'Third Party VPN', 'IKEv2']
    }
    vpn_on_demand = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//label[text()="VPN on demand"]/preceding-sibling::input'),
                label_text_locator=(By.XPATH, f'//label[text()="VPN on demand"]'),
                parent_container_locator=(By.XPATH, f'//label[text()="VPN on demand"]/parent::div')),
        'label_text': 'VPN on demand',
        'checked': False
    }

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'connection_name': factory(driver).define_text_input(self.connection_name),
            'server': factory(driver).define_text_input(self.server),
            'whole_device': factory(driver).define_checkbox(self.whole_device),
            'selected_only': factory(driver).define_checkbox(self.selected_only),
            'vpn_type': factory(driver).define_select(self.vpn_type),
            'vpn_on_demand': factory(driver).define_checkbox(self.vpn_on_demand),
            'add_button': factory(driver).define_element(self.add_button)
        }
        super().__init__(driver, self.elements)

    def select_vpn_type(self, value):
        if value not in self.vpn_type['options']:
            raise Exception(f'Option: {value} not found in options: {self.vpn_type["options"]}')
        self.elements['vpn_type'].select_option(value)

    def select_vpn_on_demand(self):
        self.elements['vpn_on_demand'].wait_for_visible()
        self.elements['vpn_on_demand'].check()