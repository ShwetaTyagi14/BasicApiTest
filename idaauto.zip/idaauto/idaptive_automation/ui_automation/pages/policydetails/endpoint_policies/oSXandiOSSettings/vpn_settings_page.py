from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import OSXIOSSettingsVPNSettings as oisvs
from idaptive_automation.ui_automation.constants import CommonButtons

class VPNSettingsPage(UIPage):
    header = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{oisvs.ElementNames.HEADER}"]')),
              'inner_text': oisvs.TextConstants.HEADER
              }
    add_button = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,f'//span[text()="{CommonButtons.ElementNames.ADD}"]')),
              'inner_text': CommonButtons.TextConstants.ADD
                }

    def __init__(self, driver):
        self.elements = {
            CommonButtons.ElementNames.ADD:factory(driver).define_modify_delete_grid(self.add_button)
                        }
        super().__init__(driver, self.elements)