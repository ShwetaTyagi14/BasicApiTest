from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import IosSettingsKioskMode as ikm


class KioskModePage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{ikm.ElementNames.HEADER}"]')),
        'inner_text': ikm.TextConstants.HEADER
    }
    ekm_xpath = f'//input[@testname="{ikm.ElementNames.KIOSK_MODE}"]'
    enable_kiosk_mode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ekm_xpath),
                              label_text_locator=(By.XPATH, f'{ekm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ekm_xpath}{toggle_xpath}')),
        'label_text': ikm.TextConstants.KIOSK_MODE,
        'options': Options.YES_NO
    }
    use_mdm_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{ikm.TextConstants.USE_MDM}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{ikm.TextConstants.USE_MDM}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="{ikm.TextConstants.USE_MDM}"]]')),
        'label_text': ikm.TextConstants.USE_MDM,
            'checked': True,
    }
    use_built_in_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{ikm.TextConstants.USE_BUILT_IN}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{ikm.TextConstants.USE_BUILT_IN}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="{ikm.TextConstants.USE_BUILT_IN}"]]')),
            'label_text': ikm.TextConstants.USE_BUILT_IN,
            'checked': False,
    }
    use_custom_button = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//label[normalize-space(.)="{ikm.TextConstants.USE_CUSTOM}"]/preceding-sibling::input'),
                              label_text_locator=(By.XPATH, f'//label[normalize-space(.)="{ikm.TextConstants.USE_CUSTOM}"]'),
                              parent_container_locator=(By.XPATH, f'//table[tbody/tr/td[2]/div/label[normalize-space(.)="{ikm.TextConstants.USE_CUSTOM}"]]')),
            'label_text': ikm.TextConstants.USE_CUSTOM,
            'checked': False,
    }
    sba_xpath = f'//input[@testname="{ikm.ElementNames.BUILT_IN}"]'
    select_built_in = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sba_xpath),
                              label_text_locator=(By.XPATH, f'{sba_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{sba_xpath}{toggle_xpath}')),
        'label_text': ikm.TextConstants.BUILT_IN,
        'options': ['', 'Calendar', 'Contacts', 'Mail', 'Maps', 'Messages', 'Music', 'Safari', 'Videos']
    }
    abi_xpath = f'//input[@testname="{ikm.ElementNames.BUNDLE_IDENTIFIER}"]'
    bundle_identifier = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, abi_xpath),
                              label_text_locator=(By.XPATH, f'{abi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{abi_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.BUNDLE_IDENTIFIER
    }
    dt_xpath = f'//input[@testname="{ikm.ElementNames.DISABLE_TOUCH}"]'
    disable_touch = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dt_xpath),
                              label_text_locator=(By.XPATH, f'{dt_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dt_xpath}{toggle_xpath}')),
        'label_text': ikm.TextConstants.DISABLE_TOUCH,
        'options': Options.YES_NO
    }
    dd_xpath = f'//input[@testname="{ikm.ElementNames.DISABLE_DEVICE}"]'
    disable_device = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dt_xpath),
                              label_text_locator=(By.XPATH, f'{dd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dd_xpath}{toggle_xpath}')),
        'label_text': ikm.TextConstants.DISABLE_DEVICE,
        'options': Options.YES_NO
    }
    dv_xpath = f'//input[@testname="{ikm.ElementNames.DISABLE_VOLUME}"]'
    disable_volume = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dv_xpath),
                              label_text_locator=(By.XPATH, f'{dv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dv_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.DISABLE_VOLUME,
            'options': Options.YES_NO
    }
    dss_xpath = f'//input[@testname="{ikm.ElementNames.DISABLE_SIDE}"]'
    disable_side = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dss_xpath),
                              label_text_locator=(By.XPATH, f'{dss_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dss_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.DISABLE_SIDE,
            'options': Options.YES_NO
    }
    dsw_xpath = f'//input[@testname="{ikm.ElementNames.DISABLE_SLEEP}"]'
    disable_sleep_wake = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dsw_xpath),
                              label_text_locator=(By.XPATH, f'{dsw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dsw_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.DISABLE_SLEEP,
            'options': Options.YES_NO
    }
    dal_xpath = f'//input[@testname="{ikm.ElementNames.DISABLE_AUTO}"]'
    disable_auto_lock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dal_xpath),
                              label_text_locator=(By.XPATH, f'{dal_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{dal_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.DISABLE_AUTO,
            'options': Options.YES_NO
    }
    evo_xpath = f'//input[@testname="{ikm.ElementNames.ENABLE_VOICE_OVER}"]'
    enable_voice_over = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, evo_xpath),
                              label_text_locator=(By.XPATH, f'{evo_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{evo_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ENABLE_VOICE_OVER,
            'options': Options.YES_NO
    }
    ez_xpath = f'//input[@testname="{ikm.ElementNames.ENABLE_ZOOM}"]'
    enable_zoom = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ez_xpath),
                              label_text_locator=(By.XPATH, f'{ez_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ez_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ENABLE_ZOOM,
            'options': Options.YES_NO
    }
    eic_xpath = f'//input[@testname="{ikm.ElementNames.ENABLE_INVERT_COLORS}"]'
    enable_invert_color = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eic_xpath),
                              label_text_locator=(By.XPATH, f'{eic_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eic_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ENABLE_INVERT_COLORS,
            'options': Options.YES_NO
    }
    eat_xpath = f'//input[@testname="{ikm.ElementNames.ENABLE_ASSISTIVE_TOUCH}"]'
    enable_assistive_touch = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eat_xpath),
                              label_text_locator=(By.XPATH, f'{eat_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eat_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ENABLE_ASSISTIVE_TOUCH,
            'options': Options.YES_NO
    }
    esc_xpath = f'//input[@testname="{ikm.ElementNames.ENABLE_SPEAK_SELECTION}"]'
    enable_speak_selection = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, esc_xpath),
                              label_text_locator=(By.XPATH, f'{esc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{esc_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ENABLE_SPEAK_SELECTION,
            'options': Options.YES_NO
    }
    ema_xpath = f'//input[@testname="{ikm.ElementNames.ENABLE_MONO_AUDIO}"]'
    enable_mono_audio = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ema_xpath),
                              label_text_locator=(By.XPATH, f'{ema_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ema_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ENABLE_MONO_AUDIO,
            'options': Options.YES_NO
    }
    aucvs_xpath = f'//input[@testname="{ikm.ElementNames.VOICE_OVER_SETTING}"]'
    voice_over_setting = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aucvs_xpath),
                              label_text_locator=(By.XPATH, f'{aucvs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aucvs_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.VOICE_OVER_SETTING,
            'options': Options.YES_NO
    }
    auczs_xpath = f'//input[@testname="{ikm.ElementNames.ZOOM_SETTING}"]'
    zoom_setting = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auczs_xpath),
                              label_text_locator=(By.XPATH, f'{auczs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{auczs_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ZOOM_SETTING,
            'options': Options.YES_NO
    }
    aucics_xpath = f'//input[@testname="{ikm.ElementNames.INVERT_COLOR_SETTING}"]'
    invert_color_setting = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aucics_xpath),
                              label_text_locator=(By.XPATH, f'{aucics_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aucics_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.INVERT_COLOR_SETTING,
            'options': Options.YES_NO
    }
    aucats_xpath = f'//input[@testname="{ikm.ElementNames.ASSISTIVE_TOUCH_SETTING}"]'
    assistive_touch_setting = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aucats_xpath),
                              label_text_locator=(By.XPATH, f'{aucats_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aucats_xpath}{toggle_xpath}')),
            'label_text': ikm.TextConstants.ASSISTIVE_TOUCH_SETTING,
            'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.use_built_in_button['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.select_built_in)
                ]
            }
        ]
        self.use_custom_button['children'] = [
            {
                'supports_validation': True,
                'elements': [

                    factory(driver).define_text_input(self.bundle_identifier),
                ]
            }
        ]
        self.enable_kiosk_mode['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.use_mdm_button),
                    factory(driver).define_checkbox(self.use_built_in_button),
                    factory(driver).define_checkbox(self.use_custom_button),
                    factory(driver).define_select(self.disable_touch),
                    factory(driver).define_select(self.disable_device),
                    factory(driver).define_select(self.disable_volume),
                    factory(driver).define_select(self.disable_side),
                    factory(driver).define_select(self.disable_sleep_wake),
                    factory(driver).define_select(self.disable_auto_lock),
                    factory(driver).define_select(self.enable_voice_over),
                    factory(driver).define_select(self.enable_zoom),
                    factory(driver).define_select(self.enable_invert_color),
                    factory(driver).define_select(self.enable_assistive_touch),
                    factory(driver).define_select(self.enable_speak_selection),
                    factory(driver).define_select(self.enable_mono_audio),
                    factory(driver).define_select(self.voice_over_setting),
                    factory(driver).define_select(self.zoom_setting),
                    factory(driver).define_select(self.invert_color_setting),
                    factory(driver).define_select(self.assistive_touch_setting)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            ikm.ElementNames.KIOSK_MODE: factory(driver).define_select(self.enable_kiosk_mode)
        }
        super().__init__(driver, self.elements)
