from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import IosSettingsApplicationManagementSettings as isams


class AppManagementPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{isams.ElementNames.HEADER}"]')),
        'inner_text': isams.TextConstants.HEADER
    }
    npuia_xpath = f'//input[@testname="{isams.ElementNames.PROMPT_USER}"]'
    number_times_prompt_user = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, npuia_xpath),
                              label_text_locator=(By.XPATH, f'{npuia_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{npuia_xpath}{toggle_xpath}')),
        'label_text': isams.TextConstants.PROMPT_USER,
        'options': Options.APPLICATION_MANAGEMENT_SETTINGS
    }
    pcaed_xpath = f'//input[@testname="{isams.ElementNames.PUSH_COMPANY_APPS}"]'
    push_company_apps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pcaed_xpath),
                              label_text_locator=(By.XPATH, f'{pcaed_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pcaed_xpath}{toggle_xpath}')),
        'label_text': isams.TextConstants.PUSH_COMPANY_APPS,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            isams.ElementNames.PROMPT_USER: factory(driver).define_select(self.number_times_prompt_user),
            isams.ElementNames.PUSH_COMPANY_APPS: factory(driver).define_select(self.push_company_apps)
        }
        super().__init__(driver, self.elements)
