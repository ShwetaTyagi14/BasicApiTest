from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options
from idaptive_automation.ui_automation.constants import IosSettingsGlobalHttpProxy as ighp


class GlobalHttpProxyPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{ighp.ElementNames.HEADER}"]')),
        'inner_text': ighp.TextConstants.HEADER
    }
    eghp_xpath = f'//input[@testname="{ighp.ElementNames.GLOBAL_HTTP_PROXY}"]'
    enable_global_http_proxy = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eghp_xpath),
                              label_text_locator=(By.XPATH, f'{eghp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eghp_xpath}{toggle_xpath}')),
        'label_text': ighp.TextConstants.GLOBAL_HTTP_PROXY,
        'options': Options.YES_NO
    }
    pt_xpath = f'//input[@testname="{ighp.ElementNames.PROXY_TYPE}"]'
    proxy_type = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pt_xpath),
                              label_text_locator=(By.XPATH, f'{pt_xpath}/ancestor::tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{pt_xpath}/parent::td/following-sibling::td')),
        'label_text': ighp.TextConstants.PROXY_TYPE,
        'options': ['Manual', 'Auto']
    }
    ps_xpath = f'//input[@testname="{ighp.ElementNames.PROXY_SERVER}"]'
    proxy_server = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ps_xpath),
                              label_text_locator=(By.XPATH, f'{ps_xpath}/ancestor::tbody/parent::table/parent::div/div'),
                              toggle_locator=(By.XPATH, f'{ps_xpath}{toggle_xpath}')),
        'label_text': ighp.TextConstants.PROXY_SERVER
    }
    prt_xpath = f'//input[@testname="{ighp.ElementNames.PORT}"]'
    port = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, prt_xpath),
                              label_text_locator=(By.XPATH, f'{prt_xpath}/ancestor::tbody/parent::table/parent::div/div'),
                              toggle_locator=(By.XPATH, f'{prt_xpath}{toggle_xpath}')),
        'label_text': ighp.TextConstants.PORT
    }
    unm_xpath = f'//input[@testname="{ighp.ElementNames.USERNAME}"]'
    user_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, unm_xpath),
                              label_text_locator=(By.XPATH, f'{unm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{unm_xpath}{toggle_xpath}')),
        'label_text': ighp.TextConstants.USERNAME
    }
    pwd_xpath = f'//input[@testname="{ighp.ElementNames.PASSWORD}"]'
    password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pwd_xpath),
                              label_text_locator=(By.XPATH, f'{pwd_xpath}/ancestor::table/parent::div/div'),
                              toggle_locator=(By.XPATH, f'{pwd_xpath}{toggle_xpath}')),
        'label_text': ighp.TextConstants.PASSWORD
    }
    ppu_xpath = f'//input[@testname="{ighp.ElementNames.PROXY_PAC}"]'
    proxy_pac_url = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ppu_xpath),
                              label_text_locator=(By.XPATH, f'{ppu_xpath}/ancestor::table/parent::div/div'),
                              toggle_locator=(By.XPATH, f'{ppu_xpath}{toggle_xpath}')),
        'label_text': ighp.TextConstants.PROXY_PAC
    }
    adcp_xpath = f'//input[@testname="{ighp.ElementNames.ALLOW_DIRECT_CONNECTION}"]'
    allow_direct_connection = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adcp_xpath),
                              label_text_locator=(By.XPATH, f'{adcp_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{adcp_xpath}/ancestor::table')),
        'label_text': ighp.TextConstants.ALLOW_DIRECT_CONNECTION,
        'checked': True
    }
    abpa_xpath = f'//input[@testname="{ighp.ElementNames.ALLOW_BYPASS_PROXY}"]'
    allow_bypassing_proxy = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, abpa_xpath),
                              label_text_locator=(By.XPATH, f'{abpa_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{abpa_xpath}/ancestor::table')),
        'label_text': ighp.TextConstants.ALLOW_BYPASS_PROXY,
        'checked': False
    }

    def __init__(self, driver):
        self.proxy_type['children'] = [
            {
                'depends_on': 'Auto',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.proxy_pac_url),
                    factory(driver).define_checkbox(self.allow_direct_connection),
                    factory(driver).define_checkbox(self.allow_bypassing_proxy)
                ]
            },
            {
                'depends_on': 'Manual',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.proxy_server),
                    factory(driver).define_text_input(self.port),
                    factory(driver).define_text_input(self.user_name),
                    factory(driver).define_text_input(self.password),
                    factory(driver).define_checkbox(self.allow_bypassing_proxy)

                ]
            }
        ]
        self.enable_global_http_proxy['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.proxy_type),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            ighp.ElementNames.GLOBAL_HTTP_PROXY: factory(driver).define_select(self.enable_global_http_proxy)
        }
        super().__init__(driver, self.elements)


