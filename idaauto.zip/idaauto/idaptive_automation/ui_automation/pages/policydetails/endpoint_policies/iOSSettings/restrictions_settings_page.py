from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import IosSettingsRestrictionsSetings as isrs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictionsSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{isrs.ElementNames.HEADER}"]')),
        'inner_text': isrs.TextConstants.HEADER
    }
    alr_xpath = f'//input[@testname="{isrs.ElementNames.APP_LIST_MODE}"]'
    app_launch_mode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, alr_xpath),
                              label_text_locator=(By.XPATH, f'{alr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{alr_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.APP_LIST_MODE,
        'options': ['--', 'Allowed', 'Disallowed']
    }
    febs_xpath = f'//input[@testname="{isrs.ElementNames.ENCRYPTED_BACKUPS}"]'
    encrypted_backups = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, febs_xpath),
                              label_text_locator=(By.XPATH, f'{febs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{febs_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ENCRYPTED_BACKUPS,
        'options': Options.YES_NO
    }
    fisp_xpath = f'//input[@testname="{isrs.ElementNames.STORE_PASSWORD}"]'
    store_password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, fisp_xpath),
                              label_text_locator=(By.XPATH, f'{fisp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{fisp_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.STORE_PASSWORD,
        'options': Options.YES_NO
    }
    flat_xpath = f'//input[@testname="{isrs.ElementNames.AD_TRACKING}"]'
    ad_tracking = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, flat_xpath),
                              label_text_locator=(By.XPATH, f'{flat_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{flat_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.AD_TRACKING,
        'options': Options.YES_NO
    }
    fspf_xpath = f'//input[@testname="{isrs.ElementNames.PROFANITY_FILTER}"]'
    profanity_filter = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, fspf_xpath),
                              label_text_locator=(By.XPATH, f'{fspf_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{fspf_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.PROFANITY_FILTER,
        'options': Options.YES_NO
    }
    patad_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_AIRDROP}"]'
    allow_airdrop = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, patad_xpath),
                              label_text_locator=(By.XPATH, f'{patad_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{patad_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_AIRDROP,
        'options': Options.YES_NO
    }
    paemi_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_BOOKSTORE_EROTICA}"]'
    bookstore_erotica = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, paemi_xpath),
                              label_text_locator=(By.XPATH, f'{paemi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{paemi_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_BOOKSTORE_EROTICA,
        'options': Options.YES_NO
    }
    pagc_xpath = f'//input[@testname="{isrs.ElementNames.GAME_CENTER}"]'
    game_center = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pagc_xpath),
                              label_text_locator=(By.XPATH, f'{pagc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pagc_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.GAME_CENTER,
        'options': Options.YES_NO
    }
    paibs_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_BOOKSTORE}"]'
    allow_bookstore = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, paibs_xpath),
                              label_text_locator=(By.XPATH, f'{paibs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{paibs_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_BOOKSTORE,
        'options': Options.YES_NO
    }
    pasps_xpath = f'//input[@testname="{isrs.ElementNames.SHARED_STREAM}"]'
    shared_stream = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pasps_xpath),
                              label_text_locator=(By.XPATH, f'{pasps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pasps_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.SHARED_STREAM,
        'options': Options.YES_NO
    }
    pam_xpath = f'//input[@testname="{isrs.ElementNames.ACCOUNT_MODIFICATION}"]'
    account_modification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pam_xpath),
                              label_text_locator=(By.XPATH, f'{pam_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pam_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ACCOUNT_MODIFICATION,
        'options': Options.YES_NO
    }
    pagcf_xpath = f'//input[@testname="{isrs.ElementNames.ADDING_GAME_CENTER}"]'
    add_game_center = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pagcf_xpath),
                              label_text_locator=(By.XPATH, f'{pagcf_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pagcf_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ADDING_GAME_CENTER,
        'options': Options.YES_NO
    }
    paudt_xpath = f'//input[@testname="{isrs.ElementNames.AIRDROP_UNMANAGED}"]'
    airdrop_unmanaged = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, paudt_xpath),
                              label_text_locator=(By.XPATH, f'{paudt_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{paudt_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.AIRDROP_UNMANAGED,
        'options': Options.YES_NO
    }
    pacdm_xpath = f'//input[@testname="{isrs.ElementNames.DATA_MODIFICATION}"]'
    data_modification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pacdm_xpath),
                              label_text_locator=(By.XPATH, f'{pacdm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pacdm_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.DATA_MODIFICATION,
        'options': Options.YES_NO
    }
    paad_xpath = f'//input[@testname="{isrs.ElementNames.APP_DOWNLOADS}"]'
    app_downloads = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, paad_xpath),
                              label_text_locator=(By.XPATH, f'{paad_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{paad_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.APP_DOWNLOADS,
        'options': Options.YES_NO
    }
    padrs_xpath = f'//input[@testname="{isrs.ElementNames.DIAGNOSTIC_SUBMISSION}"]'
    diagnostic_submission = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, padrs_xpath),
                              label_text_locator=(By.XPATH, f'{padrs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{padrs_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.DIAGNOSTIC_SUBMISSION,
        'options': Options.YES_NO
    }
    paswr_xpath = f'//input[@testname="{isrs.ElementNames.SYNC_ROAMING}"]'
    sync_roaming = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, paswr_xpath),
                              label_text_locator=(By.XPATH, f'{paswr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{paswr_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.SYNC_ROAMING,
        'options': Options.YES_NO
    }
    pcplu_xpath = f'//input[@testname="{isrs.ElementNames.PHOTO_LIBRARY}"]'
    photo_library = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pcplu_xpath),
                              label_text_locator=(By.XPATH, f'{pcplu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pcplu_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.PHOTO_LIBRARY,
        'options': Options.YES_NO
    }
    pdnm_xpath = f'//input[@testname="{isrs.ElementNames.NAME_MODIFICATION}"]'
    name_modification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pdnm_xpath),
                              label_text_locator=(By.XPATH, f'{pdnm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pdnm_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.NAME_MODIFICATION,
        'options': Options.YES_NO
    }
    pdswnls_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_LOCK_SCREEN}"]'
    allow_lock_screen = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pdswnls_xpath),
                              label_text_locator=(By.XPATH, f'{pdswnls_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pdswnls_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_LOCKS_SCREEN,
        'options': Options.YES_NO
    }
    peat_xpath = f'//input[@testname="{isrs.ElementNames.APP_TRUST}"]'
    app_trust = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, peat_xpath),
                              label_text_locator=(By.XPATH, f'{peat_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{peat_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.APP_TRUST,
        'options': Options.YES_NO
    }
    pemp_xpath = f'//input[@testname="{isrs.ElementNames.EXPLICIT_CONTENT}"]'
    explicit_content = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pemp_xpath),
                              label_text_locator=(By.XPATH, f'{pemp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pemp_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.EXPLICIT_CONTENT,
        'options': Options.YES_NO
    }
    pfmsm_xpath = f'//input[@testname="{isrs.ElementNames.FRIENDS_MODIFICATION}"]'
    friends_modification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pfmsm_xpath),
                              label_text_locator=(By.XPATH, f'{pfmsm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pfmsm_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.FRIENDS_MODIFICATION,
        'options': Options.YES_NO
    }
    picb_xpath = f'//input[@testname="{isrs.ElementNames.CLOUD_BACKUP}"]'
    cloud_backup = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, picb_xpath),
                              label_text_locator=(By.XPATH, f'{picb_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{picb_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.CLOUD_BACKUP,
        'options': Options.YES_NO
    }
    pids_xpath = f'//input[@testname="{isrs.ElementNames.CLOUD_DOCUMENT}"]'
    cloud_document = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pids_xpath),
                              label_text_locator=(By.XPATH, f'{pids_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pids_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.CLOUD_DOCUMENT,
        'options': Options.YES_NO
    }
    piks_xpath = f'//input[@testname="{isrs.ElementNames.CLOUD_KEYCHAIN}"]'
    cloud_keychain = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, piks_xpath),
                              label_text_locator=(By.XPATH, f'{piks_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{piks_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.CLOUD_KEYCHAIN,
        'options': Options.YES_NO
    }
    pims_xpath = f'//input[@testname="{isrs.ElementNames.MESSAGE}"]'
    message = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pims_xpath),
                              label_text_locator=(By.XPATH, f'{pims_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pims_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.MESSAGE,
        'options': Options.YES_NO
    }
    piap_xpath = f'//input[@testname="{isrs.ElementNames.APP_PURCHASES}"]'
    app_purchases = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, piap_xpath),
                              label_text_locator=(By.XPATH, f'{piap_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{piap_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.APP_PURCHASES,
        'options': Options.YES_NO
    }
    pia_xpath = f'//input[@testname="{isrs.ElementNames.APP_INSTALLATION}"]'
    app_installation = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pia_xpath),
                              label_text_locator=(By.XPATH, f'{pia_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pia_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.APP_INSTALLATION,
        'options': Options.YES_NO
    }
    pitmsu_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_TUNES}"]'
    allow_tunes = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pitmsu_xpath),
                              label_text_locator=(By.XPATH, f'{pitmsu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pitmsu_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_TUNES,
        'options': Options.YES_NO
    }
    pksu_xpath = f'//input[@testname="{isrs.ElementNames.KEYBOARD_SHORTCUTS}"]'
    keyboard_shortcuts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pksu_xpath),
                              label_text_locator=(By.XPATH, f'{pksu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pksu_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.KEYBOARD_SHORTCUTS,
        'options': Options.YES_NO
    }
    plscc_xpath = f'//input[@testname="{isrs.ElementNames.CONTROL_CENTER}"]'
    control_center = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, plscc_xpath),
                              label_text_locator=(By.XPATH, f'{plscc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{plscc_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.CONTROL_CENTER,
        'options': Options.YES_NO
    }
    plsnv_xpath = f'//input[@testname="{isrs.ElementNames.NOTIFICATION_VIEW}"]'
    notification_view = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, plsnv_xpath),
                              label_text_locator=(By.XPATH, f'{plsnv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{plsnv_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.NOTIFICATION_VIEW,
        'options': Options.YES_NO
    }
    plstv_xpath = f'//input[@testname="{isrs.ElementNames.TODAY_VIEW}"]'
    today_view = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, plstv_xpath),
                              label_text_locator=(By.XPATH, f'{plstv_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{plstv_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.TODAY_VIEW,
        'options': Options.YES_NO
    }
    pmcfi_xpath = f'//input[@testname="{isrs.ElementNames.CONFIGURATION_FILE}"]'
    configuration_file = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pmcfi_xpath),
                              label_text_locator=(By.XPATH, f'{pmcfi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pmcfi_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.CONFIGURATION_FILE,
        'options': Options.YES_NO
    }
    pmg_xpath = f'//input[@testname="{isrs.ElementNames.MULTIPLAYER_GAMING}"]'
    multiplayer_gaming = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pmg_xpath),
                              label_text_locator=(By.XPATH, f'{pmg_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pmg_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.MULTIPLAYER_GAMING,
        'options': Options.YES_NO
    }
    pmdu_xpath = f'//input[@testname="{isrs.ElementNames.MANAGED_UNMANAGED}"]'
    managed_unmanaged = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pmdu_xpath),
                              label_text_locator=(By.XPATH, f'{pmdu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pmdu_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.MANAGED_UNMANAGED,
        'options': Options.YES_NO
    }
    pudm_xpath = f'//input[@testname="{isrs.ElementNames.UNMANAGED_MANAGED}"]'
    unmanaged_managed = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pudm_xpath),
                              label_text_locator=(By.XPATH, f'{pudm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pudm_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.UNMANAGED_MANAGED,
        'options': Options.YES_NO
    }
    ppnch_xpath = f'//input[@testname="{isrs.ElementNames.HOST_PAIRING}"]'
    host_pairing = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ppnch_xpath),
                              label_text_locator=(By.XPATH, f'{ppnch_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ppnch_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.HOST_PAIRING,
        'options': Options.YES_NO
    }
    ppm_xpath = f'//input[@testname="{isrs.ElementNames.PASSCODE_MODIFICATION}"]'
    passcode_modification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ppm_xpath),
                              label_text_locator=(By.XPATH, f'{ppm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ppm_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.PASSCODE_MODIFICATION,
        'options': Options.YES_NO
    }
    pps_xpath = f'//input[@testname="{isrs.ElementNames.PHOTO_STREAM}"]'
    photo_stream = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pps_xpath),
                              label_text_locator=(By.XPATH, f'{pps_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pps_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.PHOTO_STREAM,
        'options': Options.YES_NO
    }
    pra_xpath = f'//input[@testname="{isrs.ElementNames.APP_REMOVAL}"]'
    app_removal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pra_xpath),
                              label_text_locator=(By.XPATH, f'{pra_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pra_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.APP_REMOVAL,
        'options': Options.YES_NO
    }
    psu_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_SAFARI}"]'
    allow_safari = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, psu_xpath),
                              label_text_locator=(By.XPATH, f'{psu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{psu_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_SAFARI,
        'options': Options.YES_NO
    }
    psc_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_SCREEN_CAPTURE}"]'
    allow_screen_capture = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, psc_xpath),
                              label_text_locator=(By.XPATH, f'{psc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{psc_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_SCREEN_CAPTURE,
        'options': Options.YES_NO
    }
    pasc_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_ASSISTANT}"]'
    allow_assistant = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pasc_xpath),
                              label_text_locator=(By.XPATH, f'{pasc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pasc_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_ASSISTANT,
        'options': Options.YES_NO
    }
    psuwdl_xpath = f'//input[@testname="{isrs.ElementNames.ASSISTANT_LOCKED}"]'
    assistant_locked = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, psuwdl_xpath),
                              label_text_locator=(By.XPATH, f'{psuwdl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{psuwdl_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ASSISTANT_LOCKED,
        'options': Options.YES_NO
    }
    ptid_xpath = f'//input[@testname="{isrs.ElementNames.UNLOCK_DEVICE}"]'
    unlock_device = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ptid_xpath),
                              label_text_locator=(By.XPATH, f'{ptid_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ptid_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.UNLOCK_DEVICE,
        'options': Options.YES_NO
    }
    puai_xpath = f'//input[@testname="{isrs.ElementNames.UI_APP}"]'
    ui_app = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, puai_xpath),
                              label_text_locator=(By.XPATH, f'{puai_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{puai_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.UI_APP,
        'options': Options.YES_NO
    }
    putp_xpath = f'//input[@testname="{isrs.ElementNames.TLS_PROMPT}"]'
    tls_prompt = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, putp_xpath),
                              label_text_locator=(By.XPATH, f'{putp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{putp_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.TLS_PROMPT,
        'options': Options.YES_NO
    }
    puna_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_NEWS}"]'
    allow_news = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, puna_xpath),
                              label_text_locator=(By.XPATH, f'{puna_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{puna_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_NEWS,
        'options': Options.YES_NO
    }
    pugcs_xpath = f'//input[@testname="{isrs.ElementNames.USER_CONTENT}"]'
    user_content = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pugcs_xpath),
                              label_text_locator=(By.XPATH, f'{pugcs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pugcs_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.USER_CONTENT,
        'options': Options.YES_NO
    }
    pvdpl_xpath = f'//input[@testname="{isrs.ElementNames.VOICE_DAILING}"]'
    voice_dailing = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pvdpl_xpath),
                              label_text_locator=(By.XPATH, f'{pvdpl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pvdpl_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.VOICE_DAILING,
        'options': Options.YES_NO
    }
    pwm_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_WALLPAPER}"]'
    allow_wallpaper = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pwm_xpath),
                              label_text_locator=(By.XPATH, f'{pwm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pwm_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_WALLPAPER,
        'options': Options.YES_NO
    }
    pwp_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_PAIRED}"]'
    allow_paired = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pwp_xpath),
                              label_text_locator=(By.XPATH, f'{pwp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pwp_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.ALLOW_PAIRED,
        'options': Options.YES_NO
    }
    ratng_xpath = f'//input[@testname="{isrs.ElementNames.RATINGS}"]'
    ratings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ratng_xpath),
                              label_text_locator=(By.XPATH, f'{ratng_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ratng_xpath}{toggle_xpath}')),
        'label_text': isrs.TextConstants.RATINGS,
        'options': ['--', 'Yes']
    }
    add_button1 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{isrs.ElementNames.ADD}"])[1]')),
        'label_text': isrs.TextConstants.ADD
    }
    add_button2 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{isrs.ElementNames.ADD}"])[2]')),
        'label_text': isrs.TextConstants.ADD
    }
    add_button3 = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="{isrs.ElementNames.ADD}"])[3]')),
        'label_text': isrs.TextConstants.ADD
    }
    paf_xpath = f'//input[@testname="{isrs.ElementNames.ALLOW_AUTO_FILL}"]'
    allow_auto_fill = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, paf_xpath),
                              label_text_locator=(By.XPATH, f'{paf_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{paf_xpath}/ancestor::table')),
        'label_text': isrs.TextConstants.ALLOW_AUTO_FILL,
        'checked': True
    }
    ffw_xpath = f'//input[@testname="{isrs.ElementNames.FORCE_FRAUD_WARNING}"]'
    force_fraud_warning = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ffw_xpath),
                              label_text_locator=(By.XPATH, f'{ffw_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ffw_xpath}/ancestor::table')),
        'label_text': isrs.TextConstants.FORCE_FRAUD_WARNING,
        'checked': False
    }
    ejs_xpath = f'//input[@testname="{isrs.ElementNames.ENABLE_JAVA_SCRIPT}"]'
    enable_java_script = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ejs_xpath),
                              label_text_locator=(By.XPATH, f'{ejs_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ejs_xpath}/ancestor::table')),
        'label_text': isrs.TextConstants.ENABLE_JAVA_SCRIPT,
        'checked': True
    }
    bps_xpath = f'//input[@testname="{isrs.ElementNames.BLOCK_POPUPS}"]'
    block_popups = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, bps_xpath),
                              label_text_locator=(By.XPATH, f'{bps_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{bps_xpath}/ancestor::table')),
        'label_text': isrs.TextConstants.BLOCK_POPUPS,
        'checked': False
    }
    blcs_xpath = f'//input[@testname="{isrs.ElementNames.BLOCK_COOKIES}"]'
    block_cookies = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, blcs_xpath),
                              label_text_locator=(By.XPATH, f'{blcs_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{blcs_xpath}/parent::td/following-sibling::td')),
        'label_text': isrs.TextConstants.BLOCK_COOKIES,
        'options': ['Always', 'From third parties and advertisers', 'Never']
    }
    srr_xpath = f'//input[@testname="{isrs.ElementNames.RATING_REGION}"]'
    rating_region = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, srr_xpath),
                              label_text_locator=(By.XPATH, f'{srr_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{srr_xpath}/parent::td/following-sibling::td')),
        'label_text': isrs.TextConstants.RATING_REGION,
        'options': ['Australia', 'Canada', 'France', 'Germany', 'Ireland', 'Japan', 'New Zealand', 'United Kingdom', 'United States']
    }
    mvs_xpath = f'//input[@testname="{isrs.ElementNames.RATING_MOVIES}"]'
    rating_movies = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mvs_xpath),
                              label_text_locator=(By.XPATH, f'{mvs_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{mvs_xpath}/parent::td/following-sibling::td')),
        'label_text': isrs.TextConstants.RATING_MOVIES,
        'options': ["Don't Allow Movies", 'G', 'PG', 'PG-13', 'R', 'NC-17', 'Allow All Movies']
    }
    tvss_xpath = f'//input[@testname="{isrs.ElementNames.RATING_TV_SHOWS}"]'
    rating_tv_shows = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, tvss_xpath),
                              label_text_locator=(By.XPATH, f'{tvss_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{tvss_xpath}/parent::td/following-sibling::td')),
        'label_text': isrs.TextConstants.RATING_TV_SHOWS,
        'options': ["Don't Allow TV shows", 'TV-Y', 'TV-Y7', 'TV-G', 'TV-PG', 'TV-14', 'TV-MA', 'Allow All TV shows']
    }
    apps_xpath = f'//input[@testname="{isrs.ElementNames.RATING_APPS}"]'
    rating_apps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apps_xpath),
                              label_text_locator=(By.XPATH, f'{apps_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{apps_xpath}/parent::td/following-sibling::td')),
        'label_text': isrs.TextConstants.RATING_APPS,
        'options': ["Don't Allow Apps", '4+', '9+', '12+', '17+', 'Allow All Apps']
    }

    def __init__(self, driver):
        self.allow_safari['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.allow_auto_fill),
                    factory(driver).define_checkbox(self.force_fraud_warning),
                    factory(driver).define_checkbox(self.enable_java_script),
                    factory(driver).define_checkbox(self.block_popups),
                    factory(driver).define_select(self.block_cookies),
                ]
            }
        ]
        self.ratings['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.rating_region),
                    factory(driver).define_select(self.rating_movies),
                    factory(driver).define_select(self.rating_tv_shows),
                    factory(driver).define_select(self.rating_apps),
                ]
            }
        ]
        self.app_launch_mode['children'] = [
            {
                'depends_on': 'Allowed',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_modify_delete_grid(self.add_button1)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            isrs.ElementNames.APP_LIST_MODE: factory(driver).define_select(self.app_launch_mode),
            isrs.ElementNames.ENCRYPTED_BACKUPS: factory(driver).define_select(self.encrypted_backups),
            isrs.ElementNames.STORE_PASSWORD: factory(driver).define_select(self.store_password),
            isrs.ElementNames.AD_TRACKING: factory(driver).define_select(self.ad_tracking),
            isrs.ElementNames.PROFANITY_FILTER: factory(driver).define_select(self.profanity_filter),
            'add_button2': factory(driver).define_modify_delete_grid(self.add_button2),
            isrs.ElementNames.ALLOW_AIRDROP: factory(driver).define_select(self.allow_airdrop),
            isrs.ElementNames.ALLOW_BOOKSTORE_EROTICA: factory(driver).define_select(self.bookstore_erotica),
            isrs.ElementNames.GAME_CENTER: factory(driver).define_select(self.game_center),
            isrs.ElementNames.ALLOW_BOOKSTORE: factory(driver).define_select(self.allow_bookstore),
            isrs.ElementNames.SHARED_STREAM: factory(driver).define_select(self.shared_stream),
            isrs.ElementNames.ACCOUNT_MODIFICATION: factory(driver).define_select(self.account_modification),
            isrs.ElementNames.ADDING_GAME_CENTER: factory(driver).define_select(self.add_game_center),
            isrs.ElementNames.AIRDROP_UNMANAGED: factory(driver).define_select(self.airdrop_unmanaged),
            isrs.ElementNames.DATA_MODIFICATION: factory(driver).define_select(self.data_modification),
            isrs.ElementNames.APP_DOWNLOADS: factory(driver).define_select(self.app_downloads),
            isrs.ElementNames.DIAGNOSTIC_SUBMISSION: factory(driver).define_select(self.diagnostic_submission),
            isrs.ElementNames.SYNC_ROAMING: factory(driver).define_select(self.sync_roaming),
            isrs.ElementNames.PHOTO_LIBRARY: factory(driver).define_select(self.photo_library),
            isrs.ElementNames.NAME_MODIFICATION: factory(driver).define_select(self.name_modification),
            isrs.ElementNames.ALLOW_LOCK_SCREEN: factory(driver).define_select(self.allow_lock_screen),
            isrs.ElementNames.APP_TRUST: factory(driver).define_select(self.app_trust),
            isrs.ElementNames.EXPLICIT_CONTENT: factory(driver).define_select(self.explicit_content),
            isrs.ElementNames.FRIENDS_MODIFICATION: factory(driver).define_select(self.friends_modification),
            isrs.ElementNames.CLOUD_BACKUP: factory(driver).define_select(self.cloud_backup),
            isrs.ElementNames.CLOUD_DOCUMENT: factory(driver).define_select(self.cloud_document),
            isrs.ElementNames.CLOUD_KEYCHAIN: factory(driver).define_select(self.cloud_keychain),
            isrs.ElementNames.MESSAGE: factory(driver).define_select(self.message),
            isrs.ElementNames.APP_PURCHASES: factory(driver).define_select(self.app_purchases),
            isrs.ElementNames.APP_INSTALLATION: factory(driver).define_select(self.app_installation),
            isrs.ElementNames.ALLOW_TUNES: factory(driver).define_select(self.allow_tunes),
            isrs.ElementNames.KEYBOARD_SHORTCUTS: factory(driver).define_select(self.keyboard_shortcuts),
            isrs.ElementNames.CONTROL_CENTER: factory(driver).define_select(self.control_center),
            isrs.ElementNames.NOTIFICATION_VIEW: factory(driver).define_select(self.notification_view),
            isrs.ElementNames.TODAY_VIEW: factory(driver).define_select(self.today_view),
            isrs.ElementNames.CONFIGURATION_FILE: factory(driver).define_select(self.configuration_file),
            isrs.ElementNames.MULTIPLAYER_GAMING: factory(driver).define_select(self.multiplayer_gaming),
            isrs.ElementNames.MANAGED_UNMANAGED: factory(driver).define_select(self.managed_unmanaged),
            isrs.ElementNames.UNMANAGED_MANAGED: factory(driver).define_select(self.unmanaged_managed),
            isrs.ElementNames.HOST_PAIRING: factory(driver).define_select(self.host_pairing),
            isrs.ElementNames.PASSCODE_MODIFICATION: factory(driver).define_select(self.passcode_modification),
            isrs.ElementNames.PHOTO_STREAM: factory(driver).define_select(self.photo_stream),
            isrs.ElementNames.APP_REMOVAL: factory(driver).define_select(self.app_removal),
            isrs.ElementNames.ALLOW_SAFARI: factory(driver).define_select(self.allow_safari),
            isrs.ElementNames.ALLOW_SCREEN_CAPTURE: factory(driver).define_select(self.allow_screen_capture),
            'add_button3': factory(driver).define_modify_delete_grid(self.add_button3),
            isrs.ElementNames.ALLOW_ASSISTANT: factory(driver).define_select(self.allow_assistant),
            isrs.ElementNames.ASSISTANT_LOCKED: factory(driver).define_select(self.assistant_locked),
            isrs.ElementNames.UNLOCK_DEVICE: factory(driver).define_select(self.unlock_device),
            isrs.ElementNames.UI_APP: factory(driver).define_select(self.ui_app),
            isrs.ElementNames.TLS_PROMPT: factory(driver).define_select(self.tls_prompt),
            isrs.ElementNames.ALLOW_NEWS: factory(driver).define_select(self.allow_news),
            isrs.ElementNames.USER_CONTENT: factory(driver).define_select(self.user_content),
            isrs.ElementNames.VOICE_DAILING: factory(driver).define_select(self.voice_dailing),
            isrs.ElementNames.ALLOW_WALLPAPER: factory(driver).define_select(self.allow_wallpaper),
            isrs.ElementNames.ALLOW_PAIRED: factory(driver).define_select(self.allow_paired),
            isrs.ElementNames.RATINGS: factory(driver).define_select(self.ratings)
        }
        super().__init__(driver, self.elements)



