from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory

class DomainSettingsPage(UIPage):

    add_button1 = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[1]')),
                    'inner_text': 'Add'
                  }

    add_button2 = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])[2]')),
                   'inner_text': 'Add'
                  }

    def __init__(self, driver):
        self.elements = {
            'add_button1': factory(driver).define_element(self.add_button1),
            'add_button2': factory(driver).define_element(self.add_button2),
        }
        super().__init__(driver, self.elements)
