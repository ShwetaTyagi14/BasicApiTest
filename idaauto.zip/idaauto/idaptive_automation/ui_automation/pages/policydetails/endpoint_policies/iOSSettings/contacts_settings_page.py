from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class ContactsSettingsPage(UIPage):

    add_button = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'(//a[@buttontext="Add"])')),
                   'inner_text': 'Add'
                  }

    def __init__(self, driver):
        self.elements = {
            'add_button': factory(driver).define_element(self.add_button),
        }
        super().__init__(driver, self.elements)
