from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AndroidManagementSettingsCertificateProfiles as amscp
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class CertificateProfilesPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{amscp.ElementNames.HEADER}"]')),
              'inner_text': amscp.TextConstants.HEADER
    }

    add_xpath = f'//input[@testname="{amscp.ElementNames.ADD}"]'
    add = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, add_xpath),
                              label_text_locator=(By.XPATH, f'{add_xpath}{label_xpath}')),
        'label_text': amscp.TextConstants.ADD,
    }

    pu_xpath = f'//input[@testname="{amscp.ElementNames.PUSH_USER}"]'
    push_user = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pu_xpath),
                              label_text_locator=(By.XPATH, f'{pu_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pu_xpath}{toggle_xpath}')),
        'label_text': amscp.TextConstants.PUSH_USER,
        'options': Options.YES_NO
    }

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'add': factory(driver).define_modify_delete_grid(self.add),
            'push_user': factory(driver).define_select(self.push_user)
        }
        super().__init__(driver, self.elements)
