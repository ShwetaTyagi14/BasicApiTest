from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AndroidManagementSettingsExchangeSettings as amses
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class ExchangeSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{amses.ElementNames.HEADER}"]')),
        'inner_text': amses.TextConstants.HEADER
    }
    eea_xpath = f'//input[@testname="{amses.ElementNames.ENABLE_EXCHANGE_ACTIVESYNC}"]'
    enable_exchange_activesync = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eea_xpath),
                              label_text_locator=(By.XPATH, f'{eea_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eea_xpath}{toggle_xpath}')),
        'label_text': amses.TextConstants.ENABLE_EXCHANGE_ACTIVE,
        'options': Options.YES_NO
    }

    ba_xpath = f'//div[text()="{amses.ElementNames.BASIC}"]'
    basic = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ba_xpath),
                              label_text_locator=(By.XPATH, f'{ba_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ba_xpath}{toggle_xpath}')),
        'label_text': amses.TextConstants.BASIC,
    }

    def __init__(self, driver):
        self.enable_exchange_activesync['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_exchange_settings(self.basic)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_exchange_activesync': factory(driver).define_select(self.enable_exchange_activesync)
        }
        super().__init__(driver, self.elements)
