from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AndroidManagementSettingsRestrictions as amsr
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RestrictionsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{amsr.ElementNames.HEADER}"]')),
        'inner_text': amsr.TextConstants.HEADER
    }

    lcp_xpath = f'//input[@testname="{amsr.ElementNames.LIMIT_COPY_PASTE}"]'
    limit_copy_paste = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, lcp_xpath),
                              label_text_locator=(By.XPATH, f'{lcp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{lcp_xpath}{toggle_xpath}')),
        'label_text': amsr.TextConstants.LIMIT_COPY_PASTE,
        'options': Options.YES_NO
    }

    pds_xpath = f'//input[@testname="{amsr.ElementNames.PERMIT_DATA_SHARING}"]'
    permit_data_sharing = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pds_xpath),
                              label_text_locator=(By.XPATH, f'{pds_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pds_xpath}{toggle_xpath}')),
        'label_text': amsr.TextConstants.PERMIT_DATA_SHARING,
        'options': Options.YES_NO
    }

    pd_xpath = f'//input[@testname="{amsr.ElementNames.PERMIT_DEBUGGING}"]'
    permit_debugging = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pd_xpath),
                              label_text_locator=(By.XPATH, f'{pd_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pd_xpath}{toggle_xpath}')),
        'label_text': amsr.TextConstants.PERMIT_DEBUGGING,
        'options': Options.YES_NO
    }

    pi_xpath = f'//input[@testname="{amsr.ElementNames.PERMIT_INSTALLATION}"]'
    permit_installation = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pi_xpath),
                              label_text_locator=(By.XPATH, f'{pi_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pi_xpath}{toggle_xpath}')),
        'label_text': amsr.TextConstants.PERMIT_INSTALLATION,
        'options': Options.YES_NO
    }

    psc_xpath = f'//input[@testname="{amsr.ElementNames.PERMIT_SCREEN_CAPTURE}"]'
    permit_screen_capture = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, psc_xpath),
                              label_text_locator=(By.XPATH, f'{psc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{psc_xpath}{toggle_xpath}')),
        'label_text': amsr.TextConstants.PERMIT_SCREEN_CAPTURE,
        'options': Options.YES_NO
    }


    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'limit_copy_paste': factory(driver).define_select(self.limit_copy_paste),
            'permit_data_sharing': factory(driver).define_select(self.permit_data_sharing),
            'permit_debugging': factory(driver).define_select(self.permit_debugging),
            'permit_installation': factory(driver).define_select(self.permit_installation),
            'permit_screen_capture': factory(driver).define_select(self.permit_screen_capture)

        }
        super().__init__(driver, self.elements)
