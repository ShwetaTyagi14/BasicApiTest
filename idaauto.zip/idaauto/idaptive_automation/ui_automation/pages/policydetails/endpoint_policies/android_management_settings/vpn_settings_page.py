from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AndroidManagementSettingsVPNSettings as amsvs
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class VPNSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{amsvs.ElementNames.HEADER}"]')),
        'inner_text': amsvs.TextConstants.HEADER
    }

    ea_xpath = f'//input[@testname="{amsvs.ElementNames.ENABLE_ALWAYS}"]'
    enable_always = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ea_xpath),
                              label_text_locator=(By.XPATH, f'{ea_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ea_xpath}{toggle_xpath}')),
        'label_text': amsvs.TextConstants.ENABLE_ALWAYS,
        'options': Options.YES_NO
    }

    pn_xpath = f'//input[@testname="{amsvs.ElementNames.PACKAGE_NAME}"]'
    package_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pn_xpath),
                              label_text_locator=(By.XPATH, f'{pn_xpath}/ancestor::table/following-sibling::label')),
        'label_text': amsvs.TextConstants.PACKAGE_NAME,
    }

    le_xpath = f'//input[@testname="{amsvs.ElementNames.LOCKDOWN_ENABLED}"]'
    lockdown_enabled = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, le_xpath),
                              label_text_locator=(By.XPATH, f'{le_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{le_xpath}{toggle_xpath}')),
        'label_text': amsvs.TextConstants.LOCKDOWN_ENABLED,
        'options': Options.YES_NO
    }


    def __init__(self, driver):
        self.enable_always['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.package_name),
                    factory(driver).define_select(self.lockdown_enabled)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_always': factory(driver).define_select(self.enable_always)
        }
        super().__init__(driver, self.elements)
