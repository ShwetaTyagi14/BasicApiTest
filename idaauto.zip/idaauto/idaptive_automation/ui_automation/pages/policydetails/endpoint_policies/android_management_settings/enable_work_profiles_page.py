from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AndroidManagementSettingsEnableWorkProfiles as amsewp
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class EnableWorkProfilesPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{amsewp.ElementNames.HEADER}"]')),
        'inner_text': amsewp.TextConstants.HEADER
    }

    ewp_xpath = f'//input[@testname="{amsewp.ElementNames.WORK_PROFILES}"]'
    enable_work_profiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ewp_xpath),
                              label_text_locator=(By.XPATH, f'{ewp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ewp_xpath}{toggle_xpath}')),
        'label_text': amsewp.TextConstants.WORK_PROFILES,
        'options': Options.YES_NO
    }


    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_work_profiles': factory(driver).define_select(self.enable_work_profiles)
        }
        super().__init__(driver, self.elements)
