from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.constants import DeviceEnrollmentSettings as des
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class DeviceEnrollmentSettingsPage(UIPage):
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,f'//div[text()="{pdc.DEVICE_ENROLLMENT_SETTINGS}"]')),
              'inner_text': pdc.DEVICE_ENROLLMENT_SETTINGS
    }

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = '/ancestor::td/following-sibling::td/div'

    pde_xpath = f'//input[@testname="{des.ElementNames.PERMIT_DEVICE_ENROLLMENT}"]'
    permit_device_enroll = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pde_xpath),
                              label_text_locator=(By.XPATH,f'{pde_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{pde_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.PERMIT_DEVICE_ENROLLMENT,
        'options': Options.YES_NO
    }

    ad_xpath = f'//input[@testname="{des.ElementNames.ADD_DEVICE_OPTIONS}"]'
    add_devices = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ad_xpath),
                              label_text_locator=(By.XPATH,f'{ad_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{ad_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.ADD_DEVICE_OPTIONS,
        'options': Options.YES_NO
    }

    oc_xpath = f'//input[@testname="{des.ElementNames.ONLY_CORPORATE_DEVICES}"]'
    only_corporate = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, oc_xpath),
                              label_text_locator=(By.XPATH,f'{oc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{oc_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.ONLY_CORPORATE_DEVICES,
        'options': Options.YES_NO
    }

    pnc_xpath = f'//input[@testname="{des.ElementNames.NON_COMPLIANT_DEVICES}"]'
    permit_non_compliant = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pnc_xpath),
                              label_text_locator=(By.XPATH,f'{pnc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{pnc_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.NON_COMPLIANT_DEVICES,
        'options': Options.YES_NO
    }

    ib_xpath = f'//input[@testname="{des.ElementNames.INVITE_BASED_ENROLLMENT}"]'
    invite_based = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ib_xpath),
                              label_text_locator=(By.XPATH,f'{ib_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{ib_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.INVITE_BASED_ENROLLMENT,
        'options': Options.YES_NO
    }
    le_xpath = f'//input[@testname="{des.ElementNames.INVITE_BASED_EXPIRATION}"]'
    link_expire = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, le_xpath),
                              label_text_locator=(By.XPATH,f'{le_xpath}/ancestor::table/following-sibling::label[span[@class="required-field-star"]]'),
                              # parent_container_locator=(By.XPATH,f'{le_xpath}/ancestor::table'),
                              toggle_locator=(By.XPATH,f'{le_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.INVITE_BASED_EXPIRATION,
        'options': ['--', '10', '30', '60', '360', '1440']
    }

    md_xpath = f'//input[@testname="{des.ElementNames.MAX_DEVICES}"]'
    max_devices = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, md_xpath),
                              label_text_locator=(By.XPATH,f'{md_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{md_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.MAX_DEVICES
    }

    sn_xpath = f'//input[@testname="{des.ElementNames.NOTIFY_ON_DEVICE_ENROLL}"]'
    send_notification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sn_xpath),
                              label_text_locator=(By.XPATH,f'{sn_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{sn_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.NOTIFY_ON_DEVICE_ENROLL,
        'options': Options.YES_NO
    }

    wt_xpath = f'//input[@testname="{des.ElementNames.WELCOME_TEXT_ON_DEVICE_ENROLL}"]'
    welcome_text = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, wt_xpath),
                              label_text_locator=(By.XPATH,f'{wt_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{wt_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.WELCOME_TEXT_ON_DEVICE_ENROLL,
        'options': Options.YES_NO
    }

    ap_xpath = f'//input[@testname="{des.ElementNames.ALLOW_PERSONAL_DEVICE}"]'
    allow_personal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ap_xpath),
                              label_text_locator=(By.XPATH,f'{ap_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{ap_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.ALLOW_PERSONAL_DEVICE,
        'options': Options.YES_NO
    }

    dc_xpath = f'//input[@testname="{des.ElementNames.DEFAULT_COMPANY_OWNED}"]'
    default_company = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dc_xpath),
                              label_text_locator=(By.XPATH,f'{dc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{dc_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.DEFAULT_COMPANY_OWNED,
        'options': Options.YES_NO
    }

    pa_xpath = f'//input[@testname="{des.ElementNames.PERMIT_ANDROID}"]'
    permit_android = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pa_xpath),
                              label_text_locator=(By.XPATH,f'{pa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{pa_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.PERMIT_ANDROID,
        'options': Options.ALL_FILTER_NONE
    }

    pios_xpath = f'//input[@testname="{des.ElementNames.PERMIT_IOS}"]'
    permit_ios = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pios_xpath),
                              label_text_locator=(By.XPATH,f'{pios_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{pios_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.PERMIT_IOS,
        'options': Options.ALL_FILTER_NONE
    }

    posx_xpath = f'//input[@testname="{des.ElementNames.PERMIT_OSX}"]'
    permit_osx = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, posx_xpath),
                              label_text_locator=(By.XPATH,f'{posx_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{posx_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.PERMIT_OSX,
        'options': Options.ALL_FILTER_NONE
    }

    eym_xpath = f'//input[@testname="{des.ElementNames.ENROLL_MAC_PROMPT}"]'
    enroll_ypur_mac = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eym_xpath),
                              label_text_locator=(By.XPATH,f'{eym_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{eym_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.ENROLL_MAC_PROMPT,
        'options': Options.YES_NO
    }

    pw_xpath = f'//input[@testname="{des.ElementNames.PERMIT_WINDOWS}"]'
    permit_windows = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pw_xpath),
                              label_text_locator=(By.XPATH,f'{pw_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{pw_xpath}{toggle_xpath}')),
        'label_text': des.TextConstants.PERMIT_WINDOWS,
        'options': Options.ALL_FILTER_NONE
    }

    dsms_xpath = f'//input[@testname="{des.ElementNames.DISPLAY_SMS}"]'
    display_sms = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dsms_xpath),
                              label_text_locator=(By.XPATH, f'{dsms_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{dsms_xpath}/ancestor::table')),
        'label_text': des.TextConstants.DISPLAY_SMS,
        'checked': True
    }

    de_xpath = f'//input[@testname="{des.ElementNames.DISPLAY_EMAIL}"]'
    display_email = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, de_xpath),
                              label_text_locator=(By.XPATH,f'{de_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH,f'{de_xpath}/ancestor::table')),
        'label_text': des.TextConstants.DISPLAY_EMAIL,
        'checked': True
    }

    dqrc_xpath = f'//input[@testname="{des.ElementNames.DISPLAY_QR_CODE}"]'
    display_qr_code = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dqrc_xpath),
                              label_text_locator=(By.XPATH,f'{dqrc_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH,f'{dqrc_xpath}/ancestor::table')),
        'label_text': des.TextConstants.DISPLAY_QR_CODE,
        'checked': True
    }

    add_android_devs = {
        'locator':
            ElementSetLocator(title_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}"]',
                              grid_rows_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[5]//table//tr',
                              btn_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[1]//a[@buttontext="Add Rule"]',
                              grid_header_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[4]/div[starts-with(@id,"header")]')
    }

    add_ios_devs = {
        'locator':
            ElementSetLocator(title_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}"]',
                              grid_rows_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[5]//table//tr',
                              btn_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[1]//a[@buttontext="Add Rule"]',
                              grid_header_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[4]/div[starts-with(@id,"header")]')
    }

    add_osx_devs = {
        'locator':
            ElementSetLocator(title_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}"]',
                              grid_rows_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[5]//table//tr',
                              btn_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[1]//a[@buttontext="Add Rule"]',
                              grid_header_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[4]/div[starts-with(@id,"header")]')
    }

    add_windows_devs = {
        'locator':
            ElementSetLocator(title_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}"]',
                              grid_rows_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[5]//table//tr',
                              btn_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[1]//a[@buttontext="Add Rule"]',
                              grid_header_locator=f'//div[.="{des.TextConstants.ANDROID_ENROLLMENT_RULES}" and @class="x-component x-ltr x-component-default"]/following-sibling::div[1]/div[4]/div[starts-with(@id,"header")]')
    }

    def __init__(self, driver):
        self.add_devices['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.display_sms),
                    factory(driver).define_checkbox(self.display_email),
                    factory(driver).define_checkbox(self.display_qr_code)
                ]
            }
        ]
        self.permit_android['children'] = [
            {
                'depends_on': 'Filter',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_device_enrollment_grid(self.add_android_devs)
                ]
            }
        ]
        self.permit_ios['children'] = [
            {
                'depends_on': 'Filter',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_device_enrollment_grid(self.add_ios_devs)
                ]
            }
        ]
        self.permit_osx['children'] = [
            {
                'depends_on': 'Filter',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_device_enrollment_grid(self.add_osx_devs)
                ]
            }
        ]
        self.permit_windows['children'] = [
            {
                'depends_on': 'Filter',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_device_enrollment_grid(self.add_windows_devs)
                ]
            }
        ]
        self.permit_device_enroll['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.add_devices),
                    factory(driver).define_select(self.only_corporate),
                    factory(driver).define_select(self.permit_non_compliant),
                    factory(driver).define_select(self.invite_based),
                    factory(driver).define_select(self.link_expire),
                    factory(driver).define_element(self.max_devices),
                    factory(driver).define_select(self.send_notification),
                    factory(driver).define_select(self.welcome_text),
                    factory(driver).define_select(self.allow_personal),
                    factory(driver).define_select(self.default_company),
                    factory(driver).define_select(self.permit_android),
                    factory(driver).define_select(self.permit_ios),
                    factory(driver).define_select(self.permit_osx),
                    factory(driver).define_select(self.enroll_ypur_mac),
                    factory(driver).define_select(self.permit_windows)

                ]
            }
        ]
        self.elements = {
            pdc.DEVICE_MANAGEMENT_SEWTTINGS: factory(driver).define_element(self.header),
            des.ElementNames.PERMIT_DEVICE_ENROLLMENT: factory(driver).define_select(self.permit_device_enroll)
        }
        super().__init__(driver, self.elements)

    def select_option(self, select_name, option):
        if select_name not in self.elements:
            raise KeyError(f'{select_name} is not a valid select box on device enrollment settings page')

        self.elements[select_name].select_option(option)
        return self

    def get_select_options(self,select_name):
        if select_name not in self.elements:
            raise KeyError(f'{select_name} is not a valid select box on device enrollment settings page')

        return self, self.elements[select_name].get_options()
