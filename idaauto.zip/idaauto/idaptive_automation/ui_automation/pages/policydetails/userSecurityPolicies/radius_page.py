from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import UserSecurityPoliciesRadius as uspr
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class RadiusPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{uspr.ElementNames.HEADER}"]')),
              'inner_text': uspr.TextConstants.HEADER
    }

    arc_xpath = f'//input[@testname="{uspr.ElementNames.ALLOW_RADIUS_CLIENT}"]'
    allow_radius_client = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, arc_xpath),
                              label_text_locator=(By.XPATH, f'{arc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{arc_xpath}{toggle_xpath}')),
        'label_text': uspr.TextConstants.ALLOW_RADIUS_CLIENT,
        'options': Options.YES_NO
    }

    rac_xpath = f'//input[@testname="{uspr.ElementNames.REQUIRE_AUTH_CHALLENGE}"]'
    require_auth_challenge = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rac_xpath),
                              label_text_locator=(By.XPATH, f'{rac_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{rac_xpath}/parent::div')),
        'label_text': uspr.TextConstants.REQUIRE_AUTH_CHALLENGE,
        'checked': False
    }

    svs_xpath = f'//input[@testname="{uspr.ElementNames.SEND_VENDOR_SPECIFIC}"]'
    send_vendor_specific = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, svs_xpath),
                              label_text_locator=(By.XPATH, f'{svs_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{svs_xpath}/parent::div')),
        'label_text': uspr.TextConstants.SEND_VENDOR_SPECIFIC,
        'checked': False
    }

    atpr_xpath = f'//input[@testname="{uspr.ElementNames.ALLOW_3RD_PARTY_RADIUS}"]'
    allow_third_party_radius = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, atpr_xpath),
                              label_text_locator=(By.XPATH, f'{atpr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{atpr_xpath}{toggle_xpath}')),
        'label_text': uspr.TextConstants.ALLOW_3RD_PARTY_RADIUS,
        'options': Options.YES_NO
    }

    ap_xpath = f'//input[@testname="{uspr.ElementNames.AUTH_PROFILE}"]'
    auth_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ap_xpath),
                              label_text_locator=(By.XPATH, f'{ap_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{ap_xpath}/parent::td/following-sibling::td')),
        'label_text': uspr.TextConstants.AUTH_PROFILE,
        'options': Options.NO_ALWAYS_ALLOWED_PROFILES[0:3] + [Options.NO_ALWAYS_ALLOWED_PROFILES[-1]]
    }

    aa_xpath = f'//a[@buttontext="{uspr.ElementNames.ADD_ATTRIBUTES}"]'
    add_attributes = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aa_xpath),
                              label_text_locator=(By.XPATH, f'{aa_xpath}/parent::div/parent::div/parent::div/parent::div/div/div/div/div')),
        'label_text': uspr.TextConstants.ADD_ATTRIBUTES,
    }

    def __init__(self, driver, auth_profiles):
        self.auth_profile['options'] = auth_profiles + ['- Add New Profile -']
        self.require_auth_challenge['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.auth_profile),
                ]
            }
        ]
        self.send_vendor_specific['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_modify_delete_grid(self.add_attributes),
                ]
            }
        ]
        self.allow_radius_client['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.require_auth_challenge),
                    factory(driver).define_checkbox(self.send_vendor_specific),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'allow_radius_client': factory(driver).define_select(self.allow_radius_client),
            'allow_third_party_radius': factory(driver).define_select(self.allow_third_party_radius)
        }
        super().__init__(driver, self.elements)
