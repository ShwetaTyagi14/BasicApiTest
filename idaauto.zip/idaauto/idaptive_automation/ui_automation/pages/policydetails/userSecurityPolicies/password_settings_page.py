from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import UserSecurityPoliciesPasswordSettings as uspps
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class PasswordSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{uspps.ElementNames.HEADER}"]')),
              'inner_text': uspps.TextConstants.HEADER
    }

    mipl_xpath = f'//input[@testname="{uspps.ElementNames.MIN_PASSWORD_LENGTH}"]'
    min_password_length = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mipl_xpath),
                              label_text_locator=(By.XPATH, f'{mipl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mipl_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.MIN_PASSWORD_LENGTH,
        'options': ['--', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16']
    }

    mapl_xpath = f'//input[@testname="{uspps.ElementNames.MAX_PASSWORD_LENGTH}"]'
    max_password_length = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mapl_xpath),
                              label_text_locator=(By.XPATH, f'{mapl_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mapl_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.MAX_PASSWORD_LENGTH,
        'options': ['--', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                    '21', '22', '23', '24', '25', '26', '27', '28', '29', '30',
                    '31', '32', '33', '34', '35', '36', '37', '38', '39', '40',
                    '41', '42', '43', '44', '45', '46', '47', '48', '49', '50',
                    '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64']
    }

    raod_xpath = f'//input[@testname="{uspps.ElementNames.REQ_ATLEAST_ONE_DIGIT}"]'
    req_atleat_ond_digit = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, raod_xpath),
                              label_text_locator=(By.XPATH, f'{raod_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{raod_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.REQ_ATLEAST_ONE_DIGIT,
        'options': Options.YES_NO
    }

    raou_xpath = f'//input[@testname="{uspps.ElementNames.REQ_ATLEAST_ONE_UPPERLOWER}"]'
    req_atleat_one_upperlower = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, raou_xpath),
                              label_text_locator=(By.XPATH, f'{raou_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{raou_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.REQ_ATLEAST_ONE_UPPERLOWER,
        'options': Options.YES_NO
    }

    raos_xpath = f'//input[@testname="{uspps.ElementNames.REQ_ATLEAST_ONE_SYMBOL}"]'
    req_atleat_one_symbol = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, raos_xpath),
                              label_text_locator=(By.XPATH, f'{raos_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{raos_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.REQ_ATLEAST_ONE_SYMBOL,
        'options': Options.YES_NO
    }

    spcr_xpath = f'//input[@testname="{uspps.ElementNames.SHOW_PWD_COMPLEXITY_REQ}"]'
    show_pwd_complexity_req = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, spcr_xpath),
                              label_text_locator=(By.XPATH, f'{spcr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{spcr_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.SHOW_PWD_COMPLEXITY_REQ,
        'options': Options.YES_NO
    }

    pcr_xpath = f'//input[@testname="{uspps.ElementNames.PWD_COMPLEXITY_REQ_DIRECTOY_SERVICES}"]'
    pwd_complexity_req = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pcr_xpath),
                              label_text_locator=(By.XPATH, f'{pcr_xpath}/ancestor::table/parent::div/div/div/div/label')),
        'label_text': uspps.TextConstants.PWD_COMPLEXITY_REQ_DIRECTOY_SERVICES,
        'options': Options.YES_NO
    }

    lcrc_xpath = f'//input[@testname="{uspps.ElementNames.LIMIT_CONSECUTIVE_REP_CHAR}"]'
    limit_consecutive_rep_char = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, lcrc_xpath),
                              label_text_locator=(By.XPATH, f'{lcrc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{lcrc_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.LIMIT_CONSECUTIVE_REP_CHAR,
    }

    cwp_xpath = f'//input[@testname="{uspps.ElementNames.CHCK_AGAINST_WEAK_PWD}"]'
    check_weak_pwd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, cwp_xpath),
                              label_text_locator=(By.XPATH, f'{cwp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{cwp_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.CHCK_AGAINST_WEAK_PWD,
        'options': Options.YES_NO
    }

    aupp_xpath = f'//input[@testname="{uspps.ElementNames.ALLOW_USERNAME_PART_PWD}"]'
    allow_username_part_pwd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aupp_xpath),
                              label_text_locator=(By.XPATH, f'{aupp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{aupp_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.ALLOW_USERNAME_PART_PWD,
        'options': Options.YES_NO
    }

    adpp_xpath = f'//input[@testname="{uspps.ElementNames.ALLOW_DISPLAYNAME_PART_PWD}"]'
    allow_displayname_part_pwd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adpp_xpath),
                              label_text_locator=(By.XPATH, f'{adpp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{adpp_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.ALLOW_DISPLAYNAME_PART_PWD,
        'options': Options.YES_NO
    }

    rau_xpath = f'//input[@testname="{uspps.ElementNames.REQ_ATLEAST_ONE_UNICODE}"]'
    req_atleast_one_unicode = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rau_xpath),
                              label_text_locator=(By.XPATH, f'{rau_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rau_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.REQ_ATLEAST_ONE_UNICODE,
        'options': Options.YES_NO
    }

    mipa_xpath = f'//input[@testname="{uspps.ElementNames.MIN_PWD_AGE}"]'
    min_pwd_age = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mipa_xpath),
                              label_text_locator=(By.XPATH, f'{mipa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mipa_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.MIN_PWD_AGE
    }

    mapa_xpath = f'//input[@testname="{uspps.ElementNames.MAX_PWD_AGE}"]'
    max_pwd_age = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mapa_xpath),
                              label_text_locator=(By.XPATH, f'{mapa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mapa_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.MAX_PWD_AGE
    }

    ph_xpath = f'//input[@testname="{uspps.ElementNames.PWD_HISTORY}"]'
    pwd_history = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ph_xpath),
                              label_text_locator=(By.XPATH, f'{ph_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ph_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.PWD_HISTORY,
        'options': ['--', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12',
                    '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25']
    }

    pen_xpath = f'//input[@testname="{uspps.ElementNames.PWD_EXPIRATION_NOT}"]'
    pwd_expiration_notification = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pen_xpath),
                              label_text_locator=(By.XPATH, f'{pen_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{pen_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.PWD_EXPIRATION_NOT,
        'options': ['--', '7', '14', '21', '28', '35', '42', '49']
    }

    espe_xpath = f'//input[@testname="{uspps.ElementNames.ESCALATE_PWD_EXPIRATION}"]'
    escalate_pwd_expiration = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, espe_xpath),
                              label_text_locator=(By.XPATH, f'{espe_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{espe_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.ESCALATE_PWD_EXPIRATION,
        'options': ['--', '24', '48', '72', '96', '120']
    }

    enpe_xpath = f'//input[@testname="{uspps.ElementNames.ENABLE_PWD_EXPIRATION}"]'
    enable_pwd_expiration = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, enpe_xpath),
                              label_text_locator=(By.XPATH, f'{enpe_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{enpe_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.ENABLE_PWD_EXPIRATION,
        'options': Options.YES_NO
    }

    mcbpa_xpath = f'//input[@testname="{uspps.ElementNames.MAX_CONSECUTIVE_BAD_PWD_ATTEMTS}"]'
    max_consec_bad_pwd_attempts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mcbpa_xpath),
                              label_text_locator=(By.XPATH, f'{mcbpa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mcbpa_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.MAX_CONSECUTIVE_BAD_PWD_ATTEMTS,
        'options': ['--', 'Off', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
    }

    cwcbpa_xpath = f'//input[@testname="{uspps.ElementNames.CAPTURE_WINDOW_CONSECUTIVE_BAD_PWD_ATTEMPTS}"]'
    capture_windows_consec_bad_pwd_attempts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, cwcbpa_xpath),
                              label_text_locator=(By.XPATH, f'{cwcbpa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{cwcbpa_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.CAPTURE_WINDOW_CONSECUTIVE_BAD_ATTEMPTES
    }

    ld_xpath = f'//input[@testname="{uspps.ElementNames.LOCKOUT_DURATION}"]'
    lockout_duration = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ld_xpath),
                              label_text_locator=(By.XPATH, f'{ld_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ld_xpath}{toggle_xpath}')),
        'label_text': uspps.TextConstants.LOCKOUT_DURATION
    }

    def __init__(self, driver):
        self.show_pwd_complexity_req['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.pwd_complexity_req)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'min_password_length': factory(driver).define_select(self.min_password_length),
            'max_password_length': factory(driver).define_select(self.max_password_length),
            'req_atleast_one_digit': factory(driver).define_select(self.req_atleat_ond_digit),
            'req_atleast_one_upperlower': factory(driver).define_select(self.req_atleat_one_upperlower),
            'req_atleast_one_symbol': factory(driver).define_select(self.req_atleat_one_symbol),
            'show_pwd_complexity_req': factory(driver).define_select(self.show_pwd_complexity_req),
            'limit_consecutive_rep_char': factory(driver).define_text_input(self.limit_consecutive_rep_char),
            'check_weak_pwd': factory(driver).define_select(self.check_weak_pwd),
            'allow_username_part_pwd':factory(driver).define_select(self.allow_username_part_pwd),
            'allow_displayname_part_pwd': factory(driver).define_select(self.allow_displayname_part_pwd),
            'req_atleast_one_unicode':factory(driver).define_select(self.req_atleast_one_unicode),
            'min_pwd_age': factory(driver).define_text_input(self.min_pwd_age),
            'max_pwd_age': factory(driver).define_text_input(self.max_pwd_age),
            'pwd_history': factory(driver).define_select(self.pwd_history),
            'pwd_expiration_notification': factory(driver).define_select(self.pwd_expiration_notification),
            'escalate_pwd_expiration': factory(driver).define_select(self.escalate_pwd_expiration),
            'enable_pwd_expiration': factory(driver).define_select(self.enable_pwd_expiration),
            'max_consec_bad_pwd_attempts': factory(driver).define_select(self.max_consec_bad_pwd_attempts),
            'capture_windows_consec_bad_pwd_attempts': factory(driver).define_text_input(self.capture_windows_consec_bad_pwd_attempts),
            'lockout_duration': factory(driver).define_text_input(self.lockout_duration)
        }
        super().__init__(driver, self.elements)

    def set_max_password_age(self, age):
        self.elements['max_pwd_age'].type(age)

    def set_min_password_length(self, value):
        self.elements['min_password_length'].select_option(value)

    def set_max_password_length(self, value):
        self.elements['max_password_length'].select_option(value)
        self.driver.wait_for_loading_mask_to_disappear()
