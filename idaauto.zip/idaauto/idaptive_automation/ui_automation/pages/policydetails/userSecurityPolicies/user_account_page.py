from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import UserSecurityPoliciesUserAccountSettings as uspuas
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class UserAccountSettingsPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{uspuas.ElementNames.HEADER}"]')),
              'inner_text': uspuas.TextConstants.HEADER
              }

    eucp_xpath = f'//input[@testname="{uspuas.ElementNames.ENABLE_USERS_CHANGE_PWD}"]'
    enable_users_change_password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eucp_xpath),
                              label_text_locator=(By.XPATH, f'{eucp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eucp_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.ENABLE_USERS_CHANGE_PWD,
        'options': Options.YES_NO
    }

    rusm_xpath = f'//input[@testname="{uspuas.ElementNames.REQ_USERS_SETUP_MOBILE}"]'
    require_users_setup_mobile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rusm_xpath),
                              label_text_locator=(By.XPATH, f'{rusm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rusm_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.REQ_USERS_SETUP_MOBILE,
        'options': Options.YES_NO
    }

    euef_xpath = f'//input[@testname="{uspuas.ElementNames.ENABLE_USERS_ENROLL_FIDO}"]'
    enable_user_enroll_fido = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, euef_xpath),
                              label_text_locator=(By.XPATH, f'{euef_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{euef_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.ENABLE_USERS_ENROLL_FIDO,
        'options': Options.YES_NO
    }

    euco_xpath = f'//input[@testname="{uspuas.ElementNames.ENABLE_USERS_CONFIG_OATH}"]'
    enable_user_config_oath = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, euco_xpath),
                              label_text_locator=(By.XPATH, f'{euco_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{euco_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.ENABLE_USERS_CONFIG_OATH,
        'options': Options.YES_NO
    }

    eurm_xpath = f'//input[@testname="{uspuas.ElementNames.ENABLE_USERS_REDIRECT_MFA}"]'
    enable_user_redirect_mfa = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eurm_xpath),
                              label_text_locator=(By.XPATH, f'{eurm_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eurm_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.ENABLE_USERS_REDIRECT_MFA,
        'options': Options.YES_NO
    }

    eucs_xpath = f'//input[@testname="{uspuas.ElementNames.ENABLE_USERS_CONFIG_SECURITY}"]'
    enable_user_config_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eucs_xpath),
                              label_text_locator=(By.XPATH, f'{eucs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eucs_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.ENABLE_USERS_CONFIG_SECURITY,
        'options': Options.YES_NO
    }

    apmp_xpath = f'//input[@testname="{uspuas.ElementNames.AUTH_PROFILE_MODIFY_PERSONAL}"]'
    auth_profile_modify_personal = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apmp_xpath),
                              label_text_locator=(By.XPATH, f'{apmp_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{apmp_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.AUTH_PROFILE_MODIFY_PERSONAL
    }

    apcp_xpath = f'//input[@testname="{uspuas.ElementNames.AUTH_PROFILE_CHANGE_PWD}"]'
    auth_profile_change_pwd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apcp_xpath),
                              label_text_locator=(By.XPATH, f'{apcp_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{apcp_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.AUTH_PROFILE_CHANGE_PWD,
    }

    rusf_xpath = f'//input[@testname="{uspuas.ElementNames.REQ_USERS_SETUP_FIDO}"]'
    require_users_setup_fido = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rusf_xpath),
                              label_text_locator=(By.XPATH, f'{rusf_xpath}/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'{rusf_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.REQ_USERS_SETUP_FIDO,
        'options': Options.YES_NO
    }

    fudn_xpath = f'//input[@testname="{uspuas.ElementNames.FIDO_U2F_DISPLAY_NAME}"]'
    fido_u2f_display_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, fudn_xpath),
                              label_text_locator=(By.XPATH, f'{fudn_xpath}/ancestor::table/preceding-sibling::div//label')),
        'label_text': uspuas.TextConstants.FIDO_U2F_DISPLAY_NAME,
    }

    apcf_xpath = f'//input[@testname="{uspuas.ElementNames.AUTH_PROFILE_CONFIG_FIDO}"]'
    auth_profile_config_fido = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apcp_xpath),
                              label_text_locator=(By.XPATH, f'{apcf_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{apcf_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.AUTH_PROFILE_CONFIG_FIDO,
    }

    ruco_xpath = f'//input[@testname="{uspuas.ElementNames.REQ_USERS_CONFIG_OATH}"]'
    require_users_config_oath = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ruco_xpath),
                              label_text_locator=(By.XPATH, f'{ruco_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{ruco_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.REQ_USERS_CONFIG_OATH,
        'options': Options.YES_NO
    }

    oodn_xpath = f'//input[@testname="{uspuas.ElementNames.OATH_OTP_DISPLAY_NAME}"]'
    oath_otp_dispaly_name = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, oodn_xpath),
                              label_text_locator=(By.XPATH, f'{oodn_xpath}/ancestor::table/../div/div/div/label')),
        'label_text': uspuas.TextConstants.OATH_OTP_DISPLAY_NAME,
    }

    apco_xpath = f'//input[@testname="{uspuas.ElementNames.AUTH_PROFILE_CONFIG_OATH}"]'
    auth_profile_config_oath = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, apco_xpath),
                              label_text_locator=(By.XPATH, f'{apco_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{apco_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.AUTH_PROFILE_CONFIG_OATH,
    }

    rucs_xpath = f'//input[@testname="{uspuas.ElementNames.REQ_USERS_CONFIG_SECURITY}"]'
    require_users_config_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, rucs_xpath),
                              label_text_locator=(By.XPATH, f'{rucs_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{rucs_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.REQ_USERS_CONFIG_SECURITY,
        'options': Options.YES_NO
    }

    ads_xpath = f'//input[@testname="{uspuas.ElementNames.ALLOW_DUPLICATE_SECURITY}"]'
    allow_duplicate_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ads_xpath),
                              label_text_locator=(By.XPATH, f'{ads_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{ads_xpath}/ancestor::table')),
        'label_text': uspuas.TextConstants.ALLOW_DUPLICATE_SECURITY,
        'checked': True
    }

    rudq_xpath = f'//input[@testname="{uspuas.ElementNames.REQ_USER_DEFINED_QUESTIONS}"]'
    require_user_defined_questions = {
    'locator':
        ElementSetLocator(element_locator=(By.XPATH, rudq_xpath),
                          label_text_locator=(By.XPATH, f'{rudq_xpath}{label_xpath}')),
    'label_text': uspuas.TextConstants.REQ_USER_DEFINED_QUESTIONS,
    }

    radq_xpath = f'//input[@testname="{uspuas.ElementNames.REQ_ADMIN_DEFINED_QUESTIONS}"]'
    require_admin_defined_questions = {
    'locator':
        ElementSetLocator(element_locator=(By.XPATH, radq_xpath),
                          label_text_locator=(By.XPATH, f'{radq_xpath}{label_xpath}')),
    'label_text': uspuas.TextConstants.REQ_ADMIN_DEFINED_QUESTIONS,
    }

    mcra_xpath = f'//input[@testname="{uspuas.ElementNames.MIN_CHAR_REQ_ANSWERS}"]'
    min_char_required_answers = {
    'locator':
        ElementSetLocator(element_locator=(By.XPATH, mcra_xpath),
                          label_text_locator=(By.XPATH, f'{mcra_xpath}{label_xpath}')),
    'label_text': uspuas.TextConstants.MIN_CHAR_REQ_ANSWERS,
    }

    aps_xpath = f'//input[@testname="{uspuas.ElementNames.AUTH_PROFILE_SECURITY}"]'
    auth_profile_security = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aps_xpath),
                              label_text_locator=(By.XPATH, f'{aps_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{aps_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.AUTH_PROFILE_SECURITY
    }

    dl_xpath = f'//input[@testname="{uspuas.ElementNames.DEFAULT_LANGUAGE}"]'
    default_language = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dl_xpath),
                              label_text_locator=(By.XPATH, f'{dl_xpath}/ancestor::table/parent::div/div/div/div/label'),
                              toggle_locator=(By.XPATH, f'{dl_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.DEFAULT_LANGUAGE,
        'options': ['--', 'Arabic - العربية', 'German - Deutsch', 'English', 'Spanish - español',
                    'French - français', 'Italian - italiano', 'Japanese - 日本語', 'Korean - 한국어', 'Dutch - Nederlands',
                    'Portuguese (Brazil) - português (Brasil)', 'Portuguese - português', 'Russian - русский',
                    'Serbian - srpski', 'Swedish - svenska', 'Thai - ไทย', 'Vietnamese - Tiếng Việt',
                    'Chinese (Simplified, PRC) - 中文(中国)', 'Chinese - 中文']
    }

    nraf_xpath = f'//input[@testname="{uspuas.ElementNames.NUMBER_AUTH_FACTORS_REQ}"]'
    number_required_auth_factors = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, nraf_xpath),
                              label_text_locator=(By.XPATH, f'{nraf_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{nraf_xpath}{toggle_xpath}')),
        'label_text': uspuas.TextConstants.NUMBER_AUTH_FACTORS_REQ
    }

    save_btn = {'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                'inner_text': 'Save'}

    def set_number_required_auth_factors(self, number):
        self.elements['number_required_auth_factors'].select_option(number)

    def set_require_users_setup_mobile(self, option):
        self.elements['require_users_setup_mobile'].select_option(option)

    def click_save_button(self):
        self.elements['save_btn'].wait_for_visible()
        self.elements['save_btn'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def warning_popup_displayed(self):
        element = self.driver.wait_for_visible_element((By.XPATH, f'//div[@role="textbox" and text()="Warning"]'))
        return element.is_displayed()

    def __init__(self, driver, auth_profiles):
        self.auth_profile_modify_personal['options'] = ['--'] + auth_profiles + ['- Add New Profile -']
        self.auth_profile_change_pwd['options'] = ['--'] + auth_profiles + ['- Add New Profile -']
        self.auth_profile_config_fido['options'] = ['--'] + auth_profiles + ['- Add New Profile -']
        self.auth_profile_config_oath['options'] = ['--'] + auth_profiles + ['- Add New Profile -']
        self.auth_profile_security['options'] = ['--'] + auth_profiles + ['- Add New Profile -']
        self.enable_users_change_password['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.auth_profile_change_pwd),
                ]
            }
        ]
        self.enable_user_enroll_fido['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.require_users_setup_fido),
                    factory(driver).define_text_input(self.fido_u2f_display_name),
                    factory(driver).define_select(self.auth_profile_config_fido),
                ]
            }
        ]
        self.enable_user_config_oath['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.require_users_config_oath),
                    factory(driver).define_text_input(self.oath_otp_dispaly_name),
                    factory(driver).define_select(self.auth_profile_config_oath),
                ]
            }
        ]
        self.enable_user_config_security['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_select(self.require_users_config_security),
                    factory(driver).define_checkbox(self.allow_duplicate_security),
                    factory(driver).define_text_input(self.require_user_defined_questions),
                    factory(driver).define_text_input(self.require_admin_defined_questions),
                    factory(driver).define_text_input(self.min_char_required_answers),
                    factory(driver).define_select(self.auth_profile_security),
                ]
            }
        ]

        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_users_change_password': factory(driver).define_select(self.enable_users_change_password),
            'require_users_setup_mobile': factory(driver).define_select(self.require_users_setup_mobile),
            'enable_user_enroll_fido': factory(driver).define_select(self.enable_user_enroll_fido),
            'enable_user_config_oath':factory(driver).define_select(self.enable_user_config_oath),
            'enable_user_redirect_mfa': factory(driver).define_select(self.enable_user_redirect_mfa),
            'enable_user_config_security': factory(driver).define_select(self.enable_user_config_security),
            'auth_profile_modify_personal': factory(driver).define_select(self.auth_profile_modify_personal),
            'default_language': factory(driver).define_select(self.default_language),
            'number_required_auth_factors': factory(driver).define_select(self.number_required_auth_factors),
            'save_btn': factory(driver).define_select(self.save_btn)
        }
        super().__init__(driver, self.elements)
