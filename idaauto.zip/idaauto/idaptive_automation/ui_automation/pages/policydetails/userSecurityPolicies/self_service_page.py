from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import UserSecurityPoliciesSelfService as uspss
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class SelfServicePage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{uspss.ElementNames.HEADER}"]')),
        'inner_text': uspss.TextConstants.HEADER
    }

    eass_xpath = f'//input[@testname="{uspss.ElementNames.ENABLE_ACCOUNT_SELF_SERVICE}"]'
    enable_account_self_service = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eass_xpath),
                              label_text_locator=(By.XPATH, f'{eass_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eass_xpath}{toggle_xpath}')),
        'label_text': uspss.TextConstants.ENABLE_ACCOUNT_SELF_SERVICE,
        'options': ['--', 'Yes']
    }

    epr_xpath = f'//input[@testname="{uspss.ElementNames.ENABLE_PWD_RESET}"]'
    enable_password_reset = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, epr_xpath),
                              label_text_locator=(By.XPATH, f'{epr_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{epr_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.ENABLE_PWD_RESET,
        'checked': True
    }

    adupr_xpath = f'//input[@testname="{uspss.ElementNames.ALLOW_ACTIVE_DIRECTORY_USERS_PR}"]'
    active_directory_users_pwd_reset = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, adupr_xpath),
                              label_text_locator=(By.XPATH, f'{adupr_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{adupr_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.ALLOW_ACTIVE_DIRECTORY_USERS_PR,
        'checked': False
    }

    oabpr_xpath = f'//input[@testname="{uspss.ElementNames.ONLY_ALLOW_BROWSERS_PR}"]'
    only_allow_browsers_pwd_reset = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, oabpr_xpath),
                              label_text_locator=(By.XPATH, f'{oabpr_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{oabpr_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.ONLY_ALLOW_BROWSERS_PR,
        'checked': False
    }

    uml_xpath = f'//input[@testname="{uspss.ElementNames.USER_MUST_LOGIN}"]'
    user_must_login = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, uml_xpath),
                              label_text_locator=(By.XPATH, f'{uml_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{uml_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.USER_MUST_LOGIN,
        'checked': True
    }

    prap_xpath = f'//input[@testname="{uspss.ElementNames.PWD_RESET_AUTH_PROFILE}"]'
    pwd_reset_auth_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, prap_xpath),
                              label_text_locator=(By.XPATH, f'{prap_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{prap_xpath}{toggle_xpath}')),
        'label_text': uspss.TextConstants.PWD_RESET_AUTH_PROFILE,
        'options': Options.NO_ALWAYS_ALLOWED_PROFILES
    }

    mcpra_xpath = f'//input[@testname="{uspss.ElementNames.MAX_CONSEC_PWD_RESET_ATTEMPTS}"]'
    max_consecutive_pwd_reset_attmepts = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mcpra_xpath),
                              label_text_locator=(By.XPATH, f'{mcpra_xpath}/ancestor::table[2]/../table[2]/preceding-sibling::label'),
                              toggle_locator=(By.XPATH, f'{mcpra_xpath}{toggle_xpath}')),
        'label_text': uspss.TextConstants.MAX_CONSEC_PWD_RESET_ATTEMPTS,
        'options': ['--', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
    }

    eau_xpath = f'//input[@testname="{uspss.ElementNames.ENABLE_ACCOUNT_UNLOCK}"]'
    enable_account_unlock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eau_xpath),
                              label_text_locator=(By.XPATH, f'{eau_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{eau_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.ENABLE_ACCOUNT_UNLOCK,
        'checked': False
    }

    aduau_xpath = f'//input[@testname="{uspss.ElementNames.ALLOW_ACTIVE_DIRECTORY_USERS_AU}"]'
    active_directory_users_account_unlock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aduau_xpath),
                              label_text_locator=(By.XPATH, f'{aduau_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aduau_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.ALLOW_ACTIVE_DIRECTORY_USERS_AU,
        'checked': False
    }

    oabau_xpath = f'//input[@testname="{uspss.ElementNames.ONLY_ALLOW_BROWSERS_AU}"]'
    only_allow_browsers_account_unlock = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, oabau_xpath),
                              label_text_locator=(By.XPATH, f'{oabau_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{oabau_xpath}/ancestor::table')),
        'label_text': uspss.TextConstants.ONLY_ALLOW_BROWSERS_AU,
        'checked': False
    }

    auap_xpath = f'//input[@testname="{uspss.ElementNames.ACCOUNT_UNLOCK_AUTH_PROFILE}"]'
    account_unlock_auth_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auap_xpath),
                              label_text_locator=(By.XPATH, f'{auap_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{auap_xpath}{toggle_xpath}')),
        'label_text': uspss.TextConstants.ACCOUNT_UNLOCK_AUTH_PROFILE
    }

    use_connector_running = {
        'locator':
            ElementSetLocator(element_locator=(
                              By.XPATH, f'//label[normalize-space(.)="{uspss.TextConstants.USE_CONNECTOR_RUNNING}"]/preceding-sibling::input'),
                              label_text_locator=(
                              By.XPATH, f'//label[normalize-space(.)="{uspss.TextConstants.USE_CONNECTOR_RUNNING}"]'),
                              parent_container_locator=(
                              By.XPATH, f'//table[tbody/tr/td[1]/div/label[normalize-space(.)="{uspss.TextConstants.USE_CONNECTOR_RUNNING}"]]')),
        'label_text': uspss.TextConstants.USE_CONNECTOR_RUNNING,
        'checked': True
    }

    use_credentials = {
        'locator':
            ElementSetLocator(element_locator=(
                              By.XPATH, f'//label[normalize-space(.)="{uspss.TextConstants.USE_CREDENTIALS}"]/preceding-sibling::input'),
                              label_text_locator=(
                              By.XPATH, f'//label[normalize-space(.)="{uspss.TextConstants.USE_CREDENTIALS}"]'),
                              parent_container_locator=(
                              By.XPATH, f'//label[normalize-space(.)="{uspss.TextConstants.USE_CREDENTIALS}"]/parent::div')),
        'label_text': uspss.TextConstants.USE_CREDENTIALS,
        'checked': False
    }

    au_xpath = f'//input[@testname="{uspss.ElementNames.ADMIN_USERNAME}"]'
    admin_username = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, au_xpath),
                              label_text_locator=(By.XPATH, f'{au_xpath}/parent::td/div/label')),
        'label_text': uspss.TextConstants.ADMIN_USERNAME,
    }

    ap_xpath = f'//input[@testname="{uspss.ElementNames.ADMIN_PWD}"]'
    admin_password = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ap_xpath),
                              label_text_locator=(By.XPATH, f'{ap_xpath}/parent::td/div/label')),
        'label_text': uspss.TextConstants.ADMIN_PWD,
    }

    mfpr_xpath = f'//input[@testname="{uspss.ElementNames.MAX_FORGOTTEN_PWD_RESETS}"]'
    max_forgotten_pwd_resets = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mfpr_xpath),
                              label_text_locator=(By.XPATH, f'{mfpr_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mfpr_xpath}{toggle_xpath}')),
        'label_text': uspss.TextConstants.MAX_FORGOTTEN_PWD_RESETS,
        'options': ['--', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
    }

    cwfp_xpath = f'//input[@testname="{uspss.ElementNames.CAPTURE_WINDOW_FORGOTTEN_PWD_RESETS}"]'
    capture_window_forgotten_pwd = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, cwfp_xpath),
                              label_text_locator=(By.XPATH, f'{cwfp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{cwfp_xpath}{toggle_xpath}')),
        'label_text': uspss.TextConstants.CAPTURE_WINDOW_FORGOTTEN_PWD_RESETS,
        'options': ['--', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100']
    }

    def __init__(self, driver, auth_profiles):
        self.account_unlock_auth_profile['options'] = auth_profiles + ['- Not Allowed -', '- Add New Profile -']
        self.pwd_reset_auth_profile['options'] = auth_profiles + ['- Not Allowed -', '- Add New Profile -']
        self.use_credentials['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_text_input(self.admin_username),
                    factory(driver).define_text_input(self.admin_password),
                ]
            }
        ]
        self.active_directory_users_account_unlock['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.only_allow_browsers_account_unlock),
                    factory(driver).define_select(self.account_unlock_auth_profile),
                    factory(driver).define_checkbox(self.use_connector_running),
                    factory(driver).define_checkbox(self.use_credentials),
                ]
            }
        ]
        self.enable_account_unlock['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.active_directory_users_account_unlock),
                ]
            }

        ]
        self.enable_account_self_service['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.enable_password_reset),
                    factory(driver).define_checkbox(self.active_directory_users_pwd_reset),
                    factory(driver).define_checkbox(self.only_allow_browsers_pwd_reset),
                    factory(driver).define_checkbox(self.user_must_login),
                    factory(driver).define_select(self.pwd_reset_auth_profile),
                    factory(driver).define_select(self.max_consecutive_pwd_reset_attmepts),
                    factory(driver).define_checkbox(self.enable_account_unlock),
                    factory(driver).define_select(self.max_forgotten_pwd_resets),
                    factory(driver).define_select(self.capture_window_forgotten_pwd),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_account_self_service': factory(driver).define_select(self.enable_account_self_service)
        }
        super().__init__(driver, self.elements)
