from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import LocalAccountLinkingPage as lalp
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class LocalAccountLinkingPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE

    local_account_linking = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Local Account Linking"]')),
                   'inner_text': 'Local Account Linking'}

    mlds_xpath = f'//input[@testname="{lalp.ElementNames.MAP_LOCAL_DIRECTORY_SERVICES}"]'
    map_local_directory_services = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, mlds_xpath),
                              label_text_locator=(By.XPATH, f'{mlds_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{mlds_xpath}{toggle_xpath}')),
        'label_text': lalp.TextConstants.MAP_LOCAL_DIRECTORY_SERVICES,
        'options': ['--', 'Required', 'Optional', 'Disabled']
    }
    sds_xpath = f'//input[@testname="{lalp.ElementNames.SOURCE_DIRECTORY_SERVICE}"]'
    source_directory_service = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sds_xpath),
                              label_text_locator=(By.XPATH, f'{sds_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{sds_xpath}{toggle_xpath}')),
        'label_text': lalp.TextConstants.SOURCE_DIRECTORY_SERVICE,
        'options': ['CyberArk Cloud Directory', 'LDAP:AppsLDAP5', 'AD:station-dc2.com', 'AD:apps.ad1']
    }
    tds_xpath = f'//input[@testname="{lalp.ElementNames.TARGET_DIRECTORY_SERVICE}"]'
    target_directory_service = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, tds_xpath),
                              label_text_locator=(By.XPATH, f'{tds_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{tds_xpath}{toggle_xpath}')),
        'label_text': lalp.TextConstants.TARGET_DIRECTORY_SERVICE,
        'options': ['CyberArk Cloud Directory', 'LDAP:AppsLDAP5', 'AD:station-dc2.com', 'AD:apps.ad1']
    }
    duma_xpath = f'//input[@testname="{lalp.ElementNames.DIRECTORY_USER_MAPPING_ATTRIBUTE}"]'
    directory_user_mapping_attribute = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, duma_xpath),
                              label_text_locator=(By.XPATH, f'{duma_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{duma_xpath}{toggle_xpath}')),
        'label_text': lalp.TextConstants.DIRECTORY_USER_MAPPING_ATTRIBUTE,
        'options': ['Name', 'Email']
    }

    mandatory_star = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'//span[@class="required-field-star"]'))
                      }

    save_button = {'locator':
                       ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                   'inner_text': 'Save'}

    policy_saved_toaster = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[.='Policy saved']"))}

    _local_directory_services_rows = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//li[@role = 'option']"))}

    _source_directory_services_rows = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f"//input[contains(@name, 'SourceDirectoryService')]"))}

    _target_directory_services_rows = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f"//input[contains(@name, 'TargetDirectoryService')]"))}

    _dir_user_map_attribute_rows = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f"//input[contains(@name, 'MapUserBy')]"))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.local_account_linking),
            'local_account_linking': factory(driver).define_element(self.local_account_linking),
            'map_local_directory_services': factory(driver).define_select(self.map_local_directory_services),
            'source_directory_service': factory(driver).define_select(self.source_directory_service),
            'target_directory_service': factory(driver).define_select(self.target_directory_service),
            'directory_user_mapping_attribute': factory(driver).define_select(self.directory_user_mapping_attribute),
            'mandatory_star': factory(driver).define_element(self.mandatory_star),
            'save_button': factory(driver).define_element(self.save_button),
            'policy_saved_toaster': factory(driver).define_element(self.policy_saved_toaster),
            'local_directory_services_rows': factory(driver).define_element_group(self._local_directory_services_rows),
            'source_directory_services_rows': factory(driver).define_select(self._source_directory_services_rows),
            'target_directory_services_rows': factory(driver).define_select(self._target_directory_services_rows),
            'dir_user_map_attribute_rows': factory(driver).define_select(self._dir_user_map_attribute_rows)
        }

        super().__init__(driver, self.elements)

    def click_local_account_linking(self):
        self.elements['local_account_linking'].click()

    def set_map_local_directory_services(self, value):
        self.elements['map_local_directory_services'].select_option(value)

    def set_source_directory_service(self, value):
        self.elements['source_directory_service'].select_option(value)

    def set_target_directory_service(self, value):
        self.elements['target_directory_service'].select_option(value)

    def set_directory_user_mapping_attribute(self, value):
        self.elements['directory_user_mapping_attribute'].select_option(value)

    def click_save_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['save_button'].click()
        self.driver.wait_for_loading_mask_to_disappear()

    def validate_policy_saved_toaster(self):
        return self.elements['policy_saved_toaster'].is_displayed()

    def get_map_local_ds_default_value(self):
        result = self.elements['map_local_directory_services'].get_attribute_value('value')
        return result

    def get_all_available_values_for_map_local_ds(self):
        self.elements['map_local_directory_services'].click()
        rows = self.elements['local_directory_services_rows'].get_element()
        row_results = []
        for row in rows:
            options = row.text
            row_results.append(options)
        return row_results

    def get_all_available_values_for_source_directory(self):
        self.elements['source_directory_services_rows'].click()
        result = self.elements['source_directory_services_rows'].get_options()
        return result

    def get_all_available_values_for_target_directory(self):
        self.elements['target_directory_services_rows'].click()
        result = self.elements['target_directory_services_rows'].get_options()
        return result

    def get_all_values_for_dir_user_mapping(self):
        self.elements['dir_user_map_attribute_rows'].click()
        result = self.elements['dir_user_map_attribute_rows'].get_options()
        return result

    def get_dir_user_mapping_default_value(self):
        result = self.elements['directory_user_mapping_attribute'].get_attribute_value('value')
        return result
