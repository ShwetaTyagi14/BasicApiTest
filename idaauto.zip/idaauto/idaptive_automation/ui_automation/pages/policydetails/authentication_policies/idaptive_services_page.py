from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AuthenticationPoliciesIdaptiveServices as apis
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class IdaptiveServicesPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{apis.ElementNames.HEADER}"]')),
        'inner_text': apis.TextConstants.HEADER
    }
    eapc_xpath = f'//input[@testname="{apis.ElementNames.ENABLE_AUTH}"]'
    enable_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eapc_xpath),
                              label_text_locator=(By.XPATH, f'{eapc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eapc_xpath}{toggle_xpath}')),
        'label_text': apis.TextConstants.ENABLE_AUTH,
        'options': ['--', 'Yes']
    }
    add_rule = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{apis.ElementNames.ADD_RULE}"')),
        'label_text': apis.TextConstants.ADD_RULE
    }
    dp_xpath = f'//input[@testname="{apis.ElementNames.DEFAULT_PROFILE}"]'
    default_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dp_xpath),
                              label_text_locator=(By.XPATH, f'{dp_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{dp_xpath}/parent::td/following-sibling::td')),
        'label_text': apis.TextConstants.DEFAULT_PROFILE
    }
    huse_xpath = f'//input[@testname="{apis.ElementNames.SESSION_HOURS}"]'
    sessoin_hours = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, huse_xpath),
                              label_text_locator=(By.XPATH, f'{huse_xpath}/ancestor::table/following-sibling::label')),
        'label_text': apis.TextConstants.SESSION_HOURS
    }
    akmscl_xpath = f'//input[@testname="{apis.ElementNames.KEEP_ME_SIGNED}"]'
    keep_me_signed = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, akmscl_xpath),
                              label_text_locator=(By.XPATH, f'{akmscl_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{akmscl_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.KEEP_ME_SIGNED,
        'checked': False
    }
    dkmsc_xpath = f'//input[@testname="{apis.ElementNames.DEFAULT}"]'
    default = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dkmsc_xpath),
                              label_text_locator=(By.XPATH, f'{dkmsc_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{dkmsc_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.DEFAULT,
        'checked': False
    }
    sekms_xpath = f'//input[@testname="{apis.ElementNames.SESSION_EXPIRES}"]'
    sessoin_expires = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sekms_xpath),
                              label_text_locator=(By.XPATH, f'{sekms_xpath}/ancestor::table/following-sibling::label')),
        'label_text': apis.TextConstants.SESSION_EXPIRES
    }
    aiwac_xpath = f'//input[@testname="{apis.ElementNames.ALLOW_IWA}"]'
    allow_iwa = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aiwac_xpath),
                              label_text_locator=(By.XPATH, f'{aiwac_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aiwac_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.ALLOW_IWA,
        'checked': True
    }
    siciwac_xpath = f'//input[@testname="{apis.ElementNames.SET_IWA}"]'
    set_cookies_iwa = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, siciwac_xpath ),
                              label_text_locator=(By.XPATH, f'{siciwac_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{siciwac_xpath}/parent::div')),
        'label_text': apis.TextConstants.SET_IWA,
        'checked': False
    }
    icsamm_xpath = f'//input[@testname="{apis.ElementNames.IWA_MECHS}"]'
    iwa_mechs = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, icsamm_xpath),
                              label_text_locator=(By.XPATH, f'{icsamm_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{icsamm_xpath}/parent::div')),
        'label_text': apis.TextConstants.IWA_MECHS,
        'checked': False
    }
    uca_xpath = f'//input[@testname="{apis.ElementNames.USE_CERTIFICATES}"]'
    use_certificates = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, uca_xpath),
                              label_text_locator=(By.XPATH, f'{uca_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{uca_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.USE_CERTIFICATES,
        'checked': True
    }
    sicuca_xpath = f'//input[@testname="{apis.ElementNames.SET_USE}"]'
    set_use = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, sicuca_xpath),
                              label_text_locator=(By.XPATH, f'{sicuca_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{sicuca_xpath}/parent::div')),
        'label_text': apis.TextConstants.SET_USE,
        'checked': False
    }
    caamm_xpath = f'//input[@testname="{apis.ElementNames.USE_MECHS}"]'
    use_mechs = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, caamm_xpath),
                              label_text_locator=(By.XPATH, f'{caamm_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{caamm_xpath}/parent::div')),
        'label_text': apis.TextConstants.USE_MECHS,
        'checked': False
    }
    auwaf_xpath = f'//input[@testname="{apis.ElementNames.NO_MFA}"]'
    no_mfa = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, auwaf_xpath),
                              label_text_locator=(By.XPATH, f'{auwaf_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{auwaf_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.NO_MFA,
        'checked': False
    }
    aaarfu_xpath = f'//input[@testname="{apis.ElementNames.FEDERATED_USERS}"]'
    federated_users = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aaarfu_xpath),
                              label_text_locator=(By.XPATH, f'{aaarfu_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aaarfu_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.FEDERATED_USERS,
        'checked': False
    }
    cvfsamm_xpath = f'//input[@testname="{apis.ElementNames.FEDERATED_MECHS}"]'
    federated_mechs = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, cvfsamm_xpath),
                              label_text_locator=(By.XPATH, f'{cvfsamm_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{cvfsamm_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.FEDERATED_MECHS,
        'checked': False
    }
    aaafsd_xpath = f'//input[@testname="{apis.ElementNames.SAME_DEVICE}"]'
    same_device = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, aaafsd_xpath),
                              label_text_locator=(By.XPATH, f'{aaafsd_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{aaafsd_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.SAME_DEVICE,
        'checked': True
    }
    cwacafc_xpath = f'//input[@testname="{apis.ElementNames.FAILED_CHALLENGE}"]'
    failed_challenge = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, cwacafc_xpath),
                              label_text_locator=(By.XPATH, f'{cwacafc_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{cwacafc_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.FAILED_CHALLENGE,
        'checked': True
    }
    pcrf_xpath = f'//input[@testname="{apis.ElementNames.PREVIOUS_CHALLENGE}"]'
    previous_challenge = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, pcrf_xpath),
                              label_text_locator=(By.XPATH, f'{pcrf_xpath}/following-sibling::label'),
                              parent_container_locator=(By.XPATH, f'{pcrf_xpath}/ancestor::table')),
        'label_text': apis.TextConstants.PREVIOUS_CHALLENGE,
        'checked': True
    }

    view_profile_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="View Profile"]')),
                           'supports_validation': False}

    pass_thru_label = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge Pass-Through Duration"]')),
                       'supports_validation': False}

    challenge_1_password = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge 1"]//following::label[text()="Password"][1]//preceding-sibling::input')),
                            'supports_validation': False}

    challenge_1_phone_call = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge 1"]//following::label[text()="Phone call"][1]//preceding-sibling::input')),
                              'supports_validation': False}

    def enable_auth_policy_control(self):
        self.elements['enable_auth'].select_option('Yes')

    def set_default_auth_profile(self, auth_profile):
        self.elements['default_profile'].select_option(auth_profile)

    def click_view_profile_button(self):
        self.elements['view_profile_button'].click()

    def is_pass_thru_label_visible(self):
        return self.elements['pass_thru_label'].is_displayed()
 
    def is_challenge_1_password_selected(self):
        return self.elements['challenge_1_password'].is_selected()
 
    def is_challenge_1_phone_call_selected(self):
        return self.elements['challenge_1_phone_call'].is_selected()
 
    def is_challenge_1_password_enabled(self):
        return self.elements['challenge_1_password'].is_enabled()
 
    def is_challenge_1_phone_call_enabled(self):
        return self.elements['challenge_1_phone_call'].is_enabled()
 
    def __init__(self, driver, auth_profiles):
        self.default_profile['options'] = auth_profiles + ['- Not Allowed -', '- Add New Profile -']
        self.keep_me_signed['children'] = [
            {
                'supports_validation': True,
                'elements': [
                    factory(driver).define_checkbox(self.default),
                    factory(driver).define_text_input(self.sessoin_expires)
                ]
            }
        ]
        self.enable_auth['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_modify_delete_grid(self.add_rule),
                    factory(driver).define_select(self.default_profile),
                    factory(driver).define_text_input(self.sessoin_hours),
                    factory(driver).define_checkbox(self.keep_me_signed),
                    factory(driver).define_checkbox(self.allow_iwa),
                    factory(driver).define_checkbox(self.set_cookies_iwa),
                    factory(driver).define_checkbox(self.iwa_mechs),
                    factory(driver).define_checkbox(self.use_certificates),
                    factory(driver).define_checkbox(self.set_use),
                    factory(driver).define_checkbox(self.use_mechs),
                    factory(driver).define_checkbox(self.no_mfa),
                    factory(driver).define_checkbox(self.federated_users),
                    factory(driver).define_checkbox(self.federated_mechs),
                    factory(driver).define_checkbox(self.same_device),
                    factory(driver).define_checkbox(self.failed_challenge),
                    factory(driver).define_checkbox(self.previous_challenge)
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'default_profile': factory(driver).define_select(self.default_profile),
            'view_profile_button': factory(driver).define_select(self.view_profile_button),
            'pass_thru_label': factory(driver).define_select(self.pass_thru_label),
            'challenge_1_password': factory(driver).define_select(self.challenge_1_password),
            'challenge_1_phone_call': factory(driver).define_select(self.challenge_1_phone_call),
            'enable_auth': factory(driver).define_select(self.enable_auth)
        }
        super().__init__(driver, self.elements)
