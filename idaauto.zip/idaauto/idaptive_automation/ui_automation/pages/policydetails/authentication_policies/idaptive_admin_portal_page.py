from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AuthenticationPoliciesIdaptiveAdminPortal as apiap
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class IdaptiveAdminPortalPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{apiap.TextConstants.HEADER}"]')),
        'inner_text': apiap.TextConstants.HEADER
    }

    disclaimer = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{apiap.TextConstants.DISCLAIMER_TEXT}"]')),
        'inner_text': apiap.TextConstants.DISCLAIMER_TEXT
    }

    eapc_xpath = f'//input[@testname="{apiap.ElementNames.ENABLE_AUTH}"]'
    enable_auth = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eapc_xpath),
                              label_text_locator=(By.XPATH, f'{eapc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eapc_xpath}{toggle_xpath}')),
        'label_text': apiap.TextConstants.ENABLE_AUTH,
        'options': ['--', 'Yes']
    }

    add_rule = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="{apiap.TextConstants.ADD_RULE}"')),
        'label_text': apiap.TextConstants.ADD_RULE
    }

    dp_xpath = f'//input[@testname="{apiap.ElementNames.DEFAULT_PROFILE}"]'
    default_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dp_xpath),
                              label_text_locator=(By.XPATH, f'{dp_xpath}/ancestor::table/tbody/tr/td/div/label'),
                              toggle_locator=(By.XPATH, f'{dp_xpath}/parent::td/following-sibling::td')),
        'label_text': apiap.TextConstants.DEFAULT_PROFILE,
        'options': Options.NO_ALWAYS_ALLOWED_PROFILES
    }
    
    view_profile_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="View Profile"]'))}

    pass_thru_label = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge Pass-Through Duration"]'))}

    challenge_1_password = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge 1"]//following::label[text()="Password"][1]//preceding-sibling::input'))}

    challenge_1_phone_call = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge 1"]//following::label[text()="Phone call"][1]//preceding-sibling::input'))}

    def enable_auth_policy_control(self):
        self.elements['enable_auth'].select_option('Yes')

    def set_default_auth_profile(self, auth_profile):
        self.elements['default_profile'].select_option(auth_profile)

    def click_view_profile_button(self):
        self.elements['view_profile_button'].click()

    def is_pass_thru_label_visible(self):
        return self.elements['pass_thru_label'].is_displayed()
 
    def is_challenge_1_password_selected(self):
        return self.elements['challenge_1_password'].is_selected()
 
    def is_challenge_1_phone_call_selected(self):
        return self.elements['challenge_1_phone_call'].is_selected()
 
    def is_challenge_1_password_enabled(self):
        return self.elements['challenge_1_password'].is_enabled()
 
    def is_challenge_1_phone_call_enabled(self):
        return self.elements['challenge_1_phone_call'].is_enabled()
 
    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'enable_auth': factory(driver).define_select(self.enable_auth),
            'default_profile': factory(driver).define_select(self.default_profile),
            'view_profile_button': factory(driver).define_select(self.view_profile_button),
            'pass_thru_label': factory(driver).define_select(self.pass_thru_label),
            'challenge_1_password': factory(driver).define_select(self.challenge_1_password),
            'challenge_1_phone_call': factory(driver).define_select(self.challenge_1_phone_call)
        }

        super().__init__(driver, self.elements)