from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import AuthenticationPoliciesWindowsWorkstations as apww
from idaptive_automation.ui_automation.constants import Xpaths
from idaptive_automation.ui_automation.constants import Options


class WindowsWorkstationPage(UIPage):
    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="{apww.ElementNames.HEADER}"]')),
              'inner_text': apww.TextConstants.HEADER
    }

    eap_xpath = f'//input[@testname="{apww.ElementNames.ENABLE_AUTH_POLICY}"]'
    enable_auth_policy = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, eap_xpath),
                              label_text_locator=(By.XPATH, f'{eap_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH, f'{eap_xpath}{toggle_xpath}')),
        'label_text': apww.TextConstants.ENABLE_AUTH_POLICY,
        'options': ['--', 'Yes' ]
    }

    ar_xpath = f'//a[@buttontext="{apww.ElementNames.ADD_RULE}"]'
    add_rule = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, ar_xpath)),
        'label_text': apww.TextConstants.ADD_RULE
    }

    dp_xpath = f'//input[@testname="{apww.ElementNames.DEFAULT_PROFILE}"]'
    default_profile = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, dp_xpath),
                              label_text_locator=(By.XPATH, f'{dp_xpath}/ancestor::td/div/label'),
                              toggle_locator=(By.XPATH, f'{dp_xpath}{toggle_xpath}')),
        'label_text': apww.TextConstants.DEFAULT_PROFILE
    }

    view_profile_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="View Profile"]'))}

    pass_thru_label = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge Pass-Through Duration"]'))}

    challenge_1_password = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge 1"]//following::label[text()="Password"][1]//preceding-sibling::input'))}

    challenge_1_phone_call = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//label[text()="Challenge 1"]//following::label[text()="Phone call"][1]//preceding-sibling::input'))}

    def enable_auth_policy_control(self):
        self.elements['enable_auth'].select_option('Yes')

    def set_default_auth_profile(self, auth_profile):
        self.elements['default_profile'].select_option(auth_profile)

    def click_view_profile_button(self):
        self.elements['view_profile_button'].click()

    def is_pass_thru_label_visible(self):
        return self.elements['pass_thru_label'].is_displayed()
 
    def is_challenge_1_password_selected(self):
        return self.elements['challenge_1_password'].is_selected()
 
    def is_challenge_1_phone_call_selected(self):
        return self.elements['challenge_1_phone_call'].is_selected()
 
    def is_challenge_1_password_enabled(self):
        return self.elements['challenge_1_password'].is_enabled()
 
    def is_challenge_1_phone_call_enabled(self):
        return self.elements['challenge_1_phone_call'].is_enabled()

    def __init__(self, driver, auth_profiles):
        self.default_profile['options'] = auth_profiles + ['- Always Allowed -', '- Not Allowed -', '- Add New Profile -']
        self.enable_auth_policy['children'] = [
            {
                'depends_on': 'Yes',
                'supports_validation': True,
                'elements': [
                    factory(driver).define_modify_delete_grid(self.add_rule),
                    factory(driver).define_select(self.default_profile),
                ]
            }
        ]
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'default_profile': factory(driver).define_select(self.default_profile),
            'view_profile_button': factory(driver).define_select(self.view_profile_button),
            'pass_thru_label': factory(driver).define_select(self.pass_thru_label),
            'challenge_1_password': factory(driver).define_select(self.challenge_1_password),
            'challenge_1_phone_call': factory(driver).define_select(self.challenge_1_phone_call),
            'enable_auth': factory(driver).define_select(self.enable_auth_policy)
        }
        super().__init__(driver, self.elements)
