from selenium.webdriver.common.by import By

from idaptive_automation.ui_automation.pages.policydetails.endpoint_policies.oSXandiOSSettings.vpn_profile_page import \
    VpnProfilePage
from idaptive_automation.ui_automation.pages.policydetails.summary_page import SummaryPage
from idaptive_automation.ui_automation.pages.policydetails.third_party_integration_page import ThirdPartyIntegration
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import  UIPage
from idaptive_automation.ui_automation.pages.policydetails.policy_settings import PolicySettingsPage


class PolicyDetailLandingPage(UIPage):
    save_button = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Save"]')),
                   'inner_text': 'Save'}

    cancel_button = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Cancel" and @tabindex=0]')),
                     'inner_text': 'Cancel'}
    summary_tab = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Summary"]')),
                   'inner_text': 'Summary'}

    third_party_integration = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Third Party Integration"]')),
                               'inner_text': 'Third Party Integration'}
    endpoint_policies = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Endpoint Policies"]')),
                         'inner_text': 'Endpoint Policiesn'}

    authentication_policies = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Authentication Policies"]')),
        'inner_text': 'Authentication Policies',
        'supports_validation': False}

    cyberark_identity_admin_portal_tab = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="CyberArk Identity Admin Portal"]')),
        'inner_text': 'Admin Portal',
        'supports_validation': False}

    cyberark_identity = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="CyberArk Identity"]')),
        'inner_text': 'CyberArk Identity',
        'supports_validation': False}

    endpoint_authentication = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Endpoint Authentication"]')),
        'inner_text': 'Endpoint Authentication',
        'supports_validation': False}

    windows_workstations = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="Windows Workstations"]')),
        'inner_text': 'Windows Workstations',
        'supports_validation': False}

    osx_and_ios = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="OS X and iOS Settings"]')),
                   'inner_text': 'OS X and iOS Settings'}

    vpn_settings = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="VPN Settings"]')),
                    'inner_text': 'VPN Settings'}

    add_button = {'locator':
                  ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add"]')),
                  'inner_text': 'Add'}

    user_security_policies = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="User Security Policies"]')),
        'inner_text': 'User Security Policies'}

    user_account_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="User Account Settings"]')),
        'inner_text': 'User Account Settings'}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.save_button),
            'save_button': factory(driver).define_element(self.save_button),
            'cancel_button': factory(driver).define_element(self.cancel_button),
            'summary_tab': factory(driver).define_element(self.summary_tab),
            'third_party_integration': factory(driver).define_element(self.third_party_integration),
            'endpoint_policies': factory(driver).define_element(self.endpoint_policies),
            'authentication_policies': factory(driver).define_element(self.authentication_policies),
            'cyberark_identity': factory(driver).define_element(self.cyberark_identity),
            'cyberark_identity_admin_portal_tab': factory(driver).define_element(self.cyberark_identity_admin_portal_tab),
            'endpoint_authentication': factory(driver).define_element(self.endpoint_authentication),
            'windows_workstations': factory(driver).define_element(self.windows_workstations),
            'osx_and_ios': factory(driver).define_element(self.osx_and_ios),
            'vpn_settings': factory(driver).define_element(self.vpn_settings),
            'add_button': factory(driver).define_element(self.add_button),
            'user_security_policies': factory(driver).define_element(self.user_security_policies),
            'user_account_settings': factory(driver).define_element(self.user_account_settings)
        }

        super().__init__(driver, self.elements)

    def cancel_changes(self):
        self.elements['cancel_button'].click()

    def save_changes(self):
        page, name = PolicySettingsPage(self.driver).get_policy_name()
        page, description = page.get_description()
        page, status = page.get_status()
        self.elements['save_button'].click()
        return self, {'Name': name, 'Status': status, 'Description': description}

    def click_summary_tab(self):
        self.elements['summary_tab'].click()
        return SummaryPage(self.driver).wait_for_page_to_load()

    def click_third_party_integration_tab(self):
        self.elements['third_party_integration'].click()
        return ThirdPartyIntegration(self.driver)

    def click_endpoint_policies_tab(self):
        self.elements['endpoint_policies'].click()

    def click_authentication_policies_tab(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['authentication_policies'].click()

    def click_cyberark_identity_tab(self):
        self.elements['cyberark_identity'].click()

    def click_cyberark_identity_admin_portal_tab(self):
        self.elements['cyberark_identity_admin_portal_tab'].click()

    def click_endpoint_authentication_tab(self):
        self.elements['endpoint_authentication'].click()

    def click_windows_workstations_tab(self):
        self.elements['windows_workstations'].click()

    def click_osx_and_ios_settings_tab(self):
        self.elements['osx_and_ios'].wait_for_visible()
        self.elements['osx_and_ios'].click()

    def click_vpn_settings_tab(self):
        self.elements['vpn_settings'].wait_for_visible()
        self.elements['vpn_settings'].click()

    def click_add_button(self):
        self.elements['add_button'].click()
        return VpnProfilePage(self.driver).wait_for_page_to_load()

    def click_save_button(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['save_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.LONG_DELAY)
        
    def click_user_security_policies_policies(self):
        self.driver.wait_for_loading_mask_to_disappear()
        self.elements['user_security_policies'].click()

    def click_user_account_settings_tab(self):
        self.elements['user_account_settings'].click()
