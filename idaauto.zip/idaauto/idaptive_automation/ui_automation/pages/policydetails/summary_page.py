from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class SummaryPage(UIPage):
    header = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//div[text()="Summary"]'))
              }
    col_header_policy_setting = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'key-value-tree')]/div//span[contains(text(),'Policy Setting')]"))
              }
    col_header_value = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(@class,'key-value-tree')]/div//span[contains(text(),'Policy Setting')]"))
              }
    empty_grid = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//div[contains(text(),'No policies set')]"))
              }
    save = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//span[text()='Save']"))
              }
    cancel = {'locator': ElementSetLocator(element_locator=(By.XPATH, f"//span[text()='Cancel']"))
              }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.header),
            'header': factory(driver).define_element(self.header),
            'col_header_policy_setting': factory(driver).define_element(self.col_header_policy_setting),
            'col_header_value': factory(driver).define_element(self.col_header_value),
            'empty_grid': factory(driver).define_element(self.empty_grid),
            'save': factory(driver).define_element(self.save),
            'cancel': factory(driver).define_element(self.cancel)
        }
        super().__init__(driver, self.elements)



