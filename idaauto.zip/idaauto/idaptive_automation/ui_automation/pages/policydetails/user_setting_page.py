from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc, UserSettings as us, Options, Xpaths


class UserSettingsPage(UIPage):
    header = {'locator':
              ElementSetLocator(element_locator=(By.XPATH,'//div[text()="User Settings"]')),
              'inner_text': pdc.USER_SETTINGS
    }

    label_xpath = Xpaths.SELECT_LABLEL
    toggle_xpath = Xpaths.SELECT_TOGGLE

    apa_xpath = '//input[@testname="/Core/Security/CDS/Applications/AllowSelfService"]'
    allow_personal_app = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,apa_xpath),
                              label_text_locator=(By.XPATH,f'{apa_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{apa_xpath}{toggle_xpath}')),
        'label_text': us.TextConstants.ALLOW_PERSONAL_APPS,
        'options': Options.YES_NO
    }

    acp_xpath = '//input[@testname="/Core/Security/CDS/Applications/AllowPasswordView"]'
    allow_copy_pwds = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,acp_xpath),
                              label_text_locator=(By.XPATH,f'{acp_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{acp_xpath}{toggle_xpath}')),
        'label_text': us.TextConstants.ALLOW_COPY_PASSWORDS,
        'options': Options.YES_NO
    }

    sbe_xpath = '//input[@testname="/Core/Security/CDS/Applications/CBECloudRelease"]'
    be_version = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,sbe_xpath),
                              label_text_locator=(By.XPATH,f'{sbe_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{sbe_xpath}{toggle_xpath}')),
        'label_text': us.TextConstants.SET_BROWSER_EXTENSION_VER,
        'options': Options.BROWSER_EXTENSION_VERSIONS
    }

    elc_xpath = '//input[@testname="/Core/Security/CDS/Applications/EnableLandCatch"]'
    enable_lc = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,elc_xpath),
                              label_text_locator=(By.XPATH,f'{elc_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{elc_xpath}{toggle_xpath}')),
        'label_text': us.TextConstants.ENABLE_L_AND_C,
        'options': Options.YES_NO
    }

    et_xpath = '//input[@testname="/Core/Security/CDS/Applications/EnableWSTrust"]'
    enable_trust = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,et_xpath),
                              label_text_locator=(By.XPATH,f'{et_xpath}{label_xpath}'),
                              toggle_locator=(By.XPATH,f'{et_xpath}{toggle_xpath}')),
        'label_text': us.TextConstants.ENABLE_TRUST_PROTCL,
        'options': Options.YES_NO
    }

    etc_xpath = '//input[@testname="/Core/Security/CDS/Applications/EnableWSTrustChallenges"]'
    enforce_trust_challenge = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,etc_xpath),
                              label_text_locator=(By.XPATH,f'{etc_xpath}/ancestor::table/following-sibling::label'),
                              parent_container_locator=(By.XPATH,f'{etc_xpath}/ancestor::table')),
        'label_text': us.TextConstants.ENFORCE_TRUST_CHALLENGE,
        'checked': True
    }

    def __init__(self, driver, latest_ibe_fixture):
        self.elements = {
            pdc.USER_SETTINGS: factory(driver).define_element(UserSettingsPage.header),
            us.ElementNames.ALLOW_PERSONAL_APPS: factory(driver).define_select(self.allow_personal_app),
            us.ElementNames.ALLOW_COPY_PASSWORDS: factory(driver).define_select(self.allow_copy_pwds),
            us.ElementNames.SET_BROWSER_EXTENSION_VERSION: factory(driver).define_select(self.be_version),
            us.ElementNames.ENABLE_L_AND_C: factory(driver).define_select(self.enable_lc),
            us.ElementNames.ENABLE_TRUST_PROTCL: factory(driver).define_select(self.enable_trust),
            us.ElementNames.ENFORCE_TRUST_CHALLENGE: factory(driver).define_checkbox(self.enforce_trust_challenge)
        }
        super().__init__(driver, self.elements)
        self.set_latest_ibe_version(latest_ibe_fixture)

    def set_latest_ibe_version(self, version_number):
        self.elements[us.ElementNames.SET_BROWSER_EXTENSION_VERSION].add_option_to_definition(version_number)
        return self
