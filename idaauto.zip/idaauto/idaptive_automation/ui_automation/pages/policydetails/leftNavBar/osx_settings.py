from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class OSXSettingsLink(LeftNavBarBase):
    locator = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OSX_SETTINGS}"]')),
        'inner_text': pdc.OSX_SETTINGS
    }

    custom_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.CUSTOM_SETTINGS}"]')),
        'inner_text': pdc.CUSTOM_SETTINGS
    }

    open_apps = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OPEN_APPS_ON_USER_LOGIN}"]')),
        'inner_text': pdc.OPEN_APPS_ON_USER_LOGIN
    }

    open_auth = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OPEN_AUTH_NETWORK_ON_USER_LOGIN}"]')),
        'inner_text': pdc.OPEN_AUTH_NETWORK_ON_USER_LOGIN
    }

    open_files = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OPEN_FILES_ON_USER_LOGIN}"]')),
        'inner_text': pdc.OPEN_FILES_ON_USER_LOGIN
    }

    open_network_mounts = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OPEN_NETWORK_MOUNTS_ON_USER_LOGIN}"]')),
        'inner_text': pdc.OPEN_NETWORK_MOUNTS_ON_USER_LOGIN
    }

    permit_skip = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.PERMIT_SHIFT_TO_SKIP_ON_USER_LOGIN}"]')),
        'inner_text': pdc.PERMIT_SHIFT_TO_SKIP_ON_USER_LOGIN
    }

    sec_priv_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.SECURITY_PRIVACY_SETTINGS}"]')),
        'inner_text': pdc.SECURITY_PRIVACY_SETTINGS
    }

    app_management = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.APPLICATION_MANAGEMENT}"]')),
        'inner_text': pdc.APPLICATION_MANAGEMENT
    }

    manage_local_admin = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.MANAGE_LOCAL_ADMIN_ACCT}"]')),
        'inner_text': pdc.MANAGE_LOCAL_ADMIN_ACCT
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(OSXSettingsLink.locator)
        self.sublinks = {
            pdc.RESTRICTIONS_SETTINGS: RestrictionsSettings(driver),
            pdc.CUSTOM_SETTINGS: factory(driver).define_element(OSXSettingsLink.custom_settings),
            pdc.OPEN_APPS_ON_USER_LOGIN: factory(driver).define_element(OSXSettingsLink.open_apps),
            pdc.OPEN_AUTH_NETWORK_ON_USER_LOGIN: factory(driver).define_element(OSXSettingsLink.open_auth),
            pdc.OPEN_FILES_ON_USER_LOGIN: factory(driver).define_element(OSXSettingsLink.open_files),
            pdc.OPEN_NETWORK_MOUNTS_ON_USER_LOGIN: factory(driver).define_element(OSXSettingsLink.open_network_mounts),
            pdc.PERMIT_SHIFT_TO_SKIP_ON_USER_LOGIN: factory(driver).define_element(OSXSettingsLink.permit_skip),
            pdc.SECURITY_PRIVACY_SETTINGS: factory(driver).define_element(OSXSettingsLink.sec_priv_settings),
            pdc.APPLICATION_MANAGEMENT: factory(driver).define_element(OSXSettingsLink.app_management),
            pdc.MANAGE_LOCAL_ADMIN_ACCT: factory(driver).define_element(OSXSettingsLink.manage_local_admin),
        }
        super().__init__(driver, self.link, self.sublinks)


class RestrictionsSettings(LeftNavBarBase):
    locator = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICTIONS_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }

    apps = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.APPLICATIONS}"]')),
        'inner_text': pdc.APPLICATIONS
    }

    media = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.MEDIA}"]')),
        'inner_text': pdc.MEDIA
    }

    prefs = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.PREFERENCES}"]')),
        'inner_text': pdc.PREFERENCES
    }

    restrict_apps = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICT_APPLICATIONS}"]')),
        'inner_text': pdc.RESTRICT_APPLICATIONS
    }

    restrict_prefs = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICT_PREFERENCES}"]')),
        'inner_text': pdc.RESTRICT_PREFERENCES
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(RestrictionsSettings.locator)
        self.sublinks = {
            pdc.APPLICATIONS: factory(driver).define_element(RestrictionsSettings.apps),
            pdc.MEDIA: factory(driver).define_element(RestrictionsSettings.media),
            pdc.PREFERENCES: factory(driver).define_element(RestrictionsSettings.prefs),
            pdc.RESTRICT_APPLICATIONS: factory(driver).define_element(RestrictionsSettings.restrict_apps),
            pdc.RESTRICT_PREFERENCES: factory(driver).define_element(RestrictionsSettings.restrict_prefs)
        }
        super().__init__(driver, self.link, self.sublinks)
