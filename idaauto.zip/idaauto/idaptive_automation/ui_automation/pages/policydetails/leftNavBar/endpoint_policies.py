from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from .comm_settings import CommonSettingsLink
from .ios_settings import IOSSettingsLink
from .osx_and_ios_settings import OSXiOSSettingsLink
from .osx_settings import OSXSettingsLink
from .samg_knox_dev_settings import SamsungKnoxDeviceSettingsLink
from .samg_knox_wrkspc_settings import SamsungKnoxWorkspaceSettingsLink
from .android_mang_settings import AndroidManagementSettingsLink
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class EndpointPoliciesLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.ENDPOINT_POLICIES}"]')),
        'inner_text': pdc.ENDPOINT_POLICIES
    }

    dev_manage_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.DEVICE_MANAGEMENT_SEWTTINGS}"]')),
        'inner_text': pdc.DEVICE_MANAGEMENT_SEWTTINGS
    }

    dev_enroll_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.DEVICE_ENROLLMENT_SETTINGS}"]')),
        'inner_text': pdc.DEVICE_ENROLLMENT_SETTINGS
    }

    touchdown = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.TOUCHDOWN_SETTINGS}"]')),
        'inner_text': pdc.TOUCHDOWN_SETTINGS
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(EndpointPoliciesLink.locator)
        self.sublinks = {
            pdc.DEVICE_MANAGEMENT_SEWTTINGS : factory(driver).define_element(EndpointPoliciesLink.dev_manage_settings),
            pdc.DEVICE_ENROLLMENT_SETTINGS : factory(driver).define_element(EndpointPoliciesLink.dev_enroll_settings),
            pdc.COMMON_SETTINGS : CommonSettingsLink(driver),
            pdc.IOS_SETTINGS : IOSSettingsLink(driver),
            pdc.OSX_IOS_SETTINGS : OSXiOSSettingsLink(driver),
            pdc.OSX_SETTINGS : OSXSettingsLink(driver),
            pdc.SAMSUMG_KNOX_DEV_SETTINGS : SamsungKnoxDeviceSettingsLink(driver),
            pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS : SamsungKnoxWorkspaceSettingsLink(driver),
            pdc.TOUCHDOWN_SETTINGS : factory(driver).define_element(EndpointPoliciesLink.touchdown),
            pdc.ANDROID_MANAGEMENT_SETTINGS : AndroidManagementSettingsLink(driver),
        }
        super().__init__(driver, self.link, self.sublinks)
