from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc


class PrivilegeElevationPoliciesLink(LeftNavBarBase):
    locator = (By.XPATH,f'//span[normalize-space(.)="{pdc.PRIVILEGE_ELEVATION_POLICIES}"]')

    def __init__(self,driver):
        self.link = PrivilegeElevationPoliciesLink.locator
        self.sublinks = {
            #'User Settings' : (By.XPATH,'//span[normalize-space(.)="Application Policies"]')
        }
        super().__init__(driver,self.link,self.sublinks)
