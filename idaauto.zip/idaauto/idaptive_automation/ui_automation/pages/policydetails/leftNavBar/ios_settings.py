from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class IOSSettingsLink(LeftNavBarBase):
    locator = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.IOS_SETTINGS}"]')),
        'inner_text': pdc.IOS_SETTINGS
    }

    restrictions = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.RESTRICTIONS_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }

    exchange_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.EXCHANGE_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }

    domain_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.DOMAIN_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }

    kiosk_mode = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.KIOSK_MODE}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }

    global_proxy = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.GLOBAL_HTTP_PROXY}"]')),
        'inner_text': pdc.GLOBAL_HTTP_PROXY
    }

    vpn_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.PER_APP_VPN_SETTINGS}"]')),
        'inner_text': pdc.PER_APP_VPN_SETTINGS
    }

    calendar_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.CALENDAR_SETTINGS}"]')),
        'inner_text': pdc.CALENDAR_SETTINGS
    }

    contact_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.CONTACTS_SETTINGS}"]')),
        'inner_text': pdc.CONTACTS_SETTINGS
    }

    ldap_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.LDAP_SETTINGS}"]')),
        'inner_text': pdc.LDAP_SETTINGS
    }

    mail_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.MAIL_SETTINGS}"]')),
        'inner_text': pdc.MAIL_SETTINGS
    }

    app_manage_settings = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.APPLICATION_MANAGEMENT_SETTINGS}"]')),
        'inner_text': pdc.APPLICATION_MANAGEMENT_SETTINGS
    }

    provision_profiles = {
        'locator': ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.PROVISIONING_PROFILES}"]')),
        'inner_text': pdc.PROVISIONING_PROFILES
    }

    def __init__(self,driver):
        self.link = factory(driver).define_element(IOSSettingsLink.locator)
        self.sublinks = {
            pdc.RESTRICTIONS_SETTINGS : factory(driver).define_element(IOSSettingsLink.restrictions),
            pdc.EXCHANGE_SETTINGS : factory(driver).define_element(IOSSettingsLink.exchange_settings),
            pdc.DOMAIN_SETTINGS : factory(driver).define_element(IOSSettingsLink.domain_settings),
            pdc.KIOSK_MODE : factory(driver).define_element(IOSSettingsLink.kiosk_mode),
            pdc.GLOBAL_HTTP_PROXY : factory(driver).define_element(IOSSettingsLink.global_proxy),
            pdc.PER_APP_VPN_SETTINGS : factory(driver).define_element(IOSSettingsLink.vpn_settings),
            pdc.CALENDAR_SETTINGS : factory(driver).define_element(IOSSettingsLink.calendar_settings),
            pdc.CONTACTS_SETTINGS : factory(driver).define_element(IOSSettingsLink.contact_settings),
            pdc.LDAP_SETTINGS : factory(driver).define_element(IOSSettingsLink.ldap_settings),
            pdc.MAIL_SETTINGS : factory(driver).define_element(IOSSettingsLink.mail_settings),
            pdc.APPLICATION_MANAGEMENT_SETTINGS : factory(driver).define_element(IOSSettingsLink.app_manage_settings),
            pdc.PROVISIONING_PROFILES : factory(driver).define_element(IOSSettingsLink.provision_profiles),
        }
        super().__init__(driver, self.link, self.sublinks)
