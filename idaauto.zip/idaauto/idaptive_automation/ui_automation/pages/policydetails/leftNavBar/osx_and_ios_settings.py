from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class OSXiOSSettingsLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OSX_IOS_SETTINGS}"]')),
        'inner_text': pdc.OSX_IOS_SETTINGS
    }

    cert_profiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.CERTIFICATE_PROFILES}"]')),
        'inner_text': pdc.CERTIFICATE_PROFILES
    }

    vpn_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.VPN_SETTINGS}"]')),
        'inner_text': pdc.VPN_SETTINGS
    }

    config_profiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.OSX_IOS_SETTINGS}"]')),
        'inner_text': pdc.OSX_IOS_SETTINGS
    }

    def __init__(self,driver):
        self.link = factory(driver).define_element(OSXiOSSettingsLink.locator)
        self.sublinks = {
            pdc.CERTIFICATE_PROFILES : factory(driver).define_element(OSXiOSSettingsLink.cert_profiles),
            pdc.VPN_SETTINGS : factory(driver).define_element(OSXiOSSettingsLink.vpn_settings),
            pdc.CONFIGURATION_PROFILES : factory(driver).define_element(OSXiOSSettingsLink.config_profiles)
        }
        super().__init__(driver,self.link,self.sublinks)
