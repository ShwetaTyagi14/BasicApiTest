from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class SamsungKnoxWorkspaceSettingsLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS}"]')),
        'inner_text': pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS
    }
    enable_knox_container = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_KNOX_CONTAINER}"]')),
        'inner_text': pdc.ENABLE_KNOX_CONTAINER
    }
    enable_tima_key_store = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_TIMA_KEY_STORE}"]')),
        'inner_text': pdc.ENABLE_TIMA_KEY_STORE
    }
    enable_ode_trusted = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_ODE_TRUSTED}"]')),
        'inner_text': pdc.ENABLE_ODE_TRUSTED
    }
    enable_common_criteria = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_COMMON_CRITERIA}"]')),
        'inner_text': pdc.ENABLE_COMMON_CRITERIA
    }
    require_attestation = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.REQUIRE_ATTESTATION}"]')),
        'inner_text': pdc.REQUIRE_ATTESTATION
    }
    vpn_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.VPN_SETTINGS}"]')),
        'inner_text': pdc.VPN_SETTINGS
    }
    configure_applications = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.CONFIGURE_APPLICATIONS}"]')),
        'inner_text': pdc.CONFIGURE_APPLICATIONS
    }
    enterprise_billing = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENTERPRISE_BILLING}"]')),
        'inner_text': pdc.ENTERPRISE_BILLING
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.locator)
        self.sublinks = {
            pdc.DEVICE_SETTINGS: Devicesettings(driver),
            pdc.CONTAINER_SETTINGS: ContainerSettings(driver),
            pdc.ENABLE_KNOX_CONTAINER: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.enable_knox_container),
            pdc.ENABLE_TIMA_KEY_STORE: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.enable_tima_key_store),
            pdc.ENABLE_ODE_TRUSTED: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.enable_ode_trusted),
            pdc.ENABLE_COMMON_CRITERIA: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.enable_common_criteria),
            pdc.REQUIRE_ATTESTATION: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.require_attestation),
            pdc.VPN_SETTINGS: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.vpn_settings),
            pdc.CONFIGURE_APPLICATIONS: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.configure_applications),
            pdc.ENTERPRISE_BILLING: factory(driver).define_element(SamsungKnoxWorkspaceSettingsLink.enterprise_billing),
        }
        super().__init__(driver, self.link, self.sublinks)


class Devicesettings(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.DEVICE_SETTINGS}"]')),
        'inner_text': pdc.DEVICE_SETTINGS
    }
    cert_validation = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_CERTIFICATE}"]')),
        'inner_text': pdc.ENABLE_CERTIFICATE
    }
    revocation_check = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_REVOCATION}"]')),
        'inner_text': pdc.ENABLE_REVOCATION
    }
    cert_authorities = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.TRUSTED_CERTIFICATE}"]')),
        'inner_text': pdc.TRUSTED_CERTIFICATE
    }
    per_app_vpn = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.APP_VPN_SETTINGS}"]')),
        'inner_text': pdc.APP_VPN_SETTINGS
    }
    audit_log = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_AUDIT_LOG}"]')),
        'inner_text': pdc.ENABLE_AUDIT_LOG
    }
    restriction_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICTION_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTION_SETTINGS
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(Devicesettings.locator)
        self.sublinks = {
            pdc.ENABLE_CERTIFICATE: factory(driver).define_element(Devicesettings.cert_validation),
            pdc.ENABLE_REVOCATION: factory(driver).define_element(Devicesettings.revocation_check),
            pdc.TRUSTED_CERTIFICATE: factory(driver).define_element(Devicesettings.cert_authorities),
            pdc.APP_VPN_SETTINGS: factory(driver).define_element(Devicesettings.per_app_vpn),
            pdc.ENABLE_AUDIT_LOG: factory(driver).define_element(Devicesettings.audit_log),
            pdc.RESTRICTION_SETTINGS: factory(driver).define_element(Devicesettings.restriction_settings)
        }
        super().__init__(driver, self.link, self.sublinks)


class ContainerSettings(LeftNavBarBase):

    locator = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.CONTAINER_SETTINGS}"]')),
        'inner_text': pdc.CONTAINER_SETTINGS
    }
    application_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.APPLICATION_SETTINGS}"]')),
        'inner_text': pdc.APPLICATION_SETTINGS
    }
    browser_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.BROWSER_SETTINGS}"]')),
        'inner_text': pdc.BROWSER_SETTINGS
    }
    certificate_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.CERTIFICATE_SETTINGS}"]')),
        'inner_text': pdc.CERTIFICATE_SETTINGS
    }
    cont_account_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.CONTAINER_ACCOUNT_SETTINGS}"]')),
        'inner_text': pdc.CONTAINER_ACCOUNT_SETTINGS
    }
    email_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.EMAIL_SETTINGS}"]')),
        'inner_text': pdc.EMAIL_SETTINGS
    }
    firewall_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.FIREWALL_SETTINGS}"]')),
        'inner_text': pdc.FIREWALL_SETTINGS
    }
    passcode_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.PASSCODE_SETTINGS}"]')),
        'inner_text': pdc.PASSCODE_SETTINGS
    }
    enable_google_apps = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_GOOGLE_APPS}"]')),
        'inner_text': pdc.ENABLE_GOOGLE_APPS
    }
    sw_restriction_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICTION_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTION_SETTINGS
    }
    sw_per_app_vpn = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.APP_VPN_SETTINGS}"]')),
        'inner_text': pdc.APP_VPN_SETTINGS
    }
    sw_exchange_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.EXCHANGE_SETTINGS}"]')),
        'inner_text': pdc.EXCHANGE_SETTINGS
    }
    sw_email_account = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.EMAIL_ACCOUNT_SETTINGS}"]')),
        'inner_text': pdc.EMAIL_ACCOUNT_SETTINGS
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(ContainerSettings.locator)
        self.sublinks = {
            pdc.APPLICATION_SETTINGS: factory(driver).define_element(ContainerSettings.application_settings),
            pdc.BROWSER_SETTINGS: factory(driver).define_element(ContainerSettings.browser_settings),
            pdc.CERTIFICATE_SETTINGS: factory(driver).define_element(ContainerSettings.certificate_settings),
            pdc.CONTAINER_ACCOUNT_SETTINGS: factory(driver).define_element(ContainerSettings.cont_account_settings),
            pdc.EMAIL_SETTINGS: factory(driver).define_element(ContainerSettings.email_settings),
            pdc.FIREWALL_SETTINGS: factory(driver).define_element(ContainerSettings.firewall_settings),
            pdc.PASSCODE_SETTINGS: factory(driver).define_element(ContainerSettings.passcode_settings),
            pdc.ENABLE_GOOGLE_APPS: factory(driver).define_element(ContainerSettings.enable_google_apps),
            pdc.RESTRICTION_SETTINGS: factory(driver).define_element(ContainerSettings.sw_restriction_settings),
            pdc.APP_VPN_SETTINGS: factory(driver).define_element(ContainerSettings.sw_per_app_vpn),
            pdc.EXCHANGE_SETTINGS: factory(driver).define_element(ContainerSettings.sw_exchange_settings),
            pdc.EMAIL_ACCOUNT_SETTINGS: factory(driver).define_element(ContainerSettings.sw_email_account),
        }
        super().__init__(driver, self.link, self.sublinks)
