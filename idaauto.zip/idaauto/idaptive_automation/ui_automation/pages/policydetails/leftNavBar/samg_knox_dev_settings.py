from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class SamsungKnoxDeviceSettingsLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SAMSUMG_KNOX_DEV_SETTINGS}"]')),
        'inner_text': pdc.SAMSUMG_KNOX_DEV_SETTINGS
    }
    restrictions = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICTIONS_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }
    roaming_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ROAMING_SETTINGS}"]')),
        'inner_text': pdc.ROAMING_SETTINGS
    }
    security_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SECURITY_SETTINGS}"]')),
        'inner_text': pdc.SECURITY_SETTINGS
    }
    vpn_restrictions = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.VPN_RESTRICTIONS}"]')),
        'inner_text': pdc.VPN_RESTRICTIONS
    }
    wifi_restrictions = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.WIFI_RESTRICTIONS}"]')),
        'inner_text': pdc.WIFI_RESTRICTIONS
    }
    password_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.PASSWORD_SETTINGS}"]')),
        'inner_text': pdc.PASSWORD_SETTINGS
    }
    device_inv_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.DEVICE_INVENTORY_SETTINGS}"]')),
        'inner_text': pdc.DEVICE_INVENTORY_SETTINGS
    }
    bluetooth_settings = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.BLUETOOTH_SETTINGS}"]')),
        'inner_text': pdc.BLUETOOTH_SETTINGS
    }

    exchange_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.EXCHANGE_SETTINGS}"]')),
        'inner_text': pdc.EXCHANGE_SETTINGS
    }

    application_management = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.APPLICATION_MANAGEMENT}"]')),
        'inner_text': pdc.APPLICATION_MANAGEMENT
    }

    kiosk_mode = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.KIOSK_MODE}"]')),
        'inner_text': pdc.KIOSK_MODE
    }

    email_acc_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.EMAIL_ACCOUNT_SETTINGS}"]')),
        'inner_text': pdc.EMAIL_ACCOUNT_SETTINGS
    }
    vpn_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.VPN_SETTINGS}"]')),
        'inner_text': pdc.VPN_SETTINGS
    }

    apn_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.APN_SETTINGS}"]')),
        'inner_text': pdc.APN_SETTINGS
    }

    wifi_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.WIFI_SETTINGS}"]')),
        'inner_text': pdc.WIFI_SETTINGS

    }

    bookmark_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.BOOKMARK_SETTINGS}"]')),
        'inner_text': pdc.BOOKMARK_SETTINGS

    }


    def __init__(self, driver):
        self.link = factory(driver).define_element(SamsungKnoxDeviceSettingsLink.locator)
        self.sublinks = {
            'Device Inventory Settings': factory(driver).define_element(SamsungKnoxDeviceSettingsLink.device_inv_settings),
            'VPN Settings': factory(driver).define_element(SamsungKnoxDeviceSettingsLink.vpn_settings),
            'APN Settings': factory(driver).define_element(SamsungKnoxDeviceSettingsLink.apn_settings),
            'Wi-Fi Settings': factory(driver).define_element(SamsungKnoxDeviceSettingsLink.wifi_settings),
            pdc.RESTRICTIONS_SETTINGS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.restrictions),
            pdc.ROAMING_SETTINGS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.roaming_settings),
            pdc.SECURITY_SETTINGS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.security_settings),
            pdc.EXCHANGE_SETTINGS:factory(driver).define_element(SamsungKnoxDeviceSettingsLink.exchange_settings),
            pdc.APPLICATION_MANAGEMENT:factory(driver).define_element(SamsungKnoxDeviceSettingsLink.application_management),
            pdc.KIOSK_MODE:factory(driver).define_element(SamsungKnoxDeviceSettingsLink.kiosk_mode),
            pdc.VPN_RESTRICTIONS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.vpn_restrictions),
            pdc.WIFI_RESTRICTIONS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.wifi_restrictions),
            pdc.PASSWORD_SETTINGS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.password_settings),
            pdc.BLUETOOTH_SETTINGS: factory(driver).define_element(SamsungKnoxDeviceSettingsLink.bluetooth_settings),
            pdc.EMAIL_ACCOUNT_SETTINGS : factory(driver).define_element(SamsungKnoxDeviceSettingsLink.email_acc_settings),
            pdc.BOOKMARK_SETTINGS : factory(driver).define_element(SamsungKnoxDeviceSettingsLink.bookmark_settings),
            pdc.FIREWALL_SETTINGS: FirewallSettings(driver)
        }
        super().__init__(driver, self.link, self.sublinks)



class FirewallSettings(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.FIREWALL_SETTINGS}"]')),
        'inner_text': pdc.FIREWALL_SETTINGS
    }

    legacy = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.LEGACY}"]')),
        'inner_text': pdc.LEGACY
    }

    knox = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.KNOX}"]')),
        'inner_text': pdc.KNOX
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(FirewallSettings.locator)
        self.sublinks = {
            'Legacy': factory(driver).define_element(FirewallSettings.legacy),
            'Knox 2.6+': factory(driver).define_element(FirewallSettings.knox)

        }
        super().__init__(driver, self.link, self.sublinks)