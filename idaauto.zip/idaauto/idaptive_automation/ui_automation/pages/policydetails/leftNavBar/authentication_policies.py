from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc


class AuthenticationPoliciesLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.AUTHENTICATION_POLICIES}"]')),
        'inner_text': pdc.AUTHENTICATION_POLICIES
    }
    idaptive_services = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.IDAPTIVE_SERVICES}"]')),
        'inner_text': pdc.IDAPTIVE_SERVICES
    }
    windows_workstation = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.WINDOWS_WORKSTATIONS}"]')),
        'inner_text': pdc.WINDOWS_WORKSTATIONS
    }
    endpoint_authentication = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENDPOINT_AUTHENTICATION}"]')),
        'inner_text': pdc.ENDPOINT_AUTHENTICATION
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(AuthenticationPoliciesLink.locator)
        self.sublinks = {
            pdc.IDAPTIVE_SERVICES: factory(driver).define_element(AuthenticationPoliciesLink.idaptive_services),
            pdc.WINDOWS_WORKSTATIONS: factory(driver).define_element(AuthenticationPoliciesLink.windows_workstation),
            pdc.ENDPOINT_AUTHENTICATION: factory(driver).define_element(AuthenticationPoliciesLink.endpoint_authentication)
        }
        super().__init__(driver, self.link, self.sublinks)
