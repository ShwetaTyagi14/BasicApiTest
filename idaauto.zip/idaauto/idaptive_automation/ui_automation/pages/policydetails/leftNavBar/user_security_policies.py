from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class UserSecurityPoliciesLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(
                element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.USER_SECURITY_POLICIES}"]')),
        'inner_text': pdc.USER_SECURITY_POLICIES
    }

    oath_otp = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.OATH_OTP}"]')),
        'inner_text': pdc.OATH_OTP
    }

    radius = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RADIUS}"]')),
        'inner_text': pdc.RADIUS
    }

    password_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.PASSWORD_SETTINGS}"]')),
        'inner_text': pdc.PASSWORD_SETTINGS
    }

    user_account_settings = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.USER_ACCOUNT_SETTINGS}"]')),
        'inner_text': pdc.USER_ACCOUNT_SETTINGS
    }

    self_service = {
        'locator': ElementSetLocator(
            element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SELF_SERVICE}"]')),
        'inner_text': pdc.SELF_SERVICE
    }

    def __init__(self,driver):
        self.link = factory(driver).define_element(UserSecurityPoliciesLink.locator)
        self.sublinks = {
            'OATH OTP': factory(driver).define_element(UserSecurityPoliciesLink.oath_otp),
            'RADIUS': factory(driver).define_element(UserSecurityPoliciesLink.radius),
            'Password Settings': factory(driver).define_element(UserSecurityPoliciesLink.password_settings),
            'User Account Settings': factory(driver).define_element(UserSecurityPoliciesLink.user_account_settings),
            'Self Service': factory(driver).define_element(UserSecurityPoliciesLink.self_service)

        }
        super().__init__(driver,self.link,self.sublinks)
