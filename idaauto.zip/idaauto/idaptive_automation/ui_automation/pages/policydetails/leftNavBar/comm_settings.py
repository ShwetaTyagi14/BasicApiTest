from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class CommonSettingsLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.COMMON_SETTINGS}"]')),
        'inner_text': pdc.COMMON_SETTINGS
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(CommonSettingsLink.locator)
        self.sublinks = {
            pdc.MOBILE_SETTINGS: MobileSettingsLink(driver),
            pdc.AGENT_SETTINGS: AgentSettingsLink(driver)
        }
        super().__init__(driver, self.link, self.sublinks)


class MobileSettingsLink(LeftNavBarBase):
    locator = {
            'locator':
                ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.MOBILE_SETTINGS}"]')),
            'inner_text': pdc.MOBILE_SETTINGS
     }
    common = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.COMMON}"]')),
        'inner_text': pdc.COMMON
    }
    restrictions = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICTIONS_SETTINGS}"]')),
        'inner_text': pdc.RESTRICTIONS_SETTINGS
    }
    sec_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SECURITY_SETTINGS}"]')),
        'inner_text': pdc.SECURITY_SETTINGS
    }
    wifi = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.WIFI_SETTINGS}"]')),
        'inner_text': pdc.WIFI_SETTINGS
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(MobileSettingsLink.locator)
        self.sublinks = {
            pdc.COMMON: factory(driver).define_element(MobileSettingsLink.common),
            pdc.RESTRICTIONS_SETTINGS: factory(driver).define_element(MobileSettingsLink.restrictions),
            pdc.SECURITY_SETTINGS: factory(driver).define_element(MobileSettingsLink.sec_settings),
            pdc.WIFI_SETTINGS: factory(driver).define_element(MobileSettingsLink.wifi)
        }
        super().__init__(driver, self.link, self.sublinks)


class AgentSettingsLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.AGENT_SETTINGS}"]')),
        'inner_text': pdc.AGENT_SETTINGS
    }
    loc_screen = {
        'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.LOCK_SCREEN}"]')),
        'inner_text': pdc.LOCK_SCREEN
    }

    def __init__(self, driver):
        self.link = factory(driver).define_element(AgentSettingsLink.locator)
        self.sublinks = {
            pdc.LOCK_SCREEN: factory(driver).define_element(AgentSettingsLink.loc_screen)
        }
        super().__init__(driver, self.link, self.sublinks)

