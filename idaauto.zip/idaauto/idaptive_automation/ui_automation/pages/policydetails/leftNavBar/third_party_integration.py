from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc


class ThirdPartyIntegrationLink(LeftNavBarBase):
    locator = (By.XPATH,f'//span[normalize-space(.)="{pdc.THIRD_PARTY_INTEGRATION}"]')

    def __init__(self,driver):
        self.link = ThirdPartyIntegrationLink.locator
        self.sublinks = {
            #'User Settings' : (By.XPATH,'//span[normalize-space(.)="Application Policies"]')
        }
        super().__init__(driver,self.link,self.sublinks)
