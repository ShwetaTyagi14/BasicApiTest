from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class ApplicationPoliciesLink(LeftNavBarBase):
    locator = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.APPLICATION_POLICIES}"]')),
               'inner_text': pdc.APPLICATION_POLICIES}

    user_settings = {'locator':
                   ElementSetLocator(element_locator=(By.XPATH,f'//span[normalize-space(.)="{pdc.USER_SETTINGS}"]')),
               'inner_text': pdc.USER_SETTINGS}

    def __init__(self, driver):
        self.link = factory(driver).define_element(ApplicationPoliciesLink.locator)
        self.sublinks = {
            'User Settings' : factory(driver).define_element(ApplicationPoliciesLink.user_settings)
        }
        super().__init__(driver, self.link, self.sublinks)
