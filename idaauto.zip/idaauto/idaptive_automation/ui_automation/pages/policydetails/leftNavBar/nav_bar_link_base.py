from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException


class LeftNavBarBase:
    def __init__(self, driver, locator, sublinks):
        self.driver = driver
        self.element = locator
        self.sublinks = sublinks or {}

    def navigate(self, links):
        if not links[0] in self.sublinks and links[0] != self.locator['inner_text']:
            raise ValueError(f'Invalid path: {links[0]}')

        sub_links = links
        if self.element is not None:
            self.element.click()
            sub_links = links[1:]

        if issubclass(type(self.sublinks[sub_links[0]]), LeftNavBarBase):
            self.sublinks[sub_links[0]].navigate(sub_links)
            return

        try:
            first_link = self.sublinks[sub_links[0]].wait_for_visible()
        except AttributeError:
            raise
        if first_link is None:
            raise NoSuchElementException(f'Link: {sub_links[0]} not found')

        # not sure why we need to wait for element again, but it fails if you
        # just try to click the element
        self.sublinks[sub_links[0]].wait_for_visible().click()
