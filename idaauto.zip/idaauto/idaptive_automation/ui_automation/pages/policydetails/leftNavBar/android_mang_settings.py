from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator


class AndroidManagementSettingsLink(LeftNavBarBase):
    locator = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ANDROID_MANAGEMENT_SETTINGS}"]')),
        'inner_text': pdc.ANDROID_MANAGEMENT_SETTINGS
    }

    work_profiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.ENABLE_WORK_PROFILES}"]')),
        'inner_text': pdc.ENABLE_WORK_PROFILES
    }

    exchange_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.EXCHANGE_SETTINGS}"]')),
        'inner_text': pdc.EXCHANGE_SETTINGS
    }

    certificate_profiles = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.CERTIFICATE_PROFILES}"]')),
        'inner_text': pdc.CERTIFICATE_PROFILES
    }

    restrictions = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.RESTRICTIONS}"]')),
        'inner_text': pdc.RESTRICTIONS
    }

    system_apps = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SYSTEM_APPS}"]')),
        'inner_text': pdc.SYSTEM_APPS
    }

    vpn_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.VPN_SETTINGS}"]')),
        'inner_text': pdc.VPN_SETTINGS
    }

    device_owner = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.DEVICE_OWNER}"]')),
        'inner_text': pdc.DEVICE_OWNER
    }


    def __init__(self, driver):
        self.link = factory(driver).define_element(AndroidManagementSettingsLink.locator)
        self.sublinks = {
            'Enable Work Profiles': factory(driver).define_element(AndroidManagementSettingsLink.work_profiles),
            'Exchange Settings': factory(driver).define_element(AndroidManagementSettingsLink.exchange_settings),
            'Certificate Profiles': factory(driver).define_element(AndroidManagementSettingsLink.certificate_profiles),
            'Restrictions': factory(driver).define_element(AndroidManagementSettingsLink.restrictions),
            'System Apps': factory(driver).define_element(AndroidManagementSettingsLink.system_apps),
            'VPN Settings': factory(driver).define_element(AndroidManagementSettingsLink.vpn_settings),
            'Device Owner': factory(driver).define_element(AndroidManagementSettingsLink.device_owner)
        }
        super().__init__(driver,self.link,self.sublinks)
