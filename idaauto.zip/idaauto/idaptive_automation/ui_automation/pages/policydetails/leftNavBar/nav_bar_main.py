from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase
from .application_policies import ApplicationPoliciesLink
from .endpoint_policies import EndpointPoliciesLink
from .authentication_policies import AuthenticationPoliciesLink
from .privilege_escalation_policies import PrivilegeElevationPoliciesLink
from .user_security_policies import UserSecurityPoliciesLink
from .third_party_integration import ThirdPartyIntegrationLink
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class LeftNavBar(LeftNavBarBase):
    pol_settings = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.POLICY_SETTINGS}"]')),
        'inner_text': pdc.POLICY_SETTINGS
    }

    summary = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//span[normalize-space(.)="{pdc.SUMMARY}"]')),
        'inner_text': pdc.SUMMARY
    }

    def __init__(self, driver):
        self.sublinks = {
            pdc.POLICY_SETTINGS: factory(driver).define_element(self.pol_settings),
            pdc.APPLICATION_POLICIES: ApplicationPoliciesLink(driver),
            pdc.ENDPOINT_POLICIES: EndpointPoliciesLink(driver),
            pdc.AUTHENTICATION_POLICIES: AuthenticationPoliciesLink(driver),
            pdc.PRIVILEGE_ELEVATION_POLICIES: PrivilegeElevationPoliciesLink(driver),
            pdc.USER_SECURITY_POLICIES: UserSecurityPoliciesLink(driver),
            pdc.THIRD_PARTY_INTEGRATION: ThirdPartyIntegrationLink(driver),
            pdc.SUMMARY: factory(driver).define_element(self.summary)
        }
        super().__init__(driver, None, self.sublinks)
