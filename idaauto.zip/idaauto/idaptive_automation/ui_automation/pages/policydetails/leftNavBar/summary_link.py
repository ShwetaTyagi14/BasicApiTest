from selenium.webdriver.common.by import By
from .nav_bar_link_base import LeftNavBarBase


class SummaryLink(LeftNavBarBase):
    locator = (By.XPATH,'//span[normalize-space(.)="Common Mobile Settings"]')

    def __init__(self,driver):
        self.link = SummaryLink.locator
        self.sublinks = {
            'User Settings' : (By.XPATH,'//span[normalize-space(.)="Application Policies"]')
        }
        super().__init__(driver,self.link,self.sublinks)
