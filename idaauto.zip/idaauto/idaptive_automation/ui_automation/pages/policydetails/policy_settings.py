from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class PolicySettingsPage(UIPage):
    header = {'locator':
                  ElementSetLocator(element_locator=
                                    (By.XPATH,f'//div[normalize-space(.)="{pdc.POLICY_SETTINGS}" and starts-with(@id,"component")]')),
              'inner_text':pdc.POLICY_SETTINGS}

    name = {'locator':
                ElementSetLocator(element_locator=
                                  (By.XPATH,'//input[@testname="Name"]'),
                                  label_text_locator=(By.XPATH,'//label[starts-with(.,"Name")][span[starts-with(@class,"required-field")]]')),
            'inner_text': pdc.DEFAULT_POLICY_NAME,
            'validation_error_class': 'x-form-field x-form-required-field x-form-text x-form-invalid-field'}

    description = {'locator':
                       ElementSetLocator(element_locator=
                                         (By.XPATH,'//textarea[@testname="Description"]'),
                                         label_text_locator=(By.XPATH,'//textarea[@testname="Description"]/preceding-sibling::div/label[normalize-space(.)="Description"]')),}

    active = {'locator':
                  ElementSetLocator(element_locator=
                                    (By.XPATH,'//input[@testname="PolicyState"]'),
                                    label_text_locator=(By.XPATH,'//input[@testname="PolicyState"]/following-sibling::label'),
                                    parent_container_locator=(By.XPATH,'//table[tbody/tr/td/div[2]/input[@testname="PolicyState"]]')),
              'label_text': 'Set policy to active',
              'checked': True}

    verify_compliance = {'locator':
                             ElementSetLocator(element_locator=
                                               (By.XPATH,'//input[@testname="EnableCompliant"]'),
                                               label_text_locator=(By.XPATH,'//input[@testname="EnableCompliant"]/following-sibling::label'),
                                               parent_container_locator=(By.XPATH,'//table[tbody/tr/td/div[2]/input[@testname="EnableCompliant"]]')),
                         'label_text': 'Verify compliance on Android and iOS devices',
                         'checked': True}

    all_users = {'locator':
                     ElementSetLocator(element_locator=
                                       (By.XPATH,'//label[normalize-space(.)="All users and Devices"]/preceding-sibling::input'),
                                       label_text_locator=(By.XPATH,'//label[normalize-space(.)="All users and Devices"]'),
                                       parent_container_locator=(By.XPATH,'//table[tbody/tr/td[2]/div/label[normalize-space(.)="All users and Devices"]]')),
                 'label_text': 'All users and Devices',
                 'checked': True}

    specified_roles = {'locator': ElementSetLocator(element_locator=
                                               (By.XPATH,'//label[normalize-space(.)="Specified Roles"]/preceding-sibling::input'),
                                               label_text_locator=(By.XPATH,'//label[normalize-space(.)="Specified Roles"]'),
                                               parent_container_locator=(By.XPATH,'//table[tbody/tr/td[2]/div/label[normalize-space(.)="Specified Roles"]]')),
                       'label_text': 'Specified Roles',
                       'checked': False}

    sets = {'locator': ElementSetLocator(element_locator=
                                   (By.XPATH,'//label[normalize-space(.)="Sets"]/preceding-sibling::input'),
                                   label_text_locator=(By.XPATH,'//label[normalize-space(.)="Sets"]'),
                                   parent_container_locator=(By.XPATH,'//table[tbody/tr/td[2]/div/label[normalize-space(.)="Sets"]]')),
            'label_text': 'Sets'}

    def __init__(self, driver):
        self.elements = {
            'header': factory(driver).define_element(self.header),
            'name': factory(driver).define_text_input(self.name),
            'description': factory(driver).define_element(self.description),
            'active': factory(driver).define_checkbox(self.active),
            'verify_compliance': factory(driver).define_checkbox(self.verify_compliance),
            'all_users': factory(driver).define_checkbox(self.all_users),
            'specified_roles': factory(driver).define_checkbox(self.specified_roles),
            'sets': factory(driver).define_checkbox(self.sets)
        }
        super().__init__(driver, self.elements)

    def get_policy_name(self):
        return self, self.elements['name'].get_text()

    def set_name(self, name):
        self.elements['name'].clear()
        self.elements['name'].type(name)
        return self

    def get_status(self):
        checked = self.elements['active'].is_checked()
        return self, 'Active' if checked else 'Inactive'

    def get_description(self):
        return self, self.elements['description'].get_text()

    def assign_policy_to_specified_roles(self):
        self.elements['specified_roles'].click()
