from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory


class ThirdPartyIntegration(UIPage):
    add_challenge_policy = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[text()="+ Add Challenge Policy"]'))
                        }
    add_key_name = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="TabName"]'))
              }

    ok_button = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="OK"]'))
              }

    enable_auth_control_policy = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, f'//input[@testname="/Core/idaptive/AuthenticationEnabled"]'),
                              label_text_locator=(By.XPATH, f'//input[@testname="/Core/idaptive/AuthenticationEnabled"]/ancestor::table/ancestor::table/following-sibling::label'),
                              toggle_locator=(By.XPATH, f'//input[@testname="/Core/idaptive/AuthenticationEnabled"]/ancestor::td/following-sibling::td/div')),
        'label_text': 'Enable authentication policy controls',
        'options': ['--', 'Yes']

    }

    add_rule = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//a[@buttontext="Add Rule"]'))
                 }
    delete_key = {'locator': ElementSetLocator(element_locator=(By.XPATH, f'//span[@title="Delete"]'))
                }

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.add_challenge_policy),
            'add_challenge_policy': factory(driver).define_element(self.add_challenge_policy),
            'add_key_name': factory(driver).define_text_input(self.add_key_name),
            'ok_button': factory(driver).define_element(self.ok_button),
            'enable_auth_control_policy': factory(driver).define_select(self.enable_auth_control_policy),
            'add_rule': factory(driver).define_element(self.add_rule),
            'delete_key': factory(driver).define_element(self.delete_key)
        }
        super().__init__(driver, self.elements)

    def press_add_challenge_policy(self):
        self.elements['add_challenge_policy'].click()

    def set_key_name(self):
        self.elements['add_key_name'].clear()
        self.elements['add_key_name'].type('idaptive')

    def click_ok_button(self):
        self.elements['ok_button'].wait_for_visible()
        self.elements['ok_button'].click()

    def press_enable_auth_control_policy(self):
        self.elements['enable_auth_control_policy'].select_option('Yes')

    def delete_key_policy(self):
        self.elements['delete_key'].click()
