from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


class ErrorDialog(UIPage):
    dialog = {'locator':
              ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"errorwindow")]'))}

    close_button = {'locator':
                    ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"errorwindow")]//a[@buttontext="Close"]')),
                    'inner_text': 'Close'}

    error_message = {'locator':
                     ElementSetLocator(element_locator=(By.XPATH, f'//div[starts-with(@id,"errorwindow-")]//span/div'))}
    error_401 = {'locator':
                 ElementSetLocator(element_locator=(By.XPATH, f'//div[@class="text"]'))}

    def __init__(self, driver):
        self.driver = driver
        dialog = factory(driver).define_element(self.dialog)
        self.elements = {
            self.LOADED_ELEMENT: dialog,
            'dialog': dialog,
            'close_button': factory(driver).define_element(self.close_button),
            'error_message': factory(driver).define_element(self.error_message),
            'error_401': factory(driver).define_element(self.error_401)
        }

        super().__init__(driver, self.elements)

    def get_error_message(self):
        return self.elements['error_message'].get_text()

    def click_close(self):
        self.elements['close_button'].click()

    def validate_error401_message(self):
        self.elements['error_401'].wait_for_visible()
        return self.elements['error_401'].is_displayed()
