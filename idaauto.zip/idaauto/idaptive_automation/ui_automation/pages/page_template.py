from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.ui_page import UIPage


# class <PageName>(UIPage):
#     These elements are here to help you get started, but they need to be corrected. THE XPATHS ARE INVALID
#     All visible elements must be defined, including headers, descriptions, 'learn more' links, etc

#     example = {'locator':
#                ElementSetLocator(element_locator=()),
#                'inner_text': 'example'}
#
#     def __init__(self, driver):
#         raise NotImplementedError('This page class has not been implemented yet')
#         self.elements = {
#             self.LOADED_ELEMENT: factory(driver).define_element(self.example),
#             'example': factory(driver).define_element(self.example)
#         }
#
#         super().__init__(driver, self.elements)
