from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.constants import Xpaths


class JobHistoryPage(UIPage):
    source_xpath = f'//input[@value="All Jobs"]'
    toggle_xpath = Xpaths.SELECT_TOGGLE

    page_title = 'Job History'
    job_history_button = {'locator': ElementSetLocator(element_locator=(By.ID, 'nav-part-SchedulerJobs-Job-History-btnInnerEl'))}
    all_jobs_drop_down = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//input[@value="All Jobs"]'),toggle_locator=(By.XPATH, f'{source_xpath}{toggle_xpath}'))}
    job = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//*[@test-text="f72818c2-ab20-7995-6412-0960e7b2a596"]'))}
    download_report = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//a[@buttontext="Download Report"]'))}
    details = {'locator': ElementSetLocator(element_locator=(By.XPATH, '//span[text()="Details"]'))}

    def __init__(self, driver):
        self.elements = {
            self.LOADED_ELEMENT: ElementFactory(driver).define_element(self.job_history_button),
            'job_history_button': ElementFactory(driver).define_element(self.job_history_button),
            'all_jobs_drop_down': ElementFactory(driver).define_select(self.all_jobs_drop_down),
            'job': ElementFactory(driver).define_element(self.job),
            'download_report': ElementFactory(driver).define_element(self.download_report),
            'details': ElementFactory(driver).define_element(self.details)
        }
        super().__init__(driver, self.elements)

    def is_page_loaded(self):
        return self.elements['job_history_button'].wait_for_not_visible() is not None

    def close_job_history_page(self):
        if self.driver.title == 'Job History':
            self.driver.close()
            self.driver.switch_to_window_by_title('Admin Portal')
            return True
        return False

    def select_job_from_all_jobs(self, job):
        self.elements['all_jobs_drop_down'].wait_for_visible()
        self.elements['all_jobs_drop_down'].select_option(job)
        return self

    def is_no_jobs_visible(self):
        element = self.driver.wait_for_visible_element((By.XPATH,
                                                        f'//div[contains(text(), "No jobs are currently listed.")]'))
        return self, element

    def select_job(self):
        self.elements['job'].click()

    def click_download_report(self):
        self.elements['download_report'].click()

    def click_details(self):
        self.elements['details'].click()
