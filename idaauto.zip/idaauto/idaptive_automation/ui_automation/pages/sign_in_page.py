from selenium.webdriver.common.by import By
from idaptive_automation.ui_automation.pages.ui_page import UIPage
from idaptive_automation.ui_automation.uielements.element_factory import ElementFactory as factory
from idaptive_automation.ui_automation.uielements.element_set_locator import ElementSetLocator
from idaptive_automation.ui_automation.pages.profilemenu.user_profile_menu import UserProfileMenu
from selenium.webdriver.common.action_chains import ActionChains

class SignInPage(UIPage):
    header = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//*[starts-with(@id,"errorwindow")]'))
    }
    user_name_input = {
        'locator':
        ElementSetLocator(element_locator=(By.NAME, 'username'))
    }
    password_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[@id="passwordForm"]//input[@name="answer"]'))
    }
    user_next_button = {
        'locator':
        ElementSetLocator(element_locator=(By.CSS_SELECTOR, '#usernameForm>div.button-wrapper>button'))
    }
    password_next_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[@id="passwordForm"]//button[.="Next"]'))
    }
    terms_of_use = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, "//a[text()='Terms of Use']"))
    }
    privacy_policy = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, "//a[text()='Privacy Policy']"))
    }
    security_question_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//label[text()="Case number"]/following-sibling::input'))
    }
    sq_next_button = {
        'locator':
        ElementSetLocator(element_locator=(By.CSS_SELECTOR, '#mechanismSelectionForm>div.button-wrapper>button'))
    }
    admin_sec_ques_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//div[@id="mechanismSelectionForm"]//input[@name="mfaAnswer"]'))
    }
    admin_next_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"login-form") and contains(@id,"mechanismSelectionForm")]//descendant::button[@type="submit"]'))
    }
    error_message = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, f'//div[contains(@class,"error-message") and not(contains(@class,"hidden"))]'))
    }
    ms_password_input = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@name="passwd"]'))
    }
    ms_sign_in_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@value="Sign in"]'))
    }
    ms_yes_button = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//input[@value="Yes"]'))
    }
    challenge_failed = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH,
                                               '//div[@class="error-message" and .="Authentication (login or challenge) has failed. Please try again or contact your system administrator."]'))
    }
    password_label = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[@id="passwordForm"]//label[.="Password"]'))
    }

    recaptcha_container = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[@id="usernameForm"]//iframe[contains(@src,"recaptcha")]'))
    }

    duo_container = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//iframe[contains(@src, "duosecurity")]'))
    }

    recaptcha_container_social_login_enabled = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[@id="socialForm"]//iframe[contains(@src,"recaptcha")]'))
    }

    user_name_input_with_social = {
        'locator':
            ElementSetLocator(element_locator=(By.XPATH, '//div[@id="socialForm"]//input[@name="username"]'))
    }
    user_next_button_with_social = {
        'locator':
        ElementSetLocator(element_locator=(By.XPATH, '//div[@id="socialForm"]//button[@class=""]'))
    }

    def __init__(self, driver):
        elements = {
            self.LOADED_ELEMENT: factory(driver).define_element(self.user_name_input),
            'user_name_input': factory(driver).define_text_input(self.user_name_input),
            'password_input': factory(driver).define_text_input(self.password_input),
            'user_next_button': factory(driver).define_element(self.user_next_button),
            'password_next_button': factory(driver).define_element(self.password_next_button),
            'terms_of_use': factory(driver).define_element(self.terms_of_use),
            'privacy_policy': factory(driver).define_element(self.privacy_policy),
            'security_question_input': factory(driver).define_text_input(self.security_question_input),
            'sq_next_button': factory(driver).define_element(self.sq_next_button),
            'admin_sec_ques_input': factory(driver).define_text_input(self.admin_sec_ques_input),
            'admin_next_button': factory(driver).define_element(self.admin_next_button),
            'error_message': factory(driver).define_element(self.error_message),
            'ms_password_input': factory(driver).define_element(self.ms_password_input),
            'ms_sign_in_button': factory(driver).define_element(self.ms_sign_in_button),
            'ms_yes_button': factory(driver).define_element(self.ms_yes_button),
            'challenge_failed': factory(driver).define_element(self.challenge_failed),
            'password_label': factory(driver).define_element(self.password_label),
            'recaptcha_container': factory(driver).define_element(self.recaptcha_container),
            'duo_container': factory(driver).define_element(self.duo_container),
            'user_name_input_with_social': factory(driver).define_text_input(self.user_name_input_with_social),
            'user_next_button_with_social': factory(driver).define_element(self.user_next_button_with_social),
            'recaptcha_container_social_login_enabled':
                factory(driver).define_element(self.recaptcha_container_social_login_enabled),
        }

        super().__init__(driver, elements)

    def is_page_loaded(self):
        self.elements['user_name_input'].wait_for_visible()
        return self.driver.wait_for_visible_element(self.user_name_input) is not None

    def wait_for_page_to_load(self, wait_time=UIPage.SHORT_DELAY, required=True, wait_for_ready=False):
        super().wait_for_page_to_load(wait_time=wait_time, required=required, wait_for_ready=wait_for_ready)

    def login(self, user_name, password):
        self.elements['user_name_input'].clear().type(user_name)
        self.elements['user_next_button'].click()
        self.elements['password_input'].type(password)
        self.elements['password_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self

    def set_username(self, user_name):
        self.elements['user_name_input'].type(user_name)
        self.elements['user_next_button'].click()
        return self

    def set_password(self, password):
        self.elements['password_input'].type(password)
        self.elements['password_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self

    def validate_terms_of_use(self, title):
        self.elements['terms_of_use'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title(title)
        self.driver.set_page_load_timeout(30)
        current_url = self.driver.current_url
        self.driver.close_all_but_first_tab()
        return current_url

    def click_privacy_policy(self, title):
        self.elements['privacy_policy'].click()
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title(title)
        self.driver.set_page_load_timeout(30)
        current_url = self.driver.current_url
        self.driver.close_all_but_first_tab()
        return current_url

    def is_authentication_failure_message_displayed(self):
        return self.elements['error_message'].is_displayed()

    def login_after_change_password(self, password):
        self.elements['user_next_button'].click()
        self.elements['password_input'].type(password)
        self.elements['password_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self

    def validate_error_message(self):
        return self.elements['error_message'].get_text()

    def set_security_question(self, answer):
        self.elements['security_question_input'].type(answer)
        self.elements['sq_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self

    def set_admin_sec_ques(self, answer):
        self.elements['admin_sec_ques_input'].type(answer)
        self.elements['admin_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self
    
    def logout(self):
        return UserProfileMenu(self.driver).sign_out()

    def aad_user_login(self, user_name, password):
        self.elements['user_name_input'].clear().type(user_name)
        self.elements['user_next_button'].click()
        self.driver.wait_for_new_window()
        self.elements['ms_password_input'].click()        
        # Unable to type
        actions = ActionChains(self.driver)
        actions.send_keys(password)
        actions.perform()
        self.elements['ms_sign_in_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        self.elements['ms_yes_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self

    def verify_challenge_failed(self):
        assert self.elements['challenge_failed'].get_element() is not None
        assert self.elements['password_label'].get_element() is not None

    def click_next_button(self):
        self.elements['user_next_button'].click()
        return self

    def verify_is_recaptcha_enabled(self, is_social_login_enabled=False):
        if is_social_login_enabled:
            self.elements['recaptcha_container_social_login_enabled'].wait_for_visible()
            result = self.elements['recaptcha_container_social_login_enabled'].is_displayed()
        else:
            self.elements['recaptcha_container'].wait_for_visible()
            result = self.elements['recaptcha_container'].is_displayed()

        return result

    def verify_duo_prompt(self):
        self.elements['duo_container'].wait_for_visible()
        result = self.elements['duo_container'].is_displayed()

        return result

    def login_with_social_identity(self, user_name, password):
        self.elements['user_name_input_with_social'].clear().type(user_name)
        self.elements['user_next_button_with_social'].click()
        self.elements['password_input'].type(password)
        self.elements['password_next_button'].click()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=UIPage.MEDIUM_DELAY)
        return self
