from os import environ
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from .url_helper import UrlHelper
import pandas


class Driver(webdriver.Remote):
    def __init__(self, options, profile=None, base_url=None,
                 ibe_url=None):
        self.base_url = base_url
        self.ibe_url = ibe_url
        super().__init__(browser_profile=profile, options=options, command_executor=environ['SELENIUM_GRID_ADDRESS'])

    def navigate_to(self, url):
        self.get(url)

    def navigate_to_resource(self, resource):
        self.get(UrlHelper().build_url([self.base_url, resource]))

    def wait_for_visible_element(self, by, wait_time=20):

        try:
            return WebDriverWait(self, wait_time).until(
                expected_conditions.visibility_of_element_located(by)
            )
        except Exception:
            return None

    def wait_for_visible_elements(self, by, wait_time=20):
        """ this method does not work!! do not use"""

        try:
            return WebDriverWait(self, wait_time).until(
                expected_conditions.presence_of_all_elements_located(by)
            )
        except Exception:
            return None

    def wait_for_clickable_element(self, by, wait_time=20):

        try:
            return WebDriverWait(self, wait_time).until(
                expected_conditions.element_to_be_clickable(by)
            )
        except Exception:
            return None

    def wait_for_invisible_element(self, by, wait_time=20):

        try:
            return WebDriverWait(self, wait_time).until(
                expected_conditions.invisibility_of_element_located(by)
            )
        except Exception:
            return None

    def wait_for_loading_mask_to_disappear(self, wait_time=5):
        elem = self.wait_for_visible_element((By.XPATH, '//div[@class="white-loadmask transparent-mask"]'), 1)
        if elem is not None and elem.is_displayed():
            elem = self.wait_for_invisible_element((By.XPATH, '//div[@class="white-loadmask transparent-mask"]'), wait_time)

    def get_warning_dialog(self):
        return self.wait_for_visible_element((By.XPATH, '//div[contains(concat(" ",@class," ")," dialog-window modal-window ")]'), 2)

    def wait_for_page_ready_state(self, wait_time=15):
        self.wait_for_visible_element((By.XPATH, '//div[@layout_loading_status="1"]'), wait_time)

    def wait_for_transient_element_to_come_and_go(self, by,
                                                  wait_for_appearance_time=5,
                                                  wait_for_disappearance_time=5):
        elem = self.wait_for_visible_element(by, wait_for_appearance_time)
        if elem is not None and elem.is_displayed():
            self.wait_for_invisible_element(by, wait_for_disappearance_time)

    def scroll_element_into_view(self, element):
        self.execute_script("arguments[0].scrollIntoView();", element)

    def fetch_elements(self, by, wait_time=20):
        try:
            return WebDriverWait(self, wait_time).until(
                expected_conditions.presence_of_all_elements_located(by)
            )
        except Exception:
            return None

    def send_element_keys(self, element, value):
        self.wait_for_visible_element(element).clear()
        self.wait_for_visible_element(element).send_keys(value)

    def click_element(self, element):
        self.wait_for_visible_element(element).click()

    def extended_click_element(self, by, duration=.0125):
        element = self.wait_for_clickable_element(by, 5)
        click_and_hold =\
            ActionChains(self)\
            .move_to_element(element)\
            .click_and_hold(element)\
            .pause(duration)\
            .release()

        click_and_hold.perform()

    def hover_over_element(self, by, pause_for=.0125):
        element = self.wait_for_clickable_element(by, 5)
        hover = ActionChains(self).move_to_element(element)\
                                  .pause(pause_for)

        hover.perform()

    def accept_alert(self):
        alert = self.switch_to.alert()
        alert.accept()

    def cancel_alert(self):
        alert = self.switch_to.alert()
        alert.cancel()

    def page_loaded(self, loaded_element):
        if self.wait_for_visible_element(loaded_element) is not None:
            return True
        else:
            return False

    def wait_for_new_window(self, default_wait=20):
        try:
            handles_before = self.window_handles
            return WebDriverWait(self, default_wait).until(
                expected_conditions.new_window_is_opened(handles_before)
            )
        except Exception:
            return

    def switch_to_window_by_title(self, title):
        window_found = False

        for _ in self.window_handles:
            self.switch_to.window(_)
            if self.title == title:
                window_found = True
                break

        if window_found is False:
            raise Exception('Window {} not found'.format(title))

    def switch_to_new_tab(self, window_handles):
        if len(self.window_handles) != len(window_handles) + 1:
            raise Exception(f'Expected {len(window_handles) + 1} windows, found {len(self.window_handles)}')

        for _ in self.window_handles:
            if _ not in window_handles:
                self.switch_to.window(_)
                return

    def switch_to_active_tab(self):
        self.switch_to.window(self.window_handles[-1])
        return

    def close_all_but_first_tab(self):
        for _ in self.window_handles:
            if _ != self.window_handles[0]:
                self.switch_to.window(_)
                self.close()
        self.switch_to.window(self.window_handles[0])
        self.switch_to.default_content()

    def get_clipboard_contents(self):
        try:
            return pandas.read_clipboard()
        except:
            self.get_screenshot_as_png()
            raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.quit()
