class RemoteCredentials(dict):
    def __init__(self, address, port, username, password):
        self['host'] = address
        self['port'] = port
        self['username'] = username
        self['password'] = password
        super().__init__()

    def get_credentials(self, database):
        return self
