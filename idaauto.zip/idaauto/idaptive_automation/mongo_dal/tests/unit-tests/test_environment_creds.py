import unittest
import pytest
from os import environ
from idaptive_automation.mongo_dal import EnvironmentCredentials


MONGOADDR = 'MONGOADDR'
MONGOPORT = 'MONGOPORT'
MONGOUSER = 'MONGOUSER'
MONGOPASS = 'MONGOPASS'


@pytest.fixture(scope='session')
def environment_fixture():
    default_address = '192.168.1.3'
    default_port = 27017
    default_user = 'test'
    default_password = 'password1'

    if MONGOADDR not in environ.keys():
        environ[MONGOADDR] = default_address
    if MONGOPORT not in environ.keys():
        environ[MONGOPORT] = default_port
    if MONGOUSER not in environ.keys():
        environ[MONGOUSER] = default_user
    if MONGOPASS not in environ.keys():
        environ[MONGOPASS] = default_password

    return [environ[MONGOADDR],
            int(environ[MONGOPORT]),
            environ[MONGOUSER],
            environ[MONGOPASS]]


def test_initializer_happy_path(environment_fixture):
    address, port, username, password = environment_fixture
    creds = EnvironmentCredentials()
    assert creds.host == address
    assert creds.port == port
    assert creds.username == username
    assert creds.password == password


def test_initializer_environment_variables_not_set():
    environ.pop(MONGOADDR)
    environ.pop(MONGOPORT)
    environ.pop(MONGOUSER)
    environ.pop(MONGOPASS)
    with unittest.TestCase().assertRaises(EnvironmentError):
        EnvironmentCredentials()