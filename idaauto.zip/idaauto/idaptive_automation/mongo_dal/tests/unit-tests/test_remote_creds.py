from idaptive_automation.mongo_dal import RemoteCredentials


def test_initializer_with_port_as_string():
    address = '192.168.1.3'
    port = '2710'
    username = 'test'
    password = 'password'
    creds = RemoteCredentials(**{'address': address,
                                 'port': port,
                                 'username': username,
                                 'password': password})
    assert creds.host == address
    assert type(creds.port) == int
    assert str(creds.port) == port
    assert creds.username == username
    assert creds.password == password


def test_initializer_with_port_as_int():
    address = '192.168.1.3'
    port = 2710
    username = 'test'
    password = 'password'
    creds = RemoteCredentials(**{'address': address,
                                 'port': port,
                                 'username': username,
                                 'password': password})
    assert creds.host == address
    assert creds.port == port
    assert creds.username == username
    assert creds.password == password
