from idaptive_automation.mongo_dal import LocalHostCredentials


def test_initializer_no_user_creds():
    creds = LocalHostCredentials()
    assert creds.host == '127.0.0.1'
    assert type(creds.port) == int
    assert creds.port == 27017
    assert creds.password is None
    assert creds.username is None


def test_initializer_with_user_creds():
    username = 'test'
    password = 'password'
    creds = LocalHostCredentials(**{'username': username,
                                    'password': password})
    assert creds.host == '127.0.0.1'
    assert type(creds.port) == int
    assert creds.port == 27017
    assert creds.username == username
    assert creds.password == password
