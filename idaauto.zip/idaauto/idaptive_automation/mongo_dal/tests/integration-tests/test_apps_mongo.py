from idaptive_automation.mongo_dal import AutomationMongoClient
from idaptive_automation.mongo_dal import EnvironmentCredentials
import pytest
import copy
import os
from bson.binary import Binary
import time


@pytest.fixture(scope='session')
def client_fixture(request):
    with AutomationMongoClient(EnvironmentCredentials(), 'apps') as client:
        client.connect()
        yield client, request.config.getoption('tenant')[0]


def test_get_tenant_credentials(client_fixture):
    client, tenant = client_fixture
    credentials = client.get_tenant_credentials(tenant)
    assert credentials is not None


def test_connect(client_fixture):
    with AutomationMongoClient(EnvironmentCredentials(), 'idaptiveqa') as client:
        client.connect()


def test_find_one(client_fixture):
    client, tenant = client_fixture
    credentials = client.find_one('credentials', {"tenant_id": tenant})
    assert credentials is not None
    assert credentials['tenant_id'] == tenant


def test_find_many(client_fixture):
    client, tenant = client_fixture
    credentials = client.find_many('credentials', {"tenant_id": tenant})
    assert credentials is not None
    assert len(credentials) == 1
    assert credentials[0]['tenant_id'] == tenant


def test_insert_one(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    test_doc = {'test-field': 'test data'}
    client.insert_one(collection, test_doc)
    doc = client.find_one(collection, {'test-field': 'test data'})
    assert doc is not None


def test_insert_many(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    test_doc = {'test-field': 'test data'}
    doc_count = client.get_collection(collection).count_documents(test_doc)

    client.insert_many(collection, [copy.copy(test_doc), copy.copy(test_doc), copy.copy(test_doc)])
    docs = client.find_many(collection, test_doc)
    assert docs is not None
    assert len(docs) == doc_count + 3


def test_update(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    test_doc = {'test-field': 'test data'}
    client.insert_one(collection, test_doc)
    update = {'connector': {'RadiusService': 'Enabled', 'MachineName': 'ASConnector1', 'DnsHostName': None, 'Name': 'ASConnector1', 'SSHService': 'Disabled', 'SQLServerPlugin': 'Disabled', 'IwaPort': 8443, 'BandwidthKbps': None, 'VMwareVMkernelPluginError': '', 'LDAPServiceInstances': '', 'ADProxy': 'Disabled', 'IwaEnabled': True, 'AppGateway': 'Enabled', 'RadiusServiceDisplay': 'Enabled', 'LastPingAttempted': '/Date(1563554537446)/', 'ID': 'bc136e6f-d4a5-40c4-8e31-f687a565f778', 'Ping': 'Y', 'HttpAPIService': 'Enabled', 'SQLServerPluginError': '', 'Version': '19.4.166.0', 'OracleDatabasePluginError': 'OracleLibraryRequired', 'RadiusExternalServiceDisplay': 'Disabled', 'Branding': None, 'AppGatewayDisplay': 'Enabled', 'IwaHostname': 'ASConnector1', 'LastPing': '/Date(1563554537446)/', 'ADProxyDisplay': 'Disabled', 'HttpAPIServiceError': '', 'IwaHttpPort': 80, 'Forest': None, 'CustomerName': 'hunter.alving@idaptive.com', 'AuditInstallationName': None, 'OracleDatabasePlugin': 'Disabled', 'Online': True, 'LDAPProxyDisplay': 'Enabled', 'LDAPProxy': 'Enabled', 'RadiusExternalService': 'Disabled', 'SAPAsePlugin': 'Disabled', 'RDPService': 'Disabled', 'LogRedirected': None, 'SAPAsePluginError': 'SAPAseLibraryRequired', '_MatchFilter': None, 'VMwareVMkernelPlugin': 'Disabled'}}
    client.update(collection, test_doc, update)
    doc = client.find_one(collection, {'test-field': 'test data', 'connector': {'$exists': True}})
    assert doc is not None


def test_update_many(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    test_doc = {'test-field': 'test data'}
    doc_count = client.get_collection(collection).count_documents(test_doc)

    client.insert_many(collection, [copy.copy(test_doc), copy.copy(test_doc), copy.copy(test_doc)])
    timestamp = time.time()
    update = {'updated': timestamp}
    client.update_many(collection, test_doc, update)
    docs = client.find_many(collection, {'test-field': 'test data', 'updated': timestamp})
    assert docs is not None
    assert len(docs) == doc_count + 3


def test_delete_one(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    test_doc = {'test-field': 'test data'}
    result = client.delete_one(collection, test_doc)
    assert result is not None
    assert result.deleted_count == 1


def test_delete_many(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    test_doc = {'test-field': 'test data'}
    doc_count = client.get_collection(collection).count_documents({})
    result = client.delete_many(collection, test_doc)
    assert result is not None
    assert result.deleted_count == doc_count


def test_empty_collection(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    result = client.empty_collection(collection)
    assert result is not None
    assert result['ok'] == 1.0


def test_drop_collection(client_fixture):
    client, _ = client_fixture
    collection = 'unit_tests'
    result = client.drop_collection(collection)
    assert result['ok'] == 1.0


@pytest.mark.parametrize("filepath, version", [
    (r"C:\Users\hunter.alving\Downloads\Connectors\Idaptive-Management-Suite-19.1-189-win64.zip", "19.1-189"),
    (r"C:\Users\hunter.alving\Downloads\Connectors\Idaptive-Management-Suite-19.2-190-win64.zip", "19.2-190")
])
def test_upload_file(client_fixture, filepath, version):
    client, _ = client_fixture
    if not os.path.isfile(filepath):
        raise FileNotFoundError(F"Could not find file: {filepath}")

    with open(filepath, mode='rb') as file:
        binary = file.read()

    client.insert_one('files', {
        "connector": {
            "version": version,
            "file": Binary(binary)
        }
    })


def test_download_file(client_fixture):
    client, _ = client_fixture
    filepath = os.path.join(os.getenv('USERPROFILE'), 'Downloads', 'Idaptive-Management-Suite-win64.zip')
    if not os.path.isfile(filepath):
        raise FileNotFoundError(F"Could not find file: {filepath}")

    with open(filepath, mode='rb') as file:
        binary = file.read()

    client.insert_one('binary-test', {"connector": Binary(binary)})


def test_count(client_fixture):
    client, _ = client_fixture
    collection = 'ldapUsers'
    count = client.count(collection, {})
    assert count is not None
    assert count == 1018


def test_distinct(client_fixture):
    client, _ = client_fixture
    collection = 'ldapUsers'
    groups = client.distinct(collection, 'groups', {'ldapServer': 'Apps-LDAP1'})
    assert groups is not None
