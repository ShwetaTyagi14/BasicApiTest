# mongo_dal

This project contains the Data Access Layer for MongoDB.


It contains only basic functionality for CRUD operations - there are no helper methods. The reason for this is to allow it to remain server agnostic - it does not rely on a any particular database structure. It doesn't know anything about the database structure, and doesn't care. It only understands basic CRUD operations in MongoDB. The one exception to this is the ```get_tenant_credentials(self, tenant_id)``` method provided for backwards compatibility with earlier versions of the client

This Mongo client supports authentication against the database you are trying to access, meaning it does not (at the time of this writing) support server-level authentication. If you are trying to access data across multiple databases, you will need one client for each database

This client supports 3 different types of authentication:
### EnvironmentCredentials
```python

"""
    Use this class to retrieve mongo credentials from the following environment variables:

        MONGOAUTOMATION - if this variable exists, the others are ignored. Use this to store
            any valid json object that represents the mongo config you want to use. It will be
            deserialized to the 'mongo' property

            This class supports the following json structure:
            {
                "<databasename>": {
                    "host": "<mongodb-ip>",
                    "port": <mongodb-port>,
                    "username": "<username>",
                    "password": "<password>"
                },
                "<databasename>": {
                    "host": "<mongodb-ip>",
                    "port": <mongodb-port>,
                    "username": "<username>",
                    "password": "<password>"
                }
            }
            This example provides the credentials for authenticating to 2 different Mongo databases,
            which could be located on 2 different servers

        ** This section is for legacy support - use MONGOAUTOMATION for new applications **
        MONGOADDR (DEPRECATED) - the IP address of the Mongo server
        MONGOPORT (DEPRECATED) - the port that the server listens on
        MONGOUSER (DEPRECATED) - the username for authenticating to the server
        MONGOPASS (DEPRECATED) - the password for authentication to the server

    """

```

### LocalHostCredentials
```python
"""
Use this class to create credentials for connecting to Mongo server on localhost
"""
```
### RemoteCredentials
```python
"""
Use this class to create credentials for connecting to Mongo server on a remote server and passing the authentication credentials directly to the constructor
"""
```

## Basic usage example:
```python
"""
This example creates a client that pulls its credentials from environment variables, 
authenticates against the 'apps' database, connects to the Mongo server, and retrieves a cloud user on the tenant under test,
then closes the connection
"""
with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
    user = client.find_one('cloudUsers',
                           {'tenant': session_fixture['tenant']})
    if user is None:
        raise Exception(f'No cloud users found for tenant {session_fixture["tenant"]}')
```

For more usage examples, refer to the [main idaptive-automation repo README.md file](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/readme.md)