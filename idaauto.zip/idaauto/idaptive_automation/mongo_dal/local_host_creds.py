class LocalHostCredentials:
    """
    Use this class to create credentials for connecting to Mongo server on localhost
    """
    def __init__(self, username=None, password=None):
        self.host = '127.0.0.1'
        self.port = 27017
        self.username = username
        self.password = password

    def get_credentials(self, database):
        return self
