from os import environ
import json


class EnvironmentCredentials(dict):
    """
    Use this class to retrieve mongo credentials from the following environment variables:

        MONGOAUTOMATION - if this variable exists, the others are ignored. Use this to store
            any valid json object that represents the mongo config you want to use. It will be
            deserialized to the 'mongo' property

            This class supports the following json structure:
            {
                "database1": {
                    "host": "<mongodb-ip>",
                    "port": <mongodb-port>,
                    "username": "<username>",
                    "password": "<password>"
                },
                "database2": {
                    "host": "<mongodb-ip>",
                    "port": <mongodb-port>,
                    "username": "<username>",
                    "password": "<password>"
                }
            }
            This example provides the credentials for authenticating to 2 different Mongo databases,
            which could be located on 2 different servers

        ** This section is for legacy support - use MONGOAUTOMATION for new applications **
        MONGOADDR (DEPRECATED) - the IP address of the Mongo server
        MONGOPORT (DEPRECATED) - the port that the server listens on
        MONGOUSER (DEPRECATED) - the username for authenticating to the server
        MONGOPASS (DEPRECATED) - the password for authentication to the server

    """
    def __init__(self):
        creds = environ.get('MONGOAUTOMATION')
        if creds:
            self['mongo'] = json.loads(creds)
        else:
            try:
                self['host'] = environ['MONGOADDR']
                self['port'] = int(environ['MONGOPORT'])
                self['username'] = environ['MONGOUSER']
                self['password'] = environ['MONGOPASS']
            except:
                raise EnvironmentError("""\n\n****************************************
                Mongo server address environment variables not set.
                Use the help command to see requirements
                ****************************************\n\n""")
        super().__init__()

    def get_credentials(self, database):
        if 'mongo' not in self.keys():
            return self
        if database not in self['mongo'].keys():
            raise Exception(f'No credentials found for database named: {database}')
        return self['mongo'][database]
