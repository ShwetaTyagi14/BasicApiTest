from pymongo import MongoClient
from bson.binary import Binary, STANDARD
from bson.codec_options import CodecOptions
import os


class AutomationMongoClient:
    def __init__(self, credentials, database_name, server_timeout_ms=5000):
        self.credentials = credentials
        self.database_name = database_name
        self.serverSelectionTimeoutMS = server_timeout_ms
        self.database = None
        self.client = None

    def connect(self):
        creds = self.credentials.get_credentials(self.database_name)
        if self.database_name == 'idaptiveqa':
            self.client = MongoClient(host=creds['host'],
                                      port=creds['port'],
                                      username=creds['username'],
                                      password=creds['password'],
                                      serverSelectionTimeoutMS=self.serverSelectionTimeoutMS)
        else:
            self.client = MongoClient(host=creds['host'],
                                      port=creds['port'],
                                      username=creds['username'],
                                      password=creds['password'],
                                      authSource=self.database_name,
                                      serverSelectionTimeoutMS=self.serverSelectionTimeoutMS)
        self.client.server_info()
        self.database = self.client[self.database_name]

        return self

    def find_one(self, collection, query):
        document = self.get_collection(collection).find_one(query)

        if document is not None and "_id" in document:
            document.pop('_id', None)
        return document

    def find_many(self, collection, query, limit=50):
        documents = [document for document in self.get_collection(collection).find(query).limit(limit)]
        if documents is None:
            return documents

        [document.pop('_id', None) for document in documents if "_id" in document]
        return documents

    def random_sample(self, collection, limit=50):
        agg_query = [{'$sample': {'size': limit}}]
        documents = [document for document in self.get_collection(collection).aggregate(agg_query)]
        if documents is None:
            return documents

        [document.pop('_id', None) for document in documents if "_id" in document]
        return documents

    def random_cursor(self, collection, limit=50):
        agg_query = [{'$sample': {'size': limit}}]
        for document in self.get_collection(collection).aggregate(agg_query):
            if "_id" in document:
                document.pop('_id', None)
            yield document

    def delete_one(self, collection, query):
        return self.get_collection(collection).delete_one(query)

    def delete_many(self, collection, query):
        return self.get_collection(collection).delete_many(query)

    def get_collection(self, collection):
        return self.database.get_collection(collection)

    def drop_collection(self, name):
        return self.database.drop_collection(name)

    def empty_collection(self, collection):
        return self.get_collection(collection).remove()

    def insert_one(self, collection, json):
        return self.get_collection(collection).insert_one(json).inserted_id

    def insert_many(self, collection, json):
        return self.get_collection(collection).insert_many(json)

    def get_tenant_credentials(self, tenant_id):
        creds = self.find_one('test_tenants', {"tenant": tenant_id})
        if creds is None:
            raise Exception(f'No tenant found with ID: {tenant_id}')

        return creds

    def upsert(self, collection, query, update):
        self.get_collection(collection).update(query, update, upsert=True)

    def update(self, collection, query, update):
        self.get_collection(collection).update_one(query, {'$set': update})

    def update_many(self, collection, query, update):
        self.get_collection(collection).update_many(query, {'$set': update})

    def push(self, collection, query, push):
        self.get_collection(collection).update_one(query, {'$push': push})

    def pull(self, collection, query, push):
        self.get_collection(collection).update_one(query, {'$pull': push})

    def upload_binary(self, binary, collection):
        return self.get_collection(collection).insert_one(Binary(binary))

    def count(self, collection, query):
        return self.get_collection(collection).count(query)

    def distinct(self, collection, value, query):
        return self.get_collection(collection).distinct(value, query)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.client is not None:
            self.client.close()
