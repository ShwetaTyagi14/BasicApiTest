from idaptive_automation.api_helpers import ApiBase


class ExtDataApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.additional_attributes_created = []
        super().__init__(api_session, auto_clean, db_metrics)

    def get_additional_attributes(self, assert_success=True):
        """
        Calls the /ExtData/GetSchema endpoint
        :return: the Result property of the API response
        """
        payload = {
            "Table": "users",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
        }

        return self.api_session.post(None,
                                     '/ExtData/GetSchema',
                                     payload,
                                     assert_success).result()

    def create_additional_attr(self, attr_name, type, description, editable, assert_success=True):
        """
        Calls the '/ExtData/UpdateSchema' endpoint
        :param editable:
        :param attr_name:
        :param type:
        :param description:
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        payload = {
            "Table": "users",
            "Columns": {
                attr_name: {
                    "Name": attr_name,
                    "Type": type,
                    "UserEditable": editable,
                    "Description": description
                }
            }
        }

        response = self.api_session.post('creating additional attribute',
                                         '/ExtData/UpdateSchema',
                                         payload,
                                         assert_success)
        if assert_success and not response.success():
            raise Exception(response.message())

        if response.success():
            self._mark_for_auto_clean(attr_name, self.additional_attributes_created)
        return response

    def delete_additional_attrs(self, attr_names, assert_success=True):
        """
        Calls the '/ExtData/UpdateSchema' endpoint
        :param attr_names: The names of the attributes to delete
        :param assert_success: Check for a success response
        :return: None
        """
        columns = self.get_additional_attributes()['Columns']

        to_remove = [c for c in columns if c['Name'] in attr_names]
        assert len(to_remove) == len(attr_names), f'Attempt to delete one or more attributes that don\'t exist'

        payload = {
            "Table": "users",
            "Columns": [{c['Name']: c} for c in columns if c not in to_remove] or {}
        }

        return self.api_session.post(None,
                                     '/ExtData/UpdateSchema',
                                     payload,
                                     assert_success)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.additional_attributes_created and self.delete_additional_attrs(self.additional_attributes_created)
