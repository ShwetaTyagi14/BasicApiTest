from .api_base import ApiBase


class JobApi(ApiBase):
    def request_app_access(self, payload, assert_success=True):
        """
        Calls '/JobFlow/Startjob'
        :param payload: the payload to send with the request
        :param assert_success: Check for a success response
        :param db_metrics: this flag determines if a metric db record should be inserted
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/JobFlow/Startjob',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response.result()

    def approve_app_access_request(self, payload, assert_success=True):
        """
        Calls '/JobFlow/Event'
        :param payload: the payload to send with the request
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/JobFlow/Event',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response.result()

    def deny_app_access_request(self, payload, assert_success=True):
        """
        Calls '/JobFlow/Event'
        :param payload: the payload to send with the request
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/JobFlow/Event',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response.result()

    def get_my_jobs(self, payload, assert_success=True):
        """
        Calls '/JobFlow/getmyjobs'
        :param payload: the payload to send with the request
        :param assert_success: Check for a success response
        :return: The 'Result.Results' property of the response object
        """
        response = self.api_session.post('',
                                         '/JobFlow/getmyjobs',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response.results()
