import time
from urllib.parse import quote
from idaptive_automation.api_client import ApiSession
from .api_base import ApiBase
from .user_management_helper import  UserMgmt
from .cdirectoryservice_helper import CDirectoryService
from .json_helper import fix_ms_json_dates
from idaptive_automation.api_payloads import RedRock, BulkUserImport, DirectoryServicesQuery, CloudUser, \
    DirectoryServicesGroupQuery


class UserApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.cdservice = CDirectoryService(api_session)
        self.users_created = []
        super().__init__(api_session, auto_clean, db_metrics)

    def create_cloud_user(self, payload, assert_success=True):
        """
        Calls the '/cdirectoryservice/createuser' endpoint
        :param payload: the user creation payload
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        payload['Password'] = quote(payload['Password'])
        payload['confirmPassword'] = quote(payload['confirmPassword'])
        response = self.api_session.post('creating idaptive cloud user',
                                         '/cdirectoryservice/createuser',
                                         payload,
                                         False)
        if assert_success and not response.success():
            raise Exception(response.message())

        if response.success():
            self._mark_for_auto_clean(payload['Name'], self.users_created)
        return response

    def create_cloud_user_if_not_exists(self, payload, assert_success=True):
        """
        Convenience method for creating cloud user safely
        Calls the '/cdirectoryservice/createuser' endpoint
        :param payload: the user creation payload
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.get_user_info(payload['Name'], assert_success=False)
        if response.result()['FullCount'] == 1:
            return response.results()[0]['Row']['ID']

        return self.create_cloud_user(payload, assert_success).result()

    def create_interactive_user(self, name_suffix, username,
                                send_invite=True, assert_success=True):
        """
        Creates an interactive user
        :param name_suffix: the suffix for the user
        :param username: the username
        :param send_invite: send an invite?
        :param assert_success: Check for a success response
        :return: a dictionary object
        """
        payload = CloudUser(name_suffix, username).to_payload()
        payload['SendEmailInvite'] = send_invite
        response = self.create_cloud_user(payload, assert_success)
        payload['Uuid'] = response.result()
        return payload

    def create_invited_user(self, name_suffix, username,
                            assert_success=True):
        """
        Creates a user and sends an invite
        :param name_suffix: the suffix for the user
        :param username: the username
        :param assert_success: Check for a success response
        :return: a dictionary object
        """
        return self.create_interactive_user(name_suffix,
                                            username,
                                            send_invite=True,
                                            assert_success=assert_success)

    def create_service_user(self, name_suffix, username,
                            assert_success=True):
        """
        Creates a service user
        :param name_suffix: the suffix for the user
        :param username: the username
        :param assert_success: Check for a success response
        :return: a dictionary object
        """
        payload = CloudUser(name_suffix, username).to_payload()
        payload['InEverybodyRole'] = False
        result = self.create_cloud_user(payload, assert_success)
        payload['Uuid'] = result.result()
        return payload

    def delete_user(self, username):
        """
        Deletes a user
        :param username: the username of the user to delete
        :return: None
        """
        user_id = self.get_user_info(username)['Row']['ID']
        response = UserMgmt(self.api_session).remove_users({'Users': [user_id]})
        assert response.success()

    def wait_for_user_and_delete(self, username, wait_time=120):
        """
        Waits for a user to be created, then delete the user
        Not meant to be invoked directly
        :param username: the username of the user to delete
        :param wait_time: how long to wait
        :return: None
        """
        response = user_id = None
        try_count = 0
        while try_count < wait_time / 10 and (not response or len(response.results()) == 0):
            response = self.get_user_info(username.lower(), False)
            if len(response.results()) > 0:
                user_id = response.results()[0]['Row']['ID']
            else:
                time.sleep(10)
                try_count += 1

        if user_id is None:
            return

        response = UserMgmt(self.api_session).remove_users({'Users': [user_id]})
        assert response.success()

    def wait_for_user_invited_status(self, username, wait_time=10):
        """
        Waits for a user's status to be changed to 'Invited'
        :param username: the username of the user in question
        :param wait_time: how long to wait
        :return: self
        """
        status = None
        try_count = 0
        start_time = time.time()

        while status is None or status != 'Invited':
            if try_count >= wait_time:
                raise TimeoutError(f'Wait for user to reach "Invited" status timed out. Status found: {status}')
            try_count += 1
            status = self.get_user_info(username)['Row']['StatusEnum']
            if status != 'Invited':
                time.sleep(1)

        end_time = time.time()
        self._record_metric('inviteSingleUser', {
            'startTime': start_time,
            'endTime': end_time,
            'elapsedTime': end_time - start_time
        })
        return self

    def authenticate_as_user(self, username, password):
        """
        Creates a new API client authenticated as the user
        :param username: the username for authentication
        :param password: the password for authentication
        :return: An ApiSession object
        """
        session = ApiSession(self.api_session.base_url,
                             self.api_session.tenant_id,
                             username,
                             password,
                             test_name=self.api_session.test_name)
        return session

    def activate_user(self, username, password):
        """
        Logs in as a user, then logs out
        :param username: the username for authentication
        :param password: the password for authentication
        :return: self
        """
        session = ApiSession(self.api_session.base_url,
                             self.api_session.tenant_id,
                             username,
                             password,
                             test_name=self.api_session.test_name)
        session.logout()
        return self

    def lock_user_account(self, username):
        """
        Locks a user's account
        :param username: the username of the account to lock
        :return: the 'Result' property of the response
        """
        return self._set_user_state(username, 'Locked')

    def lock_user_account_by_uuid(self, uuid):
        """
        Locks a user's account
        :param uuid: the uuid of the account to lock
        :return: the 'Result' property of the response
        """
        return self._set_user_state_by_uuid(uuid, 'Locked')

    def unlock_user_account(self, username):
        """
        Unlocks a user's account
        :param username: the username of the account
        :return: the 'Result' property of the response
        """
        return self._set_user_state(username, 'None')

    def _set_user_state(self, username, state):
        user_id = self.get_user_info(username)['Row']['ID']

        payload = {
            'ID': f'{user_id}',
            'state': f'{state}'
        }
        response = self.cdservice.set_user_state(payload)
        assert response.success()
        return response.result()

    def _set_user_state_by_uuid(self, uuid, state):
        payload = {
            'ID': uuid,
            'state': f'{state}'
        }
        response = self.cdservice.set_user_state(payload)
        assert response.success()
        return response.result()

    def get_user_info(self, username, assert_success=True):
        """
        Gets the user info via RedRock query
        :param username: the username for the user in question
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response object
        """
        sel = 'select'
        script = f'{sel} * FROM (Select ID, DisplayName, Email, LastInvite, LastLogin, SourceDsLocalized, SourceDsType, Status, StatusEnum, Username, ServiceUser, UserType from User) WHERE Username = "{username}"'
        response = self.api_session.post('Getting user info',
                                         '/RedRock/query',
                                         RedRock(script).to_payload(),
                                         assert_success)
        if not assert_success:
            return response
        if response.result()['FullCount'] == 1:
            return response.results()[0]
        return response.result()

    def get_all_users(self):
        """
        Gets all users via RedRock query
        :return: the Result.Results() property of the response
        """
        sel = 'select'
        response = self.api_session.post('Getting user info',
                                         '/RedRock/query',
                                         RedRock(f'{sel} * FROM User', 'Username').to_payload())
        assert response.success()
        users = response.results()
        [fix_ms_json_dates(user) for user in users]
        return users

    def get_all_cloud_users(self):
        """
        Gets a list of all cloud users for the tenant
        :return: a list of dictionaries
        """
        return self.cdservice.get_users()

    def get_users_from_csv_file(self, file_name, file_path,
                                assert_success=True, ou=False):
        """
        Calls '/cdirectoryservice/GetUsersFromCsvFile'
        :param file_name: the name of the file
        :param file_path: the path to the file
        :param assert_success: Check for a success response
        :param ou: If file is for OU Bulk Import
        :return: The full response in the format of an APIResponse object
        """
        files = {
            'Filename': (None, file_name),
            'Icon': (file_name, open(file_path, 'r'), 'application/vnd.ms-excel')
        }

        url_ext = ''
        if ou:
            url_ext = '?ImportType=UpdateBulkOrg'

        response = self.api_session.upload_file('Bulk user file',
                                                    '/cdirectoryservice/GetUsersFromCsvFile',
                                                    files,
                                                    assert_success, url_ext)
        if assert_success:
            [self.users_created.append(user['Row']['Login Name']) for user in response.results()]
        return response

    def get_cloud_user_if_exists(self, username):
        """
        Gets the user info for the username if the user exists
        :param username: The username to query
        :return: the user info or None
        """
        user = self.get_user_info(username)
        if 'Row' in user.keys():
            return user
        return None

    def wait_for_user_to_exist(self, username, wait_time=120):
        """
        Waits for a user to be created by a job
        :param username: the username of the user that is being created by a job
        :param wait_time: how long to wait
        :return: (Success)Bool
        """
        response = user_id = None
        try_count = 0
        while try_count < wait_time / 10 and (not response or len(response.results()) == 0):
            response = self.get_user_info(username.lower(), False)
            if len(response.results()) > 0:
                user_id = response.results()[0]['Row']['ID']
            else:
                time.sleep(10)
                try_count += 1

        if user_id is None:
            return False
        else:
            return True

    def wait_for_user_to_be_deleted(self, username, wait_time=120):
        """
        Waits for a user to be deleted by a job
        :param username: the username of the user that is being deleted by a job
        :param wait_time: how long to wait
        :return: (Success)Bool
        """
        response = self.get_user_info(username.lower(), False)
        if len(response.results()) > 0:
            user_id = response.results()[0]['Row']['ID']
        else:
            return True
        try_count = 0
        while try_count < wait_time / 10 and (not len(response.results()) == 0):
            response = self.get_user_info(username.lower(), False)
            if len(response.results()) == 0:
                user_id = None
            else:
                time.sleep(10)
                try_count += 1

        if user_id is None:
            return True
        else:
            return False

    def submit_bulk_users(self, return_id,
                          admin_email,
                          send_invite,
                          assert_success=True):
        """
        Calls '/cdirectoryservice/SubmitUploadedFile'
        :param return_id: the id of the file
        :param admin_email: the email to notify once the job is complete
        :param send_invite: Send invites to users?
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        payload = BulkUserImport(return_id, admin_email, send_invite).to_payload()
        return self.api_session.post('Uploading bulk user',
                                     '/cdirectoryservice/SubmitUploadedFile',
                                     payload,
                                     assert_success)

    def get_directory_services_info(self, assert_success=True):
        """
        Gets a list of all directory services for the tenant
        :param assert_success: Check for a success response
        :return: a list of dictionaries
        """
        response = self.api_session.post('Getting directory services info',
                                         '/core/GetDirectoryServices',
                                         assert_success=assert_success)
        if not assert_success:
            return response
        return [row['Row'] for row in response.results()]

    def get_directory_service_by_name(self, name, assert_success=True):
        """
        Gets the directory service info for a named directory service
        :param name: the name of the directory services in question
        :param assert_success: Check for a success response
        :return:    a list of dictionaries
        """
        matching = [row for row in self.get_directory_services_info(assert_success) if row['Name'] == name]
        return None if len(matching) != 1 else matching[0]

    def get_directory_service_uuid_by_name(self, name, assert_success=True):
        """
        Gets the directory service info for a named directory service
        :param name: the name of the directory services in question
        :param assert_success: Check for a success response
        :return:    a list of dictionaries
        """
        uuid = None
        for row in self.get_directory_services_info(assert_success):
            if row['DisplayNameShort'] == name:
                uuid = row['directoryServiceUuid']
        return uuid

    def get_ou_tree_contents(self, payload, admin_account_status, assert_success=True):
        return self.api_session.post('Get OU Tree Contents',
                                     f'/Core/GetOUTreeContents?getAdminAccountStatus={admin_account_status}',
                                     payload,
                                     assert_success)

    def get_domain_controllers_for_domain(self, payload, assert_status=True):
        return self.api_session.post('Retrieving Domain Controllers',
                                     '/Core/GetDomainControllersForDomain',
                                     payload,
                                     assert_status)

    def targeted_directory_services_query(self, payload, assert_success=True):
        """
        Calls '/UserMgmt/DirectoryServiceQuery'
        :param payload: the payload of the request
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Directory service query',
                                     '/UserMgmt/DirectoryServiceQuery',
                                     payload,
                                     assert_success)

    def search_directory_services(self, query, directory_services_ids,
                                  assert_success=True):
        """
        Calls '/UserMgmt/DirectoryServiceQuery'
        :param query: the search query
        :param directory_services_ids: the directory services to query
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Directory service query',
                                     '/UserMgmt/DirectoryServiceQuery',
                                     DirectoryServicesQuery(query, directory_services_ids).to_payload(),
                                     assert_success)

    def search_directory_services_by_email(self, query, directory_services_ids, page_number=1,
                                  assert_success=True):
        """
        Calls '/UserMgmt/DirectoryServiceQuery'
        :param query: the search query
        :param directory_services_ids: the directory services to query
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Directory service query',
                                     '/UserMgmt/DirectoryServiceQuery',
                                     DirectoryServicesQuery(query, directory_services_ids).to_email_payload(page_number),
                                     assert_success)

    def _search_ds(self, payload, assert_success=True):
        return self.api_session.post('Directory service query',
                                     '/UserMgmt/DirectoryServiceQuery',
                                     payload,
                                     assert_success)

    def get_group_info_by_name(self, group_name, ds_uuids):
        """
        Gets the DS info for a group
        :param group_name: the name of the group
        :param ds_uuids: the ids of the directory services to search
        :return: The first group info found
        """
        payload = DirectoryServicesGroupQuery(group_name, ds_uuids).to_payload()
        group_info = self._search_ds(payload)
        assert 'Group' in group_info.result().keys(), f'Group look up for {group_name} in DS failed'
        group_info = [row['Row'] for row in group_info.result()['Group']['Results'] if row['Row']['DisplayName'] == group_name]
        assert len(group_info) == 1, f'DS search for {group_name} returned {len(group_info)} groups, expected 1'
        return group_info[0]

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.auto_clean:
            stop_time = time.time() + 120
            for username in self.users_created:
                if time.time() < stop_time:
                    self.wait_for_user_and_delete(username)
