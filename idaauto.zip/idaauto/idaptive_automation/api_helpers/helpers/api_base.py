import atexit
from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials


class ApiBase:
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.api_session = api_session
        self.auto_clean = auto_clean
        self.tenant_id = self.api_session.tenant_id
        self.db_metrics = db_metrics
        if db_metrics:
            atexit.register(self._record_metrics)

    def _mark_for_auto_clean(self, entity, array):
        """
        Meant for internal use - do not invoke directly
        """
        if self.auto_clean:
            array.append(entity)

    def _record_metric(self, name, data):
        """
        Meant for internal use - do not invoke directly
        """
        if self.db_metrics:
            metric = {
                'timeStamp': self.api_session.time_stamp,
                'tenant': self.tenant_id,
                'name': name,
                'data': data
            }
            self.api_session.metrics.append(metric)

    def _record_metrics(self):
        """
        Meant for internal use - do not invoke directly
        """
        if not self.db_metrics:
            return
        api_metrics = None
        try:
            api_metrics = self.api_session.metrics
            self.api_session.metrics = []
            if api_metrics is not None and len(api_metrics) > 0:
                with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
                    client.insert_many('testMetrics', api_metrics)
        except Exception as e:
            print(f"Failed to insert test metrics. Exception: {e}\n{api_metrics}")
