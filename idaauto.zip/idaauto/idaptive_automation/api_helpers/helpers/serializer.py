import json
from builtins import staticmethod
from collections import namedtuple


class Serializer:
    @staticmethod
    def deserialize_json(json_string):
        """
        Legacy method - no documentation
        :param json_string:
        :return:
        """
        try:
            obj = json.loads(json.dumps(json_string), object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
            return obj
        except:
            return json_string
