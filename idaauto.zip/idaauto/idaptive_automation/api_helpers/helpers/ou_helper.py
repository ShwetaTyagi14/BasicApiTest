from .api_base import ApiBase
from idaptive_automation.api_payloads import RedRock
from .json_helper import fix_ms_json_dates
import time


class OUHelper(ApiBase):
    def __init__(self, api_session, auto_clean=True, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.ous_created = []
        self.ou_users_added = []
        self.ou_roles_added = []
        self.ou_groups_added = []
        self.clean_up_tasks = []
        super().__init__(api_session, auto_clean, db_metrics)

    def create_ou(self, ou_name, description=""):
        """
        Creates OU(Organizational Unit) for Delegated Administration
        ou_name: Organizational Unit ID
        description: Description of OU(IE Team Name, Manage India Team or Off Site Contractors)

        """
        payload = {
            "Name": ou_name,
            "Description": description
        }
        response = self.api_session.post('',
                                         '/Org/Create',
                                         payload)
        ou_data = None

        if response.success():
            ou_data = response.result()
            self._mark_for_auto_clean(ou_data['ID'], self.ous_created)

        return response.result()

    def create_ou_return_response(self, ou_name, description="", assert_success=True):
        """
                Creates OU(Organizational Unit) for Delegated Administration
                ou_name: Organizational Unit ID
                description: Description of OU(IE Team Name, Manage India Team or Off Site Contractors)
                assert_success: assert if post request for the API is successful
                """
        payload = {
            "Name": ou_name,
            "Description": description
        }
        response = self.api_session.post('',
                                         '/Org/Create',
                                         payload,
                                         assert_success)
        ou_data = None

        if response.success():
            ou_data = response.result()
            self._mark_for_auto_clean(ou_data['ID'], self.ous_created)

        return response

    def get_ou(self, ou_id):
        """
        Gets specific OU(Organizational Unit) info
        ou_id: OU ID
        """
        payload = {
            "OrgId": ou_id
        }

        response = self.api_session.post('',
                                         '/Org/Get',
                                         payload)
        return response.result()

    def get_ou_name(self, ou_id):
        """
        Gets specific OU(Organizational Unit) info
        ou_id: OU ID
        """
        payload = {
            "OrgId": ou_id
        }

        response = self.api_session.post('',
                                         '/Org/Get',
                                         payload)
        ou_info = response.result()
        return ou_info['Name']

    def delete_ou(self, ou_id):
        """
        Deletes specified OU(Organizational Unit)
        ou_id: OU ID
        """
        payload = {
            "OrgId": ou_id
        }

        response = self.api_session.post('',
                                         '/Org/Delete',
                                         payload)
        return response.success()

    def get_all_ous(self):
        """
        Returns ID, Name, and Description for all OUs(Organizational Unit)
        """
        payload = {}
        response = self.api_session.post('',
                                         '/Org/ListAll',
                                         payload)
        return response.result()

    def get_ou_by_name(self, ou_name):
        """
        Returns ID, Name, and Description for all OUs(Organizational Unit)
        ou_name: Name of OU
        """
        all_ous = self.get_all_ous()
        for ou in all_ous:
            if ou_name == ou['Name']:
                return ou

    def update_ou(self, ou_id, ou_name, description="", assert_success=True):
        """
        Modifies Name and/or description of an OU(Organizational Unit)
        ou_id: OU ID
        ou_name: Updated OU Name
        description: Updated OU Description
        """
        payload = {
            "OrgId": ou_id,
            "Name": ou_name,
            "Description": description
        }
        response = self.api_session.post('',
                                         '/Org/Update',
                                         payload,
                                         assert_success)
        return response

    def get_ou_permissions(self, ou_id):
        """
        Gets administrative rights definition for specific organization
        might not be useful at this time
        ou_id: OU ID
        """
        payload = {
            "OrgId": ou_id
        }
        response = self.api_session.post('',
                                         '/Org/GetPermission',
                                         payload)
        return response.result()

    def grant_ou_permissions(self, ou_id, principal, principal_type, rights):
        """
        Grants permissions to ou
        Principal = userID, groupID or RoleID
        PrincipalType = "User", "Role" or "Group" (Type of the ID being passed in Principal)
        Right = "UserManagement" or "RoleManagement" (Group is managed in LDAP/AD)
        """
        if not isinstance(rights, list):
            rights = [rights]

        payload = {
            "OrgId": ou_id,
            "Grant": [{"Principal": principal,
                       "PrincipalType": principal_type,
                       "Right": rights}]
        }
        response = self.api_session.post('',
                                         '/Org/UpdatePermission',
                                         payload)
        return response.success()

    def revoke_ou_permissions(self, ou_id, principal, principal_type, rights):
        """
        Revokes permissions to ou
        Principal = userID, groupID or RoleID
        PrincipalType = "User", "Role" or "Group" (Type of the ID being passed in Principal)
        Right = "UserManagement" or "RoleManagement" (Group is managed in LDAP/AD)
        """
        if not isinstance(rights, list):
            rights = [rights]

        payload = {
            "OrgId": ou_id,
            "Revoke": [{"Principal": principal,
                        "PrincipalType": principal_type,
                        "Right": rights}]
        }
        response = self.api_session.post('',
                                         '/Org/UpdatePermission',
                                         payload)
        return response.success()

    def add_ou_admin(self, ou_id, principal):
        """
        Add OU Admin
        ID = userID
        """

        payload = {
            "OrgId": ou_id,
            "Grant": [{"Id": principal}]
        }
        response = self.api_session.post('',
                                         '/Org/UpdateAdministrators',
                                         payload)
        return response.success()

    def remove_ou_admin(self, ou_id, principal):
        """
        Remove OU admin
        ID = userID
        """

        payload = {
            "OrgId": ou_id,
            "Revoke": [ principal]
        }
        response = self.api_session.post('',
                                         '/Org/UpdateAdministrators',
                                         payload)
        return response.success()
    
    def get_ou_admins(self, ou_id):
        """
        Gets all OU admins
        :return: the Result.Results() property of the response
        """
        payload = {
            "OrgId": ou_id
        }
        response = self.api_session.post('Getting user info',
                                         '/Org/GetAdministrators',
                                         payload)
        users = response.results()
        [fix_ms_json_dates(user) for user in users]
        return users

    def is_user_ou_admin(self, ou_id, user_id):
        """
        ou_id: Organizational Unit ID
        user_id: the ID of user.
        :return: True or False if the user exists in the OU admin list
        """
        found_user = False
        for ou_user in self.get_ou_admins(ou_id):
            if user_id == ou_user['Row']['ID']:
                found_user = True
        return found_user

    def add_units_to_ou(self, ou_id, unit_ids, unit_type):
        """
        Add member/s from ou
        ou_id: Organizational Unit ID
        unit_ids: the ID or IDs of users, roles, or groups to be added.
        unit_type: "User", "Role", or "Group"
        """
        if not isinstance(unit_ids, list):
            unit_ids = [unit_ids]
        unit_list = []
        for unit in unit_ids:
            unit_list.append({"ID": unit, "Type": unit_type})
        payload = {
            "OrgId": ou_id,
            "New": unit_list
        }
        response = self.api_session.post('',
                                         '/Org/ChangeMembership',
                                         payload)
        if response.success():
            if unit_type == "User":
                self._mark_for_auto_clean(unit_ids, self.ou_users_added)
            elif unit_type == "Role":
                self._mark_for_auto_clean(unit_ids, self.ou_roles_added)
            elif unit_type == "Group":
                self._mark_for_auto_clean(unit_ids, self.ou_groups_added)

        return response.success()

    def remove_units_from_ou(self, ou_id, unit_ids, unit_type):
        """
        Remove member/s from ou
        ou_id: Organizational Unit ID
        unit_ids: the ID or IDs of users, roles, or groups to be removed.
        unit_type: "User", "Role", or "Group"
        """
        if not isinstance(unit_ids, list):
            unit_ids = [unit_ids]
        unit_list = []
        for unit in unit_ids:
            unit_list.append({"ID": unit, "Type": unit_type})
        payload = {
            "OrgId": ou_id,
            "Remove": unit_list
        }
        response = self.api_session.post('',
                                         '/Org/ChangeMembership',
                                         payload)
        return response.success()

    def get_ou_users(self, ou_id):
        """
        Gets all OU users via RedRock query
        :return: the Result.Results() property of the response
        """
        sel = 'select'
        response = self.api_session.post('Getting user info',
                                         '/RedRock/query',
                                         RedRock(f'{sel} * FROM User where OrgID="{ou_id}"', 'Username').to_payload())
        users = response.results()
        [fix_ms_json_dates(user) for user in users]
        return users

    def is_user_in_ou(self, ou_id, user_id):
        """
        ou_id: Organizational Unit ID
        user_id: the ID of user.
        :return: True or False if the user exists in the OU
        """
        found_user = False
        for ou_user in self.get_ou_users(ou_id):
            if user_id == ou_user['Row']['ID']:
                found_user = True
        return found_user

    def get_ou_roles(self, ou_id):
        """
        Gets a list of all roles in OU
        :return: a dictionary object
        """
        payload = RedRock(f"Select ID, COALESCE(Name, ID) AS Name, RoleType, ReadOnly, Description, DirectoryServiceUuid from Role where OrgID='{ou_id}' ORDER BY Name COLLATE NOCASE", "Name")
        response = self.api_session.post(f'Getting roles',
                                         '/RedRock/query',
                                         payload.to_payload())
        return [{"Name": result['Row']['Name'],
                 "ID": result['Row']['ID'],
                 "Description": result['Row']['Description'],
                 "RoleType": result['Row']['RoleType'],
                 "DirectoryServiceUuid": result['Row']['DirectoryServiceUuid']} for result in response.results()]

    def get_ou_roles_using_getrole(self, ou_id):
        """
        Gets a list of all roles in OU using Org/GetRoles API
        :return: a dictionary object
        """
        payload = {
            "OrgId": ou_id
        }
        response = self.api_session.post('',
                                         '/Org/GetRoles',
                                         payload)
        return [{"Name": result['Row']['Name'],
                 "ID": result['Row']['ID']} for result in response.results()]

    def is_role_in_ou(self, ou_id, role_id):
        """
        ou_id: Organizational Unit ID
        role_id: the ID of role.
        :return: True or False if the role exists in the OU
        """
        found_role = False
        for ou_role in self.get_ou_roles_using_getrole(ou_id):
            if role_id == ou_role['ID']:
                found_role = True
        return found_role

    def submit_bulk_ou_users(self, return_id, assert_success=True):
        """
        Calls '/cdirectoryservice/SubmitUploadedFile'
        :param return_id: the id of the file
        :param admin_email: the email to notify once the job is complete
        :param send_invite: Send invites to users?
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        payload = {
            "ReturnID": return_id,
            "ImportType": "UpdateBulkOrg"
        }
        return self.api_session.post('Uploading bulk user',
                                     '/cdirectoryservice/SubmitUploadedFile',
                                     payload,
                                     assert_success)

    def wait_for_user_to_exist_in_ou(self, ou_id, user_id, wait_time=120):
        """
        Waits for a user to be moved to OU by a job
        :param ou_id: the ID of the OU
        :param user_id: the ID of the user that is being created by a job
        :param wait_time: how long to wait
        :return: (Success)Bool
        """
        found = False
        try_count = 0
        response = None
        while try_count < wait_time / 10 and (not response):
            response = self.is_user_in_ou(ou_id, user_id)
            if response:
                found = True
            else:
                time.sleep(10)
                try_count += 1
        return found

    def add_users_to_ou(self, ou_id, user_ids):
        return self.add_units_to_ou(ou_id, user_ids, "User")

    def remove_users_from_ou(self, ou_id, user_ids):
        return self.remove_units_from_ou(ou_id, user_ids, "User")

    def add_roles_to_ou(self, ou_id, role_ids):
        return self.add_units_to_ou(ou_id, role_ids, "Role")

    def remove_roles_from_ou(self, ou_id, role_ids):
        return self.remove_units_from_ou(ou_id, role_ids, "Role")

    def add_groups_to_ou(self, ou_id, group_ids):
        return self.add_units_to_ou(ou_id, group_ids, "Group")

    def remove_groups_from_ou(self, ou_id, group_ids):
        return self.remove_units_from_ou(ou_id, group_ids, "Group")

    def register_cleanup(self, callback):
        self.clean_up_tasks.append(callback)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.auto_clean:
            for ou in self.ous_created:
                for ou_user in self.get_ou_users(ou):
                    self.remove_units_from_ou(ou, ou_user['Row']['ID'], "User")
                for ou_role in self.get_ou_roles(ou):
                    self.remove_units_from_ou(ou, ou_role['ID'], "Role")
                self.remove_units_from_ou(ou, self.ou_groups_added, "Group")
                self.delete_ou(ou)
            for task in self.clean_up_tasks:
                task()
