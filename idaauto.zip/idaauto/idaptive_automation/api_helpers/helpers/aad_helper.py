import os
import subprocess
import platform
from .domain_helper import DomainHelper


class AzureActiveDirectoryHelper(DomainHelper):
    def __init__(self,
                 server_address,
                 domain_name,
                 domain_suffix,
                 email_suffix,
                 username,
                 password,
                 auto_clean=False):
        """
        :param user: the username for authentication on the server
        :param password: the password for authentication
        :param auto_clean: Remove anything this helper creates when it is
        destroyed (must be used in a 'with' block)
        """
        self.username = username
        self.password = password
        self.server_address = server_address
        self.domain_name = domain_name
        self.domain_suffix = domain_suffix
        self.email_suffix = email_suffix
        self.orgs_created = []
        self.groups_created = []
        self.users_created = []
        self.auto_clean = auto_clean

    def find_aad_user(self, search_string):
        file_dir = os.path.dirname(os.path.realpath('__file__'))

        powershell64 = os.path.join(os.environ['SystemRoot'],
                                    'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                    'WindowsPowerShell', 'v1.0', 'powershell.exe')

        ps = subprocess.Popen([powershell64,
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\scripts\\get_aad_users.ps1',
                               search_string,
                               self.username,
                               self.password],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        return str(eval(ps.communicate()[0].decode('utf-8').replace("'", '"')))

    def validate_msoffice_contact(self, email_prefix):
        file_dir = os.path.dirname(os.path.realpath('__file__'))

        powershell64 = os.path.join(os.environ['SystemRoot'],
                                    'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                    'WindowsPowerShell', 'v1.0', 'powershell.exe')

        ps = subprocess.Popen([powershell64,
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\scripts\\get_msol_contact.ps1',
                               email_prefix,
                               self.username,
                               self.password],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        assert contact['Contacts'][0]['EmailAddress'] == f"{email_prefix}@{self.email_suffix}"

    def validate_msol_group_members(self, group_name, user_name, assert_group_only=False, group_member_count=0):
        file_dir = os.path.dirname(os.path.realpath('__file__'))

        powershell64 = os.path.join(os.environ['SystemRoot'],
                                    'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                    'WindowsPowerShell', 'v1.0', 'powershell.exe')

        ps = subprocess.Popen([powershell64,
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\scripts\\get_msol_group_members.ps1',
                               group_name,
                               self.username,
                               self.password],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        group_members = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        member_found = False
        if not assert_group_only:
            for member in group_members['Group']['Members']:
                if member['User'] == f"{user_name.lower()}user1@{self.email_suffix}":
                    member_found = True
            assert member_found is True
        else:
            assert group_members['Group']['Name'].__len__() > 9
        if group_member_count > 0:
            assert group_members['Group']['Members'].__len__() == group_members

    def get_msol_user_attributes(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        powershell64 = os.path.join(os.environ['SystemRoot'],
                                    'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                    'WindowsPowerShell', 'v1.0', 'powershell.exe')

        ps = subprocess.Popen([powershell64,
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\scripts\\get_msol_user_attributes.ps1',
                               user_principal_name,
                               self.username,
                               self.password],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact_attr = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        return contact_attr

    def get_msol_user_all_attributes(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        powershell64 = os.path.join(os.environ['SystemRoot'],
                                    'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                    'WindowsPowerShell', 'v1.0', 'powershell.exe')

        ps = subprocess.Popen([powershell64,
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\scripts\\get_all_msol_user_attributes.ps1',
                               user_principal_name,
                               self.username,
                               self.password],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact_attr = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        return contact_attr

    def validate_msol_preferred_data_value(self, user_name, validate_key, validate_value):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        powershell64 = os.path.join(os.environ['SystemRoot'],
                                    'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                    'WindowsPowerShell', 'v1.0', 'powershell.exe')

        ps = subprocess.Popen([powershell64,
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\scripts\\get_msol_pref_data_location.ps1',
                               user_name,
                               self.username,
                               self.password],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        assert office_rules['Users'][0]['Attributes'][validate_key] == validate_value

    def clean_msoffice_online(self, search_string, group_name=None):
        try:
            file_dir = os.path.dirname(os.path.realpath('__file__'))
            powershell64 = os.path.join(os.environ['SystemRoot'],
                                        'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                        'WindowsPowerShell', 'v1.0', 'powershell.exe')

            ps = subprocess.Popen([powershell64,
                                   '-ExecutionPolicy',
                                   'Unrestricted',
                                   rf'{file_dir}\\scripts\\remove_o365_all_objects_recyclebin.ps1',
                                   search_string,
                                   self.username,
                                   self.password],
                                  stdout=subprocess.PIPE,
                                  cwd=os.getcwd()
                                  )
            result = ps.wait()
            assert result == 0
        except AssertionError:
            file_dir = os.path.dirname(os.path.realpath('__file__'))
            powershell64 = os.path.join(os.environ['SystemRoot'],
                                        'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                        'WindowsPowerShell', 'v1.0', 'powershell.exe')

            ps = subprocess.Popen([powershell64,
                                   '-ExecutionPolicy',
                                   'Unrestricted',
                                   rf'{file_dir}\\scripts\\remove_o365_users_recyclebin.ps1',
                                   search_string,
                                   self.username,
                                   self.password],
                                  stdout=subprocess.PIPE,
                                  cwd=os.getcwd()
                                  )
            result = ps.wait()
            assert result == 0

        try:
            if group_name is not None:
                file_dir = os.path.dirname(os.path.realpath('__file__'))
                powershell64 = os.path.join(os.environ['SystemRoot'],
                                            'SysNative' if platform.architecture()[0] == '32bit' else 'System32',
                                            'WindowsPowerShell', 'v1.0', 'powershell.exe')

                ps = subprocess.Popen([powershell64,
                                       '-ExecutionPolicy',
                                       'Unrestricted',
                                       rf'{file_dir}\\scripts\\remove_o365_groups.ps1',
                                       group_name,
                                       self.username,
                                       self.password],
                                      stdout=subprocess.PIPE,
                                      cwd=os.getcwd()
                                      )
                result = ps.wait()
                assert result == 0
        except:
            pass
