class DomainHelper:
    """
    Under development
    """
    def __init__(self,
                 server_address,
                 domain_name,
                 domain_suffix,
                 email_suffix,
                 username,
                 password):
        self.server_address = server_address
        self.domain_name = domain_name
        self.domain_suffix = domain_suffix
        self.email_suffix = email_suffix
        self.username = username
        self.password = password
