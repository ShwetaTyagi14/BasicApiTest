from io import BytesIO
from zipfile import ZipFile

from .api_base import ApiBase


class ProvisioningApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        self.sources_created = []
        super().__init__(api_session, auto_clean, db_metrics)

    def sync_all(self, payload, assert_success=True):
        response = self.api_session.post('Starting Full Application Synchronization Job',
                                         '/Provisioning/FullDirSyncAll',
                                         payload,
                                         assert_success)

        if not assert_success:
            return response
        return response

    def sync_user(self, user_id, assert_success=True):
        response = self.api_session.post('Starting User Synchronize Job',
                                         f'/Provisioning/SyncUser?id={user_id}',
                                         None,
                                         assert_success)

        if not assert_success:
            return response
        return response

    def request_inbound_sync(self, source_instance_id, sync_type, assert_success=True):
        payload = {
          "instanceId": source_instance_id,
          "syncType": sync_type
        }
        response = self.api_session.post('Starting Inbound Provisioning Synchronize Job',
                                         '/InboundProv/StartSyncJob',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def get_job_result(self, job_id):
        payload = {
          "Args":
          {
            "PageNumber": 1,
            "PageSize": 20,
            "Limit": 100000,
            "SortBy": "JobName",
            "Ascending": True,
            "FilterBy": None,
            "FilterQuery":
            {
              "JobHidden": False
            },
            "Caching": -1
          }
        }

        response = self.api_session.post('Retrieving Job History',
                                         '/Task/GetJobHistory',
                                         payload,
                                         False)
        history_report = None
        for result in response.response['Result']['Results']:
            if result['Entities'][0]['Key'] == job_id:
                history_report = result
                break
        if 'Processed' in history_report['Row']['JobStatus']:
            return history_report
        else:
            return None

    def get_single_job_history(self, job_id, assert_success=True):
        payload = {
            'jobId': job_id,
            'Args': {
                'PageNumber': 1,
                'Limit': 1,
                'PageSize': 1,
                'Caching': -1
            }
        }

        response = self.api_session.post('Retrieving Single Job History',
                                         '/Task/GetSingleJobHistory',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def get_job_report(self, job_id):
        payload = {
            'jobId': job_id
        }

        response = self.api_session.post('Retrieving Job Report',
                                         '/SchedulerHistory/GetJobReport',
                                         payload,
                                         False)
        return response

    def download_sync_job_report(self, file):
        url = f"{self.api_session.base_url}/Core/DownloadFile?path=/Traces/scheduler/{file}"
        report_response = self.api_session.get(url)
        return ZipFile(BytesIO(report_response.content))

    def save_notification_settings(
            self,
            assert_success=True,
            from_email='no-reply@idaptive.com',
            to_email='idaptiveprovisioning@gmail.com'):
        notification_payload = {
            'FromEmail': from_email,
            'ToEmail': to_email,
            'IncludeDebugTrace': True,
            'NotifyOnFull': True,
            'NotifyOnIndividual': False,
            'NotifyOnError': True,
            'DailySync': False
        }
        response = self.api_session.post('Saving Notification Settings',
                                         '/Provisioning/SaveNotificationSettings',
                                         notification_payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def set_administrative_accounts(self, user_name, user_uuid, password, domains, assert_success=True):
        payload = {
            'User': user_name,
            'UserUuid': user_uuid,
            'Password': password,
            'Domains': [domains]
        }
        response = self.api_session.post('Setting Administrative Accounts',
                                         '/ServerManage/SetAdministrativeAccounts',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def reset_notification_settings(self, assert_success=True):
        notification_payload = {
            'FromEmail': "no-reply@centrify.com",
            'ToEmail': "",
            'IncludeDebugTrace': False,
            'NotifyOnFull': False,
            'NotifyOnIndividual': False,
            'NotifyOnError': True,
            'DailySync': False
        }
        response = self.api_session.post('Reset Notification Settings to Default',
                                         '/Provisioning/SaveNotificationSettings',
                                         notification_payload,
                                         assert_success)

        if not assert_success:
            return response
        return response

    def verify_source_creds(self, payload, assert_success=True):
        response = self.api_session.post('Verifying Source Credentials',
                                         '/InboundProv/VerifyWorkdayReadCreds',
                                         payload,
                                         assert_success)

        if not assert_success:
            return response
        return response

    def create_inbound_source(self, payload, assert_success=True):
        response = self.api_session.post('Creating Inbound Source',
                                         '/InboundProv/SaveInstance',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        source_instance_id = self._get_instance_id(payload['Name'])
        self._mark_for_auto_clean(source_instance_id, self.sources_created)
        return source_instance_id

    def create_inbound_source_rule(self, payload, assert_success=True):
        response = self.api_session.post('Creating Inbound Source Rule',
                                         '/InboundProv/SaveRule',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def delete_inbound_source(self, source_instance_id, assert_success=True):
        payload = {'InstanceId': source_instance_id}
        response = self.api_session.post('Deleting Inbound Provisioning Source',
                                         '/InboundProv/DeleteInstance',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        if self.auto_clean:
            self.sources_created.remove(source_instance_id)
        return response.result()

    def delete_all_created_inbound_sources(self):
        for source in self.sources_created:
            self.delete_inbound_source(source)

    def get_all_inbound_sources(self, assert_success=True):
        response = self.api_session.post('Fetching All Saved Inbound Provisioning Sources',
                                         '/InboundProv/QueryInstances',
                                         None,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def ping_inbound(self, assert_success=True):
        response = self.api_session.post('Pinging Inbound',
                                         '/InboundProv/Ping',
                                         None,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def get_source_systems(self, assert_success=True):
        response = self.api_session.post('Get Inbound Sources',
                                         '/InboundProv/GetSourceSystems',
                                         None,
                                         assert_success)
        if not assert_success:
            return response
        return response.response['Result']

    def _get_instance_id(self, source_name):
        instances = self.get_all_inbound_sources().response['Result']
        return next(
            (
                instance for instance in instances
                if instance['Name'] == source_name
            ),
            None
        )['InstanceId']

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.delete_all_created_inbound_sources()
