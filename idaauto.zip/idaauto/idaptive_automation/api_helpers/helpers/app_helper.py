from .api_base import ApiBase
from idaptive_automation.api_payloads import RedRock


class AppHelper(ApiBase):
    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.apps_created = []
        super().__init__(session, auto_clean, db_metrics)

    def import_username_password_app(self, assert_success=True):
        """
        Imports a user-password app to the Admin portal list of apps
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        return self.import_app_by_name("Generic User-Password", assert_success)

    def get_app_from_app_name(self, app_name):
        """
        :param app_name: the name of the app
        :return: dictionary of app data
        """
        app = None
        response = self.get_admin_app_list_plv8()
        for entity in response:
            if app_name == str(entity['Row']['DisplayName']):
                app = entity['Row']
        return app

    def import_app_by_name(self, app_name, assert_success=True):
        """
        Calls '/SaasManage/ImportAppFromTemplate' to import an app template
        :param app_name: the name of the app to import
        :param assert_success: Check for a success response
        :return: the ID of app imported
        """
        payload = {
            "ID": [
                app_name
            ]
        }

        response = self.api_session.post('',
                                         '/SaasManage/ImportAppFromTemplate',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        app_id = response.result()[0]['_RowKey']
        self._mark_for_auto_clean(app_id, self.apps_created)
        return app_id

    def update_application_de(self, payload, assert_success=True):
        """
        Calls '/SaasManage/UpdateApplicationDE' to update the app with the provided payload
        :param payload: The changes desired on the app
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('Updating application',
                                         '/SaasManage/UpdateApplicationDE', payload)

        if assert_success:
            assert response.success(), 'failed to update user/password app'
        return response

    def set_application_permissions(self, payload, assert_success=True):
        """
        Calls the '/SaasManage/SetApplicationPermissions' endpoint to set permissions on an app
        :param payload: the permission payload
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('Setting application permissions',
                                         '/SaasManage/SetApplicationPermissions',
                                         payload,
                                         assert_success)
        return response

    def delete_linked_application(self, app_id, assert_success=True):
        """
        Deletes an app from the Admin Portal app list, but does NOT attempt to remove from the
        list of created applications (as linked apps are automatically created via the Idaptive
        cloud
        :param app_id: The id of the app to delete
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        payload = {
            "_RowKey": [app_id]
        }
        response = self.api_session.post('Deleting application',
                                         '/SaasManage/DeleteApplication',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return response.result()

    def delete_application(self, app_id, assert_success=True):
        """
        Deletes an app from the Admin Portal app list
        :param app_id: The id of the app to delete
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        payload = {
            "_RowKey": [app_id]
        }
        response = self.api_session.post('Deleting application',
                                         '/SaasManage/DeleteApplication',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        if self.auto_clean and len(self.apps_created) >= 1:
            self.apps_created.remove(app_id)
        return response.result()

    def delete_applications(self, app_ids, assert_success=True):
        """
        Deletes multiple apps from the Admin Portal app list
        :param app_ids: The id sof the app to delete
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        payload = {
            "_RowKey": app_ids
        }
        response = self.api_session.post('Deleting application',
                                         '/SaasManage/DeleteApplication',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        if self.auto_clean:
            [self.apps_created.remove(_id) for _id in app_ids]
        return response.result()

    def clone_an_application(self, app_id, assert_success=True):
        """
        Clones an application from the Admin Portal app list
        :param app_id: The id of the application to clone
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        payload = {
            "key": app_id
        }
        response = self.api_session.post('Cloning application',
                                         '/SaasManage/CloneAnApplicaton',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        app_id = response.response['Result']['_RowKey']
        self._mark_for_auto_clean(app_id, self.apps_created)
        return app_id

    def export_applications(self, application_ids, assert_success=True):
        """
        Exports an array of applications from the Admin Portal app list
        :param applicaton_ids: Array of app ids to export to .zip file
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        payload = {
            "appkeys": application_ids
        }
        response = self.api_session.post('Cloning application',
                                         '/SaasManage/ExportApplicationsToFile',
                                         payload,
                                         assert_success)
        return response

    def get_templates_and_categories(self):
        """
        Calls the '/SaasManage/GetTemplatesAndCategories' endpoint
        :return: The 'Result' property of the response
        """
        response = self.api_session.post('Getting templates and categories',
                                         '/saasmanage/GetTemplatesAndCategories',
                                         None)

        assert response.success(), 'failed to get templates and categories'
        return response.result()

    def get_application(self, row_key):
        """
        Calls the '/saasManage/GetApplication' endpoint to get details on an application
        :param row_key: the id of the application
        :return: The 'Result' property of the response
        """
        payload = {
            "_RowKey": row_key,
            "RRFormat": True,
            "Args": {
                "PageNumber": 1,
                "Limit": 1,
                "PageSize": 1,
                "Caching": -1
            }
        }
        response = self.api_session.post('',
                                         '/saasManage/GetApplication',
                                         payload)

        assert response.success(), f'failed to application: {row_key}'
        return response.result()

    def get_application_id_by_service_name(self, service_name):
        """
        Calls the '/saasManage/GetAppIDByServiceName' endpoint to get the id of an application
        :param service_name: the service name of the application
        :return: The 'Result' property of the response
        """
        payload = {
            "Name": service_name
        }
        response = self.api_session.post('',
                                         '/saasManage/GetAppIDByServiceName',
                                         payload)

        assert response.success(), f'failed to application: {row_key}'
        return response.result()

    def get_templates(self):
        """
        Calls the '/SaasManage/GetTemplatesAndCategories' endpoint
        :return: a list of the templates only
        """
        response = self.get_templates_and_categories()
        return [app['Row'] for app in response['AppTemplates']['Results']]

    def get_admin_app_list(self):
        """
        Uses a Redrock query to get all the apps that should be displayed in the AP
        :return: The 'Result.Results' property of the response object
        """
        response = self.api_session.post('Getting admin app list',
                                         '/RedRock/query',
                                         RedRock("@/lib/get_applications.js(filter:'AppType = \"Web\"')",
                                                 page_size=3000).to_payload())
        return response.results()

    def get_admin_app_list_plv8(self):
        """
        Uses a Redrock query to get all the apps that should be displayed in the AP
        :return: The 'Result.Results' property of the response object
        """
        response = self.api_session.post('Getting admin app list',
                                         '/RedRock/query',
                                         RedRock("@@Web Applications PLV8",
                                                 page_size=3000).to_payload())
        return response.results()

    def get_row_access(self, row_key):
        """
        Calls the '/Acl/GetRowAces' endpoint to get assigned rights on an application
        :param row_key: the id of the application
        :return: The 'Result' property of the response
        """
        payload = {
            "RowKey": row_key,
            "Table": "Application",
            "ReduceSysadmin": "true",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "Caching": -1
            }
        }
        response = self.api_session.post('',
                                         '/Acl/GetRowAces',
                                         payload)
        assert response.success(), f'failed to get rights for application: {row_key}'
        return response.result()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.delete_applications(self.apps_created)

    def get_app_script(self, appkey):
        """
        Calls the '/saasManage/GetScript' endpoint
        :return: the script from the SAML Script Editor
        """
        payload = {"appkey":f"{appkey}"}

        response = self.api_session.post('', '/saasManage/GetScript', payload)

        return response.response['Result']['Script']

    def get_preview_saml_response(self, app_key, uuid):
        """
        Calls the '/saasmanage/TestAdvancedScript' endpoint
        :return: a list of the templates only
        """
        script = self.get_app_script(app_key)

        payload = {"script":f"{script}",
                   "appkey":f"{app_key}",
                   "uuid":f"{uuid}"}

        response = self.api_session.post('',
                                         '/saasmanage/TestAdvancedScript',
                                         payload)

        try:
            return response.response['Result']['SSOToken']
        except KeyError:
            return response.response['Result']['Exception']['Message']

    def get_app_key_from_app_name(self, app_name):
        """
        :param app_name: the name of the app
        :return: the ID of app
        """
        app_key = None
        response = self.get_admin_app_list_plv8()
        for entity in response:
            if app_name == str(entity['Row']['DisplayName']):
                app_key = str(entity['Row']['ID'])
        return app_key

    def deploy_app_to_role(self, role_id, app_key):
        """
        Calls the '/saasManage/PublishApplication' endpoint
        :return: Success(True or False)
        """
        payload = [{
            "Role": role_id,
            "Application": app_key
        }]

        response = self.api_session.post('',
                                         '/saasManage/PublishApplication',
                                         payload)

        return response.success()

    def test_sso_token_oidc_app(self, script, app_key, user_id):
        payload = {
            "script": script,
            "appkey": app_key,
            "uuid": user_id
        }
        response =  self.api_session.post('', 'saasmanage/TestAdvancedScript', payload)
        sso_token = response.response['Result']['SSOToken']
        return sso_token