from .api_base import ApiBase
from idaptive_automation.api_payloads import RedRock


class ProxyApi(ApiBase):

    def get_all_proxies(self, assert_success=True):
        """
        Gets a list of proxies via RedRock query
        :param assert_success: Check for a success response
        :return: a list of the proxies for the tenant
        """
        response = self.api_session.post(f'Getting roles',
                                         '/RedRock/query',
                                         RedRock("Select * from Proxy").to_payload(),
                                         assert_success)
        if not assert_success:
            return response
        return [result['Row'] for result in response.results()]

    def delete_proxies(self, proxies, assert_success=True):
        """
        Deletes the list of proxies from the tenant by calling '/core/DeleteProxies'
        :param proxies: the ids of the proxies
        :param assert_success: Check for a success response
        :return: None
        """
        payload = {
            'Proxies': proxies
        }
        response = self.api_session.post(f'Deleting proxies',
                                         '/core/DeleteProxies',
                                         payload,
                                         assert_success)

        if not assert_success:
            return response
