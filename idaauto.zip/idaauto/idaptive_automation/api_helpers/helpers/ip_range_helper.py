from .api_base import ApiBase
from idaptive_automation.api_payloads import ApiResult


class IPRangeHelper(ApiBase):
    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        destroyed (must be used in a 'with' block)
        :param db_metrics: this flag determines if a metric db record should be inserted
        """
        self.corp_ips_created = []
        self.blocked_ips_created = []
        super().__init__(session, auto_clean, db_metrics)

    def whats_my_ip(self):
        return ApiResult(self.api_session.get('https://api.ipify.org?format=json'))

    def get_blocked_ip_ranges(self, assert_success=True):
        """
        Calls the /core/GetBlockedIpRanges endpoint
        :param assert_success: Check for a success response
        :return: The result property of the response
        """
        payload = {"Args":{"PageNumber":1,"PageSize":100000,"Limit":100000,"SortBy":"","direction":"False","Caching":-1}}
        return self.api_session.post(None, '/core/GetBlockedIpRanges',
                                     payload,
                                     assert_success).result()

    def add_blocked_ip_range(self, name, ip_range, assert_success=True):
        """
        Calls the /core/UpdateBlockedIpRange endpoint
        :param name: the name of the range
        :param ip_range: the value of the range
        :param assert_success: Check for a success response
        :return: The result property of the response
        """
        payload = {"Label": name, 'value': ip_range}
        result = self.api_session.post(None, '/core/UpdateBlockedIpRange',
                                       payload,
                                       assert_success).result()
        self._mark_for_auto_clean(result, self.blocked_ips_created)
        return result

    def get_corp_ip_ranges(self, assert_success=True):
        """
        Calls the /core/GetPremDetectRanges endpoint
        :param assert_success: Check for a success response
        :return: The result property of the response
        """
        payload = {"Args":{"PageNumber":1,"PageSize":100000,"Limit":100000,"SortBy":"","direction":"False","Caching":-1}}
        return self.api_session.post(None, '/core/GetPremDetectRanges',
                                     payload,
                                     assert_success).result()

    def add_corp_ip_range(self, name, ip_range, assert_success=True):
        """
        Calls the /core/UpdatePremDetectRange endpoint
        :param name: the name of the range
        :param ip_range: the value of the range
        :param assert_success: Check for a success response
        :return: The result property of the response
        """
        payload = {"Label": name, 'value': ip_range}
        result = self.api_session.post(None, '/core/UpdatePremDetectRange',
                                       payload,
                                       assert_success).result()
        self._mark_for_auto_clean(result, self.corp_ips_created)
        return result

    def update_corp_ip_range(self, name, ip_range, uuid, assert_success=True):
        """
        Calls the /core/UpdatePremDetectRange endpoint
        :param name: the name of the range
        :param ip_range: the value of the range
        :param uuid: the uuid of the range
        :param assert_success: Check for a success response
        :return: The result property of the response
        """
        payload = {"Label": name, 'value': ip_range, "Uuid": uuid}
        result = self.api_session.post(None, '/core/UpdatePremDetectRange',
                                       payload,
                                       assert_success).result()
        self._mark_for_auto_clean(result, self.corp_ips_created)
        return result

    def delete_corporate_ip_range(self, uuid, assert_success=True):
        """
        Calls the /core/DeletePremDetectRange endpoint
        :param ip_range: The range to delete
        :param assert_success: Check for a success response
        :return: None
        """
        response = self.__delete_corporate_ip_range__(uuid, assert_success)
        if not assert_success:
            return response
        if self.auto_clean:
            self.corp_ips_created.remove(uuid)
        return response.result()

    def __delete_corporate_ip_range__(self, uuid, assert_success):
        return self.api_session.post(None,
                                     f'/core/DeletePremDetectRange?systemId=&uuid={uuid}',
                                     None,
                                     assert_success)

    def delete__blocked_ip_range(self, uuid, assert_success=True):
        """
        Calls the /core/DeleteBlockedIpRange endpoint
        :param ip_range: The range to delete
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        response = self.__delete__blocked_ip_range__(uuid, assert_success)
        if not assert_success:
            return response
        if self.auto_clean:
            self.blocked_ips_created.remove(uuid)
        return response.result()

    def __delete__blocked_ip_range__(self, uuid, assert_success):
        return self.api_session.post(None,
                                     f'/core/DeleteBlockedIpRange?systemId=&uuid={uuid}',
                                     None,
                                     assert_success)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.auto_clean:
            [self.__delete__blocked_ip_range__(r, True) for r in self.blocked_ips_created]
            [self.__delete_corporate_ip_range__(r, True) for r in self.corp_ips_created]
