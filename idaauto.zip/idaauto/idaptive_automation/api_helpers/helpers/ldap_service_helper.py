from .api_base import ApiBase


class LdapServiceApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        self.ds_created = []
        super().__init__(api_session, auto_clean, db_metrics)

    def add_ldap_service_config(self, payload, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/AddLDAPDirectoryServiceConfig' endpoint
        :param payload: The payload to include with the request
        :param assert_success: Check for a success response
        :return: a dictionary
        """
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/AddLDAPDirectoryServiceConfig',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return self._clean_response(response.result())

    def modify_ldap_service_config(self, payload, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/ModifyLDAPDirectoryServiceConfig' endpoint
        :param payload: The payload to include with the request
        :param assert_success: Check for a success response
        :return: a dictionary
        """
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/ModifyLDAPDirectoryServiceConfig',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return self._clean_response(response.result())

    def get_ldap_service_config(self, ds_uuid, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/GetLDAPDirectoryServiceConfig' endpoint
        :param ds_uuid: the Uuid of the directory service in question
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response object
        """
        payload = {
            "directoryServiceUuid": ds_uuid
        }
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/GetLDAPDirectoryServiceConfig',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return response.result()

    def verify_ldap_service_config(self, payload, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/VerifyLDAPDirectoryServiceConfig' endpoint
        :param payload: The payload to include with the request
        :param assert_success: Check for a success response
        :return: a dictionary
        """
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/VerifyLDAPDirectoryServiceConfig',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return self._clean_response(response.result())

    def delete_ldap_service_config(self, uuid, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/DeleteLDAPDirectoryServiceConfig' endpoint
        :param uuid:
        :param assert_success: Check for a success response
        :return:
        """
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/DeleteLDAPDirectoryServiceConfig',
                                         {"directoryServiceUuid": uuid},
                                         assert_success)

        return response

    def get_cloud_connectors(self, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/GetCloudConnectors' endpoint
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/GetCloudConnectors',
                                         {},
                                         assert_success)
        if not assert_success:
            return response

        return response.result()

    def get_directory_service_version(self, ds_uuid, assert_success=True):
        """
        Calls the '/LDAPDirectoryService/GetDirectoryServiceVersion' endpoint
        :param ds_uuid: the Uuid of the directory service in question
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response object
        """
        payload = {
            "directoryServiceUuid": ds_uuid
        }
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/GetDirectoryServiceVersion',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return response

    def get_directory_service_uuid_by_name(self, name, assert_success=True):
        """
                Calls the '/LDAPDirectoryService/GetLDAPDirectoryServiceUuidByName' endpoint
                :param name: the given name to the directory service in question
                :param assert_success: Check for a success response
                :return: The 'Result' property of the response object
                """
        payload = {
            "DirectoryServiceName": name
        }
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/GetLDAPDirectoryServiceUuidByName',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return response

    def get_mappable_attributes(self, assert_success=True):
        """
                Calls the '/LDAPDirectoryService/GetMappableAttributeList' endpoint
                :param assert_success: Check for a success response
                :return: The 'Result' property of the response object
                """
        payload = {
            "operation": "modify"
        }
        response = self.api_session.post('',
                                         '/LDAPDirectoryService/GetMappableAttributeList',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return response

    @staticmethod
    def _clean_response(response):
        try:
            return {
                "baseDn": response['baseDn'],
                "verifyServerCertificate": response['verifyServerCertificate'],
                "description": response['description'] if 'description' in response.keys() else None,
                # "loginSuffix": response['loginSuffix'],
                "userName": response['userName'],
                "proxies": response['proxies'],
                "password": response['password'] if 'password' in response.keys() else None,
                "serviceInstanceName": response['serviceInstanceName'],
                "directoryServiceUuid": response['directoryServiceUuid'],
                "hostName": response['hostName']
            }
        except:
            print(f'Exception cleaning response: {response}')
            raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        [self.delete_ldap_service_config(uuid) for uuid in self.ds_created]
