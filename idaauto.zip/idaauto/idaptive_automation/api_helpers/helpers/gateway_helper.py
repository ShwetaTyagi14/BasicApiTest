from .api_base import ApiBase


class AppGatewayHelper(ApiBase):
    def get_gateway_management_info(self, app_id):
        """
        Calls the '/Gateway/GetGatewayManagementInfo' API endpoint
        :return: The result property of the response
        """

        return self.api_session.post('',
                                     '/Gateway/GetGatewayManagementInfo',
                                     {"_RowKey": app_id}).result()

    def probe_gateway_pipeline(self, app_id):
        """
        Calls the '/Gateway/GetGatewayManagementInfo' API endpoint
        :return: The result property of the response
        """

        return self.api_session.post('',
                                     '/Gateway/ProbeGatewayPipeline',
                                     {"_RowKey": app_id}).result()

    def configure_gateway_application(self, payload):
        """
        Calls the '/Gateway/ConfigureGatewayApplication' API endpoint
        :return: The result property of the response
        """

        return self.api_session.post('',
                                     '/Gateway/ConfigureGatewayApplication',
                                     payload).result()
