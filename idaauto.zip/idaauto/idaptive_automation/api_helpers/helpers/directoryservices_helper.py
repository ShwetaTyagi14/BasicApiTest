from .api_base import ApiBase


class DirectoryServicesApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        super().__init__(api_session, auto_clean, db_metrics)

    def set_directory_service_order(self, ds_ids, assert_success=True):
        """
        Calls the /core/directoryservices endpoint to reorder the directory services on the tenant
        :param ds_ids: the ordered ids of the directory services
        :param assert_success: Check for a success response
        :return: None
        """
        response = self.api_session.post(None, '/core/directoryservices',
                                         payload=ds_ids,
                                         assert_success=assert_success)
        if not assert_success:
            return response
