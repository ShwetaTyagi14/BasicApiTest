from .serializer import Serializer
from .api_base import ApiBase
from idaptive_automation.api_payloads import Logout, OnDemandChallenge
from idaptive_automation.api_payloads.payloads.security.oauth2_authentication import Oauth2Authentication


class Security(ApiBase):
    mechanisms = None  # do we still need this??

    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.tenant_id = session.tenant_id
        self.password = session.password
        super().__init__(session, auto_clean, db_metrics)

    def start_authentication(self, **kwargs):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :param kwargs:
        :return:
        """
        payload = {
            'TenantId': self.api_session.tenant_id,
            'Version': '1.0',
            'User': self.api_session.username,
            'ApplicationId': None,
            'MfaRequestor': None,
            **kwargs
        }
        response = self.api_session.post('Starting authentication session',
                                         '/Security/StartAuthentication',
                                         payload)

        if response.success():
            self.api_session.challenge_details = response
            self.api_session.advance_authentication_payload.session_id = \
                self.api_session.challenge_details.result()['SessionId']
            if response.result()['Challenges'][0]['Mechanisms'][0]['PromptSelectMech'] == 'Password':
                self.api_session.advance_authentication_payload.mechanism_id = \
                    response.result()['Challenges'][0]['Mechanisms'][0]['MechanismId']

        return response

    def advance_authentication(self):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :return:
        """
        response = self.api_session.post('Advancing authentication',
                                         '/Security/AdvanceAuthentication',
                                         self.api_session.advance_authentication_payload.to_payload())

        if response.ok():
            self.api_session.cookies = response.cookies()
            self.api_session.auth_details = Serializer.deserialize_json(response.response)
            if self.api_session.auth_details.Result.Summary == "LoginSuccess":
                self.api_session.user_id = self.api_session.auth_details.Result.UserId

        return self.api_session.auth_details

    def cleanup_authentication(self):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :return:
        """
        return self.api_session.post('Cleaning up authentication session',
                                     '/Security/CleanupAuthentication',
                                     self.api_session.cleanup_authentication.to_payload())

    def logout(self):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :return:
        """
        return self.api_session.post('Logging out of authentication session',
                                     '/Security/Logout',
                                     Logout(self.api_session.auth_details.Result.Auth).to_payload())

    def on_demand_challenge(self):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :return:
        """
        return self.api_session.post('Performing MFA on behalf of user',
                                     '/Security/OnDemandChallenge',
                                     OnDemandChallenge(self.api_session.username, None).to_payload())

    def refresh_token(self):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :return:
        """
        return self.api_session.post('Reloading cached identity from directory service',
                                     '/Security/RefreshToken')

    def get_authenticated_user(self):
        """
        Legacy method - Not intended for use outside this solution. Do not invoke directly
        :return:
        """
        return self.api_session.post('Getting information about the currently authenticated user',
                                     '/Security/whoami')

    def get_authenticated_user_with_token(self, payload, assert_success=True):
        """
        Calls '/Security/whoami'
        :param payload: Payload
        :param assert_success: Assertion of Post
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Getting information about the currently authenticated user',
                                     '/Security/whoami', payload=payload,
                                     assert_success=assert_success)

    def oauth2_token_authentication(self, empty_oauth_session, payload, oauth2_path=None, assert_success=True):

        if oauth2_path == None:
            oauth2_path = '__idaptive_alero_integration'

        response = self.api_session.session.post(f'{self.api_session.base_url}/oauth2/token/{oauth2_path}',
                                                 files={'file': ''}, data=payload)
        if assert_success:
            assert response.status_code == 200, f"Failed to call {oauth2_path} {response.response['Message']}"
        access_token = response.json()["access_token"]
        token_type = response.json()["token_type"]
        oauth_token = token_type + " " + access_token
        empty_oauth_session.headers['Authorization'] = oauth_token
        return oauth_token
