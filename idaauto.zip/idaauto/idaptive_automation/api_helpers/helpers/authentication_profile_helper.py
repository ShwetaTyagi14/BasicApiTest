from .api_base import ApiBase


class AuthProfileHelper(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.profiles_created = []

        super().__init__(api_session, auto_clean, db_metrics)

    def create_profile(self, payload, assert_success=True):
        """
        Calls the '/AuthProfile/SaveProfile' endpoint to create an authentication Profile
        :param payload: the profile to create
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Creating authentication profile: {payload}',
                                         '/AuthProfile/SaveProfile',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        self._mark_for_auto_clean(response.result(), self.profiles_created)
        return response.result()

    def get_auth_profiles(self, assert_success=True):
        """
        Calls the '/AuthProfile/GetDecoratedProfileList' endpoint
        Gets the details for all authentication profiles for the tenant
        :param assert_success: Check for a success response
        :return: A list of the profile details
        """
        response = self.api_session.post('Getting authentication profile list',
                                         '/AuthProfile/GetDecoratedProfileList',
                                         None,
                                         assert_success)
        if not assert_success:
            return response

        return [result['Row'] for result in response.results()]

    def get_default_new_device_profile_id(self, assert_success=True):
        """
        Gets the ID for the 'Default new device login' profile
        :param assert_success: Check for a success response
        :return: the ID
        """
        return self._parse_profile_id(self.get_auth_profiles(assert_success),
                                      'Default New Device Login Profile')

    def get_default_pwd_reset_profile_id(self, assert_success=True):
        """
        Gets the ID for the 'Default password reset' profile
        :param assert_success: Check for a success response
        :return: the ID
        """
        return self._parse_profile_id(self.get_auth_profiles(assert_success),
                                      'Default Password Reset Profile')

    def get_default_other_login_profile_id(self, assert_success=True):
        """
        Gets the ID for the 'Default other login' profile
        :param assert_success: Check for a success response
        :return: the ID
        """
        return self._parse_profile_id(self.get_auth_profiles(assert_success),
                                      'Default Other Login Profile')

    def _parse_profile_id(self, profiles, profile_name):
        filtered = [profile for profile in profiles if profile['Name'] == profile_name]
        if len(filtered) == 1:
            return filtered[0]['ID']
        raise Exception(f'No "{profile_name}" found for tenant {self.tenant_id}')

    def delete_profile(self, uuid, assert_success=True):
        """
        Delete an authentication profile
        :param uuid: the ID of the profile to delete
        :param assert_success: Check for a success response
        :return: The 'Result' property of the response
        """
        response = self.api_session.post(f'Deleting authentication profile: {uuid}',
                                         '/AuthProfile/DeleteProfile',
                                         {'uuid': uuid},
                                         assert_success)
        if not assert_success:
            return response

        return response.result()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        [self.delete_profile(profile['Uuid']) for profile in self.profiles_created]
