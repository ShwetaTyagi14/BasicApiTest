from .api_base import ApiBase
from idaptive_automation.api_payloads import ModifyAppShortcuts, SetAppCredentials
from .html_helper import HTMLHelper
import base64


class UprestHelper(ApiBase):
    def get_up_data_for_user(self):
        """
        Calls '/uprest/GetUPData' for the current user
        :return: The full response in the format of an APIResponse object
        """
        result = self.api_session.post('Getting UP data',
                                       '/uprest/GetUPData',
                                       {'force': True})
        assert result.success()
        return result

    def modify_app_shortcuts(self, app_id):
        """
        Calls '/uprest/ModifyApplicationShortcuts'
        :param app_id: the id of the app to modify
        :return: The full response in the format of an APIResponse object
        """
        result = self.api_session.post('Modifying app shortcuts',
                                       '/uprest/ModifyApplicationShortcuts',
                                       ModifyAppShortcuts(app_id).to_payload())
        assert result.success()
        return result

    def set_user_creds_for_app(self, app_id, username, password, assert_success=True):
        """
        Calls '/uprest/SetUserCredsForApp?appkey= with the specified app id
        :param app_id: the id of the app
        :param username: the username for the app
        :param password: the password for the app
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        result = self.api_session.post('Setting user credentials for app',
                                        f'/uprest/SetUserCredsForApp?appkey={app_id}',
                                        SetAppCredentials(username, password).to_payload(),
                                       assert_success)
        return result

    def handle_app_click(self, app_id, raw_response=False):
        """
        Calls '/uprest/HandleAppClick?appkey= with the specified app id
        :param app_id: the id of the app
        :return: The full response in the format of an APIResponse object
        """
        result = self.api_session.post(f'Launching app: {app_id}',
                                       f'/uprest/HandleAppClick?appkey={app_id}',
                                       assert_success=False)
        if raw_response:
            return result.raw_response
        else:
            form = HTMLHelper()
            form.feed(result.response)
            return form

    def get_user_app_catalog(self, assert_success=True):
        """
        Calls '/uprest/GetUserAppCatalog'
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('Getting user app catalog',
                                         '/uprest/GetUserAppCatalog',
                                         None,
                                         assert_success)
        return response

    def get_credentials_for_up_app(self, app_key, assert_success=True):
        """
        Calls '/uprest/GetMCFA?appkey= with the app key
        :param app_key: the id of the app in question
        :param assert_success: Check for a success response
        :return: a dictionary object
        """
        response = self.api_session.post('',
                                         f'/uprest/GetMCFA?appkey={app_key}',
                                         None,
                                         assert_success)
        if not assert_success:
            return response

        result = response.result()
        return {
            'username': result['u'],
            'password': result['p']
        }

    def get_base64decode(self, value):
        decoded_value = base64.b64decode(value).decode('utf-8')
        return decoded_value