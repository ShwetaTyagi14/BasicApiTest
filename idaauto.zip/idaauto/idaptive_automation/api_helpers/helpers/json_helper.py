import re
from datetime import datetime


def fix_ms_json_dates(dictionary):
    """
    Formats our API's date string in a Python friendly format
    :param dictionary:
    :return: None
    """
    for key, value in dictionary.items():
        if isinstance(value, str):
            m = re.search('/Date\((.*)\)/', value)
            if m:
                d = int(m.group(1)[:10])
                dictionary[key] = datetime.utcfromtimestamp(d).strftime('%Y-%m-%dT%I:%M:%S.%f')[:-3] + 'Z'

        if isinstance(value, dict):
            fix_ms_json_dates(value)
