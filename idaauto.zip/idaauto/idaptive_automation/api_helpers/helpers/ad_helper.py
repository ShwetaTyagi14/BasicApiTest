from ADLibrary.ad_server import AdServer
from .domain_helper import DomainHelper


class ActiveDirectoryHelper(DomainHelper):
    def __init__(self,
                 server_address,
                 domain_name,
                 domain_suffix,
                 email_suffix,
                 username,
                 password,
                 auto_clean=False):
        self.auto_clean = auto_clean
        self.ad_server = AdServer(
            server_address,
            domain_name,
            username,
            password
        )

        self.created_ou_list = []

        super().__init__(server_address,
                         domain_name,
                         domain_suffix,
                         email_suffix,
                         username,
                         password)

    def clean_domain_environment(self):
        for ou in self.created_ou_list:
            self.delete_ad_ou(ou)
            self.created_ou_list.pop()

    def create_ad_environment(self, base_name, default_password, num_groups=1, num_users=1, dl_group=False):
        ou = self.create_basic_ad_ou(f'{base_name}')[0]

        # self.create_sub_ad_ou(f'{base_name}GroupHolder', f"ou={base_name},{dc_string}")

        users_per_group = int(num_users / num_groups)
        # user_sub_ous = [
        #     self.create_sub_ad_ou(f'{base_name}Sub{sub_ou + 1}', f'ou={base_name},{dc_string}')
        #     for sub_ou in range(num_groups)
        # ]
        users = [
            self.create_ad_user(ou, f"user{user + 1}", default_password)
            for user in range(num_users)
        ]
        user_groups = [
            self.create_ad_group(group_name=f'{base_name}Group{group}',
                                 ou_string=f'ou={ou.name.value}',
                                 email_address=f"{base_name}Group{group}@{self.email_suffix}",
                                 is_dl=dl_group)[0]
            for group in range(1, num_groups + 1)
        ]
        results = [
            self.__add_users_to_group__(group, users, users_per_group)
            for group in user_groups
        ]
        # if num_contacts >= 1:
        #     self.create_sub_ad_ou(f'{base_name}ContactHolder', f"ou={base_name},{dc_string}")
        #     for contact in range(num_contacts):
        #         self.__create_ad_contact__(base_name, dc_string, contact + 1)

    def __add_users_to_group__(self, group, users, users_per_group):
        group_users = users[:users_per_group]
        del users[:users_per_group]
        self.ad_server.add_users_to_group(group_users, group.entry_dn)

    def add_member_to_group(self, group_dn, object_dn):
        self.ad_server.add_users_to_group(object_dn, group_dn)

    def create_ad_user(self, ou, user, password):
        user_dn = ou.entry_dn
        user_cn = f"cn={ou.name.value}{user}"

        self.ad_server.create_ad_user(
            user_dn,
            samaccount_name=f'{ou.name.value}{user}',
            password=password,
            first_name=f'{ou.name.value}',
            last_name=f'{user}',
            email=f"{ou.name.value}{user}@{self.email_suffix}",
            domain=f"{self.domain_name}.{self.domain_suffix}"
        )
        return f'{user_cn},{user_dn}'

    def create_individual_ad_user(self, dn_string, samaccount_name, password, first_name, last_name, email, domain):
        """
        Creates an AD user with the specified attributes
        :param dn_string:
        :param samaccount_name:
        :param password:
        :param first_name:
        :param last_name:
        :param email:
        :param domain:
        :return:
        """

        return self.ad_server.create_ad_user(
            dn_string,
            samaccount_name=samaccount_name,
            password=password,
            first_name=first_name,
            last_name=last_name,
            email=email,
            domain=domain
        )

    def __create_ad_user__(self, sub_ou, user):
        user_dn = sub_ou.entry_dn
        user_cn = f"cn={sub_ou.name.value}{user}"

        self.ad_server.create_ad_user(
            user_dn,
            samaccount_name=f'{sub_ou.name.value}{user}',
            password='testTEST1234!@',
            first_name=f'{sub_ou.name.value}',
            last_name=f'{user}',
            email=f"{sub_ou.name.value}{user}@{self.email_suffix}",
            domain=f"{self.domain_name}.{self.domain_suffix}"
        )
        return f'{user_cn},{user_dn}'

    def __create_ad_contact__(self, base_name, dc_string, contact):
        self.ad_server.create_ad_contact(
            f"{base_name}Contact{contact}",
            f"Test",
            f"{base_name}Contact{contact}@{self.email_suffix}",
            f"ou={base_name}ContactHolder,ou={base_name},{dc_string}"
        )

    def create_basic_ad_ou(self, ou_name):
        """
        Creates a basic ad ou
        :param ou_name: the name of the ou to create
        :return: <TODO: unknown>
        """
        suffix = f"dc={self.domain_name},dc={self.domain_suffix}"
        self.created_ou_list.append(f"ou={ou_name},{suffix}")
        return self.ad_server.create_organizational_unit(ou_name, suffix)

    def create_admin_user(self, user_name, parent_ou):
        self.ad_server.create_ad_user(
            parent_ou,
            samaccount_name=user_name,
            password='testTEST1234!@',
            first_name=user_name,
            last_name='User',
            email=f"{user_name}@{self.domain_name}.{self.domain_suffix}",
            domain=f"{self.domain_name}.{self.domain_suffix}"
        )
        distinguished_name = f"CN={user_name},{parent_ou}"
        self.ad_server.add_users_to_group(
            [distinguished_name],
            f"CN=Domain Admins,CN=Users,DC={self.domain_name},DC={self.domain_suffix}"
        )

        return self.ad_server

    def create_sub_ad_ou(self, ou_name, parent_ou):
        return self.ad_server.create_organizational_unit(
            ou_name,
            parent_ou
        )

    def create_ad_contact(self, first_name, last_name, email, dn_string):
        return self.ad_server.create_ad_contact(first_name, last_name, email, dn_string)

    def delete_ad_ou(self, ou_name):
        return self.ad_server.delete_ad_object(ou_name)

    def create_ad_group(self, group_name, ou_string, email_address="", is_dl=False):
        if not is_dl:
            return self.ad_server.create_ad_group(
                group_name,
                f"{ou_string},dc={self.domain_name},dc={self.domain_suffix}",
                email_address
            )
        else:
            return self.ad_server.create_ad_dl_group(
                group_name,
                f"{ou_string},dc={self.domain_name},dc={self.domain_suffix}",
                email_address
            )

    def get_ad_group_details(self, parent_ou):
        return self.ad_server.get_ad_group_details(
            f"ou={parent_ou},dc={self.domain_name},dc={self.domain_suffix}"
        )

    def get_ad_group_members(self, dn_string):
        return self.ad_server.get_ad_group_members(dn_string)

    def disable_user_in_ad(self, user_name, ou_string):
        return self.ad_server.disable_user(
            f"CN={user_name},{ou_string},DC={self.domain_name},DC={self.domain_suffix}"
        )

    def get_ad_ou_users(self, ou_name):
        dn_string = f"OU={ou_name},DC={self.domain_name},DC={self.domain_suffix}"
        return self.ad_server.get_organizational_unit_people(dn_string)

    def remove_user_from_group(self, user_dn, group_dn):
        return self.ad_server.remove_users_from_group(user_dn, group_dn)

    def delete_ad_user(self, user_name, ou_string):
        dn_string = f"cn={user_name},{ou_string},dc={self.domain_name},dc={self.domain_suffix}"
        self.ad_server.delete_ad_object(dn_string)

    def modify_ad_user_attribute(self, user_name, ou_string, attribute_name, attribute_value):
        dn_string = f"cn={user_name},{ou_string},dc={self.domain_name},dc={self.domain_suffix}"
        self.ad_server.modify_ad_user_attribute(
            dn_string,
            attribute_name,
            attribute_value
        )

    def require_user_to_change_pw(self, cn_string):
        self.ad_server.modify_ad_user_attribute(
            cn_string,
            "pwdLastSet",
            0
        )

    def unset_require_user_to_change_pw(self, cn_string):
        self.ad_server.modify_ad_user_attribute(
            cn_string,
            "pwdLastSet",
            -1
        )

    def get_ad_user_attribute(self, user_name, ou_string, attribute_name):
        dn_string = f"cn={user_name},{ou_string},dc={self.domain_name},dc={self.domain_suffix}"
        result = self.ad_server.search_ad_user_attribute(
            dn_string,
            attribute_name
        )
        # TODO Can we clean this up so we aren't using hardcoded indexes
        return result

    def set_user_pw(self, cn_string, password):
        self.ad_server.connection.extend.microsoft.modify_password(
            cn_string,
            password
        )

    def create_ad_environment_for_endpoint(self, base_name, default_password, num_groups=1, num_users=1,
                                           dl_group=False):
        ou = self.create_basic_ad_ou(f'{base_name}')[0]

        users_per_group = int(num_users / num_groups)

        users = [
            self.create_ad_user_for_endpoint(ou, f"user{user + 1}", default_password)
            for user in range(num_users)
        ]
        user_groups = [
            self.create_ad_group(group_name=f'{base_name}Group{group}',
                                 ou_string=f'ou={ou.name.value}',
                                 email_address=f"{base_name}Group{group}@{self.email_suffix}",
                                 is_dl=dl_group)[0]
            for group in range(1, num_groups)
        ]
        results = [
            self.__add_users_to_group__(group, users, users_per_group)
            for group in user_groups
        ]

    def create_ad_user_for_endpoint(self, ou, user, password):
        user_dn = ou.entry_dn
        user_cn = f"cn={ou.name.value}{user}"

        self.ad_server.create_ad_user_with_domain_suffix(
            user_dn,
            samaccount_name=f'{ou.name.value}{user}',
            password=password,
            first_name=f'{ou.name.value}',
            last_name=f'{user}',
            email=f"{ou.name.value}{user}@{self.email_suffix}",
            domain=f"{ou.name.value}{user}@{self.domain_name}.{self.domain_suffix}"
        )
        return f'{user_cn},{user_dn}'

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.auto_clean:
            self.clean_domain_environment()
