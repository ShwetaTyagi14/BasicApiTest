from .api_base import ApiBase


class CertificateApiHelper(ApiBase):

    def set_default_certificate(self, cert_thumbprint):
        """
        Sets the Default application signing certificate for the tenant
        :param cert_thumbprint: the thumbprint for the certificate
        :return: a dictionary object
        """
        payload = {"type": "Application", "thumbprint": f"{cert_thumbprint}"}

        response = self.api_session.post('',
                                         '/core/SetDefaultCertificate',
                                         payload)
        return response.result()

    def delete_certificate(self, cert_thumbprint):
        """
        Deletes an application signing certificate
        :param cert_thumbprint: the thumbprint for the certificate
        :return: a dictionary object
        """
        payload = {"Thumbprints": [f"{cert_thumbprint}"]}

        response = self.api_session.post('',
                                         '/core/DeleteCertificate',
                                         payload)
        return response.result()

    def get_certificates(self):
        """
        Gets all application signing certificates
        :return: a dictionary object
        """
        payload = {"Args": {"PageNumber": 1, "PageSize": 100000, "Limit": 100000, "SortBy": "", "Caching": -1}}

        response = self.api_session.post('',
                                         '/core/GetCertificateInfos?type=Application',
                                         payload)
        return response.result()
