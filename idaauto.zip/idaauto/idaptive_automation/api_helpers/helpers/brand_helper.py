from .api_base import ApiBase
from .ibe_helper import  IBEHelper


class BrandApi(ApiBase):
    def get_tenant_brand(self):
        """
        Gets the brand of the authenticated tenant
        :return: (string) Brand of the tenant
        """
        ff = IBEHelper(self.api_session).get_all_ibe_urls()['Stable'][0]['Firefox']
        if 'BrowserExt/Centrify' in ff:
            return 'Centrify'
        if 'Idaptive' in ff:
            return 'Idaptive'
        raise Exception(f'Unable to find brand for tenant: {self.api_session.tenant_id}')
