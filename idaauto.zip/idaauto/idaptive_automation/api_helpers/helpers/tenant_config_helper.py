from .api_base import ApiBase


class TenantConfigApi(ApiBase):
    def turn_off_quick_start(self):
        """
        Turns off the quick start wizard
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('creating CyberArk cloud user',
                                     '/TenantConfig/SetUISettings',
                                     {"uisection": {"doNotShowQuickstart": True}})

    def turn_off_welcome_wizard(self):
        """
        Turns off the welcome wizard
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('creating idaptive cloud user',
                                     '/TenantConfig/SetUISettings',
                                     {"uisection": {"doNotShowQuickstart": True,
                                                    "doNotShowIdaptiveWelcomeWizard": True}})

    def get_tenant_urls(self, assert_success=True):
        """
        Gets a list of urls for the tenant
        :param assert_success:
        :return: a dictionary object
        """
        response = self.api_session.post('',
                                         '/TenantCnames/UiGet',
                                         assert_success=assert_success)
        if not assert_success:
            return response
        return [row['Row'] for row in response.results()]
