from .api_base import ApiBase


class CDirectoryService(ApiBase):

    def refresh_ad_user_token(self, user_id):
        payload = {'ID': user_id}

        return self.api_session.param_post('refreshing CyberArk Identity ad user token',
                                           '/cdirectoryservice/refreshtoken',
                                           params=payload)

    def change_user(self, payload, assert_success=True):
        """
        Calls /cdirectoryservice/changeuser
        :param payload: The changes to be made to the user
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('updating CyberArk cloud user',
                                         '/cdirectoryservice/changeuser',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

    def set_user_state(self, payload):
        """
        Calls /cdirectoryservice/setuserstate
        :param payload: the state of the user to be set
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('setting CyberArk cloud user state',
                                         '/cdirectoryservice/setuserstate',
                                         payload)

        return response

    def mfa_unlock_user(self, uuid, assert_success=True):
        """
        Calls
        :param uuid: the uuid of the user
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post(None,
                                         f'/cdirectoryservice/ExemptUserFromMfa?systemId=&ID={uuid}',
                                         payload={},
                                         assert_success=assert_success)

        return response

    def get_users(self):
        """
        Calls '/CDirectoryService/GetUsers'
        :return: A list of all cloud users for the tenant
        """
        result = self.api_session.post('Getting users',
                                       '/CDirectoryService/GetUsers',
                                       payload={})

        return [row['Row'] for row in result.results()]

    def get_default_suffix(self, assert_success=True):
        """
        Calls'CDirectoryService/GetDirectoryServiceSettings'
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """

        response = self.api_session.post('Getting Default Suffix',
                                         '/CDirectoryService/GetDirectoryServiceSettings',
                                         {}, assert_success=assert_success)
        if assert_success:
            return response.result()
        else:
            return response

    def set_default_suffix(self, default_suffix, assert_success=True):
        """
        Calls'CDirectoryService/SetDirectoryServiceSettings'
        :param default_suffix: the Suffix to be set as the Default Suffix
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        payload = {'DefaultSuffix': f'{default_suffix}'}

        response = self.api_session.post('Setting Default Suffix',
                                         '/CDirectoryService/SetDirectoryServiceSettings',
                                         payload, assert_success=assert_success)
        if assert_success:
            return response.response['success']
        else:
            return response

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.auto_clean:
            [self.refresh_ad_user_token(user['Uuid']) for user in self.get_users()]
