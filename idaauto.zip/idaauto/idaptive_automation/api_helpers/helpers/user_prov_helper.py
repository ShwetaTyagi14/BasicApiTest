from .api_base import ApiBase
from idaptive_automation.api_payloads import RedRock


class UserProvisioningHelper(ApiBase):
    """
    This is a class for all cloud REST end points that fall within the UserProv namespace.
    The UserProv namespace deals with provisioning users into third part applications, typically the methods used
    to define how those users are provisioned reside within these calls.
    """
    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.apps_created = []
        super().__init__(session, auto_clean, db_metrics)

    def update_app(self, payload, assert_success=True):
        """
        This method points to the UserProv/UpdateApp endpoint.  This endpoint mimics what happens when a user
        clicks the Save button on the provisioning tab.

        Parameters:
            payload (string): The update payload sent to the API
            assert_success (bool): Performs an assert statement on the response.success property returned by the API
        Returns:
            string: Returns a REST response string
        """
        response = self.api_session.post('Updating application',
                                         '/UserProv/UpdateApp',
                                         payload,
                                         assert_success)

        if assert_success:
            assert response.success(), 'failed to update app'
        return response

    def get_app(self, app_key):
        """
        This method points to the UserProv/GetApp endpoint.  This endpoint mimics what happens when a user
        clicks the provisioning tab on a specific app.

        Parameters:
            app_key (string): The app key id to pull the data from
        Returns:
            string: Returns a REST response string
        """
        payload = {
            "appKey": app_key,
            "getEndpointData": True
        }
        response = self.api_session.post('',
                                         '/UserProv/GetApp',
                                         payload)

        assert response.success(), f'failed to get app: {app_key}'
        return response.result()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
