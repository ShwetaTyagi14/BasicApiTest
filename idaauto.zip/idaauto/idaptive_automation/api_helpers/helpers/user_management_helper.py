from .api_base import ApiBase


class UserMgmt(ApiBase):

    def remove_users(self, payload):
        """
        Calls '/UserMgmt/RemoveUsers'
        :param payload: the payload for the request
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Removing users',
                                     '/UserMgmt/RemoveUsers',
                                     payload)

    def get_user_attributes(self, payload, assert_success=True):
        """
        Calls '/UserMgmt/GetUserAttributes'
        :param payload: the payload for the request
        :param assert_success: Assertion of Post
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post("Getting user attributes", url='/UserMgmt/GetUserAttributes', payload=payload,
                                     assert_success=assert_success)

    def get_cached_user(self, payload, assert_success=True):
        """
        Calls '/UserMgmt/GetCachedUser'
        :param payload: the payload for the request
        :param assert_success: Assertion of Post
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post("Getting user attributes", url='/UserMgmt/GetCachedUser', payload=payload,
                                     assert_success=assert_success)

    def set_slack_member_id(self, payload, assert_success=True):
        """
        Calls '/UserMgmt/SetSlackMemberId'
        :param payload: the payload for the request
        :param assert_success: Assertion of Post
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post("Getting user attributes", url='/UserMgmt/SetSlackMemberId', payload=payload,
                                     assert_success=assert_success)

    def get_user_info(self):
        """
        Calls '/UserMgmt/GetUserInfo'
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Getting user info', '/UserMgmt/GetUserInfo')

    def get_new_sws_token(self, assert_success=True):
        """
        Calls '/UserMgmt/GetUserInfo'
        :param assert_success: Assertion of Post
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Getting user info',
                                     '/Core/IssueServiceTenantAccessToken',
                                     {"service": "sws", "issueBySysAdmin": True},
                                     assert_success=assert_success)

    def get_user_info_with_payload(self, payload, assert_success=True):
        """
        Calls '/UserMgmt/GetUserInfo'
        :param payload: the payload for the request
        :param assert_success: Assertion of Post
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Getting user info', '/UserMgmt/GetUserInfo', payload=payload,
                                     assert_success=assert_success)

    def get_user_settings_ui(self):
        """
        Cherry-pick the settings for UI
        :return: The dictionary of the UI settings or empty dictionary if not found
        """
        result = self.get_user_info()

        ui_settings = {}
        try:
            ui_settings = result.response['Result']['Settings']['uisection']
        except KeyError:
            pass

        return ui_settings

    def get_security_questions(self):
        """
        Calls '/UserMgmt/GetSecurityQuestions'
        :return: The full response in the format of an APIResponse object
        """
        url = '/UserMgmt/GetSecurityQuestions'

        return self.api_session.post('Getting security questions', url)

    def get_security_questions_with_admin_questions(self):
        """
        Calls '/UserMgmt/GetSecurityQuestions'
        :return: The full response in the format of an APIResponse object
        """
        url = '/UserMgmt/GetSecurityQuestions?addAdminQuestions=true'

        return self.api_session.post('Getting security questions', url)

    def update_security_questions(self, payload):
        """
        Calls '/UserMgmt/UpdateSecurityQuestions'
        :param payload: the payload for the request
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Updating security questions',
                                     '/UserMgmt/UpdateSecurityQuestions',
                                     payload)

    def invite_user(self, payload):
        """
        Calls '/UserMgmt/InviteUsers'
        :param payload: the payload for the request
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Updating security questions',
                                     '/UserMgmt/InviteUsers',
                                     payload)

    def set_phone_pin(self, user_uuid, phone_pin):
        """
        Calls '/UserMgmt/SetPhonePin'
        :param user_uuid: the user id
        :param phone_pin: the phone pin
        :return: The full response in the format of an APIResponse object
        """
        payload = {
            "ID": user_uuid,
            "phonepin": phone_pin
        }
        return self.api_session.post('/UserMgmt/SetPhonePin', payload)

    def reset_user_password(self, user_id, pwd):
        """
        Calls the /UserMgmt/ResetUserPassword endpoint to reset the user's pwd
        :param user_id: the uuid of the user
        :param pwd: the new password
        :return:
        """
        payload = {
            "ID": user_id,
            "newPassword": pwd
        }
        return self.api_session.post(None, '/UserMgmt/ResetUserPassword', payload)

    def lock_user_account_by_uuid(self, user_uuid, assert_success=True):
        """
        Locks a user's account
        :param user_uuid: the user's uuid
        :param assert_success:
        :return:
        """
        payload = {
            "user": user_uuid,
            "lockUser": True
        }
        return self.api_session.post(None, '/UserMgmt/SetCloudLock', payload, assert_success=assert_success)

    def unlock_user_account_by_uuid(self, user_uuid, assert_success=True):
        """
        Unlocks a user's account
        :param user_uuid: the user's uuid
        :param assert_success:
        :return:
        """
        payload = {
            "user": user_uuid,
            "lockUser": False
        }
        return self.api_session.post(None, '/UserMgmt/SetCloudLock', payload, assert_success=assert_success)

    def change_user_password(self, old_password, new_password, assert_success=True):
        """
        Changes the logged in user's password
        :param old_password: the user's current password
        :param new_password: the user's new password:
        :return:
        """
        payload = {
            "newPassword": new_password,
            "oldPassword": old_password
        }
        return self.api_session.post(None, '/UserMgmt/ChangeUserPassword', payload, assert_success)

    def change_user_attributes(self, payload):
        """
        Calls the /UserMgmt/ChangeUserAttributes endpoint to set AD user attributes from cloud
        :param payload: use api payloads ChangeUserAttributes to set payload
        :return:
        """

        return self.api_session.post(None, '/UserMgmt/ChangeUserAttributes', payload)
