from io import BytesIO
from zipfile import ZipFile

from .api_base import ApiBase


class O365Api(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        super().__init__(api_session, auto_clean, db_metrics)

    def federate_domain(self, domain_name, app_row_key, assert_success=True):
        payload = {}
        response = self.api_session.post('Federating O365 Domain',
                                         f'/O365/FederateDomain?domainName={domain_name}&applicationRowKey={app_row_key}',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def unfederate_domain(self, domain_name, app_row_key, assert_success=True):
        payload = {}
        response = self.api_session.post('UnFederating O365 Domain',
                                         f'/O365/UnfederateDomain?domainName={domain_name}&applicationRowKey={app_row_key}',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def get_domain_info_page(self, app_row_key, assert_success=True):
        response = self.api_session.post('Federating O365 Domain',
                                         f'/O365/GetOffice365Domains?rowKey={app_row_key}',
                                         None,
                                         assert_success)
        if not assert_success:
            return response
        return response

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
