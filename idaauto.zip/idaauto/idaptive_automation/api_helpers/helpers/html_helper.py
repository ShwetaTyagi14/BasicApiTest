from html.parser import HTMLParser


class HTMLHelper(HTMLParser):
    """
    Under development
    """
    def __init__(self):
        self.errors = []
        self.forms = []
        self.root = None
        self.current_tag = None
        self.current_search_tag = None
        self._head = None
        self._body = None

        super().__init__()

    def error(self, message):
        self.errors.append(message)

    def handle_starttag(self, tag, attrs):
        children = []
        new_tag = dict(attrs)
        new_tag.update({'children': children})
        new_tag.update({'parent': self.current_tag})

        if not self.current_tag:
            self.root = self.current_tag = new_tag
        else:
            if tag in self.current_tag.keys():
                self.current_tag[tag].append(new_tag)
            else:
                self.current_tag.update({tag: [new_tag]})
            self.current_tag['children'].append(new_tag)

        self.current_tag = new_tag
        if tag == 'head':
            self._head = new_tag
        if tag == 'body':
            self._body = new_tag

    def handle_endtag(self, tag):
        self.current_tag = self.current_tag['parent']
