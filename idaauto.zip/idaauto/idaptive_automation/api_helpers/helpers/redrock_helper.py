
class RedrockApi:
    """
    This is a class for general RedRock operations, use this class to mimic generation of RedRock reports

    Attributes:
        api_session (object): An open instance of a cloud session to execute queries from
    """
    def __init__(self, api_session):
        """
        The constructor for RedrockApi class

        Parameters:
            api_session (objec): An open instance of a cloud session
        """
        self.api_session = api_session

    def execute_redrock_query(self, payload, assert_success=True):
        """
        Calls the RedRock/query endpoint of the cloud REST API.  This call is primarily made when creating custom
        cloud reports.  However we can use this to execute any open query to RedRock. Note that Redrock intrinsically
        will not execute Update, Delete, Insert statements to prevent SQL injection.

        Parameters:
            payload (string): A JSON formatted string that contains the query to execute
            assert_success (bool): Check for a success response

        Returns:
            String:  Response formatted string that contains REST response, and any rows returned by the query
        """
        response = self.api_session.post('',
                                         '/RedRock/query',
                                         payload,
                                         assert_success)

        if not assert_success:
            return response
        return response
