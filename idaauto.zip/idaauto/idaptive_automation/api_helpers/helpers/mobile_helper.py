from .api_base import ApiBase


class MobileApi(ApiBase):
    def ping_proxy(self, proxy_id, assert_success=True):
        """
        Calls /mobile/pingproxy
        :param proxy_id: the id of the proxy to ping
        :param assert_success: Check for a success response
        :return: None or full response
        """
        response = self.api_session.post('',
                                         f'/mobile/pingproxy?systemId=&proxyID={proxy_id}',
                                         None,
                                         assert_success=assert_success)
        if not assert_success:
            return response

    def get_user_and_app_store_url_info(self, payload=""):
        """
        Calls '/Mobile/GetUserAndAppStoreUrlInfo'
        :param payload: the payload for the request, generally null
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post("Getting mobile attributes", url='/Mobile/GetUserAndAppStoreUrlInfo', payload=payload)