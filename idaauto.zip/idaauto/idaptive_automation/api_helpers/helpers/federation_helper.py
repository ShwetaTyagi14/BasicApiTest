from .api_base import ApiBase


class FederationHelper(ApiBase):
    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.apps_created = []
        super().__init__(session, auto_clean, db_metrics)

    def get_global_federation_settings(self, assert_success=True):
        """
        Calls '/Federation/GetGlobalFederationSettings?FederationType=SAML%202.0'
        :param assert_success: Check for a success response
        :returns: the Result property of the response
        """

        response = self.api_session.post(None,
                                         '/Federation/GetGlobalFederationSettings?FederationType=SAML%202.0',
                                         {},
                                         assert_success)
        if not assert_success:
            return response

        return response.result()
