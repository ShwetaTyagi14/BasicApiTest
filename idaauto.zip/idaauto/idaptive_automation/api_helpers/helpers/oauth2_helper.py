from idaptive_automation.api_helpers import ApiBase
import requests


class OAuth2Helper(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        super().__init__(api_session, auto_clean, db_metrics)

    def user_info(self, app_name, access_token):
        """
        Calls '/OAuth2/UserInfo' to get user info
        :param app_name: OIDC app name
        :param access_token: OIDC access token
        :return: Response object
        """
        url = self.api_session.base_url + '/oauth2/userinfo/' + app_name
        header_data = {
            'Content-type': 'application/x-www-form-urlencoded',
            'X-CENTRIFY-NATIVE-CLIENT': 'true',
            'Authorization': 'Bearer ' + access_token
        }
        resp = requests.get(url, headers=header_data)
        return resp