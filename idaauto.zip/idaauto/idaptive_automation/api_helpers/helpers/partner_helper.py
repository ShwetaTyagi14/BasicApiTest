from .api_base import ApiBase


class PartnerApi(ApiBase):

    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        super().__init__(api_session, auto_clean, db_metrics)
        self.partners_created = []

    def get_federations(self, assert_success=True):
        """
        Calls the '/Federation/GetFederations' endpoint
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('Getting federations',
                                         '/Federation/GetFederations',
                                         assert_success)
        return response

    def create_partner(self, payload, assert_success=True):
        """
        Calls the '/Federation/CreateFederation' endpoint
        :param payload:
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post_urlencoded('Saving federation',
                                                    '/Federation/CreateFederation',
                                                    payload=payload,
                                                    assert_success=assert_success)

        if response.success():
            self._mark_for_auto_clean(response.result()['FederationUuid'], self.partners_created)

        return response

    def update_partner(self, payload, assert_success=True):
        """
        Calls the '/Federation/UpdateFederation' endpoint
        :param payload:
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post_urlencoded(None,
                                                '/Federation/UpdateFederation',
                                                payload=payload,
                                                assert_success=assert_success)

    def _get_payload_with_uuid(self, partner_name):
        uuid = self._get_uuid_for_partner(partner_name)
        payload = {
            "FederationUuid": uuid
        }
        return payload

    def _get_uuid_for_partner(self, partner_name):
        federations = self.get_federations().result()
        uuid = None
        partner = [partner['FederationUuid'] for partner in federations if partner['FederationName'] == partner_name]

        if len(partner) > 0:
            uuid = partner[0]

        return uuid

    def delete_partner(self, partner_name, assert_success=True):
        """
        Calls the '/Federation/DeleteFederation' endpoint
        :param partner_name:
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        return self.delete_partner_by_uuid(self._get_uuid_for_partner(partner_name), assert_success)

    def delete_partner_by_uuid(self, fed_uuid, assert_success=True, cleanup=True):
        """
        Calls the '/Federation/DeleteFederation' endpoint
        :param fed_uuid: the FederationUuid of the partner
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        paload = {
            "FederationUuid": fed_uuid
        }
        response = self.api_session.post('Deleting partner',
                                         '/Federation/DeleteFederation',
                                         payload=paload,
                                         assert_success=assert_success)
        if not assert_success:
            return response

        if cleanup:
            if fed_uuid in self.partners_created:
                self.partners_created.remove(fed_uuid)

        return response.result()

    def get_federation_info(self, partner_name):
        """
        Calls the '/Federation/GetFederation' endpoint
        :param partner_name:
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('Getting partner',
                                         '/Federation/GetFederation',
                                         payload=self._get_payload_with_uuid(partner_name))
        return response.result()

    def get_partners_list(self):
        """
        Calls the '/Federation/GetFederations' endpoint
        :return: a formatted dictionary object
        """
        return self._parse_partners_from_federations()

    def _parse_partners_from_federations(self):
        names = []
        for partner in self.get_federations().result():
            name = partner['FederationName']
            partner_type = partner['FederationType']
            domain = partner['Domains']
            active = partner['Active']
            status = 'Active' if active == 'true' else active
            names.append({
                'Name': name,
                'Type': partner_type,
                'Domains': domain,
                'Status': status,
                'FederationUuid': partner['FederationUuid']
            })
        return names

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        [self.delete_partner_by_uuid(partner) for partner in self.partners_created]
