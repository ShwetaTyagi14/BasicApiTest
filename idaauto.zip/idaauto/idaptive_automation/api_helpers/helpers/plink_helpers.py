
class PlinkHelper:
    @staticmethod
    def parse_hr_policies_from_plinks(plinks):
        """
        Parses the plinks response into human readable form
        :param plinks:
        :return:
        """
        names = []
        for policy in plinks:
            name = policy['Row']['PolicySet'].split('/')[2]
            ltype = policy['Row']['LinkType']
            status = 'Active' if ltype in ['Global', 'Role'] else ltype
            description = policy['Row']['Description'].replace('\n\n', ' ').replace('\n',' ')
            names.append({'Name': name, 'Status': status, 'Description': description})
        return names
