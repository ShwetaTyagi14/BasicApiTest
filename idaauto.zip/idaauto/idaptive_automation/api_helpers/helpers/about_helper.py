from .api_base import ApiBase


class AboutHelper(ApiBase):
    def get_about_info(self):
        """
        Calls the '/sysinfo/about' API endpoint
        :return: The full response in the format of an APIResponse object
        """
        return self.api_session.post('Getting About info',
                                     '/sysinfo/about',
                                     None).result()
