import poplib
import email
import re
import time
import base64
import csv
import json
from io import StringIO
from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials


class EmailHelper:
    def __init__(self, credentials=None):
        """
        Used to check MongoDB for email in tests. Also runs the email service
        :param credentials: The credentials for the email server, if you are running the email service
        """
        self.credentials = credentials

    def check_mail(self):
        """
        Checks the email server for messages
        :return: a list of messages
        """
        pop_conn = poplib.POP3_SSL(self.credentials['server'])
        pop_conn.user(self.credentials['username'])
        pop_conn.pass_(self.credentials['password'])
        message_count = range(1, len(pop_conn.list()[1]) + 1)
        messages = [pop_conn.retr(i) for i in message_count]

        messages = [b"\n".join(mssg[1]) for mssg in messages]
        messages = [email.message_from_bytes(mssg) for mssg in messages]

        email_messages = []
        for message in messages:
            body = [f'{msg[0] if isinstance(msg, list) else msg}\n' for msg in self._decode_email_message(message)]
            ds = message['Date'].split(' +')[0]
            email_messages.append({
                'to': message['to'],
                'from': message['from'],
                'subject': message['subject'],
                'body': body,
                'date': {
                    'raw': ds,
                    'received': time.time()
                },
                'attachments': self._get_attachments(message),
                'parsed': self._parse_message(body[0])
            })

        pop_conn.quit()
        return email_messages

    @staticmethod
    def get_gmail_messages(query):
        """
        Queries MongoDB for email matching the query
        :param query: the message to look for
        :return: Any messages matching the query
        """
        with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
            return client.find_many('email', query)

    def _decode_email_message(self, message):
        if not message.is_multipart():
            if 'text/' in message.get('Content-Type'):
                splits = message.get('Content-Type').split('charset=')
                if len(splits) == 2:
                    charset = splits[1]
                    try:
                        return message.get_payload(decode=True).decode(charset)
                    except:
                        return message.get_payload()
                else:
                    return message.get_payload()
            else:
                return message.get_payload()

        return [self._decode_email_message(msg) for msg in message.get_payload()]

    @staticmethod
    def _get_attachments(message):
        attachments = []
        for part in message.walk():
            if not message.is_multipart():
                continue
            if message.get('Content-Disposition'):
                continue
            file_name = part.get_filename()
            # check if email park has filename --> attachment part
            if file_name:
                if part['Content-Transfer-Encoding'] == 'base64' and file_name.split('.')[-1] in ['csv']:
                    content = base64.b64decode(part.get_payload()).decode('utf-8')
                    EmailHelper._parse_attachment_content(content)
                    attachments.append({
                        'filename': file_name,
                        'content': EmailHelper._parse_attachment_content(content)
                    })
        return attachments

    @staticmethod
    def _parse_attachment_content(content):
        try:
            reader = csv.DictReader(StringIO(content))
            rows = [json.dumps(row) for row in reader]
            return [json.loads(row) for row in rows]
        except:
            pass
        return None

    def wait_for_message(self, query, wait_seconds=120):
        """
        Polls MongoDB for a messages matching the query
        :param query: The query to look for
        :param wait_seconds: how long to wait (seconds)
        :return: Any messages matching the query
        """
        try_count = 0
        sleep_time = 5
        while try_count < wait_seconds / sleep_time:
            messages = self.get_gmail_messages(query)
            if len(messages) == 0:
                try_count += 1
                time.sleep(sleep_time)
            else:
                return messages

    @staticmethod
    def _parse_mfa_code_from_email(body):
        pattern = r'.*Enter the following code where prompted:(\d+).*'
        splits = body.split('\n')
        match_lines = [line for line in splits if re.match(pattern, line)]
        if len(match_lines) == 0:
            raise Exception('No confirmation code found')
        return re.match(pattern, match_lines[0]).group(1)

    @staticmethod
    def _parse_message(body):
        return EmailHelper._parse_app_access_request(body) or \
               EmailHelper._parse_app_access_approval(body) or \
               EmailHelper._parse_app_access_denial(body) or \
               EmailHelper._parse_user_invite(body) or \
               EmailHelper._parse_portal_mfa(body) or \
               EmailHelper._parse_bulk_user_import_report(body)

    @staticmethod
    def _parse_app_access_request(body):
        try:
            text = [line.strip() for line in body.split('\n') if line.strip() != '']
            app_access_request = r'.*You have an application access request pending.*'
            request_match_lines = [line for line in text if re.match(app_access_request, line)]
            if len(request_match_lines) != 0:
                app_name_pattern = r'App:\s+(.*)'
                reason_pattern = r'Reason:\s?(.*)'
                requestor_pattern = r'Requestor:\s?(([^(]+)\s*\(([^)]+)\))'
                approver_pattern = r'Approver 1:\s+(([^(]+)\s*\(([^)]+)\))'
                url_pattern = r'View Request \(([^)]+)\)'
                app_name_line = next(iter([line for line in text if re.match(app_name_pattern, line)]))
                reason_line = next(iter([line for line in text if re.match(reason_pattern, line)]))
                requestor_name_line = next(iter([line for line in text if re.match(requestor_pattern, line)]))
                approver_line = next(iter([line for line in text if re.match(approver_pattern, line)]))
                view_request_url_line = next(iter([line for line in text if re.match(url_pattern, line)]))
                return {
                    'emailType': 'app access request',
                    'appName': re.match(app_name_pattern, app_name_line).group(1),
                    'reason': re.match(reason_pattern, reason_line).group(1),
                    'requestor': {
                        'displayName': re.match(requestor_pattern, requestor_name_line).group(2).strip(),
                        'userName': re.match(requestor_pattern, requestor_name_line).group(3).strip()
                    },
                    'approver': {
                        'displayName': re.match(approver_pattern, approver_line).group(2).strip(),
                        'userName': re.match(approver_pattern, approver_line).group(3).strip()
                    },
                    'requestUrl': re.match(url_pattern, view_request_url_line).group(1)
                }
            return None
        except:
            pass
        return None

    @staticmethod
    def _parse_app_access_approval(body):
        try:
            text = [line.strip() for line in body.split('\n') if line.strip() != '']
            app_access_approval = r'Access request for application\s+(.*)\s+was approved'
            request_match_lines = [line for line in text if re.match(app_access_approval, line)]
            if len(request_match_lines) != 0:
                app_name_pattern = app_access_approval
                approver_pattern = r'Approver 1:\s+(([^(]+)\s*\(([^)]+)\))'
                url_pattern = r'See your new app in the User Portal \(([^)]+)\)'
                app_name_line = next(iter([line for line in text if re.match(app_name_pattern, line)]))
                approver_line = next(iter([line for line in text if re.match(approver_pattern, line)]))
                view_app_url_line = next(iter([line for line in text if re.match(url_pattern, line)]))
                return {
                    'emailType': 'app access approval',
                    'appName': re.match(app_name_pattern, app_name_line).group(1),
                    'approver': {
                        'displayName': re.match(approver_pattern, approver_line).group(2).strip(),
                        'userName': re.match(approver_pattern, approver_line).group(3).strip()
                    },
                    'appUrl': re.match(url_pattern, view_app_url_line).group(1)
                }
            return None
        except:
            pass
        return None

    @staticmethod
    def _parse_app_access_denial(body):
        try:
            text = [line.strip() for line in body.split('\n') if line.strip() != '']
            app_access_approval = r'Access request for application\s+(.*)\s+was denied'
            request_match_lines = [line for line in text if re.match(app_access_approval, line)]
            if len(request_match_lines) != 0:
                app_name_pattern = app_access_approval
                approver_pattern = r'Approver 1:\s+(([^(]+)\s*\(([^)]+)\))'
                reason_pattern = r'Reason:\s?(.*)'
                app_name_line = next(iter([line for line in text if re.match(app_name_pattern, line)]))
                approver_line = next(iter([line for line in text if re.match(approver_pattern, line)]))
                reason_line = next(iter([line for line in text if re.match(reason_pattern, line)]))
                return {
                    'emailType': 'app access denial',
                    'appName': re.match(app_name_pattern, app_name_line).group(1),
                    'approver': {
                        'displayName': re.match(approver_pattern, approver_line).group(2).strip(),
                        'userName': re.match(approver_pattern, approver_line).group(3).strip()
                    },
                    'reason': re.match(reason_pattern, reason_line).group(1)
                }
            return None
        except:
            pass
        return None

    @staticmethod
    def _parse_user_invite(body):
        try:
            text = [line.strip() for line in body.split('\n') if line.strip() != '']
            user_invite_line = r".*You've been invited to Idaptive by your system administrator"
            match_lines = [line for line in text if re.match(user_invite_line, line)]
            if len(match_lines) != 0:
                one_time_pass_pattern = r"Login Now\s+\(([^']+)"
                username_pattern = r'login name:\s+([^\s]+)(?=If you need help)'
                one_time_pass_line = next(iter([line for line in text if re.match(one_time_pass_pattern, line)]))
                username_line = next(iter([line for line in text if re.match(username_pattern, line)]))
                return {
                    'emailType': 'user invite',
                    'username': re.match(username_pattern, username_line).group(1),
                    'onetimePassword': re.match(one_time_pass_pattern, one_time_pass_line).group(1).strip()
                }
        except:
            pass
        return None

    @staticmethod
    def _parse_portal_mfa(body):
        try:
            text = [line.strip() for line in body.split('\n') if line.strip() != '']
            portal_mfa_pattern = r'Hello\s+([\w\d\._-]+@[\w\d\._-]+),Please find your one-time authentication link or code below\.\s+Continue with Authentication\s+\(([^"]+)'
            match_lines = [line for line in text if re.match(portal_mfa_pattern, line)]
            if len(match_lines) != 0:
                mfa_code_pattern = r".*Enter the following code where prompted:\s*(\d+)"
                username_line = match_lines[0]
                return {
                    'emailType': 'portal mfa',
                    'username': re.match(portal_mfa_pattern, username_line).group(1),
                    'onetimePassword': re.match(portal_mfa_pattern, username_line).group(2),
                    'mfaCode': re.match(mfa_code_pattern, username_line).group(1)
                }
        except:
            pass
        return None

    @staticmethod
    def _parse_bulk_user_import_report(body):
        try:
            text = [line.strip() for line in body.split('\n') if line.strip() != '']
            bui_report_pattern = r'Your recent request to create multiple users for Idaptive has been processed.'
            match_lines = [line for line in text if re.match(bui_report_pattern, line)]
            if len(match_lines) != 0:
                user_count_pattern = r"[^\d]*(\d+) of (\d+) users have been created and emails have been sent to inform them that the service is now available."
                user_count_line = [line for line in text if re.match(user_count_pattern, line)][0]
                return {
                    'emailType': 'bulk user import report',
                    'usersSubmitted': int(re.match(user_count_pattern, user_count_line).group(2)),
                    'usersImported': int(re.match(user_count_pattern, user_count_line).group(1))
                }
        except:
            pass
        return None
