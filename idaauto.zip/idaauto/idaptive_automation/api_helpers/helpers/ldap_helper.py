from ldap3 import Server, Connection, ALL, ALL_ATTRIBUTES, ALL_OPERATIONAL_ATTRIBUTES


class LdapServer:
    def __init__(self, server_name, user, password, auto_clean=False):
        """
        :param server_name: the name of the LDAP server
        :param user: the username for authentication on the server
        :param password: the password for authentication
        :param auto_clean: Remove anything this helper creates when it is
        destroyed (must be used in a 'with' block)
        """
        self.server = Server(server_name, use_ssl=True, get_info=ALL, port=636)
        self.connection = Connection(
            self.server,
            user=user,
            password=password,
            auto_bind=True
        )

        self.orgs_created = []
        self.groups_created = []
        self.users_created = []
        self.auto_clean = auto_clean

    def _mark_for_auto_clean(self, entity, array):
        if self.auto_clean:
            array.append(entity)

    def delete_ldap_object(self, dn_string):
        """
        Deletes an LDAP object
        :param dn_string: the DN of the object to delete
        :return: unknown
        """
        return self.connection.delete(dn_string, controls=[('1.2.840.113556.1.4.805', False, None)])

    # region AD Group Methods
    def get_ldap_groups(self, dn_string):
        """
        Gets the LDAP groups matching the dn_string
        :param dn_string: The DN of the groups to query
        :return: The LDAP groups matching the query
        """
        self.connection.search(dn_string, '(objectclass=groupOfNames)', attributes=['cn'])
        return self.connection.entries

    def get_ldap_group_details(self, dn_string):
        """
        Gets the group details for the match LDAP group
        :param dn_string: The DN of the groups to query
        :return: The details of the groups matching the query
        """
        self.connection.search(dn_string, '(objectclass=groupOfNames)',
                               attributes=[ALL_ATTRIBUTES, ALL_OPERATIONAL_ATTRIBUTES])
        return self.connection.entries

    def get_ldap_group_members(self, dn_string):
        """
        Get the memebers of the LDAP group
        :param dn_string: The DN of the LDAP group
        :return: The members of the LDAP group
        """
        self.connection.search(dn_string, '(objectclass=groupOfNames)', attributes=['uniqueMember'])
        return self.connection.entries

    def create_ad_group(self, group_name, parent_dn_string):
        """
        Creates an LDAP group on the server
        :param group_name: The name of the group to create
        :param parent_dn_string: The DN of the parent object for the group
        :return: The group details
        """
        dn = f'cn={group_name},{parent_dn_string}'
        self.connection.add(dn, 'groupOfNames')
        self._mark_for_auto_clean(dn, self.groups_created)
        return self.get_ldap_groups(dn)

    # endregion

    # region Contacts Methods
    def create_ad_contact(self, first_name, last_name, email, parent_dn_string):
        """
        Creates a contact with the specified info
        :param first_name: the first name
        :param last_name: the last name
        :param email: the email address
        :param parent_dn_string: The DN of the parent object
        :return: The details of the object created
        """
        self.connection.add('cn={} {},{}'.format(first_name, last_name, parent_dn_string), 'contact',
                            {
                                'givenName': first_name,
                                'sn': last_name,
                                'displayName': '{} {}'.format(first_name, last_name),
                                'mail': email
                            })
    # end region

    # region AD Organizational Unit Methods
    def get_organizational_units(self, dn_string):
        """
        Gets the OU matching the query string
        :param dn_string: The DN to search for
        :return: The LDAP objects that match the query
        """
        self.connection.search(dn_string, '(objectclass=organizationalUnit)', attributes=[ALL_ATTRIBUTES])
        return self.connection.entries

    def create_organizational_unit(self, ou_name, parent_dn_string):
        """
        Creates an OU with the specified name
        :param ou_name: The name of the OU
        :param parent_dn_string: The DN of the parent object for the new group
        :return: The newly created LDAP OU object
        """
        org_name = f'ou={ou_name},{parent_dn_string}'
        self.connection.add(org_name,
                            'organizationalUnit',
                            {
                                'ou': ou_name
                            })
        self._mark_for_auto_clean(org_name, self.orgs_created)
        return self.get_organizational_units(org_name)

    def get_organizational_unit_people(self, dn_string):
        """
        Gets the people in the OU
        :param dn_string: The DN of the OU in question
        :return: A list of the people in the OU
        """
        self.connection.search(dn_string, '(objectclass=person)', attributes=[ALL_ATTRIBUTES])
        return self.connection.entries

    # endregion

    # region AD User Methods
    def create_ldap_user(self, dn_string, cn, payload):
        """
        Creates an LDAP user
        :param dn_string: The DN of the parent object
        :param cn: The CN of the new user
        :param payload: Any additional details about the new object
        :return: The name of the user
        """
        user_name = f'cn={cn},{dn_string}'
        self.connection.add(user_name,
                            'inetOrgPerson',
                            payload)
        self.users_created.append(user_name)
        return user_name

    def create_custom_entry(self, dn, object_class, args):
        """
        Creates a custom LDAP entry
        :param dn: The DN of the new entry
        :param object_class: The class of the object to create
        :param args: Any additional args to apply to the new object
        :return:
        """
        self.connection.add(dn, object_class, args)

    def disable_user(self, dn_string):
        """
        Disables the users account
        :param dn_string: The DN of the user in question
        :return: None
        """
        self.connection.modify(
            dn_string,
            {'userAccountControl': ('MODIFY_REPLACE', ['514'])}
        )

    def add_users_to_group(self, users, dn_string):
        """
        Adds the speoifiec users to the group
        :param users: The users to add to the group
        :param dn_string: The DN of the group
        :return: The group members
        """
        return self.connection.extend.microsoft.add_members_to_groups(
            set(users),
            dn_string
        )

    def remove_users_from_group(self, user, dn_string):
        """
        Removes a user from a group
        :param user: The user to remove
        :param dn_string: The DN of the group
        :return: The user that was removed
        """
        return self.connection.extend.microsoft.remove_members_from_groups(
            user,
            dn_string
        )

    # endregion

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        [self.delete_ldap_object(user) for user in self.users_created]
        [self.delete_ldap_object(group) for group in self.groups_created]
        [self.delete_ldap_object(org) for org in self.orgs_created]

    def __del__(self):
        try:
            self.connection.unbind()
        except:
            pass
