from idaptive_automation.api_payloads.payloads.add_child_roles_to_role import AddChildRolesToRole
from .api_base import ApiBase
from idaptive_automation.api_payloads import RedRock, AssignedRights, AddUsersToRole, AddGroupsToRole, \
    RemoveUsersFromRole, RemoveGroupsFromRole, GetRole, AddUserToRoleV2, RoleMetadata


# noinspection SqlNoDataSourceInspection
class RoleApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.roles_created = []
        self.automation_role_users = []
        super().__init__(api_session, auto_clean, db_metrics)

    def create_role(self, role_name, description="", assert_success=True, cleanup=True):
        """
        Calls the '/saasManage/StoreRole' endpoint
        :param role_name: the name of the role to create
        :param assert_success: Check for a success response
        :param description: the description of the role
        :param cleanup: marks if the role should be cleaned up on teardown
        :return: the id of the role
        """
        payload = {
            "Name": role_name,
            "Description": description
        }
        response = self.api_session.post(f'Creating role: {role_name}',
                                         '/saasManage/StoreRole',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        role_id = response.result()['_RowKey']
        if cleanup:
            self._mark_for_auto_clean(role_id, self.roles_created)
        return role_id

    def create_system_role(self, role_name, role_id, description="", assert_success=True):
        """
        Calls the '/saasManage/StoreRole' endpoint
        :param role_name: the name of the role to create
        :param role_id: the ID(GUID) the role to create
        :param description: the description of the role
        :param assert_success: Check for a success response
        :return: the id of the role
        """
        payload = {"Name": role_name,
                   "ID": role_id,
                   "Description": description}
        response = self.api_session.post(f'Creating System Role: {role_name}',
                                         '/roles/StoreSystemManagedRole',
                                         payload,
                                         assert_success)
        return response

    def create_role_if_not_exists(self, role_name, assert_success=True, cleanup=True):
        """
        Creates a role if it doesn't already exist
        :param role_name: the name of the role to create
        :param assert_success: Check for a success response
        :param cleanup: marks if the role should be cleaned up on teardown
        :return: the id of the role
        """
        role = self.get_role_info_by_name(role_name, assert_success)
        role_id = role['ID'] if role is not None else None
        if role_id is None:
            role_id = self.create_role(role_name, assert_success=assert_success, cleanup=cleanup)
        return role_id

    def update_role_metadata(self, role_id, display_name, description, assert_success=True):
        """
        Update the metadata of a role
        :param role_id: the id of the role in question
        :param display_name: the new display name of the role to update
        :param description: the description of the role to update
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Updating the metadata of the role {role_id}',
                                         '/Roles/UpdateRole',
                                         RoleMetadata(role_id, display_name, description).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def delete_role(self, role_id, assert_success=True, remove_users=True):
        """
        Deletes a role via the '/saasManage/DeleteRoles' endpoint
        :param role_id: the id of the role to delete
        :param assert_success: Check for a success response
        :param remove_users: True will remove all members rom the role prior to deletion
        :return: None or the full response in the format of an APIResponse object
        """
        if remove_users:
            users_list = self.get_role_members(role_id)
            members = []
            for user in users_list:
                members.append(user["Guid"])
            if len(members) > 0:
                self.remove_users_from_role(role_id, members)

        response = self.api_session.post(f'Deleting role: {role_id}',
                                         '/saasManage/DeleteRoles',
                                         [role_id],
                                         assert_success)
        if not assert_success:
            return response

    def get_role_info(self, role_id, assert_success=True):
        """
        Gets details about the role
        :param role_id: the id of the role to query
        :param assert_success: Check for a success response
        :return: the full response in the format of an APIResponse object
        """
        return self.api_session.post(f'Getting role info for role: {role_id}',
                                     '/saasManage/GetRole',
                                     GetRole(role_id).to_payload(),
                                     assert_success)

    def get_sys_admin_role_id(self):
        """
        Gets the id of the 'sysadmin' role
        :return: the id of the 'sysadmin' role
        """
        return self.get_role_info("sysadmin")

    def get_all_roles(self, assert_success=True):
        """
        Gets a list of all roles on the teant
        :param assert_success: Check for a success response
        :return: a dictionary object
        """
        payload = RedRock(
            "Select ID, COALESCE(Name, ID) AS Name, RoleType, ReadOnly, Description, DirectoryServiceUuid from Role ORDER BY Name COLLATE NOCASE",
            "Name")
        response = self.api_session.post(f'Getting roles',
                                         '/RedRock/query',
                                         payload.to_payload(),
                                         assert_success)
        if not assert_success:
            return response
        return [{"Name": result['Row']['Name'],
                 "ID": result['Row']['ID'],
                 "Description": result['Row']['Description'],
                 "RoleType": result['Row']['RoleType'],
                 "DirectoryServiceUuid": result['Row']['DirectoryServiceUuid']} for result in response.results()]

    def get_role_info_by_name(self, role_name, assert_success=True):
        """
        Gets the details of a role by name
        :param role_name: the name of the role to query
        :param assert_success: Check for a success response
        :return: a dictionary object
        """
        roles = [role for role in self.get_all_roles(assert_success) if role['Name'] == role_name]
        return roles[0] if len(roles) == 1 else None

    def get_role_members(self, role_id, assert_success=True):
        """
        Gets a list of all role memebers
        :param role_id: the id of the role
        :param assert_success: Check for a success response
        :return: A list of dictionary objects
        """
        response = self.api_session.post(f'Getting role members for role: {role_id}',
                                         f'/saasManage/GetRoleMembers?name={role_id}',
                                         assert_success=assert_success)
        if not assert_success:
            return response
        return [{"Name": result['Row']['Name'], "Guid": result['Row']['Guid'], "Type": result['Row']['Type']} for result
                in response.results()]

    def get_role_apps(self, role_id, assert_success=True):
        """
        Gets a list of all apps assigned to a role by id
        :param role_id: the id of the role in question
        :param assert_success: Check for a success response
        :return: The 'Result.Results' property of the response object
        """
        response = self.api_session.post('',
                                         f'/saasManage/GetRoleApps?role={role_id}',
                                         assert_success=assert_success)
        if not assert_success:
            return response
        return response.results()

    def get_apps_for_app_users_role(self):
        """
        Gets a list of all apps deployed to the 'App Users' role
        :return: a list of dictionaries
        """
        return self.get_apps_for_role('App Users')

    def get_apps_for_role(self, role_name):
        """
        Gets a list of apps for a role by name
        :param role_name: the name of the role in question
        :return: A list of dictionaries
        """
        role = self.get_role_info_by_name(role_name)
        return [app['Row'] for app in self.get_role_apps(role['ID'])]

    def add_users_to_role(self, role_id, user_ids, assert_success=True):
        """
        Adds a list of users to a role
        :param role_id: the id of the role in question
        :param user_ids: a list of uuids for the users
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Adding {len(user_ids)} to role {role_id}',
                                         '/Roles/UpdateRole',
                                         AddUsersToRole(role_id, user_ids).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def add_users_to_role_v2(self, role_id, user_ids, ds_uuid, assert_success=True):
        """
        Adds a list of users to a role via UpdateRoleV2
        :param role_id: the id of the role in question
        :param user_ids: a list of uuids for the users
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Adding {len(user_ids)} to role {role_id} via V2',
                                         '/Roles/UpdateRoleV2',
                                         AddUserToRoleV2(role_id, user_ids, ds_uuid).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def add_child_role_to_role(self, parent_role_id, child_role_ids, assert_success=True):
        """
                Adds a list of child roles to a parent role
                :param parent_role_id: the id of the parent role in question
                :param child_role_ids: a list of child roles to add to the parent role
                :param assert_success: Check for a success response
                :return: None or the full response in the format of an APIResponse object
                """
        response = self.api_session.post(f'Adding {len(child_role_ids)} to role {parent_role_id}',
                                         '/Roles/UpdateRole',
                                         AddChildRolesToRole(parent_role_id, child_role_ids).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def __automation_role_id__(self):
        return self.get_role_info_by_name('App Services Automation')['ID']

    def add_users_to_automation_role(self, user_ids):
        """
        Adds a list of users to the automation role
        :param user_ids: a list of uuids for the users
        :return: None
        """
        self.add_users_to_role(self.__automation_role_id__(), user_ids)
        for uid in user_ids:
            self._mark_for_auto_clean(uid, self.automation_role_users)

    def add_users_to_automation_role_v2(self, user_ids, ds_uuid):
        """
        Adds a list of users to the automation role
        :param user_ids: a list of uuids for the users
        :return: None
        """
        self.add_users_to_role_v2(self.__automation_role_id__(), user_ids, ds_uuid)

    def add_groups_to_role(self, role_id, group_ids, assert_success=True):
        """
        Adds a list of LDAP groups to a role
        :param role_id: the id of the role in question
        :param group_ids: the ids of the groups to add
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Adding {len(group_ids)} group(s) to role {role_id}',
                                         '/Roles/UpdateRole',
                                         AddGroupsToRole(role_id, group_ids).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def remove_users_from_role(self, role_id, user_ids, assert_success=True):
        """
        Removes a list of users from a role
        :param role_id: the id of the role in question
        :param user_ids: a list of the uuids for the users
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Removing {len(user_ids)} from role {role_id}',
                                         '/Roles/UpdateRole',
                                         RemoveUsersFromRole(role_id, user_ids).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def remove_groups_from_role(self, role_id, group_ids, assert_success=True):
        """
        Removes a list of groups from a role
        :param role_id: the id of the role in question
        :param group_ids: a list of the group ids
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Removing {len(group_ids)} from role {role_id}',
                                         '/Roles/UpdateRole',
                                         RemoveGroupsFromRole(role_id, group_ids).to_payload(),
                                         assert_success)
        if not assert_success:
            return response

    def get_all_admin_rights(self, assert_success=True):
        """
        Gets a list of all admin rights via RedRock query
        :param assert_success: Check for a success response
        :return: a list of dictionaries
        """
        response = self.api_session.post('Getting all admin rights',
                                         '/RedRock/query',
                                         RedRock("@/lib/get_superrights.js(excludeRight:'')").to_payload(),
                                         assert_success)
        if not assert_success:
            return response
        return [role['Row'] for role in response.results()]

    def get_assigned_super_rights_for_role(self, role_id, assert_success=True):
        """
        Gets a list of admin rights assigned to role
        :param role_id: the id of the role in question
        :param assert_success: Check for a success response
        :return: a list of dictionaries
        """
        response = self.api_session.post(f'Getting assigned admin rights for role {role_id}',
                                         '/core/GetAssignedAdministrativeRights',
                                         AssignedRights(role_id).to_payload(),
                                         assert_success)
        if not assert_success:
            return response
        return [role['Row'] for role in response.results()]

    def assign_super_rights_to_role(self, payload, assert_success=True):
        """
        Assigns the specified admin rights to a role
        :param payload: the list of admin rights
        :param assert_success: Check for a success response
        :return: None or the full response in the format of an APIResponse object
        """
        response = self.api_session.post(f'Assigning super rights to role. {payload}',
                                         '/saasManage/AssignSuperRights',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

    def remove_super_rights_from_role(self, payload, assert_success=True):
        """
        Removes the specified admin rights from a role
        :param payload: the list of admin rights to remove
        :param assert_success: Check for a success response
        :return: None
        """
        response = self.api_session.post(f'Removing super rights from role. {payload}',
                                         '/saasManage/UnAssignSuperRights',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

    def add_users_and_groups_to_alero_roles(self, payload):
        """
               Calls the '/SaasManage/AddUsersAndGroupsToRole' endpoint
               :param assert_success: Check for a success response
               :return: if the api is successful or not
               """
        response = self.api_session.post('',
                                         '/SaasManage/AddUsersAndGroupsToRole',
                                         payload
                                         )

        assert response.success()
        return response

    def remove_users_and_groups_from_alero_roles(self, payload):
        """
                       Calls the '/SaasManage/RemoveUsersandGroupsfromRoles' endpoint
                       :param assert_success: Check for a success response
                       :return: if the api is successful or not
                       """
        response = self.api_session.post('',
                                         '/SaasManage/RemoveUsersAndGroupsFromRole',
                                         payload)
        assert response.success()
        return response

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        [self.delete_role(role_id) for role_id in self.roles_created]
        if self.automation_role_users:
            self.remove_users_from_role(self.__automation_role_id__(), self.automation_role_users)
