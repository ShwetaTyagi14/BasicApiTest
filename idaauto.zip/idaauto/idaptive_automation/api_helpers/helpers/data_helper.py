from .api_base import ApiBase


class DataHelper(ApiBase):
    """
    Under development
    """
    def get_random_passwords(self, count=1):
        return self.api_session.post('',
                                     f'/query?command=password&format=json&count={count}',
                                     None)
