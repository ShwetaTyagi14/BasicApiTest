import time


def current_milliseconds():
    return int(round(time.time() * 1000))
