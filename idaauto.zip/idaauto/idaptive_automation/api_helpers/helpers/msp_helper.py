from .api_base import ApiBase


class MSPHelper(ApiBase):
    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        super().__init__(session, auto_clean, db_metrics)

    def get_otp_token(self, tenant_id, assert_success=True):
        """
        Calls '/msp/getmanagementlink' to get a one time password
        :param tenant_id: the id of the tenant you want to login to
        :param assert_success: Check for a success response
        :return: the OTP token
        """
        payload = {
            "tenantId": tenant_id
        }

        response = self.api_session.post('',
                                         '/msp/getmanagementlink',
                                         payload,
                                         assert_success)
        if not assert_success:
            return response

        return response.result()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
