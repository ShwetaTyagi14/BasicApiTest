from .api_base import ApiBase
import re


class IBEHelper(ApiBase):
    def __init__(self, session, auto_clean=False, db_metrics=True):
        """
        :param session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        super().__init__(session, auto_clean, db_metrics)

    def get_latest_cloud_version(self):
        """
        Calls '/SaasManage/GetAllCBEUrls' and gets the cloud version
        :return: (string) the cloud version
        """
        return self.get_all_ibe_urls()['Stable'][0]['CloudVersion']

    def get_all_versions(self):
        """
        Calls '/SaasManage/GetAllCBEUrls'
        :return: A formatted list of all versions
        """
        pattern = '.*/(\d\.\d{3}\.\d{2,})/.*'
        versions = dict([(k, v) for k, v in self.get_all_ibe_urls()['Stable'][0].items()])

        unneeded_keys = []
        for k, v in versions.items():
            if isinstance(v, str):
                if re.match(pattern, versions[k]):
                    versions[k] = re.match(pattern, v).groups()[0]
            else:
                unneeded_keys.append(k)

        for k in unneeded_keys:
            del versions[k]
        return versions

    def get_all_ibe_urls(self):
        """
        Calls '/SaasManage/GetAllCBEUrls'
        :return: The 'REsult' property of the response object
        """
        response = self.api_session.post('Getting All CBE Urls',
                                         '/SaasManage/GetAllCBEUrls',
                                         None)

        assert response.success(), 'failed to get CBE Urls'
        return response.result()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
