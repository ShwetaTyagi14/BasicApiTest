from .plink_helpers import PlinkHelper
from .json_helper import fix_ms_json_dates
from .api_base import ApiBase
from pprint import pprint as pp


class PolicyApi(ApiBase):
    def __init__(self, api_session, auto_clean=False, db_metrics=True):
        """
        :param api_session: an authenticated API client
        :param auto_clean: Remove anything this helper creates when it is
        :param db_metrics: this flag determines if a metric db record should be inserted
        destroyed (must be used in a 'with' block)
        """
        self.last_rev_stamp = None
        self.policies_created = []
        super().__init__(api_session, auto_clean, db_metrics)

    policy_blocks = {}
    plinks = None
    revstamps = {}

    def get_policy_block(self, policy_name="/Policy/Default Policy", **kwargs):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name:
        :param kwargs:
        :return: The full response in the format of an APIResponse object
        """
        payload = {
            'name': policy_name
        }

        response = self.api_session.post('Retrieving Policy Block',
                                         '/Policy/GetPolicyBlock',
                                         payload)

        if response.success():
            self.policy_blocks[policy_name] = response.result()
            self.revstamps[policy_name] = response.result()['RevStamp']

        return response

    def get_nice_plinks(self, **kwargs):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param kwargs:
        :return: The full response in the format of an APIResponse object
        """
        payload = {
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                **kwargs
            }
        }

        response = self.api_session.post('Getting plinks',
                                         '/Policy/GetNicePlinks', payload)
        self.plinks = response.results()

        return response

    def set_plinks(self, plinks, rev_stamp=None, assert_success=True):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param plinks:
        :param rev_stamp:
        :param assert_success: Check for a success response
        :return: The full response in the format of an APIResponse object
        """
        if rev_stamp is None:
            rev_stamp = self.get_nice_plinks().result()['RevStamp']

        payload = {
            'Plinks': plinks,
            'RevStamp': f'{rev_stamp}'
        }

        response = self.api_session.post('Setting plinks',
                                         '/Policy/setPlinksv2',
                                         payload,
                                         assert_success)
        return response

    def _parse_hr_policies_from_plinks(self):
        return PlinkHelper().parse_hr_policies_from_plinks(self.plinks)

    def get_admin_policy_list(self):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :return:
        """
        self.get_nice_plinks()
        return self._parse_hr_policies_from_plinks()

    def get_policy_info_by_name(self, policy_name):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name:
        :return:
        """
        policies = self.get_admin_policy_list()
        matches = list(filter(lambda p: p['Name'] == policy_name, policies))
        return matches[0] if len(matches) > 0 else None

    def get_policy_settings(self, settings=None):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param settings:
        :return: The 'Result' property of the response object
        """
        payload = {
            'policies': settings
        }
        response = self.api_session.post('Checking policy settings',
                                         '/Policy/PolicyChecks', payload)
        assert response.success()

        fix_ms_json_dates(response.result())
        return response.result()

    def set_default_profile(self, profile_name, uuid=None,
                            policy_name='/Policy/Default Policy', profile_payload=None):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param profile_name:
        :param uuid:
        :param policy_name:
        :param profile_payload:
        :return:
        """
        if policy_name not in self.policy_blocks:
            self.get_policy_block(policy_name=policy_name)
        if profile_name and not uuid:
            uuid = self.get_profile_uuid_using_name(profile_name, profile_payload=profile_payload)

        if uuid:
            self.policy_blocks[policy_name]['Settings']['/Core/Authentication/AuthenticationRulesDefaultProfileId'] = \
                uuid
            self.update_policy(policy_name=policy_name, settings=self.policy_blocks[policy_name]['Settings'])

    def get_profile_uuid_using_name(self, profile_name, profile_payload=None):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param profile_name:
        :param profile_payload:
        :return:
        """
        profile_list = self.api_session.auth_profile.get_profile_list().Result
        for profile in profile_list:
            if profile.Name == profile_name:
                return profile.Uuid
        if profile_payload:
            result = self.api_session.auth_profile.save_profile(**profile_payload['settings'])
            if result.success is True:
                return result.Result.Uuid
        return None

    def save_policy_block_2(self, payload, policy_name):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param payload:
        :param policy_name: The name of the policy to save
        :return: The full response in the format of an APIResponse object
        """
        response = self.api_session.post('Saving policy block',
                                         f'/Policy/SavePolicyBlock2?name={policy_name}',
                                         payload)

        return response

    def update_policy(self, policy_name, settings):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name: The name of the policy to update
        :param settings:
        :return: The full response in the format of an APIResponse object
        """
        self.get_policy_block(policy_name=policy_name)
        self.get_nice_plinks()

        payload = {
            "policy": {
                "Newpolicy": False,
                "Path": policy_name,
                "RevStamp": self.revstamps[policy_name],
                "Description": f"Automation test policy {policy_name}",
                "Version": 1,
                "Settings": settings
            },
            "plinks": self.massage_plinks(self.plinks)
        }

        response = self.api_session.post('Saving policy block',
                                         '/Policy/SavePolicyBlock3',
                                         payload)
        return response

    def deactivate_policy(self, policy_name):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name: The name of the policy to deactivate
        :return: The full response in the format of an APIResponse object
        """
        policy = self.get_policy_block(policy_name=policy_name).result()
        self.get_nice_plinks()

        plink = next(iter([pl for pl in self.plinks if pl['Row']['ID'].endswith(policy_name)]))
        if plink is None:
            raise Exception(f"Policy named {policy_name} not found")
        del plink['Row']['EnableCompliant']
        plink['Row']['LinkType'] = 'Inactive'
        payload = {
            "policy": policy,
            "plinks": self.massage_plinks(self.plinks)
        }

        response = self.api_session.post('Saving policy block',
                                         '/Policy/SavePolicyBlock3',
                                         payload)
        return response

    def activate_global_policy(self, policy_name):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name: The name of the policy to activate
        :return: The full response in the format of an APIResponse object
        """
        policy = self.get_policy_block(policy_name=policy_name).result()
        self.get_nice_plinks()

        plink = next(iter([pl for pl in self.plinks if pl['Row']['ID'].endswith(policy_name)]))
        if plink is None:
            raise Exception(f"Policy named {policy_name} not found")
        plink['Row']['EnableCompliant'] = True
        plink['Row']['LinkType'] = 'Global'
        payload = {
            "policy": policy,
            "plinks": self.massage_plinks(self.plinks)
        }

        response = self.api_session.post('Saving policy block',
                                         '/Policy/SavePolicyBlock3',
                                         payload)
        return response

    def change_policy_setting(self, setting, value,
                              policy_name="/Policy/Default Policy"):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param setting:
        :param value:
        :param policy_name: The name of the policy to change
        :return:
        """
        self.get_policy_block(policy_name=policy_name)

        self.policy_blocks[policy_name]['Settings'][setting] = value

        return self.update_policy(policy_name=policy_name,
                                  settings=self.policy_blocks[policy_name]['Settings'])

    def delete_policy_setting(self, setting, policy_name):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param setting:
        :param policy_name: The name of the policy to delete
        :return:
        """
        self.get_policy_block(policy_name=policy_name)

        self.policy_blocks[policy_name]['Settings'].pop(setting)

        return self.update_policy(policy_name=policy_name,
                                  settings=self.policy_blocks[policy_name]['Settings'])

    def update_via_policyblock2(self, policy_name, **kwargs):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name:
        :param kwargs:
        :return:
        """
        if policy_name not in self.policy_blocks:
            self.get_policy_block(policy_name=policy_name)
        if self.plinks is None:
            self.get_nice_plinks()
        payload = {
            'description': self.policy_blocks[policy_name]['Description'],
            'newpolicy': False,
            'path': policy_name,
            'plinks': self.massage_plinks(self.plinks),
            'settings':
                {
                    'Version': self.policy_blocks[policy_name]['Version'],
                    'Settings': self.policy_blocks[policy_name]['Settings'],
                    'AuthProfiles': self.policy_blocks[policy_name]['AuthProfiles'],
                    'Path': self.policy_blocks[policy_name]['Path']
                },
            **kwargs
        }

        return self.save_policy_block_2(payload=payload)

    def create_policy(self, policy_name, settings,
                      link_type='Global', params=None,
                      assert_success=True, debug=False,
                      description=""):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name:
        :param settings:
        :param link_type:
        :param params:
        :param assert_success: Check for a success response
        :param debug: print the payload before posting it
        :param description: the description of the policy
        :return: The full response in the format of an APIResponse object
        """
        self.get_nice_plinks()
        if not params:
            params = []

        plink = {
            "Description": "",
            "PolicySet": f"/Policy/{policy_name}",
            "LinkType": link_type,
            "Priority": 1,
            "Params": params,
            "Filters": [],
            "Allowedpolicies": []
        }

        plinks = [plink] + self.massage_plinks(self.plinks)

        url = '/Policy/SavePolicyBlock3'
        payload = {
            "policy": {
                "Newpolicy": True,
                "Path": f"/Policy/{policy_name}",
                "Description": description,
                "Version": 1,
                "Settings": settings
            },
            "plinks": plinks
        }

        if debug:
            pp(f'Creating policy:\r\n{payload}')

        response = self.api_session.post('Saving new policy', url, payload, assert_success)
        if assert_success:
            self._mark_for_auto_clean(policy_name, self.policies_created)

        return response

    def delete_policy(self, policy_name):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param policy_name:
        :return: The full response in the format of an APIResponse object
        """
        if '/Policy/' not in policy_name:
            policy_name = f'/Policy/{policy_name}'

        payload = {"path": policy_name}

        response = self.api_session.post('Deleting policy block',
                                         '/Policy/DeletePolicyBlock',
                                         payload)

        return response

    def get_users_policy_summary(self, userid):
        """
        :param userid: User's Uuid
        :return: The full response in the format of an APIResponse object
        """
        payload = {
            "userid": f"{userid}"
        }
        response = self.api_session.post('Retrieving User Policy Summary',
                                         '/Policy/GetRsop',
                                         payload)
        return response.result()

    def _delete_policies(self, policy_names):
        return [self.delete_policy(name) for name in policy_names]

    @staticmethod
    def massage_plinks(plink_result):
        """
        LEGACY METHOD - NO DOCUMENTATION
        :param plink_result:
        :return:
        """
        plinks = []

        for i in range(len(plink_result)):
            plinks.append(plink_result[i]['Row'])
            plinks[i]['inode'] = ""
            plinks[i]['id'] = i + 1

        return plinks

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._delete_policies(self.policies_created)
