from .api_base import ApiBase
from idaptive_automation.api_payloads import RedRockArgs, NewAlias


class TenantApiHelper(ApiBase):

    def get_aliases_for_tenant(self):
        """
        Gets a list of aliases for the tenant
        :return: a dictionary object
        """
        response = self.api_session.post('Getting aliases for tenants',
                                         '/core/GetAliasesForTenant',
                                         RedRockArgs().to_payload())
        return [row['Entities'][0]['Key'] for row in response.results()]

    def create_alias(self, alias, tenant_id):
        """
        Creates an alias for the tenant
        :param alias: the alias to create
        :param tenant_id: the id of the tenant
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/core/StoreAlias',
                                         NewAlias(alias, tenant_id).to_payload())
        return response.result()

    def update_alias(self, alias, old_alias):
        """
        Creates an alias for the tenant
        :param alias: the new alias
        :param old_alias: the old alias
        :return: The 'Result' property of the response object
        """

        payload = {"alias": alias,
                   "domain": alias,
                   "cdsAlias": True,
                   "oldName": old_alias}

        response = self.api_session.post('', '/core/StoreAlias', payload)
        return response.result()

    def precreate_tenant(self, payload):
        """
        Creates a tenant via '/Entitlements/PreCreateTenant'
        :param payload: the details of the tenant to create
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post("",
                                         '/Entitlements/PreCreateTenant',
                                         payload)
        return response.result()

    def delete_alias(self, alias):
        """
        Deletes an alias for the tenant
        :param alias: the alias to remove
        :return: The 'Result' property of the response object
        """
        payload = [alias]
        response = self.api_session.post('',
                                         '/core/DeleteAliases',
                                         payload)
        return response.result()

    def get_tenant_certificate(self):
        """
        Gets the tenant certificate info via '/core/GetCertificateInfos'
        :return: The 'Result' property of the response object
        """
        payload = {"Args": {"PageNumber": 1, "PageSize": 100000, "Limit": 100000, "SortBy": "", "direction": "False",
                            "Caching": -1}}
        response = self.api_session.post('',
                                         '/core/GetCertificateInfos?type=Application',
                                         payload)
        return response.result()

    def update_tenant_flag(self, key, value):
        """
        Updates/Adds Tenant Key via '/core/SetTenantConfig'
        :return: The 'Result' property of the response object
        Requires Core.SetTenantConfig.Whitelist.Enabled set to False
        or the Key, being updated, added to the whitelist(Core.SetTenantConfig.Whitelist.NonProd).
        """
        payload = {
            "key": key,
            "value": value
        }

        response = self.api_session.post('',
                                         '/core/SetTenantConfig',
                                         payload)
        return response

    def get_tenant_flag(self, key, defult_value):
        """
        Get Tenant Key via '/core/GetTenantConfig'
        :return: The 'Result' property of the response object
        """
        payload = {
            "key": key,
            "dflt": defult_value
        }

        response = self.api_session.post('',
                                         '/core/GetTenantConfig',
                                         payload)
        return response

    def delete_tenant_flag(self, key):
        """
        Deletes Tenant Key via '/core/DeleteTenantConfig'
        :return: The 'Result' property of the response object
        Requires Core.SetTenantConfig.Whitelist.Enabled set to False
        or the Key, being updated, added to the whitelist(Core.SetTenantConfig.Whitelist.NonProd).
        """
        payload = {
            "key": key,
        }

        response = self.api_session.post('',
                                         '/core/DeleteTenantConfig',
                                         payload)
        return response.result()

    def update_tenant_entitlement(self, tenant_id, entitlement_id, enable=True):
        """
        Changes an Entitlement of a tenant via '/Cybr/EnableEntitlement'
        return: The 'Result' property of the response object
        Requires that the station or devdog Master tenant is added to pod's whitelisting
        is in the partner_controllers.json
        And has to be called from the master to update the child.
        """
        payload = {
            "tenantId": tenant_id,
            "entitlementId": entitlement_id,
            "enable": enable
        }

        response = self.api_session.post('',
                                         '/Cybr/EnableEntitlement',
                                         payload)
        return response.result()

    def set_customer_config(self, payload):
        """
        Sets PVWA values using '/TenantConfig/SetCustomerConfig' API
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/TenantConfig/SetCustomerConfig',
                                         payload)
        return response.success(), response.message()

    def get_customer_config(self):
        """
        Sets PVWA values using '/TenantConfig/GetCustomerConfig' API
        :return: The 'Result' property of the response object
        """
        payload = {}

        response = self.api_session.post('',
                                         '/TenantConfig/GetCustomerConfig',
                                         payload)
        return response.success(), response.result()

    def set_uisettings(self, uisection):
        """
        Sets UI Settings values using '/TenantConfig/SetUISettings' API
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/TenantConfig/SetUISettings',
                                         {"uisection" : uisection})
        return response.success(), response.result()

    def get_download_urls(self):
        """
        Gets the Download urls for things like Idaptive Browser Extension, Agents, Connector, etc
        Returns: Tenant Download links as found on the Downloads page in UI
        """
        payload = {"Args":{"PageNumber":1,"PageSize":100000,"Limit":100000,"SortBy":"","Caching":-1}}

        response = self.api_session.post("Getting download URLs",
                                         '/core/GetDownloadUrls',
                                         payload)

        return response.result()

    def set_social_auth_config(self, payload):
        """
        Sets Social login values using 'SocialAuthMgmt/SetAuthConfig' API
        :return: The 'Result' property of the response object
        """
        response = self.api_session.post('',
                                         '/SocialAuthMgmt/SetAuthConfig',
                                         payload)
        return response.result()
