from idaptive_automation.api_helpers import EmailHelper
from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
from idaptive_automation.api_helpers.helpers.aad_helper import AzureActiveDirectoryHelper
import json


def test_email_format():
    with AutomationMongoClient(EnvironmentCredentials(), 'adminAccounts').connect() as client:
        creds = client.find_one('email', {'isDefault': True})
        email = EmailHelper(creds).check_mail()
        assert email is not None


def test_parse_bulk_user_import_report():
    with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
        email = client.find_one('email',
                                {'message.subject': 'Idaptive Identity Service - Bulk Import Report',
                                 'message.attachments': {'$ne': []}}
                                )

    body = email['message']['body'][0]
    email = EmailHelper(None)._parse_bulk_user_import_report(body)
    assert email is not None
    assert email['emailType'] == 'bulk user import report'
    assert email['usersSubmitted'] == 9
    assert email['usersImported'] == 9


def test_parse_csv_attachment():
    content = "Login Name,Password,Email Address,Display Name,Office Number,Mobile Number,Home Number,Roles,Description,Expiration Date,Error\r\nlogin@aaq0066,1234,mail@domain.com,\"Lastname, Firstname\",None,None,None,,None,,\"Password for User name login@aaq0066 is invalid: Password does not meet policy requirements: Must be at least 8 characters long, not be longer than 64 characters, contain at least one digit, contain at least one upper and one lower case letter.\"\r\n"
    attachment = EmailHelper._parse_attachment_content(content)
    print('\r\n')
    assert attachment is not None
    assert len(attachment) == 1
