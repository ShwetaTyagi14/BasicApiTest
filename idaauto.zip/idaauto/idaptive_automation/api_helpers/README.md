# api_helpers
This project contains all the API helper classes that know how to make API calls and format the responses so they can be easily consumed by our tests

### When to use or create a helper class:
Helper classes should be used to encapsulate common functionality when making API calls:
* To remember the url of a particular endpoint
* To format the response of an API call into a standard format - if a test needs to reformat a response into a more user-friendly format, this should be done in a helper
* To encapsulate any common functionality that might be used by another test
* To allow test setup and teardown to be done outside the scope of the test

Example: to have a test fixture create users prior to the test run, and remove them from the tenant after the test run:

```python
"""
This fixture creates 4 users of different types, then deletes the users after the test completes
"""
@pytest.fixture()
def user_fixture(session_fixture):
    with UserApi(session_fixture['session'],auto_clean=True) as user_api:
        user_api.create_invited_user(alias, 'c33448-invited')
        user_api.create_service_user(alias, 'c33448-service')    
        user_api.create_interactive_user(alias, 'c33448-active', send_invite=False)
        payload = user_api.create_interactive_user(alias, 'c33448-suspended', send_invite=False)
        user_api.lock_user_account(payload['Name'])
        yield user_api
```


For more usage examples, refer to the [main idaptive-automation repo README.md file](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/readme.md)