param (
[string]$searchstring = "a8a30945contact1",
    [string]$username = "",
    [string]$password = ""

)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord


Connect-MsolService -Credential $Credential

$create_expression = "Get-MsolContact -SearchString """ + $searchstring + """ | Remove-MsolContact -Force"

Invoke-Expression $create_expression

#debug stuff below:

#Write-Output " "
#write-output "********************"
write-output $searchstring
write-output $create_expression