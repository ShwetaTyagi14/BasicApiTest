param (
    [string]$search_string = "xxx",
    [string]$username = "",
    [string]$password = ""

)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord

Connect-MsolService -Credential $Credential

$search_expression = "Get-Msolgroup -SearchString " + $search_string + " | Select-Object objectID "

$objectIDList = Invoke-Expression $search_expression

$groupmemberlist_expression = "Get-MsolGroupMember -GroupObjectID " + $objectIDList.objectID

$groupmembers = Invoke-Expression $groupmemberlist_expression

$out = "{'Group': {'Name': '" + $objectIDList.objectID + "','Members': ["

foreach ($groupmember in $groupmembers){
    $out += "{'User': '" + $groupmember.EmailAddress + "', 'DisplayName': '" + $groupmember.DisplayName + "', 'MemberOf': '" + $search_string + "'},"
}

$out = $out.TrimEnd(",") + "]}}"

Write-Output $out