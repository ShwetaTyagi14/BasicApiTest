param (
    [string]$search_string = "",
    [string]$username = "",
    [string]$password = ""

)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord

Connect-MsolService -Credential $Credential

$search_expression = "Get-MsolContact -SearchString " + $search_string + " -All"

$userList = Invoke-Expression $search_expression
$out = "{'Contacts': ["

foreach ($user in $userList){
    $out += "{'EmailAddress': '" + $user.EmailAddress + "', 'DisplayName': '" + $user.DisplayName + "', 'ObjectId': '" + $user.ObjectId + "'},"
}

$out = $out.TrimEnd(",") + "]}"

Write-Output $out