param (
    [string]$search_string = "O365Prov",
    [string]$username = "",
    [string]$password = ""

)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord

Connect-MsolService -Credential $Credential

$search_expression_Main = "Get-MsolUser -SearchString " + $search_string + " -All"

$userList = Invoke-Expression $search_expression_Main
$out = "{'Users': ["

foreach ($user in $userList){
    $out_attrs = "'Attributes': {"

    $out_attrs += "'department': '" + $user.Department + "', 'ProxyAddresses': '" + $user.ProxyAddresses + "', 'physicalDeliveryOfficeName': '" + $user.Office + "', 'telephoneNumber': '" + $user.PhoneNumber + "', 'MobileNumber': '" + $user.MobilePhone + "', 'facisimileTelephoneNumber': '" + $user.Fax + "', 'l': '" + $user.City + "', 'co': '" + $user.Country + "', 'postalCode': '" + $user.PostalCode + "', 'title': '" + $user.Title + "'}"

    $out += "{'UserPrincipalName': '" + $user.UserPrincipalName + "', 'DisplayName': '" + $user.DisplayName + "', $out_attrs},"
}

$out = $out.TrimEnd(",") + "]}"
Write-Output $out