param (
    [string]$search_string = "",
    [string]$username = "",
    [string]$password = ""

)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord

Connect-MsolService -Credential $Credential

$search_expression = "Get-MsolUser -SearchString " + $search_string + " -All"

$userList = Invoke-Expression $search_expression
$out = "{'Users': ["

foreach ($user in $userList){
    $out += "{'UserPrincipalName': '" + $user.UserPrincipalName + "', 'DisplayName': '" + $user.DisplayName + "', 'IsLicensed': " + $user.IsLicensed + "},"
}

$out = $out.TrimEnd(",") + "]}"

Write-Output $out