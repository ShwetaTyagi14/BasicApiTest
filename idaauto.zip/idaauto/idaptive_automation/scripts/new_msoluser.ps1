param (
    [string]$username = "",
    [string]$password = "",
    [string]$newusername = "",
    [string]$newdisplayname = "",
    [string]$newfirstname = "",
    [string]$newlastname = "",
    [string]$newpassword = ""


)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord

Connect-MsolService -Credential $Credential

$new_users_expression = "New-MsolUser -UserPrincipalName """ + $newusername + """ -DisplayName """ + $newdisplayname + """ -FirstName """ + $newfirstname + """ -LastName """ + $newlastname + """ -Password """ + $newpassword + """ -PasswordNeverExpires $True"

$user_creation_results = Invoke-Expression $new_users_expression

Write-Output $user_creation_results