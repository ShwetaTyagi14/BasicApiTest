param (
    [string]$search_string = "xxx",
    [string]$username = "",
    [string]$password = ""

)

$PWord = ConvertTo-SecureString -String $password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $PWord

Connect-MsolService -Credential $Credential

$search_expression_users = "Get-Msoluser -SearchString " + $search_string + " -All | measure"

$search_expression_groups = "Get-MsolGroup -SearchString " + $search_string + " -All | measure"

$search_expression_contacts = "Get-MsolContact -SearchString " + $search_string + " -All | measure"

$userList = Invoke-Expression $search_expression_users

$groupList = Invoke-Expression $search_expression_groups

$contactList = Invoke-Expression $search_expression_contacts

$out = "{'O365Objects': ["

foreach ($user in $userList){
    $out += "{'Users': '" + $userList.Count + "', 'Groups': '" + $groupList.Count + "', 'Contacts': '" + $contactList.Count + "'},"
}

$out = $out.TrimEnd(",") + "]}"

Write-Output $out