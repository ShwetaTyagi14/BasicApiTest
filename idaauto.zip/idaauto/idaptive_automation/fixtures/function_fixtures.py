import pytest
from .fixture_base import offline_fixture, cleanup_fixture, connected_fixture, parse_args, b2b_partner_connected_fixture


@pytest.fixture()
def authenticated_api_function_fixture(request,
                                       api_session,
                                       mongo_dal):
    args = parse_args(request)

    session = connected_fixture(args, api_session, mongo_dal)
    yield session

    cleanup_fixture(session)


@pytest.fixture()
def authenticated_b2b_partner_api_function_fixture(request,
                                                   api_session,
                                                   mongo_dal):
    args = parse_args(request)

    session = b2b_partner_connected_fixture(args, api_session, mongo_dal)
    yield session

    cleanup_fixture(session)
