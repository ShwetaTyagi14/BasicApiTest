# fixtures
## Creating and using test fixtures
#### API fixtures
Making API calls with this framework is straight forward. You need:
* An authenticated API client
* An API helper that knows how to make the calls you need to make

You can handle this yourself by directly creating an ApiSession object and passing in the credentials, or you can use one of the fixtures that handle all that for you.

#### Naming conventions:
You will lots of references to objects with names like: `api_session_fixture`, or `api_function_fixture`. The middle
word is the scope of the fixture: `api_<scope>_fixture`. See notes below
> Note on terminology: There are two objects here that unfortunately have similar names, and this can cause confusion. An `api_<scope>_fixture`
generally represents the actual API client, whereas an `authenticated_api_<scope>_fixture` represents the test session object,
which contains the api client as well as the tenant database record with additional information the test might need.
Usually your tests will take a parameter of `session_fixture`, and the other imports are included because they are
required by the `session_fixture` object.
Example:

```python
# this statement is used in the test itself (note the import is renamed 'as session_fixture'):
from idaptive_automation.fixtures import authenticated_api_session_fixture as session_fixture

def test_something(session_fixture):
    # session_fixture contains an authenticated ApiSession object, plus the entire DB record for the tenant
    # The test will generally need both the client and the information about the tenant in order to do what
    # it needs to
    pass
```
```python
# this statement is used to import the api client and mongodb client that pytest will pass to 
# the session_fixture object:
from idaptive_automation.api_client import api_session_fixture as api_session, mongo_session_client as mongo_dal
```
```python
# Hence, most of your tests will have these two import statements:
from idaptive_automation.api_client import api_session_fixture as api_session, mongo_session_client as mongo_dal
from idaptive_automation.fixtures import authenticated_api_session_fixture as session_fixture
```

Each of the fixtures available in this package is explained below:

#### authenticated_api_function_fixture
This is an authenticated api client with a scope of 'fixture', which means that a new fixture is created for each test method
```python
from idaptive_automation.api_client import api_session, mongo_dal
from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
```

#### authenticated_api_class_fixture
This is an authenticated api client with a scope of 'class', which means the same client is used for all tests in the same class
```python
from idaptive_automation.api_client import api_class_session as api_session, mongo_class_dal as mongo_dal
from idaptive_automation.fixtures import authenticated_api_class_fixture as session_fixture
```

#### authenticated_api_session_fixture
You guessed it - this is an authenticated api client with a scope of 'session', which means the same client is passed to
 all tests in the session
 ```python
from idaptive_automation.api_client import api_session_fixture as api_session, mongo_session_client as mongo_dal
from idaptive_automation.fixtures import authenticated_api_session_fixture as session_fixture
```

### Passing credentials to the client
All tests in our framework rely on a `--tenant` parameter being passed in as an argument from the command line. 
```python
--tenant="aaa0197"
```
In order to retrieve the user credentials for the tenant, you need to also provide a `mongo_dal` 
object which supports the usage in the
[connected_fixture method](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/fixtures/fixture_base.py). 
The typical use case is to use the [mongo_dal](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/mongo_dal)
class in this project as shown here:
```python
from idaptive_automation.api_client import api_session, mongo_dal
```
  
or you can create your own and import it using the `as mongo-dal` option:
```python
from idaptive_automation.api_client import api_session
from my_solution import mobile_dal as mongo_dal 
```


For more usage examples, refer to the [main idaptive-automation repo README.md file](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/readme.md)