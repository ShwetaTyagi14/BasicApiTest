def pytest_addoption(parser):
    parser.addoption('--tenant', action="append", default=None)
    parser.addoption('--user_type', action='append', default=['automation'])
