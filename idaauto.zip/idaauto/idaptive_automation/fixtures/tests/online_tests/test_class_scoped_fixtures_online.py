from idaptive_automation.fixtures import authenticated_api_function_fixture as fixture, parse_args
from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
from idaptive_automation.fixtures  import authenticated_api_function_fixture as session_fixture


class TestApiClassFixture:
    def test_online_api_class_fixture(self, request, fixture):
        args = parse_args(request)
        assert fixture['tenant'] == args['tenant']
        assert args['test_name'] == 'test_online_api_class_fixture'
        assert isinstance(fixture['session'], ApiSession)
