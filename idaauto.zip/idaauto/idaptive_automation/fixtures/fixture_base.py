from idaptive_automation.mongo_dal import EnvironmentCredentials
import os, json


def parse_args(request):
    return {
        'tenant': get_arg(request, 'tenant'),
        'user_type': get_arg(request, 'user_type'),
        'test_name': request.node.name,
        'wait_secs_for_email': get_arg(request, 'wait_secs_for_email') or os.environ.get('wait_secs_for_email') or 600
    }


def get_arg(request, arg_name):
    return request.config.getoption(arg_name)[0] if request.config.getoption(arg_name) else None


def offline_fixture(args,
                    username,
                    password,
                    api_session):
    return {
        **args,
        'session': api_session(args['url'], args['tenant'], username, password, test_name=args['test_name'])
    }


def connected_fixture(args,
                      api_session,
                      mongo_client):
    with mongo_client(EnvironmentCredentials(), 'apps').connect() as client:
        tenant = client.get_tenant_credentials(args['tenant'])

        environment = tenant['environment']
        release_config = client.find_one('release_config', {'environment': environment})
        tenant.update({'release_config': release_config})

        hostname = os.environ.get('COMPUTERNAME')
        if hostname:
            host_config = client.find_one('vms', {'hostname': hostname})
            tenant.update({'host_config': host_config})

        user = [user for user in tenant['users'] if user['type'] == args['user_type']]

        if len(user) == 0:
            raise Exception(f'No user of type: {args["user_type"]} found for tenant: {args["tenant"]}')
        user = user[0]
        tenant.update({'username': user['username']})
        tenant.update({'password': user['password']})
        tenant.update({'test_name': args['test_name']})
        tenant.update({'wait_secs_for_email': args['wait_secs_for_email']})

        session = offline_fixture(tenant,
                                  user['username'],
                                  user['password'],
                                  api_session)
    return session


def b2b_partner_connected_fixture(args,
                                  api_session,
                                  mongo_client):
    with mongo_client(EnvironmentCredentials(), 'apps').connect() as client:
        idp = client.get_tenant_credentials(args['tenant'])
        try:
            tenant = client.get_tenant_credentials(idp['b2b']['idpFor'])
        except KeyError:
            assert False, f'This test requires a B2B partner. Tenant {args["tenant"]} does not have a partner.'
        if tenant is None:
            assert False, f'No credentials found for B2B partner tenant {idp}.'

        environment = tenant['environment']
        release_config = client.find_one('release_config', {'environment': environment})
        tenant.update({'release_config': release_config})

        hostname = os.environ.get('COMPUTERNAME')
        if hostname:
            host_config = client.find_one('vms', {'hostname': hostname})
            tenant.update({'host_config': host_config})

        user = [user for user in tenant['users'] if user['type'] == args['user_type']]

        if len(user) == 0:
            raise Exception(f'No user of type: {args["user_type"]} found for tenant: {args["tenant"]}')
        user = user[0]
        tenant.update({'username': user['username']})
        tenant.update({'password': user['password']})
        tenant.update({'test_name': args['test_name']})
        tenant.update({'wait_secs_for_email': args['wait_secs_for_email']})

        session = offline_fixture(tenant,
                                  user['username'],
                                  user['password'],
                                  api_session)
    return session


def cleanup_fixture(session):
    session['session'].logout()


try:
    file_path = os.getenv('USERCREDS')
    if file_path is not None and os.path.isfile(file_path):
        with open(file_path) as file:
            for p in [(k, v) for item in [json.loads(line) for line in file.readlines()] for k, v in item.items()]:
                os.environ[p[0]] = json.dumps(p[1])
except:
    pass
