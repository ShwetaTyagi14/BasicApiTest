class CleanupAuthentication:
    def __init__(self):
        self.tenant_id = None
        self.session_id = None

    def with_tenant_id(self, tenant_id):
        self.tenant_id = tenant_id
        return self

    def with_session_id(self, session_id):
        self.session_id = session_id
        return self

    def to_payload(self):
        return {
            'TenantId': self.tenant_id,
            'SessionId': self.session_id
        }
