from .cleanup_authentication import CleanupAuthentication


class AdvanceAuthentication(CleanupAuthentication):
    def __init__(self):
        self.action = 'Answer'
        self.persist = True
        self.mechanism_id = None
        self.answer = None
        super().__init__()

    def with_action(self, action):
        self.action = action
        return self

    def without_persistent_login(self):
        self.persist = False
        return self

    def with_mechanism_id(self, mechanism_id):
        self.mechanism_id = mechanism_id
        return self

    def with_answer(self, answer):
        self.answer = answer
        return self

    def to_payload(self):
        return {
            'TenantId': self.tenant_id,
            'Action': 'Answer',
            'PersistentLogin': self.persist,
            'SessionId': self.session_id,
            'MechanismId': self.mechanism_id,
            'Answer': self.answer,
        }

    def base(self):
        return super()


class MultiOperationAdvanceAuthentication(CleanupAuthentication):
    def __init__(self):
        self.action = 'Answer'
        self.persist = True
        self.mechanism_id = None
        self.answer = None
        self.operations = []
        super().__init__()

    def with_operation(self, operation):
        self.operations.append(operation)

    def without_persistent_login(self):
        self.persist = False
        return self

    def with_mechanism_id(self, mechanism_id):
        self.mechanism_id = mechanism_id
        return self

    def to_payload(self):
        return {
            'TenantId': self.tenant_id,
            'PersistentLogin': self.persist,
            'SessionId': self.session_id,
            'MultipleOperations': self.operations
        }

    def base(self):
        return super()
