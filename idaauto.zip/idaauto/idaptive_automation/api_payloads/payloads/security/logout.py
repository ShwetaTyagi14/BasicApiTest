class Logout:
    def __init__(self, authorization):
        self.authorization = authorization

    def to_payload(self):
        return {
            'Authorization': self.authorization
        }
