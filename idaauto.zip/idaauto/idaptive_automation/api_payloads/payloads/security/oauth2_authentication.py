class Oauth2Authentication:
    def __init__(self, grant_type, scope, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret
        self.grant_type = grant_type
        self.scope = scope

    def with_client_id(self, client_id):
        self.client_id = client_id
        return self

    def with_client_secret(self, client_secret):
        self.client_secret = client_secret
        return self

    def with_grant_type(self, grant_type):
        self.grant_type = grant_type
        return self

    def with_scope(self, scope):
        self.scope = scope
        return self

    def to_payload(self):
        return {
            "grant_type": self.grant_type,
            "scope": self.scope,
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }