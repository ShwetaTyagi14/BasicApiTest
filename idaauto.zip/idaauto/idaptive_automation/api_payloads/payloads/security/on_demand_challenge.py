class OnDemandChallenge:
    def __init__(self, username, policy_modifier):
        self.user = username
        self.policy_modifier = policy_modifier

    def to_payload(self):
        return {
            'User': self.user,
            'PolicyModifier': self.policy_modifier,
        }
