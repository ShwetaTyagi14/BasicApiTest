class StartAuthentication:
    def __init__(self, tenant_id, username):
        self.tenant_id = tenant_id
        self.user = username

    def to_payload(self):
        return {
            'TenantId': self.tenant_id,
            'Version': '1.0',
            'User': self.user,
            'ApplicationId': None,
            'MfaRequestor': None,
        }
