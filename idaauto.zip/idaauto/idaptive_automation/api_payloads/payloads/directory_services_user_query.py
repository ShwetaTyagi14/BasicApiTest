class DirectoryServicesUserQuery:
    def __init__(self, search_for, directory_services_ids):
        self.search_for = search_for
        self.directory_services = directory_services_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "directoryServices": self.directory_services,
            "user": f"{{\"_and\":[{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"givenName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"sn\":{{\"_like\":\"{self.search_for}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.search_for}\"}}}}]}},{{\"ObjectType\":\"user\"}}]}}",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
    }
