class SetCustomerConfig:
    def __init__(self):
        self.EnableQRCode = False
        self.IsPasswordPersistanceEnable = False
        self.ForgotUsernameAllowed = False
        self.SendPasswordChangeConfirmation = False
        self.DisableAndroidCBA = False
        self.StoreCorporateAppUserCredsInVault = False
        self.StorePersonalAppUserCredsInVault = False
        self.OtpCodeLength = 8
        self.MfaAttributeMapping = {}
        self.IsOriginValidationEnabled = False
        self.AllowCors = None
        self.Domain = ""

    def with_qrcode(self, enabled):
        self.EnableQRCode = enabled
        return self

    def with_password_persistance(self, enabled):
        self.IsPasswordPersistanceEnable = enabled
        return self

    def with_send_password_confirmation(self, enabled):
        self.SendPasswordChangeConfirmation = enabled
        return self

    def with_android_cba(self, enabled):
        self.DisableAndroidCBA = enabled
        return self

    def with_corporate_app(self, enabled):
        self.StoreCorporateAppUserCredsInVault = enabled
        return self

    def with_personal_app(self, enabled):
        self.StorePersonalAppUserCredsInVault = enabled
        return self

    def with_otp_code_length(self, number):
        self.OtpCodeLength = number
        return self

    def with_mfa_attribute_mapping(self, list):
        self.MfaAttributeMapping = list
        return self

    def with_origin_validation(self, enabled):
        self.IsOriginValidationEnabled = enabled
        return self

    def with_allow_cors(self, enabled):
        self.AllowCors = enabled
        return self

    def with_domain(self, name):
        self.Domain = name
        return self

    def to_payload(self):
        return {
            "EnableQRCode": self.EnableQRCode,
            "IsPasswordPersistanceEnabled": self.IsPasswordPersistanceEnable,
            "ForgotUsernameAllowed": self.ForgotUsernameAllowed,
            "SendPasswordChangeConfirmation": self.SendPasswordChangeConfirmation,
            "DisableAndroidCBA": self.DisableAndroidCBA,
            "StoreCorporateAppUserCredsInVault": self.StoreCorporateAppUserCredsInVault,
            "StorePersonalAppUserCredsInVault": self.StorePersonalAppUserCredsInVault,
            "OtpCodeLength": self.OtpCodeLength,
            "MfaAttributeMapping": self.MfaAttributeMapping,
            "IsOriginValidationEnabled": self.IsOriginValidationEnabled,
            "AllowCors": self.AllowCors,
            "Domain": self.Domain
        }