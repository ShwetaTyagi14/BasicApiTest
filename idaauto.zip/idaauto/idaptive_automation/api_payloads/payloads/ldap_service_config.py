class LdapServiceConfig:
    def __init__(self, name):
        self.name = name
        self.description = None
        self.host = None
        self.port = 636
        self.base_dn = None
        self.login_suffix = None
        self.username = None
        self.password = None
        self.verify_cert = False
        self.uuid = ''
        self.proxies = []

    def with_description(self, description):
        self.description = description
        return self

    def with_host_name(self, host):
        self.host = host
        return self

    def with_port(self, port):
        self.port = port
        return self

    def with_base_dn(self,dn):
        self.base_dn = dn
        return self

    def with_login_suffix(self, suffix):
        self.login_suffix = suffix
        return self

    def with_username(self, username):
        self.username = username
        return self

    def with_password(self, password):
        self.password = password
        return self

    def with_verify_cert(self, verify):
        self.verify_cert = verify
        return self

    def with_proxies(self, proxies):
        self.proxies = proxies
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "serviceInstanceName": self.name,
            "description": self.description,
            "hostName": f"{self.host}:{self.port}",
            "baseDn": self.base_dn,
            "loginSuffix": self.login_suffix,
            "userName": self.username,
            "password": self.password,
            "verifyServerCertificate": self.verify_cert,
            "directoryServiceUuid": self.uuid,
            "proxies": self.proxies
}