class RoleMetadata:
    def __init__(self, role_id, display_name, description):
        """
        Compose role metadata payload
        :param role_id: the id of the role in question
        :param display_name: the new display name of the role to update
        :param description: the description of the role to update
        """
        self.role_id = role_id
        self.display_name = display_name
        self.description = description

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Name": self.role_id,
            "NewName": self.display_name,
            "Description": self.description
        }
