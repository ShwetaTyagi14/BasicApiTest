class CloudUser:
    def __init__(self, name_suffix, username):
        self.name_suffix = name_suffix
        self.login_name = username
        self.email = "test@test.test"
        self.display_name = "test"
        self.password = "testTEST1234"
        self.pwd_never_expire = True
        self.force_pwd_change = False
        self.in_everybody = True
        self.oauth_client = False
        self.send_email_invite = False
        self.send_sms_invite = False
        self.name = f'{username.lower()}@{self.name_suffix}'

    def with_login_name(self, name):
        self.login_name = name
        return self

    def with_email(self, email):
        self.email = email
        return self

    def with_display_name(self, name):
        self.display_name = name
        return self

    def with_password(self, password):
        self.password = password
        return self

    def with_password_never_expire(self, never_expires):
        self.pwd_never_expire = never_expires
        return self

    def with_force_password_change(self, force):
        self.force_pwd_change = force
        return self

    def with_in_everybody_role(self, in_role):
        self.in_everybody = in_role
        return self

    def with_oauth_client(self, is_client):
        self.oauth_client = is_client
        return self

    def with_send_email_invite(self, send):
        self.send_email_invite = send
        return self

    def with_send_sms_invite(self, send):
        self.send_sms_invite = send
        return self

    def with_name(self, name):
        self.name = f'{name.lower()}@{self.name_suffix}'
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "LoginName": self.login_name,
            "Mail": self.email,
            "DisplayName": self.display_name,
            "Password": self.password,
            "confirmPassword": self.password,
            "PasswordNeverExpire": self.pwd_never_expire,
            "ForcePasswordChangeNext": self.force_pwd_change,
            "InEverybodyRole": self.in_everybody,
            "OauthClient": self.oauth_client,
            "SendEmailInvite": self.send_email_invite,
            "SendSmsInvite": self.send_sms_invite,
            "Description": "",
            "OfficeNumber": "",
            "HomeNumber": "",
            "MobileNumber": "",
            "fileName": "",
            "ID": "",
            "state": "None",
            "jsutil-checkbox-2233-inputEl": False,
            "ReportsTo": "Unassigned",
            "Name": self.name,
            "CmaRedirectedUserUuid": None
        }
