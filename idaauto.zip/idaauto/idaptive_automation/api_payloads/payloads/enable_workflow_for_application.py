import json


class WorkflowEnabled:
    def __init__(self, app_id, icon_url):
        self.app_id = app_id
        self.icon_url = icon_url
        self.payload = None

    def with_no_manager_action_approve(self):
        self.payload = {
            "WorkflowEnabled": True,
            "WorkflowSettings": "{\"WorkflowApprover\":[{\"Type\":\"Manager\",\"NoManagerAction\":\"approve\",\"Type-generated-field\":\"/vfslow/lib/ui/../uibuild/compiled/idaptive/production/resources/images/entities/user_icon_sml.png?_ver=1568422892\",\"OptionsSelector\":true}],\"NoManagerAction\":\"approve\"}",
            "IconUri": self.icon_url,
            "_RowKey": self.app_id
        }
        return self

    def with_no_manager_action_deny(self):
        self.payload = {
            "WorkflowEnabled": True,
            "WorkflowSettings": "{\"WorkflowApprover\":[{\"Type\":\"Manager\",\"NoManagerAction\":\"deny\",\"Type-generated-field\":\"/vfslow/lib/ui/../uibuild/compiled/idaptive/production/resources/images/entities/user_icon_sml.png?_ver=1568422892\",\"OptionsSelector\":true}],\"NoManagerAction\":\"deny\"}",
            "IconUri": self.icon_url,
            "_RowKey": self.app_id
        }
        return self

    def with_no_manager_use_role(self, role_name,
                                 role_id, ds_uuid):
        self.payload = {
            "WorkflowEnabled": True,
            "WorkflowSettings": f"{{\"WorkflowApprover\":[{{\"Type\":\"Manager\",\"NoManagerAction\":\"useBackup\",\"BackupApprover\":{{\"Name\":\"{role_name}\",\"_ID\":\"{role_id}\",\"RoleType\":\"PrincipalList\",\"ReadOnly\":false,\"DirectoryServiceUuid\":\"{ds_uuid}\",\"Guid\":\"{role_id}\",\"Type\":\"Role\",\"ObjectType\":\"Role\",\"Type-generated-field\":\"/vfslow/lib/ui/../uibuild/compiled/idaptive/production/resources/images/entities/group_icon_sml.png?_ver=1568422892\",\"Principal\":\"{role_name}\",\"PType\":\"Role\"}},\"Type-generated-field\":\"/vfslow/lib/ui/../uibuild/compiled/idaptive/production/resources/images/entities/user_icon_sml.png?_ver=1568422892\",\"OptionsSelector\":true}}],\"NoManagerAction\":\"useBackup\",\"BackupApprover\":{{\"Name\":\"{role_name}\",\"_ID\":\"{role_id}\",\"RoleType\":\"PrincipalList\",\"ReadOnly\":false,\"DirectoryServiceUuid\":\"{ds_uuid}\",\"Guid\":\"{role_id}\",\"Type\":\"Role\",\"ObjectType\":\"Role\",\"Type-generated-field\":\"/vfslow/lib/ui/../uibuild/compiled/idaptive/production/resources/images/entities/group_icon_sml.png?_ver=1568422892\",\"Principal\":\"{role_name}\",\"PType\":\"Role\"}}}}",
            "IconUri": self.icon_url,
            "_RowKey": self.app_id
        }
        return self

    def with_no_manager_use_user(self, user_info):
        if 'Description' in user_info.keys():
            del user_info['Description']
        if 'Forest' in user_info.keys():
            del user_info['Forest']
        backup_payload = self._format_user_payload(user_info)
        self.payload = {
            "WorkflowEnabled": True,
            "WorkflowSettings": f"{{\"WorkflowApprover\":[{{\"Type\":\"Manager\",\"NoManagerAction\":\"useBackup\",\"BackupApprover\":{{{backup_payload}}},\"Type-generated-field\":\"/vfslow/lib/ui/../uibuild/compiled/idaptive/production/resources/images/entities/user_icon_sml.png?_ver=1568422892\",\"OptionsSelector\":true}}],\"NoManagerAction\":\"useBackup\",\"BackupApprover\":{{{backup_payload}}}}}",
            "IconUri": self.icon_url,
            "_RowKey": self.app_id
        }
        return self

    def with_user_as_approver(self, user_info):
        self.payload = {
            "WorkflowEnabled": True,
            "WorkflowSettings": f"{{{self._format_user_payload(user_info)}}}",
            "IconUri": self.icon_url,
            "_RowKey": self.app_id
        }
        return self

    @staticmethod
    def _format_user_payload(payload):
        if 'Description' in payload.keys():
            del payload['Description']
        if 'Forest' in payload.keys():
            del payload['Forest']
        return json.dumps(payload)

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return self.payload
