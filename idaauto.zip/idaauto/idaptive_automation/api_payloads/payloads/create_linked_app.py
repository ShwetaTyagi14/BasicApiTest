class ChildLinkedSamlApp:
    def __init__(self, parent_app_id):
        self.description = "Linked Application"
        self.displayname = None
        self.deeplinkurl = "https://www.abcdefg.com"
        self.name = "Linked Application"
        self.parentapp = parent_app_id

    def with_description(self, description):
        self.description = description
        return self

    def with_display_name(self, displayname):
        self.displayname = displayname
        return self

    def with_deeplinkurl(self, deeplinkurl):
        self.deeplinkurl = deeplinkurl
        return self

    def with_name(self, name):
        self.name = name
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
          "ChildLinkedApps": [
            {
              "Description": self.description,
              "DisplayName": self.displayname,
              "TemplateName": "Generic Link",
              "AdminTag": None,
              "_STAMP": "",
              "AllowDuplicateLinkedAppInstances": True,
              "_TableName": "application",
              "_PartitionKey": "",
              "_RowKey": "Generic Link",
              "DeepLinkUrl": self.deeplinkurl,
              "NotSelfService": True,
              "Category": "Other",
              "Icon": "/vfslow/lib/application/icons/GenericSaml.svg",
              "Generic": True,
              "Intranet": False,
              "Name": self.name,
              "ParentDisplayName": None,
              "AppType": "Web",
              "ParentAppTemplateName": "",
              "WebAppType": "Link",
              "RegistrationMessage": None,
              "RegistrationLinkMessage": None,
              "AppKey": "Generic Link",
              "Action": "Add"
            }
          ],
          "IconUri": "/vfslow/lib/application/icons/GenericSaml.svg",
          "_RowKey": self.parentapp
        }