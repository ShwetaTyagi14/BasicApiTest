class PartnerCreation:
    def __init__(self, base_url):
        self.base_url = base_url
        self.federation_name = None
        self.sp_metadataurl = None
        self.sp_authentication_responseurl = None
        self.domains = []
        self.idp_metadataurl = None
        self.federation_uuid = None

    def with_federation_name(self, federation_name):
        self.federation_name = federation_name
        return self

    def with_sp_metadataurl(self):
        self.sp_metadataurl = f"{self.base_url}/Federation/federationmetadata?FederationType=SAML%202.0"
        return self

    def with_sp_authentication_responseurl(self):
        self.sp_authentication_responseurl = f"{self.base_url}/My"
        return self

    def with_domain(self, domain_names):
        for domain_name in domain_names:
            self.domains.append(domain_name)
        return self

    def with_idp_metadataurl(self, idp_base_url, app_key, tenant_id):
        self.idp_metadataurl = f"{idp_base_url}/saasManage/DownloadSAMLMetadataForApp?appkey={app_key}&customerid={tenant_id}"
        return self

    def with_federation_uuid(self, uuid):
        self.federation_uuid = uuid
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "FederationName": self.federation_name,
            "FederationType": "SAML 2.0",
            "Domains": self.domains,
            "Name": "",
            "Mappings": "",
            "IDPMetadataUrl": self.idp_metadataurl,
            "IDPSignInUrl": "",
            "IDPLogoutUrl": "",
            "IDPSigningCert_name": "",
            "IDPSigningCertPassword": "",
            "FederationUuid": self.federation_uuid,
            "IDPSigningCertificateThumbprint": "",
            "IsMetaData": "true",
            "MetaDataIsUrl": "true",
            "SPMetadataUrl": self.sp_metadataurl,
            "SPAuthenticationResponseUrl": self.sp_authentication_responseurl,
            "SPSigningCertificate_name": "",
            "SPSigningCertificateCA_name": "",
            "MapUsers": "Disabled",
            "IDPMetadataFileContents": "(binary)",
            "IDPSigningCert": "(binary)",
            "SPSigningCertificate": "(binary)",
            "SPSigningCertificateCA": "(binary)"
        }