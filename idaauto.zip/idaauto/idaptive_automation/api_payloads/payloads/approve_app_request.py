class ApprovePermAppAccessRequest:
    def __init__(self, job_id):
        self.job_id = job_id

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "jobid": self.job_id,
            "event": "approve",
            "sync": True,
            "args": {
                "AccessType": "App",
                "AssignmentType": 'perm'
            }
        }


class ApproveWindowedAppAccessRequest:
    def __init__(self, job_id):
        self.job_id = job_id
        self.start_time = None
        self.end_time = None

    def with_start_time(self, utc_time):
        self.start_time = utc_time
        return self

    def with_end_time(self, utc_time):
        self.end_time = utc_time
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "jobid": self.job_id,
            "event": "approve",
            "sync": True,
            "args": {
                "AccessType": "App",
                "AssignmentType": "window",
                "StartTime": f'{self.start_time.replace(microsecond=0).isoformat()}.000Z',
                "EndTime": f'{self.end_time.replace(microsecond=0).isoformat()}.000Z'
            }
        }
