class RemoveUsersFromRole:
    def __init__(self, role_id, user_ids):
        self.role_id = role_id
        self.user_ids = user_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Users": {
                "Delete": self.user_ids
            },
            "Name": self.role_id
        }
