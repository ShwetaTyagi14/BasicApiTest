class ConfigureGatewayApplication:

    default_script = f"""response.AddFormField(\"Username\", encode(LoginUsername));
        response.AddFormField(\"Password\", encode(LoginPassword));
        """

    def __init__(self, app_id):
        self.app_id = app_id
        self.is_gatewayed = False
        self.preferred_proxies = []
        self.configured_state = ""
        self.gateway_options = {
            "NoCanon": True,
            "LockSessionIP": False,
            "LockSessionTime": False,
            "RewriteUrl": True,
            "StandardHeader": False,
            "ForwardForUserHeader": "ipAddress"
        }

    def with_is_gatewayed(self, is_gatewayed):
        self.is_gatewayed = is_gatewayed
        return self

    def with_preferred_proxies(self, proxy_ids):
        self.preferred_proxies.append(proxy_ids)
        return self

    def with_gateway_options(self, options):
        self.gateway_options = options
        return self

    def with_configured_state(self, state):
        self.configured_state = state
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "_RowKey": self.app_id,
            "IsGatewayed": self.is_gatewayed,
            "GatewayPreferredProxies": self.preferred_proxies,
            "ConfigureGatewayState": self.configured_state,
            "GatewayOptions": self.gateway_options
        }
