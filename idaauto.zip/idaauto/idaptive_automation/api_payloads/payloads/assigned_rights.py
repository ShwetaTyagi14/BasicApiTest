class AssignedRights:
    def __init__(self, role_id, sort_by=''):
        self.role_id = role_id
        self.sort_by = sort_by

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "role": f"{self.role_id}",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": self.sort_by,
                "direction": "False",
                "Caching": -1
            }
        }
