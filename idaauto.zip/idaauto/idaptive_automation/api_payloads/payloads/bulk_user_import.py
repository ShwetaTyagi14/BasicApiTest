class BulkUserImport:
    def __init__(self,
                 return_id,
                 admin_email,
                 send_invite):
        self.return_id = return_id
        self.admin_email = admin_email
        self.send_invite = send_invite

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "ReturnID": self.return_id,
            "AdminEmail": self.admin_email,
            "SendEmailInvite": self.send_invite
        }
