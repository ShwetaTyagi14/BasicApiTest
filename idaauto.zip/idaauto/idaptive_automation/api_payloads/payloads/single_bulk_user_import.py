class SingleBulkUserImport:
    def __init__(self,
                 login,
                 email,
                 display_name,
                 description=None,
                 office_num=None,
                 mobile_num=None,
                 home_num=None,
                 roles=None,
                 password=None,
                 require_pass_change=None,
                 expiration_date = None):
        self.login = login
        self.email = email
        self.display_name = display_name
        self.description = description
        self.office_num = office_num
        self.mobile_num = mobile_num
        self.home_num = home_num
        self.roles = roles
        self.password = password
        self.require_password_change = require_pass_change
        self.set_expiration_date = expiration_date

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        display = f'"{self.display_name}"' if ',' in self.display_name else self.display_name
        return f'{self.login},{self.email},{display},{self.description},{self.office_num},{self.mobile_num},{self.home_num},{self.roles or ""},{self.password},{self.require_password_change},{self.set_expiration_date}'
