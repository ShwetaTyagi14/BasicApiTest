import json
from simplejson.errors import JSONDecodeError
from collections import namedtuple


class ApiResult:
    def __init__(self, response):
        """
        :param response: The full response from an API call
        """
        try:
            self.raw_response = response
            self.response = response.json()
        except json.JSONDecodeError:
            self.response = response.text
        except JSONDecodeError:
            self.response = response.text

    def deserialized_response(self):
        """
        Attempts to deserialize the response
        :return: the result of the deserialization
        """
        try:
            obj = json.loads(json.dumps(self.response), object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
            return obj
        except:
            return self.response

    def ok(self):
        """
        :return: the 'ok' status of the original response
        """
        return self.raw_response.ok

    def cookies(self):
        """
        :return: the cookies from the original response
        """
        return self.raw_response.cookies

    def success(self):
        """
        :return: Did the response return a success code
        """
        try:
            return self.response['success'] is True
        except:
            return self.ok()

    def message(self):
        """
        :return: Returns the Message property of the response if it exists
        """
        if isinstance(self.response, str):
            return self.response
        if 'Message' not in self.response.keys():
            return self.response
        return self.response['Message']

    def exception(self):
        """
        :return: Returns the Exception property of the response if it exists
        """
        if isinstance(self.response, str):
            return self.response
        if 'Exception' not in self.response.keys():
            return self.response
        return self.response['Exception']

    def result(self):
        """
        :return: The 'Result' property of the response
        """
        return self.response['Result']

    def results(self):
        """
        :return: the ['Result']['Results'] property of the response
        """
        return self.response['Result']['Results']

    def text(self):
        """
        :return: The text of the response
        """
        return self.response.text
