from datetime import timezone


class RequestAppAccess:
    def __init__(self, app_id):
        """
        Used to request access to an app
        :param app_id: the id of the app
        """
        self.reason = None
        self.access_type = 'App'
        self.request_options = None
        self.app_id = app_id
        self.portal_type = 'user'

    def with_reason(self, reason):
        self.reason = reason
        return self

    def with_access_type(self, access_type):
        self.access_type = access_type
        return self

    def with_permanent_access(self):
        self.request_options = {
                "AccessType": self.access_type,
                "AssignmentType": "perm"
            }
        return self

    def with_windowed_access(self, utc_start_time, utc_end_time):
        local_start_time = utc_start_time.replace(tzinfo=timezone.utc).astimezone(tz=None)
        local_end_time = utc_end_time.replace(tzinfo=timezone.utc).astimezone(tz=None)
        self.request_options = {
                "AccessType": "App",
                "AssignmentType": "window",
                "StartTime": f'{utc_start_time.replace(microsecond=0).isoformat()}.000Z',
                "jsutil-number-1154-inputEl": local_start_time.hour,
                "jsutil-number-1156-inputEl": local_start_time.minute,
                "jsutil-datacombo-1157-inputEl": "PM" if local_start_time.hour >= 12 else "AM",
                "StartTime_count": 7,
                "StartTime_unit": "day -1",
                "EndTime": f'{utc_end_time.replace(microsecond=0).isoformat()}.000Z',
                "jsutil-number-1169-inputEl": local_end_time.hour,
                "jsutil-number-1171-inputEl": local_end_time.minute,
                "jsutil-datacombo-1172-inputEl": "PM" if local_end_time.hour >= 12 else "AM",
                "EndTime_count": 7,
                "EndTime_unit": "day -1"
            }
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "script": "/lib/jobs/app_request.js",
            "args": {
                "Reason": self.reason,
                "AccessType": self.access_type,
                "RequestedOptions": self.request_options,
                "AppKey": self.app_id,
                "PortalType": self.portal_type
            }
        }
