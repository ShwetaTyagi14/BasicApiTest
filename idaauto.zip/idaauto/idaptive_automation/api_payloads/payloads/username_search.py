class UsernameSearch:
    def __init__(self, username):
        self.username = username

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "user": f"{{\"_and\":[{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.username}\"}}}},{{\"givenName\":{{\"_like\":\"{self.username}\"}}}},{{\"sn\":{{\"_like\":\"{self.username}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.username}\"}}}}]}},{{\"ObjectType\":\"user\"}}]}}",
            "directoryServices": [
                "55897ec6-91b4-4afc-a099-cbd02ba334e1"
            ],
            "group": f"{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.username}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.username}\"}}}}]}}",
            "roles": f"{{\"_or\":[{{\"_ID\":{{\"_like\":\"{self.username}\"}}}},{{\"Name\":{{\"_like\":\"{self.username}\"}}}}]}}",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
    }
