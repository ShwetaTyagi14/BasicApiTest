class NewTenant:
    def __init__(self, brand,
                 podname,
                 username,
                 password,
                 customer_name):
        self.brand = brand
        self.podname = podname
        self.username = username
        self.password = password
        self.customer = customer_name

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "brand": self.brand,
            "podName": self.podname,
            "adminUser": self.username,
            "adminPass": self.password,
            "customerName": self.customer
        }
