class RedRock:
    def __init__(self, script, sort_by='', page_size=100):
        self.script = script
        self.sort_by = sort_by
        self.page_size = page_size

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Script": f"{self.script}",
            **RedRockArgs(self.sort_by, page_size=self.page_size).to_payload()
        }


class RedRockArgs:
    def __init__(self, sort_by='', page_size=100):
        self.sort_by = sort_by
        self.page_size = page_size

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Args": {
                "PageNumber": 1,
                "PageSize": self.page_size,
                "Limit": 100000,
                "SortBy": self.sort_by,
                "Ascending": True,
                "Caching": -1
            }
        }
