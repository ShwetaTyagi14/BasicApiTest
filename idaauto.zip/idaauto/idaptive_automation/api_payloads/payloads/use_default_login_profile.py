class DefaultLoginProfilePolicy:
    def __init__(self, default_login_profile_id):
        self.login_profile_id = default_login_profile_id

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "AuthenticationEnabled": True,
            "/Core/Authentication/AuthenticationRulesDefaultProfileId": self.login_profile_id
        }
