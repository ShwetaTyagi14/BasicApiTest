class AddUsersToRole:
    def __init__(self, role_id, user_ids):
        """
        Used to add users to a role
        :param role_id: the id of the role
        :param user_ids: the ids of the users
        """
        self.role_id = role_id
        self.user_ids = user_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Users": {
                "Add": self.user_ids
            },
            "Name": self.role_id
        }
