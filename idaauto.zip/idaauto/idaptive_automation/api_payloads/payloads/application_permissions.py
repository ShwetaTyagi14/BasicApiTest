class ApplicationPermissions:
    def __init__(self):
        self.grants = []
        self.app_id = None
        self.row_key = None
        self.pvid = None

    def with_grant(self, grant):
        self.grants.append(grant)
        return self

    def with_app_id(self, app_id):
        self.app_id = self.row_key = self.pvid = app_id
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            'Grants': self.grants,
            'ID': self.app_id,
            'RowKey': self.app_id,
            'PVID': self.pvid
        }
