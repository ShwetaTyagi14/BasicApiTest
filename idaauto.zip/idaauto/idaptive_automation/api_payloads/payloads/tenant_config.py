class TenantConfig:
    def __init__(self):
        self.url = None
        self.tenant = None
        self.environment = None
        self.test_purpose = None
        self.connectors = []
        self.users = []
        self.host = None
        self.tenant_owner = None
        self.region = None
        self.fqdn = None
        self.pod_name = None

    def with_url(self, url):
        self.url = url
        return self

    def with_tenant(self, tenant):
        self.tenant = tenant
        return self

    def with_environment(self, environment):
        self.environment = environment
        return self

    def with_test_purpose(self, purpose):
        self.test_purpose = purpose
        return self

    def with_users(self, users):
        self.users = users
        return self

    def with_connectors(self, connectors):
        self.connectors = connectors
        return connectors

    def with_host(self, host):
        self.host = host
        return self

    def with_tenant_owner(self, owner):
        self.tenant_owner = owner
        return self

    def with_region(self, region):
        self.region = region
        return self

    def with_fqdn(self, fqdn):
        self.fqdn = fqdn
        return self

    def with_pod_name(self, name):
        self.pod_name = name
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "url": self.url,
            "tenant": self.tenant,
            "environment": self.environment,
            "test_purpose": self.test_purpose,
            "connectors_registered": self.connectors,
            "in_use": False,
            "test_id": None,
            "users": self.users,
            "host": self.host,
            "tenant_owner": self.tenant_owner,
            "about": {
                "PodRegion": self.region,
                "PodFqdn": self.fqdn,
                "PodName": self.pod_name
    }
}