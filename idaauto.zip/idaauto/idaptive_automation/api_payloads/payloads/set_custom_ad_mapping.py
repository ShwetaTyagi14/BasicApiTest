import json


class SetCustomAdMapping:
    def __init__(self):
        self.cloud_attribute = "mobile"
        self.ad_attribute = "description"
        self.user_editable = "true"
        self.other_user_editable = "true"

    def with_cloud_attribute(self, cloud_attribute):
        self.cloud_attribute = cloud_attribute
        return self

    def with_ad_attribute(self, ad_attribute):
        self.ad_attribute = ad_attribute
        return self

    def with_user_editable(self, value):
        self.user_editable = value
        return self

    def with_other_user_editable(self, value):
        self.other_user_editable = value
        return self

    def to_payload(self):
        payload = {
            f"{self.cloud_attribute}": {
                "attributeName": f"{self.ad_attribute}",
                "editableByUser": f"{self.user_editable}",
                "editableByOther": f"{self.other_user_editable}"
            }
        }
        payload = json.dumps(payload)
        payload = payload.replace(" ", "")
        return payload
