class NewAlias:
    def __init__(self, alias, tenant_id, is_cds_alias=True):
        self.alias = alias
        self.tenant = tenant_id
        self.is_cds_alias = is_cds_alias

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "alias": self.alias,
            "jsutil-checkbox-1405-inputEl": True,
            "domain": self.alias,
            "cdsAlias": self.is_cds_alias
        }