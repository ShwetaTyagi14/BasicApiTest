class MyJobs:
    def __init__(self, job_type):
        self.job_type = job_type

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "type": self.job_type,
            "Args": {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "Description",
                "Ascending": True,
                "Caching": -1
            }
        }