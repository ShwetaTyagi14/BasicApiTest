class InviteUser:
    def __init__(self, username, uuid):
        self.username = username
        self.uuid = uuid
        self.role = "Invited Users"

    def with_role(self, role):
        self.role = role

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Entities": [
                {
                    "Name": self.username,
                    "Guid": self.uuid,
                    "Type": "User",
                }
            ],
            "EmailInvite": True,
            "Role": self.role
        }
