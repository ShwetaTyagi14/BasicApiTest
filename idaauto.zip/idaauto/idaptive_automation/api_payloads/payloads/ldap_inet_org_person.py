class InetOrgPerson(dict):
    def with_given_name(self, name):
        self['givenName'] = name
        return self

    def with_surname(self, name):
        self['sn'] = name
        return self

    def with_common_name(self, name):
        self['cn'] = name
        return self

    def with_password(self, password):
        self['userPassword'] = password
        return self

    def with_phone_number(self, password):
        self['telephonenumber'] = password
        return self

    def with_fax_number(self, password):
        self['facsimiletelephonenumber'] = password
        return self

    def with_mobile_number(self, password):
        self['mobile'] = password
        return self

    def with_email(self, password):
        self['mail'] = password
        return self

    def with_display_name(self, password):
        self['displayname'] = password
        return self

    def with_uid(self, uid):
        self['uid'] = uid
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return dict([(k, v) for k, v in self.items()])
