class OIDCApp:
    def __init__(self, name, app_id):
        self.service_name = ""
        self.localization_enabled = False
        self.name = name
        self.description = "This template enables you to provide single sign-on to a web application that uses OpenID Connect for authentication."
        self.admin_tag = "Other"
        self.show_in_up = True
        self.oauth_profile = None
        self.row_key = app_id
        self.thumbprint = None

    def with_service_name(self, name):
        self.service_name = name
        return self

    def with_localization_enabled(self, enabled):
        self.localization_enabled = enabled
        return self

    def with_name(self, name):
        self.name = name
        return self

    def with_description(self, description):
        self.description = description
        return self

    def with_admin_tag(self, tag):
        self.admin_tag = tag
        return self

    def with_show_in_up(self, show):
        self.show_in_up = show
        return self

    def with_oauth_profile(self, profile):
        self.oauth_profile = profile
        return self

    def with_thumbprint(self, thumbprint):
        self.thumbprint = thumbprint
        return self

    def to_payload(self):
        return {
            "ServiceName": self.service_name,
            "LocalizationEnabled": self.localization_enabled,
            "Name": self.name,
            "Description": self.description,
            "AdminTag": self.admin_tag,
            "Icon": "/vfslow/lib/application/icons/genericopenidconnect",
            "ShowInUP": self.show_in_up,
            "Handler": "cloudlib;Centrify.Saas.OpenID.OpenIDConnectAppHandler",
            "IconUri": "/vfslow/lib/application/icons/genericopenidconnect",
            "OAuthProfile": self.oauth_profile,
            "Thumbprint": self.thumbprint,
            "_RowKey": self.row_key
        }


class OAuthProfile:
    def __init__(self):
        self.client_secret = ""
        self.url = ""
        self.redirects = []
        self.allow_refresh = False
        self.token_lifetime_string = "05:00:00"
        self.refresh_lifetime_string = "365.00:00:00"
        self.id = None
        self.issuer = ""

    def with_client_secret(self, secret):
        self.client_secret = secret
        return self

    def with_url(self, url):
        self.url = url
        return self

    def with_redirect(self, redirect):
        self.redirects.append(redirect)
        return self

    def with_redirects(self, redirects):
        self.redirects = redirects
        return self

    def with_allow_refresh(self, allow):
        self.allow_refresh = allow
        return self

    def with_token_lifetime_string(self, string):
        self.token_lifetime_string = string
        return self

    def with_id(self, ID):
        self.id = ID
        return self

    def with_issuer(self, issuer):
        self.issuer = issuer
        return self

    def to_payload(self):
        return {
            "ClientSecret": self.client_secret,
            "Url": self.url,
            "Redirects": self.redirects,
            "SamlScript": "undefined",
            "Key": "6A901970E8386288F7FBD955C8C628E78A74D29B",
            "AllowRefresh": self.allow_refresh,
            "TokenLifetimeString": self.token_lifetime_string,
            "RefreshLifetimeString": self.refresh_lifetime_string,
            "Confirm": False,
            "AllowScopeSelect": False,
            "Audience": self.id,
            "Issuer": self.issuer,
            "IssuerTemplate": self.issuer + "/{0}/",
            "TokenType": "JwtRS256",
            "UseSpecCompliantIssuerUrl": True,
            "AllowPublic": False,
            "ClientIDType": 3,
            "ClientID": self.id,
            "MustBeOauthClient": False,
            "ID": self.id,
            "AllowedAuth": "AuthorizationCode, Implicit",
            "TargetIsUs": False
        }