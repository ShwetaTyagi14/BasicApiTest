class AuthenticationProfile:
    def __init__(self, name):
        self.name = name
        self.challenges = []
        self.duration = 30
        self.additional_data = {}

    def with_challenges(self, challenges):
        self.challenges.extend(challenges)
        return self

    def with_duration_in_minutes(self, minutes):
        self.duration = minutes
        return self

    def with_additional_data(self, key, value):
        self.additional_data[key] = value
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "settings": {
                "Name": self.name,
                "Challenges": self.challenges,
                "DurationInMinutes": self.duration,
                "AdditionalData": self.additional_data
            }
        }