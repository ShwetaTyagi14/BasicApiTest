class AddChildRolesToRole:
    def __init__(self, parent_role_id, child_role_ids):
        """
        Used to add users to a role
        :param parent_role_id: the id of the role
        :param child_role_ids: the ids of the child roles
        """
        self.parent_role_id = parent_role_id
        self.child_role_ids = child_role_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Roles": {
                "Add": self.child_role_ids
            },
            "Name": self.parent_role_id
        }
