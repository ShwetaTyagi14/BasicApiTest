class ModifyAppShortcuts:
    def __init__(self, app_key):
        self.app_key = app_key
        self.remove_app_keys = []

    def with_remove_app_key(self, key):
        self.remove_app_keys.append(key)

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            'addAppkeys': [self.app_key],
            'removeAppkeys': self.remove_app_keys
        }
