class DenyAppAccessRequest:
    def __init__(self, job_id):
        self.job_id = job_id
        self.reason = None

    def with_reason(self, reason):
        self.reason = reason
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "jobid": self.job_id,
            "event": "reject",
            "sync": True,
            "args": {
                "Reason": self.reason
            }
        }
