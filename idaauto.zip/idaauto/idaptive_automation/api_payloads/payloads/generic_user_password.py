class GenericUserPasswordApp:

    default_script = f"""response.AddFormField(\"Username\", encode(LoginUsername));
        response.AddFormField(\"Password\", encode(LoginPassword));
        """

    def __init__(self, app_id):
        self.url = None
        self.mobile_url = None
        self.name = None
        self.description = None
        self.username = None
        self.password = None
        self.script = None
        self.app_id = app_id
        self.username_field_name = None
        self.username_arg = ''
        self.password_field_name = None
        self.username_strategy = None
        self.ad_attribute = None
        self.sws_enabled = False

    def with_url(self, url):
        self.url = url
        return self

    def with_mobile_url(self, url):
        self.mobile_url = url
        return self

    def with_username_field_name(self, field_name):
        self.username_field_name = field_name
        return self

    def with_password_field_name(self, field_name):
        self.password_field_name = field_name
        return self

    def with_name(self, name):
        self.name = name
        return self

    def with_description(self, description):
        self.description = description
        return self

    def with_username(self, username):
        self.username = username
        return self

    def with_password(self, password):
        self.password = password
        return self

    def with_script(self, script):
        self.script = script
        return self

    def with_fixed_username(self, username, password):
        self.username_strategy = 'Fixed'
        self.with_username(username)
        self.with_password(password)
        return self

    def with_prompt_for_username(self):
        self.username_strategy = 'SetByUser'
        self.with_username(None)
        self.with_password(None)
        return self

    def with_directory_service_field_account_mapping(self, ds_field):
        self.username_strategy = 'ADAttribute'
        self.ad_attribute = ds_field
        self.username_arg = ds_field
        self.with_username(None)
        self.with_password(None)
        return self

    def with_sws_enabled(self):
        self.sws_enabled = True
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Url": self.url or "",
            "MobileUrl": self.mobile_url or "",
            "UserPassScript": "@GenericUserPass",
            "LocalizationEnabled": False,
            "Name": self.name,
            "Description": self.description or "",
            "AdminTag": "Other",
            "Icon": "/vfslow/lib/application/icons/genericuser-password",
            "ShowRegistration": False,
            "Handler": "cloudlib;Centrify.Saas.apphandlers.UserPass",
            "IconUri": "/vfslow/lib/application/icons/genericuser-password",
            "UserNameStrategy": self.username_strategy,
            "ADAttribute": self.ad_attribute or "userprincipalname",
            "Username": self.username or '',
            "Password": self.password or '',
            "UserNameArg": self.username or self.username_arg,
            "Script": self.script or self.default_script,
            "_RowKey": self.app_id,
            "IsSwsEnabled": self.sws_enabled
        }
