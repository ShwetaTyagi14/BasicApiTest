class ChangeUser:
    def __init__(self):
        self.login_name = None,
        self.mail = None
        self.display_name = None
        self.enable_state = False
        self.pwd_never_expire = False
        self.force_pwd_change = False
        self.oauth_client = False
        self.send_email_invite = False
        self.description = ""
        self.office_number = ""
        self.home_number = ""
        self.mobile_number = ""
        self.filename = ""
        self.id = None
        self.state = "None"
        self.reports_to = None
        self.name = None,
        self.pwd = None

    def with_login_name(self, name):
        self.name = name
        return self

    def with_email(self, email):
        self.mail = email
        return self

    def with_display_name(self, name):
        self.display_name = name
        return self

    def with_enable_state(self, enable):
        self.enable_state = enable
        return self

    def with_pwd_never_change(self, never_change):
        self.pwd_never_expire = never_change
        return self

    def with_force_pwd_change(self, force):
        self.force_pwd_change = force
        return self

    def with_is_oauth_client(self, is_oauth):
        self.oauth_client = is_oauth
        return self

    def with_send_email_invite(self, send):
        self.send_email_invite = send
        return self

    def with_description(self, description):
        self.description = description
        return self

    def with_office_number(self, number):
        self.office_number = number
        return self

    def with_home_number(self, number):
        self.home_number = number
        return self

    def with_filename(self, filename):
        self.filename = filename
        return self

    def with_id(self, _id):
        self.id = _id
        return self

    def with_state(self, state):
        self.state = state
        return self

    def with_reports_to(self, reports_to):
        self.reports_to = reports_to
        return self

    def with_name(self, name):
        self.name = name
        self.login_name = name.split('@')[0]
        return self

    def with_password(self, pwd):
        self.pwd = pwd
        return self

    def from_mongodb_cloud_user(self, cloud_user):
        self.login_name = cloud_user['LoginName']
        self.mail = cloud_user['Mail']
        self.display_name = cloud_user['DisplayName']
        self.pwd_never_expire = cloud_user['PasswordNeverExpire']
        self.force_pwd_change = cloud_user['ForcePasswordChangeNext']
        self.oauth_client = cloud_user['OauthClient']
        self.send_email_invite = cloud_user['SendEmailInvite']
        self.description = cloud_user['Description'] or self.description
        self.office_number = cloud_user['OfficeNumber'] or self.office_number
        self.home_number = cloud_user['HomeNumber'] or self.home_number
        self.mobile_number = cloud_user['MobileNumber'] or self.mobile_number
        self.filename = cloud_user['fileName'] or self.filename
        self.id = cloud_user['Uuid']
        self.state = cloud_user['state'] or self.state
        self.reports_to = cloud_user['ReportsTo']
        self.name = cloud_user['Name']
        self.pwd = 'undefined'
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "LoginName": self.login_name,
            "Mail": self.mail,
            "DisplayName": self.display_name,
            "enableState": self.enable_state,
            "PasswordNeverExpire": self.pwd_never_expire,
            "ForcePasswordChangeNext": self.force_pwd_change,
            "InEverybodyRole": True,
            "OauthClient": self.oauth_client,
            "SendEmailInvite": self.send_email_invite,
            "Description": self.description,
            "OfficeNumber": self.office_number,
            "HomeNumber": self.home_number,
            "MobileNumber": self.mobile_number,
            "fileName": self.filename,
            "ID": self.id,
            "state": self.state,
            "jsutil-checkbox-1454-inputEl": False,
            "ReportsTo": self.reports_to,
            "Name": self.name,
            "Password": self.pwd
        }