class ChangeUserAttributes:
    def __init__(self):
        self.login_name = None
        self.mail = None
        self.display_name = None
        self.cloud_state = False
        self.oauth_client = False
        self.description = ""
        self.office_number = ""
        self.home_number = ""
        self.mobile_number = ""
        self.start_date = None
        self.start_date_hour = ""
        self.start_date_minute = ""
        self.jsutil_datacombo_1291_inputEl = ""
        self.start_date_count = 7
        self.start_date_unit = "day -1"
        self.end_date = None
        self.end_date_hour = ""
        self.end_date_minute = ""
        self.jsutil_datacombo_1305_inputEl = ""
        self.end_date_count = 7
        self.end_date_unit = "day -1"
        self.filename = ""
        self.id = None
        self.state = "None"
        self.jsutil_checkbox_1323_inputEl = False
        self.reports_to = "Unassigned"
        self.name = None
        self.org_path = ""
        self.cma_redirect = None

    def with_login_name(self, name):
        self.login_name = name
        return self

    def with_email(self, email):
        self.mail = email
        return self

    def with_display_name(self, name):
        self.display_name = name
        return self

    def with_is_oauth_client(self, is_oauth):
        self.oauth_client = is_oauth
        return self

    def with_description(self, description):
        self.description = description
        return self

    def with_office_number(self, number):
        self.office_number = number
        return self

    def with_home_number(self, number):
        self.home_number = number
        return self

    def with_mobile_number(self, number):
        self.mobile_number = number
        return self

    def with_filename(self, filename):
        self.filename = filename
        return self

    def with_id(self, _id):
        self.id = _id
        return self

    def with_state(self, state):
        self.state = state
        return self

    def with_reports_to(self, reports_to):
        self.reports_to = reports_to
        return self

    def with_name(self, name):
        self.name = name
        self.login_name = name.split('@')[0]
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
           "LoginName": self.login_name,
           "mail": self.mail,
           "DisplayName": self.display_name,
           "CloudState": self.cloud_state,
           "OauthClient": self.oauth_client,
           "Description": self.description,
           "OfficeNumber": self.office_number,
           "HomeNumber": self.home_number,
           "MobileNumber": self.mobile_number,
           "StartDate": self.start_date,
           "StartDate_hour": self.start_date_hour,
           "StartDate_minute": self.start_date_minute,
           "jsutil-datacombo-1291-inputEl": self.jsutil_datacombo_1291_inputEl,
           "StartDate_count": self.start_date_count,
           "StartDate_unit": self.start_date_unit,
           "EndDate": self.end_date,
           "EndDate_hour": self.end_date_hour,
           "EndDate_minute": self.end_date_minute,
           "jsutil-datacombo-1305-inputEl": self.jsutil_datacombo_1305_inputEl,
           "EndDate_count": self.end_date_count,
           "EndDate_unit": self.end_date_unit,
           "fileName": self.filename,
           "ID": self.id,
           "state": self.state,
           "jsutil-checkbox-1323-inputEl": self.jsutil_checkbox_1323_inputEl,
           "ReportsTo": self.reports_to,
           "OrgPath": self.org_path,
           "CmaRedirectedUserUuid": self.cma_redirect
        }
