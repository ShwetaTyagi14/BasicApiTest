class GenericBookmark:
    def __init__(self, app_id):
        self.app_id = app_id
        self.url = ""
        self.name = ""
        self.description = ""

    def with_url(self, url):
        self.url = url
        return self

    def with_name(self, name):
        self.name = name
        return self

    def with_description(self, description):
        self.description = description
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Url": self.url,
            "Name": self.name,
            "Description": self.description,
            "_RowKey": self.app_id
        }
