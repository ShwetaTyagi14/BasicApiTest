class AddUserToRoleV2:
    def __init__(self, role_id, user_ids, ds_uuid):
        """
        Used to add users to a role
        :param role_id: the id of the role
        :param user_ids: the id of the user
        :param ds_uuis: the uuid of the Directory Service
        :param login: the login of the user
        """
        self.role_id = role_id
        self.user_ids = user_ids
        self.ds_uuid = ds_uuid

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """

        users_array = []
        for user_id in self.user_ids:
            users_array.append({
                "Type": "User",
                "DirectoryServiceUuid": self.ds_uuid,
                "Id": user_id
            })

        return {
            "Users": {
                "Add": users_array
            },
            "Name": self.role_id
        }
