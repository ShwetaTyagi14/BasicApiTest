class Grants:
    def __init__(self):
        self.principal = None
        self.ptype = None
        self.rights = ''
        self.principal_id = None

    def with_principal(self, role_name):
        self.principal = role_name
        self.ptype = 'Role'
        self.principal_id = role_name
        return self

    def with_user(self, username, user_id):
        self.principal = username
        self.principal_id = user_id
        self.ptype = 'User'
        return self

    def with_view_rights(self):
        self.rights = ','.join([*self.rights.split(','), 'View']).lstrip(',')
        return self

    def with_execute_rights(self):
        self.rights = ','.join([*self.rights.split(','), 'Execute']).lstrip(',')
        return self

    def with_auto_deploy(self):
        self.rights = ','.join([*self.rights.split(','), 'Automatic']).lstrip(',')
        return self

    def with_manage_rights(self):
        self.rights = ','.join([*self.rights.split(','), 'Admin']).lstrip(',')
        return self

    def with_delete_rights(self):
        self.rights = ','.join([*self.rights.split(','), 'Delete']).lstrip(',')
        return self
    
    def with_view_detail_rights(self):
        self.rights = ','.join([*self.rights.split(','), 'ViewDetail']).lstrip(',')
        return self

    def with_no_rights(self):
        self.rights = 'None'
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            'Principal': self.principal,
            'PType': self.ptype,
            'Rights': self.rights,
            'PrincipalId': self.principal_id
        }
