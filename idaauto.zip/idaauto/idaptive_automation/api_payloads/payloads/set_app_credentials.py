class SetAppCredentials:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            'Username': self.username,
            'Password': self.password
        }
