class UsersToRolesAlero:
    def __init__(self, Name, NewName, Description, Users):
        self.Name = Name
        self.NewName = NewName
        self.Description = Description
        self.Users = Users

    def with_Name(self, Name):
        self.Name = Name
        return self

    def with_NewName(self, NewName):
        self.NewName = NewName
        return self

    def with_Description(self, Description):
        self.Description = Description
        return self

    def with_Users(self, Users):
        self.Users = Users
        return self

    def to_payload(self):
        return {
            "Name": self.Name,
            "NewName": self.NewName,
            "Description": self.Description,
            "Users": [
                self.Users
            ]
        }