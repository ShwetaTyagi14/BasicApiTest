class AddGroupsToRole:
    def __init__(self, role_id, group_ids):
        """
        Used to add groups to a role
        :param role_id: the id of the role
        :param group_ids: the ids of the groups
        """
        self.role_id = role_id
        self.group_ids = group_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Groups": {
                "Add": self.group_ids
            },
            "Name": self.role_id,
            "Description": "True"
        }
