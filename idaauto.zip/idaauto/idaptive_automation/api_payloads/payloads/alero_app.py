class AleroApp:
    def __init__(self, issuer_url, app_id):
        self.issuer = issuer_url
        self.signinurl = None
        self.spmetadataxml = None
        self.rowkey = app_id

    def with_signinurl(self, url):
        self.signinurl = url
        return self

    def with_spmetadataxml(self, xml_data):
        self.spmetadataxml = xml_data
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "IdpConfigMethod": 1,
            "Issuer": self.issuer,
            "SignInUrl": self.signinurl,
            "SpConfigMethod": 1,
            "SpMetadataUrl": "",
            "SpMetadataXml": self.spmetadataxml,
            "Audience": "",
            "Url": "https://portal.alero.io",
            "RecipientSameAsAcsUrl": True,
            "SAMLSignMethod": "response",
            "NameIDFormat": "unspecified",
            "SpSingleLogoutUrl": "",
            "EncryptAssertion": False,
            "RelayState": "",
            "AuthnContextClass": "unspecified",
            "IconUri": "/vfslow/lib/application/icons/CyberArk.png",
            "_RowKey": self.rowkey
        }
