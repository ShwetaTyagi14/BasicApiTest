class RemoveGroupsFromRole:
    def __init__(self, role_id, group_ids):
        self.role_id = role_id
        self.group_ids = group_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Groups": {
                "Delete": self.group_ids
            },
            "Name": self.role_id
        }
