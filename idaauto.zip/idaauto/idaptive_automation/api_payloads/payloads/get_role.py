class GetRole:
    def __init__(self, role_id):
        self.role_id = role_id

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
                "name": self.role_id,
                "suppressPrincipalsList": False,
                "Args": {
                    "PageNumber": 1,
                    "Limit": 1,
                    "PageSize": 1,
                    "Caching": -1
                }
}
