class GenericSamlApp:
    def __init__(self, issuer, app_id):
        self.name = None
        self.issuer = issuer
        self.app_id = app_id
        self.thumbprint = None
        self.sp_metadata_url = ''
        self.sp_metadata_xml = ''
        self.audience = None
        self.url = None
        self.recipient_same_as_acs = True
        self.want_assertions_signed = False
        self.name_id_format = 'unspecified'
        self.sp_single_logout_url = ''
        self.encrypt_assertions = False
        self.encryption_thumbprint = ''
        self.relay_state = ''
        self.auth_context_class = 'unspecified'
        self.icon_url = None
        self.username_strategy = 'ADAttribute'
        self.ad_attribute = 'userprincipalname'
        self.username_arg = 'userprincipalname'
        self.username = None
        self.sws_enabled = False

    def with_name(self, name):
        self.name = name
        return self

    def with_thumbprint(self, thumbprint):
        self.thumbprint = thumbprint
        return self

    def with_sp_metadata_url(self, url):
        self.sp_metadata_url = url
        return self

    def with_sp_metadata_xml(self, xml):
        self.sp_metadata_xml = xml
        return self

    def with_audience(self, audience):
        self.audience = audience
        return self

    def with_url(self, url):
        self.url = url
        return self

    def with_recipient_same_as_acs(self, value):
        self.recipient_same_as_acs = value
        return self

    def with_want_assertions_signed(self, value):
        self.want_assertions_signed = value
        return self

    def with_name_id_format(self, id_format):
        self.name_id_format = id_format
        return self

    def with_sp_single_logout_url(self, url):
        self.sp_single_logout_url = url
        return self

    def with_relay_state(self, state):
        self.relay_state = state
        return self

    def with_auth_context_class(self, context):
        self.auth_context_class = context
        return self

    def with_icon_url(self, url):
        self.icon_url = url
        return self

    def with_fixed_username(self, username):
        self.username_strategy = 'Fixed'
        self.username_arg = username
        self.with_username(username)
        return self

    def with_username(self, username):
        self.username = username
        return self

    def with_sws_enabled(self):
        self.sws_enabled = True
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Name": self.name,
            "IdpConfigMethod": 0,
            "Issuer": self.issuer,
            "Thumbprint": self.thumbprint,
            "SpConfigMethod": 0,
            "SpMetadataUrl": self.sp_metadata_url,
            "SpMetadataXml": self.sp_metadata_xml,
            "Audience": self.audience,
            "Url": self.url,
            "UserNameStrategy": self.username_strategy,
            "Username": self.username,
            "UserNameArg": self.username_arg,
            "RecipientSameAsAcsUrl": self.recipient_same_as_acs,
            "WantAssertionsSigned": self.want_assertions_signed,
            "NameIDFormat": self.name_id_format,
            "SpSingleLogoutUrl": self.sp_single_logout_url,
            "EncryptAssertion": False,
            "EncryptionThumbprint": self.encryption_thumbprint,
            "RelayState": self.relay_state,
            "AuthnContextClass": self.auth_context_class,
            "IconUri": self.icon_url,
            "_RowKey": self.app_id,
            "IsSwsEnabled": self.sws_enabled
        }
