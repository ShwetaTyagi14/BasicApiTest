class SecurityQuestions:
    def __init__(self):
        self.added = []
        self.deleted = []

    def with_user_question(self, kvpair):
        self.added.append({
            "Type": 'User',
            "QuestionText": kvpair['question'],
            "Modified": True,
            "HasAnswer": False,
            "Answer": kvpair['answer']
        })
        return self

    def with_admin_question(self, kvpair):
        self.added.append({
            "Type": 'Admin',
            "QuestionText": kvpair['question'],
            "Modified": True,
            "HasAnswer": False,
            "Answer": kvpair['answer']
        })
        return self

    def delete_questions_by_id(self, qids):
        self.deleted.extend(qids)
        return self

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "Deleted": self.deleted,
            "Added": self.added
        }
