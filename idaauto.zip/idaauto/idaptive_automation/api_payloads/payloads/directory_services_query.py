class DirectoryServicesQuery:
    def __init__(self, search_for, directory_services_ids):
        self.search_for = search_for
        self.directory_services = directory_services_ids

    def to_payload(self):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "user": f"{{\"_and\":[{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"givenName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"sn\":{{\"_like\":\"{self.search_for}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.search_for}\"}}}}]}},{{\"ObjectType\":\"user\"}}]}}",
            "directoryServices": self.directory_services,
            "group": f"{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.search_for}\"}}}}]}}",
            "roles": f"{{\"_or\":[{{\"_ID\":{{\"_like\":\"{self.search_for}\"}}}},{{\"Name\":{{\"_like\":\"{self.search_for}\"}}}}]}}",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
    }

    def to_email_payload(self,page_number=1):
        """
        :return: a formatted payload to be included as the body of a post request
        """
        return {
            "user": f"{{\"_and\":[{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"givenName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"sn\":{{\"_like\":\"{self.search_for}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"Email\":{{\"_end\":\"{self.search_for}\"}}}}]}},{{\"ObjectType\":\"user\"}}]}}",
            "directoryServices": self.directory_services,
            "group": f"{{\"_or\":[{{\"DisplayName\":{{\"_like\":\"{self.search_for}\"}}}},{{\"SystemName\":{{\"_like\":\"{self.search_for}\"}}}}]}}",
            "roles": f"{{\"_or\":[{{\"_ID\":{{\"_like\":\"{self.search_for}\"}}}},{{\"Name\":{{\"_like\":\"{self.search_for}\"}}}}]}}",
            "Args": {
                "PageNumber": page_number,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
    }
