# api_payloads

This project contains helper classes for creating and formatting API post request payloads

These payloads all use a 'Builder' type format. 
Example:

```python
app_name = f'{test_number} Test App number {n}'
app_descrition = f'Test App number {n}'
app_url = 'https://google.com'
app_id = app_api.import_username_password_app()
payload = GenericUserPasswordApp(app_id).with_url(app_url)\
                                        .with_description(app_descrition)\
                                        .with_name(app_name)\
                                        .with_fixed_username('testusername', 'testpassword')\
                                        .to_payload()
```

A quick look at the `to_payload()` method shows what the payload will look like:
```python
def to_payload(self):
    return {
        "Url": self.url or "",
        "MobileUrl": self.mobile_url or "",
        "UserPassScript": "@GenericUserPass",
        "LocalizationEnabled": False,
        "Name": self.name,
        "Description": self.description or "",
        "AdminTag": "Other",
        "Icon": "/vfslow/lib/application/icons/genericuser-password",
        "ShowRegistration": False,
        "Handler": "cloudlib;Centrify.Saas.apphandlers.UserPass",
        "IconUri": "/vfslow/lib/application/icons/genericuser-password",
        "UserNameStrategy": self.username_strategy,
        "ADAttribute": self.ad_attribute or "userprincipalname",
        "Username": self.username or '',
        "Password": self.password or '',
        "UserNameArg": self.username or '',
        "Script": self.script or self.default_script,
        "_RowKey": self.app_id
    }
```

For more usage examples, refer to the [main idaptive-automation repo README.md file](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/readme.md)