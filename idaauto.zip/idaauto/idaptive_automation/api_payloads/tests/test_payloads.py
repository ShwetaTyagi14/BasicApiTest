from idaptive_automation.api_payloads import InetOrgPerson, ChangeUser


def test_inet_org_person():
    cn = 'John Doe'
    sn = 'Doe'
    gn = 'John'
    password = '12345'

    payload = InetOrgPerson().with_common_name(cn)\
                             .with_surname(sn)\
                             .with_given_name(gn)\
                             .with_password(password)\
                             .to_payload()

    expected = ['cn', 'sn', 'givenName', 'userPassword']
    for k in payload.keys():
        assert k in expected
    assert 'uid' not in payload.keys()


def test_change_user():
    username = 'user1@domain.com'
    user = ChangeUser().with_name(username).to_payload()
    assert user['LoginName'] == 'user1'
    assert user['Name'] == username
