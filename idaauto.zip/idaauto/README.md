# Idaptive-Automation
This is the consolidated repo for all shared automation solutions for cross team automation at idaptive

## Installation
First make sure you have added your ssh key to bitbucket 
<a href='https://confluence.atlassian.com/bitbucket/set-up-an-ssh-key-728138079.html'>Instructions Here</a>

Install using pip:<br>
```pip install git+ssh://git@bitbucket.idaptive.com:7999/sharedautomation/idaptive-automation.git```

NOTE: On windows, you may need to run git clone at least once before running pip git+ssh.<br>
```git clone ssh://git@bitbucket.idaptive.com:7999/sharedautomation/idaptive-automation.git```

Please see <a href='https://idaptive.atlassian.net/wiki/spaces/Engineering/pages/9929023/Managing+Python+Dependencies'>Managing Python Dependencies</a> before adding new package requirements


## Structure
The solution is broken into several projects in order to meet the extensibility requirement for our coding standards. <b>Our goal is to avoid duplicate solutions to the same problem across the teams.</b>

By separating the areas of functionality in our code, we can achieve something like Dependency Injection - or as close to it as Python allows (Python does not really support DI, or even interfaces)

Each project in this repo contains a README.md file that explains how to use it

<img src="Idaptive%20automation.png" alt="Idaptive automation diagram" width="750px"/>


## The projects:

### [mongo_dal](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/mongo_dal/)
This is the Data Access Layer for MongoDB. 

### [api_helpers](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/api_helpers/)
Contains the helper classes that are used to make API calls 

### [api_payloads](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/api_payloads/)
Contains helper classes for creating the payloads for making API calls

### [api_client](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/api_client/)
A small repo containing the API client that makes the actual calls to the API

### [ui_automation](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/ui_automation/)
Contains the Page Object Model code for interacting with the Idaptive.com UI

## Contents <a name=''></a>
- [Test fixtures](#testfixtures)
  * [Api fixtures](#apifixtures)
- [Api Tests](#apitests)
- [UI Tests](#uitests)
- [SQ MFA Authentication in a test](#mfaauth)
- [Checking email during a test](#checkemail)
- [Connector Automation](#connectorautomation)

## This is confusing - How do I use all these projects to write a test??
Consolidating multiple solutions into a single repo has simplified the process considerably. Consider these examples: 
<p><b>Note: These are general suggestions for using the framework.</b> Be sure to check your team's wiki after reading this, as your team may have a different way of doing things

## Test fixtures <a name="testfixtures"></a>
#### API fixtures <a name="apifixtures"></a>
Making API calls with this framework is straight forward. You need:
* An authenticated API client
* An API helper that knows how to make the calls you need to make

You can handle this yourself by directly creating an ApiSession object and passing in the credentials, or you can use one of the fixtures that handle all that for you.

To have the an authenticated session created for you, checkout the [Fixtures](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/fixtures) section


## Api tests <a name="apitests"></a>
For most of your tests you will need to create entities on a tenant (users, roles, policies, etc). Best practices are to clean up/remove these entities after the test completes. Also, if the the creation of the entities is not part of the actual test, then the creation should be handled prior to the test being run. This way, any errors encountered during test setup or teardown will not affect the Pass/Fail status of the test itself. Most of our API helpers include an 'auto_clean' feature, that handles the removal after the test completes.

Example:
```python
# contents of conftest.py - fixtures go here
from idaptive_automation.api_helpers import TenantApiHelper, UserApi, RoleApi, AppHelper
from idaptive_automation.api_payloads import CloudUser
import re
import pytest


@pytest.fixture()
def apps_deployed_to_cloud_role_api_fixture(request, session_fixture):
    test_name = request.node.originalname or request.node.name
    m = re.match(r'test_(c\d{5,})_', test_name)
    test_number = m.group(1)
    username = f'{test_number}-automation-user'
    alias = TenantApiHelper(session_fixture['session']).get_aliases_for_tenant()[0]
    display_name = f"{test_number} Automation {alias}"
    with UserApi(session_fixture['session'], True) as user_api,\
            AppHelper(session_fixture['session'], True) as app_api,\
            RoleApi(session_fixture['session'], True) as role_api:
            # create users, roles, policies, etc
            payload = CloudUser(alias, username)\
                .with_password_never_expire(True)\
                .with_password('njGW46628&*')\
                .with_display_name(display_name)\
                .to_payload()
            uuid = user_api.create_cloud_user(payload).result()
            payload['uuid'] = uuid
            
            role_name = f'{test_number} Test Role for user'
            role_id = role_api.create_role_if_not_exists(role_name)
            role_api.add_users_to_automation_role([uuid])
            role_api.add_users_to_role(role_id, [uuid])
            
            yield {
                'alias': alias,
                'uer_api': user_api,
                'app_api': app_api,
                'role_api': role_api,
                'user': payload,
                'role_id': role_id
            }
    # when the test completes, the cloud user and the role will be removed
```

```python
# In your test file, import the api client and retrieve the tenant credentials with these 2 lines:
from idaptive_automation.api_client import api_session, mongo_dal
from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
from idaptive_testrail.plugin import pytestrail

# Want to inject your own dependencies? 
# No problem - change the import statement
# Example:
# from mobile_automation import mobile_api_session as api_session

@pytestrail.case('C33508')
def test_example(apps_deployed_to_cloud_role_api_fixture):
    user_api = apps_deployed_to_cloud_role_api_fixture['user_api']
    # do testing stuff here
    
```


## UI tests: <a name="uitests"></a>
Refer to the [ui_automation project](https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/browse/idaptive_automation/ui_automation/)
for complete examples of UI automation

## SQ MFA Authentication during a test <a name='mfaauth'></a>
The standard `ApiSession` class has been extended to include the ability to seamlessly authenticate to the API system via SQ MFA. To do so, simply set an environment variable with the full login name of the user to a json string of an array of `{'question': 'x', ' 'answer': 'y'}` values. Example:
```python
import os
import json
os.environ['john.doe@abc1234'] = json.dumps([{'question': 'dog', 'answer': 'cat'}])
```
That is all that's required to authenticate to the api using SQ MFA. Note that setting the environment variable for a user name makes SQ MFA a requirement for the user. You will not be able to authenticate without it.

## Checking email during a test <a name='checkemail'></a>
There is an EmailHelper class in the API section that includes basic functionality for checking email on a Gmail account. Each team will need to extend this class before using it, to implement message parsing for the types of messages they are working with

## Connector automation: <a name="connectorautomation"></a>
We currently use [pywinauto](https://pywinauto.readthedocs.io/en/latest/) for connector
automation. Unfortunately the level of complexity involved in automatin the connector has prevented us from exporting that automation into a shared solution.
Work in this area is ongoing, and we hope to have something everyone can use at some point in the near future.
