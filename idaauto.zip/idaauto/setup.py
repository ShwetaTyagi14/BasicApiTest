import setuptools

setuptools.setup(
    name='idaptive_automation',
    version='0.3.9',
    author='Hunter Alving',
    author_email='current.address@unknown.invalid',
    maintainer='Jared Morgan',
    maintainer_email='jared.morgan@cyberark.com',
    description='The main solution for Idaptive automation',
    url='https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptive-automation/',
    packages=setuptools.find_packages(),
    install_requires=[
            'ldap3wrapper @ git+https://bitbucket.idaptive.com/scm/sharedautomation/ldap3wrapper.git',
            'ldap3>=2.6',
            'pandas>=0.24.2',
            'pymongo>=3.7.2',
            'requests>=2.21.0',
            'selenium>=3.141.0',
            'simplejson>=3.16.0',
    ],
    extras_require={
        'test': [
            'pytest>=3.5.1'
        ]
    },
    dependency_links=[
        'https://bitbucket.idaptive.com/scm/sharedautomation/ldap3wrapper.git'
    ]

)
