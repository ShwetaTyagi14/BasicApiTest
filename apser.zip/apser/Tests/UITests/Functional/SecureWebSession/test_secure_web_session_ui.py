import pytest
from Steps.app_steps import *
from idaptive_automation.ui_automation import AppDetailsPage, WSFedSettingsPage, UserPortalPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.secure_web_session_tab import \
    SecureWebSessionPage
from idaptive_testrail.plugin import pytestrail
from Fixtures.tenant_key_fixtures import set_sws_entitlement
from Steps.navigate_steps import Login, Navigate
from idaptive_automation.ui_automation import PortalSwitcherPopout


@pytestrail.case('C178794')
def test_c178794_securewebsession_portal_switcher(app_helpers, set_sws_entitlement, driver_admin, lcm_helpers):
    app_api = lcm_helpers['app_helper']
    app_helper = app_helpers['app_helper']
    tenant_info = app_api.api_session
    role_helper = app_helpers['role_helper']
    user_helper = app_helpers['user_helper']
    cloud_session = app_helpers['cloud_session']

    user_id = user_helper.get_user_info(cloud_session.username)['Entities'][0]['Key']
    sws_admin_role_id = role_helper.get_role_info_by_name("SWS Admin")['ID']
    role_helper.add_users_to_role(sws_admin_role_id, [user_id])

    app_id = app_api.get_app_key_from_app_name("CyberArk Secure Web Session Portal")

    portal_switch = PortalSwitcherPopout(driver_admin)
    portal_switch.refresh_page()
    options = portal_switch.get_switcher_options()
    assert "Secure Web Session Portal" in options, "SWS not available, ensure SWS Entitlement is enabled on this tenant"

    portal_switch.switch_to_user_portal()
    options = portal_switch.get_switcher_options()
    assert "Secure Web Session Portal" in options, "SWS failed from User Portal"

    sws_service_name = get_service_name_from_app_name(app_helper, 'CyberArk Secure Web Session Portal')
    assert sws_service_name == "SWS_Portal_Bridge", 'SWS app was not deployed but should have been'
    sws_portal_launch_url = portal_switch.get_sws_portal_launch_url()
    assert sws_portal_launch_url == f"{tenant_info.base_url}/uprest/HandleAppClick?appkey={sws_service_name}", \
        "SWS site launch URL is not correct"

    identity_portal_location_current = driver_admin.current_url
    portal_switch.switch_to_sws_portal()
    sws_portal_url = portal_switch.get_sws_tab_current_url()
    assert sws_portal_url is not None, "SWS site url cannot be None"
    assert sws_portal_url != identity_portal_location_current, "Browser did not visit the SWS site"
    assert sws_portal_launch_url == sws_portal_url


@pytestrail.case('C178795')
def test_c178795_set_securewebsession_app_in_sws_app_tab(app_helpers, set_sws_entitlement, driver_admin, lcm_helpers):
    app_api = lcm_helpers['app_helper']
    app_helper = app_helpers['app_helper']

    ws_fed_app = app_api.import_app_by_name("GenericWsFed")
    web_apps_page = Navigate(driver_admin).to_web_app_tab()
    web_apps_page.search_for_app('WS-Fed')
    web_apps_page.select_web_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    ws_fed_page.set_app_url("https://www.wowza.com")
    AppDetailsPage(driver_admin).click_secure_web_session_tab()
    sws_page = SecureWebSessionPage(driver_admin)
    sws_page.check_enable_sws_box()
    sws_page.click_save_button()

    result_ws_fed_app = app_helper.get_application(ws_fed_app)
    assert result_ws_fed_app['IsSwsEnabled']
    assert result_ws_fed_app['SwsDeepLink'] is not None


@pytestrail.case('C178796')
def test_c178796_securewebsession_icon_validation(app_helpers, set_sws_entitlement, driver, lcm_helpers):
    app_api = lcm_helpers['app_helper']
    app_helper = app_helpers['app_helper']
    tenant_info = app_api.api_session
    role_helper = app_helpers['role_helper']
    user_helper = app_helpers['user_helper']
    cloud_session = app_helpers['cloud_session']

    user_id = user_helper.get_user_info(cloud_session.username)['Entities'][0]['Key']
    sws_admin_role_id = role_helper.get_role_info_by_name("SWS Admin")['ID']
    role_helper.add_users_to_role(sws_admin_role_id, [user_id])

    catalog_app = "SWS_test"
    app_name = f"{catalog_app}-{app_helpers['test_id']}"
    app_description = f"{catalog_app}-{app_helpers['test_id']}"
    app_url = "https://www.google.com"
    app_id = deploy_app_by_name(app_helper, "Generic User-Password")
    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .with_sws_enabled() \
        .to_payload()
    result = app_helper.update_application_de(app)

    Login(driver, tenant_info.base_url).to_user_portal(tenant_info.username, tenant_info.password,
                                                       wait_for_load_up=True)
    user_portal = UserPortalPage(driver)
    user_portal.search_app_input(app_name)
    assert user_portal.is_app_tile_displayed(app_name)
    assert user_portal.is_sws_icon_displayed()


@pytestrail.case('C178797')
def test_c178797_securewebsession_sws_link_validation(app_helpers, set_sws_entitlement, driver_admin):
    app_helper = app_helpers['app_helper']
    catalog_app = "SWS_test"
    app_name = f"{catalog_app}-{app_helpers['test_id']}"
    app_description = f"{catalog_app}-{app_helpers['test_id']}"
    app_url = "https://www.google.com"
    app_id = deploy_app_by_name(app_helper, "Generic User-Password")
    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .with_sws_enabled() \
        .to_payload()
    result = app_helper.update_application_de(app)

    web_apps_page = Navigate(driver_admin).to_web_app_tab()
    web_apps_page.search_for_app(f"{app_name}")
    web_apps_page.select_web_app(f"{app_name}")

    AppDetailsPage(driver_admin).click_secure_web_session_tab()
    sws_page = SecureWebSessionPage(driver_admin)
    sws_page.click_configure_sws_link()
    sws_page.switch_to_configure_sws_link_tab(driver_admin.window_handles[1])
    assert "portal.alero.io" in driver_admin.current_url
    assert "/uprest/handleappclick?appkey" in driver_admin.current_url
