import pytest
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_customization_page import \
    SettingsCustomizationPage
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.select_users_window import \
    SelectUsersWindow
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.send_invites import SendInvitesWindow
from idaptive_automation.ui_automation.pages.adminportal.add_login_suffix_dialog import AddLoginSuffixDialog
from idaptive_automation.ui_automation.pages.adminportal.suffix_landing_page import SuffixLandingPage
from idaptive_automation.ui_automation.pages.error_dialog import ErrorDialog
from idaptive_automation.ui_automation.pages.reset_your_password_window import ResetYourPasswordWindow
from idaptive_automation.ui_automation.pages.sign_in_page_after_change_password import SignInWithNewPassword
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate, Login
from idaptive_automation.ui_automation import UsersTab, UserAddEditWindow, UAESelectManagerPage, APUserProfileMenu, \
    UserPortalPage, AdminPortalPage, RolesTabPage, RolesAddEditWindow, RolesUnsavedChangesDialog
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_add_edit_window import AddMembersDialog
import uuid
from idaptive_automation.api_helpers import UserApi, RoleApi
from idaptive_automation.api_payloads import CloudUser, InviteUser
from idaptive_automation.ui_automation import ConfirmDeleteWindow
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.set_password_window import SetUserPasswordWindow
import time, json
from idaptive_automation.api_helpers import EmailHelper
from Fixtures.tenant_key_fixtures import *
from Fixtures.custom_attribute_mapping_fixture import CustomADMapping_fixture as customad
from Fixtures.ad_writable_fixture import MakeAdWritable_fixture as adwritable
from idaptive_automation.api_helpers import UserMgmt
from Steps.user_steps import verify_ad_attribute_changes_to_cloud, set_user_attributes
from idaptive_automation.ui_automation import PortalSwitcherPopout
from Steps.ui_user_steps import wait_for_editable, validate_mobile_numbers
from Helpers.general_helpers import random_password

@pytestrail.case('C33449')
@pytest.mark.pipeline
def test_c33449_add_user(driver, app_helpers):
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_users_tab()

    user_count = len(app_helpers['user_helper'].get_all_users()[1])

    users_tab = UsersTab(driver)
    detail_window = users_tab.open_add_user_window()
    name = app_helpers['test_id']
    email = f'{name}@gmail.com'

    detail_window.set_login(name)
    detail_window.set_email(email)
    detail_window.set_display_name(name)
    detail_window.set_password('testTEST1234')
    detail_window.set_confirm_password('testTEST1234')
    detail_window.press_create_user_button()

    users_tab.search_for_user(name)

    user_login_name = f'{name}@{str(tenant_info["tenant_id"]).lower()}'
    users_tab.select_user_checkbox(user_login_name)

    users_tab.open_actions_menu()
    users_tab.click_delete()

    ConfirmDeleteWindow(driver).press_yes()


@pytestrail.case('C149948')
@pytest.mark.pipeline
def test_c149948_search_by_email_domain_suffix(driver_admin, app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    user_api = app_helpers['user_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    name = f'test_c149948_user'
    email = f'{name}@zzxy.email'
    payload = CloudUser(alias, f'{name}').with_email(email).to_payload()
    username = user_api.create_cloud_user(payload)

    Navigate(driver_admin).to_users_tab()
    users_tab = UsersTab(driver_admin)
    users_tab.search_for_user('zzxy.email')
    user = users_tab.get_displayed_users()
    assert user[0][2] == email
    users_tab.search_for_user('xy.email')
    user = users_tab.get_displayed_users()
    assert user[0][2] == email
    users_tab.search_for_user('zzxy.e')
    user = users_tab.get_displayed_users()
    assert user[0][2] == email

    roles_tab = Navigate(driver_admin).to_roles_tab()
    add_roles_window = roles_tab.open_add_role_window()
    add_roles_window.set_role_name('C149948')
    add_roles_window.select_members_tab()

    add_members = add_roles_window.open_add_members_window()
    add_members.search_for_user('zzxy.email')
    user = add_members.get_search_results()
    assert user[0][1] == email
    add_members.search_for_user('xy.email')
    user = add_members.get_search_results()
    assert user[0][1] == email
    add_members.search_for_user('zzxy.e')
    user = add_members.get_search_results()
    assert user is None

    add_members.press_cancel_button()
    add_roles_window.press_cancel_button()


@pytestrail.case('C149949')
@pytest.mark.pipeline
def test_c149949_negative_testing_for_search_by_email_domain_suffix(driver_admin, app_helpers, lcm_helpers):
    domain_worker = lcm_helpers['active_directory_helper']
    tenant_info = lcm_helpers['app_helper'].api_session
    user_helper = app_helpers['user_helper']
    user_mgmt = UserMgmt(tenant_info)
    password = random_password()
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, password)
    ad_user = f"{base_name}user1"
    email = str(uuid.uuid4())[0:8] + ".com"
    ou = domain_worker.created_ou_list[0].split(',')
    uid = domain_worker.get_ad_user_attribute(f'{ad_user}', ou[0], 'objectGUID')
    uid = uid.values[0][1:-1]
    domain_worker.modify_ad_user_attribute(f'{ad_user}', ou[0], 'mail', f"{app_helpers['test_id']}@{email}")
    invite_payload = InviteUser(ad_user, uid).to_payload()
    user_mgmt.invite_user(invite_payload)

    Navigate(driver_admin).to_users_tab()
    users_tab = UsersTab(driver_admin)
    users_tab.search_for_user(email)
    user = users_tab.get_displayed_users()
    full_email_address = f"{app_helpers['test_id']}@{email}"
    assert user[0][2] == full_email_address
    users_tab.search_for_user(email[2:])
    user = users_tab.get_displayed_users()
    assert user[0][2] == full_email_address
    users_tab.search_for_user(email[:-4])
    user = users_tab.get_displayed_users()
    assert user[0][2] == full_email_address

    roles_tab = Navigate(driver_admin).to_roles_tab()
    add_roles_window = roles_tab.open_add_role_window()
    add_roles_window.set_role_name('C149949')
    add_roles_window.select_members_tab()

    add_members = add_roles_window.open_add_members_window()
    add_members.search_for_user(email)
    user = add_members.get_search_results()
    assert user is None
    add_members.search_for_user(email[2:])
    user = add_members.get_search_results()
    assert user is None
    add_members.search_for_user(email[:-4])
    user = add_members.get_search_results()
    assert user is None

    add_members.press_cancel_button()
    add_roles_window.press_cancel_button()


@pytestrail.case('C168294')
def test_c168294_mobile_writeback_field_editable(customad, app_helpers, adwritable, driver_admin):
    mobile_number = "8014541234"
    assert customad.enable_custom_mapping()
    domain_worker, user_mgmt, ad_user, uid = customad.setup_ad_for_mapping()
    assert wait_for_editable(driver_admin, ad_user, domain_worker, mobile_number), \
        f'Timed Out, Mobile did not become editable within allowed timeframe'
    base_name = ad_user.split('user1')[0]
    ad_description = domain_worker.get_ad_user_attribute(f'{ad_user}', f"ou={base_name}", 'description')
    assert mobile_number == ad_description, f"Expected AD description value to match new value, but it did not"


@pytestrail.case('C173576')
def test_c173576_AD_mobile_number_set_invalid(adwritable, driver_admin, app_helpers, lcm_helpers):
    domain_worker = lcm_helpers['active_directory_helper']
    password = random_password()
    tenant_info = lcm_helpers['app_helper'].api_session
    user_mgmt = UserMgmt(tenant_info)
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, password)
    ad_user = f"{base_name}user1"
    ou = domain_worker.created_ou_list[0].split(',')
    uid = domain_worker.get_ad_user_attribute(f'{ad_user}', ou[0], 'objectGUID')
    uid = uid.values[0][1:-1]
    invite_payload = InviteUser(ad_user, uid).to_payload()
    user_mgmt.invite_user(invite_payload)
    mobile_numbers = ['a2367b1234', '5555555555555555555555555555555555555555555555555', '22', '209-231-2343',
                      '+4455366789', '+912345678978']
    validate_mobile_numbers(app_helpers, driver_admin, ad_user, domain_worker, mobile_numbers)

#
# @pytestrail.case('C87852')
# @pytest.mark.pipeline
# def test_c87852_generate_user_password_in_ap(new_cloud_user_in_automation_role_fixture,
#                                              admin_portal_function_driver):
#     """ Generate user password in AP and log into UP successfully """
#     Navigate(admin_portal_function_driver).to_users_tab()
#     name = new_cloud_user_in_automation_role_fixture['Name']
#
#     users_tab = UsersTab(admin_portal_function_driver)
#     users_tab.validate_users_tab_is_loaded()
#     users_tab.search_for_user(name)
#     users_tab.select_user_checkbox(name)
#     users_tab.open_actions_menu()
#     users_tab.click_set_password()
#
#     set_user_pwd = SetUserPasswordWindow(admin_portal_function_driver)
#     set_user_pwd.wait_for_page_to_load()
#     set_user_pwd.validate_all_child_elements()
#     set_user_pwd.select_generated_radio_button()
#     set_user_pwd.is_generated_password_displayed()
#     set_user_pwd.click_copy_button()
#
#     generated_password = set_user_pwd.copy_password_to_clipboard().columns[0]
#     assert generated_password is not None
#
#     set_user_pwd.click_save_button()
#
#     APUserProfileMenu(admin_portal_function_driver).sign_out()
#     Login(admin_portal_function_driver).to_user_portal(name, generated_password)
#
#     assert UserPortalPage(admin_portal_function_driver).get_user_display_text() == new_cloud_user_in_automation_role_fixture['DisplayName'], \
#         f'User is not logged into UP, expected {new_cloud_user_in_automation_role_fixture["DisplayName"]}, found {UserPortalPage(admin_portal_function_driver).get_user_display_text()}'
#
#
# @pytestrail.case('C93726')
# @pytest.mark.pipeline
# def test_c93726_manually_change_user_password_in_ap(new_cloud_user_in_automation_role_fixture,
#                                                     admin_portal_function_driver):
#     """ Manually change user password in AP and log into UP successfully """
#     Navigate(admin_portal_function_driver).to_users_tab()
#
#     users_tab = UsersTab(admin_portal_function_driver)
#     user_password_window = SetUserPasswordWindow(admin_portal_function_driver)
#
#     name = new_cloud_user_in_automation_role_fixture['Name']
#     password = 'TESTtest1234'
#     confirm_password = 'TESTtest1234'
#     users_tab.validate_users_tab_is_loaded()
#     users_tab.search_for_user(name)
#     users_tab.select_user_checkbox(name)
#     users_tab.open_actions_menu()
#     users_tab.click_set_password()
#
#     user_password_window.wait_for_page_to_load()
#     user_password_window.validate_all_child_elements()
#
#     assert user_password_window.is_manual_radio_button_selected() is True, f'Manual radio is to be checked, but found unchecked'
#
#     user_password_window.set_password(password)
#     user_password_window.set_confirm_password(confirm_password)
#     user_password_window.click_save_button()
#
#     assert user_password_window.validate_success_toaster() is True, f'Success toaster is not displayed'
#
#     APUserProfileMenu(admin_portal_function_driver).sign_out()
#     Login(admin_portal_function_driver).to_user_portal(name, password)
#
#     assert UserPortalPage(admin_portal_function_driver).get_user_display_text() == \
#            new_cloud_user_in_automation_role_fixture['DisplayName'], \
#         f'User is not logged into UP, expected {new_cloud_user_in_automation_role_fixture["DisplayName"]}, found {UserPortalPage(admin_portal_function_driver).get_user_display_text()}'
#
#
# @pytestrail.case('C93583')
# @pytest.mark.pipeline
# def test_c93583_change_user_password_in_ap_non_matching_pwds_negative_test(new_cloud_user_in_automation_role_fixture,
#                                                                            admin_portal_function_driver):
#     """ Manually change user password in AP - non matching passwords - negative test """
#     Navigate(admin_portal_function_driver).to_users_tab()
#
#     password = 'testTEST1234'
#     confirm_password = 'testTST1234'
#
#     UsersTab(admin_portal_function_driver).search_for_user(new_cloud_user_in_automation_role_fixture['Name'])
#     UsersTab(admin_portal_function_driver).select_user_checkbox(new_cloud_user_in_automation_role_fixture['Name'])
#     UsersTab(admin_portal_function_driver).open_actions_menu()
#     UsersTab(admin_portal_function_driver).click_set_password()
#
#     SetUserPasswordWindow(admin_portal_function_driver).wait_for_page_to_load()
#     SetUserPasswordWindow(admin_portal_function_driver).validate_all_child_elements()
#     SetUserPasswordWindow(admin_portal_function_driver).set_password(password)
#     SetUserPasswordWindow(admin_portal_function_driver).set_confirm_password(confirm_password)
#
#     assert SetUserPasswordWindow(admin_portal_function_driver).is_confirm_error_icon_displayed() is True, 'Error icon not displayed in dialog, expected displayed'
#
#     assert SetUserPasswordWindow(admin_portal_function_driver).is_save_button_disabled() is True, 'Save button is enabled, expected disabled'
#
#
# @pytestrail.case('C87851')
# @pytest.mark.pipeline
# def test_c87851_change_user_password_in_ap_invalid_pwd_negative_test(new_cloud_user_in_automation_role_fixture,
#                                                                      admin_portal_function_driver):
#     """ Manually change user password in AP - invalid password - negative test """
#     Navigate(admin_portal_function_driver).to_users_tab()
#
#     users_tab = UsersTab(admin_portal_function_driver)
#     user_add_window = SetUserPasswordWindow(admin_portal_function_driver)
#
#     pwd_error = ErrorDialog(admin_portal_function_driver)
#     name = new_cloud_user_in_automation_role_fixture['Name']
#     password = 'test1234'
#     confirm_password = 'test1234'
#
#     users_tab.validate_users_tab_is_loaded()
#     users_tab.search_for_user(name)
#     users_tab.select_user_checkbox(name)
#     users_tab.open_actions_menu()
#     users_tab.click_set_password()
#
#     user_add_window.wait_for_page_to_load()
#     user_add_window.validate_all_child_elements()
#     user_add_window.set_password(password)
#     user_add_window.set_confirm_password(confirm_password)
#     user_add_window.click_save_button()
#
#     pwd_error.wait_for_page_to_load()
#
#     exp_msg = "Password update failed. Please make sure the password meet the complexity requirements. Password must be at least 8 characters long, not be longer than 64 characters, contain at least one digit, contain at least one upper and one lower case letter"
#     assert exp_msg == pwd_error.get_error_message(), f'Message incorrect ,expected {exp_msg} , but found {pwd_error.get_error_message()}'
#
#
# @pytestrail.case('C95345')
# @pytest.mark.pipeline
# def test_c95345_assign_manager_to_user_in_ap(admin_portal_function_driver, new_cloud_user_in_automation_role_fixture, session_fixture):
#     """ Assign manager to user in AP , Then the name of the user's manager is displayed under 'Manager' """
#     Navigate(admin_portal_function_driver).to_users_tab()
#
#     UsersTab(admin_portal_function_driver).validate_users_tab_is_loaded()
#     UsersTab(admin_portal_function_driver).search_for_user(session_fixture['username'])
#     UsersTab(admin_portal_function_driver).open_user_detail_window_for_user(session_fixture['username'])
#
#     UserAddEditWindow(admin_portal_function_driver).press_select_manager()
#     UAESelectManagerPage(admin_portal_function_driver).wait_for_page_to_load()
#     UAESelectManagerPage(admin_portal_function_driver).search_for_user(new_cloud_user_in_automation_role_fixture['Name'])
#
#     UAESelectManagerPage(admin_portal_function_driver).click_on_user(new_cloud_user_in_automation_role_fixture['Name'])
#     UAESelectManagerPage(admin_portal_function_driver).press_ok_button()
#     UserAddEditWindow(admin_portal_function_driver).wait_for_page_to_load()
#     text = UserAddEditWindow(admin_portal_function_driver).get_manager_text()
#     assert text == new_cloud_user_in_automation_role_fixture['Name'], f'Manager name is not displayed, found {text}, expexted {new_cloud_user_in_automation_role_fixture["Name"]} '
#     UserAddEditWindow(admin_portal_function_driver).click_save_button()
#     APUserProfileMenu(admin_portal_function_driver).sign_out()
#     Login(admin_portal_function_driver).to_user_portal(session_fixture['username'], session_fixture['password'])
#     UserPortalPage(admin_portal_function_driver).click_account_tab()
#     UserPortalPage(admin_portal_function_driver).click_organization_tab()
#     text = UserPortalPage(admin_portal_function_driver).get_manager_text()
#     assert text == new_cloud_user_in_automation_role_fixture['Name'], f'Manager name is not displayed, found {text}, expected {new_cloud_user_in_automation_role_fixture["Name"]}'
#
#
# @pytestrail.case('C76689')
# @pytest.mark.pipeline
# def test_c76689_require_pwd_change_reflects_in_next_user_login(session_fixture,
#                                                                generic_driver,
#                                                                case_number,
#                                                                new_password_change_cloud_user_in_automation_role_fixture_function):
#     """ Create a cloud user who is required to change their password on first login
#         and  user is required to change password and login successfully in UP """
#     new_password = "Idap@123"
#     confirm_password = "Idap@123"
#
#     user = new_password_change_cloud_user_in_automation_role_fixture_function['user']
#     Login(generic_driver).to_user_portal_via_reset_password(user['Name'], user['Password'])
#
#     ResetYourPasswordWindow(generic_driver).wait_for_page_to_load()
#     ResetYourPasswordWindow(generic_driver).set_new_password(new_password)
#     ResetYourPasswordWindow(generic_driver).set_confirm_password(confirm_password)
#     ResetYourPasswordWindow(generic_driver).click_next_button()
#
#     expected_message = 'Password change was successful, please authenticate with your new credentials.'
#     actual_message = ResetYourPasswordWindow(generic_driver).get_change_password_successfully_message()
#     assert actual_message == expected_message, f'Incorrect message, found {actual_message}, expected {expected_message}'
#     ResetYourPasswordWindow(generic_driver).click_start_over()
#
#     SignInWithNewPassword(generic_driver).wait_for_page_to_load()
#     actual_text = SignInWithNewPassword(generic_driver).get_username_text()
#     assert actual_text == user['Name'], \
#         f'username is not populated in the User Name filed, found {actual_text}, expected {user["Name"]}'
#
#     SignInWithNewPassword(generic_driver).wait_for_page_to_load()
#     SignInWithNewPassword(generic_driver).click_user_next_button()
#     SignInWithNewPassword(generic_driver).set_password(new_password)
#     SignInWithNewPassword(generic_driver).click_password_next_button()
#
#     UserPortalPage(generic_driver).wait_for_page_to_load()
#
#     displayed_username = UserPortalPage(generic_driver).get_user_display_text()
#     assert displayed_username == user['DisplayName'], \
#         f'User is not logged into UP, expected {user["DisplayName"]}, found {displayed_username}'
#
#
# @pytestrail.case('C33451')
# @pytest.mark.pipeline
# def test_c33451_send_user_invite_in_ap(admin_portal_function_driver,
#                                        existing_cloud_user,
#                                        session_fixture):
#     """  Create a cloud user and sending invite to the user , validating the inviting mail to user's mail  """
#     Navigate(admin_portal_function_driver).to_users_tab()
#     UsersTab(admin_portal_function_driver).validate_users_tab_is_loaded()
#
#     name = existing_cloud_user['Name']
#
#     Navigate(admin_portal_function_driver).to_users_tab()
#     UsersTab(admin_portal_function_driver).open_invite_user_window()
#
#     SelectUsersWindow(admin_portal_function_driver).search_to_invite(name)
#     SelectUsersWindow(admin_portal_function_driver).select_checkbox_for_user(name)
#     SelectUsersWindow(admin_portal_function_driver).click_invite_button()
#
#     timestamp = int(time.time()) - 1
#     SendInvitesWindow(admin_portal_function_driver).wait_for_page_to_load()
#     SendInvitesWindow(admin_portal_function_driver).click_send_invites_button()
#     assert SendInvitesWindow(
#             admin_portal_function_driver).validate_send_invites_toaster_msg() is True, f'Send Invites toaster is not displayed'
#
#     UsersTab(admin_portal_function_driver).validate_users_tab_is_loaded()
#     UserApi(session_fixture['session']).wait_for_user_invited_status(name, 60)
#     query = {
#         'date.received': {'$gt': timestamp},
#         'emailType': 'user invite',
#         'username': name
#     }
#     messages = EmailHelper(None).wait_for_message(query, wait_seconds=180)
#     assert messages is not None and len(messages) == 1, \
#         f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#     message = messages[0]
#
#     assert 'CyberArk Identity Service - User Account' in message['subject']
#     assert 'Welcome to Idaptive!' in message['body'][0]
#     assert 'Here are your account details:' in message['body'][0]
#
#
# @pytestrail.case('C28102')
# @pytest.mark.pipeline
# def test_c28102_admin_cannot_create_duplicate_user(admin_portal_function_driver, session_fixture):
#     """ Admin cannot create user with duplicate username """
#     Navigate(admin_portal_function_driver).to_users_tab()
#
#     users_tab = UsersTab(admin_portal_function_driver)
#     detail_window = users_tab.open_add_user_window()
#
#     name = f'automation'
#     email = f'test@test.test'
#     user_login_name = f'{name}@{session_fixture["tenant"]}'
#
#     detail_window.set_login(name)
#     detail_window.set_email(email)
#     detail_window.set_display_name(name)
#     detail_window.set_password('testTEST1234')
#     detail_window.set_confirm_password('testTEST1234')
#     error_dialog = detail_window.press_create_user_button_with_error()
#
#     error_message = error_dialog.get_error_message()
#     expected_error = f'User name {user_login_name} is already in use.'
#     assert error_message == expected_error, f'Error dialog not displayed, found {error_message}, expected {expected_error}'
#
#
# @pytestrail.case('C93670')
# @pytest.mark.pipeline
# def test_c93670_add_new_suffix_and_create_users_with_that_suffix(admin_portal_function_driver,
#                                                                  session_fixture,
#                                                                  case_number,
#                                                                  auto_cleanup_role_fixture,
#                                                                  random_password):
#     """ Add a new suffix and create users with that suffix and user should be logged in successfully to UP  """
#     AdminPortalPage(admin_portal_function_driver).select_settings_customization()
#     SettingsCustomizationPage(admin_portal_function_driver).click_suffix()
#
#     suffix_page = SuffixLandingPage(admin_portal_function_driver)
#     suffix_page.press_suffix_add_button()
#     AddLoginSuffixDialog(admin_portal_function_driver).set_login_suffix(suffix=case_number)
#     AddLoginSuffixDialog(admin_portal_function_driver).press_suffix_save_button()
#
#     with UserApi(session_fixture['session'], True) as user_api,\
#             RoleApi(session_fixture['session'], True) as role_api:
#         username = f'{case_number}-automation-user'
#         display_name = f"{case_number} Automation {case_number}"
#         payload = CloudUser(case_number, username)\
#             .with_password_never_expire(True)\
#             .with_password(random_password)\
#             .with_display_name(display_name)\
#             .to_payload()
#         payload['uuid'] = user_api.create_cloud_user(payload).result()
#
#         role_api.add_users_to_automation_role([payload['uuid']])
#
#         APUserProfileMenu(admin_portal_function_driver).sign_out()
#         Login(admin_portal_function_driver).to_user_portal(payload['Name'], payload['Password'])
#
#         UserPortalPage(admin_portal_function_driver).wait_for_page_to_load()
#         assert UserPortalPage(admin_portal_function_driver).get_user_display_text() == payload['DisplayName'], \
#             f'User is not logged into UP, expected {payload["DisplayName"]}, found {UserPortalPage(admin_portal_function_driver).get_user_display_text()}'
#
#
# @pytestrail.case('C28040')
# @pytest.mark.pipeline
# def test_c28040_admin_cannot_reset_password_for_min_length(new_cloud_user_in_automation_role_fixture,
#                                                                      admin_portal_function_driver):
#     """  admin cannot reset password min length to less than default maximum length"""
#     Navigate(admin_portal_function_driver).to_users_tab()
#
#     users_tab = UsersTab(admin_portal_function_driver)
#     set_user_password_window = SetUserPasswordWindow(admin_portal_function_driver)
#
#     error_dialog = ErrorDialog(admin_portal_function_driver)
#     name = new_cloud_user_in_automation_role_fixture['Name']
#     password = '1abcde'
#     confirm_password = '1abcde'
#
#     users_tab.validate_users_tab_is_loaded()
#     users_tab.search_for_user(name)
#     users_tab.select_user_checkbox(name)
#     users_tab.open_actions_menu()
#     users_tab.click_set_password()
#
#     set_user_password_window.wait_for_page_to_load()
#     set_user_password_window.set_password(password)
#     set_user_password_window.set_confirm_password(confirm_password)
#     set_user_password_window.click_save_button()
#     error_dialog.wait_for_page_to_load()
#
#     exp_msg = "Password update failed. Please make sure the password meet the complexity requirements. Password must be at least 8 characters long, not be longer than 64 characters, contain at least one digit, contain at least one upper and one lower case letter"
#     assert exp_msg == error_dialog.get_error_message(), f'Message incorrect ,expected {exp_msg} , but found {error_dialog.get_error_message()}'
#
#
# @pytestrail.case('C76718')
# @pytest.mark.pipeline
# def test_c76718_bulk_user_import_function(admin_portal_function_driver,
#                                           session_fixture):
#     file_name = 'c76718.csv'
#     file_path = write_bulk_users_to_file(file_name, 'c76718', 1, session_fixture['tenant'])
#     user_api = UserApi(session_fixture['session'])
#
#     Navigate(admin_portal_function_driver).to_users_tab()
#     users_tab = UsersTab(admin_portal_function_driver)
#     bulk_import_window = users_tab.open_bulk_user_import_window()
#     bulk_import_window.set_filename(filename=file_path)
#     bulk_import_window.click_next()
#     assert bulk_import_window.get_is_user_in_import_list('c76718') is True
#
#     bulk_import_window.click_next()
#     bulk_import_window.uncheck_send_email_invite_chk()
#     bulk_import_window.click_confirm_button()
#
#     user_api.wait_for_user_and_delete(f"c76718.cloud.1@{session_fixture['tenant']}")
#
