import time
import pytest
# import os
import sys
from idaptive_automation.api_payloads import CloudUser, SingleBulkUserImport
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.bulk_user_import_window import \
    BulkUserImportWindow
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.UserAddEdit.select_users_window import \
    SelectUsersWindow
from Helpers.constants import DEFAULT_PASSWORD
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate, Login
from Steps.users_tab_steps import UsersTabSteps
from idaptive_automation.ui_automation import UsersTab
from Fixtures.user_fixtures import setup_users
from Steps.user_steps import validate_user_list
from Helpers.test_data_helper import read_bulk_users_import_file
# from Helpers.general_helpers import contains_local_address


@pytestrail.case('C33448')
@pytest.mark.pipeline
def test_c33448_ui_validation_of_users_tab_sets_filter(driver_admin, setup_users):
    driver = driver_admin
    Navigate(driver).to_users_tab()

    user_api = setup_users
    all_users = user_api.get_all_users()
    expected_users = UsersTabSteps(driver).convert_user_info_to_match_ui_display(all_users)[1]

    users_tab = UsersTab(driver)
    users_tab.select_interactive_user_set()

    validate_user_list([user for user in expected_users if user['ServiceUser'] is not True], driver)

    users_tab.select_all_users_set()
    validate_user_list(expected_users, driver)
    users_tab.select_active_users_set()
    validate_user_list([user for user in expected_users if user['Status'] == 'Active'], driver)

    users_tab.select_invited_users_set()
    validate_user_list([user for user in expected_users if user['Status'] == 'Invited'], driver)

    users_tab.select_service_users_set()
    validate_user_list([user for user in expected_users if user['ServiceUser'] is True], driver)

    users_tab.select_all_users_set()
    search_for = expected_users[0]
    users_tab.search_for_user(search_for['Username'])
    validate_user_list([search_for], driver)


@pytestrail.case('C33450')
@pytest.mark.pipeline
def test_c33450_user_search_function_on_users_tab_landing_page(driver_admin, app_helpers):
    """ To validate User search function on Users tab landing page"""
    alias = app_helpers['alias']
    user_api = app_helpers['user_helper']
    test_id = app_helpers['test_id']
    
    users = []
    for n in range(2):
        username = f'{test_id}-automation-user-{n}'
        display_name = f"{test_id} Automation {n} {alias}"
        payload = CloudUser(alias, username) \
            .with_password_never_expire(True) \
            .with_password(DEFAULT_PASSWORD) \
            .with_display_name(display_name) \
            .to_payload()
        user_api.create_cloud_user(payload).result()
        users.append(payload)
    users_tab = UsersTab(driver_admin)
    Navigate(driver_admin).to_users_tab()
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(test_id)
    assert len(
        users_tab.get_displayed_users()) == 2, f'Created cloud users with {test_id} are 2, but found {len(users_tab.get_displayed_users())} != 2'
    users_tab.refresh_page()
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(users[0]['Name'])
    assert len(
        users_tab.get_displayed_users()) == 1, f'Expected users with {users[0]["Name"]} is 1, but found {len(users_tab.get_displayed_users())} != 1'


@pytestrail.case('C33446')
@pytest.mark.pipeline
def test_c33446_ui_validation_of_bulk_user_import_function_on_users_tab_landing_page(driver_admin):
    """ To validate 'Bulk User Import' function UI on Users tab landing page  """
    users_tab = UsersTab(driver_admin)
    bulk_user_import_window = BulkUserImportWindow(driver_admin)

    Navigate(driver_admin).to_users_tab()
    users_tab.validate_users_tab_is_loaded()
    users_list = users_tab.get_displayed_users()
    users_tab.open_bulk_user_import_window()

    bulk_user_import_window.validate_all_elements().validate_all_child_elements()
    bulk_user_import_window.click_cancel()

    users_tab.validate_users_tab_is_loaded()
    present_users_list = users_tab.get_displayed_users()

    assert users_list == present_users_list, f'Validation Error, Expected {users_list} == {present_users_list},found {present_users_list} != {users_list}'


@pytestrail.case('C33447')
@pytest.mark.pipeline
def test_c33447_ui_validation_of_invite_users_function_on_users_tab_landing_page(driver_admin, app_helpers):
    """  To validate UI of 'Invite Users' function on Users tab landing page"""
    users_tab = UsersTab(driver_admin)
    select_users_window = SelectUsersWindow(driver_admin)
    tenant_info = app_helpers['tenant_info']

    Navigate(driver_admin).to_users_tab()
    users_tab.validate_users_tab_is_loaded()
    users_list = users_tab.get_displayed_users()
    users_tab.open_invite_user_window()

    select_users_window.is_loaded()
    select_users_window.search_to_invite(tenant_info['username'])
    select_users_window.validate_all_child_elements()
    select_users_window.click_cancel_button()

    users_tab.validate_users_tab_is_loaded()
    present_users_list = users_tab.get_displayed_users()

    assert users_list == present_users_list, f'Validation Error, Expected no users were added, but found{present_users_list} != {users_list}'


# TODO  Get with Jared about this test using the contains_local_address bit, might be more elegant than just skipping
#  if pipeline (as written currently)

@pytestrail.case('C1113')
@pytest.mark.pipeline
# @pytest.mark.skipif(not contains_local_address(os.environ.get("SELENIUM_GRID_ADDRESS")),
#                    reason='Can only run in Selenium Grid is hosted on the same box')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c1113_download_bulk_user_import_template_with_addl_attr(driver_downloads, app_helpers, attribute_helper):
    """ To validate Download Bulk User Import Template with additional attributes """
    driver, download_dir = driver_downloads
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']

    attr_name = f'Test_Attribute_{test_id}'
    attribute_helper.create_additional_attr(attr_name,
                                            type='Text',
                                            description='Test additional attribute',
                                            editable=True)
    file_name = f'bulkImportUsersTemplate.csv'
    users_tab = UsersTab(driver)
    bulk_user_import_window = BulkUserImportWindow(driver)

    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_users_tab()
    users_tab.validate_users_tab_is_loaded()
    users_tab.open_bulk_user_import_window()

    bulk_user_import_window.download_bulk_user_template()
    time.sleep(5)
    lines = read_bulk_users_import_file(file_name, download_dir)

    last_column = lines[0].split(',')[-2].strip()
    assert last_column == attr_name, \
        f'Column headers are not matching, expected {attr_name} , but found {last_column}'
