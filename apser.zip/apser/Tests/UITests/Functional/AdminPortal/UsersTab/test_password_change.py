import pytest
from idaptive_automation.api_payloads import CloudUser
from idaptive_automation.ui_automation import UsersTab, APUserProfileMenu, UserPortalPage, ErrorDialog, SignInPage, \
    UserAddEditWindow
from idaptive_automation.ui_automation.pages.userportal.account_page import UserPortalAccountPage
from idaptive_automation.ui_automation.pages.userportal.change_password_dialog import ChangePasswordDialog
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate, Login


@pytestrail.case('C28039')
@pytest.mark.pipeline
def test_c28039_admin_cannot_save_user_with_invalid_password(driver_admin, app_helpers):
    """ Admin cannot save user with invalid password and validate invalid password error message """
    test_id = app_helpers['test_id']

    Navigate(driver_admin).to_users_tab()

    users_tab = UsersTab(driver_admin)
    detail_window = users_tab.open_add_user_window()

    name = f'{test_id}test-user'
    email = f'test@test.test'

    detail_window.set_login(name)
    detail_window.set_email(email)
    detail_window.set_display_name(name)
    detail_window.set_password('a')
    detail_window.set_confirm_password('a')
    error_dialog = detail_window.press_create_user_button_with_error()

    error_message = error_dialog.get_error_message()
    expected_error = f'Password does not meet policy requirements: Must be at least 8 characters long, not be longer than 64 characters, contain at least one digit, contain at least one upper and one lower case letter.'
    assert error_message == expected_error, f'Error dialog not displayed, found {error_message}, expected {expected_error}'


@pytestrail.case('C28042')
@pytest.mark.pipeline
def test_c28042_cloud_user_can_change_password_to_new_valid_password(driver_admin, new_cloud_user_in_test_role_fixture):
    """ Cloud User can change password to new valid password and validate Success toaster message """
    Navigate(driver_admin).to_users_tab()

    username = new_cloud_user_in_test_role_fixture['Name']
    password = new_cloud_user_in_test_role_fixture['Password']
    new_password = 'TESTtest1234'
    confirm_password = 'TESTtest1234'

    #TODO Fix this XPATH
    APUserProfileMenu(driver_admin).sign_out()
    Login(driver_admin).to_user_portal(username, password)
    UserPortalPage(driver_admin).wait_for_page_to_load()
    UserPortalPage(driver_admin).click_account_tab()
    UserPortalAccountPage(driver_admin).click_password_edit_button()

    ChangePasswordDialog(driver_admin).wait_for_page_to_load()
    ChangePasswordDialog(driver_admin).set_current_password(password)
    ChangePasswordDialog(driver_admin).set_new_password(new_password)
    ChangePasswordDialog(driver_admin).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver_admin).click_ok_button()

    UserPortalPage(driver_admin).wait_for_page_to_load()

    assert UserPortalAccountPage(driver_admin).validate_success_toaster() is True, f'Unable to change password successfully, expected Change password successfully'


@pytestrail.case('C28043')
@pytest.mark.pipeline
def test_c28043_cloud_user_cannot_change_password_to_invalid_password(driver_admin, new_cloud_user_in_test_role_fixture):
    """ Cloud User cannot change password to invalid password and validate invalid password error message """
    Navigate(driver_admin).to_users_tab()

    username = new_cloud_user_in_test_role_fixture['Name']
    password = new_cloud_user_in_test_role_fixture['Password']
    new_password = 'a'
    confirm_password = 'a'

    APUserProfileMenu(driver_admin).sign_out()
    Login(driver_admin).to_user_portal(username, password)
    UserPortalPage(driver_admin).wait_for_page_to_load()
    UserPortalPage(driver_admin).click_account_tab()
    UserPortalAccountPage(driver_admin).click_password_edit_button()

    ChangePasswordDialog(driver_admin).wait_for_page_to_load()
    ChangePasswordDialog(driver_admin).set_current_password(password)
    ChangePasswordDialog(driver_admin).set_new_password(new_password)
    ChangePasswordDialog(driver_admin).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver_admin).click_ok_button()

    error_message = ErrorDialog(driver_admin).get_error_message()
    expected_error = f'Password update failed. Please make sure the password meet the complexity requirements. Password must be at least 8 characters long, not be longer than 64 characters, contain at least one digit, contain at least one upper and one lower case letter'
    assert error_message == expected_error, f'Error dialog not displayed, found {error_message}, expected {expected_error}'


@pytestrail.case('C28035')
@pytest.mark.pipeline
def test_c28035_password_cannot_be_repeated_when_equal_to_the_history_limit(driver, app_helpers):
    """ Password cannot be repeated when equal to the history limit and validate error message """
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    policy_api = app_helpers['policy_helper']
    alias = app_helpers['alias']
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']
    
    policy = {
        "/Core/Security/CDS/PasswordPolicy/History": '3'
    }

    role_id = role_api.create_role_if_not_exists(f'{test_id} Allow user security policy role')
    policy_api.create_policy(f'Automated test policy - {test_id} Allow user security ',
                             policy, link_type='Role', params=[role_id])

    email_address = 'tes@test.test'
    payload = CloudUser(alias, 'Allow-User--Security-policy_user').with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_api.create_cloud_user(payload)
    user_id = payload['Uuid'] = response.result()
    role_api.add_users_to_role(role_id, [user_id])
    role_api.add_users_to_automation_role([user_id])

    new_password = 'TESTtest1234'
    confirm_password = 'TESTtest1234'

    Login(driver, tenant_info['base_url']) \
        .to_user_portal(payload['Name'], payload['Password'])

    UserPortalPage(driver).wait_for_page_to_load()
    #TODO fix XPATH
    UserPortalPage(driver).click_account_tab()
    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(payload['Password'])
    ChangePasswordDialog(driver).set_new_password(new_password)
    ChangePasswordDialog(driver).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver).click_ok_button()

    UserPortalPage(driver).wait_for_page_to_load()
    assert UserPortalAccountPage(driver).validate_success_toaster() is True, \
        f'Unable to change password successfully, expected Change password successfully'

    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(new_password)
    ChangePasswordDialog(driver).set_new_password(payload['Password'])
    ChangePasswordDialog(driver).set_confirm_password(payload['Password'])
    ChangePasswordDialog(driver).click_ok_button()

    error_message = ErrorDialog(driver).get_error_message()
    expected_error = f'Password update failed. Please make sure the new password is not one of last 3 passwords.'
    assert error_message == expected_error, f'Error dialog not displayed, found {error_message}, expected {expected_error}'


@pytestrail.case('C28036')
@pytest.mark.pipeline
def test_c28036_password_can_be_repeated_when_equal_to_the_history_limit_1(app_helpers, driver):
    """ Password can be repeated when equal to the history limit +1 and validate success toaster message """
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    policy_api = app_helpers['policy_helper']
    alias = app_helpers['alias']
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']

    policy = {
        "/Core/Security/CDS/PasswordPolicy/History": '0'
    }

    role_id = role_api.create_role_if_not_exists(f'{test_id} Allow user security policy role')
    policy_api.create_policy(f'Automated test policy - {test_id} Allow user security ',
                             policy, link_type='Role', params=[role_id])

    email_address = 'test@test.test'
    payload = CloudUser(alias, 'Allow-User--Security-policy_user').with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_api.create_cloud_user(payload)
    user_id = payload['Uuid'] = response.result()
    role_api.add_users_to_role(role_id, [user_id])
    role_api.add_users_to_automation_role([user_id])

    new_password = 'TESTtest1234'
    confirm_password = 'TESTtest1234'

    Login(driver, tenant_info['base_url']) \
        .to_user_portal(payload['Name'], payload['Password'])

    UserPortalPage(driver).wait_for_page_to_load()
    #TODO fix XPATH
    UserPortalPage(driver).click_account_tab()
    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(payload['Password'])
    ChangePasswordDialog(driver).set_new_password(new_password)
    ChangePasswordDialog(driver).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver).click_ok_button()

    UserPortalPage(driver).wait_for_page_to_load()
    assert UserPortalAccountPage(driver).validate_success_toaster() is True, \
        f'Unable to change password successfully, expected Change password successfully'

    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(new_password)
    ChangePasswordDialog(driver).set_new_password(payload['Password'])
    ChangePasswordDialog(driver).set_confirm_password(payload['Password'])
    ChangePasswordDialog(driver).click_ok_button()

    UserPortalAccountPage(driver).wait_for_page_to_load()
    assert UserPortalAccountPage(driver).validate_success_toaster() is True, \
        f'Unable to change password successfully, expected Change password successfully'


@pytestrail.case('C28044')
@pytest.mark.pipeline
def test_c28044_account_is_locked_after_max_login_attempts_reached(app_helpers, driver, driver_admin):
    """ Account is locked after max login attempts reached and validate locked checkbox"""
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    policy_api = app_helpers['policy_helper']
    alias = app_helpers['alias']
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']

    policy = {
        "/Core/Security/CDS/LockoutPolicy/Threshold": 2,
        "/Core/Security/CDS/LockoutPolicy/Duration": 5
    }

    role_id = role_api.create_role_if_not_exists(f'{test_id} PW Lockout role')
    policy_api.create_policy(f'Automated test policy - {test_id} PW Lockout policy ',
                             policy, link_type='Role', params=[role_id])

    email_address = 'test@test.test'
    payload = CloudUser(alias, 'Allow-PW_Lockout_user').with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_api.create_cloud_user(payload)
    user_id = payload['Uuid'] = response.result()
    role_api.add_users_to_role(role_id, [user_id])
    role_api.add_users_to_automation_role([user_id])

    invalid_password = 'TESTtest1234'
    Login(driver, tenant_info['base_url']).login_with_wrong_password(payload['Name'], invalid_password)
    SignInPage(driver).login_after_change_password(invalid_password)

    Navigate(driver_admin).to_users_tab()
    UsersTab(driver_admin).validate_users_tab_is_loaded()
    UsersTab(driver_admin).search_for_user(payload['Name'])
    UsersTab(driver_admin).open_user_detail_window_for_user(payload['Name'])

    expected_text = 'Suspended'
    actual_text = UserAddEditWindow(driver_admin).get_user_display_status()
    assert actual_text == expected_text, f'User status is incorrect, found {actual_text} expected {expected_text}'

    assert UserAddEditWindow(driver_admin).validate_locked_checked() is True, f'Locked checkbox is unchecked, found Checked'