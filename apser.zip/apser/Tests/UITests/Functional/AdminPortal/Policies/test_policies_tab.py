import pytest
from idaptive_automation.ui_automation import AdminPagePoliciesTab, PolicyDetailLandingPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate
from Steps.admin_policies_tab_steps import AdminPoliciesTabSteps
from idaptive_automation.api_helpers import UserApi
from idaptive_automation.ui_automation.pages.policydetails.authentication_policies.local_account_linking_page import \
LocalAccountLinkingPage
from Helpers.test_data_helper import load_json_test_data_file
from Steps.policy_steps import policy_in_policy_list


@pytestrail.case('C28097')
@pytest.mark.pipeline
def test_c28097_add_policy_set_happy_path(app_helpers):
    policy_api = app_helpers['policy_helper']
    test_id = app_helpers['test_id']

    policy_name = f"test_policy_{test_id}"
    policy_api.create_policy(policy_name, {})

    all_policies = policy_api.get_admin_policy_list()

    assert policy_in_policy_list(policy_name, all_policies)


@pytestrail.case('C28103')
@pytest.mark.pipeline
def test_c28103_cant_add_policy_with_duplicate_name(driver_admin, app_helpers):
    policy_api = app_helpers['policy_helper']
    existing_policies = policy_api.get_admin_policy_list()
    Navigate(driver_admin).to_policies_tab()

    AdminPoliciesTabSteps(driver_admin).open_add_policy_window() \
        .set_policy_name(existing_policies[0]['Name']) \
        .try_save_changes() \
        .discard_changes()

    new_policies = policy_api.get_admin_policy_list()
    assert new_policies == existing_policies


@pytestrail.case('C28151')
@pytest.mark.pipeline
def test_c28151_policy_can_be_created_without_specifying_a_role(driver_admin, app_helpers):
    """ To validate the Policy that applies to roles can be created without specifying a role  """
    policy_api = app_helpers['policy_helper']
    admin_steps = AdminPoliciesTabSteps(driver_admin)
    Navigate(driver_admin).to_policies_tab()
    policy = admin_steps.open_add_policy_window().save_changes_with_specified_roles()[1]

    new_policies = admin_steps.wait_for_policies_tab_loaded().refresh_page() \
        .get_displayed_policies()[1]

    expected_policies = policy_api.get_admin_policy_list()

    assert expected_policies == new_policies
    assert policy in new_policies


@pytestrail.case('C76629')
@pytest.mark.pipeline
def test_c76629_check_ui_when_map_local_directory_services_is_set_to_required(driver_admin):
    """ check ui when map local directory services is set to required"""

    navigate = Navigate(driver_admin)
    admin_page_policies_tab = AdminPagePoliciesTab(driver_admin)

    policy_detail_landing_page = PolicyDetailLandingPage(driver_admin)
    local_account_linking_page = LocalAccountLinkingPage(driver_admin)

    navigate.to_policies_tab()
    admin_page_policies_tab.open_add_policy_window()

    policy_detail_landing_page.click_authentication_policies_tab()
    local_account_linking_page.click_local_account_linking()

    local_account_linking_page.set_map_local_directory_services('Required')
    local_account_linking_page.validate_all_child_elements()


@pytestrail.case('C76627')
@pytest.mark.pipeline
def test_c76627_when_map_local_directory_services_is_set_to_disabled(driver_admin):
    """ check ui when map local directory services is set to disabled """

    navigate = Navigate(driver_admin)
    admin_page_policies_tab = AdminPagePoliciesTab(driver_admin)

    policy_detail_landing_page = PolicyDetailLandingPage(driver_admin)
    local_account_linking_page = LocalAccountLinkingPage(driver_admin)

    navigate.to_policies_tab()
    admin_page_policies_tab.open_add_policy_window()

    policy_detail_landing_page.click_authentication_policies_tab()
    local_account_linking_page.click_local_account_linking()

    local_account_linking_page.set_map_local_directory_services('Required')
    local_account_linking_page.validate_all_child_elements()

    local_account_linking_page.set_map_local_directory_services('Optional')
    local_account_linking_page.validate_all_child_elements()

    local_account_linking_page.set_map_local_directory_services('Disabled')
    local_account_linking_page.validate_all_child_elements()

    local_account_linking_page.click_save_button()
    admin_page_policies_tab.wait_for_page_to_load()


@pytestrail.case('C76626')
@pytest.mark.pipeline
def test_c76626_check_ui_dropdown_local_dir_service(driver_admin):
    """ Check UI dropdown for Map local directory services field """
    navigate = Navigate(driver_admin)
    admin_page_policies_tab = AdminPagePoliciesTab(driver_admin)
    policy_detail_landing_page = PolicyDetailLandingPage(driver_admin)
    local_account_linking_page = LocalAccountLinkingPage(driver_admin)
    navigate.to_policies_tab()
    admin_page_policies_tab.open_add_policy_window()
    policy_detail_landing_page.click_authentication_policies_tab()
    local_account_linking_page.click_local_account_linking()
    result = local_account_linking_page.get_map_local_ds_default_value()
    assert result == "--", f"Expected default value of '--', got {result}"
    result = local_account_linking_page.get_all_available_values_for_map_local_ds()
    expected_results = ['--', 'Required', 'Optional', 'Disabled']
    assert result.__len__() == 4, f'Expected four options, returned {result}'
    assert result == expected_results, f'Options returned: {result}'


@pytestrail.case('C76628')
@pytest.mark.pipeline
def test_c76628_check_ui_local_directory_services_optional(driver_admin, app_helpers):
    """ Check UI when Map local directory services is set to Optional """
    cloud_session = app_helpers['cloud_session']
    directories = UserApi(cloud_session).get_directory_services_info()
    directory_names = []
    for row in directories:
        disp_name = row['DisplayNameShort']
        directory_names.append(disp_name)
    directory_names.remove('FDS')
    navigate = Navigate(driver_admin)
    admin_page_policies_tab = AdminPagePoliciesTab(driver_admin)
    policy_detail_landing_page = PolicyDetailLandingPage(driver_admin)
    local_account_linking_page = LocalAccountLinkingPage(driver_admin)
    navigate.to_policies_tab()
    admin_page_policies_tab.open_add_policy_window()
    policy_detail_landing_page.click_authentication_policies_tab()
    local_account_linking_page.click_local_account_linking()
    local_account_linking_page.set_map_local_directory_services('Optional')
    result_source = local_account_linking_page.get_all_available_values_for_source_directory()
    assert result_source == directory_names, f"Dropdown {result_source}, does not match {directory_names}"
    result_target = local_account_linking_page.get_all_available_values_for_target_directory()
    assert result_target == directory_names, f"Dropdown {result_target}, does not match {directory_names}"
    expected_mapping = ["Name", "Email"]
    result_mapping = local_account_linking_page.get_all_values_for_dir_user_mapping()
    assert result_mapping == expected_mapping, f"Expected {expected_mapping}, got {result_mapping}"
    result_default = local_account_linking_page.get_dir_user_mapping_default_value()
    assert result_default == "Name", f"Expected default to 'Name', got {result_default}"


@pytestrail.case('C76630')
@pytest.mark.pipeline
def test_c76630_check_ui_local_directory_services_required(driver_admin, app_helpers):
    """ Check UI matches API when Map local directory services is set to Required """
    directories = UserApi(app_helpers['cloud_session']).get_directory_services_info()
    directory_names = []
    for row in directories:
        disp_name = row['DisplayNameShort']
        directory_names.append(disp_name)
    directory_names.remove('FDS')
    navigate = Navigate(driver_admin)
    admin_page_policies_tab = AdminPagePoliciesTab(driver_admin)
    policy_detail_landing_page = PolicyDetailLandingPage(driver_admin)
    local_account_linking_page = LocalAccountLinkingPage(driver_admin)
    navigate.to_policies_tab()
    admin_page_policies_tab.open_add_policy_window()
    policy_detail_landing_page.click_authentication_policies_tab()
    local_account_linking_page.click_local_account_linking()
    local_account_linking_page.set_map_local_directory_services('Required')
    result_source = local_account_linking_page.get_all_available_values_for_source_directory()
    assert result_source == directory_names, f"Dropdown {result_source}, does not match {directory_names}"
    result_target = local_account_linking_page.get_all_available_values_for_target_directory()
    assert result_target == directory_names, f"Dropdown {result_target}, does not match {directory_names}"



