import pytest
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_unsaved_changes_dialog import \
    RolesUnsavedChangesDialog
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import RolesTabPage, RolesAddEditWindow
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.add_members_dialog import AddMembersDialog
from idaptive_automation.ui_automation import UsersTab, UAERolesTabPage, UserAddEditWindow
from Steps.navigate_steps import Navigate
from Fixtures.role_fixtures import auto_cleanup_role_fixture


@pytestrail.case('C28078')
@pytest.mark.pipeline
def test_c28078_add_role_via_ap(driver_admin, app_helpers, auto_cleanup_role_fixture):
    """ To validate Adding Role in AP   """
    Navigate(driver_admin).to_roles_tab()
    add_role_window = RolesTabPage(driver_admin).open_add_role_window()

    role_name = f'Test role {app_helpers["test_id"]}'
    add_role_window.set_role_name(role_name)
    add_role_window.press_save_button()

    RolesTabPage(driver_admin).wait_for_page_to_load()

    assert RolesTabPage(driver_admin).validate_toaster_msg() == 'Add role succeeded.', \
        f'Message incorrect, expected "Add role succeeded.", but found {add_role_window.validate_toaster_msg()}'

    RolesTabPage(driver_admin).search_for_role(role_name)

    assert len(RolesTabPage(driver_admin).get_displayed_roles()) == 1, \
        f'Incorrect value: Expected 1, found {len(RolesTabPage(driver_admin).get_displayed_roles())} '


@pytestrail.case('C93723')
@pytest.mark.pipeline
def test_c93723_cancel_adding_role_via_ap(driver_admin, app_helpers, auto_cleanup_role_fixture):
    """ To validate cancel adding role via AP   """
    Navigate(driver_admin).to_roles_tab()

    add_role_window = RolesTabPage(driver_admin).open_add_role_window()
    role_name = f'Test role {app_helpers["test_id"]}'

    add_role_window.set_role_name(role_name)
    add_role_window.press_cancel_button()

    unsaved_changes_dialog = RolesUnsavedChangesDialog(driver_admin)
    unsaved_changes_dialog.wait_for_page_to_load()
    unsaved_changes_dialog.press_cancel()

    add_role_window.wait_for_page_to_load()
    add_role_window.press_cancel_button()

    unsaved_changes_dialog.wait_for_page_to_load()
    unsaved_changes_dialog.press_no()

    RolesTabPage(driver_admin).wait_for_page_to_load()
    RolesTabPage(driver_admin).search_for_role(role_name)

    assert RolesTabPage(driver_admin).get_displayed_roles() is None, f'Incorrect value: Expected None,found {RolesTabPage(driver_admin).get_displayed_roles()} '


@pytestrail.case('C28058')
@pytest.mark.pipeline
def test_c28058_add_cloud_member_to_role_in_ap_happy_path(driver_admin, cloud_user, app_helpers,
                                                          auto_cleanup_role_fixture):
    """ To validate adding Cloud member to a Role in AP """
    user = cloud_user
    Navigate(driver_admin).to_roles_tab()
    add_members_dialog = AddMembersDialog(driver_admin)
    role_name = f"test_role_{app_helpers['test_id']}"

    add_role_dialog = RolesTabPage(driver_admin).open_add_role_window()
    add_role_dialog.set_role_name(role_name)
    add_role_dialog.select_members_tab()
    add_role_dialog.open_add_members_window()

    add_members_dialog.wait_for_page_to_load()
    add_members_dialog.search_for_user(user['Name'])
    add_members_dialog.select_user_checkbox()
    add_members_dialog.press_add_button()

    add_role_dialog.press_save_button()

    Navigate(driver_admin).to_users_tab()

    users_tab_page = UsersTab(driver_admin)
    users_tab_page.search_for_user(user['Name'])
    users_tab_page.open_user_detail_window_for_user(user['Name'])

    users_add_edit_window = UserAddEditWindow(driver_admin)
    users_add_edit_window.click_roles_tab()

    displayed_roles = UAERolesTabPage(driver_admin).get_roles_names()
    assert role_name in displayed_roles, \
        f'Test role is not found in  {displayed_roles}'


@pytestrail.case('C28059')
@pytest.mark.pipeline
def test_c28059_remove_cloud_user_from_role_in_ap_happy_path(driver_admin, new_cloud_user_in_test_role_fixture):
    """ To validate Removing Cloud user from a Role in AP """
    user = new_cloud_user_in_test_role_fixture
    Navigate(driver_admin).to_roles_tab()
    roles_page = RolesTabPage(driver_admin)
    roles_page.wait_for_page_to_load()
    roles_page.open_role_detail_window_for_role(user['role_name'])
    roles_add_edit_window = RolesAddEditWindow(driver_admin)
    roles_add_edit_window.wait_for_page_to_load()
    roles_add_edit_window.select_members_tab()
    roles_add_edit_window.select_checkbox_for_user(user['Name'])
    roles_add_edit_window.open_actions_menu()
    roles_add_edit_window.click_delete()
    roles_add_edit_window.press_save_button()

    Navigate(driver_admin).to_users_tab()
    users_tab_page = UsersTab(driver_admin)
    users_tab_page.search_for_user(user['Name'])
    users_tab_page.open_user_detail_window_for_user(user['Name'])
    users_add_edit_window = UserAddEditWindow(driver_admin)
    users_add_edit_window.click_roles_tab()
    assert user['Name'] not in UAERolesTabPage(driver_admin).get_displayed_role_rows()