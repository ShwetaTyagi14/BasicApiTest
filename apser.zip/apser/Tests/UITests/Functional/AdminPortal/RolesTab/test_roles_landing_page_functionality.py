import pytest
from idaptive_automation.ui_automation.pages.adminportal.RolesTab.roles_delete_dialog import RolesDeleteDialog
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import RolesTabPage
from Steps.navigate_steps import Navigate


@pytestrail.case('C28077')
@pytest.mark.pipeline
def test_c28077_delete_role_in_ap_happy_path(driver_admin, app_helpers):
    """ To validate Role Deletion in AP """
    role_api = app_helpers['role_helper']
    role_name = f'Test role {app_helpers["test_id"]}'
    role_id = role_api.create_role(role_name)
    Navigate(driver_admin).to_roles_tab()

    roles_page = RolesTabPage(driver_admin)
    roles_page.wait_for_page_to_load()
    roles_page.search_for_role(role_name)
    roles_page.select_role_checkbox(role_name)
    roles_page.open_actions_menu()
    roles_page.click_delete()

    roles_delete_dialog = RolesDeleteDialog(driver_admin)
    roles_delete_dialog.validate_all_child_elements()

    expected_message = 'You are about to delete 1 role. Are you sure you want to continue?'
    actual_message = roles_delete_dialog.get_delete_dialog_text()
    assert actual_message == expected_message, f'Message incorrect, expected {expected_message}, found {actual_message}'

    assert roles_delete_dialog.is_yes_enabled() is True, 'Yes button is disabled, expected enabled'

    assert roles_delete_dialog.is_no_enabled() is True, 'No button is disabled, expected enabled'

    roles_delete_dialog.press_yes()

    assert roles_page.validate_toaster_msg() == 'Completed Delete on 1 role.', f'Toaster for successful deletion should be displayed, but not displayed'
    app_helpers['role_helper'].roles_created.remove(role_id)
    roles_page.is_loaded()
    assert roles_page.get_displayed_roles() is None, f"{role_name} is displayed and is not deleted"

    driver_admin.refresh()

    roles_page.wait_for_page_to_load(20)
    roles_page.search_for_role(role_name)
    assert roles_page.get_displayed_roles() is None, f"{role_name} is displayed after refreshing page and is not deleted"


@pytestrail.case('C87849')
@pytest.mark.pipeline
def test_c87849_cancel_deleting_role_in_ap_happy_path(driver_admin,
                                                      test_role_fixture):
    """ To validate Cancel on deleting a Role in AP """

    role = test_role_fixture
    Navigate(driver_admin).to_roles_tab().wait_for_page_to_load()

    roles_page = RolesTabPage(driver_admin)
    roles_page.search_for_role(role['name'])
    roles_page.select_role_checkbox(role['name'])
    roles_page.open_actions_menu()
    roles_page.click_delete()

    roles_delete_dialog = RolesDeleteDialog(driver_admin)
    roles_delete_dialog.wait_for_page_to_load()
    roles_delete_dialog.validate_all_elements().validate_all_child_elements()

    expected_message = 'You are about to delete 1 role. Are you sure you want to continue?'
    actual_message = roles_delete_dialog.get_delete_dialog_text()
    assert actual_message == expected_message, f'Text from Delete Dialog is incorrect, expected {expected_message} , but found {actual_message}'

    roles_delete_dialog.press_no()

    roles_page.wait_for_page_to_load()

    assert len(roles_page.get_displayed_roles()) == 1
    assert roles_page.is_role_checked(role['name']) is True, f'Checkbox is not selected or checked'


@pytestrail.case('C87853')
@pytest.mark.pipeline
def test_c87853_cannot_delete_everybody_role_in_ap(driver_admin):
    """ To validate cannot Delete Role for Everybody Role in AP """
    Navigate(driver_admin).to_roles_tab()

    RolesTabPage(driver_admin).wait_for_page_to_load()
    roles_page = RolesTabPage(driver_admin)
    roles_page.search_for_role(role_name='Everybody')
    roles_page.select_role_checkbox(role_name='Everybody')
    roles_page.open_actions_menu()

    expected_text = 'No actions available.'
    actual_text = roles_page.get_no_actions_available_text()
    assert actual_text == expected_text, f'Message displayed is incorrect, expected {expected_text}, found {actual_text}'


@pytestrail.case('C28055')
@pytest.mark.pipeline
def test_c28055_role_name_starts_with_query_returns_correct_results(driver_admin, test_role_fixture):
    """ To validate Role name 'starts with' query returns correct results """
    role = test_role_fixture
    Navigate(driver_admin).to_roles_tab()
    roles_page = RolesTabPage(driver_admin)
    roles_page.wait_for_page_to_load()
    roles_page.search_for_role(role['name'][0:5])
    assert len(roles_page.get_displayed_roles()) == 1, f'Role not exists, found {len(roles_page.get_displayed_roles())}'


@pytestrail.case('C28075')
@pytest.mark.pipeline
def test_c28075_search_box_on_roles_tab_works_single_role_search(driver_admin, test_role_fixture):
    """ To validate Search box on Roles tab works - single role search """
    role1 = test_role_fixture
    role2 = test_role_fixture
    Navigate(driver_admin).to_roles_tab()
    roles_page = RolesTabPage(driver_admin)
    roles_page.wait_for_page_to_load()
    roles_page.search_for_role(role1['name'][1:6])
    assert len(roles_page.get_displayed_roles()) >= 1, f'Role not exists, found {len(roles_page.get_displayed_roles())}'
