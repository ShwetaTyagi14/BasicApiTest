import pytest
from idaptive_automation.ui_automation import ConfirmDeleteWindow
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.CorporateIpRange.add_modify_ip_range_dialog import \
    AddModifyIpRangeDialog
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.CorporateIpRange.corporate_ip_range_tab_landing_page import \
    CorporateIpRangePage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_network_page import SettingsNetworkPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate
from Helpers.general_helpers import random_alpha
from Fixtures.tenant_fixtures import auto_cleanup_corporate_ip_fixture


@pytestrail.case('C76664')
@pytest.mark.pipeline
def test_c76664_check_labeling_name_of_corp_ip_range_ui(driver_admin, auto_cleanup_corporate_ip_fixture):
    """ Check labeling name of Corp IP Range UI and Validating without and with the name """
    name = f"Apps - {random_alpha(length=10)}"
    name_two = f"Apps - {random_alpha(length=10)}"
    ip_range = "207.140.26.26"
    ip_range_two = "26.26.240.207"

    Navigate(driver_admin).to_settings_network_tab()

    SettingsNetworkPage(driver_admin).click_corporate_ip_range()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    CorporateIpRangePage(driver_admin).press_add_button()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_address(ip_range)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    assert CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range) in (' ', None), f'ip-range name is existed , found ip-range name is empty'

    CorporateIpRangePage(driver_admin).press_add_button()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_name(name_two)
    AddModifyIpRangeDialog(driver_admin).set_ip_range_address(ip_range_two)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    assert CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range_two) == name_two, f'Incorrect name, expected {name_two},' \
        f'found {CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range_two)}' \

    CorporateIpRangePage(driver_admin).select_ip_range_checkbox(ip_range)
    CorporateIpRangePage(driver_admin).open_actions_menu()
    CorporateIpRangePage(driver_admin).click_delete()

    ConfirmDeleteWindow(driver_admin).press_yes()


@pytestrail.case('C76665')
@pytest.mark.pipeline
def test_c76665_modify_labeling_name_of_corp_ip_range(driver_admin, auto_cleanup_corporate_ip_fixture):
    """ Modify labeling name of Corp IP Range Validating without and with the name """
    name = f"Apps - {random_alpha(length=10)}"
    ip_range = "207.140.26.25"
    new_ip_range = "126.255.255.254"

    Navigate(driver_admin).to_settings_network_tab()

    SettingsNetworkPage(driver_admin).click_corporate_ip_range()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    CorporateIpRangePage(driver_admin).press_add_button()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_address(ip_range)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    CorporateIpRangePage(driver_admin).select_ip_range_checkbox(ip_range)
    CorporateIpRangePage(driver_admin).open_actions_menu()
    CorporateIpRangePage(driver_admin).click_modify()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_address(new_ip_range)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    assert CorporateIpRangePage(driver_admin).get_ip_ranges_name(new_ip_range) in (' ', None), f'ip-range name is existed , found ip-range name is empty'

    assert CorporateIpRangePage(driver_admin).get_ip_ranges_address(new_ip_range) == new_ip_range, f'ip range not modified,' \
        f'found {CorporateIpRangePage(driver_admin).get_ip_ranges_address(new_ip_range)}, expected {new_ip_range}'

    CorporateIpRangePage(driver_admin).select_ip_range_checkbox(new_ip_range)
    CorporateIpRangePage(driver_admin).open_actions_menu()
    CorporateIpRangePage(driver_admin).click_modify()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_name(name)
    AddModifyIpRangeDialog(driver_admin).set_ip_range_address(ip_range)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()

    assert CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range) == name, f'Incorrect name, expected {name},' \
        f'found {CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range)}' \

    assert CorporateIpRangePage(driver_admin).get_ip_ranges_address(ip_range) == ip_range, f'ip range not modified,' \
        f'expected {ip_range}, found {CorporateIpRangePage(driver_admin).get_ip_ranges_address(ip_range)}'

    CorporateIpRangePage(driver_admin).select_ip_range_checkbox(ip_range)
    CorporateIpRangePage(driver_admin).open_actions_menu()
    CorporateIpRangePage(driver_admin).click_delete()

    ConfirmDeleteWindow(driver_admin).press_yes()


@pytestrail.case('C76666')
@pytest.mark.pipeline
def test_c76666_check_the_format_of_the_labeling_name(driver_admin, auto_cleanup_corporate_ip_fixture):
    """ Check and validating the format of the labeling name """
    name = f"Apps - {random_alpha(length=10)}"
    name_special_char = "Apps@"
    name_special_chars = "Apps&#<"
    ip_range = "207.140.26.24"

    Navigate(driver_admin).to_settings_network_tab()

    SettingsNetworkPage(driver_admin).click_corporate_ip_range()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()
    CorporateIpRangePage(driver_admin).press_add_button()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_name(name)
    AddModifyIpRangeDialog(driver_admin).set_ip_range_address(ip_range)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()

    CorporateIpRangePage(driver_admin).wait_for_page_to_load()

    assert CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range) == name, f'Incorrect name, expected {name},' \
        f'found {CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range)}' \

    CorporateIpRangePage(driver_admin).select_ip_range_checkbox(ip_range)
    CorporateIpRangePage(driver_admin).open_actions_menu()
    CorporateIpRangePage(driver_admin).click_modify()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_name(name_special_char)
    AddModifyIpRangeDialog(driver_admin).press_ok_button()
    CorporateIpRangePage(driver_admin).wait_for_page_to_load()

    assert CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range) == name_special_char, f'Incorrect name, expected {name_special_char},' \
        f'found {CorporateIpRangePage(driver_admin).get_ip_ranges_name(ip_range)}' \

    CorporateIpRangePage(driver_admin).select_ip_range_checkbox(ip_range)
    CorporateIpRangePage(driver_admin).open_actions_menu()
    CorporateIpRangePage(driver_admin).click_modify()

    AddModifyIpRangeDialog(driver_admin).set_ip_range_name(name_special_chars)

    assert AddModifyIpRangeDialog(driver_admin).is_confirm_error_icon_displayed() is True, f'can save changes, found cannot save changes'

    AddModifyIpRangeDialog(driver_admin).set_name_as_balnk_space()

    assert AddModifyIpRangeDialog(driver_admin).is_confirm_error_icon_displayed() is True, f'can save changes, found cannot save changes'
