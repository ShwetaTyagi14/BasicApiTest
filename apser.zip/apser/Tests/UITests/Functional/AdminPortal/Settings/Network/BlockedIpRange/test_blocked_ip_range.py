import pytest
from idaptive_automation.ui_automation import ConfirmDeleteWindow
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.BlockedIpRanges.add_modify_blocked_ip_range_dialog import \
    AddModifyBlockedIpRangeDialog
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.BlockedIpRanges.blocked_ip_range_tab_landing_page import \
    BlockedIpRangesPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_network_page import SettingsNetworkPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate
from Fixtures.tenant_fixtures import auto_cleanup_blocked_ip_fixture


@pytestrail.case('C45439')
@pytest.mark.pipeline
def test_c45439_check_functionality_of_blocked_ip_range_edit_feature(driver_admin, auto_cleanup_blocked_ip_fixture):
    """ Check functionality of Blocked IP Range Edit feature and validate Ip range name modified successfully """
    name = "Apps"
    name_special_char = "Apps@"
    ip_range = "192.168.26.26"
    Navigate(driver_admin).to_settings_network_tab()

    SettingsNetworkPage(driver_admin).click_blocked_ip_ranges()
    BlockedIpRangesPage(driver_admin).press_add_button()
    AddModifyBlockedIpRangeDialog(driver_admin).set_ip_range_name(name)
    AddModifyBlockedIpRangeDialog(driver_admin).set_ip_range_address(ip_range)
    AddModifyBlockedIpRangeDialog(driver_admin).press_ok_button()

    BlockedIpRangesPage(driver_admin).select_ip_range_checkbox(ip_range)
    BlockedIpRangesPage(driver_admin).open_actions_menu()

    BlockedIpRangesPage(driver_admin).click_modify()

    AddModifyBlockedIpRangeDialog(driver_admin).set_ip_range_name(name_special_char)
    AddModifyBlockedIpRangeDialog(driver_admin).press_ok_button()
    BlockedIpRangesPage(driver_admin).wait_for_page_to_load()

    assert BlockedIpRangesPage(driver_admin).get_ip_ranges_name(
        ip_range) == name_special_char, f'Incorrect name, expected {name_special_char},' \
                                        f'found {BlockedIpRangesPage(driver_admin).get_ip_ranges_name(ip_range)}' \

    BlockedIpRangesPage(driver_admin).select_ip_range_checkbox(ip_range)
    BlockedIpRangesPage(driver_admin).open_actions_menu()
    BlockedIpRangesPage(driver_admin).click_delete()

    ConfirmDeleteWindow(driver_admin).press_yes()