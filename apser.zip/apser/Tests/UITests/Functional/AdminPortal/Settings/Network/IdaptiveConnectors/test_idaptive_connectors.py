import pytest
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.IdaptiveConnectors.add_idaptive_connector_dialog import \
AddIdaptiveConnectorDialog
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_network_page import SettingsNetworkPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate


@pytestrail.case('C45589')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c45589_download_connector_from_network_page(driver_admin):
    """ Check download connector from network page """
    Navigate(driver_admin).to_settings_network_tab()
    SettingsNetworkPage(driver_admin).press_add_button()
    assert AddIdaptiveConnectorDialog(driver_admin).is_confirm_download_link_displayed() is True, \
        f'download link not displayed , but download link found'
