import pytest
from idaptive_automation.ui_automation import UserPortalPage, SignInPage
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import api_session_fixture as api_session, mongo_session_client as mongo_dal
from idaptive_automation.fixtures import authenticated_api_session_fixture as session_fixture
from idaptive_automation.api_helpers import AboutHelper
from Steps.navigate_steps import Login


@pytestrail.case('C76663')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c76663_login_to_tenant_via_pod_url_happy_path(driver, app_helpers):
    about_info = AboutHelper(app_helpers['cloud_session']).get_about_info()
    tenant_info = app_helpers['tenant_info']
    Login(driver, f"https://{about_info['PodFqdn']}").to_user_portal_without_navigation(tenant_info['username'],
                                                                                        tenant_info['password'])
    UserPortalPage(driver).wait_for_page_to_load()
