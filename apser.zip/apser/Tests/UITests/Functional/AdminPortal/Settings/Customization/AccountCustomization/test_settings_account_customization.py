import pytest
import sys
from idaptive_automation.api_helpers import UserApi, RoleApi
from idaptive_automation.ui_automation import AdminPortalPage, APUserProfileMenu, SignInPage, UserPortalPage, \
    UserAddEditWindow
from idaptive_automation.ui_automation import AdminPortalPage, APUserProfileMenu, SignInPage, WarningWindow
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.account_customization_page import \
    SettingsAccountCustomizationPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.settings_customization_page import \
    SettingsCustomizationPage
from idaptive_automation.ui_automation.pages.adminportal.add_login_suffix_dialog import AddLoginSuffixDialog
from idaptive_automation.ui_automation.pages.adminportal.suffix_landing_page import SuffixLandingPage
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation.pages.adminportal.admin_portal_support import AdminPortalSupport
from idaptive_automation.ui_automation import UsersTab
from Steps.navigate_steps import Login, Navigate
#from Fixtures.role_fixtures import ldap_role_app_fixture, get_ldap_server_config
from idaptive_automation.api_payloads import CloudUser
from Helpers.general_helpers import random_password
from idaptive_automation.ui_automation import PortalSwitcherPopout
from Fixtures.tenant_fixtures import auto_cleanup_tenant_suffix_fixture


@pytestrail.case('C86113')
@pytest.mark.pipeline
def test_c86113_validate_custom_links_on_the_login_screen(driver_admin):
    """ To validate Custom Links on the Login Screen """
    AdminPortalPage(driver_admin).select_settings_customization()

    customization = SettingsCustomizationPage(driver_admin)
    customization.wait_for_page_to_load()
    customization.click_account_customization()
    url = 'https://www.google.com/'
    title = 'Google'

    account_customization = SettingsAccountCustomizationPage(driver_admin)
    account_customization.wait_for_page_to_load()
    account_customization.set_terms_of_use(url)
    account_customization.set_privacy_policy(url)
    account_customization.click_save()

    APUserProfileMenu(driver_admin).sign_out()

    terms_of_use_url = SignInPage(driver_admin).validate_terms_of_use(title)
    assert terms_of_use_url == url, f'Expected {terms_of_use_url} is same as provided {url}, but found different'

    privacy_url = SignInPage(driver_admin).click_privacy_policy(title)
    assert privacy_url == url, f'Expected {privacy_url} is same as provided {url}, but found different'


@pytestrail.case('C76589')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c76589_change_the_name_of_a_suffix_happy_path(driver_admin, app_helpers, auto_cleanup_tenant_suffix_fixture):
    """ Change the name of a suffix , create cloud user with modified suffix and
        login into UP successfully """
    password = random_password()
    tenant_info = app_helpers['tenant_info']
    cloud_session = app_helpers['cloud_session']
    test_id = app_helpers['test_id']
    user_api = app_helpers['user_helper']

    suffix = f'{tenant_info["tenant_id"]}automation{app_helpers["test_id"]}'.lower()
    new_suffix = f'{tenant_info["tenant_id"]}qaautomation{app_helpers["test_id"]}'.lower()
    AdminPortalPage(driver_admin).select_settings_customization()
    SettingsCustomizationPage(driver_admin).click_suffix()

    suffix_page = SuffixLandingPage(driver_admin)
    suffix_page.press_suffix_add_button()
    AddLoginSuffixDialog(driver_admin).set_login_suffix(suffix)
    AddLoginSuffixDialog(driver_admin).press_suffix_save_button()
    suffix_page.wait_for_page_to_load()
    suffix_page.select_suffix_checkbox(suffix)
    suffix_page.open_actions_menu()
    suffix_page.click_modify()
    AddLoginSuffixDialog(driver_admin).wait_for_page_to_load()
    AddLoginSuffixDialog(driver_admin).set_login_suffix(new_suffix)
    AddLoginSuffixDialog(driver_admin).press_suffix_save_button()
    # suffix_page.wait_for_page_to_load()
    assert suffix_page.validate_modified_suffix_toaster() is True, \
        f'Unable to modify suffix, found suffix modified successfully'

    name = f'new-suffix-user-{test_id}'
    user_login_name = f'{name}@{new_suffix}'

    payload = CloudUser(new_suffix, name).with_login_name(user_login_name)\
        .with_display_name(name)\
        .with_password(password)\
        .with_password_never_expire(True).to_payload()
    new_user = user_api.create_cloud_user(payload)
    user_uuid = new_user.response['Result']
    RoleApi(cloud_session).add_users_to_automation_role([user_uuid])

    APUserProfileMenu(driver_admin).sign_out()
    Login(driver_admin).to_user_portal(user_login_name, password)

    UserPortalPage(driver_admin).wait_for_page_to_load()
    assert UserPortalPage(driver_admin).get_user_display_text() == name, \
        f'User is not logged into UP, expected {name}, found {UserPortalPage(driver_admin).get_user_display_text()}'
    user_api.delete_user(user_login_name)


@pytestrail.case('C86322')
def test_c86322_validate_custom_url_field(driver_admin):
    """ To validate Custom Links when I fill in the "Terms of Use Link"
        and "Privacy Policy Link" URL without using http or https  and
        Login in with links """
    AdminPortalPage(driver_admin).select_settings_customization()

    customization = SettingsCustomizationPage(driver_admin)
    customization.wait_for_page_to_load()
    customization.click_account_customization()
    invalid_url = '//www.google.com/'
    valid_url = 'https://www.google.com/'
    title = 'Google'
    account_customization = SettingsAccountCustomizationPage(driver_admin)
    account_customization.wait_for_page_to_load(wait_time=20)
    account_customization.set_terms_of_use(invalid_url)
    assert account_customization.is_error_icon_displayed() is True, f'Error icon is not displayed'
    expected_error_text = 'This field should be a URL in the format "http://www.example.com"'
    assert expected_error_text in account_customization.get_error_icon_text(),\
        f'Error text is not same as expected {account_customization.get_error_icon_text()}'

    account_customization.set_privacy_policy(invalid_url)

    account_customization.click_save()

    assert WarningWindow(driver_admin).warning_message_text() == \
           f"Please correct the errors in your form before submitting."
    WarningWindow(driver_admin).close()

    account_customization.set_terms_of_use(valid_url)
    account_customization.set_privacy_policy(valid_url)
    account_customization.click_save()

    APUserProfileMenu(driver_admin).sign_out()

    terms_of_use_url = SignInPage(driver_admin).validate_terms_of_use(title)
    assert terms_of_use_url == valid_url, f'Expected {terms_of_use_url} is same as provided {valid_url}, but found different'

    privacy_url = SignInPage(driver_admin).click_privacy_policy(title)
    assert privacy_url == valid_url, f'Expected {privacy_url} is same as provided {valid_url}, but found different'


@pytestrail.case('C154996')
def test_c154996_validate_company_name_and_support_link(driver_admin):
    """ To validate Custom Company Name and Company Links when I fill in the these fields
        URL without using http or https will error and
        links display on the Admin Portal Support """
    admin_portal = AdminPortalPage(driver_admin)
    admin_portal.select_settings_customization()

    customization = SettingsCustomizationPage(driver_admin).wait_for_page_to_load()
    customization.click_account_customization()
    invalid_url = 'www.google.com'
    valid_url = 'https://www.google.com/'
    company = 'Google'
    account_customization = SettingsAccountCustomizationPage(driver_admin)

    account_customization.set_company_support_link(link=invalid_url)
    assert account_customization.is_error_icon_displayed()
    assert account_customization.get_error_icon_text() == \
           f'<ul class="x-list-plain"><li>This field should be a URL in the format "http://www.example.com"</li></ul>'
    account_customization.click_save()

    assert WarningWindow(driver_admin).warning_message_text() == \
           f"Please correct the errors in your form before submitting."
    WarningWindow(driver_admin).close()

    account_customization.set_company_support_link(link=valid_url)
    account_customization.set_company_name(company=company)
    account_customization.click_save()

    Navigate(driver_admin).to_user_portal_via_url()
    Navigate(driver_admin).to_admin_portal_via_url()
    admin_portal.select_settings_customization()
    customization.click_account_customization()

    APUserProfileMenu(driver_admin).click_support()

    admin_portal_support = AdminPortalSupport(driver=driver_admin)
    admin_portal_support.wait_for_page_to_load()
    assert admin_portal_support.validate_new_company_link(company, valid_url)
    admin_portal_support.click_cancel()

    account_customization.clear_company_name()
    account_customization.click_save()

    Navigate(driver_admin).to_user_portal_via_url()
    Navigate(driver_admin).to_admin_portal_via_url()
    admin_portal.select_settings_customization()
    customization.click_account_customization()

    APUserProfileMenu(driver_admin).click_support()

    admin_portal_support.wait_for_page_to_load(wait_time=20)
    assert admin_portal_support.validate_blank_company_text()
    admin_portal_support.click_cancel()

    account_customization.clear_company_support_link()
    account_customization.click_save()

    account_customization.wait_for_page_to_load(wait_time=20)

    Navigate(driver_admin).to_user_portal_via_url()
    Navigate(driver_admin).to_admin_portal_via_url()
    admin_portal.select_settings_customization()
    customization.click_account_customization()

    APUserProfileMenu(driver_admin).click_support()

    assert not admin_portal_support.validate_blank_company_text()

#TODO LDAP
# @pytestrail.case('C76671')
# @pytest.mark.pipeline
# def test_c76671_ldap_user_can_login_to_up_without_a_suffix_with_tenant_specific_url(ldap_role_app_fixture,
#                                                                                     function_driver):
#     """ LDAP user can login to UP without a suffix with tenant specific url and
#         validate user login into UP successfully """
#     app_api, user_api, app, _, user, role_api = ldap_role_app_fixture
#
#     Login(function_driver).to_user_portal(user['user_name'], user['password'])
#     displayed_user_name = UserPortalPage(function_driver).get_user_display_text()
#     assert displayed_user_name == user["displayName"], \
#         f'User is not logged into UP, expected {user["displayName"]}, found {displayed_user_name}'
