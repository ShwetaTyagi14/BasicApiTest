from Fixtures.app_fixtures import auto_clean_app_fixture
from idaptive_automation.ui_automation import AppDetailsPage, AppsPage, AdminPortalPage
from idaptive_automation.ui_automation.pages.apps.add_web_apps_window import AddWebAppsWindow
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.web_apps_page import WebAppsPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate
from Fixtures.pvwa_integration_fixture import PVWA_fixture as pvwa


# @pytestrail.case('C158393')
# def test_c158393_validate_pvwa_setting_text(app_helpers, driver_admin):
#     """ Validate PVWA Setting text contains for AD users only """
#     ss_page = Navigate(driver_admin).to_security_settings_page()
#     personal_pwva_text = ss_page.get_pvwa_element_text("personal apps")
#     corporate_pvwa_text = ss_page.get_pvwa_element_text("corporate apps")
#     assert 'Store user credentials for personal apps in the password vault (applicable only for Active Directory users)' in personal_pwva_text
#     assert 'Store user credentials for corporate apps in the password vault (applicable only for Active Directory users)' in corporate_pvwa_text
#
#
# @pytestrail.case('C158392')
# def test_c158392_validate_pvwa_setting(app_helpers, driver_admin, auto_clean_app_fixture, pvwa):
#     """ Validate PVWA Setting checkbox in app when PVWA is enabled """
#     pvwa.disable_pvwa()
#     ss_page = Navigate(driver_admin).to_security_settings_page()
#     status_personal = ss_page.personal_pvwa_status()
#     status_corporate = ss_page.corporate_pvwa_status()
#
#     if status_corporate or status_personal:
#         ss_page.select_personal_pvwa_checkbox(unselect=True)
#         ss_page.click_save()
#     ss_page.select_corporate_pvwa_checkbox()
#     ss_page.select_personal_pvwa_checkbox()
#     ss_page.click_save()
#     web_app_page = Navigate(driver_admin).to_web_app_tab()
#     web_app_page.click_add_web_apps_button()
#
#     application_settings = AppDetailsPage(driver_admin)
#     addAppsWindow = AddWebAppsWindow(driver_admin)
#
#     addAppsWindow.click_custom_tab()
#     addAppsWindow.add_featured_app('Browser Extension')
#
#     visible, checked = application_settings.get_pvwa_status()
#     assert visible is True, "PVWA setting is not visible in BE app"
#     assert checked is True, "PVWA settings is unchecked.  Default is expected to be checked"
#     assert "applicable only for Active Directory users" in application_settings.get_pvwa_text()
#
#
# @pytestrail.case('C158391')
# def test_c158391_validate_pvwa_not_set_setting(app_helpers, driver_admin, auto_clean_app_fixture, pvwa):
#     """ Validate PVWA Setting in app not available when PVWA checkbox is unset after app creation """
#     pvwa.enable_pvwa()
#     test_app = pvwa.create_app("Generic User-Password")
#     app_api = app_helpers['app_helper']
#     result_test_app = app_api.get_application(test_app)
#     assert result_test_app["StoreUserCredsInVault"] is True, \
#         f"StoreUserCredsInVault should set and True, but is not in {result_test_app['DisplayName']}"
#     pvwa.disable_pvwa()
#     ss_page = Navigate(driver_admin).to_security_settings_page()
#     status_personal = ss_page.personal_pvwa_status()
#     status_corporate = ss_page.corporate_pvwa_status()
#
#     if status_corporate or status_personal:
#         ss_page.select_corporate_pvwa_checkbox(unselect=True)
#         ss_page.select_personal_pvwa_checkbox(unselect=True)
#         ss_page.click_save()
#
#     ap_main_page = Navigate(driver_admin).to_web_app_tab()
#     web_apps_page = WebAppsPage(driver_admin)
#     web_apps_page.search_for_app(result_test_app['DisplayName'])
#     web_apps_page.click_specific_app(result_test_app['DisplayName'])
#
#     application_settings = AppDetailsPage(driver_admin)
#     visible, checked = application_settings.get_pvwa_status()
#     assert visible is False, "PVWA setting is visible in BE app, but shouldn't be"
#     assert checked is False, "PVWA settings is checked.  Option is not supposed to be available"
