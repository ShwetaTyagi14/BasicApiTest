import pytest
from idaptive_automation.api_helpers import CertificateApiHelper
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.Authentication.SigningCertificates.\
    signingcertificates_page import SigningCertificatesPage
from idaptive_automation.ui_automation import UploadCertificatePage
from idaptive_automation.ui_automation import CertDeleteDialog
from idaptive_automation.ui_automation import RenameCertDialog
from idaptive_automation.ui_automation import WebAppsPage
from idaptive_automation.ui_automation import AddWebAppsDialog
from idaptive_automation.ui_automation import ConfirmAddWebAppsDialog
from idaptive_automation.ui_automation import ConfirmDeleteWindow
from idaptive_automation.ui_automation import WSFedSettingsPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate
from Helpers.test_data_helper import get_file_path
from Steps.app_steps import create_generic_app
from Fixtures.app_fixtures import certificate_file_path, auto_clean_app_fixture
from Fixtures.tenant_fixtures import auto_cleanup_app_cert_fixture as cert_cleanup
from Steps import certificate_steps


@pytestrail.case('C33024')
@pytest.mark.pipeline
def test_c33024_search_function_checking(driver_admin):
    """ Search functionality for signing certificates page """
    invalid_key = "xxx"
    valid_key = "Idap"
    Navigate(driver_admin).to_signing_certificates_page()
    signing_certificates_page = SigningCertificatesPage(driver_admin)
    signing_certificates_page.validate_all_child_elements()
    signing_certificates_page.search_for_certificates(invalid_key)
    assert signing_certificates_page.get_displayed_certs() is None, f'Certificate Name exists, Found None'
    signing_certificates_page.search_for_certificates(valid_key)
    result_len = len(signing_certificates_page.get_displayed_certs())
    assert result_len >= 1, f'Did not find expected number of certs, Found {result_len}'


@pytestrail.case('C31701')
@pytest.mark.pipeline
def test_c31701_ui_validation_of_signing_certificates_landing_page(driver_admin):
    """ UI validation of signing certificates landing page """
    Navigate(driver_admin).to_signing_certificates_page()
    signing_certificates_page = SigningCertificatesPage(driver_admin)
    signing_certificates_page.validate_all_child_elements()
    result_len = len(signing_certificates_page.get_displayed_certs())
    assert result_len >= 1, f'Did not find expected number of certs, Found {result_len}'


@pytestrail.case('C33019')
@pytest.mark.pipeline
def test_c33019_upload_new_certificate(driver_admin, app_helpers, certificate_file_path, auto_clean_app_fixture, cert_cleanup):
    test_id = app_helpers['test_id']
    cert_name = f'Test cert for {test_id}'
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    signing_certificates_page.click_add_button()
    certificate_steps.setup_new_application_cert(driver_admin, cert_name, certificate_file_path)
    result = signing_certificates_page.get_specific_cert(cert_name)
    assert cert_name in result, f'Expected {cert_name}, Got {result}'
    signing_certificates_page.delete_cert(cert_name)
    CertDeleteDialog(driver_admin).press_yes()
    signing_certificates_page.click_add_button()
    bad_file_path = get_file_path('firefox-IBE bug.png', 'Certificates')
    result = certificate_steps.setup_new_application_cert(driver_admin, cert_name, bad_file_path, verify_error=True)
    assert result is True, "Expected Error page, however one was not displayed"


# TODO This test should use the GetCertificateInfos endpoint to gather certificate information instead of the UI
@pytestrail.case('C33020')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c33020_upload_new_default_cert(driver_admin, app_helpers, certificate_file_path, cert_cleanup):
    test_id = app_helpers['test_id']
    app_helper = app_helpers['app_helper']
    create_generic_app("GenericWsFed", app_helpers)

    cert_name = f'Test cert for {test_id}'
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.search_for_app('WS-Fed').click_specific_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    current_app_cert_thumbprint = ws_fed_page.get_cert_value().text.split("\n")[0]
    current_app_cert_thumbprint = current_app_cert_thumbprint.split(":")[1].lstrip()
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    result = signing_certificates_page.get_displayed_certs()
    builtin_cert = result[0].text.split("\n")[0].lstrip()
    builtin_cert_thumbprint = signing_certificates_page.get_specific_cert_thumbprints(builtin_cert)
    assert builtin_cert_thumbprint == current_app_cert_thumbprint
    signing_certificates_page.click_add_button()
    certificate_steps.setup_new_application_cert(driver_admin, cert_name, certificate_file_path)
    signing_certificates_page.set_default_cert(cert_name)
    result = signing_certificates_page.check_is_default(cert_name)
    assert result is True, f'Expected True for Uploaded Cert is default, but returned {result}'
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.click_specific_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    current_app_cert_thumbprint = ws_fed_page.get_cert_value().text.split("\n")[0]
    current_app_cert_thumbprint = current_app_cert_thumbprint.split(":")[1].lstrip()
    assert current_app_cert_thumbprint == builtin_cert_thumbprint, f'Expected the same cert, but app cert is {current_app_cert_thumbprint}'
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page.click_add_web_apps()
    add_apps_page = AddWebAppsDialog(driver_admin)
    add_apps_page.wait_for_apps_page_to_load()
    add_apps_page.add_web_app_by_name('Knowledge Vault')
    ConfirmAddWebAppsDialog(driver_admin).click_yes()
    AddWebAppsDialog(driver_admin).click_close()
    current_app_cert_thumbprint = ws_fed_page.get_cert_value().text.split("\n")[0]
    current_app_cert_thumbprint = current_app_cert_thumbprint.split(":")[1].lstrip()
    app_key = app_helper.get_app_key_from_app_name("Knowledge Vault")
    app_helper.apps_created.append(app_key)
    app_helper.delete_application(app_key)
    assert current_app_cert_thumbprint != builtin_cert_thumbprint, f'Expected app cert to equal uploaded cert, got {current_app_cert_thumbprint}'


# TODO Use the GetCertificateInfos endpoint to check on the status of certificates
@pytestrail.case('C33021')
@pytest.mark.pipeline
def test_c33021_rename_uploaded_cert(driver_admin, app_helpers, certificate_file_path, cert_cleanup):
    test_id = app_helpers['test_id']
    cert_name = f'Test cert for {test_id}'
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    signing_certificates_page.click_add_button()
    certificate_steps.setup_new_application_cert(driver_admin, cert_name, certificate_file_path)
    signing_certificates_page.open_rename_cert(cert_name)
    new_cert_name = cert_name + " Renamed"
    rename_cert_page = RenameCertDialog(driver_admin)
    rename_cert_page.rename_cert(new_cert_name)
    result = signing_certificates_page.get_displayed_certs()
    assert new_cert_name in result[1].text, f'Expected {new_cert_name}, Got {result[1].text}'
    signing_certificates_page.delete_cert(new_cert_name)
    cert_delete_page = CertDeleteDialog(driver_admin)
    cert_delete_page.press_yes()
    cert_delete_page.verify_window_closed()
    signing_certificates_page.open_rename_cert(f"{app_helpers['tenant_info']['tenant_id']} SHA256 Application Signing Certificate")
    result = signing_certificates_page.rename_warning_present()
    assert result is True, f'Expected True for warning displayed, Got {result}'


@pytestrail.case('C33022')
@pytest.mark.pipeline
def test_c33022_delete_cert_in_use_negative_test(driver_admin, app_helpers, certificate_file_path, auto_clean_app_fixture, cert_cleanup):
    test_id = app_helpers['test_id']
    create_generic_app("GenericWsFed", app_helpers)

    cert_name = f'Test cert for {test_id}'
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    result = signing_certificates_page.get_displayed_certs()
    builtin_cert = result[0].text.split("\n")[0].lstrip()
    signing_certificates_page.click_add_button()
    certificate_steps.setup_new_application_cert(driver_admin, cert_name, certificate_file_path)
    signing_certificates_page.delete_cert(builtin_cert)
    cert_delete_page = CertDeleteDialog(driver_admin)
    assert "default certificate is not allowed to delete" in cert_delete_page.get_delete_warning_dialog_text(), \
        "Expected delete default cert error"
    cert_delete_page.press_close()
    cert_delete_page.verify_window_closed()
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.search_for_app('WS-Fed').click_specific_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    ws_fed_page.change_app_cert(cert_name)
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    signing_certificates_page.delete_cert(cert_name)
    cert_delete_page.press_yes()
    assert "Certificate cannot be deleted because it is used by 1 application(s)" in \
           cert_delete_page.get_delete_error_dialog_text(), "Expected error of cert in use"
    cert_delete_page.press_close()
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.click_specific_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    ws_fed_page.change_app_cert(builtin_cert)


@pytestrail.case('C31700')
@pytest.mark.pipeline
def test_c31700_upload_new_cert_for_app_auth(driver_admin, certificate_file_path, app_helpers, auto_clean_app_fixture, cert_cleanup):
    test_id = app_helpers['test_id']
    create_generic_app("GenericWsFed", app_helpers)
    cert_name = f'Test cert for {test_id}'
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    result = signing_certificates_page.get_displayed_certs()
    builtin_cert = result[0].text.split("\n")[0].lstrip()
    signing_certificates_page.click_add_button()
    certificate_steps.setup_new_application_cert(driver_admin, cert_name, certificate_file_path)
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.search_for_app('WS-Fed')
    web_apps_page.click_specific_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    ws_fed_page.change_app_cert(cert_name)
    current_app_cert_thumbprint = ws_fed_page.get_cert_value().text.split("\n")[0]
    current_app_cert_thumbprint = current_app_cert_thumbprint.split(":")[1].lstrip()
    signing_certificates_page = Navigate(driver_admin).to_signing_certificates_page()
    signing_certificates_page.click_add_button()
    new_cert_name = cert_name + " NEW"
    certificate_steps.setup_new_application_cert(driver_admin, new_cert_name, certificate_file_path)
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.click_specific_app("WS-Fed")
    ws_fed_page = WSFedSettingsPage(driver_admin)
    app_cert_value = ws_fed_page.get_cert_value().text.split("\n")[0]
    app_cert_value = app_cert_value.split(":")[1].lstrip()
    assert app_cert_value == current_app_cert_thumbprint
    cert_name_from_app = ws_fed_page.get_certificate_table_text()
    assert new_cert_name == cert_name_from_app, f'Unexpected result {new_cert_name} != {cert_name_from_app}'
    ws_fed_page.change_app_cert(builtin_cert)



