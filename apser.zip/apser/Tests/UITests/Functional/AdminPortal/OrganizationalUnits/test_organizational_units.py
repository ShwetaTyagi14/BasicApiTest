import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_add_members_dialog import OUAddembersDialog
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_tab_landing_page import OUSTab
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_add_edit_window import OUAddEditWindow
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_delete_dialog import OUDeleteDialog
from idaptive_automation.ui_automation import AdminPortalPage, APUserProfileMenu, SignInPage, UserPortalPage, \
    UserAddEditWindow
from Steps.navigate_steps import Login, Navigate
from Fixtures.tenant_key_fixtures import *
from idaptive_testrail.plugin import pytestrail
from Steps.user_steps import *
from Steps.ou_steps import *
from Steps.app_steps import *
from Steps.policy_steps import add_mfa_policy_to_role
from Fixtures.app_fixtures import *
from idaptive_automation.api_helpers import RoleApi, UprestHelper
from idaptive_automation.api_payloads import *
from idaptive_automation.ui_automation import AppsPage, AdminPortalPage, AppDetailsPage, UsersTab, \
    ConfigurableAppSettingsPage, APUserProfileMenu, UserPortalPage, WarningWindow, UnsavedChangesDialog
from idaptive_automation.ui_automation.pages.apps.add_web_apps_window import AddWebAppsWindow
from idaptive_automation.ui_automation.pages.apps.add_web_app_dialog import AddWebAppDialog


@pytestrail.case('C173584')
def test_c173584_add_user(driver_admin, app_helpers, set_organization_feature_flag):
    role_helper = app_helpers['role_helper']
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']
    ou_helper = app_helpers['ou_helper']

    role_name = f'OU Role {test_id}'
    new_user = f'ou_user_{test_id}'
    ou_role1 = role_helper.create_role(role_name=role_name, description=role_name)
    ou_user1 = create_interactive_user_and_activate(app_helpers, alias, new_user, ou_role1)
    new_user = f'ou_user_{test_id}2'
    ou_user2 = create_interactive_user_and_activate(app_helpers, alias, new_user, ou_role1)

    test_id = app_helpers['test_id']
    Navigate(driver_admin).to_organizations_tab()
    OUSTab(driver_admin).click_add_ou()

    ou_name = f"temp OU-{test_id}"
    OUAddEditWindow(driver_admin).set_ou_name(name=ou_name)
    OUAddEditWindow(driver_admin).hover_and_click("Save")

    OUSTab(driver_admin).open_ou_detail_window_for_ou(ou_name=ou_name)
    OUAddEditWindow(driver_admin).open_roles_window()
    OUAddEditWindow(driver_admin).open_add_members_window()
    OUAddembersDialog(driver_admin).search_for_unit(unit_name=role_name)
    OUAddembersDialog(driver_admin).select_unit_checkbox()
    OUAddembersDialog(driver_admin).press_add_button()
    OUAddEditWindow(driver_admin).press_save_button()
    Navigate(driver_admin).to_organizations_tab()
    new_ou = ou_helper.get_ou_by_name(ou_name)
    assert ou_helper.is_role_in_ou(new_ou['ID'], ou_role1)
    OUSTab(driver_admin).open_ou_detail_window_for_ou(ou_name=ou_name)
    OUAddEditWindow(driver_admin).open_roles_window()
    OUAddEditWindow(driver_admin).select_checkbox_for_unit(unit_name=role_name)
    OUSTab(driver_admin).open_actions_menu()
    OUAddEditWindow(driver_admin).click_delete()
    OUAddEditWindow(driver_admin).hover_and_click("Save")
    Navigate(driver_admin).to_organizations_tab()
    assert not ou_helper.is_role_in_ou(new_ou['ID'], ou_role1)
    OUSTab(driver_admin).select_ou_checkbox(ou_name)
    OUSTab(driver_admin).open_actions_menu()
    OUSTab(driver_admin).click_delete()
    OUDeleteDialog(driver_admin).press_yes()
    assert ou_helper.get_ou(new_ou['ID']) is None


@pytestrail.case('C173581')
def test_c173581_ou_delegated_admin_limited_ap_access(driver_admin, app_helpers, set_organization_feature_flag):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']

    new_user = f'user_{test_id}'
    ou_name = f'OU Name {test_id}'
    cloud_user = create_interactive_user_and_activate(app_helpers, alias, new_user)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    user_id = cloud_user['Uuid']

    assert ou_helper.add_ou_admin(ou_id, user_id)
    assert ou_helper.is_user_ou_admin(ou_id, user_id)

    APUserProfileMenu(driver_admin).sign_out()
    Login(driver_admin).to_user_portal(cloud_user['Name'], cloud_user['Password'])
    Navigate(driver_admin).to_admin_portal_via_url(False)
    assert AdminPortalPage(driver_admin).is_available('users')
    assert AdminPortalPage(driver_admin).is_available('roles')
    assert AdminPortalPage(driver_admin).is_available('mobile_apps_tab')
    assert AdminPortalPage(driver_admin).is_available('web_apps_tab')
    assert AdminPortalPage(driver_admin).is_available('requests_tab')
    assert not AdminPortalPage(driver_admin).is_available('ou_tab')
    assert not AdminPortalPage(driver_admin).is_available('reports_tab')
    assert not AdminPortalPage(driver_admin).is_available('dashboard')
    assert not AdminPortalPage(driver_admin).is_available('settings')


@pytestrail.case('C178581')
@pytest.mark.pipeline
def test_C178581_ou_admin_with_app_mgt_can_add_apps(driver_admin, app_helpers, set_organization_feature_flag):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    role_helper = app_helpers['role_helper']
    alias = app_helpers['alias']

    new_user = f'user_{test_id}'
    ou_name = f'OU Name {test_id}'
    role_name = f'OU Role {test_id}'
    ou_role = role_helper.create_role(role_name=role_name, description=role_name)
    cloud_user = create_interactive_user_and_activate(app_helpers, alias, new_user)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    user_id = cloud_user['Uuid']

    role_helper.add_users_to_role(ou_role, [user_id])
    role_helper.assign_super_rights_to_role([{"Role": ou_role, "Path": "/lib/rights/appman.json"}])

    assert ou_helper.add_ou_admin(ou_id, user_id)
    assert ou_helper.is_user_ou_admin(ou_id, user_id)

    APUserProfileMenu(driver_admin).sign_out()
    Login(driver_admin).to_user_portal(cloud_user['Name'], cloud_user['Password'])
    Navigate(driver_admin).to_admin_portal_via_url(False)
    AdminPortalPage(driver_admin).select_web_apps()
    apps_page = AppsPage(driver_admin)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.search_app_input(app_name="ADP")
    add_web_apps_window.click_first_apps_add_button()

    add_web_app_dialog = AddWebAppDialog(driver_admin)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()

    assert len(
        add_web_apps_window.get_remove_buttons()) == 1, f'expected count is 1, found {len(add_web_apps_window.get_remove_buttons())}'
    add_web_apps_window.click_close_button()


@pytestrail.case('C178846')
def test_c178846_select_single_user_and_add_to_ou(driver_admin, app_helpers, set_organization_feature_flag):
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']
    ou_helper = app_helpers['ou_helper']
    ou_name = f'OU Name {test_id}'
    create_ou_response = ou_helper.create_ou_return_response(ou_name)
    ou_id = create_ou_response.result()['ID']
    new_user = f'ou_user_{test_id}'
    created_user = create_interactive_user_and_activate(app_helpers, alias, new_user)
    user_list = [new_user]
    add_users_to_ou_from_users_page(driver_admin, user_list, test_id)
    validate_users_added_to_ou(ou_helper, user_list, ou_id, alias)


@pytestrail.case('C178847')
def test_c178847_select_multiple_users_and_add_to_ou(driver_admin, app_helpers, set_organization_feature_flag):
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']
    ou_helper = app_helpers['ou_helper']
    ou_name = f'OU Name {test_id}'
    create_ou_response = ou_helper.create_ou_return_response(ou_name)
    ou_id = create_ou_response.result()['ID']
    new_user1 = f'ou_user_{test_id}_1'
    created_user1 = create_interactive_user_and_activate(app_helpers, alias, new_user1)
    new_user2 = f'ou_user_{test_id}_2'
    created_user2 = create_interactive_user_and_activate(app_helpers, alias, new_user2)
    user_list = [new_user1, new_user2]
    add_users_to_ou_from_users_page(driver_admin, user_list, test_id)
    validate_users_added_to_ou(ou_helper, user_list, ou_id, alias)


@pytestrail.case('C178849')
def test_c178849_warning_when_adding_ou_users_to_different_ou(driver_admin, app_helpers, set_organization_feature_flag):
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']
    ou_helper = app_helpers['ou_helper']
    ou1_name = f'OU Name {test_id}_1'
    ou2_name = f'OU Name {test_id}_2'
    create_ou1_response = ou_helper.create_ou_return_response(ou1_name)
    ou1_id = create_ou1_response.result()['ID']
    create_ou2_response = ou_helper.create_ou_return_response(ou2_name)
    ou2_id = create_ou2_response.result()['ID']
    new_user1 = f'ou_user_{test_id}_1'
    created_user1 = create_interactive_user_and_activate(app_helpers, alias, new_user1)
    new_user2 = f'ou_user_{test_id}_2'
    created_user2 = create_interactive_user_and_activate(app_helpers, alias, new_user2)
    user_list = [new_user1, new_user2]
    add_users_to_ou(ou_helper, ou1_id, created_user1['Uuid'])
    validate_warning_adding_users_to_different_ou(driver_admin, user_list, test_id)


@pytestrail.case('C178850')
def test_c178850_add_users_to_ou_when_no_ou_created(driver_admin, app_helpers, set_organization_feature_flag):
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']
    ou_helper = app_helpers['ou_helper']
    ous_list = ou_helper.get_all_ous()
    assert len(ous_list) == 0, 'This test is not expected to have OUs created'
    new_user1 = f'ou_user_{test_id}_1'
    created_user1 = create_interactive_user_and_activate(app_helpers, alias, new_user1)
    new_user2 = f'ou_user_{test_id}_2'
    created_user2 = create_interactive_user_and_activate(app_helpers, alias, new_user2)
    user_list = [new_user1, new_user2]
    validate_not_authorized_to_modify_ous(driver_admin, user_list, test_id)
