from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import AppsPage, AdminPortalPage, AppDetailsPage
from Steps.navigate_steps import Navigate, Login
from Steps.app_steps import *


@pytestrail.case('C178454')
@pytest.mark.pipeline
def test_c178454_delete_remote_access_app(driver, app_helpers):
    tenant_info = app_helpers['tenant_info']
    cloud_session = app_helpers['cloud_session']
    app_api = AppHelper(cloud_session)

    # Get CyberArk Remote Access app id
    app_id = get_remote_access_app_id(app_api)

    # Log in and go to Web Apps page
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_admin_portal_via_url()
    apps_page = AdminPortalPage(driver).select_web_apps()
    apps_page.refresh_page()
    apps_page.wait_for_page_to_load(15)

    # Notice that Delete option doesn't show up in Actions dropdown
    app_display_name = "CyberArk Remote Access Portal"
    apps_page.search_for_app(app_display_name).click_specific_app(app_display_name)
    app_details_page = AppDetailsPage(driver)
    app_details_page.click_actions_button()
    assert not app_details_page.elements['delete'].is_displayed()
