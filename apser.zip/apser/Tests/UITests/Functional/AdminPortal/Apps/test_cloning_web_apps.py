import pytest
from idaptive_automation.ui_automation.pages.apps.add_web_app_dialog import AddWebAppDialog
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import api_session, mongo_dal
from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
from idaptive_automation.ui_automation import AppsPage, AdminPortalPage, AppDetailsPage
from idaptive_automation.ui_automation.pages.apps.add_web_apps_window import AddWebAppsWindow
from Steps.navigate_steps import Navigate, Login
from Steps.app_steps import get_existing_app_by_name
from idaptive_automation.api_payloads import GenericSamlApp


@pytestrail.case('C173597')
@pytest.mark.pipeline
def test_c173597_clone_aws_app_in_ap(driver, app_helpers):
    tenant_info = app_helpers['tenant_info']
    app_helper = app_helpers['app_helper']
    catalog_app = "Amazon Web Services (AWS)"
    sample_aws_app = f"{catalog_app}-{app_helpers['test_id']}"
    app_id = app_helper.import_app_by_name("Amazon AWS")
    app = GenericSamlApp('https:\\AWS.com', app_id).with_name(sample_aws_app) \
        .to_payload()
    app_helper.update_application_de(app)
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_admin_portal_via_url()
    apps_page = AdminPortalPage(driver).select_web_apps()
    apps_page.refresh_page()
    apps_page.wait_for_page_to_load(15)

    apps_page.search_for_app(sample_aws_app).click_specific_app(sample_aws_app)

    app_details_page = AppDetailsPage(driver)
    app_details_page.click_actions_button()
    app_details_page.click_on_clone()
    cloned_name = sample_aws_app + " (Clone)"
    cloned_app_id = app_helper.get_app_key_from_app_name(cloned_name)
    app_helpers['app_helper'].apps_created.append(cloned_app_id)

    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.refresh_page()
    apps_page.wait_for_page_to_load(15)

    apps_page.search_for_app(appname=cloned_name)
    assert len(
        apps_page.get_apps()) >= 1, f'Search for cloned app failed, expected >= 1,but found len(apps_page.get_apps())'
    apps_page.select_web_app(web_app=cloned_name)
    app_details_page.wait_for_page_to_load()

    assert app_details_page.get_app_name_as_title() == cloned_name, f'App name is other than expected {cloned_name} and found {app_details_page.get_app_name_as_title()}'


@pytestrail.case('C33505')
@pytest.mark.pipeline
def test_c33505_clone_saml_app_in_ap(driver, app_helpers):
    tenant_info = app_helpers['tenant_info']
    app_helper = app_helpers['app_helper']
    sample_saml_app = f"ADP-{app_helpers['test_id']}"
    app_id = app_helper.import_app_by_name("ADPSAML")
    app = GenericSamlApp('https:\\ADP.com', app_id).with_name(sample_saml_app) \
        .to_payload()
    app_helper.update_application_de(app)

    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_admin_portal_via_url()
    """ To validate cloning of SAML App """
    apps_page = AdminPortalPage(driver).select_web_apps()\
        .select_specific_app(sample_saml_app)\
        .click_actions_button().click_clone()
    cloned_name = sample_saml_app + " (Clone)"
    cloned_app_id = app_helper.get_app_key_from_app_name(cloned_name)
    app_helpers['app_helper'].apps_created.append(cloned_app_id)
    app_details_page = AppDetailsPage(driver).wait_for_page_to_load()

    AdminPortalPage(driver).select_web_apps()
    apps_page.refresh_page()
    apps_page.wait_for_page_to_load(15)

    apps_page.search_for_app(cloned_name).click_specific_app(cloned_name)

    assert app_details_page.get_app_name_as_title() == cloned_name, f'App name is other than expected {cloned_name} and found {app_details_page.get_app_name_as_title()}'

    app_details_page.click_on_account_mapping()
    assert app_details_page.is_directory_field_name_selected() is True, \
        f'Directory Service Field is not selected, expected True, but found {app_details_page.is_directory_field_name_selected()}'

    app_details_page.click_on_changelog()
    assert app_details_page.is_changelog_add_displayed() is True, f'ChangeLog is not showing up "Add", expected True, but found {app_details_page.is_changelog_add_displayed()}'


@pytestrail.case('C33506')
@pytest.mark.pipeline
def test_c33506_clone_up_app_in_ap(driver_admin, app_helpers):
    tenant_info = app_helpers['tenant_info']
    app_helper = app_helpers['app_helper']
    sample_up_app = f"CDW"
    app_id = app_helper.import_app_by_name("CDW Website")
    apps_page = AdminPortalPage(driver_admin).select_web_apps()\
        .search_for_app(sample_up_app)\
        .select_specific_app(sample_up_app)\
        .click_actions_button().click_clone()
    cloned_name = sample_up_app + " (Clone)"
    cloned_app_id = app_helper.get_app_key_from_app_name(cloned_name)
    app_helpers['app_helper'].apps_created.append(cloned_app_id)
    app_details_page = AppDetailsPage(driver_admin).wait_for_page_to_load()

    AdminPortalPage(driver_admin).select_web_apps()
    apps_page.refresh_page()
    apps_page.wait_for_page_to_load()

    apps_page.search_for_app(cloned_name).click_specific_app(cloned_name)

    assert app_details_page.get_app_name_as_title() == cloned_name, f'App name is other than expected {cloned_name} and found {app_details_page.get_app_name_as_title()}'

    app_details_page.click_on_account_mapping()
    assert app_details_page.is_prompt_for_username_selected() is True, f'prompt for username is not selected, expected True, but found {app_details_page.is_prompt_for_username_selected()}'

    app_details_page.click_on_changelog()
    assert app_details_page.is_changelog_add_displayed() is True, f'ChangeLog is not showing up "Add", expected True, but found {app_details_page.is_changelog_add_displayed()}'