import pytest
from idaptive_automation.api_helpers import AppHelper
from idaptive_automation.ui_automation.pages.apps.preview_saml_response import PreviewSAMLResponseDialog
from idaptive_automation.ui_automation.pages.apps.select_user_for_saml_response import SelectUserSamlResponseDialog
from idaptive_automation.ui_automation.pages.apps.select_user_group_role import SelectUserGroupRolePage
from idaptive_automation.ui_automation.pages.confirm_user_password_window import ConfirmUsernamePasswordWindow
from idaptive_testrail.plugin import pytestrail
from Steps.app_steps import go_to_apps_tab, create_generic_app, get_displayed_apps_count
from idaptive_automation.ui_automation import AppsPage, AdminPortalPage, AppDetailsPage, UsersTab, \
    ConfigurableAppSettingsPage, APUserProfileMenu, UserPortalPage, WarningWindow, UnsavedChangesDialog
from idaptive_automation.ui_automation.pages.apps.add_web_apps_window import AddWebAppsWindow
from idaptive_automation.ui_automation.pages.apps.add_web_app_dialog import AddWebAppDialog
from idaptive_automation.ui_automation.pages.apps.add_linked_application_dialog import AddLinkedAppDialog
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.linked_applications_tab \
    import SAMLAppGatewayLinkedAppsPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.trust_tab import \
    SAMLAppGatewayTrustPage
from idaptive_automation.ui_automation.pages.adminportal.WebAppsTab.AppConfigPages.SAMLApps.permissions_tab import \
    SAMLAppGatewayPermissionsPage
from idaptive_automation.ui_automation import WebAppsPage
from Fixtures.app_fixtures import app_templates
from Helpers.test_data_helper import get_import_app_file_path
from idaptive_automation.ui_automation.pages.profilemenu.portal_switcher_popout import PortalSwitcherPopout
from idaptive_automation.api_payloads import GenericSamlApp
from Fixtures.app_fixtures import create_generic_wsfed_app, auto_clean_app_fixture #, create_generic_saml_app, deploy_salesforce_template_app, \
#    create_servicenow_saml_app, create_knowledgevault_wsfed_app, create_generic_openid_app

from Steps.navigate_steps import Navigate, Login


@pytestrail.case('C76720')
@pytest.mark.pipeline
def test_c76720_check_linked_application_ui_in_ap(driver_admin, app_helpers):
    """ Check Linked application UI
        A linked application is a set of two or more SAML applications, one being the "parent" application which contains most of
        the SAML settings, and one being the "child" application which has only one or two unique values.
        Linked applications are created so that the end user does not have to fill out the same SAML settings over and over."""
    AdminPortalPage(driver_admin).select_web_apps()
    apps_page = AppsPage(driver_admin)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.search_app_input(app_name="ADP")
    add_web_apps_window.click_first_apps_add_button()

    add_web_app_dialog = AddWebAppDialog(driver_admin)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()

    assert len(
        add_web_apps_window.get_remove_buttons()) == 1, f'expected count is 1, found {len(add_web_apps_window.get_remove_buttons())}'
    add_web_apps_window.click_close_button()

    app_details_page = AppDetailsPage(driver_admin)
    app_details_page.wait_for_page_to_load()
    app_details_page.click_linked_applications_tab()
    app_details_page.click_add_button()

    linked_apps_dialog = AddLinkedAppDialog(driver_admin)
    linked_apps_dialog.wait_for_page_to_load()
    assert len(linked_apps_dialog.get_child_apps()) >= 1, f'Child apps are < 1'


@pytestrail.case('C76724')
@pytest.mark.pipeline
def test_c76724_check_delete_linked_application_ui_in_ap(driver_admin, app_helpers):
    """ As an admin
        When I navigate to a child application's detail page
        And I check the "actions" tab
        The only options is "delete."""
    AdminPortalPage(driver_admin).select_web_apps()
    apps_page = AppsPage(driver_admin)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.search_app_input(app_name="ADP")
    add_web_apps_window.click_first_apps_add_button()

    add_web_app_dialog = AddWebAppDialog(driver_admin)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()

    assert len(
        add_web_apps_window.get_remove_buttons()) == 1, f'expected count is 1, found {len(add_web_apps_window.get_remove_buttons())}'
    add_web_apps_window.click_close_button()

    app_details_page = AppDetailsPage(driver_admin)
    app_details_page.wait_for_page_to_load()
    app_details_page.click_linked_applications_tab()
    app_details_page.click_add_button()

    linked_apps_dialog = AddLinkedAppDialog(driver_admin)
    linked_apps_dialog.wait_for_page_to_load()
    linked_apps_dialog.select_first_row()
    linked_apps_dialog.press_finish()

    app_details_page.select_checkbox_for_app(app_name='ADP')
    app_details_page.open_linked_apps_actions_menu()
    app_details_page.click_delete()


@pytestrail.case('C45608')
@pytest.mark.pipeline
def test_c45608_custom_bookmark_apps_can_no_longer_be_sorted_by_language(driver_admin, app_helpers):
    """ Custom bookmark apps can no longer be sorted by language """
    AdminPortalPage(driver_admin).select_web_apps()
    apps_page = AppsPage(driver_admin)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.click_custom_tab()
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.click_first_apps_add_button()

    add_web_app_dialog = AddWebAppDialog(driver_admin)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()

    assert len(
        add_web_apps_window.get_remove_buttons()) == 1, f'expected count is 1, found {len(add_web_apps_window.get_remove_buttons())}'
    add_web_apps_window.click_close_button()

    app_details_page = AppDetailsPage(driver_admin)
    app_details_page.set_app_url(app_url='https://duckduckgo.com/')
    app_details_page.click_description_tab()
    app_details_page.enable_localization()
    language_list_before_sort = app_details_page.get_language_list()
    app_details_page.click_header_on_grid(header_name='Language')
    language_list_after_sort = app_details_page.get_language_list()
    assert language_list_before_sort == language_list_after_sort, f'Sorting is failed'


@pytestrail.case('C76597')
@pytest.mark.pipeline
def test_c76597_remove_button_check_on_add_web_apps_page_in_ap(driver_admin, app_helpers):
    """ 'Remove' button check on "Add Web Apps" page
        Given I click the "Remove" button,Then the 'Remove' button changes back to an 'Add' button
        And the app is removed from the list of admin apps"""
    AdminPortalPage(driver_admin).select_web_apps()
    apps_page = AppsPage(driver_admin)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.click_custom_tab()

    assert add_web_apps_window.get_remove_buttons() is None, f'Remove button should not be displayed,but found'
    add_web_apps_window.click_first_apps_add_button()
    add_web_app_dialog = AddWebAppDialog(driver_admin)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()

    assert len(
        add_web_apps_window.get_remove_buttons()) == 1, f'Remove buttons count should be 1,but found {len(add_web_apps_window.get_remove_buttons())}'
    add_web_apps_window.click_remove_button()
    add_web_apps_window.wait_for_page_to_load()
    assert add_web_apps_window.get_remove_buttons() is None, f'Remove button should not be displayed,but found'


@pytestrail.case('C33503')
@pytest.mark.pipeline
def test_c33503_add_custom_ibe_application(driver_admin, app_helpers):
    """ Add a custom IBE application """
    app_helper = app_helpers['app_helper']
    Navigate(driver_admin).to_users_tab()
    admin_portal_page = AdminPortalPage(driver_admin)
    apps_page = AppsPage(driver_admin)
    application_settings = AppDetailsPage(driver_admin)
    addAppsWindow = AddWebAppsWindow(driver_admin)
    select_user_group_role = SelectUserGroupRolePage(driver_admin)

    url = 'https://www.facebook.com/'
    hostname = 'facebook.com'
    username = 'appsaccounts@centrify.com'
    password = 'dr4!^Reeeee'
    rolename = 'Everybody'

    admin_portal_page.select_web_apps()
    apps_page.click_add_web_apps_button()

    addAppsWindow.click_custom_tab()
    addAppsWindow.add_featured_app('Browser Extension')

    application_settings.set_app_url(url)
    application_settings.click_on_permissions_tab()
    application_settings.click_add_button()

    select_user_group_role.search_for_role(rolename)
    select_user_group_role.select_role_checkbox()
    select_user_group_role.click_on_add_button()

    application_settings.click_on_account_mapping()
    application_settings.click_all_users_share_one_name()
    application_settings.set_username(username)
    application_settings.set_password(password)

    application_settings.click_on_advanced()
    application_settings.set_hostname_suffix(hostname)
    application_settings.set_advanced_username(username)
    application_settings.set_advanced_password(password)

    addAppsWindow.click_save_button()
    app_name = "Browser Extension"
    app_id = app_helper.get_app_key_from_app_name(app_name)
    app_helpers['app_helper'].apps_created.append(app_id)

    application_settings.refresh_page()
    application_settings.wait_for_page_to_load(10)
    assert application_settings.validate_app_status() == 'Deployed', f'Expected deployed, found {application_settings.validate_app_status()}'


@pytestrail.case('C26522')
@pytest.mark.pipeline
def test_c26522_deploy_custom_ntlm_and_basic_app(driver, app_helpers):
    """ Deploy custom NTLM and Basic app and launch successfully via UP """
    tenant_info = app_helpers['tenant_info']
    app_helper = app_helpers['app_helper']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_users_tab()
    up_page = UserPortalPage(driver)
    admin_portal_page = AdminPortalPage(driver)
    confirm_user_password_window = ConfirmUsernamePasswordWindow(driver)
    apps_page = AppsPage(driver)
    application_settings = AppDetailsPage(driver)
    addAppsWindow = AddWebAppsWindow(driver)
    select_user_group_role = SelectUserGroupRolePage(driver)
    app_settings = ConfigurableAppSettingsPage(driver)

    url = ' https://caterpillar.centrify.com/cims'
    rolename = 'Everybody'
    app_name = 'Centrify bugzilla'
    username = 'centrify.com'
    password = 'lina'

    admin_portal_page.select_web_apps()

    apps_page.click_add_web_apps_button()

    addAppsWindow.click_custom_tab()
    addAppsWindow.add_featured_app('NTLM and Basic')

    application_settings.set_app_url(url)

    addAppsWindow.click_close_and_save_button()

    application_settings.click_description_tab()
    application_settings.entering_application_name_field(app_name)
    application_settings.click_on_permissions_tab()
    application_settings.click_add_button()
    select_user_group_role.search_for_role(rolename)
    select_user_group_role.select_role_checkbox()
    select_user_group_role.click_on_add_button()

    application_settings.click_on_account_mapping()
    application_settings.is_prompt_for_username_selected()

    addAppsWindow.click_save_button()
    app_id = app_helper.get_app_key_from_app_name(app_name)
    app_helpers['app_helper'].apps_created.append(app_id)

    admin_portal_page.refresh_page()

    application_settings.wait_for_page_to_load()

    portal_switch = PortalSwitcherPopout(driver)
    portal_switch.switch_to_user_portal()

    up_page.wait_for_page_to_load()
    up_page.refresh_page()
    up_page.wait_for_page_to_load(12)
    up_page.search_app_input(app_name)

    expected_text = 'User name/password needed.\n x\nBefore you can launch this application please enter the user name and password. This is required only the first time you launch the application. Do you want to continue?'
    text = confirm_user_password_window.user_password_dialog()
    assert text == expected_text, f'valid message not displayed in dialog, expected {expected_text}, found {text}'

    confirm_user_password_window.click_yes_button()

    app_settings.set_username(username)
    app_settings.set_password(password)
    app_settings.click_save_button()


@pytestrail.case('C76596')
@pytest.mark.pipeline
def test_c76596_add_button_check_on_add_web_apps_page(driver, app_helpers):
    """" This test-case is to check the add button on add web apps page """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    AdminPortalPage(driver).select_web_apps()

    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()

    add_web_apps_window.click_first_apps_add_button()
    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()
    assert add_web_apps_window.is_remove_button_displayed() is True, f'Remove button should be displayed, but not found'


@pytestrail.case('C76599')
@pytest.mark.pipeline
def test_c76599_add_custom_web_app_on_add_web_apps_page(driver, app_helpers):
    """ This test-case is to check the remove button on add web apps page """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.click_custom_tab()

    add_web_apps_window.click_first_apps_add_button()
    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()
    assert add_web_apps_window.is_remove_button_displayed() is True, f'Remove button should be displayed, but not found'


@pytestrail.case('C76598')
@pytest.mark.pipeline
def test_c76598_cancel_add_custom_web_app_on_add_web_apps_page(driver, app_helpers):
    """" This test-case is to cancel the add custom app button on add web apps page """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.click_custom_tab()

    add_web_apps_window.click_first_apps_add_button()
    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()

    add_web_app_dialog.press_no()
    assert add_web_apps_window.is_first_add_button_displayed() is True, f'First add button should be displayed, but not found'
    add_web_app_dialog.press_close()

    WebAppsPage(driver).wait_for_page_to_load()


@pytestrail.case('C76595')
@pytest.mark.pipeline
def test_c76595_search_box_on_add_web_apps_page(driver_admin, app_helpers):
    """" This testcase is search box on add web apps page """
    AdminPortalPage(driver_admin).select_web_apps()
    apps_page = AppsPage(driver_admin)

    invalid_value = 'aaa'
    valid_value = 'face'

    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.wait_for_page_to_load()
    apps_found = len(add_web_apps_window.get_add_buttons())
    assert apps_found == 30, f'30 apps should be displayed, but not found {apps_found}'
    add_web_apps_window.search_for_app(invalid_value)

    exp_msg = "No results were found for app: aaa\n\nSelect the Custom tab to add the app on your own."
    actual_msg = add_web_apps_window.get_invalid_search_message()

    assert add_web_apps_window.get_add_buttons() is None, f'apps should be displayed, but not found'
    assert exp_msg == actual_msg, f'Message incorrect ,expected {exp_msg} , but found {actual_msg}'

    add_web_apps_window.search_for_app(valid_value)
    assert len(add_web_apps_window.get_add_buttons()) >= 1, f'apps should be displayed, but not found'


@pytestrail.case('C27993')
@pytest.mark.pipeline
def test_c27993_deploy_linkedin_application_in_up(driver, app_helpers, auto_clean_app_fixture):
    """ deploy linkedin application in up """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_users_tab()
    admin_portal_page = AdminPortalPage(driver)
    apps_page = AppsPage(driver)
    application_settings = AppDetailsPage(driver)
    select_user_group_role = SelectUserGroupRolePage(driver)

    hostname = 'linkedin.com'
    username = 'myusername'
    password = 'mypassword'
    rolename = 'Everybody'
    valid_value = 'link'
    app_name = f'LinkedIn for {test_id}'

    admin_portal_page.select_web_apps()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.search_for_app(valid_value)
    add_web_apps_window.add_featured_app('LinkedIn')

    application_settings.entering_application_name_field(app_name)
    application_settings.click_on_permissions_tab()
    application_settings.click_add_button()

    select_user_group_role.search_for_role(rolename)
    select_user_group_role.select_role_checkbox()
    select_user_group_role.click_on_add_button()

    application_settings.click_on_advanced()
    application_settings.set_hostname_suffix(hostname)
    application_settings.set_advanced_username(username)
    application_settings.set_advanced_password(password)

    add_web_apps_window.click_save_button()

    application_settings.refresh_page()
    application_settings.wait_for_page_to_load(10)
    assert application_settings.validate_app_status() == 'Deployed', f'Expected deployed, found {application_settings.validate_app_status()}'

    portal_switch = PortalSwitcherPopout(driver)
    portal_switch.switch_to_user_portal()

    up_page = UserPortalPage(driver)
    up_page.wait_for_page_to_load()
    up_page.refresh_page()
    up_page.wait_for_page_to_load()
    assert up_page.is_app_tile_displayed(app_name) is True, f'LinkedIn app should be displayed, but not found'


@pytestrail.case('C1933')
@pytest.mark.pipeline
def test_c1933_cancelling_add_webapp_on_add_web_apps_page(driver, app_helpers):
    """" cancelling add webapp on add web apps page """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)

    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.click_custom_tab()

    add_web_apps_window.click_first_apps_add_button()
    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()

    add_web_app_dialog.press_no()
    assert add_web_apps_window.is_first_add_button_displayed() is True, f'First add button should be displayed, but not found'
    add_web_app_dialog.press_close()

    WebAppsPage(driver).wait_for_page_to_load()


@pytestrail.case('C76602')
@pytest.mark.pipeline
def test_c76602_refreshing_add_web_apps_page(driver, app_helpers):
    """ refreshing add web apps page """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_users_tab()
    admin_portal_page = AdminPortalPage(driver)
    apps_page = AppsPage(driver)

    admin_portal_page.select_web_apps()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    assert add_web_apps_window.is_add_web_apps_header_displayed() is True, f'add web apps header should be displayed, but not found'
    apps_page.refresh_page()
    assert add_web_apps_window.is_add_web_apps_header_displayed() is False, f'add web apps header should not be displayed, but found'


@pytestrail.case('C76719')
@pytest.mark.pipeline
def test_c76719_add_saml_app(driver, app_helpers, auto_clean_app_fixture):
    """ Add a SAML app either 'Salesforce' or 'Netsuite' can be used """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.search_app_input(app_name="Salesforce")
    add_web_apps_window.click_add_for_app_type_from_search("SAML + Provisioning")

    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()
    assert add_web_apps_window.is_remove_button_displayed() | add_web_apps_window.is_app_added() is True, f'Remove button or "Application Added" should be displayed, but not found'
    add_web_apps_window.click_close_button()

    app_details_page = AppDetailsPage(driver)
    app_details_page.wait_for_page_to_load()
    assert app_details_page.get_app_name_as_title() == 'Salesforce', f'Expected app name "Salesforce" is not found, found {app_details_page.get_app_name_as_title()}'
    assert app_details_page.is_settings_tab_focused() is True, f'Expected Settings tab is focused or selected, but found {app_details_page.is_settings_tab_focused()}'


@pytestrail.case('C1999')
@pytest.mark.pipeline
def test_c1999_update_user_attribute_for_app_which_mapped_with_directory_service_field(driver, app_helpers,
                                                                                       new_cloud_user, auto_clean_app_fixture):
    """ Test update user attribute for app which mapped with 'Directory Service Field' """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    appname = "101Domain"
    attribute = "displayname"
    username = new_cloud_user['user']['Name']
    password = new_cloud_user['user']['Password']
    AdminPortalPage(driver).select_web_apps()

    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.search_app_input(appname)
    add_web_apps_window.add_featured_app(appname)

    app_detail_page = AppDetailsPage(driver)
    app_detail_page.wait_for_page_to_load()
    app_detail_page.click_on_permissions_tab()
    app_detail_page.click_add_button()
    select_user_group_role = SelectUserGroupRolePage(driver)
    select_user_group_role.search_for_role('Everybody')
    select_user_group_role.select_role_checkbox()
    select_user_group_role.click_on_add_button()

    app_detail_page.click_on_account_mapping()
    app_detail_page.checked_directory_service_field()
    app_detail_page.clear_directory_service_field()

    assert app_detail_page.is_confirm_error_icon_displayed() is True, f'can save, found cannot save'
    expected_text = 'Please correct the errors in your form before submitting.'

    app_detail_page.click_save_button()

    actual_text = WarningWindow(driver).warning_message_text()
    assert actual_text == expected_text, f'Incorrect message, expected {expected_text}, found {actual_text}'

    WarningWindow(driver).close()
    app_detail_page.wait_for_page_to_load()

    app_detail_page.set_directory_service_field(attribute)
    app_detail_page.click_save_button()
    app_detail_page.refresh_page()
    app_detail_page.wait_for_page_to_load(15)

    APUserProfileMenu(driver).sign_out()
    Login(driver).to_user_portal(username, password)

    UserPortalPage(driver).wait_for_page_to_load(15)
    handles = UserPortalPage(driver).get_window_handles()
    UserPortalPage(driver).launch_app_up(appname)

    ConfirmUsernamePasswordWindow(driver).click_yes_button()

    user_name = ConfigurableAppSettingsPage(driver).get_username()
    assert user_name == new_cloud_user['user']['DisplayName'], \
        f'username not displayed in Username text field, found {user_name},' f' expected {new_cloud_user["user"]["DisplayName"]}'

    ConfigurableAppSettingsPage(driver).set_password(password)
    ConfigurableAppSettingsPage(driver).click_save_button()
    UserPortalPage(driver).switch_to_new_tab_after_app_launch(handles=handles)
    app_url = UserPortalPage(driver).get_app_url().split("?")[0]
    assert app_url == 'https://my.101domain.com/login.html', f'valid url not found, found {app_url}'


@pytestrail.case('C76600')
@pytest.mark.pipeline
def test_c76600_remove_button_check_when_adding_web_app(driver, app_helpers):
    """ remove button check when adding web app """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    admin_portal_page = AdminPortalPage(driver)
    admin_portal_page.select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    actual_apps_list = len(apps_page.get_apps())
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.click_custom_tab()

    add_web_apps_window.click_first_apps_add_button()
    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()

    add_web_app_dialog.press_yes()
    add_web_apps_window.wait_for_page_to_load()

    assert add_web_apps_window.is_remove_button_displayed() is True, f'Remove button should be displayed, but not found'
    add_web_apps_window.click_remove_button()
    assert add_web_apps_window.is_first_add_button_displayed() is True, f'Add button should be displayed, but not found'
    add_web_app_dialog.press_close()

    admin_portal_page = AdminPortalPage(driver)
    admin_portal_page.select_web_apps()

    assert actual_apps_list == len(
        apps_page.get_apps()), f'Apps before adding app are {actual_apps_list} are not same as found {len(apps_page.get_apps())}'


@pytestrail.case('C76604')
@pytest.mark.pipeline
def test_c76604_modify_an_app_in_the_app_web_apps_page(driver, app_helpers):
    """ modify an app in the app web apps page """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_users_tab()
    admin_portal_page = AdminPortalPage(driver)
    apps_page = AppsPage(driver)
    app_details_page = AppDetailsPage(driver)
    select_user_group_role = SelectUserGroupRolePage(driver)

    rolename = 'Everybody'
    valid_value1 = 'conc'
    appname = 'ConceptShare'
    changed_appname = 'ConceptSharechange'

    admin_portal_page.select_web_apps()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.search_for_app(valid_value1)
    add_web_apps_window.add_featured_app('ConceptShare')

    app_details_page.click_on_permissions_tab()
    app_details_page.click_add_button()

    select_user_group_role.search_for_role(rolename)
    select_user_group_role.select_role_checkbox()
    select_user_group_role.click_on_add_button()

    add_web_apps_window.click_save_button()

    app_details_page.refresh_page()
    app_details_page.wait_for_page_to_load(10)
    assert app_details_page.validate_app_status() == 'Deployed', f'Expected deployed, found {app_details_page.validate_app_status()}'

    admin_portal_page.select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.search_for_app(appname)
    apps_page.select_web_app(appname)
    app_details_page.entering_application_name_field(changed_appname)
    app_details_page.click_save_button()

    assert app_details_page.validate_modified_toaster() is True, f'Modified toaster is not displayed'


@pytestrail.case('C76721')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c76721_check_preview_saml_response(driver, app_helpers):
    """ check preview saml response xml when adding saml apps """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.search_app_input(app_name="ADP")
    add_web_apps_window.add_featured_app(app="ADP")

    app_details_page = AppDetailsPage(driver)
    app_details_page.wait_for_page_to_load(wait_time=30)
    assert app_details_page.get_app_name_as_title() == 'ADP', f'Expected app name "ADP" is not found, found {app_details_page.get_app_name_as_title()}'
    assert app_details_page.is_settings_tab_focused() is True, f'Expected Settings tab is focused or selected, but found {app_details_page.is_settings_tab_focused()}'

    app_details_page.click_on_saml_response_tab()
    app_details_page.wait_for_page_to_load()

    app_details_page.click_on_preview_saml_response_button()
    SelectUserSamlResponseDialog(driver).click_on_user(tenant_info['username'])
    SelectUserSamlResponseDialog(driver).click_next_button()
    assert PreviewSAMLResponseDialog(
        driver).is_confirm_preview_saml_response_xml_displayed() is True, f'The preview_saml_respons is not displayed'


@pytestrail.case('C76723')
@pytest.mark.pipeline
def test_c76723_check_inherited_permissions(driver, app_helpers):
    """ Check the linked app inherited permissions """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    AdminPortalPage(driver).select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    add_web_apps_window.search_app_input(app_name="ADP")
    add_web_apps_window.click_first_apps_add_button()

    add_web_app_dialog = AddWebAppDialog(driver)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()

    assert len(add_web_apps_window.get_remove_buttons()) == 1, \
        f'expected count is 1, found {len(add_web_apps_window.get_remove_buttons())}'
    add_web_apps_window.click_close_button()

    app_details_page = AppDetailsPage(driver)
    app_details_page.wait_for_page_to_load(wait_time=30)

    app_details_page.click_on_permissions_tab()
    app_details_page.click_add_button()

    select_user_group_role = SelectUserGroupRolePage(driver)
    select_user_group_role.search_for_role(tenant_info['username'])
    select_user_group_role.select_role_checkbox()
    select_user_group_role.click_on_add_button()

    app_details_page.wait_for_page_to_load(wait_time=10)
    app_details_page.click_linked_applications_tab()
    app_details_page.click_add_button()

    linked_apps_dialog = AddLinkedAppDialog(driver)
    linked_apps_dialog.wait_for_page_to_load()
    linked_apps_dialog.select_first_row()
    linked_apps_dialog.press_finish()
    app_details_page.wait_for_page_to_load(wait_time=10)
    app_details_page.click_save_button()
    app_details_page.refresh_page()
    app_details_page.wait_for_page_to_load(wait_time=30)
    assert app_details_page.validate_app_status() == 'Deployed', \
        f'Expected deployed, found {app_details_page.validate_app_status()}'
    app_details_page.validate_linked_app_window()
    app_details_page.click_on_permissions_tab()
    app_details_page.wait_for_page_to_load(wait_time=10)
    assert app_details_page.is_inherit_parent_permission_checked() is True, \
        f'Inherit Parent Permissions is not checked'
    assert app_details_page.verify_permission_name(name=tenant_info['username']) is True, \
        f"Permission name {tenant_info['username']} is not displayed in Permissions"


@pytestrail.case('C1931')
@pytest.mark.pipeline
def test_c1931_default_ui_check_on_add_web_apps_page(driver, app_helpers, app_templates):
    """ Default UI check while adding web apps covering all the 3 tabs"""
    tenant_info = app_helpers['tenant_info']
    cloud_session = app_helpers['cloud_session']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    admin_portal_page = AdminPortalPage(driver)
    admin_portal_page.select_web_apps()
    apps_page = AppsPage(driver)
    apps_page.wait_for_page_to_load()
    apps_page.click_add_web_apps_button()

    add_web_apps_window = AddWebAppsWindow(driver)
    add_web_apps_window.wait_for_page_to_load(wait_time=30)
    assert add_web_apps_window.is_search_tab_active() is True, f"Search Tab is not active"
    assert add_web_apps_window.is_category_selected(app_category_name='Featured') is True, \
        f"Featured is not selected, found not selected and is " \
        f"{add_web_apps_window.is_category_selected(app_category_name='Featured')}"
    add_web_apps_window.search_app_input(app_name='sa')
    templates = AppHelper(cloud_session).get_templates_and_categories()
    assert len(templates[
                   'Categories']) == 24, f"App Categories are not displayed correct,expected 24, found {len(templates['Categories'])}"

    add_web_apps_window.click_custom_tab()
    actual_apps_list = len(add_web_apps_window.get_add_buttons())
    assert actual_apps_list == len(
        add_web_apps_window.get_apps_help_list()), f'Apps before adding app are {actual_apps_list} are not same as found {len(apps_page.get_apps())}'

    add_web_apps_window.click_import_tab()
    assert add_web_apps_window.is_upload_button_clickable() is True, f'Upload is not clickable'


#TODO remove the need for admin app list to be defined
# @pytestrail.case('C1936')
# @pytest.mark.pipeline
# def test_c1936_validate_pagination_for_app_details_page(driver, app_helpers):
#     """ UI validation of App detail page """
#     tenant_info = app_helpers['tenant_info']
#     Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
#
#     apps_to_use = [{'app': app, 'count': sum(app['Name'] in a['Name'] for a in admin_app_list)} for app in admin_app_list if sum(app['Name'] in a['Name'] for a in admin_app_list) > 1]
#     assert apps_to_use, 'This test requires a tenant with multiple apps in the AP list with the same name'
#     app = apps_to_use[0]
#     app_name = app['app']['DisplayName']
#     apps_page = AppsPage(driver)
#     app_details_page = AppDetailsPage(driver)
#
#     AdminPortalPage(driver).select_web_apps()
#     apps_page.wait_for_page_to_load()
#     apps_page.search_for_app(appname=app_name)
#     label_text_expected_page_1 = f'Application 1 of {app["count"]}'
#     label_text_expected_page_2 = f'Application 2 of {app["count"]}'
#     apps_page.select_web_app(web_app=app_name)
#
#     app_details_page.wait_for_page_to_load(wait_time=AppDetailsPage.LONG_DELAY)
#     label_text_actual = app_details_page.get_counter_label_text()
#     assert label_text_expected_page_1 == label_text_actual, \
#         f"Count-label is not displayed correct, expected {label_text_expected_page_1}, found {label_text_actual}"
#     app_details_page.click_next_page()
#     app_details_page.wait_for_page_to_load()
#     displayed_app_name = app_details_page.get_app_name_as_title()
#     assert app_name in displayed_app_name, \
#         f"Title is not correct, expected {app_name}, found {displayed_app_name}"
#
#     app_details_page.click_previous_page()
#     app_details_page.wait_for_page_to_load()
#     displayed_app_name = app_details_page.get_app_name_as_title()
#     assert app_name in displayed_app_name, \
#         f"Title is not correct, expected {app_name}, found {displayed_app_name}"
#
#     app_details_page.enable_localization()
#     app_details_page.click_next_page()
#
#     unsaved_changes = UnsavedChangesDialog(driver)
#     unsaved_changes.validate_all_elements().validate_all_child_elements()
#     unsaved_changes.cancel_dialog()
#
#     app_details_page.click_next_page()
#     unsaved_changes.discard_changes()
#
#     app_details_page.wait_for_page_to_load()
#     assert app_details_page.get_counter_label_text() == label_text_expected_page_2, \
#         f"Count-label is not displayed correct, expected {label_text_expected_page_2}," \
#         f"found {app_details_page.get_counter_label_text()}"


@pytestrail.case('C76600')
@pytest.mark.pipeline
def test_c76600_remove_button_check_when_adding_custom_web_app(driver, app_helpers):
    """ UI validation of 'Remove' button inside Add Web Apps window """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    AdminPortalPage(driver).select_web_apps()
    web_apps_page = WebAppsPage(driver)
    starting_apps = web_apps_page.get_displayed_apps().__len__()
    web_apps_page.click_add_web_apps()
    add_web_apps_page = AddWebAppsWindow(driver)
    add_web_apps_page.click_custom_tab()
    add_web_apps_page.click_first_apps_add_button()
    AddWebAppDialog(driver).press_yes()
    remove_button = add_web_apps_page.get_remove_buttons()
    assert remove_button.__len__() == 1, 'Unexpected result. There is not one remove button available'
    add_web_apps_page.click_remove_button()
    add_web_apps_page.click_close_button()
    ending_apps = web_apps_page.refresh_page().get_displayed_apps().__len__()
    assert starting_apps == ending_apps, 'Unexpected result, unequal number of apps before and after'


@pytestrail.case('C76601')
@pytest.mark.pipeline
def test_c76601_import_custom_app(driver, app_helpers, auto_clean_app_fixture):
    """ UI validation of Importing a custom Web App """
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    AdminPortalPage(driver).select_web_apps()
    web_apps_page = WebAppsPage(driver)
    starting_app_count = get_displayed_apps_count(web_apps_page, "Bookmark", starting=True)
    web_apps_page.click_add_web_apps()
    add_web_apps_page = AddWebAppsWindow(driver)
    add_web_apps_page.click_import_tab()
    add_web_apps_page.set_filename(get_import_app_file_path('Apps20200311190334.zip'))
    add_web_apps_page.click_close_button()
    Navigate(driver).to_web_app_tab()
    web_apps_page.refresh_page()
    ending_app_count = get_displayed_apps_count(web_apps_page, "Bookmark", starting=False)
    assert ending_app_count > starting_app_count, f'Expected one additional app, end: {ending_app_count}, start {starting_app_count}'


@pytestrail.case('C45563')
@pytest.mark.pipeline
def test_c45563_deploy_saml_app_nonworking(driver_admin, auto_clean_app_fixture, app_helpers):
    """ UI validation of Deploying a custom SAML app """
    admin_page = AdminPortalPage(driver_admin)
    admin_page.select_web_apps()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.click_add_web_apps()
    add_web_apps_page = AddWebAppsWindow(driver_admin)
    add_web_apps_page.click_custom_tab()
    add_web_apps_page.click_add_generic_saml_app()
    add_web_app_dialog = AddWebAppDialog(driver_admin)
    add_web_app_dialog.wait_for_page_to_load()
    add_web_app_dialog.press_yes()
    add_web_apps_page.click_close_button()
    app_details_page = AppDetailsPage(driver_admin)
    app_details_page.wait_for_page_to_load()
    app_details_page.entering_application_name_field(f"SAML - {app_helpers['test_id']}")
    app_details_page.click_trust_tab()
    trust_page = SAMLAppGatewayTrustPage(driver_admin)
    trust_page.wait_for_page_to_load()
    trust_page.click_sp_manual_config()
    trust_page.input_sp_urls("https://duckduckgo.com")
    app_details_page.click_save_button()
    app_details_page.wait_for_page_to_load(12)
    app_details_page.click_on_permissions_tab()
    permissions_page = SAMLAppGatewayPermissionsPage(driver_admin)
    permissions_page.click_add_button()
    user_group_role_page = SelectUserGroupRolePage(driver_admin)
    user_group_role_page.search_for_role("Everybody")
    user_group_role_page.select_role_checkbox()
    user_group_role_page.click_on_add_button()
    app_details_page.click_save_button()
    admin_page.select_web_apps()
    admin_page.refresh_page()
    web_apps_page.search_for_app(f"SAML - {app_helpers['test_id']}")
    apps = web_apps_page.get_displayed_apps()
    assert apps[0][0].lstrip() == f"SAML - {app_helpers['test_id']}" and apps[0][3].lstrip() == 'Deployed'


@pytestrail.case('C117733')
@pytest.mark.pipeline
def test_c117733_check_custom_wsfed_app_for_linked_app_tab(driver, auto_clean_app_fixture, app_helpers):
    """ UI validation of checking custom ws-fed app type to make sure it has a 'linked app' tab """
    create_generic_app("GenericWsFed", app_helpers)
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    admin_page = AdminPortalPage(driver)
    admin_page.select_web_apps()
    WebAppsPage(driver)

    WebAppsPage(driver).search_for_app('WS-Fed').click_specific_app('WS-Fed')
    app_detail_page = AppDetailsPage(driver)
    assert app_detail_page.is_linked_app_available() is True, "Expected linked app to be available"


@pytestrail.case('C119415')
@pytest.mark.pipeline
def test_c119415_check_custom_saml_app_for_linked_app_tab(app_helpers, driver_admin, auto_clean_app_fixture):
    """ UI validation of checking custom SAML app type to make sure it has a 'linked app' tab """
    app_helper = app_helpers['app_helper']
    saml_app = app_helper.import_app_by_name("Generic SAML")
    app = GenericSamlApp("https://www.google.com", saml_app) \
        .with_name(f"SAML - {app_helpers['test_id']}") \
        .to_payload()
    app_helper.update_application_de(app)
    Navigate(driver_admin).to_web_app_tab()
    WebAppsPage(driver_admin).search_for_app(f"SAML - {app_helpers['test_id']}")\
        .click_specific_app(f"SAML - {app_helpers['test_id']}")
    app_detail_page = AppDetailsPage(driver_admin)
    assert app_detail_page.is_linked_app_available() is True, "Expected linked app to be available"


@pytestrail.case('C119416')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c119416_check_catalog_saml_app_for_linked_app_tab(driver_admin, app_helpers, auto_clean_app_fixture):
    """ UI validation of checking catalog saml app type to make sure it has a 'linked app' tab """
    create_generic_app("ServiceNow", app_helpers)
    go_to_apps_tab(driver_admin)
    WebAppsPage(driver_admin).search_for_app('ServiceNow').click_specific_app('ServiceNow')
    app_detail_page = AppDetailsPage(driver_admin)
    assert app_detail_page.is_linked_app_available() is True, "Expected linked app to be available"


@pytestrail.case('C119417')
@pytest.mark.pipeline
def test_c119417_check_catalog_wsfed_app_for_linked_app_tab(driver_admin, auto_clean_app_fixture, app_helpers):
    """ UI validation of checking catalog wsfed app type to make sure it has a 'linked app' tab """
    create_generic_app("KnowledgeVaultWsFed", app_helpers)
    go_to_apps_tab(driver_admin)
    search_page = WebAppsPage(driver_admin)
    search_page.wait_for_page_to_load(required=False)
    search_page.search_for_app('Knowledge Vault')
    search_page.click_specific_app('Knowledge Vault')
    app_detail_page = AppDetailsPage(driver_admin)
    assert app_detail_page.is_linked_app_available() is True, "Expected linked app to be available"


@pytestrail.case('C119418')
@pytest.mark.pipeline
def test_c119418_check_custom_openid_app_for_linked_app_tab(driver_admin, auto_clean_app_fixture, app_helpers):
    """ UI validation of checking custom openid connect app type to make sure it has a 'linked app' tab """
    create_generic_app("Generic OpenID Connect", app_helpers)
    go_to_apps_tab(driver_admin)
    search_page = WebAppsPage(driver_admin)
    search_page.wait_for_page_to_load(required=False)
    search_page.search_for_app('OpenID Connect')
    search_page.click_specific_app('OpenID Connect')
    app_detail_page = AppDetailsPage(driver_admin)
    assert app_detail_page.is_linked_app_available() is True, "Expected linked app to be available"


@pytestrail.case('C117735')
@pytest.mark.pipeline
def test_c117735_parent_app_has_no_default_linked_apps(driver_admin, auto_clean_app_fixture, app_helpers):
    """ UI validation of checking that the parent app doesn't have pre-canned linked apps"""
    create_generic_app("Generic SAML", app_helpers)
    go_to_apps_tab(driver_admin)
    web_app_page = WebAppsPage(driver_admin)
    web_app_page.search_for_app('SAML').click_specific_app('SAML')
    app_detail_page = AppDetailsPage(driver_admin)
    app_detail_page.click_linked_applications_tab()
    linked_apps_page = SAMLAppGatewayLinkedAppsPage(driver_admin)
    linked_apps_page.click_add_linked_app()
    linked_apps_page.set_linked_app_name('SAML Linked Test')
    linked_apps_page.set_linked_app_url('https://www.google.com')
    linked_apps_page.click_finish_button()
    assert linked_apps_page.get_linked_app_status("SAML Linked Test") == "New", "Expected status to be 'New'"
    app_detail_page.click_save_button()
    Navigate(driver_admin).to_web_app_tab()
    Navigate(driver_admin).to_web_app_tab()
    apps = web_app_page.refresh_page().search_for_app('SAML Linked Test').get_displayed_apps()
    assert apps[0][0].lstrip() == 'SAML: SAML Linked Test', "Expected SAML: SAML Linked Test"
    assert apps[0][3].lstrip() == 'Ready to Deploy', "Expected: Ready to Deploy"


# @pytestrail.case('C00000')
# def test_c117737_retain_parent_icon_when_child_app_deleted(driver_admin, auto_clean_app_fixture, app_helpers):
#     """ UI validation of checking that Parent App Icon is retained when child linked app is modified / deleted"""
#     create_generic_app("Generic SAML", app_helpers)
#     create_generic_app("GenericWsFed", app_helpers)
#     go_to_apps_tab(driver_admin)
#     web_app_page = WebAppsPage(driver)
#     web_app_page.click_specific_app('SAML')
#     app_detail_page = AppDetailsPage(driver)
#     raise NotImplementedError

# TODO Need to make this more flexible for Staging and/or Prod.  I think URL's are different with different environments
@pytestrail.case('C68323')
@pytest.mark.pipeline
def test_c68323_check_configuration_help_link_(driver_admin, auto_clean_app_fixture, app_helpers):
    """ UI validation of checking that the 'Configuration Help' link works for 101Domain app"""
    go_to_apps_tab(driver_admin)
    web_app_page = WebAppsPage(driver_admin)
    web_app_page.click_add_web_apps()
    add_web_apps_window = AddWebAppsWindow(driver_admin)
    add_web_apps_window.wait_for_page_to_load()
    add_web_apps_window.search_for_app('101Domain')
    add_web_apps_window.click_first_apps_add_button()
    AddWebAppDialog(driver_admin).press_yes()

    add_web_apps_window.click_close_button()
    app_detail_page = AppDetailsPage(driver_admin)
    expected_url = 'https://docs-staging.conjur.org/Idaptive/Dev/en/Content/Applications/AppsCustom/AddUserPassApps.htm?cshid=1034'
    current_url = app_detail_page.validate_101domain_configuration_help_link()
    assert current_url == expected_url, f"Unexpected URL returned: {current_url}"

