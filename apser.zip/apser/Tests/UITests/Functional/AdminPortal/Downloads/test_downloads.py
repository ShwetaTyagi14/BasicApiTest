from idaptive_testrail.plugin import pytestrail
import pytest
from Helpers.general_helpers import verify_url
from idaptive_automation.ui_automation import DownloadsPage
from Steps.navigate_steps import Navigate
from Fixtures.sessions_and_helpers import *


@pytestrail.case('C45588')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c45588_download_connector_from_downloads_page(app_helpers, driver_admin):
    Navigate(driver_admin).to_downloads_page()
    href = DownloadsPage(driver_admin).get_connector_href()
    verify_url(href)
