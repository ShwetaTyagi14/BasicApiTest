from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import PortalSwitcherPopout, AdminPortalPage
from idaptive_automation.ui_automation.pages.profilemenu.left_nav_pinning import LeftNavPinning
from idaptive_automation.ui_automation.pages.profilemenu.user_profile_menu import UserProfileMenu
from Steps.navigate_steps import Navigate
from Steps.left_nav_steps import left_nav_should_be_unpinned_state, left_nav_should_be_pinned_state
from Helpers.test_data_helper import load_json_test_data_file
from Fixtures.tenant_fixtures import left_nav_pinning_state_fixture


@pytestrail.case('C168259')
def test_c168259_unpinned_left_nav_shrinks_when_not_mouseover(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)
    left_nav.set_to_pinned()
    user_profile.click_profile()
    nav_size_pinned = left_nav.get_left_nav_size()
    pinned_width = int(nav_size_pinned['width'][:-2])
    assert pinned_width == nav_size['pinned_width'], \
        f"Expected width {nav_size['pinned_width']}, got {nav_size_pinned['width']}"
    left_nav.set_to_unpinned()
    user_profile.click_profile()
    nav_size_unpinned = left_nav.get_left_nav_size()
    unpinned_width = int(nav_size_unpinned['width'][:-2])
    assert unpinned_width == nav_size['unpinned_width'], \
        f"Expected width of {nav_size['unpinned_width']}, got {nav_size_unpinned['width']}"


@pytestrail.case('C168258')
def test_c168258_unpinned_left_nav_expands_when_mouseover(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)

    left_nav.set_to_unpinned()

    left_nav_should_be_unpinned_state(user_profile, left_nav, nav_size)


@pytestrail.case('C168257')
def test_c168257_pinned_nav_box_doesnt_shrink(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)

    left_nav.set_to_pinned()

    left_nav_should_be_pinned_state(user_profile, left_nav, nav_size)


@pytestrail.case('C178346')
def test_c178346_pinned_nav_should_stay_pinned_after_switching_portal(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)

    left_nav.set_to_pinned()

    left_nav_should_be_pinned_state(user_profile, left_nav, nav_size)

    Navigate(driver_admin).to_user_portal_via_url()

    left_nav_should_be_pinned_state(user_profile, left_nav, nav_size)


@pytestrail.case('C178347')
def test_c178347_unpinned_nav_should_stay_unpinned_after_switching_portal(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)

    left_nav.set_to_unpinned()

    left_nav_should_be_unpinned_state(user_profile, left_nav, nav_size)

    Navigate(driver_admin).to_user_portal_via_url()

    left_nav_should_be_unpinned_state(user_profile, left_nav, nav_size)


@pytestrail.case('C178348')
def test_c178348_pinned_nav_should_stay_pinned_after_reload_page(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)
    admin_portal_page = AdminPortalPage(driver_admin)

    left_nav.set_to_pinned()

    left_nav_should_be_pinned_state(user_profile, left_nav, nav_size)

    admin_portal_page.refresh_page()

    left_nav_should_be_pinned_state(user_profile, left_nav, nav_size)


@pytestrail.case('C178349')
def test_c178349_unpinned_nav_should_stay_unpinned_after_reload_page(left_nav_pinning_state_fixture, driver_admin):
    nav_size = load_json_test_data_file("left_nav_size.json", sub_dir="AdminPortal")
    left_nav = LeftNavPinning(driver_admin)
    user_profile = UserProfileMenu(driver_admin)
    admin_portal_page = AdminPortalPage(driver_admin)

    left_nav.set_to_unpinned()

    left_nav_should_be_unpinned_state(user_profile, left_nav, nav_size)

    admin_portal_page.refresh_page()

    left_nav_should_be_unpinned_state(user_profile, left_nav, nav_size)
