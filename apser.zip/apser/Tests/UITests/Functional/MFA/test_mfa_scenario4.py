from idaptive_testrail.plugin import pytestrail
import pytest
import sys
from Steps.navigate_steps import Login
from idaptive_automation.ui_automation import UserProfileMenu, AdminPortalPage, APUserProfileMenu, \
    AdditionalAuthenticationPage
from Steps.mfa_steps import create_mfa_admin


# TODO These tests should be moved to the MFA team, Marking all as not to run in pipeline

@pytestrail.case('C86693')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c86693_idaptive_admin_portal_mfa_mfa(app_helpers, driver):
    """ Idaptive Admin Portal MFA - MFA and validate User able to login into AP successfully """
    tenant_info = app_helpers['tenant_info']
    user = create_mfa_admin('mfa_scenario4', app_helpers, security_question=True)
    sec_question = user['sec_questions']
    Login(driver, tenant_info['base_url']) \
        .to_user_portal(user['Name'], user['Password'])

    UserProfileMenu(driver).switch_to_admin_portal()
    AdditionalAuthenticationPage(driver)\
        .answer_mfa_challenge('Security Question', sec_question)
    assert AdminPortalPage(driver).validate_admin_welcome_page() is True, \
        f'Switch to Admin Portal Failed, found Switch to Admin Portal Succeeds'


@pytestrail.case('C86695')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c86695_idaptive_admin_portal_mfa_mfa_no_passthrough(driver, app_helpers):
    """ Idaptive Admin Portal MFA - MFA + No Passthrough and User able to login into AP successfully """
    tenant_info = app_helpers['tenant_info']
    user = create_mfa_admin('mfa_scenario4', app_helpers, security_question=True)
    sec_question = user['sec_questions']
    Login(driver, tenant_info['base_url']) \
        .to_user_portal(user['Name'], user['Password'])

    UserProfileMenu(driver).switch_to_admin_portal()
    AdditionalAuthenticationPage(driver)\
        .answer_mfa_challenge('Security Question', sec_question)
    assert AdminPortalPage(driver).validate_admin_welcome_page() is True, \
        f'Switch to Admin Portal Failed, found Switch to Admin Portal Succeeds'

    AdminPortalPage(driver).close_admin_welcome_page()
    APUserProfileMenu(driver).sign_out()

    Login(driver).to_user_portal(user['Name'], user['Password'])
    UserProfileMenu(driver).switch_to_admin_portal()
    AdditionalAuthenticationPage(driver)\
        .answer_mfa_challenge('Security Question', sec_question)

    assert AdminPortalPage(driver).is_admin_portal_displayed() is True, \
        f'User unable to login into AP, found User able to logged into AP'
