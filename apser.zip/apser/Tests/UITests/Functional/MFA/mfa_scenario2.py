import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Login
from idaptive_automation.ui_automation import AdminPortalPage, UserProfileMenu
from Steps.mfa_steps import create_mfa_user
from Helpers.test_data_helper import load_json_test_data_file


@pytestrail.case('C86692')
def test_c86692_idaptive_admin_portal_mfa_always_allowed(driver, app_helpers):
    """ Idaptive Admin Portal MFA - Always Allowed and validate Switch to Admin Portal Succeeds.  """
    tenant_info = app_helpers['tenant_info']
    user = create_mfa_user('mfa_scenario2', app_helpers)
    Login(driver, tenant_info['base_url']).to_user_portal(user['Name'], user['Password'])

    UserProfileMenu(driver).switch_to_admin_portal()
    assert AdminPortalPage(driver).validate_admin_welcome_page() is True, f'Switch to Admin Portal Failed, found Switch to Admin Portal Succeeds'