""" This file is being pulled out of cicrulation pending review with the MFA team for potential duplicate coverage"""
# from idaptive_testrail.plugin import pytestrail
# import pytest
# from Steps.navigate_steps import Login, MfaLogin, Navigate, MfaNavigate
# from idaptive_automation.api_helpers import EmailHelper
# from idaptive_automation.ui_automation import MfaAuthFailedPage, AdminPortalPage
# from Steps.mfa_steps import create_mfa_admin
# from Fixtures.policy_fixtures import mfa_profile
# import time
# import json
#
#
# #TODO Update Email stuff once that is ready for c40286, C40287, and C40289
#
#
# class TestMfaChallenge:
#
#     @pytestrail.case('C40286')
#     @pytest.mark.pipeline
#     def test_c40286_login_to_admin_portal_mfa_challenge_happy_path(self, app_helpers, driver):
#         user = create_mfa_admin('admin_mfa_access', app_helpers)
#         tenant_info = app_helpers['tenant_info']
#         sec_question = user['sec_questions']
#         timestamp = int(time.time())
#         email_suffix = user['Mail'].split('@')[1]
#         mfa_login = MfaLogin(driver, tenant_info['base_url'], ['Security Question'])\
#             .to_admin_portal_with_up_mfa_challenge(user['Name'],
#                                                    user['Password'],
#                                                    'Security Question',
#                                                    sec_question,
#                                                    f'Email - ***@{email_suffix}')
#
#         # query = {
#         #     'date.received': {'$gt': timestamp},
#         #     'emailType': 'portal mfa',
#         #     'username': user['Name']
#         # }
#         # messages = EmailHelper(None).wait_for_message(query)
#         # assert messages is not None and len(messages) == 1, \
#         #     f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         # mfa_login.enter_mfa_code(messages[0]['mfaCode'])
#
#     @pytestrail.case('C40287')
#     @pytest.mark.pipeline
#     def test_c40287_user_portal_to_admin_portal_via_url_happy_path(self,
#                                                                    admin_portal_mfa_challenge,
#                                                                    function_driver,
#                                                                    tenant_info):
#         user = admin_portal_mfa_challenge['user']
#         sec_question = admin_portal_mfa_challenge['sq']
#         mfa_login = MfaLogin(function_driver, tenant_info['base_url'], ['Security Question'])
#         mfa_login.to_user_portal(user['Name'],
#                                  user['Password'],
#                                  'Security Question',
#                                  [sec_question])
#         MfaNavigate(function_driver).to_admin_portal_via_url()
#         timestamp = int(time.time())
#         email_suffix = user['Mail'].split('@')[1]
#         mfa_login.execute_mfa_authentication(f'Email - ***@{email_suffix}',)
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'portal mfa',
#             'username': user['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=int(tenant_info['wait_secs_for_email']))
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         mfa_login.enter_mfa_code(messages[0]['mfaCode'])
#
#     @pytestrail.case('C40289')
#     @pytest.mark.pipeline
#     def test_c40289_user_portal_to_admin_portal_via_menu_option_happy_path(self,
#                                                                            admin_portal_mfa_challenge,
#                                                                            function_driver,
#                                                                            tenant_info):
#         user = admin_portal_mfa_challenge['user']
#         sec_question = admin_portal_mfa_challenge['sq']
#         mfa_login = MfaLogin(function_driver, tenant_info['base_url'], ['Security Question'])
#         mfa_login.to_user_portal(user['Name'],
#                                  user['Password'],
#                                  'Security Question',
#                                  [sec_question])
#         MfaNavigate(function_driver).to_admin_portal_via_menu()
#         timestamp = int(time.time())
#         mfa_login.execute_mfa_authentication('Email - ***@gmail.com')
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'portal mfa',
#             'username': user['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=int(tenant_info['wait_secs_for_email']))
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         mfa_login.enter_mfa_code(messages[0]['mfaCode'])
#
#     @pytestrail.case('C40290')
#     @pytest.mark.pipeline
#     def test_c40290_user_portal_to_admin_portal_failed_mfa_challenge(self, app_helpers, driver):
#         user = create_mfa_admin('admin_mfa_access', app_helpers)
#         tenant_info = app_helpers['tenant_info']
#         sec_question = user['sec_questions']
#         mfa_login = MfaLogin(driver, tenant_info['base_url'], ['Security Question'])
#         mfa_login.to_user_portal(user['Name'],
#                                  user['Password'],
#                                  'Security Question',
#                                  sec_question)
#         MfaNavigate(driver).to_admin_portal_via_menu()
#         mfa_login.execute_mfa_authentication('Email - ***@test.test').enter_mfa_code('mfaCode', False)
#         MfaAuthFailedPage(driver).wait_for_page_to_load()
#         Navigate(driver).to_user_portal_via_url()
#
#
# @pytestrail.case('C40292')
# @pytest.mark.pipeline
# def test_c40292_login_to_user_portal_via_admin_portal_mfa_authentication_profile_happy_path(app_helpers, driver):
#     user = create_mfa_admin('admin_mfa_access', app_helpers)
#     tenant_info = app_helpers['tenant_info']
#     sec_question = user['sec_questions']
#     mfa_login = MfaLogin(driver, tenant_info['base_url'], ['Security Question'])
#     mfa_login.to_user_portal(user['Name'],
#                              user['Password'],
#                              'Security Question',
#                              sec_question)
#     MfaNavigate(driver).to_admin_portal_via_url()
#     AdminPortalPage(driver).wait_for_page_to_load()
#
#
# @pytestrail.case('C40294')
# @pytest.mark.pipeline
# def test_c40294_login_to_admin_portal_no_mfa_challenge_happy_path(driver, app_helpers):
#     tenant_info = app_helpers['tenant_info']
#     Login(driver, tenant_info['base_url'])\
#         .to_admin_portal(tenant_info['username'],
#                          tenant_info['password'])
#
#
# @pytestrail.case('C40288')
# @pytest.mark.pipeline
# def test_c40288_user_portal_to_admin_portal_via_url_no_mfa_challenge_option_happy_path(driver, app_helpers):
#     tenant_info = app_helpers['tenant_info']
#     Login(driver, tenant_info['base_url']) \
#         .to_user_portal(tenant_info['username'],
#                         tenant_info['password'])
#
#     Navigate(driver).to_admin_portal_via_url()
#
#
# @pytestrail.case('C40291')
# @pytest.mark.pipeline
# def test_c40291_user_portal_to_admin_portal_via_menu_option_no_mfa_challenge_option_happy_path(driver, app_helpers):
#     tenant_info = app_helpers['tenant_info']
#     Login(driver, tenant_info['base_url']) \
#         .to_user_portal(tenant_info['username'],
#                         tenant_info['password'])
#
#     Navigate(driver).to_admin_portal()
