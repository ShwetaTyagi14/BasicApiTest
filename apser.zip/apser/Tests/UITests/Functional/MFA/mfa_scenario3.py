from idaptive_automation.ui_automation import UserPortalPage
from idaptive_testrail.plugin import pytestrail
import pytest
from Steps.navigate_steps import MfaLogin
from Steps.mfa_steps import create_mfa_user


@pytestrail.case('C76586')
def test_c76586_mfa_policy_applied_to_role_with_cloud_user_happy_path(driver, app_helpers):
    """ MFA policy applied to role with cloud user - happy path and
        validate User logged into UP successfully with MFA """
    user = create_mfa_user('mfa_scenario3', app_helpers)
    mfa_login = MfaLogin(driver, app_helpers['tenant_info']['base_url'], ['Security Question'])
    mfa_login.to_user_portal(user['Name'],
                             user['Password'],
                             'Security Question',
                             user['sec_questions'])

    assert UserPortalPage(driver).get_user_display_text() == user["DisplayName"], \
        f'User is not logged into UP, expected {user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'
