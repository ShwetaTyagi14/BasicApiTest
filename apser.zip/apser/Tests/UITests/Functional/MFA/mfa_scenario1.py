from idaptive_testrail.plugin import pytestrail
import pytest
from Steps.navigate_steps import Login
from idaptive_automation.ui_automation import UserProfileMenu, ErrorDialog
from Steps.mfa_steps import create_mfa_user
from Helpers.test_data_helper import load_json_test_data_file


@pytestrail.case('C86691')
def test_c86691_idaptive_admin_portal_mfa_not_allowed(driver, app_helpers):
    """ Idaptive Admin Portal MFA - Not Allowed and validate Switch to Admin Portal Fails message """
    tenant_info = app_helpers['tenant_info']
    user = create_mfa_user('mfa_scenario1', app_helpers)
    Login(driver, tenant_info['base_url']).to_user_portal(user['Name'], user['Password'])

    UserProfileMenu(driver).switch_to_admin_portal()
    assert ErrorDialog(driver).validate_error401_message() is True, f'Switch to Admin Portal Succeeds, found Switch to Admin Portal Fails. '


@pytestrail.case('C86694')
def test_c86694_idaptive_admin_portal_mfa_not_allowed(driver, app_helpers):
    """ Idaptive Admin Portal MFA - Not Allowed - Login Direct to /admin and
        validate Switch to Admin Portal Fails message"""
    tenant_info = app_helpers['tenant_info']
    user = create_mfa_user('mfa_scenario1', app_helpers)
    Login(driver, tenant_info['base_url']).to_admin_portal_via_not_allowed_policy(user['Name'], user['Password'])

    assert ErrorDialog(driver).validate_error401_message() is True, f'Switch to Admin Portal Succeeds, found Switch to Admin Portal Fails. '