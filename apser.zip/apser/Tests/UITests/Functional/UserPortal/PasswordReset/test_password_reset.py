from idaptive_automation.ui_automation.pages.userportal.account_page import UserPortalAccountPage
from idaptive_automation.ui_automation.pages.userportal.change_password_dialog import ChangePasswordDialog
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation.pages.reset_your_password_window import ResetYourPasswordWindow
from idaptive_automation.ui_automation.pages.sign_in_page_after_change_password import SignInWithNewPassword
from idaptive_automation.ui_automation.pages.error_dialog import ErrorDialog
from idaptive_automation.ui_automation import UserProfileMenu, APUserProfileMenu, UserPortalPage, SignInPage
import pytest
from Steps.navigate_steps import Login, Navigate
from Steps.user_steps import change_user_full_service


@pytestrail.case('C76680')
@pytest.mark.pipeline
def test_c76680_change_password_successfully(driver, cloud_user):
    """ Change password successfully and validate user able to login into UP successfully or not """
    username = cloud_user['Name']
    password = cloud_user['Password']
    new_password = 'TESTtest1234'
    confirm_password = 'TESTtest1234'

    Login(driver).to_user_portal(username, password)
    UserPortalPage(driver).wait_for_page_to_load()
    UserPortalPage(driver).click_account_tab()
    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(password)
    ChangePasswordDialog(driver).set_new_password(new_password)
    ChangePasswordDialog(driver).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver).click_ok_button()

    UserPortalAccountPage(driver).wait_for_page_to_load()

    UserProfileMenu(driver).sign_out()

    SignInPage(driver).login(username, password)

    assert SignInPage(driver).is_authentication_failure_message_displayed() is True, f'User able to login, found Authentication failed'

    SignInPage(driver).login_after_change_password(new_password)
    UserPortalPage(driver).wait_for_page_to_load()

    assert UserPortalPage(driver).get_user_display_text() == cloud_user['DisplayName'], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'


@pytestrail.case('C76683')
@pytest.mark.pipeline
def test_c76683_cancel_password_successfully(driver,
                                             cloud_user):
    """ Cancel password successfully and validate user able to login into UP successfully or not """
    username = cloud_user['Name']
    password = cloud_user['Password']
    new_password = 'TESTtest1234'
    confirm_password = 'TESTtest1234'

    Login(driver).to_user_portal(username, password)
    UserPortalPage(driver).wait_for_page_to_load()
    UserPortalPage(driver).click_account_tab()
    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(password)
    ChangePasswordDialog(driver).set_new_password(new_password)
    ChangePasswordDialog(driver).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver).click_cancel_button()

    UserPortalAccountPage(driver).wait_for_page_to_load()

    UserProfileMenu(driver).sign_out()

    SignInPage(driver).login(username, new_password)

    assert SignInPage(driver).is_authentication_failure_message_displayed() is True, f'User able to login, found Authentication failed'

    SignInPage(driver).login_after_change_password(password)
    UserPortalPage(driver).wait_for_page_to_load()

    assert UserPortalPage(driver).get_user_display_text() == cloud_user['DisplayName'], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'


@pytestrail.case('C76684')
@pytest.mark.pipeline
def test_c76684_change_password_with_invalid_current_password_negative_test(driver,
                                                                            cloud_user):
    """ Change password with invalid current password - negative test and validate error message """
    username = cloud_user['Name']
    password = cloud_user['Password']
    new_password = 'TESTtest1234'
    confirm_password = 'TESTtest1234'
    bad_password = "BADPASSWORD"

    Login(driver).to_user_portal(username, password)
    UserPortalPage(driver).wait_for_page_to_load()
    UserPortalPage(driver).click_account_tab()
    UserPortalAccountPage(driver).click_password_edit_button()

    ChangePasswordDialog(driver).wait_for_page_to_load()
    ChangePasswordDialog(driver).set_current_password(bad_password)
    ChangePasswordDialog(driver).set_new_password(new_password)
    ChangePasswordDialog(driver).set_confirm_password(confirm_password)
    ChangePasswordDialog(driver).click_ok_button()

    #TODO Update wait for page to load xpaths
    ErrorDialog(driver).wait_for_page_to_load()
    expected_error_text = 'Password update failed. Please make sure the current password is correct.'
    actual_error_text = ErrorDialog(driver).get_error_message()
    assert actual_error_text == expected_error_text, f'Current password is valid, expected{expected_error_text}, found{actual_error_text}'


@pytestrail.case('C76691')
@pytest.mark.pipeline
def test_c76691_cloud_user_requirement_to_change_password_persists_across_multiple_logins(app_helpers, driver, driver2,
                                                                                          cloud_user):
    """ Cloud user requirement to change password persists across multiple logins and validate
        user is required to change password and login successfully in UP """
    change_user_full_service(app_helpers, cloud_user['uuid'], {"PasswordNeverExpire": False,
                                                               "ForcePasswordChangeNext": True})

    new_password = "Idap@123"
    confirm_password = "Idap@123"

    Login(driver).to_user_portal_via_reset_password(cloud_user['Name'], cloud_user['Password'])

    ResetYourPasswordWindow(driver).wait_for_page_to_load()
    ResetYourPasswordWindow(driver).close_browser()

    Login(driver2).to_user_portal_via_reset_password(cloud_user['Name'], cloud_user['Password'])

    ResetYourPasswordWindow(driver2).wait_for_page_to_load()
    ResetYourPasswordWindow(driver2).set_new_password(new_password)
    ResetYourPasswordWindow(driver2).set_confirm_password(confirm_password)
    ResetYourPasswordWindow(driver2).click_next_button()

    expected_message = 'Password change was successful, please authenticate with your new credentials.'
    actual_message = ResetYourPasswordWindow(driver2).get_change_password_successfully_message()
    assert actual_message == expected_message, f'Incorrect message, found {actual_message}, expected {expected_message}'
    ResetYourPasswordWindow(driver2).click_start_over()

    SignInWithNewPassword(driver2).wait_for_page_to_load()
    actual_text = SignInWithNewPassword(driver2).get_username_text()
    assert actual_text == cloud_user["Name"], f'username is not populated in the User Name filed, found {actual_text}, expected {cloud_user["DisplayName"]}'

    SignInWithNewPassword(driver2).wait_for_page_to_load()
    SignInWithNewPassword(driver2).click_user_next_button()
    SignInWithNewPassword(driver2).set_password(new_password)
    SignInWithNewPassword(driver2).click_password_next_button()

    UserPortalPage(driver2).wait_for_page_to_load()
    displayed_name = UserPortalPage(driver2).get_user_display_text()
    assert displayed_name == cloud_user["DisplayName"], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {displayed_name}'
