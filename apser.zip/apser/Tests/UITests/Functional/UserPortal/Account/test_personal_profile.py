from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation.pages.userportal.account_page import UserPortalAccountPage
from idaptive_automation.ui_automation import UserPortalPage
from Helpers.general_helpers import random_password
from Steps.navigate_steps import Login
from Steps.ui_user_steps import user_portal_ad_mobile_number_validation
import uuid

@pytestrail.case('C173592')
def test_c173592_AD_user_profile_mobile_number_validation(driver, app_helpers, lcm_helpers):
    key = "Core.DirectoryServices.ActiveDirectory.Writable"
    app_helpers['tenant_helper'].update_tenant_flag(key, value=True)
    domain_worker = lcm_helpers['active_directory_helper']
    password = random_password()
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, password)
    ad_user = f"{base_name}user1"
    ou = domain_worker.created_ou_list[0].split(',')
    uid = domain_worker.get_ad_user_attribute(f'{ad_user}', ou[0], 'objectGUID')
    uid = uid.values[0][1:-1]
    tenant_info = app_helpers['tenant_info']
    user_helper = app_helpers['user_helper']
    Login(driver, tenant_info['base_url']).to_user_portal(ad_user, password, wait_for_load_up=False)
    UserPortalPage(driver).click_account_tab()
    UserPortalAccountPage(driver).click_personal_profile_tab()
    mobile_numbers = ['a2367b1234', '5555555555555555555555555555555555555555555555555', '22', '209-231-2343',
                       '+4455366789', '+912345678978']
    user_portal_ad_mobile_number_validation(driver, mobile_numbers, password)
