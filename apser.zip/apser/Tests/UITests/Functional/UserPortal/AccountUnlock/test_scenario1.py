from idaptive_testrail.plugin import pytestrail
import pytest
from idaptive_automation.ui_automation import UserProfileMenu, SignInPage
from Steps.navigate_steps import Login
from Steps.policy_steps import add_user_to_policy


@pytestrail.case('C93678')
@pytest.mark.pipeline
def test_c93678_unlock_cloud_user_with_cookie_and_pwd_only_unlock_profile_negative_test(driver, cloud_user,
                                                                                        app_helpers):
    """ Unlock cloud user account w/cookie and pwd only unlock profile - negative test and validate error message """
    tenant_info = app_helpers['tenant_info']
    user_helper = app_helpers['user_helper']
    Login(driver, tenant_info['base_url']).to_user_portal(cloud_user['Name'], cloud_user['Password'],
                                                          wait_for_load_up=False)
    UserProfileMenu(driver).sign_out()
    user_helper.lock_user_account(cloud_user['Name'])
    add_user_to_policy(app_helpers, cloud_user, "test_scenario1")
    Login(driver, tenant_info['base_url']).to_user_portal(cloud_user['Name'], cloud_user['Password'],
                                                          wait_for_load_up=False)
    expected_text = 'User does not have the attributes required to login. Please contact your administrator.'
    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'


@pytestrail.case('C93679')
@pytest.mark.pipeline
def test_c93679_unlock_cloud_user_without_cookie_and_pwd_only_unlock_profile_negative_test(driver, locked_user_acct,
                                                                                           app_helpers):
    """ Unlock cloud user account w/o cookie and pwd only unlock profile - negative test and validate error message """
    tenant_info = app_helpers['tenant_info']
    add_user_to_policy(app_helpers, locked_user_acct, "test_scenario1")
    Login(driver, tenant_info['base_url']).to_user_portal(locked_user_acct['Name'], locked_user_acct['Password'],
                                                          wait_for_load_up=False)
    expected_text = 'User does not have the attributes required to login. Please contact your administrator.'
    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'