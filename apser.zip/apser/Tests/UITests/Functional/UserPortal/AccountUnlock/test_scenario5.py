from idaptive_testrail.plugin import pytestrail
import pytest
from Steps.navigate_steps import Navigate, Login
from idaptive_automation.ui_automation import SignInPage, UserPortalPage, UserProfileMenu
from Steps.policy_steps import add_user_to_sq_policy


@pytestrail.case('C93694')
@pytest.mark.pipeline
def test_c93694_unlock_cloud_user_with_cookie_happy_path(cloud_user, app_helpers, driver):
    """ Unlock cloud user account w/cookie - happy path and validate user login into UP successfully or not with MFA """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']

    Navigate(driver).to_up_sign_in_page()
    Login(driver, tenant_info['base_url']).to_user_portal(cloud_user['Name'], cloud_user['Password'])
    UserProfileMenu(driver).sign_out()

    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario5", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])
    
    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    SignInPage(driver).set_security_question(test_id)
    assert UserPortalPage(driver).get_user_display_text() == cloud_user['DisplayName'], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'


@pytestrail.case('C93695')
@pytest.mark.pipeline
def test_c93695_unlock_cloud_user_without_cookie_negative_test(cloud_user, app_helpers, driver):
    """ Unlock cloud user account w/o cookie negative test and validate error message """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']

    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario5", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])

    Navigate(driver).to_up_sign_in_page()
    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    expected_text = f'Authentication (login or challenge) has failed. Please try again or contact your system administrator.'
    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'
