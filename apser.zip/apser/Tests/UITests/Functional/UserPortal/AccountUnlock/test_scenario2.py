from idaptive_testrail.plugin import pytestrail
import pytest
from Steps.navigate_steps import Login, Navigate
from idaptive_automation.ui_automation import UserProfileMenu, SignInPage, UserPortalPage
from Steps.policy_steps import add_user_to_sq_policy


@pytestrail.case('C93683')
@pytest.mark.pipeline
def test_c93683_unlock_cloud_user_with_cookie_happy_path(driver, cloud_user, app_helpers):
    """  Unlock cloud user account w/cookie - happy path and validate user login into UP successfully or not with MFA """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']

    Login(driver, tenant_info['base_url']).to_user_portal(cloud_user['Name'], cloud_user['Password'],
                                                          wait_for_load_up=True)
    UserProfileMenu(driver).sign_out()

    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario1", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])

    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    SignInPage(driver).set_security_question(test_id)
    assert UserPortalPage(driver).get_user_display_text() == cloud_user['DisplayName'], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'


@pytestrail.case('C93684')
@pytest.mark.pipeline
def test_c93684_unlock_cloud_user_without_cookie_happy_path(driver, cloud_user, app_helpers):
    """ Unlock cloud user account w/o cookie - happy path and validate user login into UP successfully or not with MFA """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']

    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario1", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])

    Navigate(driver).to_up_sign_in_page()
    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    SignInPage(driver).set_security_question(test_id)

    assert UserPortalPage(driver).get_user_display_text() == cloud_user['DisplayName'], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'


@pytestrail.case('C93685')
@pytest.mark.pipeline
def test_c93685_unlock_cloud_user_wrong_mfa_response_negative_test(cloud_user, driver, app_helpers):
    """  Unlock cloud user account with wrong MFA response - negative test and validate Authentication error message """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']

    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario1", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])

    Navigate(driver).to_up_sign_in_page()
    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    SignInPage(driver).set_security_question('c12345')
    expected_text = f'Authentication (login or challenge) has failed. Please try again or contact your system administrator.'
    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'


@pytestrail.case('C93703')
@pytest.mark.pipeline
def test_c93703_unlock_cloud_user_wrong_password_happy_path(driver, app_helpers, cloud_user):

    """ Unlock cloud user account w/o cookie negative test and validate error message """
    Navigate(driver).to_up_sign_in_page()
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']
    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario1", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])

    SignInPage(driver).login(cloud_user['Name'], cloud_user['Name'])
    SignInPage(driver).set_security_question(test_id)
    expected_text = f'Authentication (login or challenge) has failed. Please try again or contact your system administrator.'

    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'

    SignInPage(driver).login_after_change_password(cloud_user['Password'])

    assert UserPortalPage(driver).get_user_display_text() == cloud_user['DisplayName'], \
        f'User is not logged into UP, expected {cloud_user["DisplayName"]}, found {UserPortalPage(driver).get_user_display_text()}'

