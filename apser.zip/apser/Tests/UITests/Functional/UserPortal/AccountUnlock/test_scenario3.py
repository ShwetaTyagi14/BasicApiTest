from idaptive_testrail.plugin import pytestrail
import pytest
from idaptive_automation.ui_automation import SignInPage
from Steps.policy_steps import add_user_to_sq_policy
from Steps.navigate_steps import Navigate


@pytestrail.case('C93686')
@pytest.mark.pipeline
def test_c93686_unlock_cloud_user_with_cookie_negative_test(cloud_user, app_helpers, driver):
    """ Unlock cloud user account w/cookie - negative test  and validate Authentication failure error message """
    tenant_info = app_helpers['tenant_info']
    test_id = app_helpers['test_id']
    user_helper = app_helpers['user_helper']

    add_user_to_sq_policy(app_helpers, cloud_user, "test_scenario3", use_mfa=True)
    user_helper.lock_user_account(cloud_user['Name'])

    Navigate(driver).to_up_sign_in_page()
    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    expected_text = f'Authentication (login or challenge) has failed. Please try again or contact your system administrator.'
    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'


@pytestrail.case('C93687')
@pytest.mark.pipeline
def test_c93687_unlock_cloud_user_without_cookie_negative_test(driver, cloud_user, app_helpers):
    """ Unlock cloud user account w/o cookie - negative test and validate Authentication failure error message """
    user_helper = app_helpers['user_helper']
    user_helper.lock_user_account(cloud_user['Name'])

    Navigate(driver).to_up_sign_in_page()
    SignInPage(driver).login(cloud_user['Name'], cloud_user['Password'])
    expected_text = f'Authentication (login or challenge) has failed. Please try again or contact your system administrator.'
    actual_text = SignInPage(driver).validate_error_message()
    assert actual_text == expected_text, f'Incorrect error message , found {actual_text}, expected {expected_text}'
