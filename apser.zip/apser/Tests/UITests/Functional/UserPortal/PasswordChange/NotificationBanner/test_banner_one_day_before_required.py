from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import UserPortalPage
import pytest
from Steps.navigate_steps import Login
from Steps.policy_steps import add_user_to_policy_standard


@pytestrail.case('C28052')
def test_c28052_no_pwd_change_banner_one_day_before_required_negative_test(driver, app_helpers, cloud_user):
    user_helper = app_helpers['user_helper']
    tenant_info = app_helpers['tenant_info']

    add_user_to_policy_standard(app_helpers, cloud_user, "display_banner")

    Login(driver, tenant_info['base_url'])\
        .to_user_portal(cloud_user['Name'], cloud_user['Password'])
    up_page = UserPortalPage(driver)
    up_page.wait_for_page_to_load()
    assert not up_page.is_pwd_change_banner_displayed()
