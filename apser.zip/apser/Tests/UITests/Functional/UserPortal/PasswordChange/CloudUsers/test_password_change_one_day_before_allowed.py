from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation.pages.error_dialog import ErrorDialog
from idaptive_automation.ui_automation import UserPortalPage
from Steps.navigate_steps import Login
from Steps.policy_steps import add_user_to_policy_standard
from Helpers.general_helpers import random_password


@pytestrail.case('C28029')
def test_c28029_pwd_change_one_day_before_allowed_negative_test(driver, app_helpers, cloud_user):
    user_helper = app_helpers['user_helper']
    tenant_info = app_helpers['tenant_info']
    new_password = random_password()
    
    add_user_to_policy_standard(app_helpers, cloud_user, "password_min_1_day")
    
    Login(driver, tenant_info['base_url'])\
        .to_user_portal(cloud_user['Name'], cloud_user['Password'])
    up_page = UserPortalPage(driver)
    up_page.wait_for_page_to_load()

    account_page = up_page.click_account_tab()
    cp_page = account_page.click_password_edit_button()

    cp_page.set_current_password(cloud_user['Password'])\
        .set_new_password(new_password)\
        .set_confirm_password(new_password)\
        .click_ok_button()

    dialog = ErrorDialog(driver).wait_for_page_to_load()
    message = dialog.get_error_message()
    expected_text = f'Password must not be changed within 1 day(s) from the last password change'
    assert expected_text in message,\
        f'Wrong error message. Expected: {expected_text}, found {message}'
