# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.ui_automation import UserPortalPage
# from Steps.navigate_steps import Login
#
#
# # TODO This test shold probably just be removed from automation given its tight time constraint requirements
# @pytestrail.case('C28030')
# def test_c28030_pwd_change_first_day_allowed_happy_path(generic_driver, session,
#                                                         random_password, minimum_pwd_age):
#     Login(generic_driver, session['url'])\
#         .to_user_portal(session['username'], session['password'])
#     up_page = UserPortalPage(generic_driver)
#     up_page.wait_for_page_to_load()
#
#     account_page = up_page.click_account_tab()
#     cp_page = account_page.click_password_edit_button()
#
#     cp_page.set_current_password(session['password'])\
#         .set_new_password(random_password)\
#         .set_confirm_password(random_password)\
#         .click_ok_button()
#
#     assert account_page.validate_success_toaster() is True,\
#         'Password change success toaster not detected'
