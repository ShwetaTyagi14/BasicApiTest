import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import UserProfileMenu, AboutPage
from Steps.navigate_steps import Login, Navigate


# @pytestrail.case('C45450')
# @pytest.mark.pipeline
# def test_c45450_ui_validation_user_profile_menu(user_portal_function_driver):
#     UserProfileMenu(user_portal_function_driver).validate_all_elements()\
#         .validate_all_child_elements()


@pytestrail.case('C45440')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c45440_user_profile_menu_about_shows_correct_version(driver, about_function_fixture, app_helpers):
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    UserProfileMenu(driver).click_about()
    AboutPage(driver, *about_function_fixture)\
        .wait_for_page_to_load()\
        .validate_all_elements()