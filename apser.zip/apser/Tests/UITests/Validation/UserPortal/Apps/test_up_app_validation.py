# import pytest
# from idaptive_automation.api_helpers import UserApi
# from idaptive_automation.ui_automation.pages.userportal.add_web_app_dialog import AddWebAppDialog
# from idaptive_automation.ui_automation.pages.userportal.app_catalog_dialog import AppCatalogDialog
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.ui_automation import UserPortalPage, SharedAppSettingsPage, ConfigurableAppSettingsPage
# from idaptive_automation.ui_automation.pages.confirm_user_password_window import ConfirmUsernamePasswordWindow
#
#
# @pytestrail.case('C87524')
# @pytest.mark.pipeline
# def test_c87524_validate_app_tile_tool_tip_for_ds_field_mapping(ds_field_app_deployed_to_cloud_user_fixture):
#     """ When I hover over the app tile on the app
#     Then the tool tip contains the text "app name", "description" and key "Login as <username> """
#
#     _, _, _, _, user, app, browser = ds_field_app_deployed_to_cloud_user_fixture
#     app_name = app['name']
#     description = app['description']
#     login_name = user['LoginName']
#
#     up_page = UserPortalPage(browser)
#
#     up_page.hover_over_app_tile(app_name)
#     tooltip_values = up_page.get_app_tile_tooltip(app_name)
#
#     assert app_name in tooltip_values, "App name not displayed not displayed in tool tip"
#     assert description in tooltip_values, "Description not displayed in tool tip"
#     assert f'Login as {login_name}' in tooltip_values, "Login name not displayed in tool tip"
#
#
# @pytestrail.case('C87528')
# @pytest.mark.pipeline
# def test_c87528_validate_app_tile_tool_tip_for_shared_username_mapping(shared_username_app_deployed_to_cloud_user_fixture):
#     """ When I hover over the app tile on the app
#     Then the tool tip contains the text "app name", "description" and key "Login as ... """
#
#     _, _, _, _, user, app, browser = shared_username_app_deployed_to_cloud_user_fixture
#     up_page = UserPortalPage(browser)
#     up_page.hover_over_app_tile(app['name'])
#     tooltip_values = up_page.get_app_tile_tooltip(app['name'])
#     app_name = tooltip_values.split('\n')[0]
#     description = tooltip_values.split('\n')[1]
#     user_name = tooltip_values.split('\n')[3]
#     assert app_name == app['name'], f'App name not displayed in tooltip, found {app_name}, expected {app["name"]}'
#     assert description == app['app']['Description'], f'App description not displayed tooltip, found {description}, expected{app["app"]["Description"]}'
#     assert user_name == 'Login as ...', f'Login as ... not displayed in tooltip, found{user_name}, expected Login as ...'
#
#
# @pytestrail.case('c87527')
# def test_c87527_validate_app_tile_tool_tip_for_prompt_for_username(prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ When I hover over the app tile on the app
#     Then the tool tip contains the text "app name", "description" and key "Login as ... """
#
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     up_page.hover_over_app_tile(app['name'])
#     tooltip_values = up_page.get_app_tile_tooltip(app['name'])
#     app_name = tooltip_values.split('\n')[0]
#     description = tooltip_values.split('\n')[1]
#     user_name = tooltip_values.split('\n')[3]
#
#     assert app_name == app['name'], f'App name not displayed in tooltip, found {app_name}, expected {app["name"]}'
#     assert description == app['app']['Description'], f'App description not displayed tooltip, found {description}, expected{app["app"]["Description"]}'
#     assert user_name == 'Login as ...', f'Login as ... not displayed in tooltip, found{user_name}, expected Login as ...'
#
#
# @pytestrail.case('C87536')
# @pytest.mark.pipeline
# def test_c87536_validate_app_settings_ui_for_shared_username(shared_username_app_deployed_to_cloud_user_fixture):
#     """ App settings dialog validation for 'All users share one name' account mapping """
#     _, _, _, _, user, app, browser = shared_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = up_page.open_app_tile_settings(app['name'])
#     app_settings.validate_all_elements().validate_all_child_elements()
#
#     assert app_settings.is_save_button_disabled() is True, 'Save button is enabled, expected disabled'
#
#     displayed_name = app_settings.get_app_name()
#     assert displayed_name == app['name'], f'App name incorrect, expected {app["name"]}, found {displayed_name}'
#
#     displayed_descr = app_settings.get_app_description()
#     assert displayed_descr == app['description'], f'App description incorrect, expected {app["description"]}, found {displayed_descr}'
#
#     assert not ConfigurableAppSettingsPage(browser).is_user_identity_displayed(), 'User Identity section displayed in shared username app'
#
#     app_settings.click_cancel_button()
#
#     up_page.wait_for_page_to_load()
#
#
# @pytestrail.case('C87533')
# @pytest.mark.pipeline
# def test_c87533_validate_app_settings_ui_for_ds_field_mapping(ds_field_app_deployed_to_cloud_user_fixture):
#     """ App settings dialog validation for 'Directory Service Field' account mapping """
#     _, _, _, _, user, app, browser = ds_field_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = ConfigurableAppSettingsPage(browser)
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.wait_for_page_to_load()
#     app_settings.validate_all_elements().validate_all_child_elements()
#
#     displayed_name = SharedAppSettingsPage(browser).get_app_name()
#     assert displayed_name == app['name'], f'App name incorrect, expected {app["name"]}, found {displayed_name}'
#
#     displayed_descr = SharedAppSettingsPage(browser).get_app_description()
#     assert displayed_descr == app['description'], f'App description incorrect, expected {app["description"]}'
#
#     assert app_settings.is_user_identity_displayed() is True, 'User Identity section not displayed in shared username app'
#
#     username = app_settings.get_username()
#     assert username == user['Name'], f'Username field not populated with login name, expected {user["Name"]}, found {username}'
#
#     password = app_settings.get_password_text()
#     assert len(password) == 0, f'password displaying in password text field, found {password}, expected: blank field'
#
#     assert app_settings.is_save_button_disabled() is True, 'Save button is enabled, expected disabled'
#
#     app_settings.click_cancel_button()
#
#     up_page.wait_for_page_to_load()
#
#
# @pytestrail.case('C87539')
# @pytest.mark.pipeline
# def test_c87539_validate_app_settings_ui_for_prompt_for_username(
#         prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ App settings dialog validation for 'Prompt for username' account mapping """
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = ConfigurableAppSettingsPage(browser)
#
#     up_page.open_app_tile_settings(app['name'])
#     app_settings.wait_for_page_to_load()
#     app_settings.validate_all_elements().validate_all_child_elements()
#
#     assert app_settings.get_username() in (None, ''), 'User Name field is not blank'
#
#     assert app_settings.get_password_text() in (None, ''), 'Password field is not blank'
#
#     assert app_settings.is_save_button_disabled() is True, 'Save button is not disabled'
#
#     app_settings.click_cancel_button()
#
#     up_page.wait_for_page_to_load()
#
#
# @pytestrail.case('C87531')
# @pytest.mark.pipeline
# def test_c87531_app_settings_pwd_input_for_ds_field_mapping(ds_field_app_deployed_to_cloud_user_fixture):
#     """ App settings password input for 'Directory Service Field' account mapping """
#     _, _, _, _, user, app, browser = ds_field_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = ConfigurableAppSettingsPage(browser)
#
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.wait_for_page_to_load()
#     app_settings.set_password(user['Password'])
#     app_settings.click_save_button()
#
#     up_page.wait_for_page_to_load()
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.click_user_identity()
#
#     assert app_settings.get_username() == user['Name'], f'Username field not populated with login name, expected {user["Name"]}, found {app_settings.get_username()}'
#
#     clipboard = app_settings.copy_password_to_clipboard()
#     assert clipboard is not None and len(clipboard.columns) == 1, f"Password not copied to clipboard"
#     assert clipboard.columns[0] == user['Password'], \
#         f'Wrong value found for copied password, expected {user["Password"]}, found {clipboard.columns[0]}'
#
#
# @pytestrail.case('C87534')
# @pytest.mark.pipeline
# def test_c87534_app_settings_pwd_input_for_prompt_for_username(prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ App settings password input for 'Prompt for user name' account mapping """
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = ConfigurableAppSettingsPage(browser)
#
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.wait_for_page_to_load()
#     app_settings.set_username(user['Name'])
#     app_settings.set_password(user['Password'])
#     app_settings.click_save_button()
#
#     up_page.wait_for_page_to_load()
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.click_user_identity()
#     username = app_settings.get_username()
#     assert username == user['Name'], f'Username field is not populated with login name, expected {user["Name"]}, found {username}'
#
#     clipboard = app_settings.copy_password_to_clipboard()
#     assert clipboard is not None and len(clipboard.columns) == 1, f"Password not copied to clipboard"
#     assert clipboard.columns[0] == user['Password'], \
#         f'Wrong value found for copied password, expected {user["Password"]}, found {clipboard.columns[0]}'
#
#
# @pytestrail.case('C87532')
# @pytest.mark.pipeline
# def test_c87532_app_settings_username_input_no_pwd_for_prompt_for_username(prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ App settings username input w/o password for 'Prompt for user name' account mapping """
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = ConfigurableAppSettingsPage(browser)
#
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.wait_for_page_to_load()
#     app_settings.set_username(user['Name'])
#     app_settings.click_save_button()
#
#     up_page.wait_for_page_to_load()
#     up_page.open_app_tile_settings(app['name'])
#
#     user_name = app_settings.get_username()
#     assert user_name == user['Name'], f'username not displayed in Username text field, found {user_name}, expected {user["Name"]}'
#
#     password = app_settings.get_password_text()
#     assert len(password) == 0, f'password displaying in password text field, found {password}, expected: blank field'
#
#
# @pytestrail.case('C87547')
# @pytest.mark.pipeline
# def test_c87547_initial_app_launch_for_prompt_for_username_app(prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ Launch app with 'Prompt for user name' account mapping """
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     app_settings = ConfigurableAppSettingsPage(browser)
#     confirm_user_password_window = ConfirmUsernamePasswordWindow(browser)
#
#     handles = up_page.get_window_handles()
#     up_page.launch_app_up(app['name'])
#
#     confirm_user_password_window.wait_for_page_to_load()
#     expected_text = 'User name/password needed.\n x\nBefore you can launch this application please enter the user name and password. This is required only the first time you launch the application. Do you want to continue?'
#     text = confirm_user_password_window.user_password_dialog()
#     assert text == expected_text, f'valid message not displayed, expected {expected_text}, found {text} '
#
#     confirm_user_password_window.click_yes_button()
#
#     app_settings.set_username(user['Name'])
#     app_settings.set_password(user['Password'])
#
#     app_settings.click_save_button()
#
#     up_page.switch_to_new_tab_after_app_launch(handles=handles)
#     app_url = up_page.get_app_url()
#     assert app_url == app['app']['Url']+'/', f'valid url not found, expected {app["app"]["Url"]+"/"}, found {app_url}'
#
#
# @pytestrail.case('C87538')
# @pytest.mark.pipeline
# def test_c87538_cancel_initial_app_launch_for_prompt_for_username_app(prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ Cancel app launch with 'Prompt for user name' account mapping """
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     confirm_user_password_window = ConfirmUsernamePasswordWindow(browser)
#
#     up_page.launch_app_up(app['name'])
#
#     confirm_user_password_window.wait_for_page_to_load()
#
#     expected_text = 'User name/password needed.\n x\nBefore you can launch this application please enter the user name and password. This is required only the first time you launch the application. Do you want to continue?'
#     text = confirm_user_password_window.user_password_dialog()
#     assert text == expected_text, f'valid message not displayed in dialog, expected {expected_text}, found {text}'
#
#     confirm_user_password_window.click_dont_continue()
#
#     up_page.wait_for_page_to_load()
#
#
# @pytestrail.case('C87838')
# @pytest.mark.pipeline
# def test_c87838_add_apps_dialog_no_self_service(user_in_role_with_no_self_service_policy):
#     """ Add apps in UP under AllowSelfService:false policy - happy path """
#     _, _, _, browser = user_in_role_with_no_self_service_policy
#
#     up_page = UserPortalPage(browser)
#     up_page.click_add_apps_button()
#
#     app_catalog_page = AppCatalogDialog(browser)
#     app_catalog_page.is_loaded()
#
#     actual_msg = app_catalog_page.get_recommended_tab_msg()
#     expected_msg1 = "No Recommended apps available at this time"
#     assert expected_msg1 in actual_msg, f'Message incorrect, expected {expected_msg1}, found {actual_msg}'
#
#     expected_msg2 = "You currently have all of the applications that your system administrator has provided for you. Check back later to see if additional apps are available or contact your system administrator for more information."
#     assert expected_msg2 in actual_msg, f'Message incorrect, expected {expected_msg2}, found {actual_msg}'
#
#
# @pytestrail.case('C87850')
# @pytest.mark.pipeline
# def test_c87850_add_apps_dialog_with_self_service_happy_path(user_in_role_with_self_service_policy):
#     """ Add apps in UP under AllowSelfService:true policy - happy path """
#     _, _, _, browser = user_in_role_with_self_service_policy
#
#     up_page = UserPortalPage(browser)
#     up_page.wait_for_page_to_load()
#     up_page.click_add_apps_button()
#
#     app_catalog_page = AppCatalogDialog(browser).click_search_tab()
#     app_catalog_page.wait_for_page_to_load()
#     assert len(app_catalog_page.get_search_string_count()) == 21, f'Incorrect number of apps displayed, expected 21, but found {app_catalog_page.get_search_string_count()}'
#
#     app_catalog_page.click_first_add_apps_button()
#
#     add_web_app_page = AddWebAppDialog(browser)
#     add_web_app_page.wait_for_page_to_load()
#     add_web_app_page.validate_all_child_elements()
#
#     actual_msg = add_web_app_page.get_continue_msg()
#     continue_msg = "Do you want to add this application?"
#     assert continue_msg == actual_msg, f'Message incorrect, expected {continue_msg}, found {actual_msg}'
#
#     add_web_app_page.press_yes()
#     app_catalog_page.wait_for_page_to_load()
#     app_catalog_page.close_app_catalog_dialog()
#
#     app_settings = ConfigurableAppSettingsPage(browser)
#     app_settings.wait_for_page_to_load()
#     app_settings.validate_all_child_elements()
#
#
# @pytestrail.case('C87540')
# @pytest.mark.pipeline
# def test_c87540_cancel_adding_app_in_up(user_in_role_with_self_service_policy):
#     """ Press Cancel button while adding apps in UP """
#     _, _, _, browser = user_in_role_with_self_service_policy
#
#     up_page = UserPortalPage(browser)
#     up_page.wait_for_page_to_load(wait_time=10)
#     assert up_page.get_apps() is None, f'No apps should be displayed,but found'
#     up_page.click_add_apps_button()
#
#     app_catalog_dialog = AppCatalogDialog(browser)
#     app_catalog_dialog.wait_for_page_to_load(wait_time=20)
#     app_catalog_dialog.click_first_add_apps_button()
#
#     add_web_app_dialog = AddWebAppDialog(browser)
#     add_web_app_dialog.press_no()
#
#     app_catalog_dialog.wait_for_page_to_load()
#     app_catalog_dialog.close_app_catalog_dialog()
#
#     up_page.wait_for_page_to_load()
#     assert up_page.get_apps() is None, f'No apps should be displayed, but found'
#
#
# @pytestrail.case('C87546')
# @pytest.mark.pipeline
# def test_c87546_search_function_in_app_catalog_dialog_in_up(user_in_role_with_self_service_policy):
#     """ Search function in App Catalog dialog """
#     _, _, _, browser = user_in_role_with_self_service_policy
#
#     up_page = UserPortalPage(browser)
#     search_string = 'Facebook'
#     UserPortalPage(browser).wait_for_page_to_load()
#     up_page.click_add_apps_button()
#
#     app_catalog_page = AppCatalogDialog(browser).click_search_tab()
#     app_catalog_page.wait_for_page_to_load(wait_time=30)
#     app_catalog_page.search_app_input(app_name=search_string)
#     assert len(app_catalog_page.get_search_string_count()) == 1, f"App {search_string} is not only one displayed, expected only one, found otherthan one app"
#
#
# @pytestrail.case('C70034')
# @pytest.mark.pipeline
# def test_c70034_user_password_app_deployed_to_user_displays_correctly_in_up(session_fixture, prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """ U/P app has been deployed to user1 with the account mapping set to 'Prompt for username' and when
#         logged in as same user, it should display correct results"""
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     up_page.search_app_input(app['name'])
#     up_page.hover_over_app_tile(app['name'])
#     tooltip_values = up_page.get_app_tile_tooltip(app['name'])
#     app_name = tooltip_values.split('\n')[0]
#     description = tooltip_values.split('\n')[1]
#     user_name = tooltip_values.split('\n')[3]
#
#     assert app_name == app['name'], f'App name not displayed in tooltip, found {app_name}, expected {app["name"]}'
#     assert description == app['app'][
#         'Description'], f'App description not displayed tooltip, found {description}, expected{app["app"]["Description"]}'
#     assert user_name == 'Login as ...', f'Login as ... not displayed in tooltip, found{user_name}, expected Login as ...'
#
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings = ConfigurableAppSettingsPage(browser)
#     app_settings.wait_for_page_to_load()
#     app_settings.set_username(user['Name'])
#     app_settings.set_password(user['Password'])
#     app_settings.click_save_button()
#
#     up_page.wait_for_page_to_load()
#     up_page.hover_over_app_tile(app['name'])
#     tooltip_values_after_clicking_save = up_page.get_app_tile_tooltip(app['name'])
#     app_name_after_clicking_save = tooltip_values_after_clicking_save.split('\n')[0]
#     description_after_clicking_save = tooltip_values_after_clicking_save.split('\n')[1]
#     user_name_after_clicking_save = tooltip_values_after_clicking_save.split('\n')[3]
#
#     assert app_name_after_clicking_save == app['name'], f'App name not displayed in tooltip, found {app_name_after_clicking_save}, expected {app["name"]}'
#     assert description_after_clicking_save == app['app'][
#         'Description'], f'App description not displayed in tooltip, found {description_after_clicking_save}, expected{app["app"]["Description"]}'
#     assert f'Login as {user["Name"]}' == user_name_after_clicking_save, "Login name is not displayed in tool tip"
#
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings.click_user_identity()
#
#     assert app_settings.get_username() == user[
#         'Name'], f'Username field not populated with login name, expected {user["Name"]}, found {app_settings.get_username()}'
#
#     clipboard = app_settings.copy_password_to_clipboard()
#     assert clipboard is not None and len(clipboard.columns) == 1, f"Password not copied to clipboard"
#     assert clipboard.columns[0] == user['Password'], \
#         f'Wrong value found for copied password, expected {user["Password"]}, found {clipboard.columns[0]}'
#
#     UserApi(session_fixture['session']).delete_user(username=user['Name'])
#
#
# @pytestrail.case('C73888')
# @pytest.mark.pipeline
# def test_c73888_user_portal_ui_validation_of_user_credentials_displayed_in_app_settings_dialog(session_fixture, prompt_for_username_app_deployed_to_cloud_user_fixture):
#     """  App has been deployed to user with the account mapping set to 'Prompt for username' and when
#         logged in as same user, it should display correct user credentials in app settings dialog"""
#     _, _, _, _, user, app, browser = prompt_for_username_app_deployed_to_cloud_user_fixture
#
#     up_page = UserPortalPage(browser)
#     up_page.search_app_input(app['name'])
#     up_page.hover_over_app_tile(app['name'])
#     tooltip_values = up_page.get_app_tile_tooltip(app['name'])
#     app_name = tooltip_values.split('\n')[0]
#     description = tooltip_values.split('\n')[1]
#     user_name = tooltip_values.split('\n')[3]
#
#     assert app_name == app['name'], f'App name not displayed in tooltip, found {app_name}, expected {app["name"]}'
#     assert description == app['app'][
#         'Description'], f'App description not displayed tooltip, found {description}, expected{app["app"]["Description"]}'
#     assert user_name == 'Login as ...', f'Login as ... not displayed in tooltip, found{user_name}, expected Login as ...'
#
#     up_page.open_app_tile_settings(app['name'])
#
#     app_settings = ConfigurableAppSettingsPage(browser)
#     app_settings.wait_for_page_to_load()
#     app_settings.set_username(user['Name'])
#     app_settings.set_password(user['Password'])
#     app_settings.click_save_button()
#
#     up_page.wait_for_page_to_load()
#     up_page.hover_over_app_tile(app['name'])
#     tooltip_values_after_clicking_save = up_page.get_app_tile_tooltip(app['name'])
#     app_name_after_clicking_save = tooltip_values_after_clicking_save.split('\n')[0]
#     description_after_clicking_save = tooltip_values_after_clicking_save.split('\n')[1]
#     user_name_after_clicking_save = tooltip_values_after_clicking_save.split('\n')[3]
#
#     assert app_name_after_clicking_save == app['name'], f'App name not displayed in tooltip, found {app_name_after_clicking_save}, expected {app["name"]}'
#     assert description_after_clicking_save == app['app'][
#         'Description'], f'App description not displayed in tooltip, found {description_after_clicking_save}, expected{app["app"]["Description"]}'
#     assert f'Login as {user["Name"]}' == user_name_after_clicking_save, "Login name is not displayed in tool tip"
#
#     up_page.open_app_tile_settings(app['name'])
#     app_settings.click_user_identity()
#     app_settings.click_show_password_icon()
#
#     assert app_settings.is_password_displayed() is True, f'Incorrect password displayed , but correct password found'
#
#
# @pytestrail.case('C45587')
# @pytest.mark.pipeline
# def test_c45587_deploy_user_password_app_from_up_self_service_happy_path(user_in_role_with_self_service_policy):
#     """ Deploy User-password app from User Portal with AllowSelfService:true """
#     _, _, _, browser = user_in_role_with_self_service_policy
#     user_password_app = 'Facebook'
#
#     up_page = UserPortalPage(browser)
#     up_page.wait_for_page_to_load()
#     up_page.click_add_apps_button()
#
#     app_catalog_page = AppCatalogDialog(browser).click_search_tab()
#     app_catalog_page.wait_for_page_to_load(wait_time=20)
#     app_catalog_page.search_app_input(app_name=user_password_app)
#     app_catalog_page.click_first_add_apps_button()
#
#     add_web_app_page = AddWebAppDialog(browser)
#     add_web_app_page.wait_for_page_to_load()
#     add_web_app_page.validate_all_child_elements()
#
#     actual_msg = add_web_app_page.get_continue_msg()
#     continue_msg = "Do you want to add this application?"
#     assert continue_msg == actual_msg, f'Message incorrect, expected {continue_msg}, found {actual_msg}'
#
#     add_web_app_page.press_yes()
#     app_catalog_page.wait_for_page_to_load()
#     assert app_catalog_page.is_remove_button_displayed() | app_catalog_page.is_app_added() is True, f'Remove button or "Application Added" should be displayed, but not found'
#     app_catalog_page.close_app_catalog_dialog()
#
#     app_settings = ConfigurableAppSettingsPage(browser)
#     app_settings.wait_for_page_to_load()
#     app_settings.click_cancel_button()
#
#     up_page.wait_for_page_to_load()
#     assert up_page.is_app_tile_displayed(app_name=user_password_app) is True, f'App is not displayed'