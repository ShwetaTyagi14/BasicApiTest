from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import APUserProfileMenu


@pytestrail.case('45451')
def test_c45451_ui_validation_ap_user_profile_menu(driver_admin):
    APUserProfileMenu(driver_admin).validate_all_elements().validate_all_child_elements()
