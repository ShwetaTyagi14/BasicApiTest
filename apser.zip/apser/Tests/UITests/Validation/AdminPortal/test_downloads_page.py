import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import DownloadsPage
from idaptive_automation.api_helpers import IBEHelper
from Steps.navigate_steps import Navigate


@pytestrail.case('C45441')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c45441_ui_validation_downloads_page(driver_admin, app_helpers):
    versions = IBEHelper(app_helpers['cloud_session']).get_all_versions()
    cloud_version = versions['CloudVersion']
    downloads_page = Navigate(driver_admin).to_downloads_page()
    downloads_page.validate_all_elements().validate_all_child_elements()
    download_versions = downloads_page.get_all_browser_extension_versions()

    for k, v in download_versions.items():
        assert v == cloud_version, f'Expected {cloud_version} for {k} download, found {v}'

# WE NO LONGER HAVE A MAC AGENT TO VALIDATE
# @pytestrail.case('C93753')
# @pytest.mark.pipeline
# def test_c93753_ui_validation_downloads_page(driver_admin):
#     downloads_page = Navigate(driver_admin).to_downloads_page()
#     downloads_page.validate_all_elements().validate_all_child_elements()
#     href = downloads_page.get_mac_agent_href()
#     assert href.endswith('Idaptive-Mac-Agent.dmg'), \
#         f'Wrong href found for mac agent download. Expected Idaptive-Mac-Agent.dmg, found {href}'
#     info_dialog = downloads_page.open_mac_agent_info_dialog()
#     info_text = info_dialog.get_main_text()
#     assert 'Idaptive Mac Cloud Agent version 19.5 or higher' in info_text, \
#         f'Info text "{info_text}" does not contain "Idaptive Mac Cloud Agent version 19.5 or higher"'
#     assert 'all of the MDM features available in version 19.1' in info_text, \
#         f'Info text "{info_text}" does not contain "all of the MDM features available in version 19.1"'
