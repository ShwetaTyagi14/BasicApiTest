# import pytest
# from idaptive_automation.api_helpers import UserApi
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.ui_automation import UsersTab, APUserProfileMenu, UserPortalPage
# from Steps.navigate_steps import Navigate, Login
# from Fixtures.role_fixtures import ldap_role_app_fixture, get_ldap_server_config
#
#
# @pytestrail.case('C68363')
# @pytest.mark.pipeline
# def test_c68363_log_in_as_idaptive_directory_user(admin_portal_function_driver,
#                                                   ldap_role_app_fixture, session_fixture,
#                                                   case_number):
#     """ Log in as Idaptive directory user and validate user login into UP successfully """
#     app_api, user_api, app, _, user, role_api = ldap_role_app_fixture
#     Navigate(admin_portal_function_driver).to_users_tab()
#     users_tab = UsersTab(admin_portal_function_driver)
#
#     name = f'{case_number}test-user'
#     email = f'test@test.test'
#     password = "testTEST1234"
#     user_login_name = f'{name}@{session_fixture["tenant"]}'
#
#     detail_window = users_tab.open_add_user_window()
#     detail_window.set_login(name)
#     detail_window.set_email(email)
#     detail_window.set_display_name(name)
#     detail_window.set_password(password)
#     detail_window.set_confirm_password(password)
#     detail_window.click_password_never_expires()
#     detail_window.click_send_email()
#     detail_window.press_create_user_button()
#
#     APUserProfileMenu(admin_portal_function_driver).sign_out()
#     Login(admin_portal_function_driver).to_user_portal(name, password)
#
#     assert UserPortalPage(admin_portal_function_driver).get_user_display_text() == user["user_name"], \
#         f'User is not logged into UP, expected {user["user_name"]}, found {UserPortalPage(admin_portal_function_driver).get_user_display_text()}'
#
#     UserApi(session_fixture['session']).delete_user(username=user_login_name)