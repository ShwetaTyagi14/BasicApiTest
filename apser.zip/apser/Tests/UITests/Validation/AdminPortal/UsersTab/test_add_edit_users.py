import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import UsersTab, UserAddEditWindow, UAEActivityTabPage, UAEAppSettingsTabPage, \
    UAEAssignedAppsTabPage, UAERolesTabPage, UAEAddtnlAttributesTabPage


@pytestrail.case('C33445')
@pytest.mark.pipeline
def test_c33445_ui_validation_of_add_user_window(admin_portal_users_tab_driver):
    admin_portal_users_tab_driver.refresh()

    users_tab = UsersTab(admin_portal_users_tab_driver)
    detail_window = users_tab.open_add_user_window()
    detail_window.validate_all_elements()
    detail_window.press_cancel_button()


@pytestrail.case('C93673')
@pytest.mark.pipeline
def test_c93673_ui_validation_of_uae_activity_tab(admin_portal_users_tab_driver, app_helpers):
    """ To validate UI checks on User Add/Edit Activity Tab in AP """
    admin_portal_users_tab_driver.refresh()
    tenant_info = app_helpers['tenant_info']

    users_tab = UsersTab(admin_portal_users_tab_driver)
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(tenant_info['username'])
    users_tab.open_user_detail_window_for_user(tenant_info['username'])

    UserAddEditWindow(admin_portal_users_tab_driver).click_activity_tab()

    UAEActivityTabPage(admin_portal_users_tab_driver).validate_all_elements() \
        .validate_all_child_elements()


@pytestrail.case('C93674')
@pytest.mark.pipeline
def test_c93674_ui_validation_of_uae_app_settings_tab(admin_portal_users_tab_driver, app_helpers):
    """ To validate UI checks on User Add/Edit App Settings Tab in AP"""
    admin_portal_users_tab_driver.refresh()
    tenant_info = app_helpers['tenant_info']

    users_tab = UsersTab(admin_portal_users_tab_driver)
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(tenant_info['username'])
    users_tab.open_user_detail_window_for_user(tenant_info['username'])
    UserAddEditWindow(admin_portal_users_tab_driver).click_app_settings_tab()
    UAEAppSettingsTabPage(admin_portal_users_tab_driver).validate_all_elements() \
        .validate_all_child_elements()


@pytestrail.case('C93675')
@pytest.mark.pipeline
def test_c93675_ui_validation_of_uae_assigned_apps_tab(admin_portal_users_tab_driver, app_helpers):
    """ To validate UI checks on User Add/Edit Assigned apps Tab"""
    admin_portal_users_tab_driver.refresh()
    tenant_info = app_helpers['tenant_info']
    users_tab = UsersTab(admin_portal_users_tab_driver)
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(tenant_info['username'])
    users_tab.open_user_detail_window_for_user(tenant_info['username'])
    UserAddEditWindow(admin_portal_users_tab_driver).click_assigned_apps_tab()
    UAEAssignedAppsTabPage(admin_portal_users_tab_driver).validate_all_elements() \
        .validate_all_child_elements()


@pytestrail.case('C93676')
@pytest.mark.pipeline
def test_c93676_ui_validation_of_uae_roles_tab(admin_portal_users_tab_driver, app_helpers):
    """ To validate UI checks on User Add/Edit Roles Tab in AP  """
    admin_portal_users_tab_driver.refresh()
    tenant_info = app_helpers['tenant_info']
    users_tab = UsersTab(admin_portal_users_tab_driver)
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(tenant_info['username'])
    users_tab.open_user_detail_window_for_user(tenant_info['username'])
    UserAddEditWindow(admin_portal_users_tab_driver).click_roles_tab()
    UAERolesTabPage(admin_portal_users_tab_driver).validate_all_child_elements()


@pytestrail.case('C93677')
@pytest.mark.pipeline
def test_c93677_ui_validation_of_uae_addtnl_attribs_tab(admin_portal_users_tab_driver, app_helpers):
    """ To validate UI checks on User Add/Edit Additional Attributes Tab"""
    admin_portal_users_tab_driver.refresh()
    tenant_info = app_helpers['tenant_info']
    users_tab = UsersTab(admin_portal_users_tab_driver)
    users_tab.validate_users_tab_is_loaded()
    users_tab.search_for_user(tenant_info['username'])
    users_tab.open_user_detail_window_for_user(tenant_info['username'])
    UserAddEditWindow(admin_portal_users_tab_driver).click_additional_attributes_tab()
    UAEAddtnlAttributesTabPage(admin_portal_users_tab_driver).validate_all_elements() \
        .validate_all_child_elements()


@pytestrail.case('C93722')
@pytest.mark.pipeline
def test_c93722_ui_validation_of_uae_assign_manager_to_user(admin_portal_users_tab_driver):
    """ To validate UI of Select Manager dialog in user detail page in AP """
    admin_portal_users_tab_driver.refresh()
    users_tab = UsersTab(admin_portal_users_tab_driver)
    uae_window = users_tab.open_add_user_window()
    select_user_window = uae_window.press_select_manager()
    select_user_window.validate_all_elements() \
        .validate_all_child_elements()


@pytestrail.case('C94681')
@pytest.mark.pipeline
def test_c94681_require_pwd_change_and_nvr_expires_are_exclusive(admin_portal_users_tab_driver):
    """ Require pwd change and Pwd never expires are mutually exclusive in AP user detail page  """
    users_tab = UsersTab(admin_portal_users_tab_driver)
    user_add_window = users_tab.open_add_user_window()
    user_add_window.click_password_never_expires()

    assert user_add_window.validate_require_pwd_change_checked() is False, f'Validate unchecked, found checked'

    user_add_window.click_require_password_change_at_login()

    assert user_add_window.validate_never_expires_checked() is False, f'Validate unchecked, found checked'
