import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.admin_policies_tab_steps import AdminPoliciesTabSteps
from Steps.navigate_steps import Navigate, Login
from Fixtures.sessions_and_helpers import *


@pytestrail.case('C28095')
@pytest.mark.pipeline
def test_c28095_policies_tab_landing_page_displays_correctly(driver, app_helpers):
    policy_api = app_helpers['policy_helper']
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_policies_tab()

    policies_steps, displayed_policies = AdminPoliciesTabSteps(driver).get_displayed_policies()

    expected_policies = policy_api.get_admin_policy_list()

    for indx, policy in enumerate(displayed_policies):
        assert expected_policies[indx] == policy
