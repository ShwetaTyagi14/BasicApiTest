# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM

# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import CommonPage, RestrictionsSettingsPage, SecuritySettingsPage, WifiSettingsPage
#
#
# @pytestrail.case('C27897')
# @pytest.mark.pipeline
# def test_c27897_validate_policy_detail_endpoints_comm_mobile_common(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.COMMON_SETTINGS, pdc.MOBILE_SETTINGS,
#                    pdc.COMMON],
#                   CommonPage)
#
#
# @pytestrail.case('C27898')
# @pytest.mark.pipeline
# def test_c27898_validate_policy_detail_endpoints_comm_mobile_restrictions(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.COMMON_SETTINGS, pdc.MOBILE_SETTINGS,
#                    pdc.RESTRICTIONS_SETTINGS],
#                   RestrictionsSettingsPage)
#
#
# @pytestrail.case('C27899')
# @pytest.mark.pipeline
# def test_c27899_validate_policy_detail_endpoints_comm_mobile_security(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.COMMON_SETTINGS,
#                    pdc.MOBILE_SETTINGS, pdc.SECURITY_SETTINGS],
#                   SecuritySettingsPage)
#
#
# @pytestrail.case('C27900')
# @pytest.mark.pipeline
# def test_c27900_validate_policy_detail_endpoints_comm_mobile_wifi(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.COMMON_SETTINGS,
#                    pdc.MOBILE_SETTINGS, pdc.WIFI_SETTINGS],
#                   WifiSettingsPage)
