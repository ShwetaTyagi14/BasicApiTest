import pytest
from idaptive_automation.ui_automation import AdminPagePoliciesTab, PolicyDetailLandingPage
from idaptive_automation.ui_automation.pages.policydetails.summary_page import SummaryPage
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate


@pytestrail.case('C33646')
@pytest.mark.pipeline
def test_c33646_ui_validation_of_summary_tab(driver_admin):
    """ UI Validation for navigation from Policy Details 'Summary Page' """
    Navigate(driver_admin).to_policies_tab()
    AdminPagePoliciesTab(driver_admin).open_add_policy_window()
    PolicyDetailLandingPage(driver_admin).click_summary_tab()
    SummaryPage(driver_admin).validate_all_elements().validate_all_child_elements()

