# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM

# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import ConfigureAppsPage, EnableCommonCriteriaPage, EnableKNOXContainerPage,\
#     EnableODEVeificationPage, EnableTIMAStorePage, EnterpriseBillingPage, RequireAttestationPage,\
#     VPNSettingsPage
#
#
# @pytestrail.case('C33592')
# @pytest.mark.pipeline
# def test_c33592_validate_policy_detail_endpoints_skws_enable_knox(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.ENABLE_KNOX_CONTAINER],
#                   EnableKNOXContainerPage)
#
#
# @pytestrail.case('C33593')
# @pytest.mark.pipeline
# def test_c33593_validate_policy_detail_endpoints_skws_enable_tima(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.ENABLE_TIMA_KEY_STORE],
#                   EnableTIMAStorePage)
#
#
# @pytestrail.case('C33594')
# @pytest.mark.pipeline
# def test_c33594_validate_policy_detail_endpoints_skws_enable_ode(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.ENABLE_ODE_TRUSTED],
#                   EnableODEVeificationPage)
#
#
# @pytestrail.case('C33595')
# @pytest.mark.pipeline
# def test_c33595_validate_policy_detail_endpoints_skws_common_criteria(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.ENABLE_COMMON_CRITERIA],
#                   EnableCommonCriteriaPage)
#
#
# @pytestrail.case('C33596')
# @pytest.mark.pipeline
# def test_c33596_validate_policy_detail_endpoints_skws_require_attestation(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.REQUIRE_ATTESTATION],
#                   RequireAttestationPage)
#
#
# @pytestrail.case('C33597')
# @pytest.mark.pipeline
# def test_c33597_validate_policy_detail_endpoints_skws_vpn_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.VPN_SETTINGS],
#                   VPNSettingsPage)
#
#
# @pytestrail.case('C33598')
# @pytest.mark.pipeline
# def test_c33598_validate_policy_detail_endpoints_skws_configure_apps(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.CONFIGURE_APPLICATIONS],
#                   ConfigureAppsPage)
#
#
# @pytestrail.case('C33599')
# @pytest.mark.pipeline
# def test_c33599_validate_policy_detail_endpoints_skws_enterprise_billing(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.ENTERPRISE_BILLING],
#                   EnterpriseBillingPage)
