import pytest
from idaptive_automation.ui_automation import AdminPagePoliciesTab, PolicyDetailLandingPage, ConfirmDeleteWindow
from idaptive_automation.ui_automation.pages.policydetails.third_party_integration_page import ThirdPartyIntegration
from idaptive_testrail.plugin import pytestrail
from Steps.navigate_steps import Navigate


@pytestrail.case('C33645')
@pytest.mark.pipeline
def test_c33645_ui_validation_of_third_party_integration(driver_admin):
    """ UI Validation for navigation from Policy Details 'Third Party Integration' """
    Navigate(driver_admin).to_policies_tab()
    AdminPagePoliciesTab(driver_admin).open_add_policy_window()
    PolicyDetailLandingPage(driver_admin).click_third_party_integration_tab()
    ThirdPartyIntegration(driver_admin).press_add_challenge_policy()
    ThirdPartyIntegration(driver_admin).set_key_name()
    ThirdPartyIntegration(driver_admin).click_ok_button()
    ThirdPartyIntegration(driver_admin).press_enable_auth_control_policy()
    ThirdPartyIntegration(driver_admin).validate_all_child_elements()
    ThirdPartyIntegration(driver_admin).delete_key_policy()
    ConfirmDeleteWindow(driver_admin).press_yes()
