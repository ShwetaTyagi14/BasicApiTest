# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM

# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import AppManagementPage, CustomSettingsPage, ManageLocalAdminPage, OpenApplicationsPage,\
#      OpenAuthenticatedNetworkMountsPage, OpenFilesPage, OpenNetworkMountsPage, PermitSkipOpeningItemsPage,\
#      SecurityPrivacySettingsPage
#
#
# @pytestrail.case('C27924')
# @pytest.mark.pipeline
# def test_c27924_validate_policy_detail_endpoints_osx_custom(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.CUSTOM_SETTINGS],
#                   CustomSettingsPage)
#
#
# @pytestrail.case('C27925')
# @pytest.mark.pipeline
# def test_c27925_validate_policy_detail_endpoints_osx_open_apps(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.OPEN_APPS_ON_USER_LOGIN],
#                   OpenApplicationsPage)
#
#
# @pytestrail.case('C27926')
# @pytest.mark.pipeline
# def test_c27926_validate_policy_detail_endpoints_osx_open_auth_network(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.OPEN_AUTH_NETWORK_ON_USER_LOGIN],
#                   OpenAuthenticatedNetworkMountsPage)
#
#
# @pytestrail.case('C27927')
# @pytest.mark.pipeline
# def test_c27927_validate_policy_detail_endpoints_osx_open_files(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.OPEN_FILES_ON_USER_LOGIN],
#                   OpenFilesPage)
#
#
# @pytestrail.case('C33557')
# @pytest.mark.pipeline
# def test_c33557_validate_policy_detail_endpoints_osx_open_network(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.OPEN_NETWORK_MOUNTS_ON_USER_LOGIN],
#                   OpenNetworkMountsPage)
#
#
# @pytestrail.case('C33555')
# @pytest.mark.pipeline
# def test_c33555_validate_policy_detail_endpoints_osx_permit_skip(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.PERMIT_SHIFT_TO_SKIP_ON_USER_LOGIN],
#                   PermitSkipOpeningItemsPage)
#
#
# @pytestrail.case('C33556')
# @pytest.mark.pipeline
# def test_c33556_validate_policy_detail_endpoints_osx_security(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.SECURITY_PRIVACY_SETTINGS],
#                   SecurityPrivacySettingsPage)
#
#
# @pytestrail.case('C33558')
# @pytest.mark.pipeline
# def test_c33558_validate_policy_detail_endpoints_osx_app_manage(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.APPLICATION_MANAGEMENT],
#                   AppManagementPage)
#
#
# @pytestrail.case('C33559')
# @pytest.mark.pipeline
# def test_c33559_validate_policy_detail_endpoints_osx_manage_local_admin(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.MANAGE_LOCAL_ADMIN_ACCT],
#                   ManageLocalAdminPage)
#
#
# @pytestrail.case('C28087')
# @pytest.mark.pipeline
# def test_c28087_validate_policy_detail_endpoints_osx_open_files(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.OSX_SETTINGS,
#                    pdc.OPEN_FILES_ON_USER_LOGIN],
#                   OpenFilesPage)
#
