# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM
#
# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import Knox26Page, LegacyPage
#
#
# @pytestrail.case('C33564')
# @pytest.mark.pipeline
# def test_c33564_validate_policy_detail_endpoints_skd_firewall_legacy(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SAMSUMG_KNOX_DEV_SETTINGS,
#                    pdc.FIREWALL_SETTINGS, pdc.LEGACY],
#                   LegacyPage)
#
#
# @pytestrail.case('C33565')
# @pytest.mark.pipeline
# def test_c33565_validate_policy_detail_endpoints_skd_firewall_knox26(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SAMSUMG_KNOX_DEV_SETTINGS,
#                    pdc.FIREWALL_SETTINGS, pdc.KNOX],
#                   Knox26Page)
