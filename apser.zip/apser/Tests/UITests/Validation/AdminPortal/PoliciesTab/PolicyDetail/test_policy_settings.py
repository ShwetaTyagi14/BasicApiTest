import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.admin_policies_tab_steps import AdminPoliciesTabSteps
from Steps.navigate_steps import Navigate, Login
from idaptive_automation.ui_automation import PolicySettingsPage


@pytestrail.case('C28100')
@pytest.mark.pipeline
def test_c28100_validate_policy_settings(driver, app_helpers):
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_policies_tab()
    policies_steps, existing_policies = AdminPoliciesTabSteps(driver).get_displayed_policies()

    policies_steps.validate_page(None, PolicySettingsPage)

    new_policies = policies_steps.refresh_page().get_displayed_policies()[1]

    assert existing_policies == new_policies
