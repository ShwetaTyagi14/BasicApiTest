# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM


# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import AppSettingsPage, BrowserSettingsPage, CertificateSettingsPage, ContainerAccountPage,\
#     EmailSettingsPage, FirewallSettingsPage, PasscodeSettingsPage, GoogleAppsPage, RestrictionsPage,\
#     PerAppVPNPage, ExchangeSettingsPage, EmailAccountPage
#
#
# @pytestrail.case('C33606')
# @pytest.mark.pipeline
# def test_c33606_validate_policy_detail_endpoints_skws_cont_app_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.APPLICATION_SETTINGS],
#                   AppSettingsPage)
#
#
# @pytestrail.case('C33618')
# @pytest.mark.pipeline
# def test_c33618_validate_policy_detail_endpoints_skws_cont_browser(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.BROWSER_SETTINGS],
#                   BrowserSettingsPage)
#
#
# @pytestrail.case('C33619')
# @pytest.mark.pipeline
# def test_c33619_validate_policy_detail_endpoints_skws_cont_cert_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.CERTIFICATE_SETTINGS],
#                   CertificateSettingsPage)
#
#
# @pytestrail.case('C33609')
# @pytest.mark.pipeline
# def test_c33609_validate_policy_detail_endpoints_skws_cont_container_acct(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.CONTAINER_ACCOUNT_SETTINGS],
#                   ContainerAccountPage)
#
#
# @pytestrail.case('C33620')
# @pytest.mark.pipeline
# def test_c33620_validate_policy_detail_endpoints_skws_cont_email_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.EMAIL_SETTINGS],
#                   EmailSettingsPage)
#
#
# @pytestrail.case('C33621')
# @pytest.mark.pipeline
# def test_c33621_validate_policy_detail_endpoints_skws_cont_firewall_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.FIREWALL_SETTINGS],
#                   FirewallSettingsPage)
#
#
# @pytestrail.case('C33622')
# @pytest.mark.pipeline
# def test_c33622_validate_policy_detail_endpoints_skws_cont_passcode_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.PASSCODE_SETTINGS],
#                   PasscodeSettingsPage)
#
#
# @pytestrail.case('C33623')
# @pytest.mark.pipeline
# def test_c33623_validate_policy_detail_endpoints_skws_cont_google_aps(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.ENABLE_GOOGLE_APPS],
#                   GoogleAppsPage)
#
#
# @pytestrail.case('C33624')
# @pytest.mark.pipeline
# def test_c33624_validate_policy_detail_endpoints_skws_cont_restrictions(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.RESTRICTION_SETTINGS],
#                   RestrictionsPage)
#
#
# @pytestrail.case('C33625')
# @pytest.mark.pipeline
# def test_c33625_validate_policy_detail_endpoints_skws_cont_per_app_vpn(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.APP_VPN_SETTINGS],
#                   PerAppVPNPage)
#
#
# @pytestrail.case('C33626')
# @pytest.mark.pipeline
# def test_c33626_validate_policy_detail_endpoints_skws_cont_exchange_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.EXCHANGE_SETTINGS],
#                   ExchangeSettingsPage)
#
#
# @pytestrail.case('C33627')
# @pytest.mark.pipeline
# def test_c33627_validate_policy_detail_endpoints_skws_cont_email_account_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.CONTAINER_SETTINGS, pdc.EMAIL_ACCOUNT_SETTINGS],
#                   EmailAccountPage)
