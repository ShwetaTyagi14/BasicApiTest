import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.ui_validation import validate_page
from Helpers.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation import LockScreenPage


@pytestrail.case('C40177')
@pytest.mark.pipeline
def test_c40177_validate_policy_detail_endpoints_comm_agent_lock(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.ENDPOINT_POLICIES,
                   pdc.COMMON_SETTINGS, pdc.AGENT_SETTINGS,
                   pdc.LOCK_SCREEN],
                  LockScreenPage)
