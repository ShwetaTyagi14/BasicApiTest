import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.ui_validation import validate_page
from Helpers.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation import EndpointAutenticationPage, IdaptiveServicesPage, WindowsWorkstationPage


@pytestrail.case('C33636')
@pytest.mark.pipeline
def test_c33636_validate_policy_detail_auth_policies_idaptive_services(policy_detail_page_driver, app_helpers):
    profile_helper = app_helpers['profile_helper']
    auth_profiles = [profile['Name'] for profile in profile_helper.get_auth_profiles()]
    validate_page(policy_detail_page_driver,
                  [pdc.AUTHENTICATION_POLICIES, pdc.IDAPTIVE_SERVICES],
                  IdaptiveServicesPage, additional_args=auth_profiles)


# TODO THESE TESTS WILL MOVE TO MFA TEAM COMMENTING OUT FOR NOW

# @pytestrail.case('C33637')
# @pytest.mark.pipeline
# def test_c33637_validate_policy_detail_auth_policies_brokered_authentication(policy_detail_page_driver, app_helpers):
#     profile_helper = app_helpers['profile_helper']
#     auth_profiles = [profile['Name'] for profile in profile_helper.get_auth_profiles()]
#     validate_page(policy_detail_page_driver,
#                   [pdc.AUTHENTICATION_POLICIES, pdc.ENDPOINT_AUTHENTICATION],
#                   EndpointAutenticationPage, additional_args=auth_profiles)
#
#
# @pytestrail.case('C33638')
# @pytest.mark.pipeline
# def test_c33638_validate_policy_detail_auth_policies_windows_workstations(policy_detail_page_driver, app_helpers):
#     profile_helper = app_helpers['profile_helper']
#     auth_profiles = [profile['Name'] for profile in profile_helper.get_auth_profiles()]
#     validate_page(policy_detail_page_driver,
#                   [pdc.AUTHENTICATION_POLICIES, pdc.WINDOWS_WORKSTATIONS],
#                   WindowsWorkstationPage, additional_args=auth_profiles)
