# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM
#
# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import ApplicationManagementPage, BluetoothSettingsPage, BookmarkSettingsPage, DeviceInventoryPage,\
#      PasswordSettingsPage, RestrictionsSettingsPage, RoamingSettingsPage, SecuritySettingsPage,\
#      VPNSettingsPage, WiFiSettingsPage, ExchangeSettingsPage, VPNRestrictionsPage, APNSettingsPage,\
#      WiFiRestrictionsPage, KioskModePage, EmailAccountSettingsPage
#
#
# @pytestrail.case('C33560')
# @pytest.mark.pipeline
# def test_c33560_validate_policy_detail_endpoints_skd_app_management(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.APPLICATION_MANAGEMENT],
#                   ApplicationManagementPage)
#
#
# @pytestrail.case('C33561')
# @pytest.mark.pipeline
# def test_c33561_validate_policy_detail_endpoints_skd_bluetooth(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.BLUETOOTH_SETTINGS],
#                   BluetoothSettingsPage)
#
#
# @pytestrail.case('C33562')
# @pytest.mark.pipeline
# def test_c33562_validate_policy_detail_endpoints_skd_bookmark(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.BOOKMARK_SETTINGS],
#                   BookmarkSettingsPage)
#
#
# @pytestrail.case('C33563')
# @pytest.mark.pipeline
# def test_c33563_validate_policy_detail_endpoints_skd_device_inventory(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SAMSUMG_KNOX_DEV_SETTINGS,
#                    pdc.DEVICE_INVENTORY_SETTINGS],
#                   DeviceInventoryPage)
#
#
# @pytestrail.case('C33566')
# @pytest.mark.pipeline
# def test_c33566_validate_policy_detail_endpoints_skd_password_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.PASSWORD_SETTINGS],
#                   PasswordSettingsPage)
#
#
# @pytestrail.case('C33567')
# @pytest.mark.pipeline
# def test_c33567_validate_policy_detail_endpoints_skd_restriction_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.RESTRICTIONS_SETTINGS],
#                   RestrictionsSettingsPage)
#
#
# @pytestrail.case('C33576')
# @pytest.mark.pipeline
# def test_c33576_validate_policy_detail_endpoints_skd_roaming_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.ROAMING_SETTINGS],
#                   RoamingSettingsPage)
#
#
# @pytestrail.case('C33588')
# @pytest.mark.pipeline
# def test_c33588_validate_policy_detail_endpoints_skd_security(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.SECURITY_SETTINGS],
#                   SecuritySettingsPage)
#
#
# @pytestrail.case('C33568')
# @pytest.mark.pipeline
# def test_c33568_validate_policy_detail_endpoints_skd_vpn_restrictions(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.VPN_RESTRICTIONS],
#                   VPNRestrictionsPage)
#
#
# @pytestrail.case('C33569')
# @pytest.mark.pipeline
# def test_c33569_validate_policy_detail_endpoints_skd_wifi_restrictions(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.WIFI_RESTRICTIONS],
#                   WiFiRestrictionsPage)
#
#
# @pytestrail.case('C33570')
# @pytest.mark.pipeline
# def test_c33570_validate_policy_detail_endpoints_skd_exch_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.EXCHANGE_SETTINGS],
#                   ExchangeSettingsPage)
#
#
# @pytestrail.case('C33571')
# @pytest.mark.pipeline
# def test_c33571_validate_policy_detail_endpoints_skd_vpn_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SAMSUMG_KNOX_DEV_SETTINGS,
#                    pdc.VPN_SETTINGS],
#                   VPNSettingsPage)
#
#
# @pytestrail.case('C33572')
# @pytest.mark.pipeline
# def test_c33572_validate_policy_detail_endpoints_skd_apn_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SAMSUMG_KNOX_DEV_SETTINGS,
#                    pdc.APN_SETTINGS],
#                   APNSettingsPage)
#
#
# @pytestrail.case('C33573')
# @pytest.mark.pipeline
# def test_c33573_validate_policy_detail_endpoints_skd_wifi_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SAMSUMG_KNOX_DEV_SETTINGS,
#                    pdc.WIFI_SETTINGS],
#                   WiFiSettingsPage)
#
#
# @pytestrail.case('C33574')
# @pytest.mark.pipeline
# def test_c33574_validate_policy_detail_endpoints_skd_kiosk(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.KIOSK_MODE],
#                   KioskModePage)
#
#
# @pytestrail.case('C33575')
# @pytest.mark.pipeline
# def test_c33575_validate_policy_detail_endpoints_skd_email(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SAMSUMG_KNOX_DEV_SETTINGS, pdc.EMAIL_ACCOUNT_SETTINGS],
#                   EmailAccountSettingsPage)
