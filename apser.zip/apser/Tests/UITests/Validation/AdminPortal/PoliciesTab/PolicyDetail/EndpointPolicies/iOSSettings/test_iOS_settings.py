# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM
#
# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import RestrictionsSettingsPage, ExchangeSettingsPage, DomainSettingsPage, KioskModePage,\
#      GlobalHttpProxyPage, PerAppVpnPage, CalendarSettingsPage, ContactsSettingsPage, LdapSettingsPage,\
#      MailSettingsPage, AppManagementPage, ProvisioningProfilesPage
#
#
# @pytestrail.case('C27901')
# @pytest.mark.pipeline
# def test_c27901_validate_policy_detail_endpoints_ios_restrictions(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.IOS_SETTINGS,
#                    pdc.RESTRICTIONS_SETTINGS],
#                   RestrictionsSettingsPage)
#
#
# @pytestrail.case('C27902')
# @pytest.mark.pipeline
# def test_c27902_validate_policy_detail_endpoints_ios_exchange(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.EXCHANGE_SETTINGS],
#                   ExchangeSettingsPage)
#
#
# @pytestrail.case('C27903')
# @pytest.mark.pipeline
# def test_c27903_validate_policy_detail_endpoints_ios_domain(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.DOMAIN_SETTINGS],
#                   DomainSettingsPage)
#
#
# @pytestrail.case('C27904')
# @pytest.mark.pipeline
# def test_c27904_validate_policy_detail_endpoints_ios_kiosk(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.KIOSK_MODE],
#                   KioskModePage)
#
#
# @pytestrail.case('C27905')
# @pytest.mark.pipeline
# def test_c27905_validate_policy_detail_endpoints_ios_global_proxy(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.GLOBAL_HTTP_PROXY],
#                   GlobalHttpProxyPage)
#
#
# @pytestrail.case('C27906')
# @pytest.mark.pipeline
# def test_c27906_validate_policy_detail_endpoints_ios_per_app_vpn(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.PER_APP_VPN_SETTINGS],
#                   PerAppVpnPage)
#
#
# @pytestrail.case('C27907')
# @pytest.mark.pipeline
# def test_c27907_validate_policy_detail_endpoints_ios_calendar(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.CALENDAR_SETTINGS],
#                   CalendarSettingsPage)
#
#
# @pytestrail.case('C27908')
# @pytest.mark.pipeline
# def test_c27908_validate_policy_detail_endpoints_ios_contacts(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.CONTACTS_SETTINGS],
#                   ContactsSettingsPage)
#
#
# @pytestrail.case('C27909')
# @pytest.mark.pipeline
# def test_c27909_validate_policy_detail_endpoints_ios_ldap(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.LDAP_SETTINGS],
#                   LdapSettingsPage)
#
#
# @pytestrail.case('C27910')
# @pytest.mark.pipeline
# def test_c27910_validate_policy_detail_endpoints_ios_mail(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.MAIL_SETTINGS],
#                   MailSettingsPage)
#
#
# @pytestrail.case('C27911')
# @pytest.mark.pipeline
# def test_c27911_validate_policy_detail_endpoints_ios_app_manage(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.APPLICATION_MANAGEMENT_SETTINGS],
#                   AppManagementPage)
#
#
# @pytestrail.case('C27912')
# @pytest.mark.pipeline
# def test_c27912_validate_policy_detail_endpoints_ios_provisioning(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.IOS_SETTINGS, pdc.PROVISIONING_PROFILES],
#                   ProvisioningProfilesPage)
