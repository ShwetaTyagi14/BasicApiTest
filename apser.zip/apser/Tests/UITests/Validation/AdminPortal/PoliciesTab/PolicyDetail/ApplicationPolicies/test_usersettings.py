import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.ui_validation import validate_page
from Helpers.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation import UserSettingsPage


@pytestrail.case('C27894')
@pytest.mark.pipeline
def test_c27894_validate_policy_detail_app_policies_user_settings(policy_detail_page_driver, latest_ibe_fixture):
    validate_page(policy_detail_page_driver,
                  [pdc.APPLICATION_POLICIES, pdc.USER_SETTINGS],
                  UserSettingsPage,
                  latest_ibe_fixture)
