import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.ui_validation import validate_page
from Helpers.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation import ApplicationsPage, MediaPage, PreferencesPage, RestrictApplicationsPage, RestrictPreferencesPage


@pytestrail.case('C27917')
@pytest.mark.pipeline
def test_c27917_validate_policy_detail_endpoints_osx_restrictions_apps(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.RESTRICTIONS_SETTINGS,
                   pdc.APPLICATIONS],
                  ApplicationsPage)


@pytestrail.case('C27918')
@pytest.mark.pipeline
def test_c27918_validate_policy_detail_endpoints_osx_restrictions_media(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.RESTRICTIONS_SETTINGS, pdc.MEDIA],
                  MediaPage)


@pytestrail.case('C27919')
@pytest.mark.pipeline
def test_c27919_validate_policy_detail_endpoints_osx_restrictions_preferences(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.RESTRICTIONS_SETTINGS,
                   pdc.PREFERENCES],
                  PreferencesPage)


@pytestrail.case('C27921')
@pytest.mark.pipeline
def test_c27921_validate_policy_detail_endpoints_osx_restrict_apps(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.RESTRICTIONS_SETTINGS, pdc.RESTRICT_APPLICATIONS],
                  RestrictApplicationsPage)


@pytestrail.case('C27920')
@pytest.mark.pipeline
def test_c27920_validate_policy_detail_endpoints_osx_restrictioins_restrict_prefs(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.ENDPOINT_POLICIES, pdc.OSX_SETTINGS, pdc.RESTRICTIONS_SETTINGS, pdc.RESTRICT_PREFERENCES],
                  RestrictPreferencesPage)
