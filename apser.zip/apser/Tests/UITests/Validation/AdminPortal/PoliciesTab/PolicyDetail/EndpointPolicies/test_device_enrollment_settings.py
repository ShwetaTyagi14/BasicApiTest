# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# # THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM
#
# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import DeviceEnrollmentSettingsPage
#
#
# @pytestrail.case('C27896')
# @pytest.mark.pipeline
# def test_c27896_validate_policy_detail_endpoints_dev_enroll_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.DEVICE_ENROLLMENT_SETTINGS],
#                   DeviceEnrollmentSettingsPage)
