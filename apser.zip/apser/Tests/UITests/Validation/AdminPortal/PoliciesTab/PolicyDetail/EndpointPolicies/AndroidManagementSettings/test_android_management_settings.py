# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM

# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import EnableWorkProfilesPage, ExchangeSettingsPage, CertificateProfilesPage, RestrictionsPage,\
#     SystemAppsPage, VPNSettingsPage, DeviceOwnerPage
#
#
# @pytestrail.case('C33629')
# @pytest.mark.pipeline
# def test_c33629_validate_policy_detail_endpoints_enable_wrk_profiles(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.ENABLE_WORK_PROFILES],
#                   EnableWorkProfilesPage)
#
#
# @pytestrail.case('C33630')
# @pytest.mark.pipeline
# def test_c33630_validate_policy_detail_endpoints_exchange_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.EXCHANGE_SETTINGS],
#                   ExchangeSettingsPage)
#
#
# @pytestrail.case('C33631')
# @pytest.mark.pipeline
# def test_c33631_validate_policy_detail_endpoints_certificate_profiles(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.CERTIFICATE_PROFILES],
#                   CertificateProfilesPage)
#
#
# @pytestrail.case('C33632')
# @pytest.mark.pipeline
# def test_c33632_validate_policy_detail_endpoints_restrictions(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.RESTRICTIONS],
#                   RestrictionsPage)
#
#
# @pytestrail.case('C33633')
# @pytest.mark.pipeline
# def test_c33633_validate_policy_detail_endpoints_system_apps(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.SYSTEM_APPS],
#                   SystemAppsPage)
#
#
# @pytestrail.case('C33634')
# @pytest.mark.pipeline
# def test_c33634_validate_policy_detail_endpoints_vpn_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.VPN_SETTINGS],
#                   VPNSettingsPage)
#
#
# @pytestrail.case('C33635')
# @pytest.mark.pipeline
# def test_c33635_validate_policy_detail_endpoints_device_owner(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.ANDROID_MANAGEMENT_SETTINGS,
#                    pdc.DEVICE_OWNER],
#                   DeviceOwnerPage)
