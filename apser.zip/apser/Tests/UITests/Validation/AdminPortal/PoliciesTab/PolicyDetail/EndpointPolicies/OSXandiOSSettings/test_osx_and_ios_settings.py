# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM
#
# import pytest
# from idaptive_automation.ui_automation.pages.policydetails.endpoint_policies.oSXandiOSSettings.vpn_profile_page import \
#     VpnProfilePage
# from idaptive_testrail.plugin import pytestrail
# from Steps.navigate_steps import Navigate
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import CertificateProfilesPage, ConfigurationProfilesPage, \
#     AdminPagePoliciesTab, PolicyDetailLandingPage
# from idaptive_automation.ui_automation.pages.policydetails.endpoint_policies.oSXandiOSSettings.vpn_settings_page import \
#     VPNSettingsPage
#
#
# @pytestrail.case('C27913')
# @pytest.mark.pipeline
# def test_c27913_validate_policy_detail_endpoints_osx_ios_cert_profiles(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.OSX_IOS_SETTINGS, pdc.CERTIFICATE_PROFILES],
#                   CertificateProfilesPage)
#
#
# @pytestrail.case('C27914')
# @pytest.mark.pipeline
# def test_c27914_validate_policy_detail_endpoints_osx_ios_vpn_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.OSX_IOS_SETTINGS, pdc.VPN_SETTINGS],
#                   VPNSettingsPage)
#
#
# @pytestrail.case('C27916')
# @pytest.mark.pipeline
# def test_c27916_validate_policy_detail_endpoints_osx_ios_config_profiles(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.OSX_IOS_SETTINGS, pdc.CONFIGURATION_PROFILES],
#                   ConfigurationProfilesPage)
#
#
# @pytestrail.case('C27915')
# @pytest.mark.pipeline
# def test_c27915_validate_policy_detail_endpoints_osx_ios_vpn_settings_vpn_profile(driver_admin):
#     """ UI Validation for navigation from Policy VPN Type 'IPSEC (Cisco)' """
#
#     Navigate(driver_admin).to_policies_tab()
#     AdminPagePoliciesTab(driver_admin).open_add_policy_window()
#     PolicyDetailLandingPage(driver_admin).click_endpoint_policies_tab()
#     PolicyDetailLandingPage(driver_admin).click_osx_and_ios_settings_tab()
#     PolicyDetailLandingPage(driver_admin).click_vpn_settings_tab()
#     PolicyDetailLandingPage(driver_admin).click_add_button()
#     VpnProfilePage(driver_admin).select_vpn_type('IPSEC (Cisco)')
#     VpnProfilePage(driver_admin).select_vpn_on_demand()
#     VpnProfilePage(driver_admin).validate_all_child_elements()
