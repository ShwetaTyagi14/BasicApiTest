import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.ui_validation import validate_page
from Steps.admin_policies_tab_steps import AdminPoliciesTabSteps
from idaptive_automation.api_helpers import PolicyApi
from Helpers.constants import PolicyDetailLeftNavConstants as pdc
from idaptive_automation.ui_automation import SelfServicePage, PasswordSettingsPage, OATHOTPPage, RadiusPage, \
    UserAccountSettingsPage, WarningWindow


@pytestrail.case('C33639')
@pytest.mark.pipeline
def test_c33639_validate_policy_detail_user_sec_policies_self_service(policy_detail_page_driver, app_helpers):
    profile_helper = app_helpers['profile_helper']
    auth_profiles = [profile['Name'] for profile in profile_helper.get_auth_profiles()]
    validate_page(policy_detail_page_driver,
                  [pdc.USER_SECURITY_POLICIES, pdc.SELF_SERVICE],
                  SelfServicePage, additional_args=auth_profiles)


@pytestrail.case('C33641')
@pytest.mark.pipeline
def test_c33641_validate_policy_detail_user_sec_policies_password_settings(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.USER_SECURITY_POLICIES, pdc.PASSWORD_SETTINGS],
                  PasswordSettingsPage)


@pytestrail.case('C45438')
@pytest.mark.pipeline
def test_c45438_passwd_max_age_accepts_zero_as_input(policy_detail_page_driver, app_helpers):
    policy_api = app_helpers['policy_helper']
    admin_steps = AdminPoliciesTabSteps(policy_detail_page_driver)
    policy_detail_steps = admin_steps.open_add_policy_window()
    policy_detail_steps.navigate([pdc.USER_SECURITY_POLICIES, pdc.PASSWORD_SETTINGS])

    PasswordSettingsPage(policy_detail_page_driver).set_max_password_age(0)
    policy_detail_steps.navigate([pdc.POLICY_SETTINGS])
    policy = policy_detail_steps.save_changes()[1]
    policy_api.policies_created.append(policy['Name'])
    displayed_policies = admin_steps.wait_for_policies_tab_loaded().refresh_page() \
        .get_displayed_policies()[1]

    assert policy in displayed_policies


@pytestrail.case('C33642')
@pytest.mark.pipeline
def test_c33642_validate_policy_detail_user_sec_policies_oath_otp(policy_detail_page_driver):
    validate_page(policy_detail_page_driver,
                  [pdc.USER_SECURITY_POLICIES, pdc.OATH_OTP],
                  OATHOTPPage)


@pytestrail.case('C33643')
@pytest.mark.pipeline
def test_c33643_validate_policy_detail_user_sec_policies_radius(policy_detail_page_driver, app_helpers):
    profile_helper = app_helpers['profile_helper']
    auth_profiles = [profile['Name'] for profile in profile_helper.get_auth_profiles()]
    validate_page(policy_detail_page_driver,
                  [pdc.USER_SECURITY_POLICIES, pdc.RADIUS],
                  RadiusPage, additional_args=auth_profiles)


@pytestrail.case('C33644')
@pytest.mark.pipeline
def test_c33644_validate_policy_detail_user_sec_policies_user_account_settings(policy_detail_page_driver, app_helpers):
    profile_helper = app_helpers['profile_helper']
    auth_profiles = [profile['Name'] for profile in profile_helper.get_auth_profiles()]
    validate_page(policy_detail_page_driver,
                  [pdc.USER_SECURITY_POLICIES, pdc.USER_ACCOUNT_SETTINGS],
                  UserAccountSettingsPage, additional_args=auth_profiles)


@pytestrail.case('C28041')
@pytest.mark.pipeline
def test_c28041_admin_cannot_set_password_min_length_to_less_than_max_length(policy_detail_page_driver, app_helpers):
    """ admin cannot set password min length to less than max length """

    policy_api = app_helpers['policy_helper']
    admin_steps = AdminPoliciesTabSteps(policy_detail_page_driver)

    policy_detail_steps = admin_steps.open_add_policy_window()
    policy_detail_steps.navigate([pdc.USER_SECURITY_POLICIES, pdc.PASSWORD_SETTINGS])

    PasswordSettingsPage(policy_detail_page_driver).set_min_password_length(13)
    PasswordSettingsPage(policy_detail_page_driver).set_max_password_length(10)

    policy_detail_steps.click_save_changes()

    expected_text = 'Please correct the errors in your form before submitting.'

    actual_text = WarningWindow(policy_detail_page_driver).warning_message_text()
    assert actual_text == expected_text, f'Incorrect message, expected {expected_text}, found {actual_text}'