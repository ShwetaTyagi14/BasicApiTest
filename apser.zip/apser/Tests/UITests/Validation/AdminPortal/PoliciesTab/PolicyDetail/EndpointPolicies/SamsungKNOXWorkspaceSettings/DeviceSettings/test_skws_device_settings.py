# REMOVING THIS ENTIRE SECTION FROM APPS AUTOMATION ALL OF THESE POLICIES ARE NOW HIDDEN BEHIND AN ENTITLEMENT FOR
# ENDPOINTS
# THESE TESTS WILL BE MOVED TO THE ENDPOINTS TEAM
# import pytest
# from idaptive_testrail.plugin import pytestrail
# from Steps.ui_validation import validate_page
# from Helpers.constants import PolicyDetailLeftNavConstants as pdc
# from idaptive_automation.ui_automation import EnableAuditLogPage, EnableCertValidationPage, EnableRevocationCheckPage, PerAppVPNPage,\
#     RestrictionsSettingsPage, TrustedCertPage
#
#
# @pytestrail.case('C33600')
# @pytest.mark.pipeline
# def test_c33600_validate_policy_detail_endpoints_skws_cert_validation(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.DEVICE_SETTINGS,
#                    pdc.ENABLE_CERTIFICATE],
#                   EnableCertValidationPage)
#
#
# @pytestrail.case('C33601')
# @pytest.mark.pipeline
# def test_c33601_validate_policy_detail_endpoints_skws_revocation_check(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.DEVICE_SETTINGS,
#                    pdc.ENABLE_REVOCATION],
#                   EnableRevocationCheckPage)
#
#
# @pytestrail.case('C33602')
# @pytest.mark.pipeline
# def test_c33602_validate_policy_detail_endpoints_skws_trusted_cert_authorities(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.DEVICE_SETTINGS,
#                    pdc.TRUSTED_CERTIFICATE],
#                   TrustedCertPage)
#
#
# @pytestrail.case('C33603')
# @pytest.mark.pipeline
# def test_c33603_validate_policy_detail_endpoints_skws_per_app_vpn(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.DEVICE_SETTINGS,
#                    pdc.APP_VPN_SETTINGS],
#                   PerAppVPNPage)
#
#
# @pytestrail.case('C33604')
# @pytest.mark.pipeline
# def test_c33604_validate_policy_detail_endpoints_skws_audit_log(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES, pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS, pdc.DEVICE_SETTINGS,
#                    pdc.ENABLE_AUDIT_LOG],
#                   EnableAuditLogPage)
#
#
# @pytestrail.case('C33605')
# @pytest.mark.pipeline
# def test_c33605_validate_policy_detail_endpoints_skws_restriction_settings(policy_detail_page_driver):
#     validate_page(policy_detail_page_driver,
#                   [pdc.ENDPOINT_POLICIES,
#                    pdc.SMASUNG_KNOX_WRKSPACE_SETTINGS,
#                    pdc.DEVICE_SETTINGS,
#                    pdc.RESTRICTION_SETTINGS],
#                   RestrictionsSettingsPage)
