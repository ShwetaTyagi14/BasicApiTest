# import pytest
# from idaptive_testrail.plugin import pytestrail
# from selenium import webdriver
# from Common import Driver
# from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture, \
#     authenticated_b2b_partner_api_function_fixture as b2b_partner_session_fixture
# from idaptive_automation.api_helpers import TenantApiHelper, UserApi, RoleApi, PolicyApi, FederationHelper, AppHelper, \
#     PartnerApi, AuthProfileHelper
# from idaptive_automation.api_payloads import CloudUser, PartnerCreation, AuthenticationProfile
# from idaptive_automation.ui_automation import SAMLAppGatewayConfigPage, SAMLAppGatewaySettingsPage, \
#     SAMLAppGatewayTrustPage, UserPortalPage, SettingsUsersPartnerManagementPage, SettingsUsersPartnersTab, \
#     UserProfileMenu, PartnerManagementConfigDialog, SettingsUsersPage, PartnerManagementConfigSettingTab, \
#     PartnerManagementConfigAuthenticationTab, PartnerManagementConfigGroupMappingsTab, \
#     PartnerManagementConfigInboundMDTab, PartnerManagementConfigOutboundMDTab
# from Steps.navigate_steps import Navigate, Login
# import config
#
#
# @pytestrail.case('C40027')
# @pytest.mark.pipeline
# def test_c40027_check_for_map_federated_user_to_existing_directory_user_options(admin_portal_function_driver,
#                                                                                 case_number):
#     """ Check for 'Map federated user to existing directory user' options """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#
#     partners_tab = SettingsUsersPartnersTab(admin_portal_function_driver).wait_for_page_to_load()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#     fed_user_options = ['Disabled', 'Optional', 'Required']
#     assert PartnerManagementConfigAuthenticationTab(
#         admin_portal_function_driver).map_fed_user_select_displayed().__contains__(fed_user_options[0]), f'Expected {fed_user_options[0]} is displayed, but not displayed'
#     assert PartnerManagementConfigAuthenticationTab(
#         admin_portal_function_driver).map_fed_user_select_displayed().__contains__(fed_user_options[1]), f'Expected {fed_user_options[1]} is displayed, but not displayed'
#     assert PartnerManagementConfigAuthenticationTab(
#         admin_portal_function_driver).map_fed_user_select_displayed().__contains__(fed_user_options[2]), f'Expected {fed_user_options[0]} is displayed, but not displayed'
#
#
# @pytestrail.case('C40028')
# @pytest.mark.pipeline
# def test_c40028_check_for_directory_user_mapping_attribute_options(admin_portal_function_driver,
#                                                                    case_number):
#     """ Check for 'Directory user mapping attribute' options like 'Name' and 'Uuid' """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#
#     partners_tab = SettingsUsersPartnersTab(admin_portal_function_driver).wait_for_page_to_load()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     config_authentication.validate_url_pattern_field_shown()
#     config_authentication.set_map_federated_user('Optional')
#     options = ['Name', 'Uuid']
#     assert config_authentication.map_directory_user_attr_displayed().__contains__(options[0]), f"Options for Directory user attribute expected to be found is {options[0]}, but is not found"
#     assert config_authentication.map_directory_user_attr_displayed().__contains__(options[1]), f"Options for Directory user attribute expected to be found is {options[1]}, but is not found"
#
#
# @pytestrail.case('C40029')
# @pytest.mark.pipeline
# def test_c40029_check_no_acct_linking_details_showing_up(admin_portal_function_driver, case_number):
#     """ Check that no account linking details show up when 'Map federated user to existing directory user' is Disabled  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#     PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).set_map_federated_user('Disabled')
#     assert PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).fed_user_map_attr_displayed() is False, f'Expected "Fed User Map Attribute" is not to be displayed, but found'
#     assert PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).directory_user_attr_displayed() is False, f'Expected "Directory User Map Attribute" is not to be displayed, but found'
#
#
# @pytestrail.case('C40030')
# @pytest.mark.pipeline
# def test_c40030_check_acct_linking_details_showing_up(admin_portal_function_driver, case_number):
#     """ Check that account linking details show up when 'Map federated user to existing directory user' is Optional  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#     PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).set_map_federated_user('Optional')
#     assert PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).fed_user_map_attr_displayed() is True, f'Expected "Fed User Map Attribute" is diaplayed, found {PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).fed_user_map_attr_displayed()}'
#     assert PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).directory_user_attr_displayed() is True, f'Expected "Directory User Map Attribute" is diaplayed, found {PartnerManagementConfigAuthenticationTab(admin_portal_function_driver).map_directory_user_attr_displayed()}'
#
#
# @pytestrail.case('C40032')
# @pytest.mark.pipeline
# def test_c40032_check_that_fed_user_mapping_attr_is_mandatory(admin_portal_function_driver, case_number):
#     """ Check that 'Federated user mapping attribute' is a mandatory field and
#         if left blank I should not be able to save the partner configuration  """
#     fed_domain = 'test domain'
#     partner_name = f'{fed_domain.upper()} for test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     assert config_authentication.is_save_button_disabled() is False, f'Expected save button is enabled, but found disabled'
#     config_authentication.set_map_federated_user('Optional')
#     config_authentication.set_fed_user_map_attr('')
#     assert config_authentication.is_save_button_disabled() is True, f'Expected save button is enabled, but found enabled'
#
#
# @pytestrail.case('C40033')
# @pytest.mark.pipeline
# def test_c40033_check_that_url_pattern_field_shows_when_url_redirecting_enabled(admin_portal_function_driver, case_number):
#     """ Check that 'URL Pattern' field shows up when 'Enable URL Redirecting' is enabled    """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     assert config_authentication.validate_url_pattern_field_shown() is True, f'Expected Url Pattern to be displayed,but not displayed and is {config_authentication.validate_url_pattern_field_shown()}'
#
#
# @pytestrail.case('C40045')
# @pytest.mark.pipeline
# def test_c40045_check_update_cloud_users_with_fed_user_attr_checkbox_shown_up(admin_portal_function_driver, case_number):
#     """ Check for 'Update cloud users with federated user attributes' when 'Map federated user
#         to existing directory user' is set to 'Optional' or 'Required'  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     assert config_authentication.validate_update_cloud_users_with_fed_user_attr_shown('Optional') is True, f'Expected Cloud users with fed user attribute to be shown up, but not displayed'
#
#
# @pytestrail.case('C40282')
# @pytest.mark.pipeline
# def test_c40282_check_preferred_directory_services_dropdown(admin_portal_function_driver, case_number):
#     """ Check for "preferred directory services" drop-down with 'Any Directory Service', 'Idaptive Directory', 'LDAP: AppsLDAP5'  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     config_authentication.set_map_federated_user('Optional')
#     pref_dir_services = ['Any Directory Service', 'Idaptive Directory', 'LDAP: AppsLDAP5']
#     assert config_authentication.map_preferred_dir_service_displayed().__contains__(pref_dir_services[0]), f"Option for Preferred Dir Service expected to be found, but is not found"
#     assert config_authentication.map_preferred_dir_service_displayed().__contains__(pref_dir_services[1]), f"Option for Preferred Dir Service expected to be found, but is not found"
#     assert config_authentication.map_preferred_dir_service_displayed().__contains__(pref_dir_services[2]), f"Option for Preferred Dir Service expected to be found, but is not found"
#     assert config_authentication.preferred_directory_service_displayed() is True, f"Preferred Dir Service expected to be found, but not found"
#
#
# @pytestrail.case('C33529')
# @pytest.mark.pipeline
# def test_c33529_validation_of_settings_partner_management_wizard(admin_portal_function_driver, case_number):
#     """ To validate Partner management settings tab  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#     assert PartnerManagementConfigSettingTab(admin_portal_function_driver).validate_fed_type_select_displayed() == ['SAML 2.0']
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).set_federation_type('SAML 2.0')
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).click_save()
#
#
# @pytestrail.case('C33531')
# @pytest.mark.pipeline
# def test_c33531_validate_inbound_metadata_options_on_partner_mgmt_wizard(admin_portal_function_driver, case_number):
#     """  Validation of 'Inbound Metadata' available 3 options on Partner Management wizard """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_inbound_md_tab()
#     PartnerManagementConfigInboundMDTab(admin_portal_function_driver).validate_idp_config_options_present()
#
#
# @pytestrail.case('C33532')
# @pytest.mark.pipeline
# def test_c33532_validate_outbound_metadata_options_on_partner_mgmt_wizard(admin_portal_function_driver, case_number):
#     """  Validation of 'Outbound Metadata' available 3 options on Partner Management wizard """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_outbound_md_tab()
#     PartnerManagementConfigOutboundMDTab(admin_portal_function_driver).validate_idp_config_options_present()
#
#
# @pytestrail.case('C33533')
# @pytest.mark.pipeline
# def test_c33533_validation_of_authentication_on_partner_management_wizard(admin_portal_function_driver, case_number):
#     """ Validation of 'Authentication' on Partner Management wizard  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#
#     assert config_authentication.validate_update_cloud_users_with_fed_user_attr_shown(
#         'Optional') is True, f'Expected Cloud users with fed user attribute to be shown up, but not displayed'
#
#     options = ['Name', 'Uuid']
#     assert config_authentication.map_directory_user_attr_displayed().__contains__(
#         options[0]), f"Options for Directory user attribute expected to be found is {options[0]}, but is not found"
#     assert config_authentication.map_directory_user_attr_displayed().__contains__(
#         options[1]), f"Options for Directory user attribute expected to be found is {options[1]}, but is not found"
#
#     assert config_authentication.get_fed_user_map_attr_value() == "UserPrincipalName", f"Text error ,expected text not found, found {config_authentication.get_fed_user_map_attr_value()}"
#     assert config_authentication.is_fed_user_map_attr_editable() is True, f"Validation error ,expected state is editable, found {config_authentication.is_fed_user_map_attr_editable()}"
#
#
# @pytestrail.case('C39989')
# @pytest.mark.pipeline
# def test_c39989_validation_of_switch_to_every_tab_on_partner_management_wizard(admin_portal_function_driver, case_number):
#     """ Validation of 'Switching between all tabs' on Partner Management wizard  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     sample_url = f'https://www.google.com'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     settings_tab = PartnerManagementConfigSettingTab(admin_portal_function_driver)
#     inbound_tab = PartnerManagementConfigInboundMDTab(admin_portal_function_driver)
#     config_dialog.switching_from_settings_tab_to_group_mappings()
#
#     assert settings_tab.check_partner_name_invalid() is True, f'Expected invalid message on Settings tab,but found {settings_tab.check_partner_name_invalid()}'
#     assert settings_tab.domain_name_not_configured() is True, f'Expected Domain name not configured to be displayed,but not found and is {settings_tab.domain_name_not_configured()}'
#     settings_tab.enter_partner_name(partner_name)
#     settings_tab.add_federated_domain(fed_domain)
#     assert settings_tab.check_partner_name_invalid() is False, f'Expected no error message on Settings tab,but found error and is {settings_tab.check_partner_name_invalid()}'
#     config_dialog.wait_for_page_to_load(10)
#     config_dialog.switching_from_settings_tab_to_group_mappings()
#
#     config_dialog.click_inbound_md_tab()
#     config_dialog.switching_from_inbound_tab_to_outbound_md()
#     assert inbound_tab.get_idp_md_url_state() is True
#     inbound_tab.input_idp_config_from_url(sample_url)
#     config_dialog.click_outbound_md_tab()
#     config_dialog.click_authentication_tab()
#
#
# @pytestrail.case('C39990')
# @pytest.mark.pipeline
# def test_c39990_cannot_save_partner_without_inputting_required_field(admin_portal_function_driver):
#     """ Cannot save Partner without inputting required field and validate save button is disabled """
#     name = 'test'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).wait_for_page_to_load()
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(name)
#
#     assert PartnerManagementConfigSettingTab(admin_portal_function_driver).is_save_button_disabled() is True, f'can save, found cannot save'
#
#
# @pytestrail.case('C39991')
# @pytest.mark.pipeline
# def test_c39991_link_to_related_document_via_learn_more(admin_portal_function_driver):
#     """  Link to related document via "Learn more",
#         Then I see a new tab opens which is pointing to documentation on adding a partner """
#
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#
#     SettingsUsersPartnerManagementPage(admin_portal_function_driver).wait_for_page_to_load()
#     SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_learn_more_link()
#
#     expected_title = 'Adding a partner'
#     actual_title = SettingsUsersPartnerManagementPage(admin_portal_function_driver).validate_adding_partner_window()
#     assert actual_title == expected_title, f'Incorrect title, expected {expected_title}, found {actual_title}'
#
#
# @pytestrail.case('C33694')
# @pytest.mark.pipeline
# def test_c33694_cannot_save_partner_management_without_inputting_required_feild(admin_portal_function_driver, case_number):
#     """ Check that 'Federated user mapping attribute' is a mandatory field and
#         if left blank I should not be able to save the partner configuration  """
#     fed_domain = 'test domain'
#     partner_name = f'{fed_domain.upper()} for test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     assert config_authentication.is_save_button_disabled() is True, f'Expected save button is disabled, but found enabled'
#
#
# @pytestrail.case('C33527')
# @pytest.mark.pipeline
# def test_c33527_validation_of_partner_management_tab_in_ap(admin_portal_function_driver):
#     """  Validating partner management tab in admin portal """
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     settings_users_partner_management_page = SettingsUsersPartnerManagementPage(admin_portal_function_driver)
#     settings_users_partner_management_page.wait_for_page_to_load()
#     settings_users_partners_tab = SettingsUsersPartnersTab(admin_portal_function_driver)
#     settings_users_partners_tab.get_displayed_partners()
#     assert len(settings_users_partners_tab.get_displayed_partners()) >= 1, f'Partner not exists, Found {len(settings_users_partners_tab.get_displayed_partners())}'
#
#
# @pytestrail.case('C33530')
# @pytest.mark.pipeline
# def test_c33530_validation_of_group_mappings_on_partner_management_wizard(admin_portal_function_driver, case_number):
#     """ To validate Partner management group mappings tab  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     PartnerManagementConfigDialog(admin_portal_function_driver).click_group_mappings_tab()
#
#     PartnerManagementConfigGroupMappingsTab(admin_portal_function_driver).wait_for_page_to_load()
#     PartnerManagementConfigGroupMappingsTab(admin_portal_function_driver).click_add_group()
#     PartnerManagementConfigGroupMappingsTab(admin_portal_function_driver).validate_all_child_elements()
#     PartnerManagementConfigGroupMappingsTab(admin_portal_function_driver).set_group_value(group_attr_value="SampleAttrValue")
#     PartnerManagementConfigGroupMappingsTab(admin_portal_function_driver).set_group_name(group_name="SampleAttrName")
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).click_save()
#
#
# @pytest.fixture()
# def policy(pwd_only_profile):
#     yield {
#         "AuthenticationEnabled": True,
#         "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
#     }
#
#
# @pytest.fixture()
# def pwd_only_profile(session_fixture, case_number):
#     with AuthProfileHelper(session_fixture['session'], True) as profile_helper:
#         yield profile_helper.create_profile(AuthenticationProfile(f'{case_number} Pwd Only Profile')
#                                             .with_challenges(["UP"])
#                                             .with_duration_in_minutes(5)
#                                             .to_payload())
#
#
# @pytest.fixture()
# def ro_admin_user(session_fixture,
#                   new_cloud_user,
#                   case_number):
#     role_api = new_cloud_user['role_api']
#     # role_name = f'Test role {case_number}'
#     # role_id = role_api.create_role(role_name)
#     role_api.assign_super_rights_to_role([{"Role": new_cloud_user['role'], "Path": "/lib/rights/monitor.json"}])
#     return new_cloud_user
#
#
# @pytest.fixture()
# def setup_ro_partner_access(session_fixture, new_cloud_user):
#     with PartnerApi(session_fixture['session'], True) as partner_helper:
#         payload = PartnerCreation(session_fixture['session']).with_federation_name('test') \
#             .with_domain(["test"]) \
#             .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9',
#                                   'AAP0774') \
#             .to_payload()
#         partner_helper.create_partner(payload)
#         role_api = new_cloud_user['role_api']
#         role_api.assign_super_rights_to_role([{"Role": new_cloud_user['role'], "Path": "/lib/rights/monitor.json"}])
#         yield new_cloud_user, payload
#
#
# @pytestrail.case('C39993')
# @pytest.mark.pipeline
# def test_c39993_ro_admin_access_partner_management(ro_admin_policy_fixture, setup_ro_partner_access):
#     session, browser = ro_admin_policy_fixture
#     new_cloud_user, partner = setup_ro_partner_access
#     Login(browser, session['session'].base_url).to_admin_portal(new_cloud_user['user']['Name'],
#                                                                 new_cloud_user['user']['Password'])
#     Navigate(browser).to_settings_users_tab()
#     SettingsUsersPage(browser).click_partner_management()
#     settings_users_partners_tab = SettingsUsersPartnersTab(browser)
#     partners = settings_users_partners_tab.get_displayed_partners()
#     assert partners.__len__() > 0
#
#     settings_users_partners_tab.open_partner_config_by_name(partner['FederationName'])
#     PartnerManagementConfigSettingTab(browser).enter_partner_name('C39993')
#     PartnerManagementConfigSettingTab(browser).click_save()
#     PartnerManagementConfigSettingTab(browser).validate_permission_error()
#
#
# @pytestrail.case('C40031')
# @pytest.mark.pipeline
# def test_c40031_check_account_linking_details(admin_portal_function_driver, case_number):
#     """ Check that account linking details show up when
#         'Map federated user to existing directory user' is selected 'Required'  """
#     fed_domain = 'test domain'
#     partner_name = f'test {case_number}'
#     Navigate(admin_portal_function_driver).to_settings_users_tab()
#     SettingsUsersPage(admin_portal_function_driver).click_partner_management()
#     partners_tab = SettingsUsersPartnerManagementPage(admin_portal_function_driver).click_partners_tab()
#     partners_tab.click_add_partner()
#
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).enter_partner_name(partner_name)
#     PartnerManagementConfigSettingTab(admin_portal_function_driver).add_federated_domain(fed_domain)
#
#     config_dialog = PartnerManagementConfigDialog(admin_portal_function_driver)
#     config_dialog.click_authentication_tab()
#
#     config_authentication = PartnerManagementConfigAuthenticationTab(admin_portal_function_driver)
#     assert config_authentication.is_save_button_disabled() is False, f'Expected save button is enabled, but found disabled'
#     assert config_authentication.fed_user_map_attr_displayed() is False, f'Fed user map attribute is displayed'
#     assert config_authentication.preferred_directory_service_displayed() is False, f'Preferred dir service is displayed'
#     assert config_authentication.directory_user_attr_displayed() is False, f'Directory user attribute is displayed'
#
#     config_authentication.set_map_federated_user('Required')
#     assert config_authentication.fed_user_map_attr_displayed() is True, f'Fed user map attribute is not displayed'
#     assert config_authentication.preferred_directory_service_displayed() is True, f'Preferred dir service is not displayed'
#     assert config_authentication.directory_user_attr_displayed() is True, f'Directory user attribute is not displayed'