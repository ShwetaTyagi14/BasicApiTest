import pytest
import uuid
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import RolesTabPage
from Steps.navigate_steps import Navigate, Login


@pytestrail.case('C28076')
@pytest.mark.pipeline
def test_c28076_validate_roles_landing_tab(driver, app_helpers):
    """ To validate correct list of roles displayed in Roles Landing Tab in AP  """
    tenant_info = app_helpers['tenant_info']
    role_name = f'Test role {uuid.uuid4()}'

    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_roles_tab()
    RolesTabPage(driver).wait_for_page_to_load()
    RolesTabPage(driver).validate_all_child_elements()
