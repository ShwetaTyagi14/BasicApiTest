import pytest
import uuid
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import RolesTabPage
from Steps.navigate_steps import Navigate, Login


@pytestrail.case('C28079')
@pytest.mark.pipeline
def test_c28079_validate_add_edit_role_dialog(driver, app_helpers):
    """ To validate add/edit role dialog    """
    tenant_info = app_helpers['tenant_info']
    role_name = f'Test role {uuid.uuid4()}'

    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])

    Navigate(driver).to_roles_tab()
    add_role_dialog = RolesTabPage(driver).open_add_role_window()
    add_role_dialog.validate_all_child_elements()
    add_role_dialog.set_role_name(role_name)
    add_role_dialog.select_members_tab()
    add_role_dialog.validate_members_tab_is_loaded()
    add_role_dialog.select_admin_rights_tab()
    add_role_dialog.validate_admin_rights_tab_is_loaded()
    add_role_dialog.select_assigned_apps_tab()
    add_role_dialog.validate_assigned_apps_tab_is_loaded()


@pytestrail.case('C93704')
@pytest.mark.pipeline
def test_c93704_validate_add_members_to_role_dialog(driver, app_helpers):
    """ To validate Add Members to role dialog"""
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_roles_tab()
    role_name = f'Test role {uuid.uuid4()}'

    add_role_dialog = RolesTabPage(driver).open_add_role_window()
    add_role_dialog.set_role_name(role_name)
    add_role_dialog.select_members_tab()

    add_members_window = add_role_dialog.open_add_members_window()
    add_members_window.validate_all_elements()\
        .validate_all_child_elements()


@pytestrail.case('C93705')
@pytest.mark.pipeline
def test_c93705_validate_add_applications_to_role_dialog(driver, app_helpers):
    """ To validate Add Applications to role dialog"""
    tenant_info = app_helpers['tenant_info']
    role_api = app_helpers['role_helper']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    role_name = f'test role {uuid.uuid4()}'
    role_id = role_api.create_role(role_name)
    Navigate(driver).to_roles_tab()

    add_role_dialog = RolesTabPage(driver).open_add_role_window()
    add_role_dialog.set_role_name(role_name)
    add_role_dialog.select_assigned_apps_tab()

    add_apps_window = add_role_dialog.open_add_apps_window()
    add_apps_window.validate_all_elements().validate_all_child_elements()


@pytestrail.case('C93748')
@pytest.mark.pipeline
def test_c93748_validate_add_admin_rights_to_role_dialog(driver, app_helpers):
    """ To validate Add Admin rights to role dialog """
    tenant_info = app_helpers['tenant_info']
    role_name = f'Test role {uuid.uuid4()}'
    role_api = app_helpers['role_helper']
    admin_rights = role_api.get_all_admin_rights()

    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    Navigate(driver).to_roles_tab()

    add_role_dialog = RolesTabPage(driver).open_add_role_window()
    add_role_dialog.set_role_name(role_name)
    add_role_dialog.select_admin_rights_tab()

    add_rights_window = add_role_dialog.open_add_admin_rights_window()
    add_rights_window.validate_all_elements()\
        .validate_all_child_elements()

    displayed_admin_rights = add_rights_window.get_displayed_admin_rights()
    assert [value['Description'] for value in admin_rights] == displayed_admin_rights, \
        f'Incorrect list of admin rights displayed.\nExpected {admin_rights}\nFound {displayed_admin_rights}'
