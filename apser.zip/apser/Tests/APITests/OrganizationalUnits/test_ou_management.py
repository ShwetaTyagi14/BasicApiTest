import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.user_steps import *
from Steps.ou_steps import *
from Steps.app_steps import *
from Steps.policy_steps import add_mfa_policy_to_role
from Fixtures.app_fixtures import *
from Fixtures.tenant_key_fixtures import *
from idaptive_automation.api_helpers import RoleApi, UprestHelper, UserMgmt
from idaptive_automation.api_payloads import *


@pytestrail.case('C168239')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c168239_add_and_remove_users_and_roles_from_ou(app_helpers):
    role_helper = app_helpers['role_helper']
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    alias = app_helpers['alias']

    role_name = f'OU Role {test_id}'
    new_user = f'ou_user_{test_id}'
    ou_name = f'OU Name {test_id}'
    ou_role1 = role_helper.create_role(role_name=role_name, description=role_name)
    role_name = f'OU Role {test_id}2'
    ou_role2 = role_helper.create_role(role_name=role_name, description=role_name)
    ou_user1 = create_interactive_user_and_activate(app_helpers, alias, new_user, ou_role1)
    new_user = f'ou_user_{test_id}2'
    ou_user2 = create_interactive_user_and_activate(app_helpers, alias, new_user, ou_role1)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    test_ou = ou_helper.get_ou_by_name(ou_name)
    assert test_ou['ID'] == ou_id
    add_users_to_ou(ou_helper, ou_id, ou_user1['Uuid'])
    remove_users_from_ou(ou_helper, ou_id, ou_user1['Uuid'])
    add_roles_to_ou(ou_helper, ou_id, ou_role1)
    remove_roles_from_ou(ou_helper, ou_id, ou_role1)
    users = [ou_user1['Uuid'], ou_user2['Uuid']]
    add_users_to_ou(ou_helper, ou_id, users)
    remove_users_from_ou(ou_helper, ou_id, users)
    roles = [ou_role1, ou_role2]
    add_roles_to_ou(ou_helper, ou_id, roles)
    remove_roles_from_ou(ou_helper, ou_id, roles)
    ou_info = ou_helper.get_ou(ou_id)
    assert ou_info["ID"] is not None
    assert ou_helper.delete_ou(ou_info["ID"])


@pytestrail.case('C168243')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c68243_role_policy_for_ou_role(app_helpers, cloud_user):
    ou_helper = app_helpers['ou_helper']
    role_helper = app_helpers['role_helper']
    user_api = app_helpers['user_helper']
    test_id = app_helpers['test_id']
    cloud_session = app_helpers['cloud_session']
    ou_name = f'OU Name {test_id}'
    ou_results = ou_helper.create_ou(ou_name)
    role_name = f'OU Role {test_id}'
    user_session = user_api.authenticate_as_user(cloud_user['Name'], cloud_user['Password'])
    user_session.logout()
    user_api.lock_user_account(cloud_user['Name'])
    role_id = role_helper.create_role(role_name=role_name, description=role_name)
    role_helper.add_users_to_role(role_id, [cloud_user['uuid']])
    add_mfa_policy_to_role(app_helpers, role_id)
    ou_helper.add_users_to_ou(ou_results['ID'], [cloud_user['uuid']])
    ou_helper.add_roles_to_ou(ou_results['ID'], role_id)
    validate_login_error(base_url=cloud_session.base_url, tenant_id=cloud_session.tenant_id,
                         username=cloud_user['Name'], password=cloud_user['Password'], assert_success=False)


@pytestrail.case('C168242')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c168242_assign_app_to_ou(app_helpers, cloud_user):
    ou_helper = app_helpers['ou_helper']
    tenant_helper = app_helpers['tenant_helper']
    user_helper = app_helpers['user_helper']
    role_helper = app_helpers['role_helper']
    test_id = app_helpers['test_id']
    alias = tenant_helper.get_aliases_for_tenant()[0]

    ou_name = f'OU Name {test_id}'
    ou_results = ou_helper.create_ou(ou_name)

    role_name = f'OU admin Role {test_id}'
    role_id = role_helper.create_role(role_name=role_name, description=role_name)
    role_helper.add_users_to_role(role_id, [cloud_user['uuid']])
    ou_helper.add_users_to_ou(ou_results['ID'], [cloud_user['uuid']])
    ou_helper.add_roles_to_ou(ou_results['ID'], role_id)

    assert ou_helper.grant_ou_permissions(ou_results['ID'], role_id, "Role", ["UserManagement", "RoleManagement"])
    results = ou_helper.get_ou_permissions(ou_results['ID'])
    validate_unit_rights(results, role_id, "Role", ["UserManagement", "RoleManagement"])

    role_name2 = f'OU Role {test_id}'
    role_id2 = role_helper.create_role(role_name=role_name2, description=role_name2)

    app_name = f'{test_id} Test App'
    assert create_generic_user_password_app_deploy_to_role(app_helpers, app_name, role_id2)

    user2 = create_interactive_user_and_activate(app_helpers, alias, f'testuser2{test_id}', role_id2)

    role_helper.add_users_to_role(role_id2, [user2['Uuid']])
    ou_helper.add_users_to_ou(ou_results['ID'], [user2['Uuid']])
    ou_helper.add_roles_to_ou(ou_results['ID'], role_id2)

    assert is_app_present(user_helper, user2['Name'], user2['Password'], app_name)


@pytestrail.case('C173580')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c173580_ou_admin_assignment_and_unassignment(app_helpers):
    ou_helper: OUHelper = app_helpers['ou_helper']
    test_id: str = app_helpers['test_id']
    user_api: UserApi = app_helpers['user_helper']
    alias: str = app_helpers['alias']

    # Prepare org, user
    new_user = f'user_{test_id}'
    ou_name = f'OU Name {test_id}'
    cloud_user = create_interactive_user_and_activate(app_helpers, alias, new_user)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    user_id = cloud_user['Uuid']

    assert ou_helper.add_ou_admin(ou_id, user_id)

    assert ou_helper.is_user_ou_admin(ou_id, user_id)

    # Verify (Login with user, this user should have OU admin right and able to create user in OU)
    user_session = user_api.authenticate_as_user(cloud_user['Name'], cloud_user['Password'])
    cloud_user_api = UserApi(user_session, True)

    payload = CloudUser(alias, f'ou_user_1_{test_id}').to_payload()
    payload["OrgPath"] = ou_results["Path"]
    assert cloud_user_api.create_cloud_user(payload)

    assert ou_helper.remove_ou_admin(ou_id, user_id)

    # Verify (After remove user from OU admin, this user should not have OU admin right now and not able to create user in OU)
    payload = CloudUser(alias, f'ou_user_2_{test_id}').to_payload()
    payload["OrgPath"] = ou_results["Path"]
    cloud_user_api.create_cloud_user(payload, assert_success=False)

    user_session.logout()


@pytestrail.case('C173582')
def test_c173582_ou_delegated_admin_abilities(app_helpers, set_organization_feature_flag):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    user_api = app_helpers['user_helper']
    role_helper = app_helpers['role_helper']
    alias = app_helpers['alias']

    new_user = f'user_{test_id}'
    ou_name = f'OU Name {test_id}'
    cloud_user = create_interactive_user_and_activate(app_helpers, alias, new_user)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    user_id = cloud_user['Uuid']

    ou_role = role_helper.create_role(role_name=f"OU Role {test_id}")

    ou_helper.add_roles_to_ou(ou_id, ou_role)

    assert ou_helper.add_ou_admin(ou_id, user_id)

    user_session = user_api.authenticate_as_user(cloud_user['Name'], cloud_user['Password'])
    cloud_user_api = UserApi(user_session, True)
    cloud_role_api = RoleApi(user_session, True)

    ou_users = create_users_in_ou(number_of_users=5, alias=alias, test_id=test_id,
                                  ou_path=ou_results["Path"], cloud_user_api=cloud_user_api)
    user_uuids = list(ou_users.keys())

    cloud_role_api.add_users_to_role(ou_role, user_uuids)

    cloud_role_api.remove_users_from_role(ou_role, user_uuids)


@pytestrail.case('C178350')
def test_c173582_ou_delegated_can_lock_and_unlock_ou_users(app_helpers, set_organization_feature_flag):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    user_api = app_helpers['user_helper']
    role_helper = app_helpers['role_helper']
    alias = app_helpers['alias']

    new_user = f'user_{test_id}'
    ou_name = f'OU Name {test_id}'
    cloud_user = create_interactive_user_and_activate(app_helpers, alias, new_user)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    user_id = cloud_user['Uuid']

    ou_role = role_helper.create_role(role_name=f"OU Role {test_id}")

    ou_helper.add_roles_to_ou(ou_id, ou_role)

    assert ou_helper.add_ou_admin(ou_id, user_id)

    user_session = user_api.authenticate_as_user(cloud_user['Name'], cloud_user['Password'])
    cloud_user_api = UserApi(user_session, True)
    cloud_role_api = RoleApi(user_session, True)

    ou_users = create_users_in_ou(number_of_users=5, alias=alias, test_id=test_id,
                                    ou_path=ou_results["Path"], cloud_user_api=cloud_user_api)
    user_uuids = list(ou_users.keys())
    cloud_role_api.add_users_to_role(ou_role, user_uuids)

    ou_user1_uuid = next(iter(ou_users))
    ou_user1_username = ou_users[ou_user1_uuid]

    # OU admin should be able to lock and unlock users of own OU
    # /UserMgmt/SetCloudLock
    UserMgmt(user_session).lock_user_account_by_uuid(ou_user1_uuid)
    user = cloud_user_api.get_user_info(ou_user1_username)['Row']
    assert user['Status'] == 'Suspended'

    UserMgmt(user_session).unlock_user_account_by_uuid(ou_user1_uuid)
    user = cloud_user_api.get_user_info(ou_user1_username)['Row']
    assert user['Status'] != 'Suspended'

    # lock user with another api. usually used for non-(cds, ad, ldap)
    # /CDirectryService/SetUserState
    cloud_user_api.lock_user_account(ou_user1_username)
    user = cloud_user_api.get_user_info(ou_user1_username)['Row']
    assert user['Status'] == 'Suspended'

    cloud_user_api.unlock_user_account(ou_user1_username)
    user = cloud_user_api.get_user_info(ou_user1_username)['Row']
    assert user['Status'] != 'Suspended'

    cloud_role_api.remove_users_from_role(ou_role, user_uuids)
    UserMgmt(user_session).remove_users({'Users': user_uuids})


@pytestrail.case('C178481')
def test_c178481_ou_admin_limited_api_access(app_helpers, set_organization_feature_flag):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    user_api = app_helpers['user_helper']
    role_helper = app_helpers['role_helper']
    alias = app_helpers['alias']

    new_user = f'user_{test_id}'
    ou_name = f'OU Name {test_id}'
    cloud_user = create_active_user_with_displayname(app_helpers, alias, new_user, new_user)
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']
    user_id = cloud_user['Uuid']

    ou_role = role_helper.create_role(role_name=f"OU Role {test_id}")

    ou_helper.add_roles_to_ou(ou_id, ou_role)

    assert ou_helper.add_ou_admin(ou_id, user_id)

    ou_users = create_users_in_ou(number_of_users=3, alias=alias, test_id=test_id,
                                  ou_path=ou_results["Path"], cloud_user_api=user_api, displayname=new_user)
    user_uuids = list(ou_users.keys())

    role_helper.add_users_to_role(ou_role, user_uuids)

    cloud_user2 = create_active_user_with_displayname(app_helpers, alias, new_user+'2', new_user)
    user_session = user_api.authenticate_as_user(cloud_user2['Name'], cloud_user2['Password'])

    assert (directory_service_user_query(UserApi(user_session, True), 'CDS', new_user) == 0)

    user_session.logout()

    user_session = user_api.authenticate_as_user(cloud_user['Name'], cloud_user['Password'])

    assert (directory_service_user_query(UserApi(user_session, True), 'CDS', new_user) == 5)


@pytestrail.case('C173585')
def test_c173585_ou_bulk_user_import(app_helpers, set_organization_feature_flag):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']
    user_api = app_helpers['user_helper']
    alias = app_helpers['alias']
    ou_name = f'OU Name {test_id}'
    ou_id = ou_helper.create_ou(ou_name)['ID']

    number_users = 10

    bulk_array = build_ou_bulk_import(cloud_user_api=user_api, alias=alias, ou_name=ou_name, test_id=test_id,
                                      number_of_users=1, admin=True)

    admin_id = user_api.get_user_info(f'ou_user_0_{test_id}@{alias}')['Row']['ID']

    bulk_array = build_ou_bulk_import(cloud_user_api=user_api, alias=alias, ou_name=ou_name, test_id=test_id,
                                      number_of_users=9, start_at=1, bulk_array=bulk_array)

    file_name = f'c173585{test_id}'

    response = submit_bulk_ou_file(user_api, file_name, bulk_array)

    results = response.results()

    assert response.result()['FullCount'] == number_users, \
        f'len(Results) was not correct. Expected: {number_users}, found: {len(results)}'

    return_id = response.result()['ReturnID']

    ou_helper.submit_bulk_ou_users(return_id)

    assert ou_helper.wait_for_user_to_exist_in_ou(ou_id, admin_id)

    assert ou_helper.is_user_ou_admin(ou_id, admin_id)


@pytestrail.case('C178478')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c178478_cannot_add_builtin_roles_to_ou(app_helpers):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']

    ou_name = f'OU Name {test_id}'
    ou_results = ou_helper.create_ou(ou_name)
    ou_id = ou_results['ID']

    roles = ['Everybody', 'sysadmin']
    ou_helper.add_roles_to_ou(ou_id, roles)

    """built-in roles are not expected to be added to OUs. The backend does not throw an error, 
    but ignores the adding roles to OU if roles are built-in"""

    assert not ou_helper.is_role_in_ou(ou_id, 'Everybody')
    assert not ou_helper.is_role_in_ou(ou_id, 'sysadmin')


@pytestrail.case('C178804')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c178804_cannot_create_multiple_ous_with_same_name(app_helpers):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']

    ou_name = f'OU Name {test_id}'
    ou_results = ou_helper.create_ou_return_response(ou_name)
    assert ou_results.success()
    create_ou_negative_case(ou_helper, ou_name)


@pytestrail.case('C178805')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c178805_cannot_update_ou_to_existing_ou_name(app_helpers):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']

    ou_name1 = f'OU Name1 {test_id}'
    create_ou_response = ou_helper.create_ou_return_response(ou_name1)
    assert create_ou_response.success()
    ou_name2 = f'OU Name2 {test_id}'
    update_ou_to_existing_ou_name(ou_helper, ou_name1, ou_name2)


@pytestrail.case('C178832')
@pytest.mark.usefixtures('set_organization_feature_flag')
def test_c178832_update_ou_happy_path(app_helpers):
    ou_helper = app_helpers['ou_helper']
    test_id = app_helpers['test_id']

    ou_name = f'OU Name {test_id}'
    ou_description = f'creating new OU'
    create_ou_response = ou_helper.create_ou_return_response(ou_name, ou_description)
    ou_id = create_ou_response.result()['ID']
    assert create_ou_response.success()
    ou_name_updated = f'OU Name {test_id} updated'
    ou_description_updated = f'updating existing OU'
    update_ou(ou_helper, ou_id, ou_name_updated, ou_description_updated)