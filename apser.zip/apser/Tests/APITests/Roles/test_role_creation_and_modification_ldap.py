import pytest
from time import sleep
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from Steps.app_steps import get_expected_admin_rights, deploy_app_by_name
from Steps.user_steps import create_interactive_user_and_activate
from Fixtures.tenant_key_fixtures import set_role_protection_flag


@pytestrail.case('C28060')
@pytest.mark.pipeline
def test_c28060_create_empty_role_happy_path(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = 'test-role-C28060'
    role_api.create_role(role_name)


@pytestrail.case('C28062')
@pytest.mark.pipeline
def test_c28062_delete_empty_role_happy_path(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = f"test-role-{app_helpers['test_id']}"
    role_id = role_api.create_role(role_name)
    role_api.delete_role(role_id)
    role_api.roles_created.remove(f'{role_id}')


@pytestrail.case('C39977')
@pytest.mark.pipeline
def test_c39977_deleting_role_is_idempotent(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = f"test-role-{app_helpers['test_id']}"
    role_id = role_api.create_role(role_name)
    role_api.delete_role(role_id)
    role_api.delete_role(role_id, remove_users=False)
    role_api.roles_created.remove(f'{role_id}')


@pytestrail.case('C39976')
@pytest.mark.pipeline
def test_c39976_cannot_create_role_with_duplicate_name(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = f"test-role-{app_helpers['test_id']}"
    role_api.create_role(role_name)
    response = role_api.create_role(role_name, assert_success=False)

    assert not response.success()
    assert f'Role with name {role_name} already exists.' in response.message()


@pytestrail.case('C158427')
def test_c158427_cannot_delete_role_with_assigned_applications(app_helpers, set_role_protection_flag):
    role_helper = app_helpers['role_helper']
    tenant_helper = app_helpers['tenant_helper']
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']

    role_name = f"test-role{app_helpers['test_id']}"
    role_id = role_helper.create_role(role_name)
    alias = tenant_helper.get_aliases_for_tenant()[0]

    tenant_helper.update_tenant_flag("Core.Roles.DeleteCheckForAssignedApplicationsOrMembers", "True")

    response = role_helper.delete_role(role_id=role_id, assert_success=False)
    assert response.success()
    role_helper.roles_created.remove(f'{role_id}')

    role_name = f"test-role{app_helpers['test_id']}"
    role_id = role_helper.create_role(role_name)

    unique_id = app_helpers['test_id']

    create_interactive_user_and_activate(app_helpers, alias, f"testuser1{unique_id}", role_id)
    create_interactive_user_and_activate(app_helpers, alias, f"testuser2{unique_id}", role_id)
    create_interactive_user_and_activate(app_helpers, alias, f"testuser3{unique_id}", role_id)

    response = role_helper.delete_role(role_id=role_id, assert_success=False, remove_users=False)
    assert not response.success()

    deploy_app_by_name(app_helper, "Instagram", role_name)
    deploy_app_by_name(app_helper, "Facebook", role_name)
    deploy_app_by_name(app_helper, "Twitter", role_name)

    response = role_helper.delete_role(role_id=role_id, assert_success=False)
    assert not response.success()

    user_helper.delete_user(f"testuser1{unique_id}@{alias}")
    user_helper.delete_user(f"testuser2{unique_id}@{alias}")
    user_helper.delete_user(f"testuser3{unique_id}@{alias}")

    response = role_helper.delete_role(role_id=role_id, assert_success=False)
    assert not response.success()

    tenant_helper.update_tenant_flag("Core.Roles.DeleteCheckForAssignedApplicationsOrMembers", "False")

    response = role_helper.delete_role(role_id=role_id, assert_success=False)
    assert response.success()
    role_helper.roles_created.remove(f'{role_id}')

# @pytestrail.case('C28068')
# @pytest.mark.pipeline
# def test_c28068_add_empty_group_to_role_happy_path(role_fixture):
#     group_name = 'Empty Group C28068'
#     _, group_id, principal = create_role_with_empty_group(role_fixture,
#                                                           'C28068.org',
#                                                           group_name,
#                                                           'test-role-C28068')
#     assert principal == f"g={group_name}"
#
#
# def create_role_with_empty_group(role_fixture, ou_name, group_name, role_name):
#     user_api, role_api, ldap_api, ds_info = role_fixture
#     dn = ds_info['Forest']
#     ou = ldap_api.create_organizational_unit(ou_name, dn)[0].entry_dn
#     group_id, group_dn = create_ldap_group(role_fixture, group_name, ou, ds_info['directoryServiceUuid'])
#     sleep(2)
#
#     role_id = role_api.create_role(role_name)
#     role_api.add_groups_to_role(role_id, [group_id])
#     role_info = role_api.get_role_info(role_id)
#
#     assert len(role_info.result()['Principals']) == 1
#     return role_id, group_id, role_info.result()['Principals'][0]
#
#
# def create_ldap_group(role_fixture, group_name, ou_dn, ds_uuid):
#     user_api, _, ldap_api, _ = role_fixture
#     group_dn = ldap_api.create_ad_group(group_name, ou_dn)[0].entry_dn
#     sleep(2)
#
#     group_info = user_api.search_directory_services(group_name, [ds_uuid])
#     assert 'Group' in group_info.result().keys(), f'Group look up for {group_name} in DS failed'
#     group_info = [row['Row'] for row in group_info.result()['Group']['Results'] if row['Row']['DistinguishedName'] == group_dn]
#     assert len(group_info) == 1, f'DS search for {group_name} returned {len(group_info)} groups, expected 1'
#     return group_info[0]['InternalName'], group_dn
#
#
# @pytestrail.case('C28064')
# @pytest.mark.pipeline
# def test_c28064_delete_role_with_empty_group_happy_path(role_fixture):
#     _, role_api, _, _ = role_fixture
#     role_id, _, _ = create_role_with_empty_group(role_fixture,
#                                                  'C28064.org',
#                                                  'Empty Group C28064',
#                                                  'test-role-C28064')
#     role_api.delete_role(role_id)
#
#
# @pytestrail.case('C40022')
# @pytest.mark.pipeline
# def test_c40022_remove_group_from_role(role_fixture):
#     _, role_api, _, _ = role_fixture
#     role_id, group_id, _ = create_role_with_empty_group(role_fixture,
#                                                         'C40022.org',
#                                                         'Empty Group C40022',
#                                                         'test-role-C40022')
#     role_api.remove_groups_from_role(role_id, [group_id])
#
#
# @pytestrail.case('C39978')
# @pytest.mark.pipeline
# def test_c39978_removing_group_from_role_is_idempotent(role_fixture):
#     _, role_api, _, ds_info = role_fixture
#     dn = ds_info['Forest']
#
#     ou_name = 'C39978.org'
#     group_name = 'Single user Group C39978'
#     user_name = 'test-user-C39978'
#     role_name = 'test-role-C39978'
#     user = {
#         'user_name': user_name,
#         'gn': 'Harry',
#         'sn': 'Potter',
#         'password': 'testTEST1234'
#     }
#
#     ou_dn, group_id, role_id, role_info = create_role_with_populated_group(role_fixture,
#                                                                            ou_name,
#                                                                            dn,
#                                                                            group_name,
#                                                                            user,
#                                                                            role_name,
#                                                                            ds_info['directoryServiceUuid'])
#
#     assert len(role_info.result()['Principals']) == 1
#     assert group_name in role_info.result()['Principals'][0]
#
#     role_api.remove_groups_from_role(role_id, [group_id])
#     role_api.remove_groups_from_role(role_id, [group_id])
#
#
# def create_role_with_populated_group(role_fixture, ou_name, dn, group_name, user, role_name, dsuuid):
#     user_api, role_api, ldap_api, directory_services = role_fixture
#     ou_dn = ldap_api.create_organizational_unit(ou_name, dn)[0].entry_dn
#     group_id, group_dn = create_ldap_group(role_fixture, group_name, ou_dn, dsuuid)
#
#     person = InetOrgPerson().with_common_name(user['user_name'])\
#                             .with_surname(user['sn'])\
#                             .with_given_name(user['gn'])\
#                             .with_password(user['password'])\
#                             .to_payload()
#     ldap_api.create_ldap_user(dn, user['user_name'], person)
#     ldap_api.add_users_to_group([f"cn={user['user_name']},{dn}"], group_dn)
#
#     role_id = role_api.create_role(role_name)
#     role_api.add_groups_to_role(role_id, [group_id])
#     role_info = role_api.get_role_info(role_id)
#     return ou_dn, group_id, role_id, role_info
#
#
# @pytestrail.case('C28056')
# @pytest.mark.pipeline
# def test_c28056_add_user_to_role_happy_path(role_fixture, case_number):
#     _, role_api, _, _ = role_fixture
#     user_name = f'test-user-{case_number}'
#     role_name = f'test-role-{case_number}'
#
#     role_id, user_id, role_info = create_role_with_single_user(role_fixture, role_name, user_name, case_number)
#
#     assert len(role_info.result()['Principals']) == 1
#     assert role_info.result()['Principals'][0] == f'u={user_name}'
#
#
# def create_role_with_single_user(role_fixture, role_name, user_name, sur_name):
#     user_api, role_api, ldap_api, ds_info = role_fixture
#     dn = ds_info['Forest']
#     person = InetOrgPerson().with_common_name(user_name)\
#                             .with_surname(sur_name)\
#                             .with_given_name('Test')\
#                             .with_password('testTEST1234')\
#                             .to_payload()
#     ldap_api.create_ldap_user(dn, user_name, person)
#     user_info = user_api.search_directory_services(user_name, [ds_info['directoryServiceUuid']])
#     user = first_or_default(user_info.result()['User']['Results'], lambda u: u['Row']['SystemName'] == user_name)
#     if user is None:
#         assert False, f'{user_name} not found in DS search'
#     user_id = user['Row']['InternalName']
#
#     role_id = role_api.create_role(role_name)
#     role_api.add_users_to_role(role_id, [user_id])
#     role_info = role_api.get_role_info(role_id)
#     return role_id, user_id, role_info
#
#
# @pytestrail.case('C39983')
# @pytest.mark.pipeline
# def test_c39983_adding_user_to_role_is_idempotent(role_fixture, case_number):
#     _, role_api, _, _ = role_fixture
#     user_name = f'test-user-{case_number}'
#     role_name = f'test-role-{case_number}'
#
#     role_id, user_id, _ = create_role_with_single_user(role_fixture, role_name, user_name, case_number)
#     role_api.add_users_to_role(role_id, [user_id])
#     role_info = role_api.get_role_info(role_id)
#
#     assert len(role_info.result()['Principals']) == 1
#     assert role_info.result()['Principals'][0] == f'u={user_name}'
#
#
# @pytestrail.case('C28057')
# @pytest.mark.pipeline
# def test_c28057_remove_user_from_role_happy_path(role_fixture, case_number):
#     _, role_api, _, _ = role_fixture
#     user_name = f'test-user-{case_number}'
#     role_name = f'test-role-{case_number}'
#
#     role_id, user_id, role_info = create_role_with_single_user(role_fixture, role_name, user_name, case_number)
#
#     assert role_info.result()['Principals'][0] == f'u={user_name}', 'Test setup failed. Failed to add user to role'
#
#     role_api.remove_users_from_role(role_id, [user_id])
#
#
# @pytestrail.case('C39979')
# @pytest.mark.pipeline
# def test_c39979_removing_user_from_role_is_idempotent(role_fixture, case_number):
#     _, role_api, _, _ = role_fixture
#     user_name = f'test-user-{case_number}'
#     role_name = f'test-role-{case_number}'
#
#     role_id, user_id, role_info = create_role_with_single_user(role_fixture, role_name, user_name, case_number)
#
#     assert role_info.result()['Principals'][0] == f'u={user_name}', 'Test setup failed. Failed to add user to role'
#
#     role_api.remove_users_from_role(role_id, [user_id])
#     role_api.remove_users_from_role(role_id, [user_id])
#
#
# @pytestrail.case('C28061')
# @pytest.mark.pipeline
# def test_c28061_delete_role_with_members_happy_path(role_fixture, case_number):
#     _, role_api, _, _ = role_fixture
#     user_name = f'test-user-{case_number}'
#     role_name = f'test-role-{case_number}'
#
#     role_id, user_id, role_info = create_role_with_single_user(role_fixture, role_name, user_name, case_number)
#
#     assert role_info.result()['Principals'][0] == f'u={user_name}', 'Test setup failed. Failed to add user to role'
#
#     role_api.delete_role(role_id)
#
#
# @pytestrail.case('C28063')
# @pytest.mark.pipeline
# def test_c28063_delete_role_populated_group_happy_path(role_fixture):
#     _, role_api, _, ds_info = role_fixture
#     dn = ds_info['Forest']
#     ou_name = 'C28063.org'
#     group_name = 'Single user Group C28063'
#     user_name = 'test-user-C28063'
#     role_name = 'test-role-C28063'
#     user = {
#         'user_name': user_name,
#         'gn': 'Test',
#         'sn': 'C28063',
#         'password': 'testTEST1234'
#     }
#
#     ou_dn, group_id, role_id, role_info = create_role_with_populated_group(role_fixture,
#                                                                            ou_name,
#                                                                            dn,
#                                                                            group_name,
#                                                                            user,
#                                                                            role_name,
#                                                                            ds_info['directoryServiceUuid'])
#
#     assert len(role_info.result()['Principals']) == 1
#     assert group_name in role_info.result()['Principals'][0]
#
#     role_api.delete_role(role_id)
#
#
# @pytestrail.case('C28069')
# @pytest.mark.pipeline
# def test_c28069_add_admin_rights_to_role_happy_path(role_fixture, admin_rights, case_number):
#     _, role_api, _, directory_services = role_fixture
#     user_name = f'test-user-{case_number}'
#     role_name = f'test-role-{case_number}'
#     role_id, user_id, role_info = create_role_with_single_user(role_fixture, role_name, user_name, case_number)
#
#     payload = [{"Role": role_id, "Path": right["Path"]} for right in admin_rights]
#
#     role_api.assign_super_rights_to_role(payload)
#     assigned_rights = role_api.get_assigned_super_rights_for_role(role_id)
#
#     assert admin_rights == assigned_rights


@pytestrail.case('C39984')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c39984_adding_admin_rights_to_role_is_idempotent(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = f"test-role-{app_helpers['test_id']}"
    role_id = role_api.create_role(role_name)
    admin_rights = get_expected_admin_rights()

    payload = [{"Role": role_id, "Path": right["Path"]} for right in admin_rights]

    role_api.assign_super_rights_to_role(payload)
    role_api.assign_super_rights_to_role(payload)

    assigned_rights = role_api.get_assigned_super_rights_for_role(role_id)
    for rights in assigned_rights:
        rights.pop('Scope')
    assert admin_rights == assigned_rights


@pytestrail.case('C28070')
@pytest.mark.pipeline
def test_c28070_remove_admin_rights_from_role_happy_path(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = 'test-role-C28070'
    role_id = role_api.create_role(role_name)
    admin_rights = get_expected_admin_rights()

    payload = [{"Role": role_id, "Path": right["Path"]} for right in admin_rights]

    role_api.assign_super_rights_to_role(payload)
    role_api.remove_super_rights_from_role(payload)

    assigned_rights = role_api.get_assigned_super_rights_for_role(role_id)

    assert len(assigned_rights) == 0


@pytestrail.case('C39980')
@pytest.mark.pipeline
def test_c39980_removing_admin_rights_from_role_is_idempotent(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = 'test-role-C39980'
    role_id = role_api.create_role(role_name)
    admin_rights = get_expected_admin_rights()

    payload = [{"Role": role_id, "Path": right["Path"]} for right in admin_rights]

    role_api.assign_super_rights_to_role(payload)
    role_api.remove_super_rights_from_role(payload)

    assigned_rights = role_api.get_assigned_super_rights_for_role(role_id)

    assert len(assigned_rights) == 0
