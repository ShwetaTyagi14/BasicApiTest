import pytest
from idaptive_testrail.plugin import pytestrail


@pytestrail.case('C168295')
def test_c168295_cannot_create_role_with_reserved_name(app_helpers):
    # Arrange
    reserved_names = ['CyberArk Remote Access Users', 'CyberArk Remote Access Admin Users']
    role_api = app_helpers['role_helper']

    for display_name in reserved_names:
        # Arrange
        response = role_api.create_role(display_name, assert_success=False)

        # Assert
        assert not response.success()
        assert 'Cannot create or update a role with reserved role name' in response.message()


@pytestrail.case('C168296')
def test_c168296_cannot_update_role_with_reserved_name(app_helpers):
    # Arrange
    reserved_names = ['CyberArk Remote Access Users', 'CyberArk Remote Access Admin Users']

    role_api = app_helpers['role_helper']
    existing_role_id = role_api.create_role("c168296")

    for display_name in reserved_names:
        # Act
        response = role_api.update_role_metadata(existing_role_id, display_name, "c168296", assert_success=False)

        # Assert
        assert not response.success()
        assert 'Cannot create or update a role with reserved role name' in response.message()
