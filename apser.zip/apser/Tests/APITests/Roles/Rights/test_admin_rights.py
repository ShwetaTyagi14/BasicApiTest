from idaptive_testrail.plugin import pytestrail
import pytest
from Steps.app_steps import get_expected_admin_rights


@pytestrail.case('C39985')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c39985_correct_list_of_admin_rights_returned_from_api(app_helpers):
    role_api = app_helpers['role_helper']

    admin_rights = role_api.get_all_admin_rights()

    expected = get_expected_admin_rights()
    assert admin_rights == expected, f'role admin rights full list is not equal, found ' \
                                     f'{admin_rights} expected {expected}'
