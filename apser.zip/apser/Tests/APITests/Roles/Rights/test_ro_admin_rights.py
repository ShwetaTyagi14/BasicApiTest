# from idaptive_testrail.plugin import pytestrail
# import pytest
# from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
# from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
# from Fixtures.role_fixtures import admin_rights_fixture
# from Fixtures.partner_fixtures import partner_fixture, partner_create_function_fixture
# from idaptive_automation.api_helpers import AuthProfileHelper, RoleApi, PartnerApi
# from idaptive_automation.api_payloads import AuthenticationProfile, PartnerCreation
#
#
# @pytest.fixture()
# def policy(pwd_only_profile):
#     yield {
#         "AuthenticationEnabled": True,
#         "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
#     }
#
#
# @pytest.fixture()
# def pwd_only_profile(session_fixture, case_number):
#     with AuthProfileHelper(session_fixture['session'], True) as profile_helper:
#         yield profile_helper.create_profile(AuthenticationProfile(f'{case_number} Pwd Only Profile')
#                                             .with_challenges(["UP"])
#                                             .with_duration_in_minutes(5)
#                                             .to_payload())
#
#
# @pytest.fixture()
# def ro_admin_user(session_fixture,
#                   new_cloud_user,
#                   case_number):
#     role_api = new_cloud_user['role_api']
#     # role_name = f'Test role {case_number}'
#     # role_id = role_api.create_role(role_name)
#     role_api.assign_super_rights_to_role([{"Role": new_cloud_user['role'], "Path": "/lib/rights/monitor.json"}])
#     return new_cloud_user
#
#
# @pytest.fixture()
# def ro_api_session(ro_admin_user, session_fixture):
#     user = ro_admin_user['user']
#     yield ApiSession(session_fixture['url'], session_fixture['tenant'],
#                      user['Name'],
#                      user['Password'])
#
#
# @pytest.fixture()
# def federation_management_user(session_fixture,
#                                new_cloud_user,
#                                case_number):
#     role_api = new_cloud_user['role_api']
#     # role_name = f'Test role {case_number}'
#     # role_id = role_api.create_role(role_name)
#     role_api.assign_super_rights_to_role([{"Role": new_cloud_user['role'], "Path": "/lib/rights/fedman.json"}])
#     return new_cloud_user
#
#
# @pytest.fixture()
# def federation_management_api_session(ro_admin_user, session_fixture):
#     user = ro_admin_user['user']
#     yield ApiSession(session_fixture['url'], session_fixture['tenant'],
#                      user['Name'],
#                      user['Password'])
#
#
# @pytestrail.case('C39994')
# @pytest.mark.pipeline
# def test_c39994_ro_sys_admin_cannot_create_partner_negative_test(partner_fixture, ro_api_session, ro_admin_user, case_number):
#     _, url = partner_fixture
#     partner_api = PartnerApi(ro_api_session)
#     payload = PartnerCreation(url).with_federation_name(f"Test partner for {case_number}")\
#         .with_domain(["test1"])\
#         .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9', 'AAP0774')\
#         .to_payload()
#     partner = partner_api.create_partner(payload, False)
#     assert partner.raw_response.status_code == 500
#
#
# @pytestrail.case('C117800')
# @pytest.mark.pipeline
# def test_c117800_ro_sys_admin_cannot_modify_partner_negative_test(partner_create_function_fixture,
#                                                                   ro_api_session,
#                                                                   ro_admin_user,
#                                                                   case_number):
#     url = partner_create_function_fixture['url']
#     partner = partner_create_function_fixture['partner']
#     partner_api = PartnerApi(ro_api_session)
#     payload = PartnerCreation(url).with_federation_name(f"New name for test partner {case_number}")\
#         .with_domain(partner.result()['Domains'])\
#         .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9', 'AAP0774')\
#         .with_federation_uuid(partner.result()['FederationUuid'])\
#         .to_payload()
#     response = partner_api.update_partner(payload, False)
#     assert response.response['success'] is False
#     assert response.response['Message'] == "You are not authorized to perform this operation. Please contact your IT helpdesk."
#
#
# @pytestrail.case('C117801')
# @pytest.mark.pipeline
# def test_c117801_fed_mgnmnt_user_can_modify_partner_happy_path(partner_create_function_fixture,
#                                                                federation_management_api_session,
#                                                                federation_management_user,
#                                                                case_number):
#     url = partner_create_function_fixture['url']
#     partner = partner_create_function_fixture['partner']
#     partner_api = PartnerApi(federation_management_api_session)
#     partner_creation = PartnerCreation(url).with_federation_name(f"New name for test partner {case_number}")\
#         .with_domain(["newdomain"])\
#         .with_federation_uuid(partner.result()['FederationUuid'])
#     partner_creation.idp_metadataurl = partner.result()['Config']['IDPMetadataUrl']
#     response = partner_api.update_partner(partner_creation.to_payload())
#     assert response.response['success'] is True
#     assert response.response['Result']['FederationName'] == f"New name for test partner {case_number}"
#
#
# @pytestrail.case('C40048')
# @pytest.mark.pipeline
# def test_c40049_ro_user_cannot_delete_a_partner(partner_create_function_fixture,
#                                                 ro_api_session,
#                                                 ro_admin_user,
#                                                 case_number):
#     url = partner_create_function_fixture['url']
#     partner = partner_create_function_fixture['partner']
#     ro_partner_api = PartnerApi(ro_api_session)
#     result = ro_partner_api.delete_partner(partner.response['Result']['NormalizedFederationName'], False)
#     assert result.response['success'] is False
#     assert result.response['Message'] == "You are not authorized to perform this operation. Please contact your IT helpdesk."
#
#
# @pytestrail.case('C40046')
# @pytest.mark.pipeline
# def test_c40046_ro_user_can_view_partner_list(partner_create_function_fixture,
#                                               ro_api_session,
#                                               ro_admin_user,
#                                               case_number):
#     url = partner_create_function_fixture['url']
#     partner = partner_create_function_fixture['partner']
#     ro_partner_api = PartnerApi(ro_api_session)
#     new_partner_name = partner.response['Result']['NormalizedFederationName']
#     partners_list = ro_partner_api.get_partners_list()
#     filter_partner = [partner for partner in partners_list if partner['Name'] == new_partner_name]
#     assert partners_list.__len__() > 0
#     assert filter_partner[0]['Name'] == "test"
