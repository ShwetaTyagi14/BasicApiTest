# import re
#
# import pytest
# from time import sleep
#
# from LDAPLibrary.ldap_server import LdapServer
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.api_payloads import Grants, ApplicationPermissions, InetOrgPerson, CloudUser
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
# from Fixtures.tenant_key_fixtures import set_core_directoryservices_paged_tenant_config as pagedconfig
# from idaptive_automation.api_client import api_session, mongo_dal
# # from Fixtures.role_fixtures import role_fixture, admin_rights_fixture as admin_rights, ldap_role_app_fixture, \
# #     get_ldap_server_config
# from idaptive_automation.api_helpers import UprestHelper, CDirectoryService, RoleApi, ActiveDirectoryHelper
# from idaptive_automation.mongo_dal import AutomationMongoClient,  EnvironmentCredentials
# # from Helpers.linq_helper import first_or_default
# from Fixtures.sessions_and_helpers import *
#
#
# @pytest.fixture()
# def new_ldap_group(request, session_fixture, get_ldap_server_config, role_fixture):
#     user_api, role_api, ldap_api, ldap = role_fixture
#     server, username, password, ds_info = get_ldap_server_config
#     test_name = request.node.originalname or request.node.name
#     m = re.match(r'test_(c\d{5,})_', test_name)
#     test_number = m.group(1)
#     dn = ds_info['Forest']
#     ds_uuid = ds_info['directoryServiceUuid']
#     ou_name = f'{test_number}.test'
#     group_name = f'Test Group {test_number}'
#     ou_dn = ldap_api.create_organizational_unit(ou_name, dn)[0].entry_dn
#     group_id, group_dn = create_ldap_group(user_api, ldap_api, group_name, ou_dn, ds_uuid)
#     yield group_id, group_dn
#
#
# @pytest.fixture()
# def new_ad_group(request, session_fixture, get_ad_server_config):
#     test_name = request.node.originalname or request.node.name
#     m = re.match(r'test_(c\d{5,})_', test_name)
#     test_number = m.group(1)
#     server = get_ad_server_config['ip']
#     username = get_ad_server_config['config']['username']
#     password = get_ad_server_config['config']['password']
#     domain_name = get_ad_server_config['config']['domainName']
#     domain_suffix = get_ad_server_config['config']['domainSuffix']
#     with ActiveDirectoryHelper(server, domain_name, domain_suffix,
#                                f'@{domain_name}.{domain_suffix}', username, password, True) as ad_api:
#         ou_name = f'{test_number}.test'
#         ad_api.create_basic_ad_ou(ou_name)
#         ou_string = f'OU={ou_name}'
#         group_name = f'Test Group {test_number}'
#         ad_api.create_ad_group(group_name, ou_string)
#         group = ad_api.get_ad_group_details(ou_name)
#         yield group[0]['objectGUID'].value.replace('{', '').replace('}', '')
#
#
# def create_ldap_group(user_api, ldap_api, group_name, ou_dn, ds_uuid):
#     group_dn = ldap_api.create_ad_group(group_name, ou_dn)[0].entry_dn
#
#     group_info = user_api.search_directory_services(group_name, [ds_uuid])
#     assert 'Group' in group_info.result().keys(), f'Group look up for {group_name} in DS failed'
#     group_info = [row['Row'] for row in group_info.result()['Group']['Results'] if row['Row']['DistinguishedName'] == group_dn]
#     assert len(group_info) == 1, f'DS search for {group_name} returned {len(group_info)} groups, expected 1'
#     return group_info[0]['InternalName'], group_dn
#
#
# @pytestrail.case('C00000')
# @pytest.mark.pipeline
# def test_c75418_map_role_to_target_group(new_ldap_group, new_ad_group, role_fixture):
#     ad_group = new_ad_group
#     _, role_api, _, _ = role_fixture
#     ldap_group_id, ldap_group_dn = new_ldap_group
#
#     role_name = 'test-role-C75418'
#     role_id = role_api.create_role(role_name)
#     # Below methods self assert
#     role_api.add_groups_to_role(role_id, [ad_group])
#     role_api.add_groups_to_role(role_id, [ldap_group_id])
#     raise NotImplementedError('This test is not complete')
#
#
# @pytestrail.case('C154993')
# def test_c154993_search_paged_users_through_api(app_helpers, pagedconfig):
#     user_api = app_helpers['user_helper']
#     tenant_helper = app_helpers['tenant_helper']
#     alias = app_helpers['alias']
#
#     for users in range(0, 125):
#         email_address = 'test@C154993.test'
#         payload = CloudUser(alias, f'Self-Service-{uuid.uuid4()}').with_email(email_address).to_payload()
#         payload['SendEmailInvite'] = False
#         username = user_api.create_cloud_user(payload)
#     dirs = user_api.get_directory_services_info()
#     all_dirs = []
#     for dir in dirs:
#         all_dirs.append(dir['directoryServiceUuid'])
#     result_page_one = user_api.search_directory_services_by_email(email_address.split("@")[1], all_dirs, page_number=1)
#     result_page_two = user_api.search_directory_services_by_email(email_address.split("@")[1], all_dirs, page_number=2)
#     assert len(result_page_one.response['Result']['User']['Results']) == 100, "Page one should contain 100 users"
#     assert len(result_page_two.response['Result']['User']['Results']) == 25, "Page two should only contain 25 users"