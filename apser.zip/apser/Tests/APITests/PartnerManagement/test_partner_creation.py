import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_payloads import PartnerCreation
from Fixtures.partner_fixtures import partner_fixture


@pytestrail.case('C33534')
@pytest.mark.pipeline
@pytest.mark.postdeploy
def test_c33534_create_partner(partner_fixture, app_helpers):
    partner_api = partner_fixture
    url = app_helpers['tenant_info']['base_url']
    payload = PartnerCreation(url).with_federation_name("test-c33534")\
        .with_domain(["test1"])\
        .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9', 'AAP0774')\
        .to_payload()
    partner = partner_api.create_partner(payload)
    assert partner.result()['DirectLoginSupported']
    assert partner.result()['PartnerManageable']
    assert partner.result()['FederationUuid']
