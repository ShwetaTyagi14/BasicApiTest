import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_payloads import PartnerCreation
from Fixtures.partner_fixtures import partner_create_fixture, partner_fixture


class TestPartners:
    @pytestrail.case('C33535')
    @pytest.mark.pipeline
    def test_c33535_view_partners_admin(self, partner_create_fixture):
        partner_api = partner_create_fixture['partner_api']
        partner_details = partner_create_fixture['partner']
        partners_list = partner_api.get_partners_list()

        new_partner = partner_details.result()['FederationName']
        partner = [partner for partner in partners_list if partner['Name'] == new_partner]
        assert len(partner) == 1
        assert partner[0]['Name']
        assert partner[0]['Type']
        assert partner[0]['Domains']
        assert partner[0]['Status']

    @pytestrail.case('C39999')
    @pytest.mark.pipeline
    def test_c39999_partner_info_persisted(self, partner_create_fixture):
        partner_api = partner_create_fixture['partner_api']
        partner_details = partner_create_fixture['partner']
        new_partner = partner_details.result()['FederationName']
        partner = partner_api.get_federation_info(new_partner)
        all_federations = partner_api.get_federations().response['Result']
        partner_in_fed_list = [p for p in all_federations if p['FederationUuid'] == partner['FederationUuid']]
        assert partner_in_fed_list.__len__() > 0

    @pytestrail.case('C33659')
    @pytest.mark.pipeline
    def test_c33659_cannot_add_two_partners_with_same_name(self, partner_create_fixture):
        partner_api = partner_create_fixture['partner_api']
        url = partner_create_fixture['url']
        payload = PartnerCreation(url).with_federation_name('test') \
            .with_domain(["test"])\
            .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9', 'AAP0774')\
            .to_payload()
        response = partner_api.create_partner(payload, False)
        assert 'Federation Name test already exists.' in response.message()

    @pytestrail.case('C33697')
    @pytest.mark.pipeline
    def test_c33697_cannot_create_two_partners_with_same_idp(self, partner_create_fixture):
        partner_api = partner_create_fixture['partner_api']
        url = partner_create_fixture['url']
        payload = PartnerCreation(url).with_federation_name('test1-c33697') \
            .with_domain(["test"])\
            .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9', 'AAP0774')\
            .to_payload()
        response = partner_api.create_partner(payload, False)
        assert 'IDP Signing certificate already in use by another business partner' in response.message()

    @pytestrail.case('C33536')
    @pytest.mark.pipeline
    def test_c33536_delete_partner(self, partner_create_fixture):
        partner_api = partner_create_fixture['partner_api']
        partner = partner_create_fixture['partner']
        partner_api.delete_partner(partner.result()['FederationName'])
