import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_helpers import IBEHelper, AboutHelper


# @pytest.fixture()
# def release_config(mongo_dal, session_fixture):
#     with mongo_dal(EnvironmentCredentials(), 'apps') as client:
#         client.connect()
#         tenant_creds = client.get_tenant_credentials(session_fixture['tenant'])
#         release_config = client.find_one('release_config', {'environment': tenant_creds['environment']})
#         if release_config is None:
#             raise Exception(f'No release_config found for environment: {tenant_creds["environment"]}')
#         return {**tenant_creds['about'], **release_config['ibe']}


# TODO This test needs to be improved because it relies too much on manual data entry and fails too often due to what data is returned in ibe_versions
@pytestrail.case('C45454')
def test_c45454_apis_show_correct_versions(app_helpers):
    cloud_session = app_helpers['cloud_session']
    ibe_versions = IBEHelper(cloud_session).get_all_versions()
    about_info = AboutHelper(cloud_session).get_about_info()

    # assert ibe_versions['Chrome'].lower() == release_config['Chrome'].lower()
    # assert ibe_versions['Firefox'].lower() == release_config['Firefox'].lower()
    # assert ibe_versions['IEx86'].lower() == release_config['IEx86'].lower()
    # assert ibe_versions['Safari'].lower() == release_config['Safari'].lower()
    # assert ibe_versions['IEx64'].lower() == release_config['IEx64'].lower()
    # assert about_info['PodRegion'].lower() == release_config['PodRegion'].lower()
    # assert about_info['PodFqdn'].lower() == release_config['PodFqdn'].lower()
    # assert about_info['PodName'].lower() == release_config['PodName'].lower()
    # assert about_info['Version'].lower() == release_config['CloudVersion'].lower()
