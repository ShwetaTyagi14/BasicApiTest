import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.fixtures import authenticated_api_class_fixture as session_fixture
from Fixtures.sessions_and_helpers import *
from Fixtures.user_fixtures import current_ds_order
import uuid


@pytestrail.case('C68368')
@pytest.mark.pipeline
def test_c68368_change_ds_lookup_order(app_helpers, current_ds_order):
    new_order = [x for x in current_ds_order]
    new_order[1], new_order[2] = new_order[2], new_order[1]
    ds_helper = app_helpers['directory_services_helper']
    user_helper = app_helpers['user_helper']
    ds_helper.set_directory_service_order(new_order)

    results = user_helper.get_directory_services_info()
    ds_order = [r['directoryServiceUuid'] for r in results]
    assert ds_order == new_order


@pytestrail.case('C68367')
@pytest.mark.pipeline
def test_c68367_change_ds_lookup_order_missing_uuid_negative_test(app_helpers, current_ds_order):
    new_order = [x for x in current_ds_order]
    del new_order[1]
    ds_helper = app_helpers['directory_services_helper']
    response = ds_helper.set_directory_service_order(new_order, assert_success=False)

    assert response.message() == "Value outside of range."


@pytestrail.case('C119123')
@pytest.mark.pipeline
def test_c119123_change_ds_lookup_order_random_uuid_negative_test(app_helpers, current_ds_order):
    new_order = [x for x in current_ds_order]
    new_order[1] = str(uuid.uuid4())
    ds_helper = app_helpers['directory_services_helper']
    response = ds_helper.set_directory_service_order(new_order, assert_success=False)

    assert response.message() == "Value outside of range."


@pytestrail.case('C119124')
@pytest.mark.pipeline
def test_c119124_change_ds_lookup_order_cds_not_on_top_negative_test(app_helpers, current_ds_order):
    new_order = [x for x in current_ds_order]
    new_order[0], new_order[1] = new_order[1], new_order[0]
    ds_helper = app_helpers['directory_services_helper']
    response = ds_helper.set_directory_service_order(new_order, assert_success=False)

    assert response.message() == "New stack must include tenant CDS at the top!"


@pytestrail.case('C119125')
@pytest.mark.pipeline
def test_c119125_change_ds_lookup_order_move_fds_negative_test(app_helpers, current_ds_order):
    new_order = [x for x in current_ds_order]
    last = len(new_order) - 1
    new_order[1], new_order[last] = new_order[last], new_order[1]
    ds_helper = app_helpers['directory_services_helper']
    response = ds_helper.set_directory_service_order(new_order, assert_success=False)

    assert response.message() == "Changing the lookup order for federated directory service is not supported."
