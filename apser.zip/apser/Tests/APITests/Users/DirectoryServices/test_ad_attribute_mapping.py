from idaptive_testrail.plugin import pytestrail
from Fixtures.app_fixtures import *
from idaptive_automation.api_helpers import UserMgmt, MobileApi
from idaptive_automation.api_payloads import InviteUser, GenericSamlApp
from Steps.user_steps import verify_ad_attribute_changes_to_cloud, set_user_attributes, validate_user_mobile_after_mapping
from Fixtures.custom_attribute_mapping_fixture import CustomADMapping_fixture as customad

from Steps.app_steps import setup_saml_app_with_script
from Helpers.test_data_helper import load_json_test_data_file
from Fixtures.ad_writable_fixture import MakeAdWritable_fixture as adwritable


@pytestrail.case('C168289')
def test_c168289_set_custom_ad_mapping_ap(customad):
    assert customad.enable_custom_mapping()
    domain_worker, user_mgmt, ad_user, uid = customad.setup_ad_for_mapping()
    attributes_payload = {"ID": f'{uid}', "DirectoryServiceUuid": "not_needed"}
    result = user_mgmt.get_user_attributes(attributes_payload)
    assert '1234567891' == result.response['Result']['mobile'], f"Expected AD description value to be mapped to mobile"


@pytestrail.case('C168290')
def test_c168290_set_custom_ad_mapping_up(customad, app_helpers):
    password = "testTEST1234"
    assert customad.enable_custom_mapping()
    domain_worker, user_mgmt, ad_user, uid = customad.setup_ad_for_mapping()
    user_helper = app_helpers['user_helper']
    user_session = user_helper.authenticate_as_user(ad_user, password)
    ad_user = UserMgmt(user_session)
    mobile_api = MobileApi(user_session)
    user_attributes = ad_user.get_user_attributes(payload="")
    assert '1234567891' == user_attributes.response['Result']['mobile'], \
        f"Expected AD description value to be mapped to mobile"
    user_and_app_store_attributes = mobile_api.get_user_and_app_store_url_info()
    assert '1234567891' == user_and_app_store_attributes.response['Result']['MobileNumber'],\
        f"Expected AD description value to be mapped to mobile"


@pytestrail.case('C168291')
def test_c168291_set_custom_ad_mapping_update_automatically(customad):
    domain_worker, user_mgmt, ad_user, uid = customad.setup_ad_for_mapping()
    attributes_payload = {"ID": f'{uid}', "DirectoryServiceUuid": "not_needed"}
    result = user_mgmt.get_user_attributes(attributes_payload)
    assert '1987654321' == result.response['Result']['mobile'], f"Expected AD mobile value to be mapped to mobile"
    assert customad.enable_custom_mapping()
    result = validate_user_mobile_after_mapping(user_mgmt, attributes_payload)
    assert '1234567891' == result.response['Result']['mobile'], f"Expected AD description value to be mapped to mobile"


@pytestrail.case('C168292')
def test_c168292_set_custom_ad_mapping_app_script(customad, app_helpers):
    config = load_json_test_data_file("generic_app.json", sub_dir="Applications")
    assert customad.enable_custom_mapping()
    domain_worker, user_mgmt, ad_user, uid = customad.setup_ad_for_mapping()
    app_helpers = app_helpers['app_helper']
    app_name = str(uuid.uuid4())[0:8]
    saml_app = setup_saml_app_with_script(app_helpers, app_name, config)
    xml_doc = app_helpers.get_preview_saml_response(saml_app, f'{ad_user}@{domain_worker.email_suffix}')
    assert "1234567891" in xml_doc, f"Expected AD description value to be mapped to mobile number"


@pytestrail.case('C168293')
def test_c168293_set_custom_ad_mapping_with_writeback(customad, adwritable, app_helpers):
    password = "testTEST1234"
    assert customad.enable_custom_mapping()
    domain_worker, user_mgmt, ad_user, uid = customad.setup_ad_for_mapping()
    user_helper = app_helpers['user_helper']
    base_name = ad_user.split('user1')[0]
    result = set_user_attributes(user_mgmt, domain_worker, base_name, uid)
    ad_mobile = domain_worker.get_ad_user_attribute(f'{ad_user}', f"ou={base_name}", 'mobile')
    assert '1987654321' == ad_mobile, f"Expected AD mobile value to not change, but it did"
    ad_description = domain_worker.get_ad_user_attribute(f'{ad_user}', f"ou={base_name}", 'description')
    assert '8012224567' == ad_description, f"Expected AD description value to change, but it did not"
    attributes_payload = {"ID": f'{uid}', "DirectoryServiceUuid": "not_needed"}
    user_session = user_helper.authenticate_as_user(ad_user, password)
    result = verify_ad_attribute_changes_to_cloud(attributes_payload, '8012224567', user_mgmt, user_session)
    assert '8012224567' == result.response['Result']['mobile'], f"Expected AD description value to be mapped to mobile"
