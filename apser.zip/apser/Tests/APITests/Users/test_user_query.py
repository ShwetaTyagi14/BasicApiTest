import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_payloads import CloudUser
from idaptive_automation.api_helpers import RedrockApi


@pytestrail.case('C28053')
@pytest.mark.pipeline
def test_c28053_username_starts_with_query(app_helpers):
    admin_session = app_helpers['cloud_session']
    user_helper = app_helpers["user_helper"]
    alias = app_helpers["alias"]
    test_id = app_helpers["test_id"]

    user1 = CloudUser(alias, f'test{test_id}001User') \
        .with_password_never_expire(True) \
        .with_password("testTEST1234") \
        .with_display_name(f"test{test_id}001User") \
        .to_payload()

    user2 = CloudUser(alias, f'test{test_id}002User') \
        .with_password_never_expire(True) \
        .with_password("testTEST1234") \
        .with_display_name(f"test{test_id}002User") \
        .to_payload()

    user_helper.create_cloud_user(user1)
    user_helper.create_cloud_user(user2)

    query_payload = {
        "Script": "@/lib/querydefbuilder.js({\"table\":\"User\",\"filter\":\"Username like 'test"
                  + f"{test_id}" + "001%'\"})",
        "Args": {"PageNumber": 1, "Limit": 100000, "PageSize": 100, "Caching": -1}
    }
    response = RedrockApi(admin_session).execute_redrock_query(query_payload)
    assert len(response.response["Result"]["Results"]) == 1


@pytestrail.case('C178866')
@pytest.mark.pipeline
def test_c178866_username_contains_apostrophe_query(app_helpers):
    admin_session = app_helpers['cloud_session']
    user_helper = app_helpers["user_helper"]
    alias = app_helpers["alias"]
    test_id = app_helpers["test_id"]

    user1 = CloudUser(alias, f'test\'{test_id}001User') \
        .with_password_never_expire(True) \
        .with_password("testTEST1234") \
        .with_display_name(f"test{test_id}001User") \
        .to_payload()

    user2 = CloudUser(alias, f'test{test_id}002User') \
        .with_password_never_expire(True) \
        .with_password("testTEST1234") \
        .with_display_name(f"test{test_id}002User") \
        .to_payload()

    user_helper.create_cloud_user(user1)
    user_helper.create_cloud_user(user2)

    query_payload = {
        "Script": "@/lib/querydefbuilder.js({\"table\":\"User\",\"filter\":\"Username like 'test''"
                  + f"{test_id}" + "%'\"})",
        "Args": {"PageNumber": 1, "Limit": 100000, "PageSize": 100, "Caching": -1}
    }
    response = RedrockApi(admin_session).execute_redrock_query(query_payload)
    assert len(response.response["Result"]["Results"]) == 1


@pytestrail.case('C178895')
@pytest.mark.pipeline
def test_c178895_displayname_contains_special_characters_query(app_helpers):
    admin_session = app_helpers['cloud_session']
    user_helper = app_helpers["user_helper"]
    alias = app_helpers["alias"]
    test_id = app_helpers["test_id"]

    user1 = CloudUser(alias, f'test{test_id}001User') \
        .with_password_never_expire(True) \
        .with_password("testTEST1234") \
        .with_display_name(f"test\"角'他{test_id}001User") \
        .to_payload()

    user2 = CloudUser(alias, f'test{test_id}002User') \
        .with_password_never_expire(True) \
        .with_password("testTEST1234") \
        .with_display_name(f"test{test_id}002User") \
        .to_payload()

    user_helper.create_cloud_user(user1)
    user_helper.create_cloud_user(user2)

    query_payload = {
        "Script": "@/lib/querydefbuilder.js({\"table\":\"User\",\"filter\":\"DisplayName like 'test\\\"角''他"
                  + f"{test_id}" + "%'\"})",
        "Args": {"PageNumber": 1, "Limit": 100000, "PageSize": 100, "Caching": -1}
    }
    response = RedrockApi(admin_session).execute_redrock_query(query_payload)
    assert len(response.response["Result"]["Results"]) == 1
