import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
from idaptive_automation.api_helpers import UserMgmt, UserApi, RoleApi, RedrockApi
from datetime import datetime, time, timezone, timedelta
from idaptive_automation.api_client.client.api_session import ApiSession
from Fixtures.tenant_key_fixtures import disable_validate_super_right


# # TODO Dynamically create a user and change their password to generate password change history
# @pytest.fixture()
# def user(app_helpers):
#     cloud_users = 'cloudUsers'
#     tenant_info = app_helpers['tenant_info']
#     timestamp = datetime.combine(datetime.today() + timedelta(days=-2), time.min).replace(tzinfo=timezone.utc).timestamp()
#     with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#         user = client.find_one(cloud_users,
#                                {'tenant': tenant_info['tenant_id'],
#                                 'activityIntervals.pwdChange.last': {'$lt': timestamp}})
#         if user is None:
#             assert False, f'''No users found with necessary activity record. This test requires cloud users who have
#             a pwd change history'''
#         return user
#
#
# @pytest.fixture()
# def expected_info(user, idaptive_directory_service):
#     is_admin = user['isSysAdmin'] if 'isSysAdmin' in 'isSysAdmin' in user.keys() else False
#     return {
#         "TenantId": user['tenant'],
#         "Id": user['Uuid'],
#         "Name": user['Name'],
#         "DisplayName": user['DisplayName'],
#         "EmailAddress": user['Mail'],
#         "MobileNumber": None if user['MobileNumber'] == "" else user['MobileNumber'],
#         "DirectoryServiceId": idaptive_directory_service['directoryServiceUuid'],
#         "DirectoryServiceName": idaptive_directory_service['Name'],
#         "DirectoryServiceLocalizedName": idaptive_directory_service['DisplayNameShort'],
#         "IsSysAdmin": is_admin,
#         "CanChangePassword": True,
#         "PasswordExpDate": "/Date(253402300799999)/",
#         # "LastPasswordChangeDate": "/Date(1584566319196)/", TODO: figure out how to validate this
#         # "PasswordChangeSoftDays": 14,
#         # "PasswordChangeHardHours": 48,
#         # "PasswordResetFlag": 0,
#     }
#
#
# @pytestrail.case('C28048')
# @pytest.mark.pipeline
# def test_c28048_validate_get_user_info_api_response(session, expected_info):
#     info = UserMgmt(session['session']).get_user_info().result()
#     for key in expected_info.keys():
#         if isinstance(expected_info[key], str) and isinstance(info[key], str):
#             assert info[key].lower() == expected_info[key].lower()
#         else:
#             assert info[key] == expected_info[key], f'Failed on key: {key} for user: {expected_info["Name"]}'


@pytestrail.case('C154967')
def test_c154967_run_getrolemembers_for_user_with_permission(app_helpers, disable_validate_super_right):
    user_api = app_helpers['user_helper']
    alias = app_helpers['alias']
    payload = user_api.create_interactive_user(alias, app_helpers['test_id'], send_invite=False)
    username, password = payload['Name'], payload['Password']
    user_session = ApiSession(app_helpers['tenant_info']['base_url'], app_helpers['tenant_info']['tenant_id'], username,
                              password)

    all_users_admin = user_api.get_all_users()

    user_ids = []
    for user in all_users_admin: user_ids.append(user['Row']['ID'])
    role_helper = app_helpers['role_helper']

    role_id = role_helper.create_role(f"TestRole {app_helpers['test_id']}", "for C154968 Test")
    role_helper.add_users_to_role(role_id, user_ids)

    role_members_admin = role_helper.get_role_members(role_id)
    role_helper_user = RoleApi(api_session=user_session)

    assert len(role_members_admin) >= 2, "Admin user should return all Role Members"

    permissions_to_check = ["/lib/rights/adminportallogin.json",
                            "/lib/rights/agentmanserviceaccount.json",
                            "/lib/rights/appman.json",
                            "/lib/rights/cybrtenantserviceaccount.json",
                            "/lib/rights/endpointserviceaccount.json",
                            "/lib/rights/monitor.json",
                            "/lib/rights/purchman.json",
                            "/lib/rights/reportman.json",
                            "/lib/rights/roleman.json"]

    for perms in permissions_to_check:
        role_helper.assign_super_rights_to_role([{"Role": role_id, "Path": perms}])
        user_session.refresh_token()
        role_members_user = role_helper_user.get_role_members(role_id, assert_success=False)
        assert role_members_user.response['success'] is True, f"{perms} should return role members, but does not"
        assert role_members_user.response['Result']['Count'] == len(role_members_admin), f"Admin and {perms} member should return same number of Role Members"
        role_helper.remove_super_rights_from_role([{"Role": role_id, "Path": perms}])


@pytestrail.case('C154968')
def test_c154968_run_getrolemembers_for_user_without_permission(app_helpers, disable_validate_super_right):
    user_api = app_helpers['user_helper']
    alias = app_helpers['alias']
    payload = user_api.create_interactive_user(alias, app_helpers['test_id'], send_invite=False)
    username, password = payload['Name'], payload['Password']
    user_session = ApiSession(app_helpers['tenant_info']['base_url'], app_helpers['tenant_info']['tenant_id'], username,
                              password)

    all_users_admin = user_api.get_all_users()

    user_ids = []
    for user in all_users_admin: user_ids.append(user['Row']['ID'])
    role_helper = app_helpers['role_helper']

    role_id = role_helper.create_role(f"TestRole {app_helpers['test_id']}", "for C154968 Test")
    role_helper.add_users_to_role(role_id, user_ids)

    role_members_admin = role_helper.get_role_members(role_id)
    role_helper_user = RoleApi(api_session=user_session)

    role_members_user = role_helper_user.get_role_members(role_id, assert_success=False)
    assert len(role_members_admin) >= 2, "Admin user should return all Role Members"
    assert role_members_user.response['success'] is False and role_members_user.response['Message'] == \
           'You are not authorized to perform this operation. Please contact your IT helpdesk.', \
           "GetRoleMembers API should not return results for non-admin user"

    permissions_to_check = ["/lib/rights/enrollonbehalfof.json",
                            "/lib/rights/mobman.json",
                            "/lib/rights/limitedmobman.json",
                            "/lib/rights/fedman.json",
                            "/lib/rights/mfaunlock.json",
                            "/lib/rights/radiusman.json",
                            "/lib/rights/dsman.json",
                            "/lib/rights/agentmanjoin.json",
                            "/lib/rights/proxycode.json"]

    for perms in permissions_to_check:
        role_helper.assign_super_rights_to_role([{"Role": role_id, "Path": perms}])
        user_session.refresh_token()
        role_members_user = role_helper_user.get_role_members(role_id, assert_success=False)
        assert role_members_user.response['success'] is False, f"{perms} should not be allowed to get Role Members, but it did"
        assert role_members_user.response['Message'] ==\
               'You are not authorized to perform this operation. Please contact your IT helpdesk.',\
               f"{perms} should not be allowed to get Role Members, but it did"
        role_helper.remove_super_rights_from_role([{"Role": role_id, "Path": perms}])
