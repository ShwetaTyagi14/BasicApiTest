import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_helpers import UserMgmt, EmailHelper
from idaptive_automation.api_payloads import InviteUser, CloudUser
from datetime import datetime
import time, json
from Helpers.general_helpers import get_mongo_cred_for_external_resource as get_creds
from externalauth.googlemail import GoogleMail


@pytestrail.case('C45437')
@pytest.mark.skip
@pytest.mark.pipeline
def test_c45437_invite_sent_to_user(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    user_api = app_helpers['user_helper']
    session = app_helpers['cloud_session']

    google_credentials = get_creds()

    email_address = google_credentials['username']
    payload = CloudUser(alias, 'c45437-invite-test-user')\
        .with_email(email_address)\
        .with_send_email_invite(False)\
        .to_payload()
    response = user_api.create_cloud_user(payload)
    uuid = payload['Uuid'] = response.result()
    username = payload['Name']

    invite_payload = InviteUser(username, uuid).to_payload()
    UserMgmt(session).invite_user(invite_payload)

    user_api.wait_for_user_invited_status(username, 60)

    timestamp = GoogleMail.get_friendly_datetime_now()
    mail = GoogleMail(google_credentials['username'], google_credentials['password'])

    message = mail.get_email_by_subject_newer_than_datetime("", timestamp)

    assert 'CyberArk Identity Service - User Account' in message['subject']
    assert 'Welcome to CyberArk!' in message['body'][0]
    assert 'Here are your account details:' in message['body'][0]

