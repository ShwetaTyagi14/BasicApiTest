import pytest
import sys
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from Helpers.test_data_helper import write_bulk_users_to_file, write_user_payload_to_file, bulk_submit_retry
import re, os
from idaptive_automation.api_payloads import SingleBulkUserImport
from externalauth.googlemail import GoogleMail
from Helpers.general_helpers import get_mongo_cred_for_external_resource as get_creds


@pytestrail.case('C33714')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c33714_bulk_user_import_happy_path(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    user_api = app_helpers['user_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    tenant_name = app_helpers['tenant_info']['tenant_id']
    cloud_session = app_helpers['cloud_session']

    number_users = 10
    file_name = 'c33714'
    file_path, file_name = write_bulk_users_to_file(file_name, 'c33714', number_users, alias)
    response = user_api.get_users_from_csv_file(file_name, file_path)
    os.remove(file_path)

    results = response.results()

    assert response.result()['FullCount'] == number_users, f'len(Results) was not correct. Expected: {number_users}, found: {len(results)}'

    return_id = response.result()['ReturnID']
    m = re.search(f'{tenant_name}{file_name.replace(".","")}', return_id)

    assert m is not None, \
        f'Filename not as expected. Expected: {tenant_name}{file_name.replace(".","")}, found: {return_id}'

    google_credentials = get_creds()

    response = bulk_submit_retry(return_id=return_id, credentials=google_credentials['username'],
                                 cloud_session=cloud_session, wait_time=120)

    assert response.success() is True, response.message()

    timestamp = GoogleMail.get_friendly_datetime_now()
    mail = GoogleMail(google_credentials['username'], google_credentials['password'])

    message = mail.get_email_by_subject_newer_than_datetime("", timestamp)
    assert message is not None, f'Confirmation email was not received. Timestamp: {timestamp}, num users: {number_users}'
    assert google_credentials['username'] in message['to']
    assert message['from'].lower().startswith(f'CyberArk Account Management <noreply-system$@{tenant_name}.my'.lower())
    assert message['subject'].lower() == 'CyberArk Identity Service - Bulk Import Report'.lower()
    assert message['usersImported'] == number_users, f'Expected {number_users} imported, found {message["parsed"]["usersImported"]}'
    assert len(message['attachments']) == 0


@pytestrail.case('C33715')
@pytest.mark.pipeline
def test_c33715_login_name_not_formatted_correctly(app_helpers):
    user_api = app_helpers['user_helper']
    file_name = 'c33715'
    user = SingleBulkUserImport('login',
                                'mail@domain.com',
                                'Lastname, Firstname')
    file_path, file_name = write_user_payload_to_file(file_name, user.to_payload())
    response = user_api.get_users_from_csv_file(file_name, file_path, False)
    os.remove(file_path)

    assert not response.success()
    assert 'User name login is invalid' in response.message()


@pytestrail.case('C33718')
@pytest.mark.pipeline
def test_c33718_suffix_not_assoiated_with_tenant(app_helpers):
    user_api = app_helpers['user_helper']
    file_name = 'c33718'
    user = SingleBulkUserImport('login@domain.com',
                                'mail@domain.com',
                                'Lastname, Firstname')
    file_path, file_name = write_user_payload_to_file(file_name, user.to_payload())
    response = user_api.get_users_from_csv_file(file_name, file_path, False)
    os.remove(file_path)

    assert not response.success()
    assert 'invalid suffix' in response.message()


@pytestrail.case('C33716')
@pytest.mark.pipeline
def test_c33716_invalid_role_name(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    user_api = app_helpers['user_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    file_name = 'c33716'
    role = 'SuperDuperAdmin'
    user = SingleBulkUserImport(f'login@{alias}',
                                'mail@domain.com',
                                'Lastname, Firstname',
                                roles=role)
    file_path, file_name = write_user_payload_to_file(file_name, user.to_payload())
    response = user_api.get_users_from_csv_file(file_name, file_path, False)
    os.remove(file_path)

    assert not response.success()
    assert response.message() == f"Role(s) '{role}' do not exist."


@pytestrail.case('C33717')
@pytest.mark.pipeline
def test_c33717_invalid_password(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    user_api = app_helpers['user_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]

    file_name = 'c33717'
    login_name = f'login@{alias}'
    user = SingleBulkUserImport(login_name,
                                'mail@domain.com',
                                'Lastname, Firstname',
                                password='1234')
    file_path, full_file_name = write_user_payload_to_file(file_name, user.to_payload())
    response = user_api.get_users_from_csv_file(full_file_name, file_path, False)
    return_id = response.result()['ReturnID']
    os.remove(file_path)

    google_credentials = get_creds()

    response = user_api.submit_bulk_users(return_id,
                                          google_credentials['username'],
                                          False,
                                          False)

    assert response.success()

    # Gmail test stuff needs to be worked out with new network
    # timestamp = int(time.time()) - 1
    # query = {
    #     'date.received': {'$gt': timestamp},
    #     'emailType': 'bulk user import report',
    #     'usersSubmitted': 1
    # }
    # messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
    # assert messages is not None and len(messages) == 1, f'Confirmation email was not received. Timestamp: {timestamp}, num users: {1}'
    # message = messages[0]
    # assert message is not None, 'Error parsing email message, maybe??'
    #
    # attachment_name = f'{tenant_name.upper()}{file_name}{file_extension}'
    # assert len(message['attachments']) == 1, 'No attachment found on confirmation email'
    # assert attachment_name in message['attachments'][0]['filename']
    # content = message['attachments'][0]['content']
    # assert f'Password for User name {login_name} is invalid' in content
