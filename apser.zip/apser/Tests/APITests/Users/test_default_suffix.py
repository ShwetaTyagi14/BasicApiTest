import pytest
import uuid
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import app_helpers
from idaptive_automation.api_client import ApiSession
from idaptive_automation.api_helpers.helpers.cdirectoryservice_helper import CDirectoryService
from Steps.user_steps import change_user_to_payload
from idaptive_automation.api_client import ApiSession
from Steps.login_steps import api_session_login_attempt


@pytestrail.case('C178851')
@pytest.mark.pipeline
def test_c178851_creating_default_suffix(app_helpers):
    cloud_session = app_helpers['cloud_session']
    tenant_helper = app_helpers['tenant_helper']
    tenant_info = app_helpers['tenant_info']
    tenant_id = tenant_info['tenant_id']
    cds = CDirectoryService(cloud_session)
    temp_alias = f'da_{app_helpers["test_id"]}'
    tenant_helper.create_alias(temp_alias, tenant_id)
    assert cds.set_default_suffix(temp_alias)
    default_suffix = cds.get_default_suffix()
    assert default_suffix['DefaultSuffix'] == temp_alias
    new_alias = f'{temp_alias}2'
    tenant_helper.update_alias(new_alias, temp_alias)
    default_suffix = cds.get_default_suffix()
    assert default_suffix['DefaultSuffix'] == new_alias
    tenant_helper.delete_alias(new_alias)
    default_suffix = cds.get_default_suffix()
    assert default_suffix['DefaultSuffix'] == ''


@pytestrail.case('C178852')
@pytest.mark.pipeline
def test_c178852_ds_rename_default_suffix_and_login(app_helpers):
    cloud_session = app_helpers['cloud_session']
    tenant_helper = app_helpers['tenant_helper']
    tenant_info = app_helpers['tenant_info']
    tenant_id = tenant_info['tenant_id']
    user_api = app_helpers['user_helper']
    cds = CDirectoryService(cloud_session)
    temp_alias = f'da_{app_helpers["test_id"]}'
    temp_username = f"ds_test_{str(uuid.uuid4())[0:8]}"
    tenant_helper.create_alias(temp_alias, tenant_id)
    assert cds.set_default_suffix(temp_alias)
    payload = user_api.create_interactive_user(temp_alias, temp_username, send_invite=False)
    username, password = payload['Name'], payload['Password']
    #1. Auth User without default Suffix
    assert api_session_login_attempt(app_helpers, temp_username, password)
    new_alias = f'{temp_alias}2'
    tenant_helper.update_alias(new_alias, temp_alias)
    #2. Auth User without default Suffix renamed
    assert api_session_login_attempt(app_helpers, temp_username, password)

    user_api.delete_user(f'{temp_username}@{new_alias}')

    #3. validate default Suffix renamed
    tenant_helper.delete_alias(new_alias)
    default_suffix = cds.get_default_suffix()
    assert default_suffix['DefaultSuffix'] == ''


@pytestrail.case('C178854')
@pytest.mark.pipeline
def test_c78854_ds_move_user_to_tenant_suffix(app_helpers):
    cloud_session = app_helpers['cloud_session']
    tenant_helper = app_helpers['tenant_helper']
    tenant_info = app_helpers['tenant_info']
    tenant_id = tenant_info['tenant_id']
    user_api = app_helpers['user_helper']
    cds = CDirectoryService(cloud_session)
    temp_alias = f'da_{app_helpers["test_id"]}'
    temp_username = f"ds_test_{str(uuid.uuid4())[0:8]}"
    tenant_helper.create_alias(temp_alias, tenant_id)
    assert cds.set_default_suffix(temp_alias)
    payload = user_api.create_interactive_user(temp_alias, temp_username, send_invite=False)
    username, password = payload['Name'], payload['Password']
    #1. Auth User without default Suffix
    assert api_session_login_attempt(app_helpers, temp_username, password)
    response = user_api.get_user_info(username)
    user_id = response['Row']['ID']
    update_user_payload = change_user_to_payload(app_helpers, user_id)
    update_user_payload['Name'] = f'{temp_username}@{tenant_id.lower()}'
    CDirectoryService(cloud_session).change_user(payload=update_user_payload)

    user_session = ApiSession(
        base_url=tenant_info['base_url'],
        tenant_id=tenant_info['tenant_id'],
        username=temp_username,
        password=password,
        db_metrics=False,
        start_auth=False, auto_auth=False)

    #2. Changed Suffix to any other Suffix
    user_session.authenticate_user(assert_success=False)

    assert not user_session.auth_details.success
    #3. login with other suffix
    assert api_session_login_attempt(app_helpers, f'{temp_username}@{tenant_id.lower()}', password)

    user_api.delete_user(f'{temp_username}@{tenant_id.lower()}')

    tenant_helper.delete_alias(temp_alias)
    default_suffix = cds.get_default_suffix()
    assert default_suffix['DefaultSuffix'] == ''


@pytestrail.case('C178853')
@pytest.mark.pipeline
def test_c1178853_login_with_and_without_default_suffix(app_helpers):
    cloud_session = app_helpers['cloud_session']
    tenant_helper = app_helpers['tenant_helper']
    tenant_info = app_helpers['tenant_info']
    tenant_id = tenant_info['tenant_id']
    user_api = app_helpers['user_helper']
    cds = CDirectoryService(cloud_session)
    temp_alias = f'da_{app_helpers["test_id"]}'
    temp_username = f"ds_test_{str(uuid.uuid4())[0:8]}"
    tenant_helper.create_alias(temp_alias, tenant_id)
    assert cds.set_default_suffix(temp_alias)
    payload = user_api.create_interactive_user(temp_alias, temp_username, send_invite=False)
    username, password = payload['Name'], payload['Password']
    #1. Auth User without default Suffix
    assert api_session_login_attempt(app_helpers, temp_username, password)
    assert api_session_login_attempt(app_helpers, username, password)

    user_api.delete_user(f'{temp_username}@{temp_alias}')

    tenant_helper.delete_alias(temp_alias)
    default_suffix = cds.get_default_suffix()
    assert default_suffix['DefaultSuffix'] == ''
