import pytest
from idaptive_testrail.plugin import pytestrail
from Fixtures.tenant_key_fixtures import *


class TestUsers:
    @pytestrail.case('C33438')
    @pytest.mark.pipeline
    @pytest.mark.postdeploy
    def test_c33438_create_invited_user(self, app_helpers):
        tenant_helper = app_helpers['tenant_helper']
        user_api = app_helpers['user_helper']
        alias = tenant_helper.get_aliases_for_tenant()[0]

        username = user_api.create_invited_user(alias, app_helpers['test_id'])['Name']
        user_api.wait_for_user_invited_status(username, wait_time=45)

        user = user_api.get_user_info(username)['Row']
        assert user['Username'] == username

    @pytestrail.case('C33439')
    @pytest.mark.pipeline
    @pytest.mark.postdeploy
    def test_c33439_create_active_user(self, app_helpers):
        tenant_helper = app_helpers['tenant_helper']
        user_api = app_helpers['user_helper']
        alias = tenant_helper.get_aliases_for_tenant()[0]
        role_helper = app_helpers['role_helper']

        payload = user_api.create_interactive_user(alias, app_helpers['test_id'], send_invite=False)
        username, password = payload['Name'], payload['Password']

        role_helper.add_users_to_automation_role([payload['Uuid']])

        user_api.activate_user(username, password)

        user = user_api.get_user_info(username)['Row']
        assert user['Username'] == username
        assert user['Status'] == 'Active'

    @pytestrail.case('C149944')
    @pytest.mark.pipeline
    def test_c149944_validate_update_role_v2(self, app_helpers, set_role_v2_flag):
        tenant_helper = app_helpers['tenant_helper']
        user_api = app_helpers['user_helper']
        alias = tenant_helper.get_aliases_for_tenant()[0]
        role_helper = app_helpers['role_helper']
        
        ds_uuid = user_api.get_directory_service_uuid_by_name('CyberArk Cloud Directory')

        payload = user_api.create_interactive_user(alias, app_helpers['test_id'], send_invite=False)
        username, password = payload['Name'], payload['Password']

        result = role_helper.add_users_to_automation_role_v2([payload['Uuid']], ds_uuid)

        user_api.activate_user(username, password)

        user = user_api.get_user_info(username)['Row']
        assert user['Username'] == username
        assert user['Status'] == 'Active'

    @pytestrail.case('C33440')
    @pytest.mark.pipeline
    @pytest.mark.postdeploy
    def test_c33440_create_suspended_user(self, app_helpers):
        tenant_helper = app_helpers['tenant_helper']
        user_api = app_helpers['user_helper']
        alias = tenant_helper.get_aliases_for_tenant()[0]

        payload = user_api.create_interactive_user(alias, 'c33440', send_invite=False)
        username = payload['Name']

        user_api.lock_user_account(username)

        user = user_api.get_user_info(username)['Row']
        assert user['Username'] == username
        assert user['Status'] == 'Suspended'

    @pytestrail.case('C33441')
    @pytest.mark.pipeline
    @pytest.mark.postdeploy
    def test_c33441_create_service_user(self, app_helpers):
        tenant_helper = app_helpers['tenant_helper']
        user_api = app_helpers['user_helper']
        alias = tenant_helper.get_aliases_for_tenant()[0]

        username = user_api.create_service_user(alias, 'c33441')['Name']

        user = user_api.get_user_info(username)['Row']
        assert user['Username'] == username
        assert user['UserType'] == 'Service'
