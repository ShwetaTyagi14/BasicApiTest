import pytest
import sys
import uuid
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
from Helpers.test_data_helper import write_bulk_users_to_file, bulk_submit_retry
from idaptive_automation.api_helpers import UserApi, UserMgmt, RedrockApi
from idaptive_automation.api_client import ApiSession
import re, os, time, pytest
from idaptive_automation.api_payloads import DirectoryServicesUserQuery
from Helpers.general_helpers import get_mongo_cred_for_external_resource as get_creds


@pytest.mark.slow
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
@pytestrail.case('C76713')
def test_c76713_bulk_user_import_large_file(app_helpers):
    NUMBER_BUI_USERS = 10000
    cloud_session = app_helpers['cloud_session']
    user_api = app_helpers['user_helper']
    tenant_name = app_helpers['tenant_info']['tenant_id']
    file_name = f"{app_helpers['test_id']}"

    file_path, file_name = write_bulk_users_to_file(file_name, file_name, NUMBER_BUI_USERS, f"{app_helpers['alias']}")
    response = user_api.get_users_from_csv_file(file_name, file_path)
    os.remove(file_path)

    results = response.results()

    assert response.result()['FullCount'] == NUMBER_BUI_USERS, f'len(Results) was not correct. Expected: {NUMBER_BUI_USERS}, found: {len(results)}'

    return_id = response.result()['ReturnID']
    m = re.search(f'{tenant_name}{file_name.replace(".","")}', return_id)

    assert m is not None, \
        f'Filename not as expected. Expected: {tenant_name}{file_name.replace(".","")}, found: {return_id}'

    google_credentials = get_creds()
    response = bulk_submit_retry(return_id=return_id, credentials=google_credentials['username'],
                                 cloud_session=cloud_session, wait_time=120)
    assert response.success(), f'\n\n\n{response.message()}\n\n\n'


# TODO update these tests to no longer be dependent
@pytest.mark.slow
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
@pytestrail.case('C76714')
def test_c76714_wait_for_bui_users_to_be_created(app_helpers):
    NUMBER_BUI_USERS = 10000
    TEST_NAME = str(uuid.uuid4())
    TIMESTAMP = int(round(time.time() * 1000))

    user_api = app_helpers['user_helper']
    start_time = time.time()
    elapsed_time = int(time.time() - start_time)
    ds_info = user_api.get_directory_service_by_name('CDS')
    payload = DirectoryServicesUserQuery(TEST_NAME, [ds_info['directoryServiceUuid']]).to_payload()
    created_count = user_api.targeted_directory_services_query(payload).result()['User']['Count']

    while created_count < NUMBER_BUI_USERS and elapsed_time < 30 * 60:
        time.sleep(60)
        new_count = user_api.targeted_directory_services_query(payload).result()['User']['Count']
        elapsed_time = int(time.time() - start_time)
        created_count = new_count

    end_time = time.time()

    if created_count > 0:
        metric = {
            'tenant': session_fixture['tenant'],
            'environment': session_fixture['environment'],
            'PodFqdn': session_fixture['about']['PodFqdn'],
            'timeStamp': str(TIMESTAMP),
            'metric': {
                'name': 'Bulk User Import',
                'importCount': NUMBER_BUI_USERS,
                'createdCount': created_count,
                'elapsedSeconds': elapsed_time,
                'averageUserCreationTimeSeconds': elapsed_time / created_count,
                'startTime': start_time,
                'endTime': end_time
            }
        }
        with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
            client.insert_one('testMetrics', metric)

    assert created_count == NUMBER_BUI_USERS, \
        f'\n\nExpected {NUMBER_BUI_USERS} users to be created, found {created_count}. Waited {elapsed_time / 60} minutes'


@pytest.mark.slow
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
@pytestrail.case('C76715')
def test_c76715_delete_bui_users_from_tenant(session_fixture):
    start_time = time.time()
    print(f'\n\n\nStarting test at: {start_time}')
    session = ApiSession(session_fixture['url'],
                         session_fixture['tenant'],
                         session_fixture['username'],
                         session_fixture['password'])

    users = [user['Uuid'] for user in UserApi(session).get_all_cloud_users() if user['Name'].startswith('apps_bui.')]
    print(f'\n\nFound {len(users)} matching users')

    n = 100
    chunks = [users[i:i + n] for i in range(0, len(users), n)]
    print(len(chunks))
    print(len(chunks[0]))
    user_count = 0
    job_start_time = time.time()
    print(f'\n\n\nStarting job submission at: {job_start_time}')
    for chunk in chunks:
        start = time.time()
        print(f'Removing {len(chunk)} users at start + {int(time.time() - job_start_time)}')
        response = UserMgmt(session).remove_users({'Users': chunk})
        print(f'\tResponse: {response.success()} took {int(time.time() - start)}')
        user_count += len(chunk)

    lowest_user_count = user_count
    while len(users) > 0 and int(time.time() - start_time) < 30 * 60:
        users = [user['Uuid'] for user in UserApi(session).get_all_cloud_users() if
                 user['Name'].startswith('apps_bui.')]
        lowest_user_count = min(lowest_user_count, len(users))
        print(f'Found {len(users) / n} jobs still running at start + {int(time.time() - job_start_time)}')
        time.sleep(1)

    job_end_time = time.time()
    number_jobs = len(chunks)
    job_run_time_seconds = int(job_end_time - job_start_time)
    average_job_runtime_seconds = int(job_run_time_seconds / number_jobs)
    job_run_time_minutes = round(job_run_time_seconds / 60, 2)
    test_run_time_seconds = int(job_end_time - job_start_time)
    test_run_time_minutes = round(test_run_time_seconds / 60, 2)
    print(f'\n\nRuntime for {len(chunks)} jobs: {job_run_time_minutes} minutes, {job_run_time_seconds} seconds')
    print(f'Average runtime for a delete user job with {n} users: {average_job_runtime_seconds} seconds')
    print(f'Average delete time for a user: {round(average_job_runtime_seconds / n, 2)} seconds')
    print(f'Completed test in {test_run_time_minutes} minutes')
    metric = {
        'tenant': session_fixture['tenant'],
        'environment': session_fixture['environment'],
        'PodFqdn': session_fixture['about']['PodFqdn'],
        'timeStamp': str(TIMESTAMP),
        'metric': {
            'name': 'Bulk User Delete',
            'startTime': job_start_time,
            'endTime': job_end_time,
            'startingUserCount': user_count,
            'lowestUserCount': lowest_user_count,
            'endingUserCount': len(users),
            'numberOfJobs': len(chunks),
            'totalRunTimeSeconds': job_run_time_seconds,
            'totalRunTimeMinutes': job_run_time_minutes,
            'averageJobRunTimeSeconds': average_job_runtime_seconds,
            'averageUserDeleteTimeSeconds': round(job_run_time_seconds / user_count, 2)
        }
    }
    with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
        client.insert_one('testMetrics', metric)

    assert len(users) == 0