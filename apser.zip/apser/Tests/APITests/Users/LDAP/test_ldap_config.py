# import pytest
# from idaptive_automation.api_helpers import UserApi, LdapServiceApi, UserMgmt, LdapServer
# from idaptive_testrail.plugin import pytestrail
# from uuid import UUID, uuid4
# from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
# from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
#
#
# @pytestrail.case('C86604')
# @pytest.mark.pipeline
# def test_c86604_get_directory_services_endpoint_happy_path(session_fixture):
#     session = session_fixture['session']
#     ds_info = UserApi(session).get_directory_services_info()
#     cds = [row for row in ds_info if row['Name'] == 'CDS']
#     assert len(cds) == 1, f'Expected 1 DS named "CDS", found {len(cds)}'
#     cds = cds[0]
#     assert cds['Service'] == 'CDS'
#     assert cds['DisplayName'] == 'Idaptive Idaptive Directory'
#     assert cds['Tenant'].lower() == session_fixture['tenant']
#     assert cds['Status'] == 'Active'
#     assert cds['Config'] == 'Idaptive Directory'
#     assert cds['StatusDisplay'] == 'Online'
#     assert cds['Everybody'] is True
#     assert cds['Description'] == 'Idaptive Directory'
#     assert cds['DisplayNameShort'] == 'Idaptive Directory'
#
#     valid_uuid = None
#     try:
#         valid_uuid = UUID(cds['directoryServiceUuid'], version=4)
#     except:
#         pass
#     assert valid_uuid is not None, f'directoryServiceUuid for CDS is not valid'
#
#     fds = [row for row in ds_info if row['Name'] == 'FDS']
#     assert len(fds) == 1, f'Expected 1 DS named "FDS", found {len(fds)}'
#     fds = fds[0]
#     assert fds['Service'] == 'FDS'
#     assert fds['DisplayName'] == 'Federated Directory Service'
#     assert fds['Tenant'].lower() == session_fixture['tenant']
#     assert fds['Status'] == 'Active'
#     assert fds['Config'] == 'Federated Directory Service'
#     assert fds['StatusDisplay'] == 'Online'
#     assert fds['Everybody'] is True
#     assert fds['Description'] == 'Federated Directory'
#     assert fds['DisplayNameShort'] == 'FDS'
#
#     valid_uuid = None
#     try:
#         valid_uuid = UUID(fds['directoryServiceUuid'], version=4)
#     except:
#         pass
#     assert valid_uuid is not None, f'directoryServiceUuid for FDS is not valid'
#
#     ldaps = [row for row in ds_info if row['Service'].startswith('LDAPProxy')]
#     if len(ldaps) > 0:
#         with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#             for ldap in ldaps:
#                 ldap_record = client.find_one('vms',
#                                               {'ldap.serviceInstanceName': ldap['Config']})
#                 if ldap_record is not None:
#                     assert ldap['Forest'] == ldap_record['ldap']['baseDN']
#
#
# @pytestrail.case('C86647')
# @pytest.mark.pipeline
# def test_c86647_get_directory_services_no_authentication_negative_test(session_fixture, case_number):
#     session = session_fixture['session']
#     api_session = ApiSession(session.base_url,
#                              session.tenant_id,
#                              None, None,
#                              start_auth=False,
#                              auto_auth=False,
#                              test_name=case_number)
#     response = UserApi(api_session).get_directory_services_info(assert_success=False)
#     assert not response.success()
#     assert 'You do not have access to this content' in response.message()
#
#
# @pytestrail.case('C86605')
# @pytest.mark.pipeline
# def test_c86605_get_cloud_connectors_happy_path(session_fixture):
#     known_connectors = session_fixture['connectors']
#     connectors = LdapServiceApi(session_fixture['session']).get_cloud_connectors()['cloudConnectorData']
#     assert len(connectors) == len(known_connectors), f'''Expected {len(known_connectors)} connectors, found {len(connectors)}
#     Either the API is not reporting the correct number, or the tenant data needs to be updated in MongoDB'''
#
#     for connector in connectors:
#         matchings = [con for con in known_connectors if con['Name'] == connector['proxyName']]
#         assert len(matchings) == 1, f'Failed to match connectors. No Mongo record found for connector named {connector["proxyName"]}'
#         matching = matchings[0]
#         assert matching['ID'] == connector['proxyId']
#
#
# @pytestrail.case('C86648')
# @pytest.mark.pipeline
# def test_c86648_get_cloud_connectors_no_authentication_negative_test(session_fixture, case_number):
#     session = session_fixture['session']
#     api_session = ApiSession(session.base_url,
#                              session.tenant_id,
#                              None, None,
#                              start_auth=False,
#                              auto_auth=False,
#                              test_name=case_number)
#     response = LdapServiceApi(api_session).get_cloud_connectors(assert_success=False)
#     assert not response.success()
#     assert 'You do not have access to this content' in response.message()
#
#
# @pytestrail.case('C86650')
# @pytest.mark.pipeline
# def test_c86650_get_cloud_connectors_no_proxies_negative_test(session_fixture):
#     response = LdapServiceApi(session_fixture['session']).get_cloud_connectors(assert_success=False)
#     assert not response.success()
#     assert 'No online proxies support LDAP' in response.message()
#
#
# @pytestrail.case('C86638')
# @pytest.mark.pipeline
# def test_c86638_get_ldap_directory_config_negative_test(session_fixture):
#     response = LdapServiceApi(session_fixture['session']).get_ldap_service_config(str(uuid4()), assert_success=False)
#     assert response.success() is False
#     assert response.message() == 'You must specify the Uuid of the LDAP Directory Service.'
#
#
# @pytestrail.case('C86655')
# @pytest.mark.pipeline
# def test_c86655_get_ldap_directory_config_no_authentication_negative_test(session_fixture, case_number):
#     session = session_fixture['session']
#     api_session = ApiSession(session.base_url,
#                              session.tenant_id,
#                              None, None,
#                              start_auth=False,
#                              auto_auth=False,
#                              test_name=case_number)
#     response = LdapServiceApi(api_session).get_ldap_service_config(str(uuid4()), assert_success=False)
#     assert response.success() is False
#     assert 'You do not have access to this content' in response.message()
#
#
# @pytestrail.case('C86606')
# @pytest.mark.pipeline
# def test_c86606_get_ldap_directory_config_happy_path(existing_ldap_services_info, session_fixture):
#     ldap_api = LdapServiceApi(session_fixture['session'])
#
#     with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#         for info in existing_ldap_services_info:
#             config = ldap_api.get_ldap_service_config(info['directoryServiceUuid'])
#             assert config['directoryServiceUuid'] == info['directoryServiceUuid']
#             assert config['loginSuffix'] is not None
#             ldap_record = client.find_one('vms',
#                                           {'ldap.baseDN': config['baseDn']})
#             if ldap_record is not None:
#                 assert config['serviceInstanceName'] == ldap_record['ldap']['serviceInstanceName']
#                 assert config['baseDn'] == ldap_record['ldap']['baseDN']
#                 assert config['userName'] == ldap_record['ldap']['bindDN']
#                 assert str(ldap_record['ldap']['sslPort']) in config['hostName']
#
#
# @pytestrail.case('C86639')
# @pytest.mark.pipeline
# def test_c86639_get_ldap_directory_config_cds_uuid_negative_test(directory_services_info, session_fixture):
#     cds_info = [row for row in directory_services_info if row['Service'] == 'CDS']
#     response = LdapServiceApi(session_fixture['session']).get_ldap_service_config(cds_info[0]['directoryServiceUuid'], assert_success=False)
#     assert response.success() is False
#     assert response.message() == 'You must specify the Uuid of the LDAP Directory Service.'
#
#
# @pytestrail.case('C86607')
# @pytest.mark.pipeline
# def test_c86607_verify_ldap_config_happy_path(existing_or_new_ldap_services_config, session_fixture):
#     LdapServiceApi(session_fixture['session']).verify_ldap_service_config(existing_or_new_ldap_services_config)
#
#
# @pytestrail.case('C86656')
# @pytest.mark.pipeline
# def test_c86656_verify_ldap_config_no_authentication_negative_test(request, existing_or_new_ldap_services_config, session_fixture):
#     test_name = request.node.originalname or request.node.name
#     session = session_fixture['session']
#     api_session = ApiSession(session.base_url,
#                              session.tenant_id,
#                              None, None,
#                              start_auth=False,
#                              auto_auth=False,
#                              test_name=test_name)
#     response = LdapServiceApi(api_session).verify_ldap_service_config(existing_or_new_ldap_services_config,
#                                                                       assert_success=False)
#     assert not response.success()
#     assert 'You do not have access to this content' in response.message()
#
#
# @pytestrail.case('C86611')
# @pytest.mark.pipeline
# def test_c86611_verify_ldap_config_wrong_hostname_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config.update({'hostName': 'wrong_name'})
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'Cannot contact the LDAP server' in response.message()
#
#
# @pytestrail.case('C86613')
# @pytest.mark.pipeline
# def test_c86613_verify_ldap_config_wrong_basedn_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config['baseDn'] = 'dc=google,dc=com'
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'The object does not exist' in response.message()
#
#
# @pytestrail.case('C86668')
# @pytest.mark.pipeline
# def test_c86668_verify_ldap_config_invalid_basedn_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config['baseDn'] = 'wrong_name'
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'The distinguished name contains invalid syntax' in response.message()
#
#
# @pytestrail.case('C86614')
# @pytest.mark.pipeline
# def test_c86614_verify_ldap_config_wrong_username_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config['userName'] = 'cn=wrong_name'
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'The supplied credential is invalid' in response.message()
#
#
# @pytestrail.case('C86669')
# @pytest.mark.pipeline
# def test_c86669_verify_ldap_config_invalid_username_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config['userName'] = 'wrong_name'
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'Unexpected LDAP exception' in response.message()
#
#
# @pytestrail.case('C86615')
# @pytest.mark.pipeline
# def test_c86615_verify_ldap_config_wrong_password_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config['password'] = 'invalidpassword'
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'The supplied credential is invalid' in response.message()
#
#
# @pytestrail.case('C86616')
# @pytest.mark.pipeline
# def test_c86616_verify_ldap_config_invalid_proxy_id_negative_test(new_ldap_services_config, session_fixture):
#     new_ldap_services_config['proxies'] = [str(uuid4())]
#     print(new_ldap_services_config)
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'Validation of the configuration failed with error: No online proxies support LDAP' in response.message()
#
#
# @pytestrail.case('C86662')
# @pytest.mark.pipeline
# def test_c86662_verify_ldap_config_no_connectors_online_negative_test(existing_or_new_ldap_services_config,
#                                                                       session_fixture):
#
#     response = LdapServiceApi(session_fixture['session']).verify_ldap_service_config(existing_or_new_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'Validation of the configuration failed with error: No online proxies support LDAP' in response.message()
#
#
# @pytestrail.case('C86608')
# @pytest.mark.pipeline
# def test_c86608_modify_ldap_ds_config_happy_path(existing_ldap_services_config, session_fixture):
#     LdapServiceApi(session_fixture['session']).modify_ldap_service_config(existing_ldap_services_config)
#
#
# @pytestrail.case('C86657')
# @pytest.mark.pipeline
# def test_c86657__modify_ldap_ds_config_no_authentication_negative_test(request, existing_ldap_services_config, session_fixture):
#     test_name = request.node.originalname or request.node.name
#     session = session_fixture['session']
#     api_session = ApiSession(session.base_url,
#                              session.tenant_id,
#                              None, None,
#                              start_auth=False,
#                              auto_auth=False,
#                              test_name=test_name)
#     response = LdapServiceApi(api_session).modify_ldap_service_config(existing_ldap_services_config,
#                                                                       assert_success=False)
#     assert not response.success()
#     assert 'You do not have access to this content' in response.message()
#
#
# @pytestrail.case('C86617')
# @pytest.mark.pipeline
# def test_c86617_modify_ldap_ds_config_invalid_ds_id_negative_test(existing_ldap_services_config, session_fixture):
#     existing_ldap_services_config['directoryServiceUuid'] = str(uuid4())
#     response = LdapServiceApi(session_fixture['session']).modify_ldap_service_config(existing_ldap_services_config,
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert 'You must specify the Uuid of the LDAP Directory Service' in response.message()
#
#
# @pytestrail.case('C86609')
# @pytest.mark.pipeline
# def test_c86609_add_ldap_ds_config_happy_path(copy_existing_ldap_services_config):
#     ldap_api, config = copy_existing_ldap_services_config
#     ldap_api.add_ldap_service_config(config)
#
#
# @pytestrail.case('C86670')
# @pytest.mark.pipeline
# def test_c86670_add_ldap_ds_config_duplicate_name_negative_test(existing_ldap_services_config, session_fixture):
#     response = LdapServiceApi(session_fixture['session']).add_ldap_service_config(existing_ldap_services_config,
#                                                                                   assert_success=False)
#     assert not response.success()
#     assert f'There is already a directory service named {existing_ldap_services_config["serviceInstanceName"]}' in response.message()
#
#
# @pytestrail.case('C86610')
# @pytest.mark.pipeline
# def test_c86610_delete_ldap_ds_config_happy_path(new_ldap_service, session_fixture):
#     LdapServiceApi(session_fixture['session']).delete_ldap_service_config(new_ldap_service['directoryServiceUuid'])
#
#
# @pytestrail.case('C86671')
# @pytest.mark.pipeline
# def test_c86671_delete_ldap_ds_config_bad_uuid_negative_test(existing_ldap_services_config, session_fixture):
#     existing_ldap_services_config['directoryServiceUuid'] = str(uuid4())
#     response = LdapServiceApi(session_fixture['session']).delete_ldap_service_config(existing_ldap_services_config['directoryServiceUuid'],
#                                                                                      assert_success=False)
#     assert not response.success()
#     assert f'A service instance of name {existing_ldap_services_config["directoryServiceUuid"]} does not exist' in response.message()
#
#
# @pytestrail.case('c87261')
# def test_c87261_get_directory_service_uuid_by_name(new_ldap_services_config, session_fixture):
#     # TODO Deletion of the ldap config does not always work - Caching issue?
#     ldap_api = LdapServiceApi(session_fixture['session'], auto_clean=True)
#     ldap_api.add_ldap_service_config(new_ldap_services_config)
#     res = ldap_api.get_directory_service_uuid_by_name(new_ldap_services_config['serviceInstanceName'])
#     ldap_api.delete_ldap_service_config(res.response['Result'])
#     assert res.response['success'] is True
#     assert res.response['Result'].__len__() > 0
#
#
# @pytestrail.case('C87259')
# @pytest.mark.pipeline
# def test_c87259_get_directory_service_version_v2(new_ldap_services_config, session_fixture):
#     # TODO Need to rework for ldap version 3
#     ldap_api = LdapServiceApi(session_fixture['session'], auto_clean=True)
#     ldap_api.add_ldap_service_config(new_ldap_services_config)
#     create_ldap_res = ldap_api.get_directory_service_uuid_by_name(new_ldap_services_config['serviceInstanceName'])
#     new_ldap_services_config['directoryServiceUuid'] = create_ldap_res.response['Result']
#     res = ldap_api.get_directory_service_version(new_ldap_services_config['directoryServiceUuid'])
#     ldap_api.delete_ldap_service_config(new_ldap_services_config['directoryServiceUuid'])
#     assert res.response['success'] is True
#     assert res.response['Result']['Version'] == 2
#
#
# @pytestrail.case('C87260')
# @pytest.mark.pipeline
# def test_c87260_verify_mappable_attributes_ldap_v3(existing_ldap_services_config, session_fixture):
#     session = session_fixture['session']
#     ds_info = UserApi(session).get_directory_services_info()
#     ldaps = [row for row in ds_info if row['Service'].startswith('LDAPProxy')]
#     if len(ldaps) > 0:
#         with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#             for ldap in ldaps:
#                 ldap_record = client.find_one('vms',
#                                           {'ldap.serviceInstanceName': ldap['Config']}) #verify if the ldap is existing or not
#                 if ldap_record is not None:
#                     ldap_api = LdapServiceApi(session_fixture['session'], auto_clean=True)
#                     res = ldap_api.get_directory_service_version(existing_ldap_services_config['directoryServiceUuid'])
#                     if res.response['Result']['Version'] == 3:  # go to next API call only if the ldap version is 3
#                         res = LdapServiceApi(session).get_mappable_attributes()
#                         mappableAttributes = [row for row in res.response['Result']['mappableAttributes']]
#                         assert mappableAttributes[00] == 'Manager'
#                         assert mappableAttributes[0o1] == 'DisplayName'
#                         assert mappableAttributes[0o2] == 'UserObjectClasses'
#                         assert mappableAttributes[0o3] == 'PreferredCulture'
#                         assert mappableAttributes[0o4] == 'GroupName'
#                         assert mappableAttributes[0o5] == 'HomeNumber'
#                         assert mappableAttributes[0o6] == 'EmailAddress'
#                         assert mappableAttributes[0o7] == 'MobileNumber'
#                         assert mappableAttributes[0o10] == 'FirstName'
#                         assert mappableAttributes[0o11] == 'Description'
#                         assert mappableAttributes[10] == 'UserLoginName'
#                         assert mappableAttributes[11] == 'OfficeNumber'
#                         assert mappableAttributes[12] == 'LastName'
#                         assert mappableAttributes[13] == 'GroupObjectClasses'