import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
from idaptive_automation.api_helpers import ProxyApi, UserApi, LdapServiceApi
from uuid import uuid4

# TODO assess the usefulness of these tests
# @pytestrail.case('C86651')
# @pytest.mark.pipeline
# def test_c86651_delete_proxies_invalid_id_negative_test(session_fixture):
#     response = ProxyApi(session_fixture['session']).delete_proxies([str(uuid4())], assert_success=False)
#     assert not response.success()
#     assert 'The requested data or its dependent data was not found in the service' in response.message()
#
#
# @pytestrail.case('C86653')
# @pytest.mark.pipeline
# def test_c86653_delete_proxy_connector_online_negative_test(session_with_online_cloud_connector):
#     session = session_with_online_cloud_connector['session']
#     con_id = LdapServiceApi(session).get_cloud_connectors()['cloudConnectorData'][0]['proxyId']
#     response = ProxyApi(session_with_online_cloud_connector['session']).delete_proxies([con_id],
#                                                                                        assert_success=False)
#     assert not response.success()
#     assert 'is online' in response.message()
#
#
# @pytestrail.case('C86652')
# def test_c86652_delete_proxy_happy_path(session_fixture):
#     response = LdapServiceApi(session_fixture['session']).get_cloud_connectors()
#     con_id = [response['cloudConnectorData'][0]['proxyId']]
#     ProxyApi(session_fixture['session']).delete_proxies(con_id)
#
#
# @pytestrail.case('C86654')
# @pytest.mark.pipeline
# def test_c86654_delete_proxies_no_authentication_negative_test(session_fixture, case_number):
#     session = session_fixture['session']
#     api_session = ApiSession(session.base_url,
#                              session.tenant_id,
#                              None, None,
#                              start_auth=False,
#                              auto_auth=False,
#                              test_name=case_number)
#     response = ProxyApi(api_session).delete_proxies([str(uuid4())], assert_success=False)
#     assert not response.success()
#     assert 'You do not have access to this content' in response.message()
