import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.app_steps import *
from Fixtures.tenant_key_fixtures import set_sws_entitlement, enable_issue_service_tenant_access_token
from Fixtures.tenant_key_fixtures import sws_service_account_token
from idaptive_automation.api_payloads.payloads.generic_user_password import GenericUserPasswordApp
from idaptive_automation.api_payloads.payloads.create_linked_app import ChildLinkedSamlApp
from idaptive_automation.api_payloads.payloads.red_rock import RedRock
from Helpers.test_data_helper import load_json_test_data_file
from idaptive_automation.api_helpers.helpers.user_management_helper import UserMgmt
from idaptive_automation.api_helpers.helpers.session_security import Security
from idaptive_automation.api_helpers.helpers.role_helper import RoleApi
from idaptive_automation.api_helpers.helpers.redrock_helper import RedrockApi
from Helpers.secure_web_session_helper import empty_session, session_header


@pytestrail.case('C178799')
def test_c178799_validate_oauth2_authorize_url_when_launching_sws_app(app_helpers, set_sws_entitlement):
    user_helper = app_helpers['user_helper']
    app_helper = app_helpers['app_helper']
    catalog_app = "SWS_test"
    app_name = f"{catalog_app}-{app_helpers['test_id']}"
    app_description = f"{catalog_app}-{app_helpers['test_id']}"
    app_url = "https://www.google.com"
    app_id = deploy_app_by_name(app_helper, "Generic User-Password")
    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .with_sws_enabled()\
        .to_payload()
    result = app_helper.update_application_de(app)
    result_app_details = app_helper.get_application(app_id)
    assert result_app_details['IsSwsEnabled']
    assert result_app_details['SwsDeepLink']

    uprest_helper = UprestHelper(user_helper.api_session)
    response = uprest_helper.handle_app_click(app_id, raw_response=True)
    oauth2_authorize_url = response.history[1].url

    assert "client_id" in oauth2_authorize_url
    assert "scope=openid" in oauth2_authorize_url
    assert "redirect_uri=" in oauth2_authorize_url
    assert "AuthCallback&state" in oauth2_authorize_url
    assert "user_principal_name" in oauth2_authorize_url


@pytestrail.case('C178800')
def test_c178800_securewebsession_redrock_query(app_helpers, set_sws_entitlement):
    app_helper = app_helpers['app_helper']
    catalog_app = "SWS_test"
    app_name = f"{catalog_app}-{app_helpers['test_id']}"
    app_url = "https://www.google.com"
    app_id = deploy_app_by_name(app_helper, "Generic User-Password")
    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_name) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .with_sws_enabled() \
        .to_payload()
    result = app_helper.update_application_de(app)
    cloud_session = app_helpers['cloud_session']
    script = load_json_test_data_file("sws_redrock_script.json", sub_dir="Applications")['Script']
    payload = RedRock(script=script).to_payload()
    response = RedrockApi(cloud_session).execute_redrock_query(payload)
    sws_apps = response.response['Result']['Results']
    assert sws_apps.__len__() >= 1
    sws_app_name = []
    for apps in sws_apps:
        sws_app_name.append(apps['Row']['DisplayName'])
    assert f"{app_name}" in sws_app_name


@pytestrail.case('C178801')
def test_c178801_securewebsession_linked_application(app_helpers, set_sws_entitlement):
    app_helper = app_helpers['app_helper']
    app_id = deploy_app_by_name(app_helper, "Generic SAML")
    saml_app_name = f"SAML - {app_helpers['test_id']}"
    app = GenericSamlApp("https://www.google.com", app_id) \
        .with_name(saml_app_name)\
        .with_sws_enabled() \
        .to_payload()

    result = app_helper.update_application_de(app)
    linked_app_name = "SWS Name LA"
    linked_app = ChildLinkedSamlApp(app_id).with_display_name("SWS test linked app")\
        .with_description("SWS LA")\
        .with_name(linked_app_name)\
        .to_payload()
    result = app_helper.update_application_de(linked_app)
    assert result.response['success']
    linked_app_id = app_helper.get_app_key_from_app_name(f"{linked_app_name}")
    result_linked_app = app_helper.get_application(linked_app_id)
    assert "IsSwsEnabled" not in result_linked_app
    assert "SwsDeepLink" not in result_linked_app


@pytestrail.case('C178819')
def test_c178819_sys_svc_get_user_attr_expect_fail(app_helpers, set_sws_entitlement):
    sws_sys_user_id = "4320c78b-833e-4793-abdc-b0dc94fdea8c"
    everyone_user_id = "00000002-0dfa-4f56-b68b-41a1bdfae7f7"
    cloud_session = app_helpers['cloud_session']
    user_mgmt_helper = UserMgmt(cloud_session)
    response = user_mgmt_helper.get_user_attributes({'ID': sws_sys_user_id}, False)
    assert not response.response['success']
    response = user_mgmt_helper.get_user_attributes({'ID': everyone_user_id}, False)
    assert not response.response['success']


@pytestrail.case('C178820')
def test_c178820_sys_svc_get_cached_user_expect_fail(app_helpers, set_sws_entitlement):
    sws_sys_user_id = "4320c78b-833e-4793-abdc-b0dc94fdea8c"
    everyone_user_id = "00000002-0dfa-4f56-b68b-41a1bdfae7f7"
    cloud_session = app_helpers['cloud_session']
    user_mgmt_helper = UserMgmt(cloud_session)
    response = user_mgmt_helper.get_cached_user({'ID': sws_sys_user_id}, False)
    assert not response.response['success']
    response = user_mgmt_helper.get_cached_user({'ID': everyone_user_id}, False)
    assert not response.response['success']


@pytestrail.case('C178821')
def test_c178821_sys_svc_user_set_slack_id_expect_fail(app_helpers, set_sws_entitlement):
    sws_sys_user_id = "4320c78b-833e-4793-abdc-b0dc94fdea8c"
    everyone_user_id = "00000002-0dfa-4f56-b68b-41a1bdfae7f7"
    cloud_session = app_helpers['cloud_session']
    user_mgmt_helper = UserMgmt(cloud_session)
    response = user_mgmt_helper.set_slack_member_id({'ID': sws_sys_user_id, 'slackmemberid': "something"}, False)
    assert not response.response['success']
    response = user_mgmt_helper.set_slack_member_id({'ID': everyone_user_id, 'slackmemberid': "something"}, False)
    assert not response.response['success']


@pytestrail.case('C178825')
def test_c178825_sys_svc_user_get_user_expect_fail(app_helpers, set_sws_entitlement):
    sws_sys_user_id = "4320c78b-833e-4793-abdc-b0dc94fdea8c"
    everyone_user_id = "00000002-0dfa-4f56-b68b-41a1bdfae7f7"
    cloud_session = app_helpers['cloud_session']
    user_mgmt_helper = UserMgmt(cloud_session)
    response = user_mgmt_helper.get_user_info_with_payload({'id': sws_sys_user_id}, False)
    assert not response.response['success']
    response = user_mgmt_helper.get_user_info_with_payload({'id': everyone_user_id}, False)
    assert not response.response['success']


@pytestrail.case('C178822')
def test_c178822_service_user(app_helpers, set_sws_entitlement, sws_service_account_token):
    tenant_info = app_helpers['tenant_info']
    sws_session = empty_session(tenant_info)
    sws_session.headers = session_header(sws_service_account_token)
    security_helper = Security(sws_session)
    response = security_helper.get_authenticated_user_with_token(payload={}, assert_success=False)
    assert response.response['success'], response.response["Exception"]


@pytestrail.case('C178823')
def test_c178823_create_system_role(app_helpers, set_sws_entitlement, sws_service_account_token):
    cloud_session = app_helpers['cloud_session']
    tenant_info = app_helpers['tenant_info']
    user_mgmt_helper = UserMgmt(cloud_session)
    new_sws_session = empty_session(tenant_info)
    new_sws_session.headers = session_header(sws_service_account_token)
    role_helper = RoleApi(new_sws_session)
    key = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
    new_role_id = 'p_cloud_auditors_test'
    response = role_helper.create_system_role(role_name="Privilege Cloud Test",
                                              role_id=new_role_id,
                                              description=f"Test {key}",
                                              assert_success=False)
    assert response.response['success'], response.response["Exception"]
    response = user_mgmt_helper.get_user_attributes({'ID': new_role_id}, False)
    assert not response.response['success']
    response = user_mgmt_helper.get_cached_user({'ID': new_role_id}, False)
    assert not response.response['success']
    response = user_mgmt_helper.set_slack_member_id({'ID': new_role_id, 'slackmemberid': "something"}, False)
    assert not response.response['success']
    response = user_mgmt_helper.get_user_info_with_payload({'id': new_role_id}, False)
    assert not response.response['success']
    role_helper.delete_role(role_id=new_role_id, assert_success=True, remove_users=True)


@pytestrail.case('C178824')
def test_c178824_sys_user_call_redrock_plv8(app_helpers, set_sws_entitlement, sws_service_account_token):
    tenant_info = app_helpers['tenant_info']
    sws_session = empty_session(tenant_info)
    sws_session.headers = session_header(sws_service_account_token)
    redrock_helper = RedrockApi(sws_session)
    payload = RedRock(script="Select ID, Username, UserType,SourceDs from User").to_payload()
    response = redrock_helper.execute_redrock_query(payload)
    assert response.response["Result"]["FullCount"] > 0
