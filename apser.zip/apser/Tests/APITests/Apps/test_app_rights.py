""" Tests about application permission """
# pylint: disable=redefined-outer-name,too-many-locals
import pytest
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from idaptive_automation.api_helpers import RoleApi
from idaptive_automation.api_payloads import *
from Helpers.test_data_helper import load_json_test_data_file
from Steps.app_steps import *
from Steps.user_steps import *


@pytestrail.case('C163456')
@pytest.mark.pipeline
def test_c163456_manage_rights(app_helpers):
    """ Test application manage permission """
    test_id = app_helpers['test_id']
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    role_api = app_helpers['role_helper']
    permission_data = load_json_test_data_file('../TestData/Permissions/app_permissions.json')

    alias = tenant_helper.get_aliases_for_tenant()[0]
    unique_id = app_helpers['test_id']

    role_name = f'C163456-{test_id} manage users role {test_id}'
    role_id = role_api.create_role(role_name, 'test')
    user = create_user_and_add_to_role(app_helpers, alias, f"app_manage_user{unique_id}", role_id)

    deployed_app = create_generic_user_password_app(app_helpers)
    set_manage_rights_for_app(user, app_helpers, deployed_app)

    row_access_result = app_helper.get_row_access(deployed_app['_RowKey'])
    assert get_grantstr_for_principal(user['Name'], row_access_result) == permission_data['view_manage_enabled']

    user_session = user_helper.authenticate_as_user(user['Name'], 'testTEST1234')

    updated_app_url = "https://yahoo.com"
    app_mobile_url = "https://bing.com"
    updated_app_name = f'C163456-{test_id} Test App updated'
    updated_app_description = f'Testing setting Manage right for an app updated'

    app_update_payload = GenericUserPasswordApp(deployed_app['_RowKey']).with_url(updated_app_url) \
        .with_mobile_url(app_mobile_url) \
        .with_description(updated_app_description) \
        .with_name(updated_app_name) \
        .with_prompt_for_username() \
        .to_payload()
    AppHelper(user_session).update_application_de(app_update_payload)
    updated_app = AppHelper(user_session).get_application(deployed_app['_RowKey'])
    assert updated_app['Name'] == updated_app_name
    assert updated_app['Description'] == updated_app_description
    assert updated_app['Url'] == updated_app_url
    assert updated_app['MobileUrl'] == app_mobile_url
    assert updated_app['UserNameStrategy'] == 'SetByUser'


@pytest.mark.pipeline
def test_delete_rights(cloud_session, app_helpers):
    """ Test application delete permission """
    test_id = app_helpers['test_id']
    user_helper: UserApi = app_helpers['user_helper']
    tenant_helper: TenantApiHelper = app_helpers['tenant_helper']
    role_api: RoleApi = app_helpers['role_helper']
    permission_data = load_json_test_data_file('../TestData/Permissions/app_permissions.json')
    app_helper = AppHelper(cloud_session)

    alias = tenant_helper.get_aliases_for_tenant()[0]
    unique_id = app_helpers['test_id']

    role_name = f'{unique_id} app delete role {test_id}'
    role_id = role_api.create_role(role_name, 'test')
    user = create_user_and_add_to_role(app_helpers, alias, f"app_delete_user{unique_id}", role_id)

    # create a new AppHelper without auto clean because the app would be removed by another user session
    deployed_app = create_generic_user_password_app({"test_id": unique_id, "app_helper": app_helper})
    set_delete_rights_for_app(user, app_helper, deployed_app)

    row_access_result = app_helper.get_row_access(deployed_app['_RowKey'])
    assert get_grantstr_for_principal(user['Name'], row_access_result) == permission_data['view_delete_enabled']

    with AppHelper(user_helper.authenticate_as_user(user['Name'], 'testTEST1234')) as user_api:
        assert user_api.get_app_key_from_app_name(deployed_app['Name'])
        assert user_api.get_application(deployed_app['_RowKey'])
        # should be able to delete by the user have "delete" permission of this app
        assert user_api.delete_application(deployed_app['_RowKey'], True)

@pytest.mark.pipeline
def test_admin_read_rights(app_helpers):
    """ Test application admin view permission """
    test_id = app_helpers['test_id']
    user_helper: UserApi = app_helpers['user_helper']
    tenant_helper: TenantApiHelper = app_helpers['tenant_helper']
    role_api: RoleApi = app_helpers['role_helper']
    permission_data = load_json_test_data_file('../TestData/Permissions/app_permissions.json')
    app_helper: AppHelper = app_helpers['app_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    unique_id = app_helpers['test_id']

    role_name = f'{unique_id} app delete role {test_id}'
    role_id = role_api.create_role(role_name, 'test')
    user = create_user_and_add_to_role(app_helpers, alias, f"app_delete_user{unique_id}", role_id)

    deployed_app = create_generic_user_password_app(app_helpers)
    set_admin_view_rights_for_app(user, app_helper, deployed_app)

    row_access_result = app_helper.get_row_access(deployed_app['_RowKey'])
    assert get_grantstr_for_principal(user['Name'], row_access_result) == permission_data['view_viewdetail_enabled']

    with AppHelper(user_helper.authenticate_as_user(user['Name'], 'testTEST1234')) as user_api:
        assert user_api.get_application(deployed_app['_RowKey'])
        assert user_api.get_app_key_from_app_name(deployed_app['Name'])
        assert user_api.delete_application(deployed_app['_RowKey'], False) # should not able to delete

@pytest.mark.pipeline
def test_normal_read_rights(app_helpers):
    """ Test application normal view permission, which comes with application assignment """
    test_id = app_helpers['test_id']
    user_helper: UserApi = app_helpers['user_helper']
    tenant_helper: TenantApiHelper = app_helpers['tenant_helper']
    role_api: RoleApi = app_helpers['role_helper']
    app_helper: AppHelper = app_helpers['app_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    unique_id = app_helpers['test_id']

    app_name = f'{test_id} Test App'
    role_name = f'{unique_id} app delete role {test_id}'
    role_id = role_api.create_role(role_name, 'test')
    user = create_user_and_add_to_role(app_helpers, alias, f"app_delete_user{unique_id}", role_id)

    assert create_generic_user_password_app_deploy_to_role(app_helpers, app_name, role_id)

    assert app_helper.get_app_key_from_app_name(app_name)

    with AppHelper(user_helper.authenticate_as_user(user['Name'], 'testTEST1234')) as user_api:
        assert user_api.get_app_key_from_app_name(app_name) is None # Should not able to get this app from the list
    