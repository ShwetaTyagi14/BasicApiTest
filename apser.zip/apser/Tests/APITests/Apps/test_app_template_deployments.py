# import pytest
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.api_client import api_session, mongo_dal
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
# from Fixtures.app_fixtures import deploy_salesforce_template_app, app_templates
#
#
# #TODO make salesforce template app deployment dynamic
# @pytestrail.case('C68724')
# def test_c68724_deploy_salesforce_template_app(deploy_salesforce_template_app):
#     app_name, app_api = deploy_salesforce_template_app
#
#     apps = app_api.get_admin_app_list()
#     assert [app for app in apps if app['Row']['Name'] == app_name] is not None
