# import pytest
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.api_helpers import AppGatewayHelper, AppHelper, IPRangeHelper
# from idaptive_automation.api_payloads import GenericBookmark, Grants, ApplicationPermissions, \
#     ConfigureGatewayApplication, AuthenticationProfile
# from selenium import webdriver
# from Steps.navigate_steps import Login
# from idaptive_automation.ui_automation import UserPortalPage
# from Fixtures.proxy_fixtures import all_proxies_for_tenant
# from Fixtures.policy_fixtures import ensure_current_ip_not_in_corp_range
#
#
# #TODO Figure out dnsZone
# # @pytestrail.case('C119116')
# # @pytest.mark.pipeline
# # def test_c119116_deploy_new_app_gateway_enabled_app_to_role_happy_path(app_helpers,
# #                                                                        ensure_current_ip_not_in_corp_range,
# #                                                                        new_cloud_user_in_role_with_policy_fixture,
# #                                                                        all_proxies_for_tenant,
# #                                                                        driver):
# #
# #     new_user = new_cloud_user_in_role_with_policy_fixture
# #     app_api = app_helpers['app_helper']
# #     cloud_session = app_helpers['cloud_session']
# #     app_id = app_api.import_app_by_name('Generic Bookmark')
# #     test_id = app_helpers['test_id']
# #     name = f'App Gateway app'
# #     description = f'An app gateway for test case {test_id}'
# #     protocol = 'http://'
# #     domain = '172.27.13.254'
# #     resource = '/ccnet/server/local/SimpleUserLogin.aspx'
# #     url = f'{protocol}{domain}{resource}'
# #     payload = GenericBookmark(app_id)\
# #         .with_name(name)\
# #         .with_description(description)\
# #         .with_url(url).to_payload()
# #     app_api.update_application_de(payload)
# #
# #     grant = Grants().with_principal(new_user['role_name']) \
# #         .with_view_rights() \
# #         .with_execute_rights() \
# #         .with_auto_deploy()
# #     permissions = ApplicationPermissions().with_app_id(app_id) \
# #         .with_grant(grant.to_payload()) \
# #         .to_payload()
# #
# #     app_api.set_application_permissions(permissions)
# #
# #     app_gateway_api = AppGatewayHelper(cloud_session)
# #     gateway_info = app_gateway_api.get_gateway_management_info(app_id)['GatewayManagementInfo']
# #     assert gateway_info['DnsZone'] == f'gateway.{session_fixture["dnsZone"]}'
# #     assert gateway_info['GeneratedUrl'].endswith(session_fixture['dnsZone'])
# #     assert gateway_info["InternalHost"] in gateway_info['InternalUrl']
# #     assert gateway_info['HasOfflineProxy'] is False
# #     assert gateway_info['HasOnlineProxy'] is True
# #     assert gateway_info['HasGatewayProxy'] is True
# #     assert gateway_info['ProxyErrorMessage'] is None
# #     assert gateway_info['Proxies']
# #     assert len(gateway_info['Proxies']) == len(all_proxies_for_tenant)
# #     for p in all_proxies_for_tenant:
# #         proxy = first_or_default(gateway_info['Proxies'], lambda prox: prox['Name'] == p['Name'])
# #         assert proxy, f'Proxy not listed as expected {p["Name"]}'
# #         for k in p.keys():
# #             assert proxy[k] == p[k]
# #
# #     probe_results = app_gateway_api.probe_gateway_pipeline(app_id)
# #     assert probe_results['ProxyProbeResults'] and probe_results['ProxyProbeResults'][""]['ProxyUuid'] in [p['Uuid'] for p in all_proxies_for_tenant]
# #     assert probe_results['HostUri'] == gateway_info['InternalUrl'].strip('/')
# #     assert probe_results['ProbeResult'] is True
# #     assert probe_results["GatewayManagementInfo"]['DnsZone'] == gateway_info['DnsZone']
# #     assert probe_results["GatewayManagementInfo"]['GeneratedUrl'] == gateway_info['GeneratedUrl']
# #     assert probe_results["GatewayManagementInfo"]['InternalUrl'] == gateway_info['InternalUrl']
# #     assert probe_results["GatewayManagementInfo"]["InternalHost"] == gateway_info['InternalHost']
# #     assert probe_results["GatewayManagementInfo"]['HasOfflineProxy'] == gateway_info['HasOfflineProxy']
# #     assert probe_results["GatewayManagementInfo"]['HasOnlineProxy'] == gateway_info['HasOnlineProxy']
# #
# #     gateway_payload = ConfigureGatewayApplication(app_id)\
# #         .with_is_gatewayed(True)\
# #         .with_configured_state(probe_results['ConfigureGatewayState'])\
# #         .to_payload()
# #     result = app_gateway_api.configure_gateway_application(gateway_payload)
# #     assert result['ShadowAppLink']
# #
# #     url = f'{cloud_session["base_url"]}/uprest/HandleAppClick?appkey={app_id}'
# #     driver.navigate_to(url)
# #     assert driver.current_url == f'{probe_results["GatewayManagementInfo"]["GeneratedUrl"]}{resource}'
#
# #TODO make cruise control app dynamic
# # @pytest.fixture()
# # def cruise_control_app(session_fixture):
# #     return first_or_default(session_fixture['adminApps'], lambda a: a['Name'] == 'CruiseControl App Gateway')
#
# #TODO make cruise control app dynamic
# @pytest.fixture()
# def cruise_control_app_session(app_helpers, user_in_role_with_policy_fixture,
#                                cruise_control_app):
#     cloud_session = app_helpers['cloud_session']
#     with AppHelper(cloud_session, True) as app_api:
#         app = app_api.get_application(cruise_control_app['ID'])
#         grant = Grants().with_principal(user_in_role_with_policy_fixture['role_name']) \
#             .with_view_rights() \
#             .with_execute_rights() \
#             .with_auto_deploy()
#         permissions = ApplicationPermissions().with_app_id(cruise_control_app['ID']) \
#             .with_grant(grant.to_payload()) \
#             .to_payload()
#
#         app_api.set_application_permissions(permissions)
#         yield{
#             'app_api': app_api,
#             'cruise_control_app': app,
#             **user_in_role_with_policy_fixture
#         }
#
#         permissions = ApplicationPermissions().with_app_id(cruise_control_app['ID']) \
#             .with_grant(grant.with_no_rights().to_payload()) \
#             .to_payload()
#         app_api.set_application_permissions(permissions)
#
#
# @pytestrail.case('C119117')
# @pytest.mark.pipeline
# def test_c119117_deploy_existing_ag_app_to_cloud_role_and_launch_from_outside_corp_ip_range(session_fixture,
#                                                                                             cruise_control_app_session,
#                                                                                             ensure_current_ip_not_in_corp_range,
#                                                                                             user_portal_driver):
#     app_name = cruise_control_app_session['cruise_control_app']['Name']
#     url = f'{cruise_control_app_session["cruise_control_app"]["GatewayManagementInfo"]["GeneratedUrl"]}/ccnet/server/local/SimpleUserLogin.aspx'
#     UserPortalPage(user_portal_driver).search_app_input(app_name).launch_app(app_name)
#     assert user_portal_driver.current_url == url
#
#
# @pytestrail.case('C00000')
# def test_c00000_deploy_existing_ag_app_to_ad_role_and_launch_from_outside_corp_ip_range(session_fixture):
#     # precondition - ensure current ip address not in tenant corporate ip range
#     # deploy existing app gateway app to role
#     # add cloud user to role
#     # login as user
#     # launch app
#     # verify page load
#     # verify url == app gateway url
#     # cleanup:
#     #   undeploy app
#     pass
#
#
# @pytestrail.case('C00000')
# def test_c00000_deploy_existing_ag_app_to_ldap_role_and_launch_from_outside_corp_ip_range(session_fixture):
#     # precondition - ensure current ip address not in tenant corporate ip range
#     # deploy existing app gateway app to role
#     # add cloud user to role
#     # login as user
#     # launch app
#     # verify page load
#     # verify url == app gateway url
#     # cleanup:
#     #   undeploy app
#     pass
#
#
# @pytestrail.case('C119118')
# @pytest.mark.pipeline
# def test_c119118_deploy_existing_ag_app_to_cloud_role_and_launch_from_inside_corp_ip_range(session_fixture,
#                                                                                            cruise_control_app_session,
#                                                                                            current_ip_in_corp_range,
#                                                                                            user_portal_driver):
#     app_name = cruise_control_app_session['cruise_control_app']['Name']
#     url = f'{cruise_control_app_session["cruise_control_app"]["Url"]}'
#     UserPortalPage(user_portal_driver).search_app_input(app_name).launch_app(app_name)
#     assert user_portal_driver.current_url == url
#
#
# @pytestrail.case('C00000')
# def test_c00000_deploy_existing_ag_app_to_ad_role_and_launch_from_inside_corp_ip_range(session_fixture):
#     # precondition - ensure current ip address in tenant corporate ip range
#     # deploy existing app gateway app to role
#     # add cloud user to role
#     # login as user
#     # launch app
#     # verify page load
#     # verify url == app gateway url
#     # cleanup:
#     #   undeploy app
#     #   remove ip address from corporate ip range
#     pass
#
#
# @pytestrail.case('C00000')
# def test_c00000_deploy_existing_ag_app_to_ldap_role_and_launch_from_inside_corp_ip_range(session_fixture):
#     # precondition - ensure current ip address in tenant corporate ip range
#     # deploy existing app gateway app to role
#     # add cloud user to role
#     # login as user
#     # launch app
#     # verify page load
#     # verify url == app gateway url
#     # cleanup:
#     #   undeploy app
#     #   remove ip address from corporate ip range
#     pass
