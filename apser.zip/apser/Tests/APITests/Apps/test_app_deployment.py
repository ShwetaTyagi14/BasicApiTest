import pytest
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from Fixtures.app_fixtures import *
from idaptive_automation.api_helpers import RoleApi, UprestHelper
from idaptive_automation.api_payloads import *
import Steps.ldap_steps as ldap_steps
from Steps.app_steps import setup_user_password_app, generate_string
import uuid
from Helpers.test_data_helper import load_json_test_data_file


@pytestrail.case('C33508')
@pytest.mark.pipeline
def test_c33508_auto_deployed_app_is_avail_in_up(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers["app_helper"]
    user_helper = app_helpers["user_helper"]
    tenant_helper = app_helpers["tenant_helper"]

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33508 Test App'
    app_description = 'A test app '
    app_url = 'https://google.com'

    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()

    app_helper.update_application_de(app)
    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()
    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    app_helper.set_application_permissions(permissions)

    apps = app_helper.get_admin_app_list()
    assert next(iter([app for app in apps if app['Row']['Name'] == app_name])) is not None

    user_id = user_helper.create_invited_user(alias, 'c33508')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    up_data = UprestHelper(user_session).get_up_data_for_user()
    assert len([app for app in up_data.result()['Apps'] if app['Name'] == app_name]) == 1


@pytestrail.case('C33509')
@pytest.mark.pipeline
def test_c33509_non_auto_deployed_app_not_avail_in_up(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33509 test app'
    app_description = 'A test app '
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    app_helper.update_application_de(app)
    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights()

    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    app_helper.set_application_permissions(permissions)

    apps = app_helper.get_admin_app_list()
    assert [app for app in apps if app['Row']['Name'] == app_name] is not None

    user_id = user_helper.create_invited_user(alias, 'c33509')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    up_data = UprestHelper(user_session).get_up_data_for_user()
    assert len([app for app in up_data.result()['Apps'] if app['Name'] == app_name]) == 0


@pytestrail.case('C33510')
@pytest.mark.pipeline
def test_c33510_app_displays_in_up_after_user_deploys_it(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33510 User/pass app'
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()

    app_helper.update_application_de(app)

    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights()

    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    app_helper.set_application_permissions(permissions)

    user_id = user_helper.create_invited_user(alias, 'c33510')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    uprest_helper = UprestHelper(user_session)
    uprest_helper.modify_app_shortcuts(app_id)

    up_data = uprest_helper.get_up_data_for_user()
    assert len([app for app in up_data.result()['Apps'] if app['Name'] == app_name]) == 1


@pytestrail.case('C33514')
@pytest.mark.pipeline
def test_c33514_undeployed_app_not_displayed_in_up(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33514 Test App'
    app_url = 'https://google.com'
    app_description = 'A test app '
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    app_helper.update_application_de(app)

    apps = app_helper.get_admin_app_list()
    assert [app for app in apps if app['Row']['Name'] == app_name] is not None

    user_id = user_helper.create_invited_user(alias, 'c33514')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    up_data = UprestHelper(user_session).get_up_data_for_user()
    assert len([app for app in up_data.result()['Apps'] if app['Name'] == app_name]) == 0


@pytestrail.case('C33648')
@pytest.mark.pipeline
def test_c33648_apps_admin_user_can_set_permissions_for_app(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33648 Test App'
    app_description = 'Testing setting permissions on an app'
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testTST1234') \
        .to_payload()
    app_helper.update_application_de(app)
    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()

    username = 'apps_admin'
    display_name = f"Apps Admin C33648"
    payload = CloudUser(alias, username) \
        .with_password_never_expire(True) \
        .with_password('testTEST1234') \
        .with_display_name(display_name) \
        .to_payload()
    uuid = user_helper.create_cloud_user(payload).result()
    with RoleApi(cloud_session, True) as role_api:
        role_id = role_api.create_role_if_not_exists('C33648 Apps Admin')
        role_api.add_users_to_role(role_id, [uuid])
        role_api.add_users_to_automation_role([uuid])
        role_api.assign_super_rights_to_role([{"Role": role_id, "Path": "/lib/rights/appman.json"}])
        user_session = user_helper.authenticate_as_user(payload['Name'], 'testTEST1234')
        permissions = ApplicationPermissions().with_app_id(app_id) \
            .with_grant(grant.to_payload()) \
            .to_payload()

        AppHelper(user_session).set_application_permissions(permissions)
        assert next(iter([a for a in role_api.get_role_apps('Everybody') if a['Row']['ID'] == app_id])) is not None


@pytestrail.case('C33519')
@pytest.mark.pipeline
def test_c33519_non_admin_user_cannot_set_permissions_on_app(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33519 Test App'
    app_description = 'A test app '
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    app_helper.update_application_de(app)
    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()

    user_id = user_helper.create_invited_user(alias, 'c33519')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    response = AppHelper(user_session).set_application_permissions(permissions, False)
    assert not response.success()
    assert 'not authorized' in response.message()


@pytestrail.case('C33520')
@pytest.mark.pipeline
def test_c33520_user_can_set_credentials_for_user_pass_app_if_allowed(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33520 Test App'
    app_description = 'A test app '
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_prompt_for_username() \
        .to_payload()
    app_helper.update_application_de(app)
    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()

    user_id = user_helper.create_invited_user(alias, "c33520")['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')

    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()
    app_helper.set_application_permissions(permissions)

    response = UprestHelper(user_session).set_user_creds_for_app(app_id, 'abc', 'def', False)
    assert response.success()


@pytestrail.case('C33521')
@pytest.mark.pipeline
def test_c33521_user_cannot_set_credentials_for_user_pass_app_if_not_allowed(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33521 Test App'
    app_descrition = 'A test app '
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_descrition) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    app_helper.update_application_de(app)
    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()

    user_id = user_helper.create_invited_user(alias, 'c33521')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')

    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    app_helper.set_application_permissions(permissions)

    response = UprestHelper(user_session).set_user_creds_for_app(app_id, 'newusername', 'newpassword', False)
    assert not response.success()
    assert 'Cannot set user credentials for this type of application' in response.message()


@pytestrail.case('C33524')
@pytest.mark.pipeline
def test_c33524_user_changes_to_fields_in_user_pass_app_reflect_in_handle_app_click(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    app_name = 'C33524 Test App'
    app_description = 'A test app '
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_prompt_for_username()
    app_helper.update_application_de(app.to_payload())

    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()

    user_id = user_helper.create_invited_user(alias, 'c33524')['Name']
    RoleApi(cloud_session).add_users_to_automation_role([user_id])
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')

    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()
    app_helper.set_application_permissions(permissions)

    script = GenericUserPasswordApp.default_script. \
        replace('Username', 'user_name_input', 1). \
        replace('Password', 'pass_word_input', 1)
    app.with_script(script)
    app_helper.update_application_de(app.to_payload())

    uprest_helper = UprestHelper(user_session)
    uprest_helper.set_user_creds_for_app(app_id, 'c33524', 'puppy')
    form = uprest_helper.handle_app_click(app_id).root['body'][0]['form'][0]
    name_input, pass_input = form['input']

    assert name_input['name'] == 'user_name_input'
    assert name_input['value'] == 'c33524'
    assert pass_input['name'] == 'pass_word_input'
    assert pass_input['value'] == 'puppy'


@pytestrail.case('C33525', 'C33526')
@pytest.mark.pipeline
def test_c33525_c33526_user_with_rights_sees_full_app_catalog(mongo_cred_tenant, app_helpers):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    role_helper = app_helpers['role_helper']
    policy_helper = app_helpers['policy_helper']
    tenant_helper = app_helpers['tenant_helper']

    alias = tenant_helper.get_aliases_for_tenant()[0]
    username = 'TestC33525'
    display_name = f"Test C33525"
    payload = CloudUser(alias, username) \
        .with_password_never_expire(True) \
        .with_password('testTEST1234') \
        .with_display_name(display_name) \
        .to_payload()
    uuid = user_helper.create_cloud_user(payload).result()

    role_helper.add_users_to_automation_role([uuid])
    user_session = user_helper.authenticate_as_user(uuid, 'testTEST1234')

    role_id = role_helper.create_role_if_not_exists('C33525 Deny personal apps')
    role_helper.add_users_to_role(role_id, [uuid])
    settings = {"/Core/Security/CDS/Applications/AllowSelfService": False}
    policy_helper.create_policy('C33525 - deny self service',
                                settings, link_type='Role', params=[role_id])

    uprest_api = UprestHelper(user_session)
    user_apps_without_permission = uprest_api.get_user_app_catalog().result()['AppTemplates']

    role_id = role_helper.create_role_if_not_exists('C33525 Allow personal apps')
    role_helper.add_users_to_role(role_id, [uuid])
    settings = {"/Core/Security/CDS/Applications/AllowSelfService": True}
    policy_helper.create_policy('C33525 - allow self service',
                                settings, link_type='Role', params=[role_id])

    admin_apps = UprestHelper(cloud_session).get_user_app_catalog().result()['AppTemplates']
    user_apps = uprest_api.get_user_app_catalog().result()['AppTemplates']

    # this is kinda lame way to validate, but for now we don't have a way of knowing what apps should be deployed
    assert user_apps['FullCount'] > user_apps_without_permission['FullCount']
    assert admin_apps['FullCount'] <= user_apps['FullCount']


# @pytestrail.case('C28074')
# @pytest.mark.pipeline
# def test_c28074_remove_assigned_apps_from_ldap_role_happy_path(create_app_ldap_environment):
    # app_api, user_api, app, _, user, role_api = ldap_role_app_fixture
    # app_id, app_name = app
    # permissions = ldap_steps.add_user_password_app_to_role(ldap_role_app_fixture)
    # permissions['Grants'][0]['Rights'] = 'None'
    # app_api.set_application_permissions(permissions)
    # session = user_api.authenticate_as_user(user['user_name'], user['password'])
    # up_data = UprestHelper(session).get_up_data_for_user()
    # assert len([app for app in up_data.result()['Apps'] if app['Name'] == app_name]) == 0

@pytestrail.case('C83862')
@pytest.mark.pipeline
def test_c83862_remove_assigned_apps_from_cloud_role_happy_path(app_helpers, apps_deployed_to_cloud_role_api_fixture):
    app_api = app_helpers['app_helper']
    user_api = app_helpers['user_helper']
    policy_api = app_helpers['policy_helper']
    role_api = app_helpers['role_helper']
    role_id, alias, users, roles, deployed_apps = apps_deployed_to_cloud_role_api_fixture

    for app in deployed_apps:
        app['permissions']['Grants'][0]['Rights'] = 'None'
        app_api.set_application_permissions(app['permissions'])

    user = users[0]
    session = user_api.authenticate_as_user(user['Name'], user['Password'])
    up_data = UprestHelper(session).get_up_data_for_user()

    for app in deployed_apps:
        assert len([a for a in up_data.result()['Apps'] if a['Name'] == app['name']]) == 0

# @pytestrail.case('C28073')
# @pytest.mark.pipeline
# def test_c28073_add_assigned_apps_to_ldap_role_happy_path(self, ldap_role_app_fixture):
#     self.add_user_password_app_to_role(ldap_role_app_fixture)


@pytestrail.case('C163458')
def test_c163458_set_credentials_for_invalid_app_should_error(app_helpers):
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    user_id = user_helper.create_invited_user(alias, str(uuid.uuid4())[0:8])['Name']
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    response = UprestHelper(user_session).set_user_creds_for_app(
        '00000000-0000-0000-0000-000000000000',
        'new_username',
        'new_password',
        False)
    assert not response.success()
    assert 'Failed to save credentials. Please try again later or try saving the credentials via the User Portal.' \
           in response.message()


@pytestrail.case('C173562')
def test_c173562_username_meets_character_limit(app_helpers):
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    length_json = load_json_test_data_file('../TestData/Applications/default_app_un_pw_lengths.json')
    length = length_json['username_max_length']
    app_id = setup_user_password_app(app_helper, f"{app_helpers['test_id']} Test App")
    username_string = generate_string(length)

    user_id = user_helper.create_invited_user(f"{app_helpers['alias']}", f"{app_helpers['test_id']}")['Name']
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    uprest_helper = UprestHelper(user_session)
    result = uprest_helper.set_user_creds_for_app(app_id, f'{username_string}', 'test', assert_success=False)
    assert result.response['success'], f"result was not successful, got {result.response['Message']} instead"


@pytestrail.case('C173564')
def test_c173564_password_meets_character_limit(app_helpers):
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    length_json = load_json_test_data_file('../TestData/Applications/default_app_un_pw_lengths.json')
    length = length_json['password_max_length']
    app_id = setup_user_password_app(app_helper, f"{app_helpers['test_id']} Test App")
    password_string = generate_string(length)

    user_id = user_helper.create_invited_user(f"{app_helpers['alias']}", f"{app_helpers['test_id']}")['Name']
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    uprest_helper = UprestHelper(user_session)
    result = uprest_helper.set_user_creds_for_app(app_id, 'test', f'{password_string}', assert_success=False)
    assert result.response['success'], f"result was not successful, got {result.response['Message']} instead"


@pytestrail.case('C173563')
def test_c173563_username_exceeds_character_limit(app_helpers):
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    length_json = load_json_test_data_file('../TestData/Applications/default_app_un_pw_lengths.json')
    length = length_json['username_max_length']
    app_id = setup_user_password_app(app_helper, f"{app_helpers['test_id']} Test App")
    username_string = generate_string(length + 1)

    user_id = user_helper.create_invited_user(f"{app_helpers['alias']}", f"{app_helpers['test_id']}")['Name']
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    uprest_helper = UprestHelper(user_session)
    result = uprest_helper.set_user_creds_for_app(app_id, f'{username_string}', 'test', assert_success=False)
    assert not result.response['success']
    assert f"You cannot exceed {length} chars for Username" in result.response['Message']


@pytestrail.case('C173565')
def test_c173565_password_exceeds_character_limit(app_helpers):
    app_helper = app_helpers['app_helper']
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    length_json = load_json_test_data_file('../TestData/Applications/default_app_un_pw_lengths.json')
    length = length_json['password_max_length']
    app_id = setup_user_password_app(app_helper, f"{app_helpers['test_id']} Test App")
    password_string = generate_string(length + 1)

    user_id = user_helper.create_invited_user(f"{app_helpers['alias']}", f"{app_helpers['test_id']}")['Name']
    user_session = user_helper.authenticate_as_user(user_id, 'testTEST1234')
    uprest_helper = UprestHelper(user_session)
    result = uprest_helper.set_user_creds_for_app(app_id, 'test', f'{password_string}', assert_success=False)
    assert not result.response['success']
    assert f"You cannot exceed {length} chars for Password" in result.response['Message']