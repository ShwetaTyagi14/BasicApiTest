# import pytest
# import pytest, re, json
# import time
# from datetime import datetime, timedelta, timezone
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.api_helpers import AppHelper, EmailHelper, CDirectoryService, JobApi, UserApi,\
#     RoleApi, UserMgmt
# from idaptive_automation.api_payloads import GenericUserPasswordApp, ApplicationPermissions, \
#     Grants, WorkflowEnabled, ChangeUser, RequestAppAccess, MyJobs, ApprovePermAppAccessRequest, \
#     ApproveWindowedAppAccessRequest, DenyAppAccessRequest
# from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
# from Helpers.time_helper import current_milliseconds, millseconds_one_hour_ago
# from idaptive_automation.api_client import api_session, mongo_dal
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
#
# # Core.ContactRateLimit.Tenant.UseFailAction    False
#
#
# class TestAppWorkflows:
#     @pytest.fixture()
#     def fixed_username_user_password_app_fixture(self, request, session_fixture):
#         test_name = request.node.originalname or request.node.name
#         m = re.match(r'test_(c\d{5,})_', test_name)
#         test_number = m.group(1)
#         assert m is not None and test_number is not None
#         with AppHelper(session_fixture['session'], True) as app_api:
#             app_name = f'{test_number} Test App'
#             app_descrition = f'Test App for test {test_number}'
#             app_url = 'https://google.com'
#             app_id = app_api.import_username_password_app()
#
#             app = GenericUserPasswordApp(app_id).with_url(app_url)\
#                                                 .with_description(app_descrition)\
#                                                 .with_name(app_name)\
#                                                 .with_fixed_username('testusername', 'testpassword')\
#                                                 .to_payload()
#
#             app_api.update_application_de(app)
#             yield [app_api, app]
#
#     @pytest.fixture()
#     def two_existing_cloud_users(self, session_fixture):
#         with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#             users = client.find_many('cloudUsers',
#                                      {'tenant': session_fixture['tenant'],
#                                       'Password': {'$exists': True},
#                                       '$or': [{'LastAppRequest': None}, {'LastAppRequest': {'$lte': millseconds_one_hour_ago()}}]
#                                       },
#                                      limit=2)
#             if users is None or len(users) == 0:
#                 raise Exception(f'''\r\n***********************
# No cloud users found in MongoDB for tenant {session_fixture["tenant"]}
# If users exist, they must also contain required fields such as LoginName, Password, etc
# ***********************\r\n''')
#
#         yield users
#
#     @pytest.fixture()
#     def app_and_cloud_user(self, fixed_username_user_password_app_fixture,
#                            existing_cloud_user):
#         app_api, app = fixed_username_user_password_app_fixture
#         user = existing_cloud_user
#
#         yield [app_api, app, user]
#
#     @pytest.fixture()
#     def cloud_user_with_manager_fixture(self, two_existing_cloud_users, session_fixture):
#         user, manager = two_existing_cloud_users
#         user_payload = ChangeUser().from_mongodb_cloud_user(user) \
#             .with_email(session_fixture['email']['address'])\
#             .with_reports_to(manager['Name']).to_payload()
#         manager_payload = ChangeUser().from_mongodb_cloud_user(manager)\
#             .with_email(session_fixture['email']['address']).to_payload()
#
#         cd_api = CDirectoryService(session_fixture['session'])
#         cd_api.change_user(manager_payload)
#         cd_api.change_user(user_payload)
#         manager['Mail'] = session_fixture['email']['address']
#         with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#             cms = current_milliseconds()
#             print(f'Setting last app request to: {cms} for user {user["Name"]}')
#             client.update('cloudUsers',
#                           {'Uuid': manager['Uuid']},
#                           {'Mail': session_fixture['email']['address']})
#             client.update('cloudUsers',
#                           {'Uuid': user['Uuid']},
#                           {'Mail': session_fixture['email']['address'],
#                            'Manager': {
#                                'uuid': manager['Uuid'],
#                                'name': manager['Name']
#                            },
#                            'LastAppRequest': cms
#                            })
#
#         with RoleApi(session_fixture['session'], True) as role_api:
#             role_api.add_users_to_automation_role([manager['Uuid'], user['Uuid']])
#             yield [user, manager]
#
#             session = UserApi(session_fixture['session']).authenticate_as_user(manager['Name'], manager['Password'])
#             jobs = JobApi(session).get_my_jobs(MyJobs('all').to_payload())
#         with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#             client.update('cloudUsers',
#                           {'Uuid': manager['Uuid']},
#                           {'Jobs': jobs})
#
#     @pytest.fixture()
#     def a_user_a_manager_and_a_workflow_app(self, cloud_user_with_manager_fixture,
#                                             fixed_username_user_password_app_fixture):
#         app_api, app = fixed_username_user_password_app_fixture
#         user, manager = cloud_user_with_manager_fixture
#         payload = WorkflowEnabled(app['_RowKey'], app['IconUri'])\
#             .with_no_manager_action_approve()\
#             .to_payload()
#
#         app_api.update_application_de(payload)
#         application = app_api.get_application(app['_RowKey'])
#
#         assert application['WorkflowEnabled'] is True
#
#         yield [app_api, app, user, manager]
#
#     @pytestrail.case('C45548')
#     @pytest.mark.pipeline
#     def test_c45548_enable_workflow_happy_path(self, app_and_cloud_user):
#         app_api, app, user = app_and_cloud_user
#         payload = WorkflowEnabled(app['_RowKey'], app['IconUri'])\
#             .with_no_manager_action_approve()\
#             .to_payload()
#
#         app_api.update_application_de(payload)
#         application = app_api.get_application(app['_RowKey'])
#
#         assert application['WorkflowEnabled'] is True
#
#     @pytestrail.case('C45549')
#     @pytest.mark.pipeline
#     def test_c45549_request_permanent_access_happy_path(self, a_user_a_manager_and_a_workflow_app,
#                                                         session_fixture):
#         timestamp = int(time.time()) - 1
#         app_api, app, user, manager = a_user_a_manager_and_a_workflow_app
#         payload = WorkflowEnabled(app['_RowKey'], app['IconUri'])\
#             .with_no_manager_action_approve()\
#             .to_payload()
#
#         app_api.update_application_de(payload)
#
#         user_api = UserApi(session_fixture['session'])
#
#         try:
#             session = user_api.authenticate_as_user(user['Name'], user['Password'])
#         except Exception:
#             print(f'Authentication failed for user: {user["Name"]} using pwd: {user["Password"]}')
#             raise
#         job_api = JobApi(session)
#         payload = RequestAppAccess(app['_RowKey']).with_permanent_access().to_payload()
#         job_id = job_api.request_app_access(payload)
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'appName': app['Name'],
#             'requestor.username': user['Name'],
#             'approver1.username': manager['Name']
#         }
#
#         try:
#             session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         except Exception:
#             print(f'Authentication failed for user: {manager["Name"]} using pwd: {manager["Password"]}')
#             raise
#         jobs = JobApi(session).get_my_jobs(MyJobs('all').to_payload())
#         job = next(iter(job for job in jobs if job['Entities'][0]['Key'] == job_id))
#         assert job is not None
#         assert job['Row']['Context']['RequestorDisplayName'] == user['DisplayName']
#         assert job['Row']['Context']['AppDisplayName'] == app['Name']
#         assert job['Row']['Context']['EventPrincipalUUID'] == user['Uuid']
#         assert job['Row']['Context']['RequestorUUID'] == user['Uuid']
#         assert job['Row']['Context']['EventPrincipalMail'] == user['Mail']
#         assert job['Row']['Context']['EventPrincipalUserName'] == user['Name']
#         assert job['Row']['Context']['RequestorUserName'] == user['Name']
#         assert job['Row']['Context']['RequestedOptions']['AccessType'] == 'App'
#         assert job['Row']['Context']['RequestedOptions']['AssignmentType'] == 'perm'
#         assert job['Row']['Context']['AppKey'] == app['_RowKey']
#         assert job['Row']['State'] == 'Ask'
#
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message['appName'] == app['Name']
#
#     @pytestrail.case('C45553')
#     @pytest.mark.pipeline
#     def test_c45553_request_windowed_access_happy_path(self, a_user_a_manager_and_a_workflow_app,
#                                                        session_fixture):
#         timestamp = int(time.time()) - 1
#         app_api, app, user, manager = a_user_a_manager_and_a_workflow_app
#         payload = WorkflowEnabled(app['_RowKey'], app['IconUri'])\
#             .with_no_manager_action_approve()\
#             .to_payload()
#
#         app_api.update_application_de(payload)
#
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(user['Name'], user['Password'])
#         job_api = JobApi(session)
#         start_time = datetime.utcnow()
#         end_time = datetime.utcnow() + timedelta(hours=3)
#         payload = RequestAppAccess(app['_RowKey'])\
#             .with_windowed_access(start_time, end_time)\
#             .to_payload()
#         job_id = job_api.request_app_access(payload)
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access request',
#             'appName': app['Name'],
#             'requestor.username': user['Name'],
#             'approver1.username': manager['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message['appName'] == app['Name']
#
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         jobs = JobApi(session).get_my_jobs(MyJobs('all').to_payload())
#         job = next(iter(job for job in jobs if job['Entities'][0]['Key'] == job_id))
#         assert job is not None
#         assert job['Row']['Context']['RequestorDisplayName'] == user['DisplayName']
#         assert job['Row']['Context']['AppDisplayName'] == app['Name']
#         assert job['Row']['Context']['EventPrincipalUUID'] == user['Uuid']
#         assert job['Row']['Context']['RequestorUUID'] == user['Uuid']
#         assert job['Row']['Context']['EventPrincipalMail'] == user['Mail']
#         assert job['Row']['Context']['EventPrincipalUserName'] == user['Name']
#         assert job['Row']['Context']['RequestorUserName'] == user['Name']
#         assert job['Row']['Context']['RequestedOptions']['AccessType'] == 'App'
#         assert job['Row']['Context']['RequestedOptions']['AssignmentType'] == 'window'
#         assert job['Row']['Context']['AppKey'] == app['_RowKey']
#
#     @pytest.fixture()
#     def perm_access_has_been_requested(self, a_user_a_manager_and_a_workflow_app,
#                                        session_fixture):
#         timestamp = int(time.time()) - 1
#         app_api, app, user, manager = a_user_a_manager_and_a_workflow_app
#         payload = WorkflowEnabled(app['_RowKey'], app['IconUri'])\
#             .with_no_manager_action_approve()\
#             .to_payload()
#
#         app_api.update_application_de(payload)
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(user['Name'], user['Password'])
#         job_api = JobApi(session)
#         payload = RequestAppAccess(app['_RowKey']).with_permanent_access().to_payload()
#         job_id = job_api.request_app_access(payload)
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         jobs = JobApi(session).get_my_jobs(MyJobs('all').to_payload())
#         job = next(iter(job for job in jobs if job['Entities'][0]['Key'] == job_id))
#         assert job is not None
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access request',
#             'appName': app['Name'],
#             'requestor.username': user['Name'],
#             'approver1.username': manager['Name']
#         }
#         yield [app_api, app, user, manager, job_id, query]
#
#     @pytest.fixture()
#     def windowed_access_has_been_requested(self, a_user_a_manager_and_a_workflow_app,
#                                            session_fixture):
#
#         timestamp = int(time.time()) - 1
#         app_api, app, user, manager = a_user_a_manager_and_a_workflow_app
#         payload = WorkflowEnabled(app['_RowKey'], app['IconUri'])\
#             .with_no_manager_action_approve()\
#             .to_payload()
#
#         app_api.update_application_de(payload)
#
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(user['Name'], user['Password'])
#         job_api = JobApi(session)
#         start_time = datetime.utcnow()
#         end_time = datetime.utcnow() + timedelta(hours=3)
#         payload = RequestAppAccess(app['_RowKey']).with_windowed_access(start_time, end_time).to_payload()
#         job_id = job_api.request_app_access(payload)
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         jobs = JobApi(session).get_my_jobs(MyJobs('all').to_payload())
#         job = next(iter(job for job in jobs if job['Entities'][0]['Key'] == job_id))
#         assert job is not None
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access request',
#             'appName': app['Name'],
#             'requestor.username': user['Name'],
#             'approver1.username': manager['Name']
#         }
#         yield [app_api, app, user, manager, job_id, query]
#
#     @pytestrail.case('C45550')
#     @pytest.mark.pipeline
#     def test_c45550_grant_perm_access_happy_path(self, perm_access_has_been_requested,
#                                                  session_fixture):
#         app_api, app, user, manager, job_id, query = perm_access_has_been_requested
#
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message['appName'] == app['Name']
#
#         timestamp = int(time.time()) - 1
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         result = JobApi(session).approve_app_access_request(ApprovePermAppAccessRequest(job_id).to_payload())
#         assert result['State'] == 'Complete'
#         assert result['TargetPrincipalAction'] == 'Approved'
#         assert result['DefaultOptions'] == '{"EndTime":null,"StartTime":null,"AssignmentType":"perm"}'
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access approval',
#             'appName': app['Name'],
#             'approver1.username': manager['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message is not None
#         assert message['appName'] == app['Name']
#         assert message['appUrl'].startswith(f'https://{session_fixture["tenant"]}')
#
#     @pytestrail.case('C45554')
#     @pytest.mark.pipeline
#     def test_c45554_grant_windowed_access_happy_path(self, windowed_access_has_been_requested,
#                                                      session_fixture):
#         app_api, app, user, manager, job_id, query = windowed_access_has_been_requested
#
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message['appName'] == app['Name']
#
#         timestamp = int(time.time()) - 1
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         start_time = datetime.utcnow()
#         end_time = datetime.utcnow() + timedelta(hours=3)
#         approval = ApproveWindowedAppAccessRequest(job_id)\
#             .with_start_time(start_time)\
#             .with_end_time(end_time)\
#             .to_payload()
#         result = JobApi(session).approve_app_access_request(approval)
#         assert result['State'] == 'Complete'
#         assert result['TargetPrincipalAction'] == 'Approved'
#         end_timestamp = int(end_time.replace(tzinfo=timezone.utc, microsecond=0).timestamp()) * 1000
#         start_timestamp = int(start_time.replace(tzinfo=timezone.utc, microsecond=0).timestamp()) * 1000
#         assert result['SelectedOptions'] == f'{{"EndTime":"\\/Date({end_timestamp})\\/","StartTime":"\\/Date({start_timestamp})\\/","AccessType":"App","AssignmentType":"window"}}'
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access approval',
#             'approver1.username': manager['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message is not None
#         assert message['appName'] == app['Name']
#         assert message['appUrl'].startswith(f'https://{session_fixture["tenant"]}')
#
#     @pytest.fixture()
#     def completed_job(self,
#                       a_user_a_manager_and_a_workflow_app,
#                       session_fixture):
#         with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
#             user_w_completed_requests = client.find_one('cloudUsers',
#                                                         {'Jobs.Row.State': 'Complete',
#                                                          'tenant': session_fixture['tenant']})
#             if user_w_completed_requests is None:
#                 raise Exception(f'No users with completed jobs found on tenant {session_fixture["tenant"]}')
#         job = next(iter(job for job in user_w_completed_requests['Jobs'] if job['Row']['State'] == 'Complete'))
#
#         with RoleApi(session_fixture['session']) as role_api:
#             role_api.add_users_to_automation_role([user_w_completed_requests['Uuid']])
#             session = UserApi(session_fixture['session']).authenticate_as_user(user_w_completed_requests['Name'],
#                                                                                user_w_completed_requests['Password'])
#             job_api = JobApi(session)
#             yield [job, job_api]
#
#     @pytestrail.case('C45551')
#     @pytest.mark.pipeline
#     def test_c45551_grant_access_on_completed_request_negative_test(self, completed_job):
#         job, job_api = completed_job
#         job_id = job['Entities'][0]['Key']
#         approval = ApprovePermAppAccessRequest(job_id).to_payload()
#         result = job_api.approve_app_access_request(approval, assert_success=False)
#         assert not result.success()
#         assert result.message() == "Workflow is in state Complete and may not accept further input."
#
#     @pytestrail.case('C45555')
#     @pytest.mark.pipeline
#     def test_c45555_deny_perm_access_happy_path(self, perm_access_has_been_requested,
#                                                 session_fixture):
#         app_api, app, user, manager, job_id, query = perm_access_has_been_requested
#
#         timestamp = int(time.time()) - 1
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         reason = "Just because"
#         payload = DenyAppAccessRequest(job_id).with_reason(reason).to_payload()
#         # Tenant Unlimited Contact Rate Limit
#         result = JobApi(session).approve_app_access_request(payload)
#         assert result['State'] == 'Complete'
#         assert result['TargetPrincipalAction'] == 'Rejected'
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access denial',
#             'appName': app['Name'],
#             'approver1.username': manager['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message is not None
#         assert message['appName'] == app['Name']
#         assert message['reason'] == reason
#
#     @pytestrail.case('C45557')
#     @pytest.mark.pipeline
#     def test_c45557_deny_windowed_access_happy_path(self, windowed_access_has_been_requested,
#                                                     session_fixture):
#         app_api, app, user, manager, job_id, query = windowed_access_has_been_requested
#
#         timestamp = int(time.time()) - 1
#         user_api = UserApi(session_fixture['session'])
#         session = user_api.authenticate_as_user(manager['Name'], manager['Password'])
#         reason = "Just because"
#         payload = DenyAppAccessRequest(job_id).with_reason(reason).to_payload()
#         result = JobApi(session).approve_app_access_request(payload)
#         assert result['State'] == 'Complete'
#         assert result['TargetPrincipalAction'] == 'Rejected'
#
#         query = {
#             'date.received': {'$gt': timestamp},
#             'emailType': 'app access denial',
#             'appName': app['Name'],
#             'approver1.username': manager['Name']
#         }
#         messages = EmailHelper(None).wait_for_message(query, wait_seconds=session_fixture['wait_secs_for_email'])
#         assert messages is not None and len(messages) == 1, \
#             f'Expected 1 email, found {0 if messages is None else len(messages)} matching query {json.dumps(query)}'
#         message = messages[0]
#         assert message is not None
#         assert message['appName'] == app['Name']
#         assert message['reason'] == reason
