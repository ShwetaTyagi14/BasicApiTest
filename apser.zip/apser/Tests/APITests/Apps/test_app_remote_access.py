from idaptive_testrail.plugin import pytestrail
from Steps.app_steps import *


@pytestrail.case('C178455')
@pytest.mark.pipeline
def test_c178455_delete_application_for_remote_access_app(app_helpers):
    cloud_session = app_helpers['cloud_session']
    app_api = AppHelper(cloud_session)

    # Get CyberArk Remote Access app id
    app_id = get_remote_access_app_id(app_api)

    # Try to delete the app. It should fail.
    result = app_api.delete_application(app_id, False)
    assert not result.response['success']
