import pytest
import sys
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
from idaptive_automation.api_helpers import AppGatewayHelper, UprestHelper, ProxyApi, AuthProfileHelper,\
    AppHelper, IPRangeHelper
from idaptive_automation.api_payloads import GenericBookmark, Grants, ApplicationPermissions, \
    ConfigureGatewayApplication, AuthenticationProfile
from idaptive_automation.ui_automation import UserPortalPage
from Steps.app_steps import *


@pytestrail.case("C119117")
@pytest.mark.postdeploy
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c119117_launch_app_gateway_app_from_outside_corp_ip(connector_vm, app_helpers):
    user_helper = app_helpers['user_helper']
    tenant_info = app_helpers['tenant_info']
    short_app_name = "App_GW_test"
    app_configuration_result, result_app_details = deploy_app_gw_enabled_up_app(short_app_name, app_helpers)

    uprest_helper = UprestHelper(user_helper.api_session)
    response = uprest_helper.handle_app_click(result_app_details['_RowKey'], raw_response=True)
    env_url_suffix = tenant_info['base_url'].split(".my.")[1]
    assert f"action=\"https://{app_configuration_result['ShadowAppLink']}.gateway.{env_url_suffix}/\"" in response.text
#
#
# @pytest.fixture()
# def policy(pwd_only_profile):
#     yield {
#         "AuthenticationEnabled": True,
#         "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
#     }
#
#
# @pytest.fixture()
# def pwd_only_profile(session_fixture, case_number):
#     with AuthProfileHelper(session_fixture['session'], True) as profile_helper:
#         yield profile_helper.create_profile(AuthenticationProfile(f'{case_number} Pwd Only Profile')
#                                             .with_challenges(["UP"])
#                                             .with_duration_in_minutes(5)
#                                             .to_payload())
#
#
# @pytest.fixture()
# def app_gateway_fixture(session_fixture, user_in_role_with_policy_fixture):
#     with AppHelper(session_fixture['session'], True) as app_api:
#         yield{
#             'app_api': app_api,
#             **user_in_role_with_policy_fixture
#         }
#
#
# @pytest.fixture()
# def all_proxies_for_tenant(session_fixture):
#     proxies = ProxyApi(session_fixture['session']).get_all_proxies()
#     return [{
#         'Name': p['Name'],
#         'Hostname': p['MachineName'],
#         'Uuid': p['ID'],
#         'Version': p['Version'],
#         'IsOnline': p['Online'],
#         'IsGatewayCapable': p['AppGateway'] == 'Enabled',
#         'IsPreferred': False,
#         'ErrorMessage': None
#     } for p in proxies]
#
#
# @pytest.fixture()
# def user(random_ad_user_in_automation_role):
#     return random_ad_user_in_automation_role
#
#
# @pytest.fixture()
# def user_portal_driver(session_fixture, case_number, screenshots, user):
#     with Driver(webdriver.ChromeOptions(), base_url=session_fixture['url'],
#                 case_number=case_number, screenshots=screenshots) as browser:
#         browser.maximize_window()
#         browser.navigate_to('https://api.ipify.org?format=json')
#         browser.current_ip = browser.page_source.split('{')[1].split('}')[0].split(':')[1].strip('"')
#         Login(browser, session_fixture['url'])\
#             .to_user_portal(user['mail'], user['userPassword'])
#         yield browser
#
#
# @pytest.fixture()
# def ensure_current_ip_not_in_corp_range(session_fixture, user_portal_driver):
#     ip_helper = IPRangeHelper(session_fixture['session'])
#     corp_ranges = [r['Row']['ID'] for r in ip_helper.get_corp_ip_ranges()['Results']]
#     assert user_portal_driver.current_ip not in corp_ranges, 'Test cannot be run. Current IP is part of corp IP range'
#
#
# @pytest.fixture()
# def current_ip_in_corp_range(session_fixture, case_number, user_portal_driver):
#     with IPRangeHelper(session_fixture['session'], True) as ip_helper:
#         corp_ranges = [r['Row']['ID'] for r in ip_helper.get_corp_ip_ranges()['Results']]
#         if user_portal_driver.current_ip not in corp_ranges:
#             ip_helper.add_corp_ip_range(case_number, user_portal_driver.current_ip)
#         yield ip_helper
#
#
# @pytest.fixture()
# def cruise_control_app(session_fixture):
#     return first_or_default(session_fixture['adminApps'], lambda a: a['Name'] == 'CruiseControl App Gateway')
#
#
# @pytest.fixture()
# def cruise_control_app_session(session_fixture, random_ad_user_in_role_with_policy_fixture,
#                                cruise_control_app):
#     with AppHelper(session_fixture['session'], True) as app_api:
#         app = app_api.get_application(cruise_control_app['ID'])
#         grant = Grants().with_principal(random_ad_user_in_role_with_policy_fixture['role_name']) \
#             .with_view_rights() \
#             .with_execute_rights() \
#             .with_auto_deploy()
#         permissions = ApplicationPermissions().with_app_id(cruise_control_app['ID']) \
#             .with_grant(grant.to_payload()) \
#             .to_payload()
#
#         app_api.set_application_permissions(permissions)
#         yield{
#             'app_api': app_api,
#             'cruise_control_app': app,
#             **random_ad_user_in_role_with_policy_fixture
#         }
#
#         permissions = ApplicationPermissions().with_app_id(cruise_control_app['ID']) \
#             .with_grant(grant.with_no_rights().to_payload()) \
#             .to_payload()
#         app_api.set_application_permissions(permissions)
#
#
# @pytestrail.case('C119407')
# @pytest.mark.pipeline
# def test_c119407_deploy_existing_ag_app_to_ad_role_and_launch_from_outside_corp_ip_range(session_fixture,
#                                                                                          cruise_control_app_session,
#                                                                                          ensure_current_ip_not_in_corp_range,
#                                                                                          user_portal_driver):
#     app_name = cruise_control_app_session['cruise_control_app']['Name']
#     url = f'{cruise_control_app_session["cruise_control_app"]["GatewayManagementInfo"]["GeneratedUrl"]}/ccnet/server/local/SimpleUserLogin.aspx'
#     UserPortalPage(user_portal_driver).search_app_input(app_name).launch_app(app_name)
#     assert user_portal_driver.current_url == url
#
#
# @pytestrail.case('C119408')
# @pytest.mark.pipeline
# def test_c119408_deploy_existing_ag_app_to_ad_role_and_launch_from_inside_corp_ip_range(session_fixture,
#                                                                                         cruise_control_app_session,
#                                                                                         current_ip_in_corp_range,
#                                                                                         user_portal_driver):
#     app_name = cruise_control_app_session['cruise_control_app']['Name']
#     url = f'{cruise_control_app_session["cruise_control_app"]["Url"]}'
#     UserPortalPage(user_portal_driver).search_app_input(app_name).launch_app(app_name)
#     assert user_portal_driver.current_url == url
