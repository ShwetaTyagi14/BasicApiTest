import pytest
from idaptive_automation.api_payloads import GenericUserPasswordApp, ApplicationPermissions
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from idaptive_automation.api_helpers import RoleApi
from Helpers.general_helpers import random_password


@pytestrail.case('C33517')
@pytest.mark.pipeline
def test_c33517_user_cannot_launch_app_deployed_for_another_user(app_helpers):
    test_id = app_helpers['test_id']
    app_helper = app_helpers["app_helper"]
    user_helper = app_helpers["user_helper"]
    tenant_helper = app_helpers['tenant_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    tenant_info = app_helpers['tenant_info']
    cloud_session = app_helpers['cloud_session']
    user_password = random_password(length=25)
    username = f'automation-user-{test_id}'
    display_name = f"Automation {alias} {test_id}"
    payload = CloudUser(alias, username) \
        .with_password_never_expire(True) \
        .with_password(user_password) \
        .with_display_name(display_name) \
        .to_payload()
    user = user_helper.create_cloud_user(payload)

    user_login_name = payload['Name']

    app_name = f'c33517 Test App {test_id}'
    app_description = 'A test app'
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()
    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    app_helper.update_application_de(app)
    payload = ApplicationPermissions() \
        .with_grant({
            "Principal": user_login_name,
            "PType": "User",
            "Rights": "View,Execute,Automatic",
            "PrincipalId": user.response['Result'],
        }) \
        .with_app_id(app['_RowKey']) \
        .to_payload()
    app_helper.set_application_permissions(payload)
    user_session = user_helper.authenticate_as_user(user_login_name, user_password)
    resp = user_session.get(url=f"{tenant_info['base_url']}/run?appkey={app_id}&customerID={tenant_info['tenant_id']}")
    assert 'Unable to Launch Application' not in resp.text

    username = f'automation-user2-{test_id}'
    display_name = f"Automation2 {alias} {test_id}"
    password = random_password(length=32)
    payload = CloudUser(alias, username) \
        .with_password_never_expire(True) \
        .with_password(password) \
        .with_display_name(display_name) \
        .to_payload()
    payload['uuid'] = user_helper.create_cloud_user(payload).result()

    RoleApi(cloud_session).add_users_to_automation_role([payload['uuid']])

    user = CloudUser(tenant_info['tenant_id'], str(uuid.uuid4())[0:8])
    user_no_perms_id = user_helper.create_cloud_user_if_not_exists(user.to_payload())
    user_session = user_helper.authenticate_as_user(payload['Name'], password)
    resp = user_session.get(url=f"{tenant_info['base_url']}/run?appkey={app_id}&customerID={tenant_info['tenant_id']}")
    assert 'Unable to Launch Application' in resp.text
