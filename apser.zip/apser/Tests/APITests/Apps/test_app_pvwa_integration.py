from idaptive_testrail.plugin import pytestrail
from Fixtures.app_fixtures import *
from Fixtures.pvwa_integration_fixture import PVWA_fixture as pvwa


# @pytestrail.case('C158396')
# def test_c158396_enable_pvwa_corporate_apps(app_helpers, pvwa):
#     """ Enable PVWA, then check if 'StoreUserCredsInVault' is available in app API """
#     app_helpers = app_helpers['app_helper']
#
#     test_app = pvwa.create_app("Generic User-Password")
#     pvwa.enable_pvwa(corporate=True, personal=False)
#     test_app_two = pvwa.create_app("Generic User-Password")
#     result_app_one = app_helpers.get_application(test_app)
#     result_app_two = app_helpers.get_application(test_app_two)
#
#     assert "StoreUserCredsInVault" not in result_app_one, f"StoreUserCredsInVault should not be set, but is"
#     assert result_app_two['StoreUserCredsInVault'] is True, "StoreUserCredsInVault should be present, and set to True"
#
#
# @pytestrail.case('C158397')
# def test_c158397_disable_pvwa_corporate_apps(app_helpers, pvwa):
#     """ Check Set/Get API for PVWA """
#     app_helpers = app_helpers['app_helper']
#     pvwa.enable_pvwa(corporate=True, personal=True)
#     success, result = pvwa.get_tenant_config()
#     assert result['StorePersonalAppUserCredsInVault'] is True
#     assert result['StoreCorporateAppUserCredsInVault'] is True
#     pvwa.disable_pvwa()
#     success, result = pvwa.get_tenant_config()
#     assert result['StorePersonalAppUserCredsInVault'] is False
#     assert result['StoreCorporateAppUserCredsInVault'] is False
#     test_app = pvwa.create_app("Generic User-Password")
#     result_test_app = app_helpers.get_application(test_app)
#     assert "StoreUserCredsInVault" not in result_test_app, f"StoreUserCredsInVault should not be set, but is"
#
#
# @pytestrail.case('C158394')
# def test_c158394_pvwa_corporate_apps_present_in_appropriate_app_types(app_helpers, pvwa):
#     """ Validate PVWA Settings is available in applicable app types with PVWA enabled """
#     app_helpers = app_helpers['app_helper']
#     pvwa.enable_pvwa(corporate=True, personal=False)
#
#     app_check_list = ["Generic Browser Extension",
#                       "GenericBrowserExtensionScript",
#                       "GenericNTLMBasic",
#                       "Generic User-Password",
#                       "101Domain"
#                       ]
#
#     for app in app_check_list:
#         test_app = pvwa.create_app(app)
#         result = app_helpers.get_application(test_app)
#         assert result["StoreUserCredsInVault"] is True, f"StoreUserCredsInVault should set and True, but is not in {app}"
#
#
# @pytestrail.case('C158395')
# def test_c158395_pvwa_corporate_apps_not_present_in_other_app_types(app_helpers, pvwa):
#     """ Validate PVWA Settings is NOT available in applicable app types with PVWA enabled """
#     app_helpers = app_helpers['app_helper']
#     pvwa.enable_pvwa(corporate=True, personal=False)
#
#     app_check_list = ["Generic Bookmark",
#                       "OAuth2ServerClient",
#                       "OAuth2Server",
#                       "Generic OpenID Connect",
#                       "Generic SAML",
#                       "GenericWsFed",
#                       "ADPSAML"
#                       ]
#
#     for app in app_check_list:
#         test_app = pvwa.create_app(app)
#         result = app_helpers.get_application(test_app)
#         assert "StoreUserCredsInVault" not in result, f"StoreUserCredsInVault should not be set, but is in {app}"
