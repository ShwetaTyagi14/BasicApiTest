import sys
from Fixtures.app_fixtures import auto_clean_app_fixture
from idaptive_testrail.plugin import pytestrail
from Steps.app_steps import *


@pytestrail.case('C178331')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c178331_get_oidc_standard_claims(driver_to_user_portal, app_helpers, auto_clean_app_fixture):
    tenant_info = app_helpers['tenant_info']
    port = get_available_port()

    # Create OIDC app
    app_id, app_name, client_secret, index_page_uri, redirect_uri = create_oidc_app(app_helpers, tenant_info, port)

    # Start OIDC Client
    start_oidc_client(app_id, app_name, client_secret, redirect_uri, tenant_info, port)

    # Follow Authorization Code flow and get JWT token
    access_token = follow_authorization_code_flow(driver_to_user_portal, index_page_uri)

    # Call UserInfo endpoint with access_token
    if access_token != '':
        call_userinfo(app_helpers, app_name, access_token)
