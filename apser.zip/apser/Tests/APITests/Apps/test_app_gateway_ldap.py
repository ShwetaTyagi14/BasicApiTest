# import pytest
# from idaptive_testrail.plugin import pytestrail
# from idaptive_automation.api_client import api_session, mongo_dal, ApiSession
# from idaptive_automation.fixtures import authenticated_api_function_fixture as session_fixture
# from idaptive_automation.api_helpers import AppGatewayHelper, UprestHelper, ProxyApi, AuthProfileHelper,\
#     AppHelper, IPRangeHelper
# from idaptive_automation.api_payloads import GenericBookmark, Grants, ApplicationPermissions, \
#     ConfigureGatewayApplication, AuthenticationProfile
# from Helpers.linq_helper import first_or_default
# from selenium import webdriver
# from Common import Driver
# from Steps.login_steps import Login
# from idaptive_automation.ui_automation import UserPortalPage
#
#
# @pytest.fixture()
# def policy(pwd_only_profile):
#     yield {
#         "AuthenticationEnabled": True,
#         "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
#     }
#
#
# @pytest.fixture()
# def pwd_only_profile(session_fixture, case_number):
#     with AuthProfileHelper(session_fixture['session'], True) as profile_helper:
#         yield profile_helper.create_profile(AuthenticationProfile(f'{case_number} Pwd Only Profile')
#                                             .with_challenges(["UP"])
#                                             .with_duration_in_minutes(5)
#                                             .to_payload())
#
#
# @pytest.fixture()
# def user(random_ldap_user):
#     yield random_ldap_user
#
#
# @pytest.fixture()
# def user_portal_driver(session_fixture, case_number, screenshots, user):
#     with Driver(webdriver.ChromeOptions(), base_url=session_fixture['url'],
#                 case_number=case_number, screenshots=screenshots) as browser:
#         browser.maximize_window()
#         browser.navigate_to('https://api.ipify.org?format=json')
#         browser.current_ip = browser.page_source.split('{')[1].split('}')[0].split(':')[1].strip('"')
#         Login(browser, session_fixture['url'])\
#             .to_user_portal(user['mail'].split('@')[0], user['userPassword'])
#         yield browser
#
#
# @pytest.fixture()
# def ensure_current_ip_not_in_corp_range(session_fixture, user_portal_driver):
#     ip_helper = IPRangeHelper(session_fixture['session'])
#     corp_ranges = [r['Row']['ID'] for r in ip_helper.get_corp_ip_ranges()['Results']]
#     assert user_portal_driver.current_ip not in corp_ranges, 'Test cannot be run. Current IP is part of corp IP range'
#
#
# @pytest.fixture()
# def current_ip_in_corp_range(session_fixture, case_number, user_portal_driver):
#     with IPRangeHelper(session_fixture['session'], True) as ip_helper:
#         corp_ranges = [r['Row']['ID'] for r in ip_helper.get_corp_ip_ranges()['Results']]
#         if user_portal_driver.current_ip not in corp_ranges:
#             ip_helper.add_corp_ip_range(case_number, user_portal_driver.current_ip)
#         yield ip_helper
#
#
# @pytest.fixture()
# def cruise_control_app(session_fixture):
#     return first_or_default(session_fixture['adminApps'], lambda a: a['Name'] == 'CruiseControl App Gateway')
#
#
# @pytest.fixture()
# def cruise_control_app_session(session_fixture, user_in_role_with_policy_fixture,
#                                cruise_control_app):
#     with AppHelper(session_fixture['session'], True) as app_api:
#         app = app_api.get_application(cruise_control_app['ID'])
#         grant = Grants().with_principal(user_in_role_with_policy_fixture['role_name']) \
#             .with_view_rights() \
#             .with_execute_rights() \
#             .with_auto_deploy()
#         permissions = ApplicationPermissions().with_app_id(cruise_control_app['ID']) \
#             .with_grant(grant.to_payload()) \
#             .to_payload()
#
#         app_api.set_application_permissions(permissions)
#         yield{
#             'app_api': app_api,
#             'cruise_control_app': app,
#             **user_in_role_with_policy_fixture
#         }
#
#         permissions = ApplicationPermissions().with_app_id(cruise_control_app['ID']) \
#             .with_grant(grant.with_no_rights().to_payload()) \
#             .to_payload()
#         app_api.set_application_permissions(permissions)
#
#
# @pytestrail.case('C119413')
# @pytest.mark.pipeline
# def test_c119413_deploy_existing_ag_app_to_ldap_user_and_launch_from_outside_corp_ip_range(session_fixture,
#                                                                                            cruise_control_app_session,
#                                                                                            ensure_current_ip_not_in_corp_range,
#                                                                                            user_portal_driver):
#     app_name = cruise_control_app_session['cruise_control_app']['Name']
#     url = f'{cruise_control_app_session["cruise_control_app"]["GatewayManagementInfo"]["GeneratedUrl"]}/ccnet/server/local/SimpleUserLogin.aspx'
#     UserPortalPage(user_portal_driver).search_app_input(app_name).launch_app(app_name)
#     assert user_portal_driver.current_url == url
#
#
# @pytestrail.case('C119414')
# @pytest.mark.pipeline
# def test_c119414_deploy_existing_ag_app_to_ldap_user_and_launch_from_inside_corp_ip_range(session_fixture,
#                                                                                           cruise_control_app_session,
#                                                                                           current_ip_in_corp_range,
#                                                                                           user_portal_driver):
#     app_name = cruise_control_app_session['cruise_control_app']['Name']
#     url = f'{cruise_control_app_session["cruise_control_app"]["Url"]}'
#     UserPortalPage(user_portal_driver).search_app_input(app_name).launch_app(app_name)
#     assert user_portal_driver.current_url == url
