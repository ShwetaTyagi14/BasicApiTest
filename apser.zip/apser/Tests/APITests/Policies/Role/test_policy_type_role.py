from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *


@pytestrail.case('C140379')
@pytest.mark.pipeline
def test_c140379_modify_policy_settings(app_helpers):
    user_helper = app_helpers['user_helper']
    role_helper = app_helpers['role_helper']
    policy_helper = app_helpers['policy_helper']
    tenant_helper = app_helpers['tenant_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]

    test_id = app_helpers['test_id']
    policy_name = f'Automated test {test_id}'

    policy = {
        '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/containerCreate': False
    }

    role_id = role_helper.create_role_if_not_exists(policy_name)

    policy_helper.create_policy(policy_name=policy_name, settings=policy, link_type='Role', params=[role_id])

    email_address = 'test@test.com'
    payload = CloudUser(alias, f'Self-Service-{uuid.uuid4()}').with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_helper.create_cloud_user(payload)
    user_id = payload['Uuid'] = response.result()
    role_helper.add_users_to_role(role_id, [user_id])

    base_line_summary = policy_helper.get_users_policy_summary(user_id)

    new_policy = {
        '/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/containerCreate': True
    }

    policy_helper.update_policy(policy_name=f'/Policy/{policy_name}',settings=new_policy)

    new_summary = policy_helper.get_users_policy_summary(user_id)

    assert not(base_line_summary['rsop']['/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/containerCreate'])
    assert (new_summary['rsop']['/Mobile/Software/Policies/Centrify/SamsungKnoxSettings/containerCreate'])
