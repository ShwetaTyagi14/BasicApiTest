import pytest
from idaptive_automation.api_helpers import UserMgmt
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from Fixtures.policy_fixtures import basic_password_policy, \
    weak_password_policy, strong_password_policy, no_username_password_policy, \
    allow_username_password_policy, require_unicode_password_policy, basic_password_history_policy
from idaptive_automation.api_payloads import CloudUser
from Steps.password_steps import create_user_with_password


class TestUserAndPasswordCreation:
    @pytestrail.case('C28013')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ1@5', 'pyL9*&'])
    def test_c28013_min_length_boundary_tests(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('c28013', user_helper, alias, test_password, True)

    @pytestrail.case('C33719')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ1@'])
    def test_c33719_min_length_boundary_negative_tests(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('c33719', user_helper, alias, test_password, False)

    @pytestrail.case('C28014')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ1@aQ1', 'aQ1@aQ1@'])
    def test_c28014_max_length_boundary_tests(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28014', user_helper, alias, test_password, True)

    @pytestrail.case('C33720')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ1@aQ1qW'])
    def test_c33720_max_length_boundary_negative_tests(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C33720', user_helper, alias, test_password, False)

    @pytestrail.case('C28015')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ1@W', 'aQ1@5'])
    def test_c28015_min_digit_happy_path(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28015', user_helper, alias, test_password, True)

    @pytestrail.case('C33721')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ@A'])
    def test_c33721_min_digit_negative_test(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C33721', user_helper, alias, test_password, False)

    @pytestrail.case('C28016')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ1@Q', '#Q1a$'])
    def test_c28016_symbol_required_happy_path(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28016', user_helper, alias, test_password, True)

    @pytestrail.case('C33722')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aQ16Q'])
    def test_c33722_symbol_required_negative_test(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C33722', user_helper, alias, test_password, False)

    @pytestrail.case('C28018')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['abr1$', 'AB51$'])
    def test_c28018_upper_and_lower_required_negative_test(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28018', user_helper, alias, test_password, False)

    @pytestrail.case('C33723')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aaBB1$',
                                               'BBaa51$',
                                               '#122qTQ',
                                               'zA1##',
                                               'zzAA11@@',
                                               'zzAAzz1@'])
    def test_c33723_consecutive_char_count_happy_path(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C33723', user_helper, alias, test_password, True)

    @pytestrail.case('C33724')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['aaBBB1$',
                                               'BBBaa51$',
                                               '#1222qTQ',
                                               'zA1###',
                                               'zzAA11@@@'])
    def test_c33724_consecutive_char_count_negative_test(self, basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C33724', user_helper, alias, test_password, False)

    @pytestrail.case('C28024')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['abc123',
                                               'Password',
                                               'Passw0rD!',
                                               '!QAZxsw2',
                                               '123456789'])
    def test_c28024_weak_password_happy_path(self, weak_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28024', user_helper, alias, test_password, True)

    @pytestrail.case('C28025')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['testc28025'])
    def test_c28025_username_as_part_of_pwd_happy_path(self, allow_username_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28025', user_helper, alias, test_password, True)

    @pytestrail.case('C28026')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['testc28026'])
    def test_c28026_username_as_part_of_pwd_negative_test(self, no_username_password_policy, app_helpers,
                                                          test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28026', user_helper, alias, test_password, False)

    @pytestrail.case('C28037')
    @pytest.mark.pipeline
    def test_c28037_pwd_cannot_be_repeated_when_equal_to_history_limit(self, basic_password_history_policy, app_helpers):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]
        role_helper = app_helpers["role_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]
        user = CloudUser(alias, 'C28037').with_password('testTEST1234') \
            .with_name('testTEST1234') \
            .with_display_name('C28037')

        uuid = user_helper.create_cloud_user(user.to_payload(), False).result()
        role_helper.add_users_to_automation_role([uuid])
        user_session = user_helper.authenticate_as_user(user.name, user.password)
        user_mgnmt = UserMgmt(user_session)
        user_mgnmt.change_user_password('testTEST1234', 'TESTtest1234', assert_success=True)
        pw_change_response = user_mgnmt.change_user_password('TESTtest1234', 'testTEST1234', assert_success=False)
        assert not pw_change_response.success()
        assert 'Please make sure the new password is not one of last 2 passwords.' in pw_change_response.message()


class TestUnicodeCharacter:
    @pytestrail.case('C28027')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['Test1@'])
    def test_c28027_unicode_chars_negative_test(self, require_unicode_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28027', user_helper, alias, test_password, False)

    @pytestrail.case('C28028')
    @pytest.mark.pipeline
    @pytest.mark.parametrize('test_password', ['\u0074est1@Q'])
    def test_c28028_unicode_chars_happy_path(self,  basic_password_policy, app_helpers, test_password):
        user_helper = app_helpers["user_helper"]
        tenant_helper = app_helpers["tenant_helper"]

        alias = tenant_helper.get_aliases_for_tenant()[0]

        create_user_with_password('C28028', user_helper, alias, test_password, True)
