import pytest
from idaptive_testrail.plugin import pytestrail
from Helpers.test_data_helper import load_json_test_data_file
from Fixtures.policy_fixtures import policy_fixture

POLICY_B = 'Policy B'
POLICY_C = 'Policy C'
DEFAULT_POLICY_B_FILE = 'Endpoint policies - android manage settings - cert profiles Policy B.json'
DEFAULT_POLICY_C_FILE = 'Endpoint policies - android manage settings - cert profiles Policy C.json'


@pytestrail.case('C28089')
@pytest.mark.postdeploy
def test_c28089_policy_reordering_happy_path(policy_fixture):
    policy_api = policy_fixture[0]

    policy_b = load_json_test_data_file(DEFAULT_POLICY_B_FILE)
    policy_c = load_json_test_data_file(DEFAULT_POLICY_C_FILE)
    policy_api.create_policy(POLICY_B, policy_b)
    policy_api.create_policy(POLICY_C, policy_c)

    plinks = policy_api.get_nice_plinks().results()
    assert plinks[0]['Row']['PolicySet'].endswith(POLICY_C)
    assert plinks[1]['Row']['PolicySet'].endswith(POLICY_B)

    plinks[0], plinks[1] = plinks[1], plinks[0]
    payload = [link['Row'] for link in plinks]
    policy_api.set_plinks(payload)

    plinks = policy_api.get_nice_plinks().results()
    assert plinks[0]['Row']['PolicySet'].endswith(POLICY_B)
    assert plinks[1]['Row']['PolicySet'].endswith(POLICY_C)


@pytestrail.case('C28090')
@pytest.mark.pipeline
def test_c28090_policy_reordering_race_condition(policy_fixture):
    policy_api = policy_fixture[0]

    rev_stamp = policy_api.get_nice_plinks().result()['RevStamp']

    policy_b = load_json_test_data_file(DEFAULT_POLICY_B_FILE)
    policy_api.create_policy(POLICY_B, policy_b)

    plinks = policy_api.get_nice_plinks().results()
    payload = [link['Row'] for link in plinks]
    response = policy_api.set_plinks(payload, rev_stamp, False)

    assert not response.success()
    assert 'recently modified' in response.response['Message']


@pytestrail.case('C28094')
@pytest.mark.pipeline
def test_c28094_setplinks_wont_accept_invalid_policies(policy_fixture):
    policy_api = policy_fixture[0]

    invalid_policy = {
                "Params": [],
                "ID": "/Policy/DOESNT_EXIST",
                "EnableCompliant": False,
                "Description": "",
                "LinkType": "Global",
                "PolicySet": "/Policy/DOESNT_EXIST"
            }

    plinks = policy_api.get_nice_plinks().results()

    payload = [link['Row'] for link in plinks]
    payload.insert(0, invalid_policy)

    response = policy_api.set_plinks(payload)

    assert response.success()


@pytestrail.case('C28138')
@pytest.mark.parametrize('test_file', [
    'App policies - user settings - Policy B.json',
    # 'Authentication policies - zero trust Policy B.json',  # TODO Awaiting to be moved to Endpoint Team # policy enforcement
    'Endpoint policies - android manage settings - cert profiles Policy B.json',
    'Endpoint policies - android manage settings - device owner Policy B.json',
    'Endpoint policies - android manage settings - enable work profiles Policy B.json',
    'Endpoint policies - android manage settings - exchange settings Policy B.json',
    'Endpoint policies - android manage settings - restrictions Policy B.json',
    'Endpoint policies - android manage settings - system apps Policy B.json',
    'Endpoint policies - android manage settings - vpn settings Policy B.json',
    'Endpoint policies - comm mobile - common Policy B.json',
    'Endpoint policies - comm mobile - restrictions Policy B.json',
    'Endpoint policies - comm mobile - security Policy B.json',
    'Endpoint policies - comm mobile - wifi Policy C.json',
    'Endpoint policies - dev enroll settings Policy B.json',
    'Endpoint policies - dev manage settings Policy B.json',
    'Endpoint policies - ios - app mange Policy B.json',
    'Endpoint policies - ios - calendar Policy C.json',
    'Endpoint policies - ios - contacts Policy C.json',
    'Endpoint policies - ios - domain Policy C.json',
    'Endpoint policies - ios - exchange Policy C.json',
    'Endpoint policies - ios - http Policy B.json',
    'Endpoint policies - ios - kiosk Policy B.json',
    'Endpoint policies - ios - ldap Policy C.json',
    'Endpoint policies - ios - mail Policy C.json',
    'Endpoint policies - ios - restrictions Policy B.json',
    'Endpoint policies - ios - vpn Policy C.json',
    'Endpoint policies - KNOX Dev - apn settings Policy B.json',
    'Endpoint policies - KNOX Dev - app manage Policy B.json',
    'Endpoint policies - KNOX Dev - bluetooth Policy B.json',
    'Endpoint policies - KNOX Dev - dev inventory Policy B.json',
    'Endpoint policies - KNOX Dev - email settings Policy B.json',
    'Endpoint policies - KNOX Dev - exchange Policy B.json',
    'Endpoint policies - KNOX Dev - firewall Policy B.json',
    'Endpoint policies - KNOX Dev - kiosk Policy B.json',
    'Endpoint policies - KNOX Dev - password Policy B.json',
    'Endpoint policies - KNOX Dev - restrictions Policy B.json',
    'Endpoint policies - KNOX Dev - roaming Policy B.json',
    'Endpoint policies - KNOX Dev - security Policy B.json',
    'Endpoint policies - KNOX Dev - vpn restricts Policy B.json',
    'Endpoint policies - KNOX Dev - vpn settings Policy B.json',
    'Endpoint policies - KNOX Dev - wifi restrictions Policy B.json',
    'Endpoint policies - KNOX Dev - wifi settings Policy B.json',
    'Endpoint policies - KNOX work - configure apps Policy B.json',
    'Endpoint policies - KNOX work - container - app settings Policy B.json',
    'Endpoint policies - KNOX work - container - browser settings Policy B.json',
    'Endpoint policies - KNOX work - container - cert settings Policy B.json',
    'Endpoint policies - KNOX work - container - container acct settings Policy B.json',
    'Endpoint policies - KNOX work - container - email account settings Policy B.json',
    'Endpoint policies - KNOX work - container - email settings Policy B.json',
    'Endpoint policies - KNOX work - container - exchange settings Policy B.json',
    'Endpoint policies - KNOX work - container - firewall settings Policy B.json',
    'Endpoint policies - KNOX work - container - google apps Policy B.json',
    'Endpoint policies - KNOX work - container - passcode settings Policy B.json',
    'Endpoint policies - KNOX work - container - per app vpn Policy B.json',
    'Endpoint policies - KNOX work - container - restriction settings Policy B.json',
    'Endpoint policies - KNOX work - dev settings - cert validation Policy B.json',
    'Endpoint policies - KNOX work - dev settings - enable audit Policy B.json',
    'Endpoint policies - KNOX work - dev settings - per app vpn Policy B.json',
    'Endpoint policies - KNOX work - dev settings - revocation check Policy B.json',
    'Endpoint policies - KNOX work - dev settings - trusted cert Policy B.json',
    'Endpoint policies - KNOX work - enterpirse billing Policy B.json',
    'Endpoint policies - KNOX work - multi[ple enable settings Policy B.json',
    'Endpoint policies - KNOX work - vpn settings Policy B.json',
    'Endpoint policies - os and ios - cert profiles Policy C.json',
    'Endpoint policies - os and ios - vpn Policy C.json',
    'Endpoint policies - osx - app manage Policy B.json',
    'Endpoint policies - osx - local admin Policy B.json',
    'Endpoint policies - osx - open apps Policy C.json',
    'Endpoint policies - osx - open auth network mounts Policy C.json',
    'Endpoint policies - osx - open files Policy C.json',
    'Endpoint policies - osx - open network mounts Policy C.json',
    'Endpoint policies - osx - restrictions - apps Policy C.json',
    'Endpoint policies - osx - restrictions - media Policy B.json',
    'Endpoint policies - osx - restrictions - prefs Policy B.json',
    'Endpoint policies - osx - restrictions - restrict apps and prefs Policy B.json',
    'Endpoint policies - osx - security Policy B.json',
    'Endpoint policies - osx - shift key Policy B.json',
    'Endpoint policies - touchdown settings Policy B.json',
    # 'Third party integration - challenge policy Policy B.json',  #  policy enforcement
    'User security policies - oath otp Policy B.json',
    'User security policies - password settings Policy B.json',
    'User security policies - radius Policy B.json',
    'User security policies - self service Policy B.json',
    'User security policies - user acct settings Policy B.json'
])
def test_c28138_scenario_b_default(policy_fixture, test_file):
    policy_api = policy_fixture[0]

    settings = load_json_test_data_file(test_file)
    response = policy_api.create_policy(POLICY_B, settings)
    assert response.success(), f'Failed to create {POLICY_B}'

    keys = [key for key in settings]
    policy_settings = policy_api.get_policy_settings(keys)

    assert settings == policy_settings


@pytestrail.case('C28139')
@pytest.mark.parametrize('test_file', [
    'App policies - user settings -',
    'User security policies - password settings',
    # 'Authentication policies - zero trust',  # TODO Awaiting to be moved to Endpoint Team # policy enforcement
    'Endpoint policies - android manage settings - cert profiles',
    'Endpoint policies - android manage settings - device owner',
    'Endpoint policies - android manage settings - enable work profiles',
    'Endpoint policies - android manage settings - exchange settings',
    'Endpoint policies - android manage settings - restrictions',
    'Endpoint policies - android manage settings - system apps',
    'Endpoint policies - android manage settings - vpn settings',
    'Endpoint policies - comm mobile - common',
    'Endpoint policies - comm mobile - restrictions',
    'Endpoint policies - comm mobile - security',
    'Endpoint policies - dev enroll settings',
    'Endpoint policies - dev manage settings',
    'Endpoint policies - ios - app mange',
    'Endpoint policies - ios - http',
    'Endpoint policies - ios - kiosk',
    'Endpoint policies - ios - restrictions',
    'Endpoint policies - KNOX Dev - apn settings',
    'Endpoint policies - KNOX Dev - app manage',
    'Endpoint policies - KNOX Dev - bluetooth',
    'Endpoint policies - KNOX Dev - dev inventory',
    'Endpoint policies - KNOX Dev - email settings',
    'Endpoint policies - KNOX Dev - exchange',
    'Endpoint policies - KNOX Dev - firewall',
    'Endpoint policies - KNOX Dev - kiosk',
    'Endpoint policies - KNOX Dev - password',
    'Endpoint policies - KNOX Dev - restrictions',
    'Endpoint policies - KNOX Dev - roaming',
    'Endpoint policies - KNOX Dev - security',
    'Endpoint policies - KNOX Dev - vpn restricts',
    'Endpoint policies - KNOX Dev - vpn settings',
    'Endpoint policies - KNOX Dev - wifi restrictions',
    'Endpoint policies - KNOX Dev - wifi settings',
    'Endpoint policies - KNOX work - configure apps',
    'Endpoint policies - KNOX work - container - app settings',
    'Endpoint policies - KNOX work - container - browser settings',
    'Endpoint policies - KNOX work - container - cert settings',
    'Endpoint policies - KNOX work - container - container acct settings',
    'Endpoint policies - KNOX work - container - email account settings',
    'Endpoint policies - KNOX work - container - email settings',
    'Endpoint policies - KNOX work - container - exchange settings',
    'Endpoint policies - KNOX work - container - firewall settings',
    'Endpoint policies - KNOX work - container - google apps',
    'Endpoint policies - KNOX work - container - passcode settings',
    'Endpoint policies - KNOX work - container - per app vpn',
    'Endpoint policies - KNOX work - container - restriction settings',
    'Endpoint policies - KNOX work - dev settings - cert validation',
    'Endpoint policies - KNOX work - dev settings - enable audit',
    'Endpoint policies - KNOX work - dev settings - per app vpn',
    'Endpoint policies - KNOX work - dev settings - revocation check',
    'Endpoint policies - KNOX work - dev settings - trusted cert',
    'Endpoint policies - KNOX work - enterpirse billing',
    'Endpoint policies - KNOX work - multi[ple enable settings',
    'Endpoint policies - KNOX work - vpn settings',
    'Endpoint policies - osx - app manage',
    'Endpoint policies - osx - local admin',
    'Endpoint policies - osx - restrictions - media',
    'Endpoint policies - osx - restrictions - prefs',
    'Endpoint policies - osx - restrictions - restrict apps and prefs',
    'Endpoint policies - osx - security',
    'Endpoint policies - osx - shift key',
    'Endpoint policies - touchdown settings',
    'Third party integration - challenge policy',  #  policy enforcement
    'User security policies - oath otp',
    'User security policies - password settings',
    'User security policies - radius',
    'User security policies - self service',
    'User security policies - user acct settings'
])
def test_c28139_scenario_default_b_c(policy_fixture, test_file):
    policy_api = policy_fixture[0]

    policy_b = load_json_test_data_file(f'{test_file} Policy B.json')
    policy_c = load_json_test_data_file(f'{test_file} Policy C.json')
    result_b = policy_api.create_policy(POLICY_B, policy_b)
    result_c = policy_api.create_policy(POLICY_C, policy_c)
    assert result_b.success(), f'Failed to create {POLICY_B}'
    assert result_c.success(), f'Failed to create {POLICY_C}'

    keys = [key for key in policy_c]
    policy_settings = policy_api.get_policy_settings(keys)

    assert policy_c == policy_settings


@pytestrail.case('C28140')
@pytest.mark.pipeline
@pytest.mark.skip('Not implemented')
def test_c28140_scenario_default_b_c_applied_to_rolea():
    pass


@pytestrail.case('C28141')
@pytest.mark.pipeline
@pytest.mark.skip('Not implemented')
def test_c28141_scenario_default_b_applied_to_rolea_c():
    pass


@pytestrail.case('C28142')
@pytest.mark.pipeline
@pytest.mark.skip('Not implemented')
def test_c28142_scenario_default_b_c_applied_to_rolec():
    pass


@pytest.mark.slow
@pytest.mark.parametrize('test_file', [
    'App policies - user settings -',
    'User security policies - password settings',
    # 'Authentication policies - zero trust',  # TODO Awaiting to be moved to Endpoint Team # policy enforcement
    'Endpoint policies - android manage settings - cert profiles',
    'Endpoint policies - android manage settings - device owner',
    'Endpoint policies - android manage settings - enable work profiles',
    'Endpoint policies - android manage settings - exchange settings',
    'Endpoint policies - android manage settings - restrictions',
    'Endpoint policies - android manage settings - system apps',
    'Endpoint policies - android manage settings - vpn settings',
    'Endpoint policies - comm mobile - common',
    'Endpoint policies - comm mobile - restrictions',
    'Endpoint policies - comm mobile - security',
    'Endpoint policies - dev enroll settings',
    'Endpoint policies - dev manage settings',
    'Endpoint policies - ios - app mange',
    'Endpoint policies - ios - http',
    'Endpoint policies - ios - kiosk',
    'Endpoint policies - ios - restrictions',
    'Endpoint policies - KNOX Dev - apn settings',
    'Endpoint policies - KNOX Dev - app manage',
    'Endpoint policies - KNOX Dev - bluetooth',
    'Endpoint policies - KNOX Dev - dev inventory',
    'Endpoint policies - KNOX Dev - email settings',
    'Endpoint policies - KNOX Dev - exchange',
    'Endpoint policies - KNOX Dev - firewall',
    'Endpoint policies - KNOX Dev - kiosk',
    'Endpoint policies - KNOX Dev - password',
    'Endpoint policies - KNOX Dev - restrictions',
    'Endpoint policies - KNOX Dev - roaming',
    'Endpoint policies - KNOX Dev - security',
    'Endpoint policies - KNOX Dev - vpn restricts',
    'Endpoint policies - KNOX Dev - vpn settings',
    'Endpoint policies - KNOX Dev - wifi restrictions',
    'Endpoint policies - KNOX Dev - wifi settings',
    'Endpoint policies - KNOX work - configure apps',
    'Endpoint policies - KNOX work - container - app settings',
    'Endpoint policies - KNOX work - container - browser settings',
    'Endpoint policies - KNOX work - container - cert settings',
    'Endpoint policies - KNOX work - container - container acct settings',
    'Endpoint policies - KNOX work - container - email account settings',
    'Endpoint policies - KNOX work - container - email settings',
    'Endpoint policies - KNOX work - container - exchange settings',
    'Endpoint policies - KNOX work - container - firewall settings',
    'Endpoint policies - KNOX work - container - google apps',
    'Endpoint policies - KNOX work - container - passcode settings',
    'Endpoint policies - KNOX work - container - per app vpn',
    'Endpoint policies - KNOX work - container - restriction settings',
    'Endpoint policies - KNOX work - dev settings - cert validation',
    'Endpoint policies - KNOX work - dev settings - enable audit',
    'Endpoint policies - KNOX work - dev settings - per app vpn',
    'Endpoint policies - KNOX work - dev settings - revocation check',
    'Endpoint policies - KNOX work - dev settings - trusted cert',
    'Endpoint policies - KNOX work - enterpirse billing',
    'Endpoint policies - KNOX work - multi[ple enable settings',
    'Endpoint policies - KNOX work - vpn settings',
    'Endpoint policies - osx - app manage',
    'Endpoint policies - osx - local admin',
    'Endpoint policies - osx - restrictions - media',
    'Endpoint policies - osx - restrictions - prefs',
    'Endpoint policies - osx - restrictions - restrict apps and prefs',
    'Endpoint policies - osx - security',
    'Endpoint policies - osx - shift key',
    'Endpoint policies - touchdown settings',
    'Third party integration - challenge policy',  #  policy enforcement
    'User security policies - oath otp',
    'User security policies - password settings',
    'User security policies - radius',
    'User security policies - self service',
    'User security policies - user acct settings'
])
def test_default_b_c(policy_fixture, test_file):
    policy_api = policy_fixture[0]

    policy_b = load_json_test_data_file(f'{test_file} Policy B.json')
    policy_c = load_json_test_data_file(f'{test_file} Policy C.json')
    result_b = policy_api.create_policy(POLICY_B, policy_b)
    result_c = policy_api.create_policy(POLICY_C, policy_c)
    assert result_b.success(), f'Failed to create {POLICY_B}'
    assert result_c.success(), f'Failed to create {POLICY_C}'

    keys = [key for key in policy_c]
    policy_settings = policy_api.get_policy_settings(keys)

    assert policy_c == policy_settings
