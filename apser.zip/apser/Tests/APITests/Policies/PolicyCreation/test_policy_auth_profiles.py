import pytest
from idaptive_testrail.plugin import pytestrail
from Fixtures.sessions_and_helpers import *
from idaptive_automation.api_payloads import AuthenticationProfile


@pytestrail.case('C40295')
@pytest.mark.pipeline
def test_c40295_auth_profile_single_matching_mechanism_negative_test(app_helpers):
    profile_helper = app_helpers['profile_helper']
    response = profile_helper.create_profile(AuthenticationProfile(f'Profile {str(uuid.uuid4())[:8]}')
                                             .with_challenges(["UP", "UP"])
                                             .with_duration_in_minutes(5)
                                             .to_payload(), assert_success=False)
    assert not response.success()
    assert response.message() == "Invalid combination - both challenges match and have only one mechanism - remove mechanism from 2nd challenge"


@pytestrail.case('C119126')
@pytest.mark.pipeline
def test_c119126_auth_profile_invalid_combination_negative_test(app_helpers):
    profile_helper = app_helpers['profile_helper']
    response = profile_helper.create_profile(AuthenticationProfile(f'Profile {str(uuid.uuid4())[:8]}')
                                             .with_challenges(["UP", "UP,SQ"])
                                             .with_duration_in_minutes(5)
                                             .to_payload(), assert_success=False)
    assert not response.success()
    assert response.message() == "Invalid combination - 1st challenge has only one mechanism which is also in 2nd challenge - remove from 2nd challenge"
