# from idaptive_automation.ui_automation.pages.userportal.add_web_app_dialog import AddWebAppDialog
# from idaptive_automation.ui_automation.pages.userportal.app_catalog_dialog import AppCatalogDialog
# from idaptive_testrail.plugin import pytestrail
# import pytest
# from idaptive_automation.ui_automation import UserPortalPage, ConfigurableAppSettingsPage
# from Steps.app_steps import deploy_app_by_name
# from Fixtures.sessions_and_helpers import *
# from Helpers.test_data_helper import load_json_test_data_file
# from Steps.navigate_steps import Login
#
# #TODO This seems to require IBE stuff to get up and running
# @pytestrail.case('C28091')
# @pytest.mark.pipeline
# def test_c28091_user_deployed_app_launch_happy_path(app_helpers, driver):
#     """ End-user may deploy an application when policy allows """
#     app_helper = app_helpers['app_helper']
#     user_helper = app_helpers['user_helper']
#     role_helper = app_helpers['role_helper']
#     policy_helper = app_helpers['policy_helper']
#     tenant_helper = app_helpers['tenant_helper']
#     alias = tenant_helper.get_aliases_for_tenant()[0]
#     app_details = load_json_test_data_file("Costco.json", sub_dir="Applications")
#
#     app_name = app_details['name']
#     deploy_app_by_name(app_helper, app_name)
#
#     policy = {
#         "/Core/Security/CDS/Applications/AllowSelfService": True,
#         "/Core/Security/CDS/Applications/EnableWSTrustChallenges": True
#     }
#
#     role_id = role_helper.create_role_if_not_exists(f'Allow self service role')
#     policy_helper.create_policy(f'Automated test policy - Allow self service role',
#                                 policy, link_type='Role', params=[role_id])
#
#     email_address = 'test@test.com'
#     payload = CloudUser(alias, f'Self-Service-{uuid.uuid4()}').with_email(email_address).to_payload()
#     payload['SendEmailInvite'] = False
#     response = user_helper.create_cloud_user(payload)
#     user_id = payload['Uuid'] = response.result()
#     role_helper.add_users_to_role(role_id, [user_id])
#
#     Login(driver, tenant_helper.api_session.base_url).to_user_portal(payload['Name'], payload['Password'])
#     UserPortalPage(driver).wait_for_page_to_load()
#     UserPortalPage(driver).click_add_apps_button()
#
#     AppCatalogDialog(driver).search_app_input(app_name=app_name)
#     AppCatalogDialog(driver).click_first_add_apps_button()
#     AddWebAppDialog(driver).wait_for_page_to_load()
#     AddWebAppDialog(driver).press_yes()
#
#     AppCatalogDialog(driver).close_app_catalog_dialog()
#
#     app_settings = ConfigurableAppSettingsPage(driver)
#     app_settings.set_username('test_user')
#     app_settings.set_password('test_pass')
#
#     app_settings.click_save_button()
#
#     handles = UserPortalPage(driver).get_window_handles()
#     UserPortalPage(driver).launch_app_up(app_name=app_name)
#     UserPortalPage(driver).switch_to_new_tab_after_app_launch(handles)
#
#     app_url = UserPortalPage(driver).get_app_url()
#     assert app_url == app_details['url'], f'valid url not found, expected {app_details["url"]}, found {app_url}'
