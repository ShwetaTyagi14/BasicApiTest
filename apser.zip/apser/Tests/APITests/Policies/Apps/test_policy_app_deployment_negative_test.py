from idaptive_automation.ui_automation.pages.userportal.app_catalog_dialog import AppCatalogDialog
from idaptive_testrail.plugin import pytestrail
import pytest
from Steps.navigate_steps import Login
from idaptive_automation.api_payloads import CloudUser
from idaptive_automation.ui_automation import UserPortalPage


@pytestrail.case('C31690')
@pytest.mark.pipeline
def test_c31690_user_deployed_app_launch_negative_test(driver, app_helpers):
    """ End-user may not deploy an application when policy prohibits """
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    policy_api = app_helpers['policy_helper']
    alias = app_helpers['alias']
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']

    policy = {
        "/Core/Security/CDS/Applications/AllowSelfService": False,
        "/Core/Security/CDS/Applications/EnableWSTrustChallenges": True
    }

    role_id = role_api.create_role_if_not_exists(f'Allow self service role {test_id}')
    policy_api.create_policy(f'Automated test policy - Allow self service role {test_id}',
                             policy, link_type='Role', params=[role_id])

    email_address = 'test@test.test'
    payload = CloudUser(alias, f'Allow-Self-Service-user-{test_id}').with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_api.create_cloud_user(payload)
    user_id = payload['Uuid'] = response.result()
    role_api.add_users_to_role(role_id, [user_id])
    Login(driver, tenant_info['base_url']).to_user_portal(payload['Name'], payload['Password'])
    UserPortalPage(driver).wait_for_page_to_load()
    UserPortalPage(driver).click_add_apps_button()

    expected_text = "No Recommended apps available at this time"
    actual_text = AppCatalogDialog(driver).validate_apps_recommended_message()
    assert actual_text == expected_text, f'Incorrect message, found{actual_text}, expected{expected_text}'
