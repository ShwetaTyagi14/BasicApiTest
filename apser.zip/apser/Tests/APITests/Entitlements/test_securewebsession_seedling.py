import pytest
from idaptive_testrail.plugin import pytestrail
from Steps.app_steps import *


@pytestrail.case('C178582')
def test_c178582_securewebsession_pas_entitlement(app_helpers, master_session):
    tenant_info = app_helpers['tenant_info']
    user_helper = app_helpers['user_helper']
    app_helper = app_helpers['app_helper']
    role_helper = app_helpers['role_helper']
    master_tenant_helper = TenantApiHelper(master_session)

    tenant_helper = app_helpers['tenant_helper']
    top_alias = tenant_helper.get_aliases_for_tenant()[0]
    service_username = f"sws-integration-user$@{top_alias}"

    # Make sure CyberArk Remote Access (Secure Web Session) Entitlement is disabled
    master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                   entitlement_id='78C106E2-2295-4D29-875F-8DE79377D5EC', enable=False)

    # validate CyberArk Secure Web Session app and service user do not exist as the prerequisite of the test
    assert (user_helper.wait_for_user_to_be_deleted(service_username))
    assert wait_for_app_to_be_deleted(app_helper, 'CyberArk Secure Web Session Portal'), \
        'Secure Web Session application should have been deleted'

    # enable CyberArk Remote Access (Secure Web Sessio) Entitlement
    master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                   entitlement_id='78C106E2-2295-4D29-875F-8DE79377D5EC', enable=True)

    # validate the service user is created when entitlement is enabled
    assert (user_helper.wait_for_user_to_exist(service_username))

    # validate the roles are seeded
    assert role_helper.get_role_info('securewebsessionauditor', assert_success=True)
    assert role_helper.get_role_info('securewebsessionadmin', assert_success=True)

    # validate CyberArk Remote Access (Secure Web Session) app does exist when entitlement is enabled
    assert get_service_name_from_app_name(app_helper, 'CyberArk Secure Web Session Portal') == "SWS_Portal_Bridge", \
        'Secure Web Session app was not deployed but should have been'

    # disabled CyberArk Remote Access (Secure Web Session) Entitlement
    master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                   entitlement_id='78C106E2-2295-4D29-875F-8DE79377D5EC', enable=False)

    # validate the service user and app are removed when entitlement is disabled
    assert (user_helper.wait_for_user_to_be_deleted(service_username))
    assert wait_for_app_to_be_deleted(app_helper, 'CyberArk Secure Web Session Portal'), \
        'Secure Web Session application was not removed'
    # validate the roles are removed
    assert role_helper.get_role_info('securewebsessionauditor', assert_success=False)
    assert role_helper.get_role_info('securewebsessionadmin', assert_success=False)
