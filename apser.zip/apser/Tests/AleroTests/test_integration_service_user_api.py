import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_helpers import UserMgmt, RoleApi
from idaptive_automation.api_payloads.payloads.users_to_roles_in_alero import UsersToRolesAlero
from Fixtures.sessions_and_helpers import oauth_session_sws
from Fixtures.sessions_and_helpers import oauth_session_alero
from Helpers.test_data_helper import load_json_test_data_file
from idaptive_automation.api_helpers import RedrockApi
from idaptive_automation.api_payloads.payloads.red_rock import RedRock


@pytestrail.case('C163267')
def test_c163267_alero_oauth_token(oauth_session_alero):
    app_helpers, alero_oauth_session = oauth_session_alero
    cloud_session = app_helpers['cloud_session']
    role_helper = app_helpers['role_helper']

    role_exists = role_helper.get_role_info_by_name(role_name=f'CyberArk Remote Access Admin Users')
    assert role_exists['ID'] == "aleroadminusers"
    new_name = role_exists['Name']
    description = role_exists['Description']
    name = role_exists['ID']
    payload = UsersToRolesAlero(NewName=new_name, Description=description, Name=name,
                                Users=cloud_session.user_id).to_payload()
    oauth_api = RoleApi(alero_oauth_session)
    assert oauth_api.add_users_and_groups_to_alero_roles(payload)


@pytestrail.case('C178798')
def test_c178798_sws_integration_user_can_use_api_with_oauth_token(oauth_session_sws):
    app_helpers, sws_oauth_session = oauth_session_sws
    cloud_session = app_helpers['cloud_session']
    role_helper = app_helpers['role_helper']

    script = load_json_test_data_file("sws_redrock_app_script.json", sub_dir="Applications")['Script']
    payload = RedRock(script=script).to_payload()
    response = RedrockApi(sws_oauth_session).execute_redrock_query(payload)
    assert response

    role_exists = role_helper.get_role_info_by_name(role_name=f'SWS Admin')
    assert role_exists['ID'] == "securewebsessionadmin"
    new_name = role_exists['Name']
    description = role_exists['Description']
    name = role_exists['ID']
    payload = UsersToRolesAlero(NewName=new_name, Description=description, Name=name, Users=cloud_session.user_id).to_payload()
    oauth_api = RoleApi(sws_oauth_session)
    assert oauth_api.add_users_and_groups_to_alero_roles(payload)
