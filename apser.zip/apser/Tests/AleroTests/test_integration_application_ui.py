import pytest
import sys
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import PortalSwitcherPopout
from idaptive_automation.ui_automation import AppDetailsPage, WebAppsPage
from Steps.navigate_steps import Navigate, Login
from idaptive_automation.api_helpers.helpers.app_helper import AppHelper
from Helpers.test_data_helper import load_json_test_data_file
from Steps.user_steps import update_application_de_alero
from Fixtures.tenant_key_fixtures import set_alero_entitlement
from idaptive_automation.api_payloads import CloudUser
from idaptive_automation.ui_automation.pages.adminportal.ap_user_profile_menu import APUserProfileMenu


@pytestrail.case('C150002')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c150002_alero_ui_portal_switcher(app_helpers, lcm_helpers, driver_admin, set_alero_entitlement):

    app_api = lcm_helpers['app_helper']
    tenant_info = lcm_helpers['app_helper'].api_session

    role_helper = app_helpers['role_helper']
    user_helper = app_helpers['user_helper']
    cloud_session = app_helpers['cloud_session']

    user_id = user_helper.get_user_info(cloud_session.username)['Entities'][0]['Key']
    alero_admin_role_id = role_helper.get_role_info_by_name("CyberArk Remote Access Admin Users")['ID']
    role_helper.add_users_to_role(alero_admin_role_id, [user_id])

    app_id = app_api.get_app_key_from_app_name("CyberArk Remote Access Portal")
    issuer = f"{tenant_info.base_url}/{app_id}"
    signinurl = f"{tenant_info.base_url}/applogin/appKey/{app_id}/customerId/{tenant_info.tenant_id}"
    sp_xml = load_json_test_data_file("alero_xml.json", sub_dir="Applications")['xml']
    update_application_de_alero(app_api, issuer, app_id, signinurl, sp_xml)

    portal_switch = PortalSwitcherPopout(driver_admin)
    portal_switch.refresh_page()
    options = portal_switch.get_switcher_options()
    assert "Remote Access" in options, "Alero not available, ensure Alero Entitlement is enabled on this tenant"

    portal_switch.switch_to_user_portal()
    options = portal_switch.get_switcher_options()
    assert "Remote Access" in options, "Alero failed from User Portal"

    alero_portal_launch_url = portal_switch.get_alero_portal_launch_url()
    assert alero_portal_launch_url == f"{tenant_info.base_url}/uprest/HandleAppClick?appkey={app_id}",\
        "Alero site launch URL is not correct"

    identity_portal_location_current = driver_admin.current_url
    portal_switch.switch_to_alero_portal()
    alero_portal_url = portal_switch.get_alero_tab_current_url()
    assert alero_portal_url is not None, "Alero site url cannot be None"
    assert alero_portal_url != identity_portal_location_current, "Browser did not visit the Alero site"
    assert alero_portal_url in sp_xml, "Alero site did not launch correctly"


@pytestrail.case('C168250')
def test_c168250_linked_app_of_aleroportal_app_should_be_read_only(driver_admin, app_helpers, set_alero_entitlement):
    app_api = app_helpers['app_helper']
    tenant_info = app_helpers['app_helper'].api_session
    cyberark_app_name = "CyberArk Remote Access Portal"
    app_id = app_api.get_app_key_from_app_name(cyberark_app_name)
    payload = load_json_test_data_file("linked_app_payload.json", sub_dir="Applications")
    payload['_RowKey'] = app_id
    AppHelper(tenant_info).update_application_de(payload=payload)
    AppHelper(tenant_info).get_application(row_key=app_id)
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.search_for_app(cyberark_app_name)
    web_apps_page.click_specific_app(cyberark_app_name)
    app_details_page = AppDetailsPage(driver_admin)
    app_details_page.click_linked_applications_tab()
    app_details_page.validate_linked_app_window()
    assert app_details_page.validate_input_text_is_read_only('linked_application_settings_url')
    app_details_page.click_description_tab()
    assert app_details_page.validate_input_text_is_read_only('application_name_field')


@pytestrail.case('C168249')
def test_c168249_aleroportal_app_name_should_be_read_only(driver_admin, set_alero_entitlement):
    cyberark_app_name = "CyberArk Remote Access Portal"
    Navigate(driver_admin).to_web_app_tab()
    web_apps_page = WebAppsPage(driver_admin)
    web_apps_page.search_for_app(cyberark_app_name)
    web_apps_page.click_specific_app(cyberark_app_name)
    app_details_page = AppDetailsPage(driver_admin)
    app_details_page.open_settings_tab()
    assert app_details_page.validate_input_text_is_read_only('application_name_field')


