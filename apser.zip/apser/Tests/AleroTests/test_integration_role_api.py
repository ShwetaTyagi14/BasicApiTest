import pytest
import sys
import uuid
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_helpers import RedrockApi, RoleApi, TenantApiHelper
from idaptive_automation.api_payloads.payloads.users_to_roles_in_alero import UsersToRolesAlero
from idaptive_automation.api_payloads.payloads.red_rock import RedRock
from Helpers.test_data_helper import load_json_test_data_file
from Fixtures.tenant_key_fixtures import set_alero_entitlement


@pytestrail.case('C163440')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c163440_alero_add_users_to_role(lcm_helpers, set_alero_entitlement):
    role_helper = lcm_helpers['role_helper']
    tenant_info = lcm_helpers['app_helper'].api_session
    domain_worker = lcm_helpers['active_directory_helper']
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, "asdf1122!!@")
    ad_user = f"{base_name}user1"
    email_suffix = domain_worker.email_suffix
    object_guid = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'objectGUID')
    object_guid = str(object_guid)[1:-1]

    role_exists = role_helper.get_role_info_by_name(role_name=f'CyberArk Remote Access Admin Users')
    assert role_exists['ID'] == "aleroadminusers"
    new_name = role_exists['Name']
    description = role_exists['Description']
    name = role_exists['ID']
    payload = UsersToRolesAlero(NewName=new_name, Description=description, Name=name, Users=object_guid).to_payload()
    RoleApi(tenant_info).add_users_and_groups_to_alero_roles(payload)
    role_info = role_helper.get_role_info(name)
    assert f'u={f"{ad_user}@{email_suffix}"}' in role_info.result()['Principals']


@pytestrail.case('C163444')
def test_c163444_redrock_query(app_helpers, set_alero_entitlement):
    cloud_session = app_helpers['cloud_session']
    script = load_json_test_data_file("alero_redrock_script.json", sub_dir="Applications")['Script']
    payload = RedRock(script=script).to_payload()
    response = RedrockApi(cloud_session).execute_redrock_query(payload)
    assert 'aleroadminusers' in [entity['Entities'][00]['Key'] for entity in response.response['Result']['Results']]
    assert 'alerousers' in [entity['Entities'][00]['Key'] for entity in response.response['Result']['Results']]


@pytestrail.case('C163441')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c163441_remove_users_and_groups_from_alero_roles(lcm_helpers, set_alero_entitlement):
    role_helper = lcm_helpers['role_helper']
    tenant_info = lcm_helpers['app_helper'].api_session
    domain_worker = lcm_helpers['active_directory_helper']
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, "asdf1122!!@")
    ad_user = f"{base_name}user1"
    email_suffix = domain_worker.email_suffix
    object_guid = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'objectGUID')
    object_guid = str(object_guid)[1:-1]

    role_exists = role_helper.get_role_info_by_name(role_name=f'CyberArk Remote Access Admin Users')
    assert role_exists['ID'] == "aleroadminusers"
    new_name = role_exists['Name']
    description = role_exists['Description']
    name = role_exists['ID']
    payload = UsersToRolesAlero(NewName=new_name, Description=description, Name=name, Users=object_guid).to_payload()
    RoleApi(tenant_info).add_users_and_groups_to_alero_roles(payload)
    RoleApi(tenant_info).remove_users_and_groups_from_alero_roles(payload)
    role_info = role_helper.get_role_info(name)
    assert f'u={f"{ad_user}@{email_suffix}"}' not in role_info.result()['Principals']


@pytestrail.case('C150001')
@pytest.mark.skipif(any(arg == '--pipeline_skip' for arg in sys.argv), reason="This test should not be run in the Pipeline")
def test_c150001_alero_role_protection(app_helpers, set_alero_entitlement):
    role_helper = app_helpers['role_helper']

    # assert Alero Roles Can Not Be Created
    another_alero_users_role = role_helper.create_role(role_name='CyberArk Remote Access Users',
                                                       description="CyberArk Remote Access Users",
                                                       assert_success=False)
    assert not(another_alero_users_role.success())

    another_alero_admin_role = role_helper.create_role(role_name='CyberArk Remote Access Admin Users',
                                                       description="CyberArk Remote Access Admin Users",
                                                       assert_success=False)
    assert not(another_alero_admin_role.success())

    # assert Alero users roles display name cannot be modified
    update_role_display_name_response = role_helper.update_role_metadata('alerousers',
                                                                         'Alero_Users',
                                                                         'desc',
                                                                         assert_success=False)
    assert not update_role_display_name_response.success()
    assert 'Cannot create or update a role with reserved role name' in update_role_display_name_response.message()

    # assert Alero admin users roles display name cannot be modified
    update_role_display_name_response = role_helper.update_role_metadata('aleroadminusers',
                                                                         'Alero_Admin_Users',
                                                                         'desc',
                                                                         assert_success=False)
    assert not update_role_display_name_response.success()
    assert 'Cannot create or update a role with reserved role name' in update_role_display_name_response.message()

    # TODO: The 2 lines will need to be uncommented in phase 2 of Alero Integration
    # assert roles can not be deleted
    # assert not(role_helper.delete_role(role_id=roleid1) is None)
    # assert not(role_helper.delete_role(role_id=roleid2) is None)


@pytestrail.case('C178450')
def test_c178450_alero_admin_role_delete(app_helpers, set_alero_entitlement):
    role_helper = app_helpers['role_helper']

    # assert alero roles cannot be deleted
    delete_alero_admin_role = role_helper.delete_role(role_id="aleroadminusers",
                                                      assert_success=False,
                                                      remove_users=True)
    assert not(delete_alero_admin_role.success())


@pytestrail.case('C178452')
def test_c178452_alero_user_role_delete(app_helpers, set_alero_entitlement):
    role_helper = app_helpers['role_helper']

    # assert alero roles cannot be deleted
    delete_alero_user_role = role_helper.delete_role(role_id="alerousers",
                                                      assert_success=False,
                                                      remove_users=True)
    assert not(delete_alero_user_role.success())