from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import RolesTabPage, RolesAddEditWindow
from Steps.navigate_steps import Navigate
from Fixtures.tenant_key_fixtures import set_alero_entitlement


@pytestrail.case('C163207')
def test_c163207_add_user_to_alero_users_role(driver_admin, app_helpers, set_alero_entitlement):
    tenant_helper = app_helpers['tenant_helper']
    user_api = app_helpers['user_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]
    username = user_api.create_invited_user(alias, app_helpers['test_id'])['Name']
    user_api.wait_for_user_invited_status(username, wait_time=45)
    Navigate(driver_admin).to_roles_tab()
    roles_page = RolesTabPage(driver_admin)
    roles_page.wait_for_page_to_load()
    roles_page.open_role_detail_window_for_role("CyberArk Remote Access Users")
    roles_add_edit_window = RolesAddEditWindow(driver_admin)
    roles_add_edit_window.wait_for_page_to_load()
    roles_add_edit_window.select_members_tab()
    add_members_dialog = roles_add_edit_window.open_add_members_window()
    add_members_dialog.search_for_user(username)
    add_members_dialog.select_user_checkbox()
    add_members_dialog.press_add_button()
    roles_add_edit_window.press_save_button()
    roles_add_edit_window.press_cancel_button()
    roles_page.wait_for_page_to_load()
    roles_page.open_role_detail_window_for_role("CyberArk Remote Access Users")
    roles_add_edit_window = RolesAddEditWindow(driver_admin)
    roles_add_edit_window.wait_for_page_to_load()
    roles_add_edit_window.select_members_tab()
    user_info = roles_add_edit_window.get_displayed_members(username)
    assert username in user_info[0].text, f"{username} expected to be in Members list, but isn't"


@pytestrail.case('C168228')
def test_c168228_alero_users_role_is_read_only(driver_admin, set_alero_entitlement):
    Navigate(driver_admin).to_roles_tab()
    roles_page = RolesTabPage(driver_admin)
    roles_page.wait_for_page_to_load()
    roles_page.open_role_detail_window_for_role("CyberArk Remote Access Users")
    roles_add_edit_window = RolesAddEditWindow(driver_admin)
    roles_add_edit_window.wait_for_page_to_load()
    assert roles_add_edit_window.validate_name_input_text_is_read_only("name")
    assert roles_add_edit_window.validate_name_input_text_is_read_only("description_field")
    roles_add_edit_window.select_members_tab()
    value = roles_add_edit_window.validate_add_button_is_read_only()
    assert value is not True, f"Add button IS NOT selectable, but should be {value}"
    roles_add_edit_window.select_admin_rights_tab()
    value = roles_add_edit_window.validate_add_button_is_read_only()
    assert value is True, f"Add button IS selectable, but should not be {value}"
    roles_add_edit_window.select_assigned_apps_tab()
    value = roles_add_edit_window.validate_add_button_is_read_only()
    assert value is True, f"Add button IS selectable, but should not be {value}"


@pytestrail.case('C168229')
def test_c168229_alero_admin_role_is_read_only(driver_admin, set_alero_entitlement):
    roles_page = Navigate(driver_admin).to_roles_tab()
    roles_page.wait_for_page_to_load()
    roles_page.open_role_detail_window_for_role("CyberArk Remote Access Admin Users")
    roles_add_edit_window = RolesAddEditWindow(driver_admin)
    roles_add_edit_window.wait_for_page_to_load()
    assert roles_add_edit_window.validate_name_input_text_is_read_only("name")
    assert roles_add_edit_window.validate_name_input_text_is_read_only("description_field")
    roles_add_edit_window.select_members_tab()
    value = roles_add_edit_window.validate_add_button_is_read_only()
    assert value is True, f"Add button IS selectable, but should not be {value}"
    roles_add_edit_window.select_admin_rights_tab()
    value = roles_add_edit_window.validate_add_button_is_read_only()
    assert value is True, f"Add button IS selectable, but should not be {value}"
    roles_add_edit_window.select_assigned_apps_tab()
    value = roles_add_edit_window.validate_add_button_is_read_only()
    assert value is True, f"Add button IS selectable, but should not be {value}"
