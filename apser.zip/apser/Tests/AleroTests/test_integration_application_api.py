import pytest
import uuid
from idaptive_testrail.plugin import pytestrail
from Helpers.test_data_helper import load_json_test_data_file
from idaptive_automation.api_helpers import UprestHelper
from Steps.user_steps import verify_alero_response_xml, update_application_de_alero
from Steps.app_steps import get_service_name_from_app_name
from Fixtures.tenant_key_fixtures import set_alero_entitlement


@pytestrail.case('C163450')
def test_c163450_verify_attributes_in_alero_app(lcm_helpers, set_alero_entitlement):
    app_api = lcm_helpers['app_helper']
    user_api = lcm_helpers['user_helper']
    role_helper = lcm_helpers['role_helper']
    tenant_info = lcm_helpers['app_helper'].api_session
    domain_worker = lcm_helpers['active_directory_helper']
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, "asdf1122!!@")
    ad_user = f"{base_name}user1"
    email_suffix = domain_worker.email_suffix
    object_guid = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'objectGUID')
    distinguished_name = object_guid.entry.distinguishedName.value
    object_guid = str(object_guid)[1:-1]
    object_sid = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'objectSid').value
    cn = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'cn').value
    sn = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'sn').value
    given_name = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'givenName').value

    app_id = app_api.get_app_key_from_app_name("CyberArk Remote Access Portal")
    issuer = f"{tenant_info.base_url}/{app_id}"
    signinurl = f"{tenant_info.base_url}/applogin/appKey/{app_id}/customerId/{tenant_info.tenant_id}"
    sp_xml = load_json_test_data_file("alero_xml.json", sub_dir="Applications")['xml']
    update_application_de_alero(app_api, issuer, app_id, signinurl, sp_xml)
    role_id = role_helper.get_role_info_by_name("CyberArk Remote Access Users")['ID']
    role_helper.add_users_to_role(role_id, [object_guid])
    ad_user_session = user_api.authenticate_as_user(ad_user, 'asdf1122!!@')
    uprest_helper = UprestHelper(ad_user_session)
    form = uprest_helper.handle_app_click(app_id)
    saml_response = form.root['body'][0]['form'][0]['input'][0]['value']
    decrypted = uprest_helper.get_base64decode(saml_response)
    verify_alero_response_xml(decrypted, ad_user, email_suffix, object_guid, object_sid, distinguished_name, cn, sn,
                              given_name)


@pytestrail.case('C163451')
def test_c163451_preview_attributes_in_alero_app(lcm_helpers, set_alero_entitlement):
    app_api = lcm_helpers['app_helper']
    tenant_info = lcm_helpers['app_helper'].api_session
    domain_worker = lcm_helpers['active_directory_helper']
    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(base_name, "asdf1122!!@")
    ad_user = f"{base_name}user1"
    email_suffix = domain_worker.email_suffix
    object_guid = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'objectGUID')
    distinguished_name = object_guid.entry.distinguishedName.value
    object_guid = str(object_guid)[1:-1]
    object_sid = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'objectSid').value
    cn = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'cn').value
    sn = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'sn').value
    given_name = domain_worker.get_ad_user_attribute(ad_user, f"ou={base_name}", 'givenName').value

    app_id = app_api.get_app_key_from_app_name("CyberArk Remote Access Portal")
    issuer = f"{tenant_info.base_url}/{app_id}"
    signinurl = f"{tenant_info.base_url}/applogin/appKey/{app_id}/customerId/{tenant_info.tenant_id}"
    sp_xml = load_json_test_data_file("alero_xml.json", sub_dir="Applications")['xml']
    update_application_de_alero(app_api, issuer, app_id, signinurl, sp_xml)

    xml_doc = app_api.get_preview_saml_response(app_id, ad_user)
    verify_alero_response_xml(xml_doc, ad_user, email_suffix, object_guid, object_sid, distinguished_name, cn, sn,
                              given_name)


@pytestrail.case('C178476')
def test_c178476_get_alero_app_id_by_fixed_service_name_should_succeed(app_helpers, set_alero_entitlement):
    app_api = app_helpers['app_helper']

    app_name = 'CyberArk Remote Access Portal'
    expected_id = app_api.get_app_key_from_app_name(app_name)
    expected_service_name = 'Alero_Portal_Bridge'
    got_id = app_api.get_application_id_by_service_name(expected_service_name)
    got_service_name = get_service_name_from_app_name(app_api, app_name)

    assert expected_id == got_id
    assert expected_service_name == got_service_name
