from idaptive_testrail.plugin import pytestrail
from idaptive_automation.ui_automation import UsersTab, UserAddEditWindow, AdminPortalPage, AppsPage, AppDetailsPage
from idaptive_testrail.plugin import pytestrail
from Fixtures.tenant_key_fixtures import *
from Steps.navigate_steps import Login
from Fixtures.tenant_key_fixtures import set_alero_entitlement


@pytestrail.case('C150004')
@pytest.mark.pipeline
def test_c150004_alero_ui_deep_dive(driver, app_helpers, set_alero_entitlement):
    tenant_info = app_helpers['tenant_info']
    Login(driver, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
    admin_portal = AdminPortalPage(driver)
    apps_page = AppsPage(driver)
    app_details = AppDetailsPage(driver)
    users_tab = UsersTab(driver)
    user_aew = UserAddEditWindow(driver)

    admin_portal.select_users()
    users_tab.select_all_users_set()

    tenant_helper = app_helpers['tenant_helper']
    top_alias = tenant_helper.get_aliases_for_tenant()[0]
    user_login_name = f"alero-integration-user$@{top_alias}"
    users_tab.open_user_detail_window_for_user(user_login_name)
    assert user_aew.is_service_user_checked()

    admin_portal.select_web_apps()
    apps_page.search_for_app('CyberArk Remote Access Portal')
    apps_page.select_web_app('CyberArk Remote Access Portal')
    app_details.click_on_permissions_tab()
    assert app_details.verify_permission_name('alerousers')
    assert app_details.verify_permission_name('aleroadminusers')
    assert app_details.verify_permission_name('sysadmin')
