from idaptive_automation.ui_automation.idaptive_driver import Driver
from idaptive_automation.mongo_dal import AutomationMongoClient, EnvironmentCredentials
from bson.binary import Binary
from datetime import datetime
import json


class AppServicesDriver(Driver):
    def __init__(self, options, profile=None, base_url=None,
                 ibe_url=None, case_number=None, screenshots=False):
        self.screenshots = screenshots
        self.case_number = case_number
        super().__init__(options, profile=profile, base_url=base_url, ibe_url=ibe_url)

    def get_screenshot_as_png(self):
        if not self.screenshots:
            return
        try:
            png = super().get_screenshot_as_png()
            encoded = Binary(png)
            timestamp = str(datetime.now())
            print(f'\nRecording screenshot at {timestamp}\n')
            query = {
                'caseNumber': self.case_number,
                'time': timestamp,
                'png': encoded
            }
            with AutomationMongoClient(EnvironmentCredentials(), 'apps').connect() as client:
                client.insert_one('screenshots', query)
            del query['png']
            return json.dumps({'caseNumber': self.case_number, 'time': timestamp})
        except Exception as e:
            print(f'Exception processing screenshot: {e}')
