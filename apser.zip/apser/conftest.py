import pytest
import tempfile
import requests
import os
import stat
import shutil
import time
from skytap.skytap import PySkytap
from msedge.selenium_tools import EdgeOptions
from selenium import webdriver
from idaptive_automation.api_helpers import EmailHelper, AboutHelper, ExtDataApi, IBEHelper
from Helpers.general_helpers import random_alphanumeric
from idaptive_automation.ui_automation.idaptive_driver import Driver
from idaptive_automation.api_helpers.helpers.proxy_helper import ProxyApi
from Fixtures.sessions_and_helpers import *
from Fixtures.policy_fixtures import pwd_only_profile, app_policy_no_self_serve
from Helpers.general_helpers import random_password
from Steps.navigate_steps import Login, Navigate
from Helpers.test_data_helper import get_test_data_dir


def pytest_addoption(parser):
    parser.addoption(
        '--tenant', action='append', default=None,
        help='tenant to test'
    )
    parser.addoption(
        '--env', action='append', default=None,
        help='tenant to test'
    )
    parser.addoption(
        '--skytap_user', action='store', default=None,
        help='skytap username'
    )
    parser.addoption(
        '--skytap_key', action='store', default=None,
        help='skytap key'
    )

    parser.addoption('--get_auto_clean', required=False, action='store_true', default=False)
    parser.addoption('--get_metrics', required=False, action='store_true', default=False)
    parser.addoption('--pipeline_skip', required=False, action='store_true', default=False)


@pytest.fixture()
def screenshots(request):
    return request.config.getoption('screenshots', default=False)


@pytest.fixture(scope='function')
def case_number(request):
    test_name = request.node.originalname or request.node.name
    m = re.match(r'test_(c\d{4,})_', test_name)
    yield m.group(1)


@pytest.fixture()
def test_role_fixture(app_helpers):
    role_api = app_helpers['role_helper']
    role_name = f'Test role {app_helpers["test_id"]}'
    role_id = role_api.create_role(role_name)

    yield {'name': role_name, 'id': role_id}


@pytest.fixture()
def new_cloud_user(app_helpers, pwd_only_profile):
    test_id = app_helpers['test_id']
    cloud_session = app_helpers['cloud_session']
    policy_api = app_helpers['policy_helper']
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    alias = TenantApiHelper(cloud_session).get_aliases_for_tenant()[0]

    username = f'{test_id}-automation-user'
    display_name = f"{test_id} Automation"
    password = random_password()
    payload = CloudUser(alias, username)\
        .with_password_never_expire(True)\
        .with_password(password)\
        .with_display_name(display_name)\
        .to_payload()
    payload['uuid'] = user_api.create_cloud_user(payload).result()
    payload['Password'] = password
    role_id = role_api.create_role(f'Test {test_id} role',
                                   f"A temporary role for test case {test_id}")
    role_api.add_users_to_role(role_id, [payload['uuid']])
    policy = policy_api.create_policy(f'{test_id} Policy',
                                      {}, link_type='Role',
                                      params=[role_id],
                                      description=f"A temporary policy for test case {test_id}")

    yield {
        'user': payload,
        'role': role_id,
        'policy': policy,
        'user_api': user_api,
        'role_api': role_api,
        'policy_api': policy_api
    }


@pytest.fixture()
def new_cloud_user_in_test_role_fixture(app_helpers):
    cloud_session = app_helpers['cloud_session']
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    test_id = app_helpers['test_id']
    alias = TenantApiHelper(cloud_session).get_aliases_for_tenant()[0]
    password = random_password()

    username = f'{test_id}-automation-user'
    display_name = f"{test_id} Automation {alias}"
    payload = CloudUser(alias, username)\
        .with_password_never_expire(True)\
        .with_password(password)\
        .with_display_name(display_name)\
        .to_payload()
    payload['uuid'] = user_api.create_cloud_user(payload).result()
    payload['Password'] = password

    role_name = f'Test role {test_id}'
    role_id = role_api.create_role(role_name)
    role_api.add_users_to_role(role_id, [payload['uuid']])
    role_api.add_users_to_automation_role([payload['uuid']])

    payload['role_id'] = role_id
    payload['role_name'] = role_name

    yield payload


@pytest.fixture()
def cloud_user(app_helpers):
    cloud_session = app_helpers['cloud_session']
    user_api = app_helpers['user_helper']
    test_id = app_helpers['test_id']
    alias = TenantApiHelper(cloud_session).get_aliases_for_tenant()[0]
    password = random_password()

    username = f'{test_id}-automation-user'
    display_name = f"{test_id} Automation {alias}"
    payload = CloudUser(alias, username)\
        .with_password_never_expire(True)\
        .with_password(password)\
        .with_display_name(display_name)\
        .to_payload()
    payload['uuid'] = user_api.create_cloud_user(payload).result()
    payload['Password'] = password

    yield payload


@pytest.fixture()
def new_cloud_user_in_role_with_policy_fixture(app_helpers, app_policy_no_self_serve):
    test_id = app_helpers['test_id']
    cloud_session = app_helpers['cloud_session']
    alias = TenantApiHelper(cloud_session).get_aliases_for_tenant()[0]
    password = random_password()
    session = cloud_session
    with UserApi(session, True) as user_api,\
            RoleApi(session, True) as role_api,\
            PolicyApi(session, True) as policy_api:
        username = f'{test_id}-automation-user'
        display_name = f"{test_id} Automation {alias}"
        payload = CloudUser(alias, username)\
            .with_password_never_expire(True)\
            .with_password(password)\
            .with_display_name(display_name)\
            .to_payload()
        payload['uuid'] = user_api.create_cloud_user(payload).result()
        payload['Password'] = password

        role_name = f'Test role {test_id}'
        role_id = role_api.create_role(role_name,
                                       f"A temporary role {test_id}")
        role_api.add_users_to_role(role_id, [payload['uuid']])
        policy_api.create_policy(f'{test_id} Policy',
                                 app_policy_no_self_serve, link_type='Role',
                                 params=[role_id],
                                 description=f"A temporary policy {test_id}")
        payload['role_id'] = role_id
        payload['role_name'] = role_name

        yield payload


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def driver(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()
        yield browser


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def driver2(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()
        yield browser


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def driver_admin(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()
        tenant_info = app_helpers['tenant_info']
        Login(browser, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
        yield browser


@pytest.yield_fixture(params=[
    #'Chrome'
    #'Firefox'
    'Edge'
])
def driver_ibe(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    download_urls = app_helpers['tenant_helper'].get_download_urls()
    browser_name = request.param
    if browser_name == 'Edge':
        browser_name = 'MicrosoftEdge'
    download_url = download_urls['browserExtensionUrls']['Stable'][0][browser_name]
    extension_name = download_url.split('/')[-1:][0]

    dirpath = get_test_data_dir()
    full_path = os.path.join(dirpath, extension_name)
    r = requests.get(download_url, allow_redirects=True, verify=False)
    open(full_path, 'wb').write(r.content)

    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
        options.add_extension(full_path)
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    if request.param == 'Edge':
        options = EdgeOptions()
        options.add_extension(full_path)

    with Driver(options, base_url=tenant_info['base_url']) as browser:
        if request.param == 'Firefox':
            browser.install_addon(full_path)
        browser.maximize_window()
        yield browser

    os.remove(full_path)


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def admin_portal_users_tab_driver(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()
        tenant_info = app_helpers['tenant_info']
        Login(browser, tenant_info['base_url']).to_admin_portal(tenant_info['username'], tenant_info['password'])
        Navigate(browser).to_admin_portal().to_users_tab()
        yield browser


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def driver_user(request, app_helpers, new_cloud_user_in_role_with_policy_fixture):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()
        tenant_info = app_helpers['tenant_info']
        Login(browser,  tenant_info['base_url'])\
            .to_user_portal(new_cloud_user_in_role_with_policy_fixture['Name'],
                            new_cloud_user_in_role_with_policy_fixture['Password'])
        yield browser


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def driver_to_user_portal(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()
        tenant_info = app_helpers['tenant_info']
        Login(browser, tenant_info['base_url']).to_user_portal(tenant_info['username'], tenant_info['password'])
        yield browser


@pytest.fixture()
def locked_user_acct(app_helpers, cloud_user):
    UserApi(app_helpers['cloud_session']).lock_user_account(cloud_user['Name'])
    return cloud_user


@pytest.fixture()
def unique_id():
    yield random_alphanumeric()


@pytest.fixture()
def about_function_fixture(app_helpers):
    cloud_session = app_helpers['cloud_session']
    tenant_info = app_helpers['tenant_info']
    info = AboutHelper(cloud_session).get_about_info()
    version = info['Version']
    region = f'{info["PodRegion"]} ({info["PodFqdn"]})'
    tenant = tenant_info['tenant_id']
    return [version, region, tenant]

@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def driver_downloads(request, app_helpers):
    with tempfile.TemporaryDirectory() as download_path:
        tenant_info = app_helpers['tenant_info']
        if request.param == 'Chrome':
            options = webdriver.ChromeOptions()
        if request.param == 'Firefox':
            options = webdriver.FirefoxOptions()
        prefs = dict()
        prefs["profile.default_content_settings.popups"] = 0
        prefs["download.default_directory"] = download_path
        options.add_experimental_option("prefs", prefs)
        with Driver(options, base_url=tenant_info['base_url']) as browser:
            browser.maximize_window()
            yield browser, download_path


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def policy_detail_page_driver(request, app_helpers):
    tenant_info = app_helpers['tenant_info']
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_info['base_url']) as browser:
        browser.maximize_window()

        Login(browser, tenant_info['base_url']) \
            .to_admin_portal(tenant_info['username'], tenant_info['password'])

        Navigate(browser).to_policies_tab()
        yield browser


@pytest.fixture()
def attribute_helper(app_helpers):
    with ExtDataApi(app_helpers['cloud_session'], True) as attr_api:
        yield attr_api


@pytest.fixture()
def latest_ibe_fixture(app_helpers):
    latest = IBEHelper(app_helpers['cloud_session']).get_latest_cloud_version()
    return latest


@pytest.fixture()
def connector_vm(app_helpers, request):
    """ Sets up a skytap vm that has the connector software on it and configures it to connect to the tenant """
    username = request.config.getoption('--skytap_user')
    password = request.config.getoption('--skytap_key')
    tenant_info = app_helpers['tenant_info']
    note_string = f'{tenant_info["base_url"]}~{tenant_info["username"]}~{tenant_info["password"]}'
    with PySkytap(template_id=2042859, notes=note_string, username=username, password=password) as skytap:
        cloud_session = app_helpers['cloud_session']
        proxy_helper = ProxyApi(cloud_session)
        skytap_proxy_ready = None
        count = 0
        while skytap_proxy_ready is None and count <= 20:
            count = count + 1
            time.sleep(20)
            all_proxies = proxy_helper.get_all_proxies()
            for proxy in all_proxies:
                if proxy['Forest'] == 'idap-cicd.com' and proxy['Online'] is True:
                    skytap_proxy_ready = proxy
        yield skytap

    while not proxy_helper.delete_proxies([skytap_proxy_ready['ID']], assert_success=False).success():
        time.sleep(5)
        pass
