

class StepsBase:
    def __init__(self,driver):
        self.driver = driver

    def refresh_page(self):
        self.driver.refresh()
        return self
