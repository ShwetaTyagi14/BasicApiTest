from idaptive_automation.ui_automation import AdminPortalPage, EnterAuthenticationCodePage,\
    MfaAuthenticationPage, UserPortalPage, SignInPage, SelectAuthenticationMethodPage


class MfaLogin:
    def __init__(self, driver, environment_url, challenges):
        self.driver = driver
        self.environment_url = environment_url
        self.challenges = challenges
        if environment_url:
            driver.get(environment_url)

    def to_user_portal(self, user_name,
                       password,
                       challenge,
                       responses,
                       wait_for_portal_load=True):
        self.driver.navigate_to_resource('my')
        self.perform_login(user_name, password, challenge, responses)
        if wait_for_portal_load:
            UserPortalPage(self.driver).wait_for_page_to_load(wait_time=20)
        return self

    def perform_login(self, username,
                      password,
                      challenge,
                      responses):
        SignInPage(self.driver).set_username(username)
        MfaAuthenticationPage(self.driver, [challenge]).login(password, challenge, responses)
        return self

    def to_admin_portal_with_up_mfa_challenge(self, username,
                                              password,
                                              up_challenge,
                                              up_responses,
                                              ap_challenge):
        self.driver.navigate_to_resource('admin')
        self.perform_login(username, password, up_challenge, up_responses)
        return self.execute_mfa_authentication(ap_challenge)

    def execute_mfa_authentication(self,
                                   ap_challenge,):
        SelectAuthenticationMethodPage(self.driver, [ap_challenge]).select_mfa_challenge(ap_challenge)
        return self

    def enter_mfa_code(self, code,
                       wait_for_portal_load=True):
        EnterAuthenticationCodePage(self.driver).answer_mfa_challenge(code)
        if wait_for_portal_load:
            AdminPortalPage(self.driver).wait_for_page_to_load(wait_time=20)
