def left_nav_should_be_unpinned_state(user_profile, left_nav, nav_size):
    user_profile.click_profile()
    nav_size_unpinned = left_nav.get_left_nav_size()
    unpinned_width = int(nav_size_unpinned['width'][:-2])
    assert unpinned_width == nav_size['unpinned_width'], \
        f"Expected width of {nav_size['unpinned_width']}, got {nav_size_unpinned['width']}"
    left_nav.expand_pinned_nav()
    nav_floating_displayed = left_nav.is_floating_nav_displayed()
    assert nav_floating_displayed, f"expected floating nav displayed, but it was not"


def left_nav_should_be_pinned_state(user_profile, left_nav, nav_size):
    user_profile.click_profile()
    nav_size_pinned = left_nav.get_left_nav_size()
    pinned_width = int(nav_size_pinned['width'][:-2])
    assert pinned_width == nav_size['pinned_width'], \
        f"Expected width {nav_size['pinned_width']}, got {nav_size_pinned['width']}"
    left_nav.expand_pinned_nav()
    nav_floating_displayed = left_nav.is_floating_nav_displayed()
    assert not nav_floating_displayed, f"expected floating nav not displayed, but it is"