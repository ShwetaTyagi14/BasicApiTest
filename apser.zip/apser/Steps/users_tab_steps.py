from idaptive_automation.ui_automation import UsersTab
from Steps.steps_base import StepsBase


class UsersTabSteps(StepsBase):
    def __init__(self, driver):
        self.users_tab = UsersTab(driver)
        super().__init__(driver)

    def get_displayed_users(self):
        rows = self.users_tab.get_displayed_users()
        users = []
        for row in rows:
            username, display_name, email, source, status, *other = row
            users.append({'Username': username.strip(),
                          'DisplayName': display_name.strip(),
                          'Email': email.strip(),
                          'SourceDsLocalized': source.strip(),
                          'Status': status.strip(),
                          })
        return self, users

    def convert_user_info_to_match_ui_display(self, user_info):
        users = [self._parse_user_info(user['Row']) for user in user_info]
        return self, users

    @staticmethod
    def _parse_user_info(info):
        return {'Username': info['Username'],
                'DisplayName':  info['DisplayName'],
                'Email':  info['Email'],
                'SourceDsLocalized':  info['SourceDsLocalized'],
                'Status': info['Status'],
                'LastInvite':  info['LastInvite'],
                'LastLogin':  info['LastLogin'],
                'ServiceUser':  info['ServiceUser']}

