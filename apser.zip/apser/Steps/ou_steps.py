from idaptive_automation.api_payloads import *
import os
import tempfile
import ntpath
from idaptive_automation.ui_automation import AppsPage, AdminPortalPage, UsersTab
from Steps.navigate_steps import Login, Navigate


def add_users_to_ou(ou_helper, ou_id, user_ids):
    if not isinstance(user_ids, list):
        user_ids = [user_ids]
    assert ou_helper.add_users_to_ou(ou_id, user_ids)
    for user_id in user_ids:
        assert ou_helper.is_user_in_ou(ou_id, user_id)


def remove_users_from_ou(ou_helper, ou_id, user_ids):
    if not isinstance(user_ids, list):
        user_ids = [user_ids]
    assert ou_helper.remove_users_from_ou(ou_id, user_ids)
    for user_id in user_ids:
        assert not ou_helper.is_user_in_ou(ou_id, user_id)


def add_roles_to_ou(ou_helper, ou_id, role_ids):
    if not isinstance(role_ids, list):
        role_ids = [role_ids]
    assert ou_helper.add_roles_to_ou(ou_id, role_ids)
    for role_id in role_ids:
        assert ou_helper.is_role_in_ou(ou_id, role_id)


def remove_roles_from_ou(ou_helper, ou_id, role_ids):
    if not isinstance(role_ids, list):
        role_ids = [role_ids]
    assert ou_helper.remove_roles_from_ou(ou_id, role_ids)
    for role_id in role_ids:
        assert not ou_helper.is_role_in_ou(ou_id, role_id)


def validate_unit_rights(results, unit_id, unit_type, rights):
    for granted_rights in results:
        assert granted_rights['Principal'] == unit_id
        assert granted_rights['PrincipalType'] == unit_type
        assert granted_rights['Right'] in rights


def create_users_in_ou(number_of_users, alias, test_id, ou_path, cloud_user_api, displayname='Test'):
    users = {}

    for x in range(number_of_users):
        username = f'ou_user_{x}_{test_id}'
        payload = CloudUser(alias, username).with_display_name(displayname).to_payload()
        payload["OrgPath"] = ou_path
        users[cloud_user_api.create_cloud_user(payload).result()] = payload["Name"]
    return users


def write_bulk_ou_file(file_name, bulk_array):
    """
    Submits bulk_array as a csv file to api_session.upload_file
    :param file_name: temporary filename
    :param bulk_array: string array composed of lines to be written to the csv file
    :return: (Success)Bool
    """
    temp_file, file_path = tempfile.mkstemp(prefix=file_name, suffix='.csv')
    with open(file_path, 'w') as file:
        for line in bulk_array:
            file.write(line)
    os.close(temp_file)
    _, final_name = ntpath.split(file_path)
    return file_path, final_name


def build_ou_bulk_import(cloud_user_api, alias, ou_name, test_id, number_of_users,
                             start_at=0, admin=False, bulk_array=['Login Name, Organization Unit, OU Admin\n']):
    """
    build an array to later be converted in to a CSV file for OU Bulk Import
    :param cloud_user_api: user_api
    :param alias: Tenant Alias
    :param ou_name: Name of OU
    :param test_id: Random String
    :param number_of_users: Number of Users to create and be added to OU
    :param start_at: Default 0.  Part of the user naming convention
    :param admin: Bool if created users should be admins in OU
    :param bulk_array: If building the bulk_array in several parts, it can be passed back
    :return: bulk_array
    """
    for x in range(number_of_users):
        payload = CloudUser(alias, f'ou_user_{start_at + x}_{test_id}').to_payload()
        user_uuid = cloud_user_api.create_cloud_user(payload).result()
        if user_uuid is not None:
            bulk_array.append(f'ou_user_{start_at + x}_{test_id}@{alias}, {ou_name}, {str(admin).upper()}\n')
    return bulk_array


def submit_bulk_ou_file(cloud_user_api, file_name, bulk_array):
    """
    Submits bulk_array as a csv file to api_session.upload_file
    :param cloud_user_api: user_api
    :param file_name: temporary filename
    :param bulk_array: string array composed of lines to be written to the csv file
    :param user_api: user_api to submit file
    :return: (Success)Bool
        """
    file_path, file_name = write_bulk_ou_file(file_name, bulk_array)
    response = cloud_user_api.get_users_from_csv_file(file_name, file_path, ou=True)
    os.remove(file_path)

    return response


def create_ou_negative_case(ou_helper, ou_name, description=""):
    response = ou_helper.create_ou_return_response(ou_name, assert_success=False)
    assert not response.success()
    assert 'A set with this name already exists' in response.message()


def update_ou_to_existing_ou_name(ou_helper, ou_name1, ou_name2, description=""):
    create_response = ou_helper.create_ou_return_response(ou_name2)
    assert create_response.success()
    ou_id = create_response.result()['ID']
    update_response = ou_helper.update_ou(ou_id, ou_name1, assert_success=False)
    assert not update_response.success()
    assert 'A set with this name already exists' in update_response.message()


def update_ou(ou_helper, ou_id, ou_name, description=""):
    update_result = ou_helper.update_ou(ou_id, ou_name, description)
    assert update_result.success()
    get_ou_result = ou_helper.get_ou(ou_id)
    assert get_ou_result['Name'] == ou_name
    assert get_ou_result['Description'] == description


def add_users_to_ou_from_users_page(driver_admin, users, test_id):
    Navigate(driver_admin).to_users_tab()
    users_tab = UsersTab(driver_admin)
    search_criteria = users[0][0:10]
    users_tab.search_for_user(search_criteria)
    for user in users:
        users_tab.select_user_checkbox(user)
    users_tab.open_actions_menu()
    users_tab.click_add_to_organization()
    users_tab.press_cancel_button()
    users_tab.open_actions_menu()
    users_tab.click_add_to_organization()
    users_tab.press_add_button()
    users_tab.refresh_page()


def validate_users_added_to_ou(ou_helper, users, ou_id, alias):
    users_in_ou = ou_helper.get_ou_users(ou_id)
    users_list = []
    for user in users_in_ou:
        users_list.append(user['Row']['Username'])
    for user in users:
        assert users_list.__contains__(f'{user}@{alias}')


def validate_warning_adding_users_to_different_ou(driver_admin, users, test_id):
    Navigate(driver_admin).to_users_tab()
    users_tab = UsersTab(driver_admin)
    search_criteria = users[0][0:10]
    users_tab.search_for_user(search_criteria)
    for user in users:
        users_tab.select_user_checkbox(user)
    users_tab.open_actions_menu()
    users_tab.click_add_to_organization()
    users_tab.validate_ou_warning()
    users_tab.press_ok_on_warning()


def validate_not_authorized_to_modify_ous(driver_admin, users, test_id):
    Navigate(driver_admin).to_users_tab()
    users_tab = UsersTab(driver_admin)
    search_criteria = users[0][0:10]
    users_tab.search_for_user(search_criteria)
    for user in users:
        users_tab.select_user_checkbox(user)
    users_tab.open_actions_menu()
    users_tab.click_add_to_organization()
    users_tab.validate_ou_unauthorized_popup()
    users_tab.press_ok_on_warning()
    users_tab.validate_users_tab_is_loaded()