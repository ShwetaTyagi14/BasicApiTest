from idaptive_automation.ui_automation import PortalSwitcherPopout
from idaptive_automation.ui_automation import UsersTab, AdminPortalPage
from Steps.navigate_steps import Navigate
from idaptive_automation.ui_automation.pages.adminportal.UsersTab.user_add_edit_window import UserAddEditWindow
import time
from idaptive_automation.ui_automation.pages.userportal.personal_profile import PersonalProfile
from idaptive_automation.api_helpers import UserMgmt
from idaptive_automation.api_helpers import CDirectoryService


def wait_for_editable(driver_admin, ad_user, domain_worker, number):
    editable = False
    tries = 0
    while not editable:
        time.sleep(20)
        admin_portal_page = AdminPortalPage(driver_admin)
        portal_switch = PortalSwitcherPopout(driver_admin)
        admin_portal_page.refresh_page()
        portal_switch.switch_to_user_portal()
        admin_portal_page.refresh_page()
        portal_switch.switch_to_admin_portal()

        Navigate(driver_admin).to_users_tab()
        users_tab = UsersTab(driver_admin)
        users_tab.search_for_user(ad_user)
        users_tab.open_user_detail_window_for_user(f'{ad_user}@{domain_worker.email_suffix}')
        edit_user = UserAddEditWindow(driver_admin)
        editable = edit_user.edit_mobile_when_editable(number)
        tries = tries + 1
        if tries == 25:
            break
    return editable


def user_portal_ad_mobile_number_validation(driver, mobile_numbers, password):
    for current_number in mobile_numbers:
        PersonalProfile(driver).click_edit_profile(password)
        assert PersonalProfile(driver).edit_mobile_number(current_number)


def validate_mobile_numbers(app_helpers, driver_admin, ad_user, domain_worker, mobile_numbers):
    first_cycle = True
    for current_number in mobile_numbers:
        if first_cycle:
            first_cycle = False
            assert wait_for_editable(driver_admin, ad_user, domain_worker, current_number)
            verify_numbers_match(app_helpers, ad_user, current_number)
        else:
            edit_user = UserAddEditWindow(driver_admin)
            assert edit_user.edit_mobile_when_editable(current_number)
            verify_numbers_match(app_helpers, ad_user, current_number)


def verify_numbers_match(app_helpers, ad_user, current_number):
    user_helper = app_helpers['user_helper']
    user_suffix = app_helpers['tenant_info']['domain_controller']['default_email_suffix']
    cloud_session = app_helpers['cloud_session']
    user_mgmt = UserMgmt(cloud_session)
    uid = user_helper.get_user_info(f"{ad_user}@{user_suffix}")['Entities'][0]['Key']
    attributes_payload = {"ID": f'{uid}', "DirectoryServiceUuid": "not_needed"}

    result = user_mgmt.get_user_attributes(attributes_payload).response['Result']['mobile']
    for num in range(10):
        CDirectoryService(cloud_session).refresh_ad_user_token(uid)
        result = user_mgmt.get_user_attributes(attributes_payload).response['Result']['mobile']
        if result == current_number:
            break
    assert current_number == result, f"Expected: {current_number} to match user results, got {result} instead"
