from idaptive_automation.ui_automation import AdminPagePoliciesTab
from idaptive_automation.ui_automation import PolicyDetailLandingPage
from Steps.policy_detail_steps import PolicyDetailSteps
from Steps.steps_base import StepsBase


class AdminPoliciesTabSteps(StepsBase):
    def __init__(self, driver):
        self.driver = driver
        self.policies_tab = AdminPagePoliciesTab(driver)
        super().__init__(driver)

    def validate_admin_policies_tab_display(self):
        self.policies_tab.validate_all_elements()
        return self

    def get_displayed_policies(self):
        self.ensure_previous_test_discarded_changes()

        rows = self.policies_tab.get_displayed_policies()
        policies = []
        for row in rows:
            name, status, descr = row.text.split('\n')
            policies.append({'Name': name.strip(), 'Status': status.strip(), 'Description': descr.strip()})
        return self, policies

    def open_add_policy_window(self):
        self.ensure_previous_test_discarded_changes()

        self.driver.wait_for_loading_mask_to_disappear(wait_time=10)
        self.policies_tab.open_add_policy_window()
        self.driver.wait_for_loading_mask_to_disappear(wait_time=10)
        return PolicyDetailSteps(self.driver)

    def wait_for_policies_tab_loaded(self):
        AdminPagePoliciesTab(self.driver).wait_for_page_to_load()
        return self

    def ensure_previous_test_discarded_changes(self):
        # this only applies to the policy detail tests, and only if the previous test failed without discarding changes
        if PolicyDetailLandingPage(self.driver).is_loaded():
            PolicyDetailSteps(self.driver).discard_changes()

    def refresh_page(self):
        super().refresh_page()
        return self

    def validate_page(self, navigation_links, ui_page, additional_args=None):
        AdminPoliciesTabSteps(self.driver).open_add_policy_window()
        PolicyDetailSteps(self.driver).navigate(navigation_links)
        page = None

        if additional_args is not None:
            page = ui_page(self.driver, additional_args)
        else:
            page = ui_page(self.driver)

        page.validate_all_elements() \
            .validate_all_child_elements()

        PolicyDetailSteps(self.driver).discard_changes()
