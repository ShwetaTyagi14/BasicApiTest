from idaptive_automation.ui_automation import UploadCertificatePage


def setup_new_application_cert(driver_admin, cert_name, certificate_file_path, verify_error=False, ):
    upload_certs_page = UploadCertificatePage(driver_admin)
    upload_certs_page.set_name(cert_name)
    upload_certs_page.set_password('centrify')
    upload_certs_page.set_filename(certificate_file_path)
    upload_certs_page.click_save()
    if not verify_error:
        upload_certs_page.verify_window_closed()
    else:
        result = upload_certs_page.verify_error_displayed_and_close()
        return result