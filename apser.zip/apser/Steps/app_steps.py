from idaptive_automation.api_payloads.payloads.grants import Grants
from idaptive_automation.api_payloads.payloads.application_permissions import ApplicationPermissions
from idaptive_automation.api_payloads.payloads.configure_gateway_application import ConfigureGatewayApplication
from idaptive_automation.api_payloads import GenericUserPasswordApp, GenericSamlApp
from idaptive_automation.api_helpers import RedrockApi
from idaptive_automation.api_helpers.helpers.gateway_helper import AppGatewayHelper
from idaptive_automation.api_helpers.helpers.oauth2_helper import OAuth2Helper
from Helpers.test_data_helper import load_json_test_data_file, prepare_app_payload, prepare_oidc_app_payload, \
    prepare_oidc_client_payload
from Helpers.oidc_client import oidc_client
from idaptive_automation.ui_automation import AdminPortalPage, WebAppsPage
from idaptive_automation.api_helpers import UprestHelper
from Fixtures.sessions_and_helpers import *
import time
import string
import random
import multiprocessing
import json
import jwt
import socket


def deploy_app_by_name(app_helper, name, role=None):
    if role is None:
        role = "Everybody"

    app_id = app_helper.import_app_by_name(name)

    grant = Grants().with_principal(role) \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()
    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    app_helper.set_application_permissions(permissions)
    return app_id


def create_generic_app(app_name, app_helpers):
    tenant_info = app_helpers['tenant_info']
    app_api = app_helpers['app_helper']
    cloud_session = app_helpers['cloud_session']
    response = TenantApiHelper(cloud_session).get_tenant_certificate()
    cert_thumbprint = response['Results'][0]['Row']['Thumbprint']
    app_id = app_api.import_app_by_name(app_name)
    generic_app_data = load_json_test_data_file("generic_app.json", sub_dir="Applications")
    if app_name in generic_app_data:
        payload = prepare_app_payload(generic_app_data[app_name], tenant_info, app_id, cert_thumbprint)
        result = app_api.update_application_de(payload)
        assert result.response['success'] is True
    return app_id


def get_existing_app_by_name(name, session):
    redrock = RedrockApi(session)

    apps = redrock.execute_redrock_query({
        "Script": "@@Web Applications PLV8",
        "Args": {
            "PageNumber": 1,
            "PageSize": 100,
            "Limit": 100000,
            "SortBy": "Name",
            "Ascending": True,
            "Caching": -1
        }
    })

    for app in apps.response['Result']['Results']:
        app_details = app['Row']
        if app_details['DisplayName'] == name:
            return app_details

    return None


def get_expected_admin_rights():
    return load_json_test_data_file('../TestData/AdminRights/admin_rights.json')


def go_to_apps_tab(driver):
    admin_page = AdminPortalPage(driver)
    admin_page.select_web_apps()
    WebAppsPage(driver)


def deploy_template_app(session, app_name=None, web_app_type=None):
    if app_name is None:
        app_name = 'Salesforce'
    if web_app_type is None:
        web_app_type = 'SAML + Provisioning'

    # TODO: Pull config from new source
    config = configured_app['configuration']
    for template in AppHelper(session_fixture['session']).get_templates_and_categories()['AppTemplates']['Results']:
        if template['Row']['Name'] == app_name and template['Row']['WebAppTypeDisplayName'] == web_app_type:
            with AppHelper(session_fixture['session'], True) as app_api:

                app_id = app_api.import_app_by_name(template['Row']['Name'])

                issuer = config['Issuer']
                app = GenericSamlApp(issuer, app_id)\
                    .with_name('Salesforce SAML app for automation')\
                    .with_url(config['Url'])\
                    .with_thumbprint(config['Thumbprint'])\
                    .with_audience(config['Audience'])\
                    .with_fixed_username(config['Username'])\
                    .to_payload()

                app_api.update_application_de(app)
                grant = Grants().with_principal('App Services Automation') \
                    .with_view_rights() \
                    .with_execute_rights() \
                    .with_auto_deploy()
                permissions = ApplicationPermissions().with_app_id(app_id) \
                    .with_grant(grant.to_payload()) \
                    .to_payload()

                app_api.set_application_permissions(permissions)

                yield [app_name, app_api]


def deploy_generic_apps(number, user, app_helpers, wait_until_deployed=False):
    test_id = app_helpers['test_id']
    app_api = app_helpers['app_helper']
    deployed_apps = []

    for n in range(number):
        app_name = f'{test_id} Test App number {n}'
        app_descrition = f'Test App number {n}'
        app_url = 'https://google.com'
        app_id = app_api.import_username_password_app()

        app = GenericUserPasswordApp(app_id).with_url(app_url) \
            .with_description(app_descrition) \
            .with_name(app_name) \
            .with_fixed_username('testusername', 'testpassword') \
            .to_payload()

        app_api.update_application_de(app)

        grant = Grants().with_user(user['Name'], user['uuid']) \
            .with_view_rights() \
            .with_execute_rights() \
            .with_auto_deploy()
        permissions = ApplicationPermissions().with_app_id(app_id) \
            .with_grant(grant.to_payload()) \
            .to_payload()

        deployed_apps.append({
            'name': app_name,
            'app': app,
            'permissions': permissions,
            'app_id': app_id
        })

    if wait_until_deployed:
        result = None
        tries = 30
        while result is None:
            try:
                result = app_api.get_application(app_id)
            except AssertionError:
                if tries > 0:
                    tries -= 1
                    time.sleep(1)
                else:
                    assert result is not None, "Unable to retrieve newly created apps"

    return deployed_apps


def get_service_name_from_app_name(app_helper, app_name):
    app = app_helper.get_app_from_app_name(app_name)
    if app and 'ServiceName' in app:
        return app['ServiceName']
    else:
        return None


def get_grantstr_for_principal(principal, row_access_result):
    """
    Retrieves GrantStr for a principal for a specific app
    principal refers to the username or role name
    """
    for row in row_access_result:
        if row['PrincipalName'] == principal:
            grant_str = row['GrantStr']
            return grant_str


def create_generic_user_password_app(app_helpers):
    test_id = app_helpers['test_id']
    app_api: AppHelper = app_helpers['app_helper']

    app_name = f'{test_id} Test App number'
    app_description = f'Test App number'
    app_url = 'https://google.com'
    app_id = app_api.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()

    app_api.update_application_de(app)

    return app


def set_manage_rights_for_app(user, app_helpers, app):
    app_helper = app_helpers['app_helper']
    grant = Grants().with_user(user['Name'], user['Uuid']) \
        .with_view_rights() \
        .with_view_detail_rights() \
        .with_manage_rights()

    permissions = ApplicationPermissions().with_app_id(app['_RowKey']) \
        .with_grant(grant.to_payload()) \
        .to_payload()
    app_helper.set_application_permissions(permissions)

def set_delete_rights_for_app(user, app_helper: AppHelper, app):
    grant = Grants().with_user(user['Name'], user['Uuid']) \
        .with_view_rights() \
        .with_view_detail_rights() \
        .with_delete_rights()

    permissions = ApplicationPermissions().with_app_id(app['_RowKey']) \
        .with_grant(grant.to_payload()) \
        .to_payload()
    app_helper.set_application_permissions(permissions)


def set_admin_view_rights_for_app(user, app_helper: AppHelper, app):
    grant = Grants().with_user(user['Name'], user['Uuid']) \
        .with_view_rights() \
        .with_view_detail_rights()

    permissions = ApplicationPermissions().with_app_id(app['_RowKey']) \
        .with_grant(grant.to_payload()) \
        .to_payload()
    app_helper.set_application_permissions(permissions)


def create_generic_user_password_app_deploy_to_role(app_helpers, app_name, role_id):
    app_helper = app_helpers['app_helper']
    test_id = app_helpers['test_id']
    app_url = 'https://google.com'
    app_description = 'A test app '
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    app_helper.update_application_de(app)

    apps = app_helper.get_admin_app_list()
    assert [app for app in apps if app['Row']['Name'] == app_name] is not None
    return app_helper.deploy_app_to_role(role_id, app_id)


def is_app_present(user_helper, username, password, app_name):
    user_session = user_helper.authenticate_as_user(username, password)
    up_data = UprestHelper(user_session).get_up_data_for_user()
    return len([app for app in up_data.result()['Apps'] if app['Name'] == app_name]) == 1


def setup_saml_app_with_script(app_helpers, base_name, config):
    saml_app = app_helpers.import_app_by_name("Generic SAML")

    app = GenericSamlApp("https://www.google.com", saml_app) \
        .with_name(base_name) \
        .with_url(config['Generic SAML']['Url']) \
        .with_thumbprint(config['Generic SAML']['Thumbprint']) \
        .with_audience(config['Generic SAML']['Audience']) \
        .to_payload()

    app_helpers.update_application_de(app)
    script_payload = config['GenericSAMLScript']
    script_payload['_RowKey'] = saml_app
    app_helpers.update_application_de(script_payload)
    return saml_app


def setup_user_password_app(app_helper, app_name):
    app_description = 'A user password test app '
    app_url = 'https://google.com'
    app_id = app_helper.import_username_password_app()

    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_prompt_for_username()
    app_helper.update_application_de(app.to_payload())

    grant = Grants().with_principal('Everybody') \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()

    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()
    app_helper.set_application_permissions(permissions)

    return app_id


def generate_string(length):
    allowed_chars = str(string.ascii_letters)
    str_size = length
    new_string = ''.join(random.choice(allowed_chars) for x in range(str_size))
    return new_string


def get_available_port():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


def create_oidc_app(app_helpers, tenant_info, port):
    cloud_session = app_helpers['cloud_session']
    app_api = AppHelper(cloud_session)

    # Create an OIDC app
    app_id = app_api.import_app_by_name("Generic OpenID Connect")

    # Set other variables
    app_name = "oidc_test_" + app_helpers['test_id']
    client_secret = app_helpers['test_id']
    index_page_uri = 'http://localhost:' + str(port)
    redirect_uri = index_page_uri + '/callback'

    # Update OIDC app
    oidc_app_payload = load_json_test_data_file("oidc_app_payload.json", sub_dir="Applications")
    prepare_oidc_app_payload(oidc_app_payload, app_id, app_name, client_secret, index_page_uri, tenant_info['base_url'])
    app_api.update_application_de(oidc_app_payload)

    # Set OIDC app permissions
    permissions = ApplicationPermissions().with_app_id(app_id)
    grant = Grants().with_principal("Everybody") \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()
    permissions = permissions.with_grant(grant.to_payload())
    app_api.set_application_permissions(permissions.to_payload())

    return app_id, app_name, client_secret, index_page_uri, redirect_uri


def start_oidc_client(app_id, app_name, client_secret, redirect_uri, tenant_info, port):
    oidc_client_payload = load_json_test_data_file("oidc_client_payload.json", sub_dir="Applications")
    prepare_oidc_client_payload(oidc_client_payload, app_id, app_name, tenant_info['base_url'], client_secret, redirect_uri)
    # multiprocessing makes sure that daemon process gets terminated right before main thread terminates.
    # No need to explicitly call oidc_client_server.terminate()
    oidc_client_server = multiprocessing.Process(target=oidc_client.run, args=(port, oidc_client_payload), daemon=True)
    oidc_client_server.start()


def follow_authorization_code_flow(driver_to_user_portal, index_page_uri):
    access_token = ""
    driver_to_user_portal.get(index_page_uri)
    time.sleep(3)
    submit = driver_to_user_portal.find_element_by_id("submit")
    submit.click()
    time.sleep(3)
    result = driver_to_user_portal.find_element_by_id("result")
    assert result.text != ""
    if result.text != "":
        result_json = json.loads(result.text)
        access_token = result_json["access_token"]
        jwt_dict = jwt.decode(access_token, options = {"verify_signature": False})

        assert "auth_time" in jwt_dict
        assert "name" in jwt_dict
        # Make sure the logged-in user has a profile picture or else assertion will fail
        assert "picture" in jwt_dict
    return access_token


def call_userinfo(app_helpers, app_name, access_token):
    cloud_session = app_helpers['cloud_session']
    oauth2_api = OAuth2Helper(cloud_session)
    resp = oauth2_api.user_info(app_name, access_token)

    assert resp.status_code == 200
    if resp.status_code == 200:
        resp_dict = resp.json()

        assert "auth_time" in resp_dict
        assert "name" in resp_dict
        # Make sure the logged-in user has a profile picture or else assertion will fail
        assert "picture" in resp_dict


def get_remote_access_app_id(app_api):
    # Get CyberArk Remote Access app
    app = app_api.get_app_from_app_name("CyberArk Remote Access Portal")

    # If app doesn't exist, create it and return app_id
    return app_api.import_app_by_name("CyberArkAleroAccessSAML") if app is None else app['ID']


def get_displayed_apps_count(web_apps_page, app_name, starting=True):
    max_apps_per_page = load_json_test_data_file("number_of_apps_in_a_page.json", sub_dir="AdminPortal")
    max_apps_per_page = max_apps_per_page['max_apps_per_page']
    if starting:
        max_apps_per_page = max_apps_per_page - 1
    app_count = web_apps_page.get_displayed_apps().__len__()
    if app_count >= max_apps_per_page:
        web_apps_page.search_for_app(app_name)
        app_count = web_apps_page.get_displayed_apps().__len__()
    return app_count


def wait_for_app_to_be_deleted(app_helper, app_name, wait_time=120):
    app = app_helper.get_app_from_app_name(app_name)

    try_count = 0
    while try_count < wait_time / 10 and app:
        response = app_helper.get_app_from_app_name(app_name)
        if not response:
            app = None
        else:
            time.sleep(10)
            try_count += 1

    if app is None:
        return True
    else:
        return False


def deploy_app_gw_enabled_up_app(short_app_name, app_helpers):
    app_helper = app_helpers['app_helper']
    cloud_session = app_helpers['cloud_session']
    app_name = f"{short_app_name}-{app_helpers['test_id']}"
    app_description = f"{app_name}"
    app_url = "https://www.google.com"
    app_id = deploy_app_by_name(app_helper, "Generic User-Password")
    app = GenericUserPasswordApp(app_id).with_url(app_url) \
        .with_description(app_description) \
        .with_name(app_name) \
        .with_fixed_username('testusername', 'testpassword') \
        .to_payload()
    result = app_helper.update_application_de(app)
    payload = ConfigureGatewayApplication(app_id).with_is_gatewayed(True).to_payload()
    app_configuration_result = AppGatewayHelper(cloud_session).configure_gateway_application(payload)
    result_app_details = app_helper.get_application(app_id)
    return app_configuration_result, result_app_details
