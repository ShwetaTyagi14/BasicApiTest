from Fixtures.sessions_and_helpers import *
from Helpers.test_data_helper import load_json_test_data_file
from idaptive_automation.api_payloads import CloudUser, AuthenticationProfile, SecurityQuestions
from idaptive_automation.api_helpers import UserMgmt


def create_mfa_user(scenario, app_helpers, email=None):
    alias = app_helpers['alias']
    policy_api = app_helpers['policy_helper']
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    auth_api = app_helpers['profile_helper']
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']

    policies = load_json_test_data_file('mfa_policy.json', "MFA")
    profiles = load_json_test_data_file('mfa_profile.json', "MFA")

    policy = None
    profile = None
    user_profile = None

    if scenario in policies:
        policy = policies[scenario]

    if scenario in profiles:
        profile = profiles[scenario]

    if profile:
        user_profile = auth_api.create_profile(AuthenticationProfile(f'Automated test profile - User Portal MFA {test_id}')
                                               .with_challenges(profile['challenges'])
                                               .with_additional_data("NumberOfQuestions", profile['NumberOfQuestions'])
                                               .to_payload())

    if "/Core/Authentication/AuthenticationRulesDefaultProfileId" in policy and user_profile:
        policy["/Core/Authentication/AuthenticationRulesDefaultProfileId"] = user_profile['Uuid']

    role_id = role_api.create_role_if_not_exists(f'Admin Portal MFA Login {test_id}')
    policy_api.create_policy(f'Automated test policy - Admin portal MFA challenge {test_id}',
                             policy, link_type='Role', params=[role_id])

    if email is None:
        email_address = 'test@test.test'
    payload = CloudUser(alias, f'Admin-Portal-MFA-Challenge-user-{test_id}').with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_api.create_cloud_user(payload)
    user_id = payload['Uuid'] = response.result()
    role_api.add_users_to_automation_role([user_id])

    role_api.add_users_to_role(role_id, [payload['Uuid']])
    role_api.add_users_to_role('sysadmin', [payload['Uuid']])

    if profile:
        sec_question = {'question': 'cat', 'answer': 'Dog'}

        UserMgmt(ApiSession(tenant_info['base_url'],
                            tenant_info['tenant_id'],
                            payload['Name'],
                            'testTEST1234',
                            test_name=test_id)) \
            .update_security_questions(SecurityQuestions()
                                       .with_user_question(sec_question)
                                       .to_payload())
        payload['sec_questions'] = [sec_question]

    return payload


def create_mfa_admin(scenario, app_helpers, security_question=False, email=None):
    alias = app_helpers['alias']
    policy_api = app_helpers['policy_helper']
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    auth_api = app_helpers['profile_helper']
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']

    policies = load_json_test_data_file('mfa_policy_admin.json', "MFA")
    profiles = load_json_test_data_file('mfa_profile.json', "MFA")

    user_profile = auth_api.create_profile(AuthenticationProfile(f'Automated test profile - User Portal MFA {test_id}')
                                           .with_challenges(["UP", "SQ"])
                                           .with_additional_data("NumberOfQuestions", 1)
                                           .to_payload())

    if not security_question:
        admin_profile = auth_api.create_profile(AuthenticationProfile(f'Automated test profile - Admin Portal MFA {test_id}')
                                                .with_challenges(["EMAIL"])
                                                .to_payload())
    else:
        challenges = ["SQ"]

        if scenario in profiles:
            challenges = profiles[scenario]['challenges']

        admin_profile = auth_api.create_profile(
            AuthenticationProfile(f'Automated test profile - Admin Portal MFA {test_id}')
            .with_challenges(challenges)
            .with_additional_data("NumberOfQuestions", 1)
            .to_payload())

    policy = policies[scenario]

    if "/Core/Authentication/AuthenticationRulesDefaultProfileId" in policy:
        policy["/Core/Authentication/AuthenticationRulesDefaultProfileId"] = user_profile['Uuid']

    if "/Core/Authentication/AdminService/Portal/Strong/Authentication/DefaultProfileId" in policy:
        policy["/Core/Authentication/AdminService/Portal/Strong/Authentication/DefaultProfileId"] = admin_profile['Uuid']

    role_id = role_api.create_role_if_not_exists('Admin Portal MFA Login')
    policy_api.create_policy(f'Automated test policy - Admin portal MFA challenge {test_id}', policy, link_type='Role',
                             params=[role_id])

    if email is None:
        email_address = "test@test.test"
    username = f'Admin-Portal-MFA-Challenge-user{test_id}'
    payload = CloudUser(alias, username).with_email(email_address).to_payload()
    payload['SendEmailInvite'] = False
    response = user_api.create_cloud_user(payload)
    payload['Uuid'] = response.result()
    role_api.add_users_to_automation_role([payload['Uuid']])
    sec_question = {'question': 'cat', 'answer': 'Dog'}

    UserMgmt(ApiSession(tenant_info['base_url'],
                        tenant_info['tenant_id'],
                        f'{username}@{alias}',
                        'testTEST1234',
                        test_name=test_id)) \
        .update_security_questions(SecurityQuestions()
                                   .with_user_question(sec_question)
                                   .to_payload())

    role_api.add_users_to_role(role_id, [payload['Uuid']])
    role_api.add_users_to_role('sysadmin', [payload['Uuid']])

    payload['sec_questions'] = [sec_question]

    return payload
