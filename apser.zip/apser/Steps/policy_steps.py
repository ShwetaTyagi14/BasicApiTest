from Helpers.test_data_helper import load_json_test_data_file
from idaptive_automation.api_payloads import AuthenticationProfile, SecurityQuestions
from idaptive_automation.api_helpers import UserMgmt
from idaptive_automation.api_client import ApiSession


def add_user_to_policy(app_helpers, user, policy_key):
    policy_api = app_helpers['policy_helper']
    test_id = app_helpers['test_id']
    role_api = app_helpers['role_helper']
    policies = load_json_test_data_file("mfa_policy.json", "MFA")
    policy = policies[policy_key]

    profile_helper = app_helpers['profile_helper']

    profile = profile_helper.create_profile(AuthenticationProfile(f'Pwd Only Profile {test_id}')
                                               .with_challenges(["UP"])
                                               .with_duration_in_minutes(5)
                                               .to_payload())

    role_name = f'Test role {test_id}'
    role_id = role_api.create_role(role_name,
                                   f"A temporary role {test_id}")
    role_api.add_users_to_role(role_id, [user['uuid']])

    if "/Core/Authentication/AuthenticationRulesDefaultProfileId" in policy:
        policy["/Core/Authentication/AuthenticationRulesDefaultProfileId"] = profile['Uuid']

    if "/Core/PasswordReset/AccountUnlockAuthProfile" in policy:
        policy["/Core/PasswordReset/AccountUnlockAuthProfile"] = profile['Uuid']

    policy_api.create_policy(f'{test_id} Policy', policy, link_type='Role', params=[role_id],
                             description=f"A temporary policy {test_id}")


def add_user_to_sq_policy(app_helpers, user, policy_key, use_mfa=False):
    user_helper = app_helpers['user_helper']
    policy_api = app_helpers['policy_helper']
    test_id = app_helpers['test_id']
    role_api = app_helpers['role_helper']
    policies = load_json_test_data_file("mfa_policy.json", "MFA")
    policy = policies[policy_key]
    tenant_info = app_helpers['tenant_info']
    cloud_session = app_helpers['cloud_session']

    user_session = user_helper.authenticate_as_user(user['Name'], user['Password'])
    sec_question = {'question': 'Case number', 'answer': test_id}
    payload = SecurityQuestions().with_user_question(sec_question) \
        .to_payload()

    UserMgmt(user_session).update_security_questions(payload)

    profile_helper = app_helpers['profile_helper']

    profile = profile_helper.create_profile(AuthenticationProfile(f'{test_id} Profile')
                                            .with_challenges(["UP"])
                                            .with_duration_in_minutes(5)
                                            .to_payload())
    if use_mfa:
        mfa_profile = profile_helper.create_profile(AuthenticationProfile(f'{test_id} MFA Profile')
                                                    .with_challenges(["SQ"])
                                                    .with_additional_data("NumberOfQuestions", 1)
                                                    .with_duration_in_minutes(5)
                                                    .to_payload())

    role_name = f'Test role {test_id}'
    role_id = role_api.create_role(role_name,
                                   f"A temporary role {test_id}")
    role_api.add_users_to_role(role_id, [user['uuid']])

    if "/Core/Authentication/AuthenticationRulesDefaultProfileId" in policy:
        policy["/Core/Authentication/AuthenticationRulesDefaultProfileId"] = profile['Uuid']

    if "/Core/PasswordReset/AccountUnlockAuthProfile" in policy:
        if use_mfa:
            policy["/Core/PasswordReset/AccountUnlockAuthProfile"] = mfa_profile['Uuid']
        else:
            policy["/Core/PasswordReset/AccountUnlockAuthProfile"] = profile['Uuid']

    policy_api.create_policy(f'{test_id} Policy', policy, link_type='Role', params=[role_id],
                             description=f"A temporary policy {test_id}")


def add_user_to_policy_standard(app_helpers, user, policy_key):
    policy_api = app_helpers['policy_helper']
    test_id = app_helpers['test_id']
    role_api = app_helpers['role_helper']
    policies = load_json_test_data_file("policy.json", "Policy")
    policy = policies[policy_key]
    tenant_info = app_helpers['tenant_info']

    sec_question = {'question': 'Case number', 'answer': test_id}
    payload = SecurityQuestions().with_user_question(sec_question) \
        .to_payload()

    UserMgmt(ApiSession(tenant_info['base_url'], tenant_info['tenant_id'], user['Name'],
                        user['Password'])).update_security_questions(payload)

    profile_helper = app_helpers['profile_helper']

    profile = profile_helper.create_profile(AuthenticationProfile(f'{test_id} Profile')
                                            .with_challenges(["UP"])
                                            .with_duration_in_minutes(5)
                                            .to_payload())

    role_name = f'Test role {test_id}'
    role_id = role_api.create_role(role_name,
                                   f"A temporary role {test_id}")
    role_api.add_users_to_role(role_id, [user['uuid']])

    if "/Core/Authentication/AuthenticationRulesDefaultProfileId" in policy:
        policy["/Core/Authentication/AuthenticationRulesDefaultProfileId"] = profile['Uuid']

    if "/Core/PasswordReset/AccountUnlockAuthProfile" in policy:
        policy["/Core/PasswordReset/AccountUnlockAuthProfile"] = profile['Uuid']

    policy_api.create_policy(f'{test_id} Policy', policy, link_type='Role', params=[role_id],
                             description=f"A temporary policy {test_id}")


def add_mfa_policy_to_role(app_helpers, role_id):
    policy_api = app_helpers['policy_helper']
    test_id = app_helpers['test_id']
    role_api = app_helpers['role_helper']
    policies = load_json_test_data_file("mfa_policy.json", "MFA")
    policy = policies['test_scenario1']

    profile_helper = app_helpers['profile_helper']

    profile = profile_helper.create_profile(AuthenticationProfile(f'Pwd Only Profile {test_id}')
                                               .with_challenges(["UP"])
                                               .with_duration_in_minutes(5)
                                               .to_payload())

    if "/Core/Authentication/AuthenticationRulesDefaultProfileId" in policy:
        policy["/Core/Authentication/AuthenticationRulesDefaultProfileId"] = profile['Uuid']

    if "/Core/PasswordReset/AccountUnlockAuthProfile" in policy:
        policy["/Core/PasswordReset/AccountUnlockAuthProfile"] = profile['Uuid']

    policy_api.create_policy(f'{test_id} Policy', policy, link_type='Role', params=[role_id],
                             description=f"A temporary policy {test_id}")

def policy_in_policy_list(policy_name, policy_list):
    """
    Check that policy name is in a list of dictionaries and returns True if found and False if not

    Keyword arguments:
         policy_name -- The name of the policy to check for
         policy_list -- A list from by the call get_admin_policy_list from policy_helper class in idaptive-automation
    """
    for policy_data in policy_list:
        if policy_data['Name'] == policy_name:
            return True

    return False
