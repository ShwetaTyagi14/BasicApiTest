from idaptive_automation.ui_automation import AdminPortalPage, UserProfileMenu, UserPortalPage, DownloadsPage, \
    RolesTabPage, AppsPage, SignInPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.Authentication.SigningCertificates.\
    signingcertificates_page import SigningCertificatesPage
from idaptive_automation.ui_automation.pages.adminportal.SettingsTab.Authentication.SecuritySettings.\
    security_settings_page import SecuritySettingsPage
from idaptive_automation.ui_automation.pages.reset_your_password_window import ResetYourPasswordWindow
from .mfa_login_steps import MfaLogin
import os
import json
from Steps.admin_policies_tab_steps import AdminPoliciesTabSteps
from Steps.users_tab_steps import UsersTabSteps
from idaptive_automation.ui_automation.pages.adminportal.OUTab.ou_tab_landing_page import OUSTab
from selenium import webdriver
from idaptive_automation.ui_automation.idaptive_driver import Driver


class Login:
    def __init__(self, driver, environment_url=None):
        self.driver = driver
        if environment_url:
            self.environment_url = environment_url
            driver.get(environment_url)

    def to_user_portal(self, user_name, password, wait_for_load_up=True):
        if '/my' not in self.driver.current_url:
            self.driver.navigate_to_resource('my')
        self.perform_up_login(user_name, password)
        if wait_for_load_up:
            UserPortalPage(self.driver).wait_for_page_to_load()
        else:
            up_page = UserPortalPage(self.driver)
            if up_page.is_loaded():
                return self
        return self

    def to_user_portal_without_navigation(self, user_name, password):
        self.perform_up_login(user_name, password)
        UserPortalPage(self.driver).wait_for_page_to_load()
        return self

    def to_user_portal_via_reset_password(self, user_name, password):
        self.driver.navigate_to_resource('my')
        self.perform_up_login(user_name, password)
        ResetYourPasswordWindow(self.driver).wait_for_page_to_load()
        return self

    def perform_up_login(self, user_name, password):
        up_page = UserPortalPage(self.driver)
        if up_page.is_loaded():
            return
        if os.environ.get(user_name) is not None:
            MfaLogin(self.driver, None, None)\
                .to_user_portal(user_name, password, 'Security Question', json.loads(os.environ[user_name]))
            return self

        SignInPage(self.driver).login(user_name, password)

    def to_admin_portal(self, username, password, wait_for_portal_load=True):
        self.driver.navigate_to_resource('admin')
        self.perform_ap_login(username, password)
        if wait_for_portal_load:
            AdminPortalPage(self.driver).wait_for_page_to_load(wait_time=20)

    def perform_ap_login(self, username, password):
        if os.environ.get(username) is not None:
            MfaLogin(self.driver, None, None)\
                .perform_login(username, password, 'Security Question', json.loads(os.environ[username]))
            return self
        SignInPage(self.driver).login(username, password)

    def to_admin_portal_via_mfa_challenge(self, username, password):
        self.to_admin_portal(username, password, False)

        AdminPortalPage(self.driver).wait_for_page_to_load(wait_time=20)
        # TODO: change this once feature is working - Admin portal should not load
        assert False, 'This test cannot be completed until the feature is working'

    def to_admin_portal_via_not_allowed_policy(self, username, password, wait_for_portal_load=True):
        self.driver.navigate_to_resource('admin')
        SignInPage(self.driver).login(username, password)
        if wait_for_portal_load:
            return self

    def login_with_wrong_password(self, user_name, password):
        self.driver.navigate_to_resource('my')
        SignInPage(self.driver).login(user_name, password)


class Navigate:
    def __init__(self, driver):
        self.driver = driver

    def to_up_sign_in_page(self):
        if '/my' not in self.driver.current_url:
            self.driver.navigate_to_resource('my')

    def to_admin_portal(self, auto_dismiss_wizard=False):
        if 'admin' in self.driver.current_url:
            return self

        UserProfileMenu(self.driver).switch_to_admin_portal()
        ap = AdminPortalPage(self.driver)
        if auto_dismiss_wizard:
            ap.close_welcome_wizard(required=False)
        ap.wait_for_page_to_load()
        return self

    def to_user_portal_via_url(self, wait_for_portal_load=True):
        self.driver.navigate_to_resource('my')
        if wait_for_portal_load:
            UserPortalPage(self.driver).wait_for_page_to_load(wait_time=20)

    def to_admin_portal_via_url(self, wait_for_portal_load=True):
        self.driver.navigate_to_resource('admin')
        if wait_for_portal_load:
            AdminPortalPage(self.driver).wait_for_page_to_load(wait_time=20)

    def to_policies_tab(self):
        AdminPortalPage(self.driver)\
            .select_policies()\
            .wait_for_page_to_load(wait_time=10)
        return AdminPoliciesTabSteps(self.driver)

    def to_organizations_tab(self):
        AdminPortalPage(self.driver)\
            .select_organizations()\
            .wait_for_page_to_load(wait_time=10)
        return OUSTab(self.driver)

    def to_roles_tab(self):
        AdminPortalPage(self.driver)\
            .select_roles()\
            .wait_for_page_to_load(wait_time=10)
        return RolesTabPage(self.driver)

    def to_users_tab(self):
        AdminPortalPage(self.driver)\
            .select_users()\
            .validate_users_tab_is_loaded()
        return UsersTabSteps(self.driver)

    def to_downloads_page(self):
        AdminPortalPage(self.driver)\
            .select_downloads()
        return DownloadsPage(self.driver)

    def to_settings_network_tab(self):
        return AdminPortalPage(self.driver).select_settings_network()

    def to_signing_certificates_page(self):
        AdminPortalPage(self.driver)\
            .select_authentication_signing_certificates()
        return SigningCertificatesPage(self.driver)

    def to_security_settings_page(self):
        AdminPortalPage(self.driver)\
            .select_authentication_security_settings()
        return SecuritySettingsPage(self.driver)

    def to_web_app_tab(self):
        AdminPortalPage(self.driver)\
            .select_web_apps()
        return AppsPage(self.driver)

    def to_settings_users_tab(self):
        return AdminPortalPage(self.driver).select_settings_users()

    def logout_tenant(self):
        return UserProfileMenu(self.driver).sign_out()


class MfaNavigate:
    def __init__(self, driver):
        self.driver = driver

    def to_admin_portal_via_menu(self):
        UserProfileMenu(self.driver).switch_to_admin_portal()

    def to_admin_portal_via_url(self):
        self.driver.navigate_to_resource('admin')
