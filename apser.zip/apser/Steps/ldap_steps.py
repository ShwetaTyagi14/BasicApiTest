from idaptive_automation.api_helpers import AppHelper, PolicyApi, UprestHelper, RoleApi, CDirectoryService, \
    UserApi
from idaptive_automation.api_payloads import GenericUserPasswordApp, ApplicationPermissions, Grants, CloudUser, \
    OIDCApp, OAuthProfile


def add_user_password_app_to_role(fixture):
    app_api, user_api, app, role_name, user, _ = fixture
    app_id, app_name = app

    grant = Grants().with_principal(role_name) \
        .with_view_rights() \
        .with_execute_rights() \
        .with_auto_deploy()
    permissions = ApplicationPermissions().with_app_id(app_id) \
        .with_grant(grant.to_payload()) \
        .to_payload()

    app_api.set_application_permissions(permissions)

    apps = app_api.get_admin_app_list()
    assert [app for app in apps if app['Row']['Name'] == app_name] is not None
    user_session = user_api.authenticate_as_user(user['user_name'], user['password'])
    CDirectoryService(user_api.api_session).refresh_ad_user_token(user['uuid'])
    up_data = UprestHelper(user_session).get_up_data_for_user()
    assert next(iter([app for app in up_data.result()['Apps'] if app['Name'] == app_name])) is not None
    return permissions
