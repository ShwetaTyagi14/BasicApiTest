def init_nav_pinning_state(tenant_helper, current_ui_settings, pinned):
    current_ui_settings['nav-state-IsPinned'] = pinned
    tenant_helper.set_uisettings(current_ui_settings)


def init_ui_settings(tenant_helper, ui_settings):
    tenant_helper.set_uisettings(ui_settings)


def avoid_setup_popups(tenant_helper, current_ui_settings):
    current_ui_settings['doNotShowQuickstart'] = True
    current_ui_settings['doNotShowIdaptiveWelcomeWizard'] = True
    tenant_helper.set_uisettings(current_ui_settings)
