import uuid
from idaptive_automation.api_payloads import CloudUser
from Helpers.general_helpers import random_password, random_alpha, random_alphanumeric


def create_user_with_password(test_name, user_api, alias, test_password, expect_success):
    user = CloudUser(alias, f'{test_name}_{random_alphanumeric(6)}').with_password(test_password).with_display_name(test_name)

    response = user_api.create_cloud_user(user.to_payload(), False)
    if not response.success():
        print(response.message())

    assert expect_success == response.success()
    if not expect_success:
        assert 'Password does not meet policy requirements' in response.message()
