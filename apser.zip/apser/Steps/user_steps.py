from Steps.users_tab_steps import UsersTabSteps
from idaptive_automation.api_helpers import RedrockApi, UserMgmt, CDirectoryService
from idaptive_automation.api_payloads.payloads.alero_app import AleroApp
from idaptive_automation.api_client import ApiSession
from idaptive_automation.api_client.client.session_security import Security
from idaptive_automation.api_payloads.payloads.change_user_attributes import ChangeUserAttributes
from idaptive_automation.api_client.client.session_security import *
from idaptive_automation.api_payloads import *
import time


def validate_user_list(expected_users, driver):
    users_tab_steps = UsersTabSteps(driver)
    displayed_users = users_tab_steps.get_displayed_users()[1]

    assert len(displayed_users) == len(expected_users)

    for euser in expected_users:
        for duser in displayed_users:
            if duser['Username'] == euser['Username']:
                assert duser['DisplayName'] == euser['DisplayName']
                assert duser['Email'] == euser['Email']
                assert duser['SourceDsLocalized'] == euser['SourceDsLocalized']
                assert duser['Status'] == euser['Status']


def create_interactive_user_and_activate(app_helpers, alias, new_user, role_id=None):
    role_helper = app_helpers['role_helper']
    user_api = app_helpers['user_helper']
    payload = user_api.create_interactive_user(alias, new_user, send_invite=False)
    username, password = payload['Name'], payload['Password']
    if role_id is not None:
        role_helper.add_users_to_role(role_id, [payload['Uuid']])
    user_api.activate_user(username, password)
    return payload


def create_active_user_with_displayname(app_helpers, alias, new_user, displayname='Test', role_id=None,
                                        send_invite=False, assert_success=False):
    role_helper = app_helpers['role_helper']
    user_api = app_helpers['user_helper']
    payload = CloudUser(alias, new_user).with_display_name(displayname).to_payload()
    payload['SendEmailInvite'] = send_invite
    response = user_api.create_cloud_user(payload, assert_success)
    payload['Uuid'] = response.result()

    username, password = payload['Name'], payload['Password']
    if role_id is not None:
        role_helper.add_users_to_role(role_id, [payload['Uuid']])
    user_api.activate_user(username, password)
    return payload


def directory_service_user_query(cloud_user_api, directory_service, search_name):
    ds_info = cloud_user_api.get_directory_service_by_name(directory_service)
    payload = DirectoryServicesUserQuery(search_name, [ds_info['directoryServiceUuid']]).to_payload()
    ds = cloud_user_api.targeted_directory_services_query(payload).result()
    if len(ds) == 0:
        return len(ds)
    else:
        return int(ds['User']['Count'])


def change_user_full_service(app_helpers, user_id, keys_values, directory_service_uuid=None):
    admin_session = app_helpers['cloud_session']
    if directory_service_uuid is None:
        payload = {
            "Script": f"select * from User where ID = '{user_id}'",
            "Args": {"PageNumber": 1, "Limit": 1, "PageSize": 1, "Caching": -1}
        }
        response = RedrockApi(admin_session).execute_redrock_query(payload)
        directory_service_uuid = response.response['Result']['Results'][0]['Row']['DirectoryServiceUuid']

    attributes_payload = {"ID": user_id, "DirectoryServiceUuid": directory_service_uuid}

    user_attributes = UserMgmt(admin_session).get_user_attributes(payload=attributes_payload).response["Result"]

    final_payload = {
        "LoginName": user_attributes['Name'].split("@")[0],
        "Mail": user_attributes['Mail'],
        "DisplayName": user_attributes['DisplayName'],
        "CloudState": user_attributes['CloudState'],
        "PasswordNeverExpire": user_attributes['PasswordNeverExpire'],
        "ForcePasswordChangeNext": user_attributes['ForcePasswordChangeNext'],
        "InEverybodyRole": user_attributes['InEverybodyRole'],
        "OauthClient": user_attributes['OauthClient'],
        "jsutil-datacombo-1318-inputEl": "",
        "jsutil-datacombo-1332-inputEl": "",
        "ID": user_id,
        "state": user_attributes['State'],
        "jsutil-checkbox-1350-inputEl": False,
        "ReportsTo": user_attributes['ReportsTo'],
        "Name": user_attributes['Name'],
        "Password": "undefined",
        **keys_values
    }

    return CDirectoryService(admin_session).change_user(payload=final_payload)


def change_user_to_payload(app_helpers, user_id, directory_service_uuid=None):
    admin_session = app_helpers['cloud_session']
    if directory_service_uuid is None:
        payload = {
            "Script": f"select * from User where ID = '{user_id}'",
            "Args": {"PageNumber": 1, "Limit": 1, "PageSize": 1, "Caching": -1}
        }
        response = RedrockApi(admin_session).execute_redrock_query(payload)
        directory_service_uuid = response.response['Result']['Results'][0]['Row']['DirectoryServiceUuid']

    attributes_payload = {"ID": user_id, "DirectoryServiceUuid": directory_service_uuid}

    user_attributes = UserMgmt(admin_session).get_user_attributes(payload=attributes_payload).response["Result"]

    final_payload = {
        "LoginName": user_attributes['Name'].split("@")[0],
        "Mail": user_attributes['Mail'],
        "DisplayName": user_attributes['DisplayName'],
        "CloudState": user_attributes['CloudState'],
        "PasswordNeverExpire": user_attributes['PasswordNeverExpire'],
        "ForcePasswordChangeNext": user_attributes['ForcePasswordChangeNext'],
        "InEverybodyRole": user_attributes['InEverybodyRole'],
        "OauthClient": user_attributes['OauthClient'],
        "jsutil-datacombo-1318-inputEl": "",
        "jsutil-datacombo-1332-inputEl": "",
        "ID": user_id,
        "state": user_attributes['State'],
        "jsutil-checkbox-1350-inputEl": False,
        "ReportsTo": user_attributes['ReportsTo'],
        "Name": user_attributes['Name'],
        "Password": "undefined"
    }

    return final_payload


def verify_alero_response_xml(alero_xml, ad_user, email_suffix, object_guid, object_sid, distinguished_name, cn, sn,
                              given_name):
    assert 'sAMAccountName' in alero_xml
    assert ad_user in alero_xml
    assert 'userPrincipalName' in alero_xml
    assert f'{ad_user}@{email_suffix}' in alero_xml
    assert 'objectGuid' in alero_xml
    assert object_guid in alero_xml
    assert 'objectSid' in alero_xml
    assert object_sid in alero_xml
    assert 'mail' in alero_xml
    assert 'distinguishedName' in alero_xml
    assert distinguished_name in alero_xml
    assert ad_user in alero_xml
    assert 'cn' in alero_xml
    assert cn in alero_xml
    assert 'sn' in alero_xml
    assert sn in alero_xml
    assert 'givenName' in alero_xml
    assert given_name in alero_xml


def update_application_de_alero(api_session, issuer, app_id, signinurl, sp_xml):
    payload = AleroApp(issuer, app_id) \
        .with_signinurl(signinurl) \
        .with_spmetadataxml(sp_xml) \
        .to_payload()

    result = api_session.update_application_de(payload)

    assert result.response['success'], f"Failed to update Alero App {result.response['Message']}"


def create_user_and_add_to_role(app_helpers, alias, username, role_id):
    role_helper = app_helpers['role_helper']
    user_api = app_helpers['user_helper']
    response = user_api.create_interactive_user(alias, username, send_invite=False)
    role_helper.add_users_to_role(role_id, [response['Uuid']])
    return response


def validate_login_error(base_url, tenant_id, username, password, assert_success):
    api_session = ApiSession(base_url, tenant_id,
                             username, password,
                             start_auth=False, auto_auth=False)
    Security(api_session).start_authentication()
    failed_login = Security(api_session).advance_authentication(assert_success=assert_success)

    error_message = 'Authentication (login or challenge) has failed. Please try again or contact your system administrator.'
    assert failed_login[2] == error_message


def verify_ad_attribute_changes_to_cloud(attributes_payload, expected_value, user_mgmt, user_session):
    repeat = 0
    while repeat != 5:
        repeat = repeat + 1
        user_session.refresh_token()
        new_value = user_mgmt.get_user_attributes(attributes_payload)
        if expected_value == new_value.response['Result']['mobile']:
            return new_value
        else:
            time.sleep(15)
    new_value = None
    return new_value


def set_user_attributes(user_mgmt, domain_worker, base_name, uid):
    payload = ChangeUserAttributes().with_login_name(f'{base_name}user1') \
        .with_email(f'{base_name}user1@{domain_worker.email_suffix}') \
        .with_display_name(f'{base_name} user1') \
        .with_description("1234567891") \
        .with_mobile_number("8012224567") \
        .with_id(uid) \
        .to_payload()

    result = user_mgmt.change_user_attributes(payload)
    return result


def validate_user_mobile_after_mapping(user_mgmt, attributes_payload):
    result = user_mgmt.get_user_attributes(attributes_payload)
    tries = 0
    while result.response['Result']['mobile'] == '1987654321' and tries <= 10:
        result = user_mgmt.get_user_attributes(attributes_payload)
        tries += 1
    return result
