from Steps.policy_detail_steps import PolicyDetailSteps
from Steps.admin_policies_tab_steps import AdminPoliciesTabSteps


def validate_page(policy_detail_page_driver,
                  navigation_links,
                  ui_page,
                  additional_args=None):
    AdminPoliciesTabSteps(policy_detail_page_driver).open_add_policy_window()
    PolicyDetailSteps(policy_detail_page_driver).navigate(navigation_links)
    if 'CyberArk Identity' in navigation_links:
        PolicyDetailSteps(policy_detail_page_driver).enable_auth_controls(additional_args)
    page = None

    if additional_args is not None:
        page = ui_page(policy_detail_page_driver, additional_args)
    else:
        page = ui_page(policy_detail_page_driver)

    page.validate_all_elements() \
        .validate_all_child_elements()

    PolicyDetailSteps(policy_detail_page_driver).discard_changes()