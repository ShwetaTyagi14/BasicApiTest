from idaptive_automation.api_client import ApiSession


def api_session_login_attempt(app_helpers, username, password):
    user_session = ApiSession(app_helpers['tenant_info']['base_url'], app_helpers['tenant_info']['tenant_id'],
                              username, password)
    if user_session.auth_details.success:
        user_session.logout()
        return True
    else:
        return False
