import pytest
from Helpers.ad_writable_helper import MakeAdWritable
from Fixtures.sessions_and_helpers import app_helpers


@pytest.fixture()
def MakeAdWritable_fixture(app_helpers):
  with MakeAdWritable(app_helpers) as adwritable:
    yield adwritable
