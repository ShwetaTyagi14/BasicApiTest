import pytest
from idaptive_automation.api_helpers import PartnerApi
from idaptive_automation.api_payloads import PartnerCreation


@pytest.fixture()
def partner_fixture(app_helpers):
    with PartnerApi(app_helpers['cloud_session'], True) as partner_api:
        yield partner_api


@pytest.fixture()
def partner_create_fixture(app_helpers, partner_fixture):
    url = app_helpers['tenant_info']['base_url']
    partner_api = partner_fixture
    payload = PartnerCreation(url).with_federation_name('test') \
        .with_domain(["test1"]) \
        .with_idp_metadataurl('https://aap0774.my-qa.centrify.com', '49cdc216-a1bc-4201-b15e-e075a05dbcb9', 'AAP0774') \
        .to_payload()  # TO-Do: pull this value from database
    partner = partner_api.create_partner(payload)
    yield {
        'partner_api': partner_api,
        'partner': partner,
        'url': url
    }
