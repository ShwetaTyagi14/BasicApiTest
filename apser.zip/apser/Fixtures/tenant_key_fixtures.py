import pytest
from idaptive_automation.api_helpers import TenantApiHelper, UserApi
from idaptive_automation.api_helpers.helpers.ou_helper import OUHelper
from Helpers.secure_web_session_helper import empty_session, session_header
from idaptive_automation.api_helpers.helpers.user_management_helper import UserMgmt
from idaptive_automation.api_helpers.helpers.role_helper import RoleApi


@pytest.fixture
def set_role_v2_flag(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    tenant_helper.update_tenant_flag("Core.Roles.UpdateRoleV2Transition", "True")
    yield
    tenant_helper.update_tenant_flag("Core.Roles.UpdateRoleV2Transition", "False")


@pytest.fixture
def disable_validate_super_right(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    tenant_helper.update_tenant_flag("Core.Role.ValidateSuperRight", "False")
    yield
    tenant_helper.update_tenant_flag("Core.Role.ValidateSuperRight", "True")


@pytest.fixture
def sws_service_account_token(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    tenant_helper.update_tenant_flag("Core.IssueServiceTenantAccessToken.Enabled", "True")
    cloud_session = app_helpers['cloud_session']
    user_mgmt_helper = UserMgmt(cloud_session)
    response = user_mgmt_helper.get_new_sws_token()
    token = response.response['Result']['Token']
    yield token
    tenant_helper.update_tenant_flag("Core.IssueServiceTenantAccessToken.Enabled", "False")


@pytest.fixture
def enable_issue_service_tenant_access_token(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    tenant_helper.update_tenant_flag("Core.IssueServiceTenantAccessToken.Enabled", "True")
    yield
    tenant_helper.update_tenant_flag("Core.IssueServiceTenantAccessToken.Enabled", "False")


@pytest.fixture
def set_organization_feature_flag(app_helpers):
    """
    This Fixture sets 'Core.Organization.Feature.Enabled' tenant config
    Requires Core.SetTenantConfig.Whitelist.Enabled set to False
    or the Key, being updated, added to the whitelist(Core.SetTenantConfig.Whitelist.NonProd).
    """
    tenant_helper: TenantApiHelper = app_helpers['tenant_helper']
    ou_helper: OUHelper = app_helpers['ou_helper']
    _, cfgs = tenant_helper.get_customer_config()
    if cfgs['CoreDelegatedAdminEnabled'] is False:
        tenant_helper.update_tenant_flag("Core.Organization.Feature.Enabled", "True")
        ou_helper.register_cleanup(lambda: tenant_helper.delete_tenant_flag("Core.Organization.Feature.Enabled"))



@pytest.fixture(scope="session")
def set_alero_entitlement(mongo_cred_tenant, master_session, request):
    """
    For use on TCs that test Alero Integration Already Setup
    See idaptive-automation.api_helpers.app_helper.py>update_tenant_entitlement for setup instructions.
    """
    tenant_info, cloud_session, _ = mongo_cred_tenant
    with UserApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as user_helper:
        master_tenant_helper = TenantApiHelper(master_session)
        tenant_helper = TenantApiHelper(cloud_session)
        top_alias = tenant_helper.get_aliases_for_tenant()[0]
        username = f"alero-integration-user$@{top_alias}"

        # Clean up config and turn off the entitlement
        master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                       entitlement_id='78C106E2-2295-4D29-875F-8DE79377D856', enable=False)
        if not user_helper.wait_for_user_to_be_deleted(username):
            user_helper.wait_for_user_to_be_deleted(username)

        # Turn on the entitlement
        master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                       entitlement_id='78C106E2-2295-4D29-875F-8DE79377D856',
                                                       enable=True)

        if not user_helper.wait_for_user_to_exist(username):
            user_helper.wait_for_user_to_exist(username)
        # Turn off the entitlement during exit
        yield
        master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                       entitlement_id='78C106E2-2295-4D29-875F-8DE79377D856', enable=False)

        if not user_helper.wait_for_user_to_be_deleted(username):
            user_helper.wait_for_user_to_be_deleted(username)


@pytest.fixture
def set_core_directoryservices_paged_tenant_config(app_helpers):
    """
    This Fixture sets 'Core.DirectoryServices.Paged' tenant config
    Requires Core.SetTenantConfig.Whitelist.Enabled set to False
    or the Key, being updated, added to the whitelist(Core.SetTenantConfig.Whitelist.NonProd).
    """
    tenant_helper = app_helpers['tenant_helper']
    success, result = tenant_helper.update_tenant_flag("Core.DirectoryServices.Paged", "True")
    assert success is True, f"Setting Core.DirectoryServices.Paged failed. {result}"
    yield
    tenant_helper.update_tenant_flag("Core.DirectoryServices.Paged", "False")


@pytest.fixture
def set_role_protection_flag(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    yield
    tenant_helper.update_tenant_flag("Core.Roles.DeleteCheckForAssignedApplicationsOrMembers", "False")


@pytest.fixture
def set_sws_entitlement(mongo_cred_tenant, master_session, request):
    """
    For use on TCs that test SWS Integration Already Setup
    See idaptive-automation.api_helpers.app_helper.py>update_tenant_entitlement for setup instructions.
    """
    tenant_info, cloud_session, _ = mongo_cred_tenant
    with UserApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as user_helper:
        master_tenant_helper = TenantApiHelper(master_session)
        tenant_helper = TenantApiHelper(cloud_session)
        top_alias = tenant_helper.get_aliases_for_tenant()[0]
        username = f"sws-integration-user$@{top_alias}"

        # Clean up config and turn off the entitlement
        master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                       entitlement_id='78C106E2-2295-4D29-875F-8DE79377D5EC',
                                                       enable=False)
        if not user_helper.wait_for_user_to_be_deleted(username):
            user_helper.wait_for_user_to_be_deleted(username)

        # Turn on the entitlement
        master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                       entitlement_id='78C106E2-2295-4D29-875F-8DE79377D5EC',
                                                       enable=True)

        if not user_helper.wait_for_user_to_exist(username):
            user_helper.wait_for_user_to_exist(username)
        # Turn off the entitlement during exit
        yield
        master_tenant_helper.update_tenant_entitlement(tenant_id=tenant_info['tenant_id'],
                                                       entitlement_id='78C106E2-2295-4D29-875F-8DE79377D5EC',
                                                       enable=False)

        if not user_helper.wait_for_user_to_be_deleted(username):
            user_helper.wait_for_user_to_be_deleted(username)
