import copy

from idaptive_automation.api_helpers.helpers.tenant_helper import TenantApiHelper
from idaptive_automation.api_helpers import CertificateApiHelper, UserMgmt, IPRangeHelper
from Steps import ui_settings_steps
import pytest


@pytest.fixture()
def auto_cleanup_tenant_suffix_fixture(app_helpers):
    test_id = app_helpers['test_id']
    tenant_helper = app_helpers['tenant_helper']
    yield

    suffix = tenant_helper.get_aliases_for_tenant()
    delete_alias = None

    for alias in suffix:
        if test_id in alias:
            delete_alias = alias
            break

    if delete_alias is not None:
        tenant_helper.delete_alias(delete_alias)


@pytest.fixture()
def auto_cleanup_app_cert_fixture(app_helpers):
    cloud_session = app_helpers['cloud_session']
    test_id = app_helpers['test_id']
    tenant_helper = app_helpers['tenant_helper']
    cert_api = CertificateApiHelper(cloud_session)
    all_existing_certs = cert_api.get_certificates()['Results']
    for cert in all_existing_certs:
        if f"{tenant_helper.tenant_id} SHA256 Application Signing Certificate" in cert['Row']['Name']:
            default_cert = cert['Row']['Thumbprint']
    yield
    all_new_certs = cert_api.get_certificates()['Results']
    delete_cert = None

    for cert in all_new_certs:
        if cert['Row']['Thumbprint'] != default_cert:
            delete_cert = cert

    if delete_cert is not None and delete_cert['Row']['IsDefault']:
        cert_api.set_default_certificate(default_cert)

    try:
        if delete_cert is not None:
            result = cert_api.delete_certificate(delete_cert['Row']['Thumbprint'])
    except Exception as e:
        print(f"Failed to cleanup certificate. Exception: {e}")


@pytest.fixture()
def left_nav_pinning_state_fixture(app_helpers):
    user_helper = app_helpers['user_helper']
    tenant_helper = app_helpers['tenant_helper']
    cloud_session = app_helpers['cloud_session']
    user_session = user_helper.authenticate_as_user(cloud_session.username, cloud_session.password)
    current_user = UserMgmt(user_session)

    ui_settings_original = current_user.get_user_settings_ui()
    ui_settings = copy.copy(ui_settings_original)

    ui_settings_steps.init_nav_pinning_state(tenant_helper, ui_settings, pinned=True)
    ui_settings_steps.avoid_setup_popups(tenant_helper, ui_settings)
    tenant_helper.set_uisettings(ui_settings)

    yield

    ui_settings_steps.init_ui_settings(tenant_helper, ui_settings_original)


@pytest.fixture()
def auto_cleanup_corporate_ip_fixture(app_helpers):
    cloud_session = app_helpers['cloud_session']
    ip_helper = IPRangeHelper(cloud_session)
    results = ip_helper.get_corp_ip_ranges()
    if results['Count'] > 0:
        for result in results['Results']:
            ip_helper.delete_corporate_ip_range(result['Row']['ID'])
    yield

    results = ip_helper.get_corp_ip_ranges()
    if results['Count'] > 0:
        for result in results['Results']:
            ip_helper.delete_corporate_ip_range(result['Row']['ID'])


@pytest.fixture()
def auto_cleanup_blocked_ip_fixture(app_helpers):
    cloud_session = app_helpers['cloud_session']
    ip_helper = IPRangeHelper(cloud_session)
    results = ip_helper.get_blocked_ip_ranges()
    if results['Count'] > 0:
        for result in results['Results']:
            ip_helper.delete__blocked_ip_range(result['Row']['ID'])
    yield

    results = ip_helper.get_blocked_ip_ranges()
    if results['Count'] > 0:
        for result in results['Results']:
            ip_helper.delete_blocked_ip_range(result['Row']['ID'])

