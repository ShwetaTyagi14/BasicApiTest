import pytest
from Fixtures.role_fixtures import role
from idaptive_automation.api_helpers import PolicyApi, IPRangeHelper
from idaptive_automation.api_payloads import AuthenticationProfile
from Fixtures.sessions_and_helpers import *


@pytest.fixture()
def policy_fixture(app_helpers):
    policy_helper = app_helpers['policy_helper']

    yield [policy_helper]

    policy_helper._delete_policies(policy_helper.policies_created)


@pytest.fixture()
def basic_password_policy(app_helpers, unique_id):
    policy_name = f'Basic password policy {unique_id}'
    policy_helper = app_helpers['policy_helper']
    result = policy_helper.create_policy(policy_name,
                                         {
                                             "/Core/Security/CDS/PasswordPolicy/MinLength": 5,
                                             "/Core/Security/CDS/PasswordPolicy/MaxLength": 8,
                                             "/Core/Security/CDS/PasswordPolicy/RequireDigit": True,
                                             "/Core/Security/CDS/PasswordPolicy/RequireMixCase": True,
                                             "/Core/Security/CDS/PasswordPolicy/RequireSymbol": True,
                                             "/Core/Security/CDS/PasswordPolicy/AllowRepeatedChar": 3,
                                             "/Core/Security/CDS/PasswordPolicy/CheckWeakPassword": False,
                                             "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": True,
                                             "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": True,
                                             "/Core/Security/CDS/PasswordPolicy/RequireUnicode": False
                                         })
    yield result

    policy_helper.delete_policy(policy_name)


@pytest.fixture()
def weak_password_policy(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant
    policy_name = f'Weak password policy {str(uuid.uuid4())[:8]}'
    policy_api = PolicyApi(cloud_session)
    result = policy_api.create_policy(policy_name,
                                      {
                                          "/Core/Security/CDS/PasswordPolicy/MinLength": 1,
                                          "/Core/Security/CDS/PasswordPolicy/MaxLength": 18,
                                          "/Core/Security/CDS/PasswordPolicy/RequireDigit": False,
                                          "/Core/Security/CDS/PasswordPolicy/RequireMixCase": False,
                                          "/Core/Security/CDS/PasswordPolicy/RequireSymbol": False,
                                          "/Core/Security/CDS/PasswordPolicy/AllowRepeatedChar": 3,
                                          "/Core/Security/CDS/PasswordPolicy/CheckWeakPassword": False,
                                          "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": True,
                                          "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": True,
                                          "/Core/Security/CDS/PasswordPolicy/RequireUnicode": False
                                      })
    yield result

    policy_api.delete_policy(policy_name)


@pytest.fixture()
def strong_password_policy(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant
    policy_name = f'Strong password policy {str(uuid.uuid4())[:8]}'
    policy_api = PolicyApi(cloud_session)
    result = policy_api.create_policy(policy_name,
                                      {
                                          "/Core/Security/CDS/PasswordPolicy/MinLength": 1,
                                          "/Core/Security/CDS/PasswordPolicy/MaxLength": 64,
                                          "/Core/Security/CDS/PasswordPolicy/RequireDigit": True,
                                          "/Core/Security/CDS/PasswordPolicy/RequireMixCase": True,
                                          "/Core/Security/CDS/PasswordPolicy/RequireSymbol": False,
                                          "/Core/Security/CDS/PasswordPolicy/AllowRepeatedChar": True,
                                          "/Core/Security/CDS/PasswordPolicy/CheckWeakPassword": False,
                                          "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": True,
                                          "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": True,
                                          "/Core/Security/CDS/PasswordPolicy/RequireUnicode": False
                                      })
    yield result

    policy_api.delete_policy(policy_name)


@pytest.fixture()
def allow_username_password_policy(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant
    policy_name = f'Allow username in password policy {str(uuid.uuid4())[:8]}'
    policy_api = PolicyApi(cloud_session)
    result = policy_api.create_policy(policy_name,
                                      {
                                          "/Core/Security/CDS/PasswordPolicy/MinLength": 1,
                                          "/Core/Security/CDS/PasswordPolicy/MaxLength": 25,
                                          "/Core/Security/CDS/PasswordPolicy/RequireDigit": False,
                                          "/Core/Security/CDS/PasswordPolicy/RequireMixCase": False,
                                          "/Core/Security/CDS/PasswordPolicy/RequireSymbol": False,
                                          "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": True,
                                          "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": True,
                                      })
    yield result

    policy_api.delete_policy(policy_name)


@pytest.fixture()
def no_username_password_policy(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant
    policy_name = f'No username in password policy {str(uuid.uuid4())[:8]}'
    policy_api = PolicyApi(cloud_session)
    result = policy_api.create_policy(policy_name,
                                     {
                                            "/Core/Security/CDS/PasswordPolicy/MinLength": 1,
                                            "/Core/Security/CDS/PasswordPolicy/MaxLength": 25,
                                            "/Core/Security/CDS/PasswordPolicy/RequireDigit": False,
                                            "/Core/Security/CDS/PasswordPolicy/RequireMixCase": False,
                                            "/Core/Security/CDS/PasswordPolicy/RequireSymbol": False,
                                            "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": False,
                                            "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": False,
                                         })
    yield result

    policy_api.delete_policy(policy_name)


@pytest.fixture()
def require_unicode_password_policy(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant
    policy_name = f'Require unicode password policy {str(uuid.uuid4())[:8]}'
    policy_api = PolicyApi(cloud_session)
    result = policy_api.create_policy(policy_name,
                                         {
                                            "/Core/Security/CDS/PasswordPolicy/MinLength": 1,
                                            "/Core/Security/CDS/PasswordPolicy/MaxLength": 10,
                                            "/Core/Security/CDS/PasswordPolicy/RequireDigit": False,
                                            "/Core/Security/CDS/PasswordPolicy/RequireMixCase": False,
                                            "/Core/Security/CDS/PasswordPolicy/RequireSymbol": False,
                                            "/Core/Security/CDS/PasswordPolicy/AllowRepeatedChar": 3,
                                            "/Core/Security/CDS/PasswordPolicy/CheckWeakPassword": False,
                                            "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": True,
                                            "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": True,
                                            "/Core/Security/CDS/PasswordPolicy/RequireUnicode": True
                                         })
    yield result

    policy_api.delete_policy(policy_name)


@pytest.fixture()
def basic_password_history_policy(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant
    policy_name = f'History password policy {str(uuid.uuid4())[:8]}'
    policy_api = PolicyApi(cloud_session)
    result = policy_api.create_policy(policy_name,
                            {
                               "/Core/Security/CDS/PasswordPolicy/MinLength": 5,
                               "/Core/Security/CDS/PasswordPolicy/MaxLength": 16,
                               "/Core/Security/CDS/PasswordPolicy/RequireDigit": True,
                               "/Core/Security/CDS/PasswordPolicy/RequireMixCase": True,
                               "/Core/Security/CDS/PasswordPolicy/RequireSymbol": False,
                               "/Core/Security/CDS/PasswordPolicy/AllowRepeatedChar": 10,
                               "/Core/Security/CDS/PasswordPolicy/CheckWeakPassword": False,
                               "/Core/Security/CDS/PasswordPolicy/AllowIncludeUsername": True,
                               "/Core/Security/CDS/PasswordPolicy/AllowIncludeDisplayname": True,
                               "/Core/Security/CDS/PasswordPolicy/RequireUnicode": False,
                               "/Core/Security/CDS/PasswordPolicy/History": 2
                            })
    yield result

    policy_api.delete_policy(policy_name)


@pytest.fixture()
def app_policy_no_self_serve(pwd_only_profile):
    yield {
        "AuthenticationEnabled": True,
        "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
        "/Core/Security/CDS/Applications/AllowSelfService": True
    }


@pytest.fixture()
def app_policy_self_serve(pwd_only_profile):
    yield {
        "AuthenticationEnabled": True,
        "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
        "/Core/Security/CDS/Applications/AllowSelfService": False
    }

@pytest.fixture()
def policy_accoun_unlock(pwd_only_profile):
    yield {
        "AuthenticationEnabled": True,
        "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
        "/Core/Authentication/AllowZso": False,
        "PasswordResetEnabled": True,
        "/Core/PasswordReset/PasswordResetEnabled": False,
        "/Core/PasswordReset/AccountUnlockEnabled": True,
        "/Core/PasswordReset/AccountUnlockADEnabled": False,
        "/Core/PasswordReset/AccountUnlockIdentityCookieOnly": False,
        "/Core/PasswordReset/AccountUnlockAuthProfile": pwd_only_profile['Uuid']
    }


@pytest.fixture()
def pwd_only_profile(app_helpers):
    profile_helper = app_helpers['profile_helper']
    cloud_session = app_helpers['cloud_session']
    with AuthProfileHelper(cloud_session, True) as profile_helper:
        yield profile_helper.create_profile(AuthenticationProfile(f'Pwd Only Profile {app_helpers["test_id"]}')
                                            .with_challenges(["UP"])
                                            .with_duration_in_minutes(5)
                                            .to_payload())


@pytest.fixture()
def mfa_profile(app_helpers):
    with AuthProfileHelper(app_helpers['cloud_session'], True) as profile_helper:
        yield profile_helper.create_profile(AuthenticationProfile(f'{app_helpers["test_id"]} MFA Profile')
                                            .with_challenges(["SQ"])
                                            .with_additional_data("NumberOfQuestions", 1)
                                            .with_duration_in_minutes(5)
                                            .to_payload())


@pytest.fixture()
def authentication_rules_policy(pwd_only_profile):
    yield {
        "AuthenticationEnabled": True,
        "/Core/Authentication/AuthenticationRulesDefaultProfileId": pwd_only_profile['Uuid'],
    }


@pytest.fixture()
def ensure_current_ip_not_in_corp_range(app_helpers, driver):
    ip_helper = IPRangeHelper(app_helpers['cloud_session'])
    corp_ranges = [r['Row']['ID'] for r in ip_helper.get_corp_ip_ranges()['Results']]
    assert driver.current_ip not in corp_ranges, 'Test cannot be run. Current IP is part of corp IP range'


@pytest.fixture()
def current_ip_in_corp_range(app_helpers, driver):
    with IPRangeHelper(app_helpers['cloud_session'], True) as ip_helper:
        corp_ranges = [r['Row']['ID'] for r in ip_helper.get_corp_ip_ranges()['Results']]
        if driver.current_ip not in corp_ranges:
            ip_helper.add_corp_ip_range(app_helpers['test_id'], driver.current_ip)
        yield ip_helper
