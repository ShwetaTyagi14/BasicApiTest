import pytest
from selenium import webdriver
from app_services_driver import AppServicesDriver as Driver
from Steps.navigate_steps import Login
from Fixtures.sessions_and_helpers import *


@pytest.yield_fixture(params=[
    'Chrome',
    # 'Firefox'
])
def user_portal_driver(request, app_helpers, screenshots):
    tenant_helper = app_helpers['tenant_helper']
    options = None
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    if request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=tenant_helper.api_session.base_url,
                case_number='null', screenshots=screenshots) as browser:
        browser.maximize_window()

        yield browser
