import pytest
from idaptive_automation.api_payloads import GenericUserPasswordApp, ApplicationPermissions, Grants
from Fixtures.sessions_and_helpers import *
from idaptive_automation.api_helpers import AppHelper, TenantApiHelper, UprestHelper
from Helpers.test_data_helper import get_file_path


def first_or_default(source_list, predicate):
    filtered_list = list(filter(lambda x: predicate(x), source_list))
    return filtered_list[0] if len(filtered_list) > 0 else None


@pytest.fixture()
def app_fixture(app_helpers):
    tenant_helper = app_helpers['tenant_helper']
    app_api = app_helpers['app_helper']
    user_api = app_helpers['user_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]

    yield [app_api, user_api, alias]


@pytest.fixture()
def app_role_fixture(app_helpers):
    app_api = app_helpers['app_helper']
    user_api = app_helpers['user_helper']
    role_api = app_helpers['role_helper']
    policy_api = app_helpers['policy_helper']
    tenant_helper = app_helpers['tenant_helper']
    alias = tenant_helper.get_aliases_for_tenant()[0]

    yield [app_api, user_api, role_api, policy_api, alias]

@pytest.fixture()
def app_templates(request, mongo_cred_tenant):
    tenant_info, cloud_session, mongo_cred = mongo_cred_tenant
    templates = AppHelper(cloud_session).get_templates_and_categories()
    yield [entity['Entities'][00]['Key'] for entity in templates['AppTemplates']['Results']]
    
    
@pytest.fixture()
def apps_deployed_to_cloud_role_api_fixture(app_helpers):
    cloud_session = app_helpers['cloud_session']
    test_id = app_helpers['test_id']
    test_password = 'testTEST1234'

    alias = TenantApiHelper(cloud_session).get_aliases_for_tenant()[0]
    with UserApi(cloud_session, True) as user_api,\
            AppHelper(cloud_session, True) as app_api,\
            RoleApi(cloud_session, True) as role_api,\
            PolicyApi(cloud_session, True) as policy_api:

        users = []
        roles = []
        for n in range(2):
            username = f'automation-user-{n}-{test_id}'
            display_name = f"Automation {n} {alias} {test_id}"
            payload = CloudUser(alias, username)\
                .with_password_never_expire(True)\
                .with_password(test_password)\
                .with_display_name(display_name)\
                .to_payload()
            uuid = user_api.create_cloud_user(payload).result()
            payload['uuid'] = uuid
            users.append(payload)

            role_name = f'Test Role for user{n} {test_id}'
            role_id = role_api.create_role_if_not_exists(role_name)
            role_api.add_users_to_automation_role([uuid])
            role_api.add_users_to_role(role_id, [uuid])
            roles.append({
                'name': role_name,
                'id': role_id,
                'principals': [payload]
            })

        deployed_apps = []
        for n in range(5):
            app_name = f'Test App number {n} {test_id}'
            app_descrition = f'Test App number {n}'
            app_url = 'https://google.com'
            app_id = app_api.import_username_password_app()

            app = GenericUserPasswordApp(app_id).with_url(app_url)\
                                                .with_description(app_descrition)\
                                                .with_name(app_name)\
                                                .with_fixed_username('testusername', 'testpassword')\
                                                .to_payload()

            app_api.update_application_de(app)

            permissions = ApplicationPermissions().with_app_id(app_id)
            for role in roles:
                grant = Grants().with_principal(role['name']) \
                    .with_view_rights() \
                    .with_execute_rights() \
                    .with_auto_deploy()
                permissions = permissions.with_grant(grant.to_payload())
            permissions = permissions.to_payload()

            app_api.set_application_permissions(permissions)
            deployed_apps.append({
                'name': app_name,
                'id': app_id,
                'app': app,
                'permissions': permissions
            })

        user_session = user_api.authenticate_as_user(payload['Name'], test_password)
        up_data = UprestHelper(user_session).get_up_data_for_user()

        for entry in deployed_apps:
            assert next(iter([app for app in up_data.result()['Apps'] if app['Name'] == entry['name']])) is not None

        yield [role_id, alias, users, roles, deployed_apps]


@pytest.fixture()
def app_templates(app_helpers):
    templates = AppHelper(app_helpers['cloud_session']).get_templates_and_categories()
    yield [entity['Entities'][00]['Key'] for entity in templates['AppTemplates']['Results']]


@pytest.fixture()
def auto_clean_app_fixture(app_helpers):
    app_api = app_helpers['app_helper']
    apps_before_test = [app["Row"]["ID"] for app in app_api.get_admin_app_list()]

    yield app_api

    apps_after_test = app_api.get_admin_app_list()

    apps_to_delete = []
    linked_apps = []
    apps_with_child_apps = []
    for app in [app for app in apps_after_test if app["Row"]["ID"] not in apps_before_test]:
        apps_to_delete.append(app)

    for app in [app for app in apps_to_delete if app["Row"]["ChildLinkedApps"] is not None]:
        apps_with_child_apps.append(app)

    for app in apps_with_child_apps:
        if app["Row"]["ChildLinkedApps"] is not '':
            linked_apps.append(app["Row"]["ChildLinkedApps"])

    if linked_apps.__len__() != 0:
        linked_apps = str(linked_apps)[2:-2].split(",")
        for app in linked_apps:
            app_api.delete_application(app, assert_success=False)
    for app in [app for app in apps_to_delete if app["Row"]["ID"] not in linked_apps]:
        app_api.delete_application(app["Row"]["ID"])


@pytest.fixture()
def create_generic_wsfed_app(app_helpers):
    cloud_session = app_helpers['cloud_session']
    tenant_info = app_helpers['tenant_info']
    app_api = AppHelper(cloud_session)
    user_api = UserApi(cloud_session)
    user_session = user_api.authenticate_as_user(tenant_info['username'],
                                                 tenant_info['password'])
    response = TenantApiHelper(user_session).get_tenant_certificate()
    cert_thumbprint = response['Results'][0]['Row']['Thumbprint']
    app_id = app_api.import_app_by_name("GenericWsFed")
    payload = {
        "Url": "https://www.google.com",
        "Issuer": f"{tenant_info['base_url']}/{app_id}",
        "SamlScript": "@GenericWsFed",
        "jsutil-enhancetext-2151-inputEl": f"{tenant_info['base_url']}/applogin/appKey/{app_id}/customerId/{tenant_info['tenant_id']}",
        "jsutil-enhancetext-2156-inputEl": f"{tenant_info['base_url']}/applogout",
        "Thumbprint": cert_thumbprint,
        "ServiceName": "",
        "ShowInUP": True,
        "_RowKey": app_id}
    result = app_api.update_application_de(payload)
    assert result.response['success'] is True


@pytest.fixture()
def certificate_file_path():
    yield get_file_path('idp.centrify.com.pfx', "Certificates")
