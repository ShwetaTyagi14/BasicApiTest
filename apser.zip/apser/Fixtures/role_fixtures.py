import pytest
from Fixtures.sessions_and_helpers import *
from idaptive_automation.api_helpers import RoleApi


@pytest.fixture()
def role(app_helpers, unique_id):
    role_helper = app_helpers['role_helper']
    role_uuid = role_helper.create_role_if_not_exists(f'Test Role {unique_id}')

    yield role_uuid


@pytest.fixture()
def auto_cleanup_role_fixture(app_helpers):
    test_id = app_helpers['test_id']
    role_api = app_helpers['role_helper']

    yield role_api

    roles = role_api.get_all_roles()
    new_role = None

    for role in roles:
        if test_id in role['Name']:
            new_role = role
            break

    if new_role is not None:
        role_api.delete_role(new_role['ID'])
