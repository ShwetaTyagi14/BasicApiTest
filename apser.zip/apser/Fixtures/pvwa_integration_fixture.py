import pytest
from Helpers.pvwa_helpers import PVWA
from Fixtures.sessions_and_helpers import app_helpers


@pytest.fixture()
def PVWA_fixture(app_helpers):
  with PVWA(app_helpers) as pvwa:
    yield pvwa
