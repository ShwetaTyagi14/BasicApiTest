import pytest
from Fixtures.sessions_and_helpers import *
from idaptive_automation.api_payloads import SecurityQuestions
from idaptive_automation.api_helpers import UserMgmt


@pytest.fixture()
def current_ds_order(app_helpers):
    user_api = app_helpers['user_helper']
    results = user_api.get_directory_services_info()

    ds_ids = [r['directoryServiceUuid'] for r in results]
    if len(ds_ids) < 4:
        assert False, 'This test requires at least 2 Directory Services not including CDS and FDS'
    yield ds_ids

    ds_api = app_helpers['directory_services_helper']
    ds_api.set_directory_service_order(ds_ids)


@pytest.fixture()
def setup_users(app_helpers):
    alias = app_helpers['alias']
    user_api = app_helpers['user_helper']
    cloud_session = app_helpers['cloud_session']

    user_api.create_invited_user(alias, 'c33448-invited')
    user_api.create_service_user(alias, 'c33448-service')

    payload = user_api.create_interactive_user(alias, 'c33448-active', send_invite=False)
    username, password = payload['Name'], payload['Password']
    RoleApi(cloud_session).add_users_to_automation_role([payload['Uuid']])
    user_api.activate_user(username, password)

    payload = user_api.create_interactive_user(alias, 'c33448-suspended', send_invite=False)
    username = payload['Name']
    user_api.lock_user_account(username)
    return user_api


@pytest.fixture()
def user_with_sqs(new_cloud_user_in_role_with_policy_fixture, app_helpers):
    test_id = app_helpers['test_id']
    tenant_info = app_helpers['tenant_info']
    sec_question = {'question': 'Case number', 'answer': test_id}
    payload = SecurityQuestions().with_user_question(sec_question)\
        .to_payload()

    UserMgmt(ApiSession(tenant_info['base_url'],
                        tenant_info['tenant_id'],
                        new_cloud_user_in_role_with_policy_fixture['Name'],
                        new_cloud_user_in_role_with_policy_fixture['Password'])).update_security_questions(payload)
    yield new_cloud_user_in_role_with_policy_fixture
