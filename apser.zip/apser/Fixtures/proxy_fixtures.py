import pytest
from idaptive_automation.api_helpers import ProxyApi


@pytest.fixture()
def all_proxies_for_tenant(session_fixture):
    proxies = ProxyApi(session_fixture['session']).get_all_proxies()
    return [{
        'Name': p['Name'],
        'Hostname': p['MachineName'],
        'Uuid': p['ID'],
        'Version': p['Version'],
        'IsOnline': p['Online'],
        'IsGatewayCapable': p['AppGateway'] == 'Enabled',
        'IsPreferred': False,
        'ErrorMessage': None
    } for p in proxies]
