import re
import uuid
import pytest
from idaptive_automation.api_client import ApiSession
from idaptive_automation.api_helpers import UserApi, RoleApi, AppHelper, ProvisioningApi, UserProvisioningHelper, \
    CDirectoryService, RedrockApi, O365Api, ActiveDirectoryHelper, TenantApiHelper, PolicyApi, LdapServer, \
    AuthProfileHelper, DirectoryServicesApi, OUHelper, UserMgmt
from idaptive_automation.api_payloads import CloudUser
from idaptive_automation.api_payloads.payloads.security.oauth2_authentication import Oauth2Authentication
from mongocred.mongocred import MongoCred
from idaptive_automation.api_helpers.helpers.session_security import Security
from Fixtures.tenant_key_fixtures import set_alero_entitlement
from Fixtures.tenant_key_fixtures import set_sws_entitlement


@pytest.fixture(scope="session")
def mongo_cred_tenant(request):
    mongo_cred = MongoCred()
    tenant_info = mongo_cred.get_tenant_credentials(env=request.config.getoption('--env')[0],
                                                    tenant_id=request.config.getoption('--tenant')[0])
    tenant_session = ApiSession(
        base_url=tenant_info['base_url'],
        tenant_id=tenant_info['tenant_id'],
        username=tenant_info['username'],
        password=tenant_info['password'],
        db_metrics=request.config.getoption('--get_metrics')
    )
    yield tenant_info, tenant_session, mongo_cred


@pytest.fixture()
def cloud_session(mongo_cred_tenant):
    _, cloud_session, _ = mongo_cred_tenant

    yield cloud_session


@pytest.fixture()
def app_helpers(mongo_cred_tenant, request):
    tenant_info, cloud_session, _ = mongo_cred_tenant
    helpers = {}
    with UserApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as user_helper, \
            AppHelper(session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as app_helper, \
            RoleApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as role_helper, \
            AuthProfileHelper(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as profile_helper, \
            PolicyApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as policy_helper, \
            OUHelper(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as ou_helper:
        role_helper.create_role_if_not_exists(role_name='App Services Automation', cleanup=False)
        tenant_helper = TenantApiHelper(cloud_session)
        directory_services_helper = DirectoryServicesApi(cloud_session)
        alias = tenant_helper.get_aliases_for_tenant()[0]
        helpers['user_helper'] = user_helper
        helpers['app_helper'] = app_helper
        helpers['tenant_helper'] = tenant_helper
        helpers['role_helper'] = role_helper
        helpers['policy_helper'] = policy_helper
        helpers['profile_helper'] = profile_helper
        helpers['directory_services_helper'] = directory_services_helper
        helpers['ou_helper'] = ou_helper
        helpers['cloud_session'] = cloud_session
        helpers['tenant_info'] = tenant_info
        helpers['test_id'] = str(uuid.uuid4())[0:8]
        helpers['alias'] = alias
        yield helpers


@pytest.fixture()
def lcm_helpers(mongo_cred_tenant, request):
    tenant_info, cloud_session, _ = mongo_cred_tenant
    helpers = {}
    with UserApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as user_helper, \
            RoleApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as role_helper, \
            AppHelper(session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as app_helper, \
            ProvisioningApi(api_session=cloud_session, auto_clean=request.config.getoption('--get_auto_clean')) as provisioning_helper, \
            CDirectoryService(api_session=cloud_session,
                              auto_clean=request.config.getoption('--get_auto_clean')) as cdirectory_helper, \
            UserProvisioningHelper(session=cloud_session, db_metrics=False) as user_prov_helper, \
            O365Api(api_session=cloud_session) as o365_helper:
        helpers['user_helper'] = user_helper
        helpers['role_helper'] = role_helper
        helpers['app_helper'] = app_helper
        helpers['redrock_helper'] = RedrockApi(api_session=cloud_session)
        helpers['cdirectory_helper'] = cdirectory_helper
        helpers['user_prov_helper'] = user_prov_helper
        helpers['provisioning_helper'] = provisioning_helper
        helpers['o365_helper'] = o365_helper

        try:
            with ActiveDirectoryHelper(server_address=tenant_info['domain_controller']['server_address'],
                                       domain_name=tenant_info['domain_controller']['domain_name'],
                                       domain_suffix=tenant_info['domain_controller']['domain_suffix'],
                                       email_suffix=tenant_info['domain_controller']['default_email_suffix'],
                                       username=tenant_info['domain_controller']['username'],
                                       password=tenant_info['domain_controller']['password'],
                                       auto_clean=True) as active_directory_helper:
                helpers['active_directory_helper'] = active_directory_helper
        except:
            # Not every test is going to require an AD instance so if we are unable
            # to connect to the DC go ahead and try to execute the test run anyways
            helpers['active_directory_helper'] = None
        yield helpers
        if helpers['active_directory_helper'] is not None:
            active_directory_helper.clean_domain_environment()


@pytest.fixture()
def create_user_role_pairing(mongo_cred_tenant, lcm_helpers):
    tenant_info, _, _ = mongo_cred_tenant
    name_base = f"{tenant_info['tenant_id'].lower()}.{str(uuid.uuid4())[0:4]}"
    role = dict(role_name=f'{name_base}.role', role_id=lcm_helpers['role_helper'].create_role(f'{name_base}.role'))
    user = CloudUser(
        tenant_info['domain_controller']['default_login_suffix'],
        f"{name_base}.user"
    )
    user.email = f"{user.login_name}@{tenant_info['domain_controller']['default_email_suffix']}"
    user.display_name = name_base
    user_info = dict(user=user, user_id=lcm_helpers['user_helper'].create_cloud_user(user.to_payload()).response['Result'])
    yield role, user_info


@pytest.fixture()
def create_ad_user_role_paring(request, mongo_cred_tenant, lcm_helpers):
    tenant_info, _, _ = mongo_cred_tenant
    name_base = f"{tenant_info['tenant_id'].lower()}.{str(uuid.uuid4())[0:4]}"
    role = dict(role_name=f'{name_base}.role', role_id=lcm_helpers['role_helper'].create_role(f'{name_base}.role'))

    environment_group_count = 1
    if 'environment_group_objects' in request.fixturenames:
        environment_group_count = request.getfixturevalue('environment_group_objects')
    environment_user_count = 1
    if 'environment_user_objects' in request.fixturenames:
        environment_user_count = request.getfixturevalue('environment_user_objects')

    lcm_helpers['active_directory_helper'].create_ad_environment(
        base_name=name_base,
        default_password='testTEST1234!@',
        num_groups=environment_group_count,
        num_users=environment_user_count
    )
    groups = lcm_helpers['active_directory_helper'].get_ad_group_details(name_base)
    yield role, groups, name_base


@pytest.fixture()
def create_ad_domain_admin(request, mongo_cred_tenant, lcm_helpers):
    tenant_info, _, _ = mongo_cred_tenant
    user_name = f"{tenant_info['tenant_id']}.{str(uuid.uuid4())[0:4]}.user"

    ou_name = f"{tenant_info['tenant_id']}.{str(uuid.uuid4())[0:4]}"
    lcm_helpers['active_directory_helper'].create_basic_ad_ou(ou_name)
    lcm_helpers['active_directory_helper'].create_admin_user(
        user_name,
        f"OU={ou_name},DC={tenant_info['domain_controller']['domain_name']},DC={tenant_info['domain_controller']['domain_suffix']}"
    )
    user = lcm_helpers['active_directory_helper'].get_ad_ou_users(ou_name)[0]
    yield user, lcm_helpers['active_directory_helper'], lcm_helpers


@pytest.fixture()
def create_app_ldap_environment(request, mongo_cred_tenant):
    tenant_info, cloud_session, _ = mongo_cred_tenant
    test_name = request.node.originalname or request.node.name
    m = re.match(r'test_(c\d{5,})_', test_name)
    test_number = m.group(1)
    assert m is not None and test_number is not None

    with LdapServer(server_name=tenant_info['domain_controller']['server_address'],
                    user=tenant_info['username'],
                    password=tenant_info['password'],
                    auto_clean=True) as ldap_helper:
        ou_name = f'{test_number}.org'
        group_name = f'Group {test_number}'
        user_name = f'test-user-{test_number}'
        role_name = f'test-role-{test_number}'


@pytest.fixture(scope="session")
def master_session(mongo_cred_tenant):
    """
    master_session pulls creds under "master_tenant" in mongo.
    Specifically for testing on child tenants, while configuring child tenants via the master tenant
    See tenant_id: AAF7550 in devdog for an example configuration
    """
    tenant_info, _, _ = mongo_cred_tenant
    master_session = ApiSession(
        base_url=tenant_info['master_tenant']['base_url'],
        tenant_id=tenant_info['master_tenant']['tenant_id'],
        username=tenant_info['master_tenant']['username'],
        password=tenant_info['master_tenant']['password'],
        db_metrics=False
    )
    yield master_session


@pytest.fixture()
def oauth_session_sws(app_helpers, request, set_sws_entitlement):
    helpers = app_helpers
    tenant_info = helpers['tenant_info']
    user_helper = app_helpers['user_helper']
    cloud_session = app_helpers['cloud_session']
    tenant_helper = app_helpers['tenant_helper']

    oauth_session = ApiSession(
        base_url=tenant_info['base_url'],
        tenant_id=tenant_info['tenant_id'],
        username=tenant_info['username'],
        password=tenant_info['password'],
        db_metrics=request.config.getoption('--get_metrics'),
        start_auth=False
    )

    top_alias = tenant_helper.get_aliases_for_tenant()[0]
    username = f"sws-integration-user$@{top_alias}"
    response = user_helper.get_user_info(username)
    user_id = response['Row']['ID']
    UserMgmt(cloud_session).reset_user_password(user_id, 'testTEST1234')
    authentication_payload = Oauth2Authentication(grant_type="client_credentials", scope="sws",
                                                  client_id=username, client_secret='testTEST1234').to_payload()
    oauth2_token = Security(cloud_session).oauth2_token_authentication(oauth_session,
                                                                       authentication_payload,
                                                                       oauth2_path="__idaptive_sws_integration")
    assert oauth2_token is not None

    yield helpers, oauth_session


@pytest.fixture()
def oauth_session_alero(app_helpers, request, set_alero_entitlement):
    helpers = app_helpers
    tenant_info = helpers['tenant_info']
    user_helper = app_helpers['user_helper']
    cloud_session = app_helpers['cloud_session']
    tenant_helper = app_helpers['tenant_helper']

    oauth_session = ApiSession(
        base_url=tenant_info['base_url'],
        tenant_id=tenant_info['tenant_id'],
        username=tenant_info['username'],
        password=tenant_info['password'],
        db_metrics=request.config.getoption('--get_metrics'),
        start_auth=False
    )

    top_alias = tenant_helper.get_aliases_for_tenant()[0]
    username = f"alero-integration-user$@{top_alias}"
    response = user_helper.get_user_info(username)
    user_id = response['Row']['ID']
    UserMgmt(cloud_session).reset_user_password(user_id, 'testTEST1234')
    authentication_payload = Oauth2Authentication(grant_type="client_credentials", scope="alero",
                                                  client_id=username, client_secret='testTEST1234').to_payload()
    oauth2_token = Security(cloud_session).oauth2_token_authentication(oauth_session,
                                                                       authentication_payload,
                                                                       oauth2_path="__idaptive_alero_integration")
    assert oauth2_token is not None

    yield helpers, oauth_session

