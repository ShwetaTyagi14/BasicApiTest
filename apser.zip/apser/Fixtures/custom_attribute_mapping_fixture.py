import pytest
from Helpers.custom_attribute_mapping_helper import CustomADMapping
from Fixtures.sessions_and_helpers import app_helpers
from Fixtures.sessions_and_helpers import lcm_helpers
from idaptive_automation.api_helpers import UserMgmt
import uuid


@pytest.fixture()
def CustomADMapping_fixture(app_helpers, lcm_helpers):
    with CustomADMapping(app_helpers, lcm_helpers) as admapping:
        yield admapping
