import os
import json
import tempfile
import ntpath
from pathlib import Path
from idaptive_automation.api_helpers import UserApi, RedrockApi
import time


def get_test_data_dir():
    if 'APITESTDATADIRECTORY' not in os.environ:
        path = os.path.dirname(__file__)
        test_data_dir = os.path.join(Path(path).parent, 'TestData')
    else:
        test_data_dir = str(os.environ['APITESTDATADIRECTORY'])
    return test_data_dir


def load_json_test_data_file(json_file, sub_dir=None):
    file_dir = get_test_data_dir()
    if sub_dir:
        final_path = os.path.join(file_dir, sub_dir, json_file)
    else:
        final_path = os.path.join(file_dir, json_file)

    return json.load(open(final_path))


def prepare_app_payload(payload, tenant_info, app_id, cert_thumbprint):
    if "Issuer" in payload:
        payload['Issuer'] = payload['Issuer'].format(tenant_info['base_url'], app_id)
    if "Thumbprint" in payload:
        payload["Thumbprint"] = cert_thumbprint
    if "_RowKey" in payload:
        payload["_RowKey"] = app_id
    if "jsutil-enhancetext-2151-inputEl" in payload:
        payload["jsutil-enhancetext-2151-inputEl"] = payload["jsutil-enhancetext-2151-inputEl"].format(tenant_info['base_url'], app_id, tenant_info['tenant_id'])
    if "jsutil-enhancetext-2156-inputEl" in payload:
        payload["jsutil-enhancetext-2156-inputEl"] = payload["jsutil-enhancetext-2156-inputEl"].format(tenant_info['base_url'])

    return payload


def write_bulk_users_to_file(file_name, test_name, number_users, alias):
    temp_file, file_path = tempfile.mkstemp(prefix=file_name, suffix='.csv')
    temp_file_elements = load_json_test_data_file('../TestData/TempFiles/tempelements.json')
    with open(file_path, 'w') as file:
        file.write(temp_file_elements['BulkHeader'])
        [file.write(temp_file_elements['Line'].format(test_name, line, alias, line, line, line))
         for line in range(1, number_users + 1)]
    os.close(temp_file)
    _, final_name = ntpath.split(file_path)
    return file_path, final_name


def write_user_payload_to_file(file_name, payload):
    temp_file, file_path = tempfile.mkstemp(prefix=file_name, suffix='.csv')
    temp_file_elements = load_json_test_data_file('../TestData/TempFiles/tempelements.json')
    with open(file_path, 'w') as file:
        file.write(temp_file_elements['BulkHeader'])
        file.write(payload)
    os.close(temp_file)
    _, final_name = ntpath.split(file_path)
    return file_path, final_name


def get_import_app_file_path(file_name):
    test_data_dir = get_test_data_dir()
    file_dir = os.path.join(test_data_dir, 'Applications')
    if not os.path.exists(file_dir):
        raise EnvironmentError(f'There is no "{test_data_dir}\\Applications" directory, importable Apps must be located here')
    return os.path.join(file_dir, file_name)


def get_file_path(file_name, sub_directory=None):
    test_data_dir = get_test_data_dir()
    file_dir = test_data_dir
    if sub_directory:
        file_dir = os.path.join(test_data_dir, sub_directory)
    if not os.path.exists(file_dir):
        raise EnvironmentError(f'There is no "{file_dir}" directory')
    return os.path.join(file_dir, file_name)


def read_bulk_users_import_file(file_name, directory):
    file_path = os.path.join(directory, file_name)
    content = open(file_path, 'r')
    return content.readlines()


def bulk_submit_retry(return_id, credentials, cloud_session, wait_time=120):
    """
    Bulk Import Collision Detection and Avoidance System.  Or BICDAS for Short.
    Calls 'UserApi.submit_bulk_users' and if blocked by another bulk import,
    tries submitting every 10 seconds, until exhausting 'wait_time'
    :param return_id: the id of the file
    :param credentials: the email to notify once the job is complete
    :param cloud_session: Logged in user Session
    :param wait_time: (Default 120) Max time to wait in seconds for the Bulk Import Collision to resolve
    :return: The full response in the format of an APIResponse object
    """
    response = UserApi(cloud_session).submit_bulk_users(return_id,
                                          credentials,
                                          False,
                                          False)
    if not response.success():
        if response.message() == 'There is already a bulk user import job in process. Please wait for the job to complete and try again.':
            payload = {
                "Script": f"SELECT Count(*) as thecount FROM JobHistory WHERE JobGroup = 'BulkUserImportJobGroup' AND EndedAt is Null",
                "Args": {"PageNumber": 1, "Limit": 1, "PageSize": 1, "Caching": -1}
            }
            redrock_response = 1
            while wait_time > 0 and (redrock_response > 0) and not response.success():
                redrock_response = RedrockApi(cloud_session).execute_redrock_query(payload).results()[0]['Row']['thecount']
                if int(redrock_response) < 1:
                    response = UserApi(cloud_session).submit_bulk_users(return_id,
                                                          credentials,
                                                          False,
                                                          False)
                else:
                    time.sleep(10)
                    wait_time -= 10
    return response


def prepare_oidc_app_payload(oidc_app_payload, app_id, app_name, client_secret, index_page_uri, base_url):
    oidc_app_payload["ServiceName"] = app_name
    oidc_app_payload["OAuthProfile"]["ClientSecret"] = client_secret
    oidc_app_payload["OAuthProfile"]["Redirects"] = [index_page_uri]
    oidc_app_payload["OAuthProfile"]["Audience"] = app_id
    oidc_app_payload["OAuthProfile"]["Issuer"] = base_url + "/"
    oidc_app_payload["OAuthProfile"]["IssuerTemplate"] = base_url + "/{0}/"
    oidc_app_payload["OAuthProfile"]["ClientID"] = app_id
    oidc_app_payload["OAuthProfile"]["ID"] = app_id
    oidc_app_payload["_RowKey"] = app_id


def prepare_oidc_client_payload(oidc_client_payload, app_id, app_name, base_url, client_secret, redirect_uri):
    oidc_client_payload["app_name"] = app_name
    oidc_client_payload["base_url"] = base_url
    oidc_client_payload["client_id"] = app_id
    oidc_client_payload["client_secret"] = client_secret
    oidc_client_payload["redirect_uri"] = redirect_uri