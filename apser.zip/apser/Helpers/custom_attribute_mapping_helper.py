from idaptive_automation.api_payloads.payloads.set_custom_ad_mapping import SetCustomAdMapping
from Fixtures.sessions_and_helpers import app_helpers
from Fixtures.sessions_and_helpers import lcm_helpers
from idaptive_automation.api_helpers import UserMgmt
import uuid
from idaptive_automation.api_payloads import InviteUser


class CustomADMapping:

    def __init__(self, app_helpers, lcm_helpers):
        self.app_helpers = app_helpers
        self.user_helpers = app_helpers['user_helper']
        self.domain_worker = lcm_helpers['active_directory_helper']
        self.base_name = ""

    def enable_custom_mapping(self, cloud_attribute="mobile", ad_attribute="description", user_editable="true", other_user_editable="true"):
        key = "Core.DirectoryServices.ActiveDirectory.PropToAttrMultimap.Default"
        payload = SetCustomAdMapping().with_cloud_attribute(cloud_attribute)\
            .with_ad_attribute(ad_attribute).with_user_editable(user_editable)\
            .with_other_user_editable(other_user_editable).to_payload()
        result = self.app_helpers['tenant_helper'].update_tenant_flag(key, payload)
        return result.response['success']

    def setup_ad_for_mapping(self):
        password = "testTEST1234"
        session = self.app_helpers['cloud_session']
        user_helper = self.app_helpers['user_helper']
        user_mgmt = UserMgmt(session)
        domain_worker = self.domain_worker
        base_name = str(uuid.uuid4())[0:8]
        self.base_name = base_name
        domain_worker.create_ad_environment(base_name, password)
        ad_user = f"{base_name}user1"
        ou = domain_worker.created_ou_list[0].split(',')
        domain_worker.modify_ad_user_attribute(f'{ad_user}', ou[0], 'description', '1234567891')
        domain_worker.modify_ad_user_attribute(f'{ad_user}', ou[0], 'telephoneNumber', '1234567891')
        domain_worker.modify_ad_user_attribute(f'{ad_user}', ou[0], 'mobile', '1987654321')
        uid = domain_worker.get_ad_user_attribute(f'{ad_user}', ou[0], 'objectGUID')
        uid = uid.values[0][1:-1]
        invite_payload = InviteUser(ad_user, uid).to_payload()
        user_mgmt.invite_user(invite_payload)
        return domain_worker, user_mgmt, ad_user, uid

    def disable_custom_mapping(self, assert_success=True):
        key = "Core.DirectoryServices.ActiveDirectory.PropToAttrMultimap.Default"
        result = self.app_helpers['tenant_helper'].delete_tenant_flag(key)
        if assert_success:
            assert result is None
        return result

    def remove_ad_user_from_portal(self, user_helper, base_name, domain_worker):
        user_helper.wait_for_user_and_delete(f"{base_name}user1@{domain_worker.email_suffix}")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disable_custom_mapping()
        self.remove_ad_user_from_portal(self.user_helpers, self.base_name, self.domain_worker)