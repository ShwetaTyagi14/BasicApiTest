from idaptive_automation.api_payloads.payloads.set_customer_config import SetCustomerConfig

# TODO This will change on 5/11 to use an entitlement vs the config flag, so we need to fix these.


class PVWA:

    def __init__(self, app_helpers):
        self.app_helpers = app_helpers

    def enable_pvwa(self, corporate=True, personal=True):
        payload = SetCustomerConfig().with_personal_app(personal)\
            .with_corporate_app(corporate)\
            .to_payload()
        result, message = self.app_helpers['tenant_helper'].set_customer_config(payload)
        assert result is True
        return result, message

    def disable_pvwa(self, corporate=False, personal=False):
        payload = SetCustomerConfig().with_personal_app(personal) \
            .with_corporate_app(corporate) \
            .to_payload()
        result, message = self.app_helpers['tenant_helper'].set_customer_config(payload)
        assert result is True
        return result, message

    def get_tenant_config(self):
        result, message = self.app_helpers['tenant_helper'].get_customer_config()
        return result, message

    def create_app(self, app_type):
        app_helper = self.app_helpers['app_helper']
        app = app_helper.import_app_by_name(app_type)
        assert app is not None
        return app

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disable_pvwa()




