from flask import render_template
from flask import Flask, request
import requests
import urllib

app = Flask(__name__)

all_configs = {}

@app.route('/')
def index():
    port = int(request.host.split(':')[1])
    config = all_configs[port]

    url = config['base_url'] + '/oauth2/authorize/' + config['app_name']
    params = {
        'redirect_uri': config['redirect_uri'],
        'client_id': config['client_id'],
        'response_type': 'code',
        'scope': config['scope']}
    return render_template('index.html', title='OpenIDConnect', url=url, params=urllib.parse.urlencode(params))


@app.route('/callback')
def callback():
    port = int(request.host.split(':')[1])
    config = all_configs[port]

    code = request.args.get('code')
    url = config['base_url'] + '/oauth2/token/' + config['app_name']
    header_data = {
        'Content-type': 'application/x-www-form-urlencoded',
        'X-CENTRIFY-NATIVE-CLIENT': 'true'}
    post_fields = {
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': config['redirect_uri'],
        'client_id': config['client_id'],
        'client_secret': config['client_secret']}

    resp = requests.post(url, headers=header_data, data=post_fields)
    if resp.status_code != 200:
        return render_template('result.html', title='OpenIDConnect', result='')
    else:
        return render_template('result.html', title='OpenIDConnect', result=resp.text)


def run(port, config):
    all_configs[port] = config
    app.run(host='localhost', port=port)


# Before running it, make sure to create OIDC app in the tenant and copy over the information
if __name__ == '__main__':
    port = 5000
    config = {
        'app_name': 'my_oidc_app',
        'base_url': 'https://aaj7390.my.dev.idaptive.app',
        'client_id': 'my_client_id',
        'client_secret': 'my_client_secret',
        'redirect_uri': 'http://localhost:' + str(port) + '/callback',
        'scope': 'openid'
    }

    run(port, config)