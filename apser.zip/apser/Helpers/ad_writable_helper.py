# from idaptive_automation.api_payloads.payloads.set_custom_ad_mapping import SetCustomAdMapping


class MakeAdWritable:

    def __init__(self, app_helpers):
        self.app_helpers = app_helpers

    def enable_make_ad_writable(self):
        key = "Core.DirectoryServices.ActiveDirectory.Writable"
        payload = True
        result = self.app_helpers['tenant_helper'].update_tenant_flag(key, payload)
        assert result.response['success'] is True
        return result

    def disable_make_ad_writable(self):
        key = "Core.DirectoryServices.ActiveDirectory.Writable"
        payload = False
        result = self.app_helpers['tenant_helper'].update_tenant_flag(key, payload)
        assert result.response['success'] is True
        return result

    def __enter__(self):
        self.enable_make_ad_writable()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disable_make_ad_writable()