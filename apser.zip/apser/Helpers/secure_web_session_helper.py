from idaptive_automation.api_client import ApiSession


def empty_session(tenant_info):
    return ApiSession(
        base_url=tenant_info['base_url'],
        tenant_id=tenant_info['tenant_id'],
        username=tenant_info['username'],
        password=tenant_info['password'],
        db_metrics=False,
        start_auth=False, auto_auth=False)


def session_header(token):
    temp_header = {'Content-type': 'application/json',
                   'X-IDAP-NATIVE-CLIENT': 'Test',
                   'Authorization': f"Bearer {token}"}
    return temp_header

