import random
import string
import uuid
import requests
# import os
# import socket
# import struct
# import fcntl

from mongocred.mongocred import MongoCred


def random_password(length=12):
    pwlist = ([random.choice(string.punctuation), random.choice(string.ascii_lowercase),
               random.choice(string.ascii_uppercase), random.choice(string.digits)] +
              [random.choice(string.ascii_lowercase + string.ascii_uppercase + string.punctuation)
               for i in range(length-4)])
    random.shuffle(pwlist)
    pw = ''.join(pwlist)
    return pw


def random_alpha(length=6):
    characters = string.ascii_letters
    password = ''.join(random.choice(characters) for i in range(length))
    return password


def random_alphanumeric(length=8):
    characters = string.ascii_letters + string.digits
    password = ''.join(random.choice(characters) for i in range(length))
    return password


def get_mongo_cred_for_external_resource(resource="google"):
    mongo_cred = MongoCred()
    query = {
        "external_resource": resource
    }
    credentials = mongo_cred.query_mongo_db_find_one('automation', 'external_auth', query)
    return credentials


def verify_url(url):
    request = requests.get(url, verify=False)
    assert request.status_code == 200, f"URL {url} is not valid or is broken"


# def contains_local_address(address):
#     local_addresses = ['localhost', '127.0.0.1']
#     for local in local_addresses:
#         if local in address:
#             return True
#     return False
