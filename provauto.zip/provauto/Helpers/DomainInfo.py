

class DomainInfo:
    def __init__(self):
        self.directory_service_uuid = ''
        self.domain_name = ''
        self.domain_ou = ''
        self.directory_descriptor = ''
        self.domain_guid = ''
        self.organizational_unit = ''
        self.domain_controller_host_name = ''
        self.organizational_unit_display_name = ''
