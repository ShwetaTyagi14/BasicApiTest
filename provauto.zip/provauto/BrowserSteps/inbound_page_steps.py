import uuid

from idaptive_automation.ui_automation import InboundProvisioningPage


class InboundProvisioningPageSteps:
    def __init__(self, driver):
        self.driver = driver

    def validate_learn_more_link(self):
        page = InboundProvisioningPage(self.driver).click_learn_more_link()
        assert page.is_page_loaded() is not None
        page.close_inbound_documentation()
        return self

    def validate_view_reports_link(self):
        page = InboundProvisioningPage(self.driver).click_sync_options_tab()
        job_history_page = page.click_view_reports_link()
        assert job_history_page.is_page_loaded() is not None
        job_history_page.close_job_history_page()
        return self

    def refresh_source_list(self):
        InboundProvisioningPage(self.driver).refresh_page()
        return self

    def select_inbound_source(self, source):
        page = InboundProvisioningPage(self.driver).check_inbound_source(source)
        return self

    def validate_no_actions_available(self):
        page = InboundProvisioningPage(self.driver).click_actions_button()
        page, actions_element = page.is_no_actions_visible()
        assert actions_element.text == 'No actions available.'
