

from idaptive_automation.ui_automation import AppsPage, AppDetailsPage, BoxAuthPage


class AppsPageSteps:
    def __init__(self, driver):
        self.driver = driver

    def add_web_app(self, app):
        apps_page = AppsPage(self.driver)
        add_app_dialog = apps_page.click_add_web_apps_button()
        add_app_dialog.add_featured_app(app)
        apps_page.refresh_page()

    def select_web_app_enable_provisioning(self, app):
        apps_page = AppsPage(self.driver)
        app_details_page = apps_page.select_web_app(app)
        app_details_page.enable_provisioning()

    def authorize_provisioning_creds(self):
        app_details_page = AppDetailsPage(self.driver)
        app_details_page.click_authorize_button()

    def switch_to_oauth_window(self):
        oauth_window = self.driver.window_handles[1]
        self.driver.switch_to_window(oauth_window)

    def validate_authorize_box(self, username, password):
        box_page = BoxAuthPage(self.driver)
        assert box_page.authorize_box(username=username, password=password) is True
        self.driver.close()
        home = self.driver.window_handles[0]
        self.driver.switch_to_window(home)

    def click_cancel_provisioning_tab(self):
        app_page = AppsPage(self.driver)
        app_page.cancel_provisioning()

    def delete_provisioning_app(self, app):
        app_page = AppsPage(self.driver)
        app_page.delete_web_app(app)
