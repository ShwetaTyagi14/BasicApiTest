from idaptive_automation.ui_automation import OutboundProvisioningPage


class OutboundProvisioningPageSteps:
    def __init__(self, driver):
        self.driver = driver

    def validate_default_daily_sync_settings(self):
        assert OutboundProvisioningPage(self.driver).daily_sync_enabled() is False
        return self

    def validate_enabling_daily_sync(self):
        page = OutboundProvisioningPage(self.driver).check_enable_daily_sync_checkbox()
        assert page.daily_sync_enabled() is True
        page, tool_tip_visible = page.is_daily_sync_tooltip_visible()
        assert tool_tip_visible is True
        page, dropdown_content_available = page.validate_start_time_dropdown_contents_available('00:00 - 01:00')
        assert dropdown_content_available is True
        page, save_modal_visible = page.click_save_button().is_modal_visible()
        assert save_modal_visible is True
        page.close_modal()

    def validate_reset_outbound_daily_sync(self):
        page = OutboundProvisioningPage(self.driver).clear_enable_daily_sync_checkbox()
        assert page.daily_sync_enabled() is False
