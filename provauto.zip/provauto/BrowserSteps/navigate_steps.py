from idaptive_automation.ui_automation import AdminPortalPage, UserProfileMenu, UserPortalPage, InboundProvisioningPage, OutboundProvisioningPage, AppsPage


class Navigate:
    def __init__(self, driver):
        self.driver = driver

    def to_admin_portal(self):
        if 'admin' in self.driver.current_url:
            return self

        UserProfileMenu(self.driver).switch_to_admin_portal()
        AdminPortalPage(self.driver).wait_for_page_to_load()
        return self

    def to_inbound_provisioning_page(self):
        AdminPortalPage(self.driver).select_inbound_provisioning()
        return InboundProvisioningPage(self.driver)

    def to_outbound_provisioning_page(self):
        AdminPortalPage(self.driver).select_outbound_provisioning()
        return OutboundProvisioningPage(self.driver)

    def to_apps_page(self):
        AdminPortalPage(self.driver).select_web_apps()
        return AppsPage(self.driver)
