from idaptive_automation.ui_automation import AdminPortalPage, SignInPage, UserPortalPage


class Login:
    def __init__(self, driver, environment_url=None):
        self.driver = driver
        if environment_url:
            self.environment_url = environment_url
            driver.get(environment_url)

    def to_user_portal(self, user_name, password):
        self.driver.navigate_to_resource('my')
        SignInPage(self.driver).login(user_name, password)
        UserPortalPage(self.driver).wait_for_page_to_load()
        return self

    def to_admin_portal(self, username, password, wait_for_portal_load=True):
        self.driver.navigate_to_resource('admin')
        SignInPage(self.driver).login(username, password)
        if wait_for_portal_load:
            AdminPortalPage(self.driver).wait_for_page_to_load(wait_time=20)

    def to_admin_portal_via_mfa_challenge(self, username, password):
        self.to_admin_portal(username, password, False)

        AdminPortalPage(self.driver).wait_for_page_to_load(wait_time=20)
        # TODO: change this once feature is working - Admin portal should not load
        assert False, 'This test cannot be completed until the feature is working'
