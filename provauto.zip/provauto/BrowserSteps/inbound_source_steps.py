import uuid

from idaptive_automation.ui_automation import ProvisioningSourceDialog


class InboundSourceSteps:
    def __init__(self, driver):
        self.driver = driver

    def validate_default_settings(self):
        page, source_enabled = ProvisioningSourceDialog(self.driver).get_instance_enabled()
        page, name_input_enabled = page.get_name_input_enabled()
        page, verify_button_enabled = page.get_verify_button_enabled()
        assert source_enabled is False
        assert name_input_enabled is False
        assert verify_button_enabled is False
        return self

    def validate_post_source_selection_settings(self):
        page = ProvisioningSourceDialog(self.driver).select_inbound_source('Workday (Production)')
        page, source_enabled = page.get_instance_enabled()
        page, name_input_enabled = page.get_name_input_enabled()
        page, verify_button_enabled = page.get_verify_button_enabled()
        page, write_back_enabled = page.get_write_back_enabled()
        page, workday_url_enabled = page.get_workday_url_enabled()
        page, username_enabled = page.get_username_input_enabled()
        page, password_enabled = page.get_password_input_enabled()
        assert source_enabled is True
        assert name_input_enabled is True
        assert verify_button_enabled is False
        assert write_back_enabled is True
        assert workday_url_enabled is True
        assert username_enabled is True
        assert password_enabled is True
        return self

    def validate_password_mask(self):
        page, pre_click_value = ProvisioningSourceDialog(self.driver).get_password_mask()
        page = page.click_show_password()
        page, post_click_value = page.get_password_mask()
        assert pre_click_value == 'password'
        assert post_click_value == 'text'
        return self

    def configure_source_settings(self, source_name):
        ProvisioningSourceDialog(self.driver).select_inbound_source('Workday (Integration)') \
            .input_source_name(source_name) \
            .input_source_url('https://wd2-impl-services1.workday.com/ccx/service/centrify_pt1') \
            .input_source_username('AnilTestIntegrationUser@centrify_pt1') \
            .input_source_password('testTEST1234!')
        return self

    def validate_report_integration_defaults(self):
        page = ProvisioningSourceDialog(self.driver).click_report_integration_menu()
        page, report_integration_enabled = page.get_report_integration_enabled()
        page, base_report_url_enabled = page.get_base_report_url_enabled()
        page, relative_schema_url_enabled = page.get_relative_schema_url_enabled()
        page, relative_json_url_enabled = page.get_relative_json_url_enabled()
        page, worker_field_name_enabled = page.get_worker_field_name_enabled()
        page, query_timeout_enabled = page.get_query_timeout_enabled()
        assert report_integration_enabled is True
        assert base_report_url_enabled is False
        assert relative_schema_url_enabled is False
        assert relative_json_url_enabled is False
        assert worker_field_name_enabled is False
        assert query_timeout_enabled is False
        return self

    def validate_report_integration_enabled_defaults(self):
        page = ProvisioningSourceDialog(self.driver).click_report_integration()
        page, base_report_url_enabled = page.get_base_report_url_enabled()
        page, relative_schema_url_enabled = page.get_relative_schema_url_enabled()
        page, relative_json_url_enabled = page.get_relative_json_url_enabled()
        page, worker_field_name_enabled = page.get_worker_field_name_enabled()
        page, query_timeout_enabled = page.get_query_timeout_enabled()
        page, worker_field_name = page.get_worker_field_name_value()
        assert base_report_url_enabled is True
        assert relative_schema_url_enabled is True
        assert relative_json_url_enabled is True
        assert worker_field_name_enabled is True
        assert query_timeout_enabled is True
        assert worker_field_name == 'Workday_ID'
        return self

    def validate_min_max_report_query_timeout(self):
        page, valid = ProvisioningSourceDialog(self.driver).input_query_timeout_value(0)
        assert valid is False
        page, valid = page.input_query_timeout_value(1)
        assert valid is True
        page, valid = page.input_query_timeout_value(21)
        assert valid is False
        page, valid = page.input_query_timeout_value(20)
        assert valid is True
        return self

    def validate_sync_settings_defaults(self):
        page = ProvisioningSourceDialog(self.driver).click_sync_settings_menu()
        page, new_hire_pre_provisioning_interval_enabled = page.get_new_hire_pre_provisioning_interval_enabled()
        assert new_hire_pre_provisioning_interval_enabled is False
        return self

    def validate_min_max_pre_provisioning_interval(self):
        page = ProvisioningSourceDialog(self.driver).click_new_hire_pre_provision()
        page, pre_provisioning_interval_value = page.get_new_hire_pre_provisioning_interval_value()
        assert pre_provisioning_interval_value == '120'
        page, valid = page.input_new_hire_pre_provisioning_interval_value(7)
        assert valid is False
        page, valid = page.input_new_hire_pre_provisioning_interval_value(8)
        assert valid is True
        page, valid = page.input_new_hire_pre_provisioning_interval_value(337)
        assert valid is False
        page, valid = page.input_new_hire_pre_provisioning_interval_value(336)
        assert valid is True
        return self

    def validate_min_max_tenant_utc_offset(self):
        page, valid = ProvisioningSourceDialog(self.driver).input_tenant_utc_offset_value(-841)
        assert valid is False
        page, valid = ProvisioningSourceDialog(self.driver).input_tenant_utc_offset_value(-840)
        assert valid is True
        page, valid = ProvisioningSourceDialog(self.driver).input_tenant_utc_offset_value(841)
        assert valid is False
        page, valid = ProvisioningSourceDialog(self.driver).input_tenant_utc_offset_value(840)
        assert valid is True
        return self

    def validate_sync_report_defaults(self):
        page = ProvisioningSourceDialog(self.driver).click_sync_reports_menu()
        page, sync_report_type_enabled = page.get_sync_report_type_dropdown_enabled()
        assert sync_report_type_enabled is False
        page, distribution_add_button_enabled = page.get_distribution_add_button_enabled()
        assert distribution_add_button_enabled is False
        return self

    def validate_send_report_defaults(self):
        page = ProvisioningSourceDialog(self.driver).click_send_report_on_completion()
        page = page.click_add_distribution_button()
        page, email_input_visible = page.get_email_input_visibility()
        assert email_input_visible is True
