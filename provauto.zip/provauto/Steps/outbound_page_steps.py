from Pages.outbound_provisining_page import OutboundProvisioningPage


class OutboundProvPageSteps:
    def __init__(self, driver):
        self.outbound_page = OutboundProvisioningPage(driver)

    def check_default_outbound_daily_sync_settings(self):
        assert self.outbound_page.is_daily_sync_enabled() is False

    def check_enabling_daily_sync(self):
        self.outbound_page.click_enable_daily_sync_chkbox()
        assert self.outbound_page.is_daily_sync_enabled() is True
        assert self.outbound_page.check_daily_sync_tooltip() is True
        assert self.outbound_page.click_daily_sync_start_time_dropdown() is True

        self.outbound_page.click_save_btn()
        assert self.outbound_page.is_warning_modal_visible() is True

        self.outbound_page.close_warning_modal()

    def reset_outbound_daily_sync(self):
        self.outbound_page.click_enable_daily_sync_chkbox()
        assert self.outbound_page.is_daily_sync_enabled() is False

    def click_job_history_link(self):
        self.outbound_page.click_job_history_link()

