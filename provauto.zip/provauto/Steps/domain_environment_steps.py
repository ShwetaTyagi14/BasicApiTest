from ADLibrary.ad_server import AdServer


class DomainEnvironmentSteps:
    def __init__(self, dc):
        self.dc = dc
        self.ad_server = AdServer(
            self.dc['server_address'],
            self.dc['domain_name'],
            self.dc['username'],
            self.dc['password']
        )
        self.created_ou_list = []

    def clean_domain_environment(self):
        for ou in self.created_ou_list:
            self.delete_ad_ou(ou)
            self.created_ou_list.pop()

    def create_ad_environment(self, base_name, num_groups=1, num_users=1, num_contacts=0):
        self.create_basic_ad_ou(f'{base_name}')
        dc_string = f"dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"

        self.create_sub_ad_ou(f'{base_name}GroupHolder', f"ou={base_name},{dc_string}")

        users_per_group = int(num_users / num_groups)
        user_sub_ous = [
            self.create_sub_ad_ou(f'{base_name}Sub{sub_ou + 1}', f'ou={base_name},{dc_string}')
            for sub_ou in range(num_groups)
        ]
        users = [
            self.__create_ad_user__(next(iter(sub_ou)), f"user{user + 1}")
            for sub_ou in user_sub_ous
            for user in range(users_per_group)
        ]
        user_groups = [
            self.create_ad_group(f'{base_name}group{sub_ou + 1}', f'ou={base_name}GroupHolder,ou={base_name}', f"{base_name}group{sub_ou + 1}@{self.dc['default_email_suffix']}")
            for sub_ou in range(num_groups)
        ]
        results = [
            self.__add_users_to_group__(next(iter(group)), users, users_per_group)
            for group in user_groups
        ]
        if num_contacts >= 1:
            self.create_sub_ad_ou(f'{base_name}ContactHolder', f"ou={base_name},{dc_string}")
            for contact in range(num_contacts):
                self.__create_ad_contact__(base_name, dc_string, contact + 1)

    def create_ad_distribution_environment(self, base_name, num_groups=1, num_users=1, num_contacts=0):
        self.create_basic_ad_ou(f'{base_name}')
        dc_string = f"dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"

        self.create_sub_ad_ou(f'{base_name}GroupHolder', f"ou={base_name},{dc_string}")

        users_per_group = int(num_users / num_groups)
        user_sub_ous = [
            self.create_sub_ad_ou(f'{base_name}Sub{sub_ou + 1}', f'ou={base_name},{dc_string}')
            for sub_ou in range(num_groups)
        ]
        users = [
            self.__create_ad_user__(next(iter(sub_ou)), f"user{user + 1}")
            for sub_ou in user_sub_ous
            for user in range(users_per_group)
        ]
        user_groups = [
            self.create_ad_group(f'{base_name}group{sub_ou + 1}', f'ou={base_name}GroupHolder,ou={base_name}', f"{base_name}group{sub_ou + 1}@{self.dc['default_email_suffix']}", True)
            for sub_ou in range(num_groups)
        ]
        sec_group = self.create_ad_group(f'{base_name}sec', f'ou={base_name}GroupHolder,ou={base_name}', f"{base_name}group{1}@{self.dc['default_email_suffix']}")
        user_groups.append(sec_group)
        self.ad_server.add_users_to_group(users, next(iter(sec_group)).entry_dn)
        results = [
            self.__add_users_to_group__(next(iter(group)), users, users_per_group)
            for group in user_groups
        ]
        if num_contacts >= 1:
            self.create_sub_ad_ou(f'{base_name}ContactHolder', f"ou={base_name},{dc_string}")
            for contact in range(num_contacts):
                self.__create_ad_contact__(base_name, dc_string, contact + 1)

    def __add_users_to_group__(self, group, users, users_per_group):
        group_users = users[:users_per_group]
        del users[:users_per_group]
        self.ad_server.add_users_to_group(group_users, group.entry_dn)

    def __create_ad_user__(self, sub_ou, user):
        user_dn = sub_ou.entry_dn
        user_cn = f"cn={sub_ou.name.value}{user}"

        self.ad_server.create_ad_user(
            user_dn,
            samaccount_name=f'{sub_ou.name.value}{user}',
            password='testTEST1234!@',
            first_name=f'{sub_ou.name.value}',
            last_name=f'{user}',
            email=f"{sub_ou.name.value}{user}@{self.dc['default_email_suffix']}",
            domain=f"{self.dc['domain_name']}.{self.dc['domain_suffix']}"
        )
        return f'{user_cn},{user_dn}'

    def __create_ad_contact__(self, base_name, dc_string, contact):
        self.ad_server.create_ad_contact(
            f"{base_name}contact{contact}",
            f"Test",
            f"{base_name}contact{contact}@{self.dc['default_email_suffix']}",
            f"ou={base_name}ContactHolder,ou={base_name},{dc_string}"
        )

    def create_basic_ad_ou(self, ou_name):
        self.created_ou_list.append(f"ou={ou_name},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}")
        return self.ad_server.create_organizational_unit(
            ou_name,
            f"dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"
        )

    def create_admin_user(self, user_name, parent_ou):
        self.ad_server.create_ad_user(
            parent_ou,
            samaccount_name=user_name,
            password='testTEST1234!@',
            first_name=user_name,
            last_name='User',
            email=f"{user_name}@{self.dc['domain_name']}.{self.dc['domain_suffix']}",
            domain=f"{self.dc['domain_name']}.{self.dc['domain_suffix']}"
        )
        distinguished_name = f"CN={user_name},{parent_ou}"
        self.ad_server.add_users_to_group(
            [distinguished_name],
            f"CN=Domain Admins,CN=Users,DC={self.dc['domain_name']},DC={self.dc['domain_suffix']}"
        )

        return self.ad_server

    def create_sub_ad_ou(self, ou_name, parent_ou):
        return self.ad_server.create_organizational_unit(
            ou_name,
            parent_ou
        )

    def create_ad_contact(self, first_name, last_name, email, dn_string):
        return self.ad_server.create_ad_contact(first_name, last_name, email, dn_string)

    def delete_ad_ou(self, ou_name):
        return self.ad_server.delete_ad_object(ou_name)

    def create_ad_group(self, group_name, ou_string, email_address="", is_distribution_list=False):
        if not is_distribution_list:
            return self.ad_server.create_ad_group(
                group_name,
                f"{ou_string},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}",
                email_address
            )
        else:
            return self.ad_server.create_ad_dl_group(
                group_name,
                f"{ou_string},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}",
                email_address
            )

    def get_ad_group_details(self, parent_ou):
        return self.ad_server.get_ad_group_details(
            f"ou={parent_ou},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"
        )

    def get_ad_group_members(self, dn_string):
        return self.ad_server.get_ad_group_members(dn_string)

    def disable_user_in_ad(self, user_name, ou_string):
        return self.ad_server.disable_user(
            f"CN={user_name},{ou_string},DC={self.dc['domain_name']},DC={self.dc['domain_suffix']}"
        )

    def get_ad_ou_users(self, ou_name):
        dn_string = f"OU={ou_name},DC={self.dc['domain_name']},DC={self.dc['domain_suffix']}"
        return self.ad_server.get_organizational_unit_people(dn_string)

    def remove_user_from_group(self, user_dn, group_dn):
        return self.ad_server.remove_users_from_group(user_dn, group_dn)

    def delete_ad_user(self, user_name, ou_string):
        dn_string = f"cn={user_name},{ou_string},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"
        self.ad_server.delete_ad_object(dn_string)

    def modify_ad_user_attribute(self, user_name, ou_string, attribute_name, attribute_value):
        dn_string = f"cn={user_name},{ou_string},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"
        self.ad_server.modify_ad_user_attribute(
            dn_string,
            attribute_name,
            attribute_value
        )

    def get_ad_user_attribute(self, user_name, ou_string, attribute_name):
        dn_string = f"cn={user_name},{ou_string},dc={self.dc['domain_name']},dc={self.dc['domain_suffix']}"
        result = self.ad_server.search_ad_user_attribute(
            dn_string,
            attribute_name
        )
        # TODO Can we clean this up so we aren't using hardcoded indexes
        return result

    def add_user_to_group(self, user_dn, group_dn):
        user_dn = f"{user_dn}DC={self.dc['domain_name']},DC={self.dc['domain_suffix']}"

        result = self.ad_server.add_users_to_group([user_dn], group_dn)
        return result