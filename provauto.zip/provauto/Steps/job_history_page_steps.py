from Pages.job_history_page import JobHistoryPage


class JobHistoryPageSteps:

    def __init__(self, driver):
        self.job_history_page = JobHistoryPage(driver)

    def page_loaded(self):
        assert self.job_history_page.is_page_loaded() is True

    def check_default_filter(self):
        assert self.job_history_page.check_default_filter() is not None

    def validate_filter(self, filter_name, current_filter="All Jobs"):
        self.job_history_page.select_filter(filter_name, current_filter)
        assert self.job_history_page.check_table_for_full_text("Completed (with issues)") is not None
        assert self.job_history_page.check_table_for_full_text("Completed") is None

    def validate_search(self, search_value, valid=True):
        if valid:
            self.job_history_page.perform_search(search_value)
            assert self.job_history_page.validate_search(search_value, valid) is not None
            assert self.job_history_page.validate_search("Automatic user sync", valid) is None
        else:
            self.job_history_page.perform_search(search_value)
            assert self.job_history_page.validate_search(search_value, valid) is not None
