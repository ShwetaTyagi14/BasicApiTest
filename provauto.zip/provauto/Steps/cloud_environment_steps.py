import csv
import email
import os
import os.path
import poplib

from Steps.data_steps import DataSteps


class CloudEnvironment:
    def __init__(self, idaptive_session, data_steps):
        self.api_session = idaptive_session
        self.data_steps = data_steps
        self.created_roles = []
        self.imported_apps = []
        self.created_cloud_users = []
        self.created_inbound_sources = []

    def clean_cloud_environment(self):
        cleaned_roles = [
            self.remove_core_role(role)
            for role in self.created_roles
        ]
        cleaned_apps = [
            self.remove_app(app)
            for app in self.imported_apps
        ]
        cleaned_cloud_users = [
            self.delete_cloud_user(user)
            for user in self.created_cloud_users
        ]
        cleaned_sources = [
            self.delete_inbound_source(source)
            for source in self.created_inbound_sources
        ]

        try:
            assert cleaned_roles.__len__() == self.created_roles.__len__()
            assert cleaned_apps.__len__() == self.imported_apps.__len__()
            assert cleaned_cloud_users.__len__() == self.created_cloud_users.__len__()
            assert cleaned_sources.__len__() == self.created_inbound_sources.__len__()
        except AssertionError:
            pass

    def create_core_role(self, role_name):
        role = {
            'Name': role_name
        }

        role_id = self.api_session.saas_manage.store_role(role).Result[0]

        self.created_roles.append(role_id)
        return role_id

    def import_app(self, app):
        # app_key = self.app_helper.import_app_by_name(app_name=app)
        app_payload = {
            'ID': [app]
        }

        app_key = self.api_session.saas_manage.import_app_from_template(app_payload).Result[0][2]
        self.imported_apps.append(app_key)
        return app_key

    def create_cloud_user(self, user_name, dc_info):
        # TODO this needs to be moved to MongoDB
        user_data = DataSteps.load_json_file('CreateUserData')

        user_data['LoginName'] = user_name
        user_data['Mail'] = f"{user_name}@{dc_info['default_email_suffix']}"
        user_data['DisplayName'] = user_name
        user_data['Name'] = f"{user_name}@{dc_info['default_login_suffix']}"

        user_id = self.api_session.cdirectory_service.create_cloud_user(**user_data).Result
        self.created_cloud_users.append(user_id)
        return user_id

    def create_inbound_source(self, test_data, name=None, enabled=True, email=False, email_list=None):
        source_payload = test_data['sourceCreds']
        source_payload['Name'] = name
        source_payload['IsInstanceEnabled'] = enabled

        if email is True:
            source_payload['EnableSyncNotificationEmails'] = True
            source_payload['SyncNotificationEmails'] = email_list

        result = self.api_session.inbound.save_source(source_payload)
        assert result.success is True

        instance_id = self.__get_instance_id(name)
        self.created_inbound_sources.append(instance_id)
        return instance_id

    def create_inbound_source_report_integrated(self, test_data, name, enabled=True):
        source_payload = test_data['customReportCreds']
        source_payload['Name'] = name
        source_payload['IsInstanceEnabled'] = enabled

        result = self.api_session.inbound.save_source(source_payload)
        assert result.success is True

        instance_id = self.__get_instance_id(name)
        self.created_inbound_sources.append(instance_id)
        return instance_id

    def __get_instance_id(self, source_name):
        instances = self.api_session.inbound.query_all_instances().Result
        return next(
            (
                instance for instance in instances
                if instance.Name == source_name
            ),
            None
        ).InstanceId

    def delete_inbound_source(self, instance_id):
        payload = {'InstanceId': instance_id}

        try:
            result = self.api_session.inbound.delete_instance(payload)
            assert result.ok is True
            return instance_id
        except AssertionError:
            return None

    def delete_cloud_user(self, user_id):
        payload = {'Users': [user_id]}

        try:
            result = self.api_session.user_management.remove_users(payload)
            assert result.success is True
            return user_id
        except AssertionError:
            return None

    def remove_app(self, app_key):
        payload = {'_RowKey': [app_key]}

        try:
            result = self.api_session.saas_manage.delete_applications(payload)
            assert result.success is True
            return app_key
        except AssertionError:
            return None

    def remove_core_role(self, role_id):
        payload = [role_id]

        try:
            result = self.api_session.saas_manage.delete_roles(payload)
            assert result.success is True
            return role_id
        except AssertionError:
            return None

    def validate_email(self, validate_messages):
        content_found = 0
        SERVER = "pop.gmail.com"
        USER = "idaptiveprovisioning"
        PASSWORD = "testTEST1234"

        server = poplib.POP3_SSL(SERVER)
        server.user(USER)
        server.pass_(PASSWORD)

        resp, mails, octets = server.list()
        index = len(mails)
        resp, lines, octets = server.retr(index)

        message = email.message_from_bytes(b'\n'.join(lines))
        payload = message.get_payload(decode=True)
        payload = payload.decode(message.get_content_charset())

        for validation in validate_messages:
            if validation in payload:
                content_found += 1

        assert content_found >= validate_messages.__len__()
        server.dele(index)
        server.quit()

    def download_generated_passwords(self):
        SERVER = "pop.gmail.com"
        USER = "idaptiveprovisioning"
        PASSWORD = "testTEST1234"

        server = poplib.POP3_SSL(SERVER)
        server.user(USER)
        server.pass_(PASSWORD)

        resp, mails, octets = server.list()
        index = len(mails)
        resp = server.retr(index)
        raw_message = resp[1]

        dir_path = os.path.dirname(os.path.realpath(__file__))
        strmessage = email.message_from_bytes(b'\n'.join(raw_message))
        users_sycd = []
        filename = ''

        for part in strmessage.walk():
            if part.get_content_maintype() == 'multipart':
                continue

            if part.get('Content-Disposition') is None:
                print("no content dispo")
                continue

            filename = part.get_filename()

            fp = open(os.path.join(dir_path, filename), 'wb')
            fp.write(part.get_payload(decode=1))
            fp.close()

        server.dele(index)
        server.quit()

        with open(os.path.join(dir_path, filename), newline='') as f:
            reader = csv.reader(f)
            next(reader)

            for row in reader:
                users_sycd.append(row)

        os.remove(os.path.join(dir_path, filename))
        return users_sycd
