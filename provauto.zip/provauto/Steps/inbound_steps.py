import json
import os
import time

from Steps.data_steps import DataSteps


class InboundSteps:
    def __init__(self, idaptive_session):
        self.session = idaptive_session

    def save_source(self, payload):
        result = self.session.inbound.save_source(payload)
        return result

    def get_instance_id(self, source_name):
        instance_collection = self.session.inbound.query_all_instances().Result
        return next(
            (
                instance for instance in instance_collection
                if instance.Name == source_name
            ),
            None
        )

    def get_service_directory_uuid(self, payload, display_name):
        directory_services = self.session.core.get_directory_services(payload).Result.Results
        directory_row = next(
            (
                directory_service for directory_service in directory_services
                if directory_service.Row.DisplayName == display_name
            ),
            None
        )
        return directory_row.Row.directoryServiceUuid

    def get_ou_tree_content(self, payload, get_admin_account_status):
        ou_tree = next(
            iter(
                self.session.core.get_ou_tree_contents(payload, get_admin_account_status).Result
            ),
            None
        )
        return ou_tree

    def get_domain_controller(self, payload):
        return next(
            iter(
                self.session.core.get_domain_controllers_for_domain(payload).Result
            )
        )

    def save_rule(self, payload):
        result = self.session.inbound.save_rule(payload)
        return result

    def start_sync_job(self, instance_id=None, sync_type=None):
        sync_job_payload = DataSteps.load_json_file('SyncJobTemplate')

        sync_job_payload['instanceId'] = instance_id
        sync_job_payload['syncType'] = sync_type

        result = self.session.inbound.start_sync_job(sync_job_payload)
        return result

    def get_job_report(self, job_id):
        payload = {'jobId': job_id}

        result = self.session.scheduler_history.get_job_details(payload)
        return result

    def get_job_status(self, job_id, expected_status):
        job_result = None
        count = 0

        while job_result is None:
            count = count + 1
            job_result = self.__find_job_status(job_id, expected_status)
            time.sleep(5)
            if count == 40:
                break

        if job_result is None:
            return False
        else:
            return True

    def __find_job_status(self, job_id, expected_status):
        payload = {
            'Script': f"SELECT  JobStatus \
                        FROM    ScheduleJob sj \
                        WHERE   sj.Id = '{job_id}' \
                              AND JobStatus = '{expected_status}'",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
        }
        result = self.session.red_rock.execute_redrock_query(payload)

        try:
            if result.Result.Results.__len__() == 0:
                return None
            else:
                return result.Result.Results[0].Row
        except AttributeError:
            return None

    def delete_inbound_source(self, instance_id):
        payload = {'InstanceId': instance_id}

        result = self.session.inbound.delete_instance(payload)
        return result

    def logout_api_session(self):
        result = self.session.security.logout()
        return result

    def login_api_session(self, username, password):
        try:
            self.session.username = username
            self.session.password = password

            self.session.security.start_authentication()
            self.session.security.advance_authentication()
        except:
            return False
        return True

    def get_ad_organizational_unit_users(self, dn_string):
        raise NotImplementedError

    def get_ad_group_members(self, dn_string):
        raise NotImplementedError

    def log_users_with_missing_attributes(self, user):
        pass

    def build_save_source_payload(self, name=None, source_name=None, url=None,
                                  user_name=None, password=None, enabled=True):
        source_payload = DataSteps.load_json_file('SourceCredentials')

        source_payload['Name'] = name
        source_payload['SourceName'] = source_name
        source_payload['WorkdayUrl'] = url
        source_payload['Auth_UserName'] = user_name
        source_payload['Auth_Encrypted_Password'] = password
        source_payload['IsInstanceEnabled'] = enabled
        return source_payload

    def build_ou_tree_payload(self, directory_service_id=None, id=None, use_cache=False):
        ou_tree_payload = DataSteps.load_json_file('GetOuTreeContents')

        ou_tree_payload['directoryServiceUuid'] = directory_service_id
        ou_tree_payload['id'] = id
        ou_tree_payload['useCache'] = use_cache
        return ou_tree_payload

    def build_domain_controller_payload(self, directory_service_uuid, domain_name):
        domain_controller_payload = DataSteps.load_json_file('GetDomainControllers')

        domain_controller_payload['directoryServiceUuid'] = directory_service_uuid
        domain_controller_payload['domainName'] = domain_name
        return domain_controller_payload

    def build_group_rule(self, group, directory_uuid, forest):
        group_rule = DataSteps.load_json_file('GroupAssignment')

        group_rule["DirectoryServiceUuid"] = directory_uuid
        group_rule["DisplayName"] = group.cn.value
        group_rule["DistinguishedName"] = group.distinguishedName.value
        group_rule["Forest"] = forest
        group_rule["Guid"] = group.objectGUID.value
        group_rule["InternalName"] = group.objectGUID.value
        group_rule["Name"] = "{}@{}".format(group.cn.value, forest)
        group_rule["ServiceInstance"] = "AdProxy_{}".format(forest)
        group_rule["ServiceInstanceLocalized"] = "Active Directory ({})".format(forest)
        group_rule["SystemName"] = "{}@{}".format(group.cn.value, forest)
        return group_rule

    def build_rule(self, instance_id, domain_info=None, rule_state='Production',
                   rule_name='Test Rule', rule_source='Workday (Integration)',
                   rule_template='SaveWorkdayRule', source_id='', source_name='', script_block='', group_rule=None,
                   user_password='@bSolution'):
        domain_rule = DataSteps.load_json_file(rule_template)

        domain_rule['InstanceId'] = instance_id
        domain_rule['DirectoryServiceUuid'] = domain_info.directory_service_uuid
        domain_rule['DirectoryDescriptor'] = domain_info.directory_descriptor
        domain_rule['OrganizationalUnit'] = domain_info.organizational_unit
        domain_rule['RuleSelectionValues'][0]['Id'] = source_id
        domain_rule['RuleSelectionValues'][0]['Name'] = source_name
        domain_rule['ActiveDirectoryRuleData']['OrganizationalUnit'] = domain_info.organizational_unit
        domain_rule['ActiveDirectoryRuleData']['OrganizationUnitDisplayName'] = \
            domain_info.organizational_unit_display_name
        domain_rule['ActiveDirectoryRuleData']['DomainControllerHostName'] = domain_info.domain_controller_host_name
        domain_rule['ActiveDirectoryRuleData']['DomainName'] = domain_info.domain_name
        domain_rule['ActiveDirectoryRuleData']['DomainGuid'] = domain_info.domain_guid
        domain_rule['ActiveDirectoryRuleData']['ScriptBlock'] = script_block
        if group_rule is not None:
            domain_rule['ActiveDirectoryRuleData']['Groups'].append(group_rule)
        domain_rule['RuleState'] = rule_state
        domain_rule['SourceName'] = rule_source
        domain_rule['Name'] = rule_name
        domain_rule['NewUserPasswordConfig']['StaticPassword'] = user_password
        return domain_rule

    def download_job_sync_status_report(self, file_name):
        # file_path = 'InboundProvSyncJob_Workday_{}_FullSync_OneTime/{}/Report.zip'.format(instance_id, job_id)
        file_path = file_name.replace('/vfs/Traces/scheduler/', '')
        zip_file = self.session.core.download_sync_job_report(file_path)

        report_contents = zip_file.open(zip_file.filelist[0]).read()
        return report_contents

    def add_administrative_account(self, user_name, user_id, password, dc_info):
        payload = {
            'User': user_name,
            'UserUuid': user_id,
            'Password': password,
            'Domains': [f"{dc_info['domain_name']}.{dc_info['domain_suffix']}"]
        }

        result = self.session.server_manage.set_administrative_accounts(payload)
        assert result.success is True
        return result
