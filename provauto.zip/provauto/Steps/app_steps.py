
from Pages.user_search_page import UserSearchPage
from Pages.web_app_prov_detail_page import WebAppProvDetailPage
from Pages.web_apps_page import WebAppsPage


class AppSteps:
    def __init__(self, driver):
        self.web_apps_page = WebAppsPage(driver)
        self.web_app_prov_detail_page = WebAppProvDetailPage(driver)
        self.user_search_page = UserSearchPage(driver)

    def validate_web_apps_page_loaded(self):
        assert self.web_apps_page.is_page_loaded()

    def validate_enabled_disabled_prov_columns(self):
        app_list = self.web_apps_page.parse_apps_table()

        # TODO I despise this code block - need to refactor when time allows
        for app in app_list:
            if app['Name'] == 'App Prov Disabled':
                assert app['Provisioning'] == 'Disabled'
            elif app['Name'] == 'App Prov Enabled':
                assert app['Provisioning'] == 'Enabled'

    def select_web_app(self, web_app):
        self.web_apps_page.select_web_app(web_app)

    def select_featured_app(self, web_app):
        self.web_apps_page.add_web_apps_page.add_featured_app(web_app)

    def validate_provisioning_script_enables(self):
        self.web_app_prov_detail_page.click_provisioning_item()
        self.web_app_prov_detail_page.click_script_tag()
        assert self.web_app_prov_detail_page.is_provisioning_script_open()

    def validate_provisioning_script_test(self, name):
        self.web_app_prov_detail_page.click_provisioning_item()
        self.web_app_prov_detail_page.click_script_tag()
        self.web_app_prov_detail_page.input_script_text("trace('test'); destination.Name = source.DisplayName; destination.Email = source.Email;")
        self.web_app_prov_detail_page.click_script_test_button()
        self.user_search_page.input_user_name(name)
        self.user_search_page.select_user(name)
        self.user_search_page.click_next_button()
        assert self.web_app_prov_detail_page.validate_test_result("ProvisioningScript: test") is True

    def validate_learn_more_link(self):
        self.web_app_prov_detail_page.click_settings_item()
        self.web_app_prov_detail_page.click_learn_more_link()
        assert self.web_app_prov_detail_page.close_how_to_window() is True

    def add_web_app_role(self, role):
        self.web_app_prov_detail_page.click_provisioning_item()
        self.web_app_prov_detail_page.click_add_role_btn()

        self.web_app_prov_detail_page.click_role_name_dropdown()
        assert self.web_app_prov_detail_page.validate_role_name_available(role) is True

        self.web_app_prov_detail_page.select_role_name(role)
        self.web_app_prov_detail_page.click_done_button()

    def validate_role_not_available(self, role):
        self.web_app_prov_detail_page.click_add_role_btn()
        self.web_app_prov_detail_page.click_role_name_dropdown()
        assert self.web_app_prov_detail_page.validate_role_name_available('System Administrator') is False

    def cancel_add_web_app_role(self):
        self.web_app_prov_detail_page.click_cancel_button()

    def open_add_web_app(self):
        self.web_apps_page.click_add_web_apps_btn()

    def add_custom_saml_app(self):
        self.web_apps_page.click_add_web_apps_btn()
        self.web_apps_page.add_web_apps_page.click_custom_tab()
        self.web_apps_page.add_web_apps_page.add_saml_app()
        self.web_apps_page.refresh_page()

    def enable_app_provisioning(self):
        self.web_app_prov_detail_page.click_provisioning_item()
        self.web_app_prov_detail_page.click_enable_checkbox()

    def click_prov_authorize_btn(self):
        self.web_app_prov_detail_page.click_authorize_btn()

    def validate_creds_required_nav_tab(self):
        self.web_app_prov_detail_page.click_acocunt_mapping_item()
        self.validate_cred_warning_modal_displayed()

    def validate_creds_requried_save_tab(self):
        self.web_app_prov_detail_page.click_save_button()
        self.validate_cred_warning_modal_displayed()

    def validate_cred_warning_modal_displayed(self):
        assert self.web_app_prov_detail_page.is_warning_modal_displayed() is True
        self.web_app_prov_detail_page.close_warning_modal()

    def check_message_on_invalid_creds(self):
        assert self.web_app_prov_detail_page.is_error_modal_displayed() is True
        self.web_app_prov_detail_page.close_warning_modal()

    def input_scim_creds(self, url, token):
        self.web_app_prov_detail_page.input_scim_service_url(url)
        self.web_app_prov_detail_page.input_scim_auth_token(token)
        self.web_app_prov_detail_page.click_verify_button()

    def check_valid_creds(self):
        assert self.web_app_prov_detail_page.is_error_modal_displayed() is False
        assert self.web_app_prov_detail_page.is_add_role_btn_visible() is True

    def validate_creds_are_persistent(self, url, token):
        self.web_app_prov_detail_page.click_enable_checkbox()
        self.web_app_prov_detail_page.click_enable_checkbox()
        assert self.web_app_prov_detail_page.get_scim_service_url() == url
        assert self.web_app_prov_detail_page.get_scim_auth_token() == token

    def cancel_provisioning_tab(self):
        self.web_app_prov_detail_page.click_provisioning_cancel_btn()

    def delete_provisioning_app(self, app):
        self.web_apps_page.delete_web_app(app)

    def validate_account_mapping_not_available(self):
        self.web_app_prov_detail_page.click_acocunt_mapping_item()
        assert self.web_app_prov_detail_page.is_app_not_available_label_displayed() is True
