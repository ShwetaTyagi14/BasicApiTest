from Pages.admin_page import AdminPortalPage
from Pages.sign_in_page import SignInPage
from Pages.user_portal_page import UserPortalPage


class AdminSteps:
    def __init__(self, driver):
        self.driver = driver

        self.user_portal = UserPortalPage(driver)
        self.sign_in_page = SignInPage(driver)
        self.admin_portal = AdminPortalPage(driver)

    def login(self, user_name, password):
        self.sign_in_page.login(user_name, password)
        assert self.user_portal.is_page_loaded() is True

    def navigate_to_admin_portal(self):
        self.user_portal.switch_to_admin_portal()
        assert self.admin_portal.is_page_loaded() is True

    def navigate_to_inbound_provisioning(self):
        self.admin_portal.select_inbound_provisioning()

    def validate_admin_portal_loaded(self):
        assert self.admin_portal.is_page_loaded()

    def navigate_to_outbound_provisioning(self):
        self.admin_portal.select_outbound_provisioning()

    def navigate_to_web_apps(self):
        self.admin_portal.select_web_apps()
