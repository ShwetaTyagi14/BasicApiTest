import json
import os


class DataSteps:
    def __init__(self, mongo):
        self.mongo = mongo

    def query_db_collection(self, db, collection, query=None):
        return self.mongo.query_mongo_db_find_one(db, collection, query)

    @staticmethod
    def load_json_file(json_file):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        return json.load(open(os.path.join(file_dir, 'TestData/{}.json'.format(json_file))))
