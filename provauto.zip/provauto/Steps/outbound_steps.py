import os
import subprocess
import datetime
import base64
import uuid
import time
import pymongo
import logging
from Steps.data_steps import DataSteps


logging.basicConfig(filename="RYANoutboundsteps.log",
                    level=logging.DEBUG,
                    format="%(asctime)s:%(levelname)s:%(message)s"
                    )


class OutboundSteps:
    def __init__(self, idaptive_session, data_steps):
        self.session = idaptive_session
        self.data_steps = data_steps

    def create_core_role(self, role_name):
        role = {
            'Name': role_name
        }
        role_result = self.session.saas_manage.store_role(role)
        return role_result

    def role_assign_super_rights(self, role_id, role_type):
        payload = self.data_steps.query_db_collection(
            collection='predefined_roles',
            query={'Name': role_type},
            db='automation'
        )['AdminRights']

        for role in payload:
            role['Role'] = role_id

        self.session.saas_manage.assign_super_rights(payload)

    def map_ad_group_to_core_role(self, role_id, group_array):
        group_role_mapping = {
            'Groups':
                {
                    'Add': group_array
                },
            'Name': role_id
        }
        mapping_result = self.session.roles.update_role(group_role_mapping)
        return mapping_result

    def map_user_to_core_role(self, role_id, user_id):
        user_role_mapping = {
            'Users':
                {
                    'Add': [user_id]
                },
            'Name': role_id
        }
        mapping_result = self.session.roles.update_role(user_role_mapping)
        return mapping_result

    def map_role_to_core_role(self, parent_role_id, child_role_id):
        role_mapping = {
            'Roles':
                {
                    'Add': [child_role_id]
                },
            'Name': parent_role_id
        }
        mapping_result = self.session.roles.update_role(role_mapping)
        return mapping_result

    def remove_user_from_core_role(self, role_id, user_id):
        payload = {
            'Users':
                {
                    'Delete': [user_id]
                },
            'Name': role_id
        }
        remove_result = self.session.roles.update_role(payload)
        return remove_result

    def import_app(self, app):
        app_payload = {
            'ID': [app]
        }
        app_key = self.session.saas_manage.import_app_from_template(app_payload)['Result'][0]['_RowKey']
        return app_key

    def import_app_get_result(self, app):
        app_payload = {
            'ID': [app]
        }
        result = self.session.saas_manage.import_app_from_template(app_payload)
        return result

    def o365_update_app(self, app_key, role_name, app_settings='O365UpdateAppData', retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': f'{app_settings}'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def o365_update_app_enable_dl_sync(self, app_key, role_name, domain, app_settings='O365UpdateAppData', retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': f'{app_settings}'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        app_data['settings']['RoleMappings'].append({
            'MappingType': 'Forest',
            'RoleName': domain,
            'SyncContacts': False,
            'SyncUsers': False,
            'SyncGroups': True,
            'SyncResources': False,
            'LicenseNames': None
        })

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def update_webex_application_de(self, app_key):
        app_data = DataSteps.load_json_file('WebExUpdateApplicationDEData')
        app_data['_RowKey'] = app_key

        result = self.session.saas_manage.update_application_de(app_data)
        return result

    def update_application_de(self, app_key, payload):
        app_data = payload
        app_data['_RowKey'] = app_key

        result = self.session.saas_manage.update_application_de(app_data)
        return result

    def webex_update_app(self, app_key, role_name):
        app_data = DataSteps.load_json_file('WebExUpdateAppData')
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        result = self.session.user_prov.update_app(app_data)
        return result

    def aws_update_app(self, app_key, role_name):
        app_data = DataSteps.load_json_file('AWSConsoleUser')
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        result = self.session.user_prov.update_app(app_data)
        return result

    def box_update_app(self, app_key, role_name):
        app_data = DataSteps.load_json_file('BoxUpdateAppData')
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        result = self.session.user_prov.o365_update_app(app_data)
        return result

    def set_app_permission(self, app_key, role_name):
        app_permissions = DataSteps.load_json_file('UpdatePermissionData')

        app_permissions['Grants'][0]['Principal'] = role_name
        app_permissions['ID'] = app_key
        app_permissions['RowKey'] = app_key
        app_permissions['PVID'] = app_key

        result = self.session.saas_manage.set_application_permissions(app_permissions)
        return result

    def request_outbound_full_sync(self, app_key):
        payload = {
            'previewMode': False,
            'appid': app_key
        }

        result = self.session.provisioning.sync_all(payload)
        return result

    def request_outbound_user_sync(self, user_id):
        return self.session.provisioning.sync_user(user_id)

    def get_job_report(self, job_id):
        payload = {'jobId': job_id}
        result = self.session.scheduler_history.get_job_details(payload)

        return result

    def get_job_result_base(self, job_id):
        payload = DataSteps.load_json_file('JobHistory')

        results = self.session.task.get_job_history(payload)['Result']['Results']
        report_result = None

        for result in results:
            if result['Entities'][0]['Key'] == job_id:
                report_result = result
                break

        if 'Processed' in report_result['Row']['JobStatus']:
            return_value = report_result
        else:
            return_value = None

        return return_value

    # def get_job_report_try_continuously(self, job_id):
    #     job_result = None
    #     count = 0
    #     while job_result is None:
    #         count = count + 1
    #         job_result = self.get_job_result_base(job_id)
    #         time.sleep(30)
    #         if count == 30:
    #             logging.error(f"Get Job Report did not complete in required time, or failed. Count = {count}")
    #             break
    #     try:
    #         job_report = self.download_app_prov_sync_status_report(job_id)
    #     except Exception:
    #         job_report = self.download_app_prov_sync_status_report(job_id, "IncrementalProvSync")
    #     return job_report

    def update_app(self, app_key, payload):
        payload['appKey'] = app_key

        result = self.session.user_prov.update_app(payload)
        return result

    def saml_update_app(self, app_key, url, auth_token, role=None, user_script=None):
        update_data = self.data_steps.query_db_collection(
            db='automation',
            collection='payload_templates',
            query={'name': 'SAMLUpdateApp'}
        )['payload']

        update_data['appKey'] = app_key
        update_data['creds']['Url'] = url
        update_data['creds']['AuthToken'] = auth_token

        if role is not None:
            update_data.update({
                'settings': {
                    'RoleMappings': [
                        {
                            'RoleName': role,
                            'MappingType': 'Role'
                        }
                    ],
                    'UserScript': user_script,
                    'DirGroupSync': False
                }
            })
        result = self.session.user_prov.update_app(update_data)
        return result

    def saml_update_app_direct(self, app_key, url, direct_header, role=None, user_script=None):
        update_data = self.data_steps.query_db_collection(
            db='automation',
            collection='payload_templates',
            query={'name': 'SAMLUpdateApp'}
        )['payload']

        update_data['appKey'] = app_key
        update_data['creds']['Url'] = url
        update_data['creds']['AuthToken'] = direct_header
        update_data['creds']['AuthType'] = 'AuthorizationHeader'
        update_data['creds']['HeaderSubType'] = 'Direct'
        update_data['creds']['mergeusers'] = False

        if role is not None:
            update_data.update({
                'settings': {
                    'RoleMappings': [
                        {
                            'RoleName': role,
                            'MappingType': 'Role'
                        }
                    ],
                    'UserScript': user_script,
                    'DirGroupSync': False
                }
            })
        result = self.session.user_prov.update_app(update_data)
        return result

    def create_cloud_user(self, user_name, dc_info):
        user_data = DataSteps.load_json_file('CreateUserData')

        # TODO Need to figure out how to handle multiple tenants in same podscape
        user_data['LoginName'] = user_name
        user_data['Mail'] = f"{user_name}@{dc_info['default_email_suffix']}"
        user_data['DisplayName'] = user_name
        user_data['Name'] = f"{user_name}@{dc_info['default_login_suffix']}"

        result = self.session.cdirectory_service.create_cloud_user(**user_data)
        return result

    def get_app(self, app_key):
        payload = {
            'appKey': app_key,
            'getEndpointData': True
        }

        app = self.session.user_prov.get_app(payload)
        return app

    def download_app_prov_sync_status_report(self, file_name):
        # file_path = f'{prov_sync_type}/{job_id}/Report.zip'
        file_path = file_name.replace('/vfs/Traces/scheduler', '')
        zip_file = self.session.core.download_sync_job_report(file_path)

        report_contents = zip_file.open(zip_file.filelist[0]).read()
        return report_contents

    def delete_web_application(self, app_key):
        payload = {
            '_RowKey': [app_key]
        }

        result = self.session.saas_manage.delete_applications(payload)
        return result

    def delete_cloud_user(self, user_id):
        payload = {
            'Users': [user_id]
        }

        result = self.session.user_management.remove_users(payload)
        return result

    def delete_core_role(self, role_id):
        payload = [role_id]

        result = self.session.saas_manage.delete_roles(payload)
        return result

    def get_user_details_from_email(self, email):

        payload = {
            'Script': f"SELECT   * \
                       FROM     ( \
                                    Select  ID, \
                                            DisplayName, \
                                            Email, \
                                            LastInvite, \
                                            LastLogin, \
                                            SourceDsLocalized, \
                                            SourceDsType, \
                                            Status, \
                                            StatusEnum, \
                                            Username, \
                                            ServiceUser, \
                                            UserType \
                                    from    User \
                                ) \
                        WHERE   (UserType = 'User' \
                                OR \
                                UserType IS NULL) \
                                AND Email ='{email}'",
            'Args': {
                'PageNumber': 1,
                'PageSize': 100,
                'Limit': 100000,
                'SortBy': 'Username',
                'Ascending': True,
                'Caching': -1
            }
        }

        result = self.session.red_rock.execute_redrock_query(payload)
        return result.Result.Results[0].Row

    def refresh_user_token(self, user_id):

        result = self.session.cdirectory_service.refresh_ad_user_token(user_id)
        return result

    def check_o365_license(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_users.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"OFFICE RULES LICENSE REPORT: ={office_rules}")
        return office_rules

    def check_o365_license_continuously(self, user_principal_name):
        office_license_report = False
        office_license = False
        count = 0
        while office_license_report is False:
            count = count + 1
            time.sleep(15)
            office_license = self.check_o365_license(user_principal_name)
            office_license_report = office_license['Users'].__len__() > 0
            if count == 20:
                logging.error(f"Licence was not able to be gathered in the required time. Count ={count}")
                break
        return office_license

    def get_msol_group_members(self, group_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_group_members.ps1',
                               group_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        group_members = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"OFFICE GROUP MEMBER REPORT: ={group_members}")
        return group_members

    def get_msol_contact(self, contact_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_contact.ps1',
                               contact_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"OFFICE CONTACT REPORT: ={contact}")
        return contact

    def get_number_of_msol_objects(self, base_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_number_msol_objects.ps1',
                               base_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        num_objects = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"NUMBER OF OBJECTS: ={num_objects}")
        return num_objects

    def remove_o365_user_and_empty_recycle(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\Scripts\remove_o365_users_recyclebin.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        result = ps.wait()
        return result

    def remove_all_o365_objects_and_empty_recycle(self, search_string):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\Scripts\remove_o365_all_objects_recyclebin.ps1',
                               search_string],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        result = ps.wait()
        return result

    def remove_o365_group_from_azure(self, group_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\Scripts\remove_o365_groups.ps1',
                               group_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        result = ps.wait()
        return result

    def remove_o365_contact_from_azure(self, contact_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\Scripts\remove_o365_contact.ps1',
                               contact_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        result = ps.wait()
        return result

    @staticmethod
    def __get_two_minute_search_dictionary():
        query_time = {
            'end_time': str(datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z",
            'start_time': str((datetime.datetime.utcnow() - datetime.timedelta(minutes=2)).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"
        }
        return query_time

    def __get_user_sync_status(self, app_id, status):
        query_time = self.__get_two_minute_search_dictionary()
        payload = {
            'Script': f"SELECT  LastSync, \
                                AppRowKey, \
                                DestUpn, \
                                SyncStatusCode \
                        FROM    UserProvisioningSync up \
                        WHERE   up.AppRowKey='{app_id}' \
                                AND up.SyncStatusCode in ({status}) ",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": query_time['end_time'],
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": query_time['start_time'],
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }

        result = self.session.red_rock.execute_redrock_query(payload)
        logging.debug(f'Payload:  {payload}')
        logging.debug(f'Query Result: {result}')

        try:
            if result.Result.Results.__len__() == 0:
                return None
            else:
                return result.Result.Results
        except AttributeError:
            return None

    def __get_any_type_sync(self, user_principal_name, sync_type_result, app_name, change_to_lower):
        redrock_search_time = datetime.datetime.utcnow()
        format_redrock_search_time = str(redrock_search_time.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        redrock_search_time_minus_two_minutes = datetime.datetime.utcnow() - datetime.timedelta(minutes=2)
        format_redrock_search_time_minus_two_minutes = str(redrock_search_time_minus_two_minutes.strftime
                                                           ('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        if change_to_lower == True: user_principal_name = user_principal_name.lower()

        payload = {
            'Script': f"SELECT WhenOccurred, AppName, DestUpn, SyncType, EventType, Event.SyncResult, JobUniqueId \
                                FROM Event \
                                WHERE Event.EventType = 'Cloud.Provisioning.UserAppSyncCompleted' \
                                AND Event.AppName = '{app_name}' \
                                AND Event.SyncResult = '{sync_type_result}' \
                                AND Event.DestUpn is '{user_principal_name}' \
                                AND Event.WhenOccurred > @startDate \
                                AND Event.WhenOccurred < @endDate",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": format_redrock_search_time,
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": format_redrock_search_time_minus_two_minutes,
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }

        result = self.session.red_rock.execute_redrock_query(payload)
        logging.debug(f"Payload {payload}")
        logging.debug(f"RR Query result {result}")

        try:
            if result.Result.Results.__len__() == 0:
                return None
            else:
                return result.Result.Results[0].Row
        except AttributeError:
            return None

    def validate_user_prov_status(self, app_id, expected_status):
        job_result = None
        count = 0

        while job_result is None:
            count = count + 1
            job_result = self.__get_user_sync_status(app_id=app_id, status=expected_status)
            time.sleep(30)
            if count == 20:
                logging.error(f'Sync job did not complete in required time, or failed.  Count = {count}')
                break

        job_id = job_result
        assert job_id is not None

    def get_any_type_sync_report_continuously(self, user_principal_name, sync_type_result, app_name, change_to_lower=True):
        job_result = None
        count = 0

        while job_result is None:
            count = count + 1
            time.sleep(30)
            job_result = self.__get_any_type_sync(user_principal_name, sync_type_result, app_name, change_to_lower)
            if count == 20:
                logging.error(f"Sync job did not complete in required time, or failed. Count = {count},")
                break

        job_id = job_result.JobUniqueId
        raw_result = self.get_job_report_info(job_id)
        report_url = raw_result.Result.reportUrl
        job_report = self.download_app_prov_sync_status_report(report_url)
        return job_report

    def o365_update_app_immutable(self, app_key, role_name, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365UpdateAppDataImmutableScript'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def convert_objectguid_to_immutable(self, ad_user_objectguid):
        ad_user_objectguid = ad_user_objectguid
        ad_user_objectguid = str(ad_user_objectguid)[1:-1]
        ad_user_objectguid = uuid.UUID(ad_user_objectguid)
        return str(base64.b64encode(ad_user_objectguid.bytes_le))[2:-1]

    def get_msol_user_license(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\Scripts\get_msol_user_licenses.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        logging.debug(f'Powershell Return Code {ps.returncode}')
        office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"License Results: {office_rules}['Users'][0]")
        return office_rules

    def get_msol_user_license_continuously(self, user_principal_name):
        office_license_report = False
        office_license = False
        count = 0
        while office_license_report is False:
            count = count + 1
            time.sleep(15)
            office_license = self.get_msol_user_license(user_principal_name)
            office_license_report = office_license['Users'].__len__() > 0
            if count == 20:
                logging.error(f"Licence was not able to be gathered in the required time. Count ={count}")
                break
        return office_license

    def o365_update_app_license_hierarchy(self, app_key, role_name, role_name_two, retainDeprovAccount=False, disabled_service_plans=None):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365UpdateAppDataLicenseOrderScript'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = role_name_two

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def logout_api_session(self):
        result = self.session.security.logout()
        return result

    def login_api_session(self, username, password):
        self.session.username = username
        self.session.password = password

        self.session.security.start_authentication()
        self.session.security.advance_authentication()

    def o365_update_app_license_service(self, app_key, role_name, role_name_two, retainDeprovAccount=False, disabled_service_plans=None):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365UpdateAppDataSubLicenseScript'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = role_name_two
        app_data['settings']['RoleMappings'][0]['DisabledServicePlans'][0]['Role'] = role_name
        app_data['settings']['RoleMappings'][0]['DisabledServicePlans'][1]['Role'] = role_name

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def cissup_4725_app_setup(self, app_key, role_name, role_name_two, json_instance, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': f'{json_instance}'})
        app_data = test_data['value']
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = role_name_two
        app_data['settings']['RoleMappings'][2]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][3]['RoleName'] = role_name_two
        app_data['settings']['RoleMappings'][4]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][5]['RoleName'] = role_name

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def o365_update_app_conflicting_license(self, app_key, role_name, role_name_two, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365UpdateAppDataConflictingLicenseScript'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = role_name_two

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def o365_update_app_all_license_and_services(self, app_key, role_name, role_name_two, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': 'O365UpdateAppDataAllLicenses'})

        app_data = test_data['value']
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name_two
        app_data['settings']['RoleMappings'][1]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['DisabledServicePlans'][0]['Role'] = role_name
        app_data['settings']['RoleMappings'][1]['DisabledServicePlans'][1]['Role'] = role_name
        app_data['settings']['RoleMappings'][1]['DisabledServicePlans'][2]['Role'] = role_name
        app_data['settings']['RoleMappings'][1]['DisabledServicePlans'][3]['Role'] = role_name

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def o365_update_hybrid_settings(self, app_key, role_name, domain_name, sync_contact=False, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': 'O365GroupsChecked'})

        app_data = test_data['value'][0]
        app_data['appKey'] = f'{app_key}'
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = f'{domain_name}'
        app_data['settings']['RoleMappings'][1]['SyncGroups'] = True
        app_data['settings']['RoleMappings'][1]['SyncContacts'] = sync_contact

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def confirm_large_o365_job_completion(self, email_user_name, num_users, num_groups, num_contacts):
        count = 0
        done_provisioning = False

        while done_provisioning is False:
            count = count + 1
            time.sleep(60)
            result = self.get_number_of_msol_objects(email_user_name)
            actual_num_users = result['O365Objects'][0]['Users']
            actual_num_contacts = result['O365Objects'][0]['Contacts']
            actual_num_groups = result['O365Objects'][0]['Groups']
            total_provisioned = (int(actual_num_users) + int(actual_num_groups) + int(actual_num_contacts))
            expected_provisioned = num_contacts + num_groups + num_users
            if total_provisioned == expected_provisioned:
                done_provisioning = True
                break
            elif count == 30:
                done_provisioning = False
                logging.ERROR(f"Large Job Provisioning did not complete in time. At timeout: {total_provisioned}")
                break
        return done_provisioning

    def __get_any_type_preview_sync(self):
        redrock_search_time = datetime.datetime.utcnow()
        format_redrock_search_time = str(redrock_search_time.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        redrock_search_time_minus_two_minutes = datetime.datetime.utcnow() - datetime.timedelta(minutes=3)
        format_redrock_search_time_minus_two_minutes = str(redrock_search_time_minus_two_minutes.strftime
                                                           ('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"
        payload = {
            'Script': f"SELECT WhenOccurred, SyncType, EventType, JobUniqueId \
                                FROM Event \
                                WHERE Event.EventType = 'Cloud.Provisioning.SyncJobCompleted' \
                                AND Event.SyncType = 'OneTimeSyncAll' \
                                AND Event.WhenOccurred > @startDate \
                                AND Event.WhenOccurred < @endDate",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": format_redrock_search_time,
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": format_redrock_search_time_minus_two_minutes,
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }

        result = self.session.red_rock.execute_redrock_query(payload)
        logging.debug(f"Payload {payload}")
        logging.debug(f"RR Query result {result}")

        try:
            if result.Result.Results.__len__() == 0:
                return None
            else:
                return result.Result.Results[0].Row
        except AttributeError:
            return None

    def get_any_type_preview_sync_report_continuously(self):
        job_result = None
        count = 0

        while job_result is None:
            count = count + 1
            job_result = self.__get_any_type_preview_sync()
            time.sleep(30)
            if count == 20:
                logging.error(f"Sync job did not complete in required time, or failed. Count = {count},")
                break

        job_id = job_result.JobUniqueId

        raw_result = self.get_job_report_info(job_id)
        report_url = raw_result.Result.reportUrl
        job_report = self.download_app_prov_sync_status_report(report_url)
        return job_report

    def o365_update_app_unmodified_deprov(self, app_key, role_name, dc_info, sync_groups=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365UnmodifiedDeprov'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = dc_info['default_login_suffix']

        if sync_groups is True:
            app_data['settings']['RoleMappings'][1]['SyncGroups'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def __get_incremental_type_sync(self, user_principal_name, sync_type_result, app_name, change_to_lower=True):
        redrock_search_time = datetime.datetime.utcnow()
        format_redrock_search_time = str(redrock_search_time.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        redrock_search_time_minus_two_minutes = datetime.datetime.utcnow() - datetime.timedelta(minutes=2)
        format_redrock_search_time_minus_two_minutes = str(redrock_search_time_minus_two_minutes.strftime
                                                           ('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        if change_to_lower: user_principal_name = user_principal_name.lower()

        payload = {
            'Script': f"SELECT WhenOccurred, AppName, DestUpn, SyncType, EventType, Event.SyncResult, JobUniqueId \
                                FROM Event \
                                WHERE Event.EventType = 'Cloud.Provisioning.UserAppSyncCompleted' \
                                AND Event.SyncType = 'AggregateUserSync' \
                                AND Event.AppName = '{app_name}' \
                                AND Event.SyncResult = '{sync_type_result}' \
                                AND Event.DestUpn is '{user_principal_name}' \
                                AND Event.WhenOccurred > @startDate \
                                AND Event.WhenOccurred < @endDate",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": format_redrock_search_time,
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": format_redrock_search_time_minus_two_minutes,
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }

        result = self.session.red_rock.execute_redrock_query(payload)
        logging.debug(f"Payload {payload}")
        logging.debug(f"RR Query result {result}")

        try:
            if result.Result.Results.__len__() == 0:
                return None
            else:
                return result.Result.Results[0].Row
        except AttributeError:
            return None

    def get_incremental_type_sync_report_continuously(self, user_principal_name, sync_type_result, app_name):
        job_result = None
        count = 0

        while job_result is None:
            count = count + 1
            time.sleep(30)
            job_result = self.__get_incremental_type_sync(user_principal_name, sync_type_result, app_name)
            if count == 20:
                logging.error(f"Sync job did not complete in required time, or failed. Count = {count},")
                break

        job_id = job_result.JobUniqueId
        raw_result = self.get_job_report_info(job_id)
        report_url = raw_result.Result.reportUrl
        job_report = self.download_app_prov_sync_status_report(report_url)
        return job_report

    def __has_attribute_incremental_updated(self, user_principal_name):
        redrock_search_time = datetime.datetime.utcnow()
        format_redrock_search_time = str(redrock_search_time.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        redrock_search_time_minus_two_minutes = datetime.datetime.utcnow() - datetime.timedelta(minutes=2)
        format_redrock_search_time_minus_two_minutes = str(redrock_search_time_minus_two_minutes.strftime
                                                           ('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"

        user_principal_name = user_principal_name.lower()

        payload = {
            'Script': f"SELECT WhenOccurred, EventType, NormalizedUser \
                                FROM Event \
                                WHERE Event.EventType = 'Cloud.Core.DSEntityChange' \
                                AND Event.NormalizedUser is '{user_principal_name}' \
                                AND Event.WhenOccurred > @startDate \
                                AND Event.WhenOccurred < @endDate",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": format_redrock_search_time,
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": format_redrock_search_time_minus_two_minutes,
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }

        result = self.session.red_rock.execute_redrock_query(payload)
        logging.debug(f"Payload {payload}")
        logging.debug(f"RR Query result {result}")

        try:
            if result.Result.Results.__len__() == 0:
                return None
            else:
                return True
        except AttributeError:
            return None

    def get_sync_report_when_no_user_in_destination(self, user_principal_name):
        user_ready = None
        count = 0

        while user_ready is None:
            count = count + 1
            time.sleep(30)
            user_ready = self.__has_attribute_incremental_updated(user_principal_name)
            if count == 20:
                logging.error(f"Sync job did not complete in required time, or failed. Count = {count},")
                break
        return user_ready

    def o365_update_app_remove_license_deprov(self, app_key, role_name, dc_info, sync_groups=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365RemoveLicenseDeprov'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = dc_info['default_login_suffix']

        if sync_groups:
            app_data['settings']['RoleMappings'][1]['SyncGroups'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def update_notification_settings(self, payload):
        result = self.session.provisioning.save_notification_settings(payload)
        return result

    def modify_multiple_ad_user_attributes(self, email_user_name, domain_environment):
        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Sub1user1",
            f"OU={email_user_name}Sub1,OU={email_user_name}",
            'mobile',
            '1231231234'
        )

        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Sub1user1",
            f"OU={email_user_name}Sub1,OU={email_user_name}",
            'title',
            'General Manager'
        )

        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Sub1user1",
            f"OU={email_user_name}Sub1,OU={email_user_name}",
            'department',
            'Information'
        )

        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Sub1user1",
            f"OU={email_user_name}Sub1,OU={email_user_name}",
            'displayName',
            'New name'
        )

    def get_msol_user_attributes(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_user_attributes.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact_attr = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"OFFICE USER ATTRIBUTES: ={contact_attr}")
        return contact_attr

    def modify_multiple_ad_group_attributes(self, email_user_name, app, dc_info, domain_environment):
        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Group1",
            f"OU={app[:8]}GroupHolder,OU={app[:8]}",
            'mail',
            f"{email_user_name}g1@{dc_info['default_email_suffix']}"
        )

        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Group1",
            f"OU={app[:8]}GroupHolder,OU={app[:8]}",
            'proxyAddresses',
            f"SMTP:{email_user_name}g1@{dc_info['default_email_suffix']}"
        )

    def o365_federate_domain(self, domain_name, app_row_key):
        result = self.session.o365.o365_federate_domain(domain_name, app_row_key)

        pass
        return result

    def o365_unfederate_domain(self, domain_name, app_row_key):
        result = self.session.o365.o365_unfederate_domain(domain_name, app_row_key)

        pass
        return result

    def o365_get_domain_info_page(self, app_row_key):
        result = self.session.o365.o365_get_domain_info_page(app_row_key)

        pass
        return result

    def o365_update_app_linked_apps(self, app_key):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365AddLinkedApps'})
        app_data = test_data['value'][0]
        app_data['_RowKey'] = app_key

        result = self.session.saas_manage.update_application_de(app_data)

        pass
        return result

    def o365_delete_linked_apps(self, parent_app_key, child_app_key_one, child_app_key_two, child_app_key_three):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365RemoveLinkedApps'})
        app_data = test_data['value'][0]
        app_data['_RowKey'] = parent_app_key
        app_data['ChildLinkedApps'][0]['ParentApp'] = parent_app_key
        app_data['ChildLinkedApps'][0]['_RowKey'] = child_app_key_one
        app_data['ChildLinkedApps'][1]['ParentApp'] = parent_app_key
        app_data['ChildLinkedApps'][1]['_RowKey'] = child_app_key_two
        app_data['ChildLinkedApps'][2]['AppKey'] = child_app_key_three
        app_data['ChildLinkedApps'][2]['_RowKey'] = child_app_key_three

        result = self.session.saas_manage.update_application_de(app_data)

        pass
        return result

    def get_linked_app_list(self, app_key):
        payload = {
            'Script': f'SELECT Application.DisplayName, Application.ID \
            FROM Application \
            WHERE Application.ParentApp = "{app_key}"'
        }

        result = self.session.red_rock.execute_redrock_query(payload)

        pass
        return result.Result.Results

    def refresh_portal_token(self):

        result = self.session.security.refresh_token()

        pass
        return result

    def validate_linked_app_list(self, app_key, linked_apps):
        count = 0
        while linked_apps.__len__() == 4:
            count = count + 1
            time.sleep(30)
            self.refresh_portal_token()
            linked_apps = self.get_linked_app_list(app_key)
            if count == 20:
                break

        return linked_apps

    def get_job_report_info(self, job_id):
        payload = {'jobId': job_id}

        result = self.session.scheduler_history.get_job_details(payload)
        return result

    def get_provisioning_changelog(self, app_key):
        query = f"select    ID,  \
                           whenoccurred as Date, \
                           EventType as Change, \
                           NormalizedUser as User   \
                from       event  \
                where      ( \
                               ( \
                                   +EventType='Cloud.Saas.Application.AppAdd'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppModify'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppDelete'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppPublish'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppUnpublish'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppClone'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppProvModify' \
                               )  \
                               and WhenOccurred >= datefunc('now', -30) \
                               and ApplicationID = '{app_key}' \
                           )"
        payload = {
            'Script': query
        }
        result = self.session.red_rock.execute_redrock_query(payload).Result.Results
        assert result.__len__() >= 2
        assert any(r.Row.Change == 'Cloud.Saas.Application.AppProvModify' for r in result)
        assert any(r.Row.Change == 'Cloud.Saas.Application.AppAdd' for r in result)

    def o365_update_app_preferred_data(self, app_key, role_name, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                   {'name': 'O365UpdateAppDataPreferredData'})
        app_data = test_data['value'][0]
        app_data['appKey'] = app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        result = self.session.user_prov.update_app(app_data)
        return result

    def get_msol_preferred_data_value(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_pref_data_location.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"License Results: {office_rules}['Users'][0]")
        return office_rules

    def modify_multiple_ad_attributes(self, email_user_name, app, dc_info, domain_environment, key, value):

        domain_environment.modify_ad_user_attribute(
            f"{email_user_name}Sub1user1",
            f"OU={app[:8]}Sub1,OU={app[:8]}",
            key,
            value)

    def get_o365_all_user_attributes(self, user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_all_msol_user_attributes.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        logging.debug(f"OFFICE RULES LICENSE REPORT: ={office_rules}")
        return office_rules
