from Pages.InboundProvisioning.inbound_provisioning_page import InboundProvisioningPage


class InboundProvSteps:
    def __init__(self, driver):
        self.source_page = InboundProvisioningPage(driver)

    def check_inbound_prov_learn_more(self):
        self.source_page.click_learn_more_link()
        assert self.source_page.close_how_to_window() is True

    def check_view_reports_link(self):
        self.source_page.click_sync_options_tab()
        self.source_page.click_view_job_reports_link()
        assert self.source_page.close_job_history_window() is True

    def select_inbound_source(self, source):
        self.source_page.check_inbound_source(source)

    def check_no_actions_available(self):
        self.source_page.click_actions_button()
        assert self.source_page.validate_no_actions_visible()
