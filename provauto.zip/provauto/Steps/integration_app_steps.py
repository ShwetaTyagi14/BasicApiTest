# from zenpy import Zenpy


# class IntegrationAppSteps:
#     @staticmethod
#     def is_user_suspended(user_name):
#         is_suspended = None
#         creds = {
#             'email': 'appsaccounts@centrify.com',
#             'password': 'fjewiofE123!2!',
#             'subdomain': 'centrifyhelpdesk1354579520'
#         }
#         zenpy_client = Zenpy(**creds)
#         user_list = zenpy_client.users()
#         user = filter(lambda u: u.name == user_name, user_list.values)
#
#         for x in user:
#             is_suspended = x.suspended
#
#         return is_suspended
#
#     @staticmethod
#     def get_user_from_zen(user_name):
#         creds = {
#             'email': 'appsaccounts@centrify.com',
#             'password': 'fjewiofE123!2!',
#             'subdomain': 'centrifyhelpdesk1354579520'
#         }
#         zenpy_client = Zenpy(**creds)
#         user_list = zenpy_client.users()
#         user = filter(lambda u: u.name == user_name, user_list.values)
#
#         for x in user:
#             return x
#
#         return None
