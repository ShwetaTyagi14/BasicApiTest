
from Pages.InboundProvisioning.inbound_provisioning_page import InboundProvisioningPage


class AddRuleSteps:
    def __init__(self, driver, dc_info):
        self.source_page = InboundProvisioningPage(driver)
        self.dc_info = dc_info

    def add_inbound_source_rule(self, source_name):
        self.source_page.select_inbound_source_rule(source_name)

    def check_add_rule_source_defaults(self):
        assert self.source_page.provisioning_rule.is_inactive_rule() is True

    def check_supervisory_organization_add(self):
        self.source_page.provisioning_rule.select_supervisory_org_source()
        self.source_page.provisioning_rule.click_add_source_btn()
        self.source_page.provisioning_rule.select_supervisory_org('Tax')

        self.source_page.provisioning_rule.click_add_source_btn()
        self.source_page.provisioning_rule.select_supervisory_org('Payroll')

        orgs = ['Tax', 'Payroll']
        assert self.source_page.provisioning_rule.validate_org_selections(orgs).__len__() == 2

    def clean_up_rule(self, source_name):
        self.source_page.delete_inbound_source(source_name)

    def configure_rule_source(self):
        self.source_page.provisioning_rule.enter_rule_name('WD Test Rule')
        self.source_page.provisioning_rule.select_all_users_source()
        self.source_page.provisioning_rule.click_next_btn()

    def check_target_defaults(self):
        assert self.source_page.provisioning_rule.check_target_is_required() is True
        self.source_page.provisioning_rule.select_target_from_dropdown(
            f"Active Directory ({self.dc_info['domain_name']}.{self.dc_info['domain_suffix']})"
        )

        assert self.source_page.provisioning_rule.check_domain_is_required() is True
        self.source_page.provisioning_rule.select_domain_from_dropdown(
            f"{self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}"
        )

        assert self.source_page.provisioning_rule.check_domain_controller_is_required() is True
        self.source_page.provisioning_rule.select_domain_controller_from_dropdown(self.dc_info['full_computer_name'])

        self.source_page.provisioning_rule.select_target_ou('Domain Controllers')

    def configure_rule_target(self):
        self.source_page.provisioning_rule.select_target_from_dropdown(
            f"Active Directory ({self.dc_info['domain_name']}.{self.dc_info['domain_suffix']})"
        )
        self.source_page.provisioning_rule.select_domain_from_dropdown(
            f"{self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}"
        )
        self.source_page.provisioning_rule.select_domain_controller_from_dropdown(self.dc_info['full_computer_name'])
        self.source_page.provisioning_rule.select_target_ou('Domain Controllers')
        self.source_page.provisioning_rule.click_next_btn()

    def check_attribute_required_mappings(self):
        assert self.source_page.provisioning_rule.get_is_field_required('Cn (Common Name)') is True
        assert self.source_page.provisioning_rule.get_is_field_required('DisplayName') is True
        assert self.source_page.provisioning_rule.get_is_field_required('EmployeeId') is True
        assert self.source_page.provisioning_rule.get_is_field_required('SamAccountName') is True
        assert self.source_page.provisioning_rule.get_is_field_required('UserPrincipalName') is True

    def check_attribute_mapping_script(self):
        self.source_page.provisioning_rule.click_load_sample_btn()
        assert self.source_page.provisioning_rule.get_sample_script_loaded() is True

        self.source_page.provisioning_rule.set_invalid_attribute_mapping_script()
        assert self.source_page.provisioning_rule.get_is_attribute_mapping_script_invalid() is True

        self.source_page.provisioning_rule.clear_attribute_mapping_script()
        assert self.source_page.provisioning_rule.get_is_attribute_mapping_script_invalid() is False

    def configure_attributes(self):
        self.source_page.provisioning_rule.click_next_btn()

    def check_option_defaults(self):
        assert self.source_page.provisioning_rule.check_password_type_is_required() is True
        assert self.source_page.provisioning_rule.get_require_password_change_is_checked() is True

    def check_static_password_defaults(self):
        self.source_page.provisioning_rule.select_password_type_from_dropdown('Static Password')

        self.source_page.provisioning_rule.enter_static_password('testTEST1234')
        assert self.source_page.provisioning_rule.get_password_mask_attribute() == 'password'
        self.source_page.provisioning_rule.click_show_password()
        assert self.source_page.provisioning_rule.get_password_mask_attribute() == 'text'

    def check_generated_password_defaults(self):
        self.source_page.provisioning_rule.select_password_type_from_dropdown('Generated Password')
        assert self.source_page.provisioning_rule.is_send_password_to_email_available() is True
        assert self.source_page.provisioning_rule.is_send_password_to_manager_available() is True
        assert self.source_page.provisioning_rule.is_send_password_to_personal_email_available() is True

        self.source_page.provisioning_rule.click_send_password_to_email()
        assert self.source_page.provisioning_rule.check_notify_email_is_required() is True
        self.source_page.provisioning_rule.enter_notify_email('test@test.com')
        assert self.source_page.provisioning_rule.is_invalid_email_alert_present() is False
        self.source_page.provisioning_rule.enter_notify_email('test@test')
        assert self.source_page.provisioning_rule.is_invalid_email_alert_present() is True

    def check_map_provisioning_group_defaults(self):
        self.source_page.provisioning_rule.click_map_group_checkbox()
        assert self.source_page.provisioning_rule.is_mapping_table_present() is True
