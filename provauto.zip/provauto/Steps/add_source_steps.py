import uuid
from Pages.InboundProvisioning.inbound_provisioning_page import InboundProvisioningPage


class AddSourceSteps:
    def __init__(self, driver):
        self.source_page = InboundProvisioningPage(driver)

    def check_provisiong_source_dialog_appears(self):
        assert self.source_page.is_page_loaded() is True

    def check_default_settings_on_add_source(self):
        self.source_page.click_add_source()
        assert self.source_page.provisioning_source.is_page_loaded() is True
        assert self.source_page.provisioning_source.is_enable_instance_enabled() is False
        assert self.source_page.provisioning_source.is_name_input_enabled() is False
        assert self.source_page.provisioning_source.is_verify_button_disabled() is True

    def check_settings_after_workday_source_selection(self):
        self.source_page.provisioning_source.select_source('Workday (Production)')
        assert self.source_page.provisioning_source.is_enable_instance_enabled() is True
        assert self.source_page.provisioning_source.is_name_input_enabled() is True
        assert self.source_page.provisioning_source.is_verify_button_disabled() is True
        assert self.source_page.provisioning_source.is_write_back_enabled() is True
        assert self.source_page.provisioning_source.is_workday_url_enabled() is True
        assert self.source_page.provisioning_source.is_username_enabled() is True
        assert self.source_page.provisioning_source.is_password_enabled() is True

    def check_add_source_password_mask(self):
        assert self.source_page.provisioning_source.get_password_mask_attribute() == 'password'
        self.source_page.provisioning_source.click_show_password()
        assert self.source_page.provisioning_source.get_password_mask_attribute() == 'text'

    def configure_source_settings(self):
        source_name = 'WD Source {}'.format(uuid.uuid4())
        self.source_page.click_add_source()
        self.source_page.provisioning_source.select_source('Workday (Integration)')
        self.source_page.provisioning_source.enter_source_name(source_name)
        self.source_page.provisioning_source.enter_source_url('https://wd2-impl-services1.workday.com/ccx/service/centrify_pt1')
        self.source_page.provisioning_source.enter_source_username('AnilTestIntegrationUser@centrify_pt1')
        self.source_page.provisioning_source.enter_source_password('testTEST1234!')
        return source_name

    def check_report_integration_defaults(self):
        self.source_page.provisioning_source.click_report_integration_menu()
        assert self.source_page.provisioning_source.is_report_integration_checkbox_enabled() is True
        assert self.source_page.provisioning_source.is_base_report_url_enabled() is False
        assert self.source_page.provisioning_source.is_relative_schema_url_enabled() is False
        assert self.source_page.provisioning_source.is_relative_json_url_enabled() is False
        assert self.source_page.provisioning_source.is_worker_field_name_enabled() is False
        assert self.source_page.provisioning_source.is_query_timeout_enabled() is False

    def check_enable_report_integration_defaults(self):
        self.source_page.provisioning_source.click_enable_report_integration()
        assert self.source_page.provisioning_source.is_base_report_url_enabled() is True
        assert self.source_page.provisioning_source.is_relative_schema_url_enabled() is True
        assert self.source_page.provisioning_source.is_relative_json_url_enabled() is True
        assert self.source_page.provisioning_source.is_worker_field_name_enabled() is True
        assert self.source_page.provisioning_source.is_query_timeout_enabled() is True
        assert self.source_page.provisioning_source.get_worker_field_name_text() == 'Workday_ID'

    def check_min_max_report_query_timeout(self):
        self.source_page.provisioning_source.enter_report_query_timeout(0)
        assert self.source_page.provisioning_source.check_report_query_timeout_invalid() is True
        self.source_page.provisioning_source.enter_report_query_timeout(1)
        assert self.source_page.provisioning_source.check_report_query_timeout_invalid() is False
        self.source_page.provisioning_source.enter_report_query_timeout(21)
        assert self.source_page.provisioning_source.check_report_query_timeout_invalid() is True
        self.source_page.provisioning_source.enter_report_query_timeout(20)
        assert self.source_page.provisioning_source.check_report_query_timeout_invalid() is False

    def check_sync_settings_defaults(self):
        self.source_page.provisioning_source.click_sync_settings_menu()
        assert self.source_page.provisioning_source.is_new_hire_pre_provisioning_interval_enabled() is False

    def check_min_max_pre_provisioning_interval(self):
        self.source_page.provisioning_source.click_new_hire_pre_provision()
        assert self.source_page.provisioning_source.get_pre_provisioning_interval_text() == '120'

        self.source_page.provisioning_source.enter_pre_provisioning_interval(7)
        assert self.source_page.provisioning_source.check_pre_provisioning_interval_invalid() is True
        self.source_page.provisioning_source.enter_pre_provisioning_interval(8)
        assert self.source_page.provisioning_source.check_pre_provisioning_interval_invalid() is False
        self.source_page.provisioning_source.enter_pre_provisioning_interval(337)
        assert self.source_page.provisioning_source.check_pre_provisioning_interval_invalid() is True
        self.source_page.provisioning_source.enter_pre_provisioning_interval(336)
        assert self.source_page.provisioning_source.check_pre_provisioning_interval_invalid() is False

    def check_min_max_workday_tenant_utc_offset(self):
        self.source_page.provisioning_source.enter_tenant_utc_offset(-841)
        assert self.source_page.provisioning_source.check_tenant_utc_offset_invalid() is True
        self.source_page.provisioning_source.enter_tenant_utc_offset(-840)
        assert self.source_page.provisioning_source.check_tenant_utc_offset_invalid() is False
        self.source_page.provisioning_source.enter_tenant_utc_offset(841)
        assert self.source_page.provisioning_source.check_tenant_utc_offset_invalid() is True
        self.source_page.provisioning_source.enter_tenant_utc_offset(840)
        assert self.source_page.provisioning_source.check_tenant_utc_offset_invalid() is False

    def check_sync_reports_defaults(self):
        self.source_page.provisioning_source.click_sync_reports_menu()
        assert self.source_page.provisioning_source.is_sync_report_type_enabled() is False
        assert self.source_page.provisioning_source.is_distribution_add_button_enabled() is False

    def check_add_distribution_btn(self):
        self.source_page.provisioning_source.click_send_report_on_sync_complete()
        self.source_page.provisioning_source.click_add_distribution_btn()
        assert self.source_page.provisioning_source.is_email_input_visible() is True

    def save_provisioning_source(self):
        self.source_page.provisioning_source.click_save_provisioning_source_btn()
