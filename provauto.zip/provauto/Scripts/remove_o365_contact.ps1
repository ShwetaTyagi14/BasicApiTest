param (
[string]$searchstring = "a8a30945contact1"
)

$User = "qaautomation@centrifyqaautomation.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "@ut0m@t3Th1s" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord


Connect-MsolService -Credential $Credential

$create_expression = "Get-MsolContact -SearchString """ + $searchstring + """ | Remove-MsolContact -Force"

Invoke-Expression $create_expression

#debug stuff below:

#Write-Output " "
#write-output "********************"
write-output $searchstring
write-output $create_expression