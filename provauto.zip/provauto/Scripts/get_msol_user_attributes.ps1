param (
    [string]$search_string = "O365ProvSub"
)

$User = "qaautomation@centrifyqaautomation.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "@ut0m@t3Th1s" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

Connect-MsolService -Credential $Credential

$search_expression_Main = "Get-MsolUser -SearchString " + $search_string + " -All"

$userList = Invoke-Expression $search_expression_Main
$out = "{'Users': ["

foreach ($user in $userList){
    $out_attrs = "'Attributes': {"

    $out_attrs += "'Department': '" + $user.Department + "', 'ProxyAddresses': '" + $user.ProxyAddresses + "', 'MobileNumber': '" + $user.MobilePhone + "', 'Title': '" + $user.Title + "'}"

    $out += "{'UserPrincipalName': '" + $user.UserPrincipalName + "', 'DisplayName': '" + $user.DisplayName + "', $out_attrs},"
}

$out = $out.TrimEnd(",") + "]}"
Write-Output $out