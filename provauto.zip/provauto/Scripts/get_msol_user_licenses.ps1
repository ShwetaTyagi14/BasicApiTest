param (
    [string]$search_string = "xxx"
)

$User = "qaautomation@centrifyqaautomation.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "@ut0m@t3Th1s" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

Connect-MsolService -Credential $Credential

$search_expression_Main = "Get-MsolUser -SearchString " + $search_string + " -All"
$get_licenses = (get-msoluser -searchstring "$search_string").Licenses.AccountSkuId

$search_expression_Sub = "(get-msoluser -SearchString " + $search_string + ").Licenses.ServiceStatus"

$sub_licenses = invoke-Expression $search_expression_Sub

$out_license = "'SubLicenses': {"

foreach ($s_license in $sub_licenses){
    $out_license += "'" + $s_license.ServicePlan.ServiceName + "':" + "'" + $s_license.ProvisioningStatus + "', "
}

$out_license = $out_license.TrimEnd(", ") + "}"

$userList = Invoke-Expression $search_expression_Main
$out = "{'Users': ["

foreach ($user in $userList){
    $out += "{'UserPrincipalName': '" + $user.UserPrincipalName + "', 'DisplayName': '" + $user.DisplayName + "', 'Licenses': '" + $get_licenses + "', $out_license },"
}

$out = $out.TrimEnd(",") + "]}"
Write-Output $out


