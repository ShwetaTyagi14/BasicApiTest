param (
    [string]$search_string = ""
)

$User = "qaautomation@centrifyqaautomation.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "@ut0m@t3Th1s" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

Connect-MsolService -Credential $Credential

$search_expression = "Get-MsolUser -SearchString " + $search_string + " -All"

$userList = Invoke-Expression $search_expression
$out = "{'Users': ["

foreach ($user in $userList){
    $out += "{'UserPrincipalName': '" + $user.UserPrincipalName + "', 'DisplayName': '" + $user.DisplayName + "', 'IsLicensed': " + $user.IsLicensed + "},"
}

$out = $out.TrimEnd(",") + "]}"

Write-Output $out
