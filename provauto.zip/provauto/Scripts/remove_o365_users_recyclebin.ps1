﻿param (
[string]$searchstring = "user1"
)

$User = "qaautomation@centrifyqaautomation.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "@ut0m@t3Th1s" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord


Connect-MsolService -Credential $Credential

$create_expression = "Get-MsolUser -SearchString """ + $searchstring + """ -All | Remove-MsolUser -Force"

$create_expression_two = "Get-MsolUser -ReturnDeletedUsers -SearchString """ + $searchstring + """ -All | Remove-MsolUser -RemoveFromRecycleBin -Force"

Invoke-Expression $create_expression

Invoke-Expression $create_expression_two

#debug stuff below:

#Write-Output " "
#write-output "********************"
write-output $searchstring
write-output $create_expression
Write-Output $create_expression_two