param (
    [string]$search_string = ""
)

$User = "qaautomation@centrifyqaautomation.onmicrosoft.com"
$PWord = ConvertTo-SecureString -String "@ut0m@t3Th1s" -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord

Connect-MsolService -Credential $Credential

$search_expression = "Get-MsolContact -SearchString " + $search_string + " -All"

$userList = Invoke-Expression $search_expression
$out = "{'Contacts': ["

foreach ($user in $userList){
    $out += "{'EmailAddress': '" + $user.EmailAddress + "', 'DisplayName': '" + $user.DisplayName + "', 'ObjectId': '" + $user.ObjectId + "'},"
}

$out = $out.TrimEnd(",") + "]}"

Write-Output $out