import logging
import requests
import json

# from Fixtures.global_fixtures import validate_session
from ADLibrary.ad_server import AdServer

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('user_creation.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


def test_generic_ad_environment():
    ad_server = AdServer(
        'LDAPS://10.11.25.13',
        'qascale',
        'admin',
        'Pass@1234'
    )

    ad_server.create_organizational_unit(
        'GeneralProvisionOU',
        'dc=qascale,dc=test'
    )

    for ou in range(5):
        ad_server.create_organizational_unit(
            'ProvisionGroup{}'.format(ou + 1),
            'ou=GeneralProvisionOU,dc=qascale,dc=test'
        )

    ad_server.create_organizational_unit(
        'GroupsOU',
        'ou=GeneralProvisionOU,dc=qascale,dc=test'
    )

    for group in range(5):
        group_users = []
        ad_server.create_ad_group(
            'Group{}'.format(group + 1),
            'OU=GroupsOU,OU=GeneralProvisionOU,DC=qascale,DC=test'
        )

        for user in range(1000):
            ad_server.create_ad_user(
                'OU={},OU=GeneralProvisionOU,DC=qascale,DC=test'.format('ProvisionGroup{}'.format(group + 1)),
                samaccount_name='AWSGroup{}user{}'.format(group + 1, user + 1),
                password='+3St1234',
                first_name='AWSGroup{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='AWSGroup{}user{}@automationrdtesting.com'.format(group + 1, user + 1),
                domain='qascale.test'
            )

            user_string = 'CN={},OU={},OU=GeneralProvisionOU,DC=qascale,DC=test'\
                .format('AWSGroup{}user{}'
                        .format(group + 1, user + 1),
                        'ProvisionGroup{}'
                        .format(group + 1)
                        )

            logger.info('User: {}'.format(user_string))

            group_users.append(user_string)
        # for contact in range(10):
        #     ad_server.create_ad_contact('CF1Test',
        #                                 'Contact {}'.format(contact + 1),
        #                                 'cf1testcontact{}@test.test',
        #                                 'OU={},OU=GeneralProvisionOU,DC=qascale,DC=test'
        #                                 .format('ProvisionGroup{}'
        #                                         .format(group + 1)
        #                                         )
        #                                 )
        #     contact_string = 'CN={},OU={},OU=GeneralProvisionOU,DC=qascale,DC=test'\
        #         .format('Test Contact {}'
        #                 .format(contact + 1),
        #                 'ProvisionGroup{}'
        #                 .format(group + 1)
        #                 )
        #
        #     logger.info('Contact: {}'.format(contact_string))

        ad_server.add_users_to_group(group_users, 'CN=Group{},OU=GroupsOU,OU=GeneralProvisionOU,'
                                                  'DC=qascale,DC=test'.format(group + 1))


# def test_zen_api():
#     creds = {
#         'email': 'appsaccounts@centrify.test',
#         'password': 'fjewiofE123!2!',
#         'subdomain': 'centrifyhelpdesk1354579520'
#     }
#     zenpy_client = Zenpy(**creds)
#     user_list = zenpy_client.users()
#     user = filter(lambda u: u.name == 'user.zendesk', user_list.values)
#
#     for x in user:
#         print(x.name)


def test_update_cases():
    update_json = {
        "custom_automationstatus": 4
    }
    res = requests.get("http://localhost:3000/testrail/getsuites/1")
    suites = json.loads(res.text)

    for suite in suites:
        res = requests.get(f"http://localhost:3000/testrail/getcases/1/{suite['id']}")
        tests = json.loads(res.text)

        for test in tests:
            if test['custom_automationstatus'] is None:
                requests.post(f"http://localhost:3000/testrail/updatetestcase/{test['id']}", update_json)
