import pytest
import time

from mongocred.mongocred import MongoCred

from BrowserSteps.apps_page_steps import AppsPageSteps
from BrowserSteps.navigate_steps import Navigate
from Pages.box_auth_page import BoxAuthPage
from Steps.admin_steps import AdminSteps
from Steps.app_steps import AppSteps
from Steps.cloud_environment_steps import CloudEnvironment
from Steps.data_steps import DataSteps
from Steps.outbound_steps import OutboundSteps

from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker
from driver import Driver


class TestPodValidation:
    def test_basic_login(self, pod_validation):
        api_session = pod_validation['api_session']
        assert api_session is not None

    @pytest.mark.parametrize('source', [
        "Workday",
        "Bamboo",
        "SuccessFactors"
    ])
    def test_inbound_read_creds(self, pod_validation, validation_helpers, source):
        provisioning_worker = ProvisioningWorker(pod_validation, validation_helpers)
        provisioning_worker.validate_inbound_source_creds(source)

    @pytest.mark.parametrize('app', [
        "Trello SCIM",
        "CitrixShareFile",
        "AbsorbLMS",
        "ZenDesk",
        # "Samanage",
        "MangoApps",
        "ServiceNow",
        "NetSuite",
        "Salesforce",
        "FacebookAtWork",
        "AWS"
    ])
    def test_outbound_provisioning_setup(self, pod_validation, validation_helpers, app):
        cloud_setup = CloudSetupWorker(pod_validation, validation_helpers)
        assert cloud_setup.import_application(app, False) is not None

    def test_oauth_box_app_setup(self, ui_validation_apps_page_driver):
        mongo_cred = MongoCred()
        data_steps = DataSteps(mongo_cred)
        box_test_data = data_steps.query_db_collection('automation', 'provision_apps', {'name': 'Box'})

        app_steps = AppsPageSteps(ui_validation_apps_page_driver)
        app_steps.add_web_app(box_test_data['importName'])
        Navigate(ui_validation_apps_page_driver).to_apps_page()
        app_steps.select_web_app_enable_provisioning(box_test_data['importName'])
        app_steps.authorize_provisioning_creds()
        app_steps.switch_to_oauth_window()
        app_steps.validate_authorize_box(
            username=box_test_data['creds']['userName'],
            password=box_test_data['creds']['password']
        )
        time.sleep(10)
        app_steps.click_cancel_provisioning_tab()
        # TODO Figure out why this occasionally fails pulling up the context menu
        # app_steps.delete_provisioning_app(box_test_data['importName'])
