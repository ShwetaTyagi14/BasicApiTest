import uuid
import time

from idaptive_automation.api_client import ApiSession
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker
from idaptive_automation.api_payloads import CloudUser


def test_cloud_tenant(idaptive_session, helpers_fixture):
    cloud_setup = CloudSetupWorker(idaptive_session, helpers_fixture)
    provisioning_worker = ProvisioningWorker(idaptive_session, helpers_fixture)

    role = cloud_setup.create_unique_role()
    for user in range(0, 1000):
        username = str(uuid.uuid4())[0:8]
        user = cloud_setup.create_unique_user(username)
        cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
