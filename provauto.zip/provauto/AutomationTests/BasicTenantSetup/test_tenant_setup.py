import json

from Helpers.DomainInfo import DomainInfo
from Steps.cloud_environment_steps import CloudEnvironment
from Steps.inbound_steps import InboundSteps
from Steps.outbound_steps import OutboundSteps
from Steps.data_steps import DataSteps
from Steps.domain_environment_steps import DomainEnvironmentSteps
import time


def test_tenant_setup(idaptive_session):
    domain_info = DomainInfo()
    app = "EnvTest"
    email_user_name = app[:8]

    num_groups = 5
    num_users = 1000
    num_contacts = 0

    api_session = idaptive_session['api_session']
    data_steps = DataSteps(idaptive_session['mongo_cred'])
    dc_info = idaptive_session['dc_info']
    outbound_steps = OutboundSteps(api_session, data_steps)
    inbound_steps = InboundSteps(api_session)
    domain_environment = DomainEnvironmentSteps(dc_info)
    cloud_environment = CloudEnvironment(api_session, data_steps)

    # TODO: Create AD Environment
    domain_environment.create_ad_environment(
        app[:8],
        num_groups=num_groups,
        num_users=num_users,
        num_contacts=num_contacts
    )

    groups = domain_environment.get_ad_group_details(
        f"{app[:8]}"
    )

    # TODO: Create Group Role
    role_name = f'{app} - Test Role - Remove'
    role_id = cloud_environment.create_core_role(role_name)
    assert role_id is not None

    map_these_groups = []
    for group in groups:
        map_these_groups.append(group['objectGUID'].value.replace('{', '').replace('}', ''))
    assert outbound_steps.map_ad_group_to_core_role(role_id, map_these_groups).success is True

    # # TODO: Create an Inbound Provisioning Source/Rule
    # source = 'Workday'
    # domain_environment.create_basic_ad_ou('Inbound{}TestOU'.format(source))
    # test_data = data_steps.query_db_collection('automation', 'provision_sources', {'name': source})
    #
    # instance_id = cloud_environment.create_inbound_source(
    #     test_data=test_data,
    #     name=f'{source} Source Active Rule'
    # )
    #
    # directory_service_uuid = inbound_steps.get_service_directory_uuid(
    #     DataSteps.load_json_file('GetGenericAPIArgs'),
    #     f"Active Directory: {dc_info['domain_name']}.{dc_info['domain_suffix']}"
    # )
    #
    # ou_tree = inbound_steps.get_ou_tree_content(inbound_steps.build_ou_tree_payload(directory_service_uuid), True)
    # domain_info.domain_name = ou_tree.Name
    # domain_info.domain_ou = ou_tree.DistinguishedName
    # domain_info.directory_descriptor = ou_tree.Name
    # domain_info.domain_guid = ou_tree.Uuid
    # domain_info.directory_service_uuid = directory_service_uuid
    #
    # inbound_steps.get_ou_tree_content(
    #     inbound_steps.build_ou_tree_payload(
    #         None,
    #         domain_info.domain_guid,
    #         False
    #     ), True
    # )
    #
    # domain_info.domain_controller_host_name = inbound_steps.get_domain_controller(
    #     inbound_steps.build_domain_controller_payload(directory_service_uuid, domain_info.domain_name)
    # ).Name
    #
    # domain_info.organizational_unit = f"OU=Inbound{source}TestOU,DC={dc_info['domain_name']},DC={dc_info['domain_suffix']}"
    # domain_info.organizational_unit_display_name = f"Active{source}TestOU"
    #
    # test_data['ruleTemplate']['InstanceId'] = instance_id
    # test_data['ruleTemplate']['DirectoryServiceUuid'] = domain_info.directory_service_uuid
    # test_data['ruleTemplate']['DirectoryDescriptor'] = domain_info.directory_descriptor
    # test_data['ruleTemplate']['OrganizationalUnit'] = domain_info.organizational_unit
    # test_data['ruleTemplate']['ActiveDirectoryRuleData']['OrganizationalUnit'] = domain_info.organizational_unit
    # test_data['ruleTemplate']['ActiveDirectoryRuleData'][
    #     'OrganizationUnitDisplayName'] = domain_info.organizational_unit_display_name
    # test_data['ruleTemplate']['ActiveDirectoryRuleData'][
    #     'DomainControllerHostName'] = domain_info.domain_controller_host_name
    # test_data['ruleTemplate']['ActiveDirectoryRuleData']['DomainName'] = domain_info.domain_name
    # test_data['ruleTemplate']['ActiveDirectoryRuleData']['DomainGuid'] = domain_info.domain_guid
    # test_data['ruleTemplate']['RuleState'] = 'Production'
    # test_data['ruleTemplate']['SourceName'] = f'{source} Source Active Rule'
    # test_data['ruleTemplate']['Name'] = f'{source} Test Active Rule'
    # test_data['ruleTemplate']['NewUserPasswordConfig']['StaticPassword'] = '@bSolution'
    #
    # assert inbound_steps.save_rule(test_data['ruleTemplate']).success is True
    #
    # result = inbound_steps.start_sync_job(instance_id, 'FullSync')
    # job_id = json.loads(result.text)['Result']
    #
    # job_result = None
    # while job_result is None:
    #     job_result = inbound_steps.get_job_report(job_id).Result.report
    #     time.sleep(30)
    #
    # assert "Number of Succeeded worker syncs: " in job_result

    # TODO: Build out Provisioning App Catalog
    apps_list = ['ZenDesk', 'Salesforce', 'Samanage', 'ServiceNow', 'NetSuite', 'CitrixShareFile', 'AbsorbLMS', 'FacebookAtWork']
    for app in apps_list:
        try:
            test_data = data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
            app_key = cloud_environment.import_app(test_data['importName'])
            assert app_key is not None

            if test_data['updateApplicationDE'] is not None:
                assert outbound_steps.update_application_de(app_key, test_data['updateApplicationDE']).success is True

            # TODO Not in love with how this is done
            test_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
            assert outbound_steps.update_app(app_key, test_data['updateAppProvisioning']).success is True
            assert outbound_steps.get_app(app_key).success is True

            job_result = outbound_steps.request_outbound_full_sync(app_key)
            assert job_result['success'] is True
            job_id = job_result['Result']['JobId']

            job_result = None
            while job_result is None:
                job_result = outbound_steps.get_job_result_base(job_id)
                time.sleep(15)

                outbound_steps.validate_user_prov_status(
                    app_id=app_key,
                    expected_status="'Created','Merged','Updated'"
                )
        except:
            pass


    # TODO: Create O365 App with Provisioning
    app_key = cloud_environment.import_app('Office 365v2')
    assert outbound_steps.o365_update_hybrid_settings(app_key, f'{role_name}', dc_info['default_login_suffix'],
                                                      sync_contact=True).success is True
    assert outbound_steps.set_app_permission(app_key, role_id).success is True
    job_result = outbound_steps.request_outbound_full_sync(app_key)
    assert job_result['success'] is True
