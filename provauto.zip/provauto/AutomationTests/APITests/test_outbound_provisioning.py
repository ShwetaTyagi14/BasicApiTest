"""
Contains all functional tests for Outbound SAML App Provisioning that are not UI driven.
Additionally these tests are not app specific, app specific tests reside in their own .py file
Apps Tested:  ZenDesk, Salesforce, SaManage, MangoApps, ServiceNow, NetSuite, CitrixShareFile,
AbsorbLMS, FacebookAtWork, WebEx
"""
import uuid
import boto3
import pytest

from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import ApiSession
from idaptive_automation.api_helpers import AppHelper, RoleApi, UserApi, RedrockApi, CDirectoryService
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C22392')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_outbound_provisioning_setup(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22392  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)

    assert cloud_setup.import_application(app, False) is not None


@pytestrail.case('C33590')
@pytest.mark.pipeline
def test_save_notification_settings(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33590  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    provisioning_worker.save_notification_settings()
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C22393')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork",
    "WebEx"
])
def test_basic_cloud_user_prov_then_deprov(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22393  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C33640')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_validate_sync_report_email(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33640  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    dc_info = cloud_session['dc_info']

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    provisioning_worker.save_notification_settings()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    provisioning_worker.validate_email([
                'Sync Report Summary',
                user['user_id'],
                f"user.{app.lower()}@{dc_info['default_email_suffix']}"])
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C22395')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_preview_mode_provisioning(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22395  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app=app,
                                             setup_provisioning=True,
                                             role_name=role['role_name'],
                                             preview_mode=True)
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "Sync Preview Mode")


@pytestrail.case('C33412')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_live_switch_to_preview(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33412  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app=app,
                                             setup_provisioning=True,
                                             role_name=role['role_name'],
                                             preview_mode=False)

    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'],
                           preview_mode=True)
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "Sync Preview Mode")


@pytestrail.case('C33402')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_preview_switch_to_live(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33402  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app=app,
                                             setup_provisioning=True,
                                             role_name=role['role_name'],
                                             preview_mode=True)

    job_result = provisioning_worker.fire_app_sync_job(app_key)
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "Sync Preview Mode")

    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'],
                           preview_mode=False)

    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C22394')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_basic_ad_user_prov_then_deprov(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22394  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    basename = str(uuid.uuid4())[0:8]

    domain_worker.create_ad_environment(
        base_name=basename,
        default_password='testTEST1234!@',
        num_groups=5,
        num_users=5
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(basename)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    # FIXME I'm not entirely sure how much I like this block - Possible refactor candidate
    for user in range(5):
        user_name = f'{basename}user{user + 1}'
        domain_worker.disable_user_in_ad(
            user_name=user_name,
            ou_string=f'ou={basename}'
        )
        user_id = cloud_setup.get_user_details_from_email(user_name=user_name)
        cloud_setup.refresh_user_token(user_id)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Deactivated'")


@pytestrail.case('C28112')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_multiple_roles_prov_deprov(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28112  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    roles = []
    basename = str(uuid.uuid4())[0:8]

    domain_worker.create_ad_environment(
        base_name=basename,
        default_password='testTEST1234!@',
        num_groups=5,
        num_users=5
    )
    role = cloud_setup.create_unique_role()
    roles.append(role)
    groups = domain_worker.get_ad_group_details(basename)
    cloud_setup.add_ad_groups_to_role(role['role_id'], [groups[0]])
    app_key = cloud_setup.import_application(
        app=app,
        setup_provisioning=True,
        role_name=role['role_name']
    )
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    role_2 = cloud_setup.create_unique_role()
    roles.append(role_2)
    cloud_setup.add_ad_groups_to_role(role_2['role_id'], [groups[1]])
    cloud_setup.append_role_to_app(
        app=app,
        app_key=app_key,
        setup_provisioning=True,
        roles=roles
    )
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    # FIXME I'm not entirely sure how much I like this block - Possible refactor candidate
    for user in range(5):
        user_name = f'{basename}user{user + 1}'
        domain_worker.disable_user_in_ad(
            user_name=user_name,
            ou_string=f'ou={basename}'
        )
        try:
            user_id = cloud_setup.get_user_details_from_email(user_name=user_name)
            cloud_setup.refresh_user_token(user_id)
        except Exception:  # pylint: disable=broad-except
            # If there is an error refreshing the token it means the user has already been removed
            # or never existed in the first place - so we can move on
            pass
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Deactivated'")


@pytestrail.case('C33181')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "ZenDesk",
    "Salesforce",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "CitrixShareFile",
    "AbsorbLMS",
    "FacebookAtWork"
])
def test_sync_user_invalid_email(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33181  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    domain_worker.create_ad_environment(
        base_name=app[:8],
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{app[:8]}user1',
        ou_string=f'ou={app[:8]}',
        attribute_name='mail',
        attribute_value='test'
    )
    provisioning_worker.save_notification_settings()
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(app[:8])
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    app_key = cloud_setup.import_application(
        app=app,
        setup_provisioning=True,
        role_name=role['role_name']
    )
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(
        job_id=job_id,
        validate_message="the application requires an e-mail address which is not valid for the user"
    )
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C22396')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_delete_provisioned_app(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22396  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)

    app_key = cloud_setup.import_application(app, False)
    assert app_key is not None
    cloud_setup.delete_application(app_key)


@pytestrail.case('C22')
@pytest.mark.pipeline
def test_generic_saml_slack_setup(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22  """
    app = "GenericSAMLSlack"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    app_key = cloud_setup.import_application(
        app=app,
        setup_provisioning=True,
        role_name=role['role_name'],
        update_app=False
    )
    cloud_setup.saml_update_app(
        app_key,
        'https://api.slack.com/scim/v1',
        'xoxp-3428720405-3428720407-12036746626-39a97ed49f'
    )


@pytestrail.case('C25')
@pytest.mark.pipeline
def test_trello_scim_provisioning(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/25  """
    app = "TrelloSCIM"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    app_key = cloud_setup.import_application(
        app=app,
        setup_provisioning=True,
        role_name=role['role_name'],
        update_app=False
    )
    cloud_setup.saml_update_app(
        app_key,
        'https://trello.com/scim/v2',
        '11faac7d7a6480bc1ff86189579c83a6f0ea16a70cd24964b7b1dc921977bc61'
    )


@pytestrail.case('C22398')
@pytest.mark.pipeline
def test_existing_aws_user_initial_sync(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22398  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    iam = boto3.resource('iam')
    aws_user = iam.create_user(UserName=user['user'].email)
    app = "AWSConsole"
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert aws_user.arn is not None
    provisioning_worker.save_notification_settings()
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(
        job_id=job_id,
        validate_message="Value cannot be null.",
        negative_check=True
    )
    user = iam.User(aws_user.user_name)
    user.remove_group(GroupName='groupB')
    user.delete()
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C27786')
@pytest.mark.pipeline
def test_cus_user_no_app_management(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/27786  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    cloud_setup.assign_role_super_rights(role['role_id'], 'Admin No App Management')

    # FIXME Not in love with this - but we need to create a new session with the new users creds
    api_session = ApiSession(
        base_url=cloud_session['api_session'].base_url,
        tenant_id=cloud_session['api_session'].tenant_id,
        username=user['user'].name,
        password=user['user'].password
    )
    new_user_session = {
        'api_session': api_session,
        'mongo_cred': cloud_session['mongo_cred'],
        'dc_info': cloud_session['dc_info']
    }
    helpers = {}
    with AppHelper(new_user_session['api_session'], True) as app_helper, \
            RoleApi(new_user_session['api_session'], True) as role_helper, \
            UserApi(new_user_session['api_session'], True) as user_helper, \
            RedrockApi(new_user_session['api_session']) as redrock_helper, \
            CDirectoryService(new_user_session['api_session']) as cdirectory_helper:
        helpers['app_helper'] = app_helper
        helpers['role_helper'] = role_helper
        helpers['user_helper'] = user_helper
        helpers['redrock_helper'] = redrock_helper
        helpers['cdirectory_helper'] = cdirectory_helper
    new_user_cloud_worker = CloudSetupWorker(new_user_session, helpers)

    app = "AWSConsole"
    new_user_cloud_worker.import_application_check_response(
        app=app,
        validate_response='You are not authorized to perform this operation. Please contact your IT helpdesk.'
    )
    app_key = cloud_setup.import_application(app)
    new_user_cloud_worker.update_app_check_response(
        app=app,
        app_key=app_key,
        validate_response='You are not authorized to perform this operation. Please contact your IT helpdesk.'
    )


@pytestrail.case('C40181')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_multiple_user_types_in_role(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40181  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    domain_worker.create_ad_environment(
        base_name=app[:8],
        default_password='testTEST1234!@',
        num_groups=5,
        num_users=5
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(app[:8])
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C40180')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_switch_cloud_user_role(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40180  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_user_from_role(role['role_id'], user['user_id'])
    second_role = cloud_setup.create_unique_role()
    cloud_setup.add_user_to_role(second_role['role_id'], user['user_id'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C40182')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_outbound_provisioning_changelog(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40182  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    app_key = cloud_setup.import_application(app, False)
    cloud_setup.validate_provisioning_changelog(app_key)


@pytestrail.case('C40207')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_create_destination_group_one_empty_source(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40207  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    provisioning_worker.save_notification_settings()
    role = cloud_setup.create_unique_role()
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] == 0
    provisioning_worker.validate_job_report(job_id, 'No users found to sync.')
    provisioning_worker.validate_job_report(job_id, f"Role {role['role_id']}: 0 users found")
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C40220')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_can_provision_cus_with_alphanumeric_name(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40220  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user(str(uuid.uuid4())[0:8])
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C40230')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_full_sync_email_report_sync_success(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40230  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    provisioning_worker.save_notification_settings()
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    provisioning_worker.validate_email(['A new directory synchronization report'])
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C70035')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_nested_roles(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/70035  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    provisioning_worker.save_notification_settings()
    parent_role = cloud_setup.create_unique_role()
    child_role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(child_role['role_id'], user['user_id'])
    cloud_setup.add_child_role_to_parent_role(parent_role['role_id'], child_role['role_id'])
    app_key = cloud_setup.import_application(app, True, parent_role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
    provisioning_worker.reset_notification_settings()


@pytestrail.case('C70219')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_sync_all_apps_in_user_management(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/70219  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_user_sync_job(user['user_id']) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_map_all_optional_attributes(app, cloud_session, helpers):
    """ Test Case Link :  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.map_all_not_required_attributes(app, app_key, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C33660')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "Trello SCIM",
    "CitrixShareFile",
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork"
])
def test_provision_from_google_directory_services(app, cloud_session):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33660  """
    # FIXME This test needs to be reworked - as it stands it will only run on a tenant that is federated to GDS
    #   Need to somehow incorporate the federation of GDS into new tenants
    #   Until then I am going to simply mark this test as pass so it doesn't screw up a run
    pass
    # api_session = cloud_session['api_session']
    #
    # data_steps = DataSteps(cloud_session['mongo_cred'])
    # outbound_steps = OutboundSteps(api_session, data_steps)
    # cloud_environment = CloudEnvironment(api_session, data_steps)
    #
    # try:
    #     role_name = '{} GDS Provisioning - Test Role - Remove'.format(app)
    #     test_data = data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
    #
    #     role_id = cloud_environment.create_core_role(role_name)
    #     assert role_id is not None
    #
    #     map_these_users = '113657461437619836812-de198581820242c8b8a2687a297d9e9b'
    #     assert outbound_steps.map_user_to_core_role(role_id, map_these_users).success is True
    #
    #     app_key = cloud_environment.import_app(test_data['importName'])
    #     assert app_key is not None
    #
    #     if test_data['updateApplicationDE'] is not None:
    #         assert outbound_steps.update_application_de(app_key, test_data['updateApplicationDE']).success is True
    #
    #     test_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
    #
    #     assert outbound_steps.update_app(app_key, test_data['updateAppProvisioning']).success is True
    #     assert outbound_steps.get_app(app_key).success is True
    #
    #     job_result = outbound_steps.request_outbound_full_sync(app_key)
    #     assert job_result['success'] is True
    #
    #     job_id = job_result['Result']['JobId']
    #     job_result = None
    #     while job_result is None:
    #         job_result = outbound_steps.get_job_result_base(job_id)
    #         time.sleep(15)
    #
    #     outbound_steps.validate_user_prov_status(
    #         app_id=app_key,
    #         expected_status="'Created','Merged'"
    #     )
    #
    #     assert outbound_steps.remove_user_from_core_role(role_id, map_these_users).success is True
    #
    #     job_result = outbound_steps.request_outbound_full_sync(app_key)
    #     assert job_result['success'] is True
    #
    #     job_id = job_result['Result']['JobId']
    #     job_result = None
    #     while job_result is None:
    #         job_result = outbound_steps.get_job_result_base(job_id)
    #         time.sleep(15)
    #
    #     outbound_steps.validate_user_prov_status(
    #         app_id=app_key,
    #         expected_status="'Deactivated'"
    #     )
    # finally:
    #     cloud_environment.clean_cloud_environment()


@pytestrail.case('C93671')
@pytest.mark.pipeline
@pytest.mark.parametrize('app', [
    "AbsorbLMS",
    "ZenDesk",
    # "Samanage",
    "MangoApps",
    "ServiceNow",
    # "NetSuite",
    "Salesforce",
    "FacebookAtWork",
    "CitrixShareFile"
])
def test_set_password_attributes_in_provisioning(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/93671  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'], destination_attribute='Password',
                                                  destination_attribute_value="Pass@12345")
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
