""" Contains all functional tests that are 'AmazonWebService_specific' """

from idaptive_testrail.plugin import testrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@testrail('C117803')
def test_modify_aws_specific_user_attribute(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117803  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    display_name = cloud_setup.get_user_attribute_value(user, 'display_name')
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app = "AWSConsole"
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'],
                                                  destination_attribute='Username',
                                                  destination_attribute_value=display_name)
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, str(display_name) + " " + "(" + user['user_id'] + ")" + " "
                                            + "=>" + " " + str(display_name))
    provisioning_worker.validate_job_report(job_id, 'User updated:')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@testrail('C117802')
def test_sync_up_user_to_sepecial_charaters_group(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117802  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app = "AWSConsole"
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute_for_aws_specific(app, app_key, role['role_name'],
                                                                 group_value='+=,.@-_',
                                                                 friendly_value='+=,.@-_')
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"Value":"+=,.@-_"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@testrail('C117804')
def test_sync_up_user_to_administrators_destination_group(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117804	  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app = "AWSConsole"
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute_for_aws_specific(app, app_key, role['role_name'],
                                                                 group_value='Administrators',
                                                                 friendly_value='Administrators')
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"Value":"Administrators"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@testrail('C117805')
def test_sync_up_user_to_sales_destination_group(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117805	 """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app = "AWSConsole"
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute_for_aws_specific(app, app_key, role['role_name'],
                                                                 group_value='Sales',
                                                                 friendly_value='Sales')
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"Value":"Sales"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@testrail('C117806')
def test_sync_up_same_user_different_role_with_multiple_destination_group(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/C117806  """
    app = "AWSConsole"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    roles = []
    role_1 = cloud_setup.create_unique_role()
    roles.append(role_1)
    role_2 = cloud_setup.create_unique_role()
    roles.append(role_2)
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role_1['role_id'], user['user_id'])
    cloud_setup.add_user_to_role(role_2['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role_1['role_name'])
    cloud_setup.append_role_to_app_for_aws_specific(app=app, app_key=app_key, setup_provisioning=True, roles=roles,
                                                    list_licences=["Administrators", "Sales"])
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"Value":"Administrators"')
    provisioning_worker.validate_job_report(job_id, '"Value":"Sales"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
