"""
Contains all functional tests for Outbound SAML App Provisioning that are not UI driven.
Additionally these tests are not app specific, app specific tests reside in their own .py file
Apps Tested:  ZenDesk, Salesforce, SaManage, MangoApps, ServiceNow, NetSuite, CitrixShareFile,
AbsorbLMS, FacebookAtWork, WebEx
"""
import requests


from Workers.cloud_setup_worker import CloudSetupWorker


def test_oauth_server_token_retrieval(cloud_session, helpers):
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    app_key = cloud_setup.import_oauth_server_application()

    assert app_key is not None
    cloud_setup.set_application_permissions(app_key=app_key,
                                            role_name='Everybody')

    user = cloud_setup.create_unique_user()['user']
    service_user = cloud_setup.create_service_user()['user']

    # TODO Move below code block to a worker library
    payload = {
        'scope': 'all',
        'grant_type': "password",
        'username': user.name,
        'password': user.password,
        'client_id': service_user.name,
        'client_secret': service_user.password
    }
    headers = {
        'X-CENTRIFY-NATIVE-CLIENT': 'true',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    r = requests.post(f"{cloud_session['api_session'].base_url}/oauth2/token/OAuth2Test", headers=headers, data=payload)
    token = eval(r.text)
    # TODO End code block

    assert token['access_token'].__len__() > 0
    assert token['token_type'] == 'Bearer'
    assert token['expires_in'] == 18000
