""" Contains all functional tests that are ServiceNow Specific"""

from idaptive_testrail.plugin import pytestrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C40231')
def test_mapped_destination_role_chat_admin(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40231  """
    app = "ServiceNow"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute_for_servicenow(app, app_key, role['role_name'],
                                                               license_value='chat_admin',
                                                               friendly_value='chat_admin')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"Value":"chat_admin"')
    provisioning_worker.validate_job_report(job_id, '"Friendly":"chat_admin"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C70241')
def test_switch_mapped_destination_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/70241  """
    app = "ServiceNow"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])

    cloud_setup.updating_role_mapping_attribute_for_servicenow(app, app_key, role['role_name'],
                                                               license_value='activity_creator',
                                                               friendly_value='activity_creator')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"Value":"activity_creator"')
    provisioning_worker.validate_job_report(job_id, '"Friendly":"activity_creator"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117591')
def test_modify_provisioning_script_with_new_attribute(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117591  """
    app = "ServiceNow"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='mobile_phone',
                                                          destination_attribute_value=1234567890)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"mobile_phone":"1234567890"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117592')
def test_switch_mapped_source_role_and_destination_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117592  """
    app = "ServiceNow"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute_for_servicenow(app, app_key, role['role_name'],
                                                               license_value='approver_user',
                                                               friendly_value='approver_user')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"Value":"approver_user"')
    provisioning_worker.validate_job_report(job_id, '"Friendly":"approver_user"')
    role_2 = cloud_setup.create_unique_role()
    user_2 = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role_2['role_id'], user_2['user_id'])
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role_2['role_name'])

    cloud_setup.updating_role_mapping_attribute_for_servicenow(app, app_key, role_2['role_name'],
                                                               license_value='activity_creator',
                                                               friendly_value='activity_creator')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result_new = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result_new is not None
    job_id_new = job_result_new['Row']['JobUniqueId']
    assert job_result_new['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id_new, '"Value":"activity_creator"')
    provisioning_worker.validate_job_report(job_id_new, '"Friendly":"activity_creator"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
