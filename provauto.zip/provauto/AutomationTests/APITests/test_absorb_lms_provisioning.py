""" Contains all functional tests that are Absorb LMS Specific"""
import pytest

from idaptive_testrail.plugin import pytestrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C93706')
@pytest.mark.parametrize('destination_role', [
    "IsLearner"
])
def test_set_role_permission_learner(cloud_session, helpers, destination_role):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/93706  """
    app = "AbsorbLMS"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'],
                                                  destination_attribute=destination_role,
                                                  destination_attribute_value=True)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C93719')
@pytest.mark.parametrize('destination_role', [
    "IsInstructor"
])
def test_set_role_permission_instructor(cloud_session, helpers, destination_role):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/C93719 """
    app = "AbsorbLMS"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'],
                                                  destination_attribute=destination_role,
                                                  destination_attribute_value=True)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C93720')
@pytest.mark.parametrize('destination_role', [
    "IsAdmin"
])
def test_set_role_permission_admin(cloud_session, helpers, destination_role):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/C93720  """
    app = "AbsorbLMS"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'],
                                                  destination_attribute=destination_role,
                                                  destination_attribute_value=True)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C93721')
def test_set_role_without_permission(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/C93721 """
    app = "AbsorbLMS"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role['role_name'], role_attribute='Learner',
                                                role_attribute_value=False)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117600')
def test_modify_provisioning_script_with_new_attribute(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117600  """
    app = "AbsorbLMS"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'], destination_attribute='LastName',
                                                  destination_attribute_value='LastgnameUpdated')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"LastName":"LastgnameUpdated"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117601')
def test_set_provisioning_script_overwrite_role_mapping_attribute(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/C117601 """
    app = "AbsorbLMS"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    mapping_script = "destination.Username = source.CanonicalizeName;" \
                     "destination.EmailAddress = source.Email;" \
                     "destination.FirstName = source.Get('givenName');" \
                     "destination.LastName = source.Get('sn');" \
                     "if (!destination.FirstName || !destination.LastName) {" \
                     "var displayName = source.DisplayName;" \
                     "var nameBits = displayName.split( / \s / );" \
                     "destination.FirstName = nameBits[0];" \
                     "destination.LastName = nameBits[nameBits.length - 1];}" \
                     "if (source.OfficePhone != null && source.OfficePhone != \"\")" \
                     "{destination.Phone = source.OfficePhone;}"\
                     "else if (source.MobilePhone != null && source.MobilePhone != \"\")" \
                     "{destination.Phone = source.MobilePhone;}else {destination.Phone = source.HomePhone;}" \
                     "destination.IsLearner = false;" \
                     "destination.IsInstructor = true;" \
                     "destination.IsAdmin = true;"
    cloud_setup.updating_role_mapping_for_attribute_absorblms(app, app_key, role['role_name'],
                                                              learner_attribute_value=True,
                                                              instructor_attribute_value=True,
                                                              mapping_script=mapping_script,
                                                              admin_attribute_value=None)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
