""" Contains all functional tests that are WebEx specific"""
from idaptive_testrail.plugin import pytestrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C117588')
def test_modify_user_attributes_event_center(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117588  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='supportedServices_eventCenter',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"eventCenter":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117579')
def test_modify_user_attributes_teleconf_callin_international(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117579  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_teleConfCallInInternational',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"teleConfCallInInternational":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117580')
def test_modify_user_attributes_teleconf_callout_international(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117580  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_teleConfCallOutInternational ',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"teleConfCallOutInternational":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117581')
def test_modify_user_attributes_teleconf_callout(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117581  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_teleConfCallOut',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"teleConfCallOut":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117582')
def test_modify_user_attributes_teleconf_callin(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117582  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_teleConfCallIn',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"teleConfCallIn":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117583')
def test_modify_user_attributes_lab_admin(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117583  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_labAdmin',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"labAdmin":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117584')
def test_modify_user_attributes_attendee_only(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117584  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_attendeeOnly',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"attendeeOnly":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117585')
def test_modify_user_attributes_recording_editor(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117585  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_recordingEditor',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"recordingEditor":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117586')
def test_modify_user_attributes_training_center(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/1175786  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='supportedServices_trainingCenter',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"trainingCenter":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117587')
def test_modify_user_attributes_support_center(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/  117587  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='supportedServices_supportCenter',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"supportCenter":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117723')
def test_modify_provisioning_script_attribute_ro_site_admin(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117723  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_roSiteAdmin',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"roSiteAdmin":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117724')
def test_modify_user_attributes_meeting_assist(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117724  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='privilege_meetingAssist',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"meetingAssist":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117725')
def test_modify_user_attributes_supported_services_sales_center(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117725  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='supportedServices_salesCenter',
                                                          destination_attribute_value='false')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"salesCenter":"false"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117722')
def test_modify_meeting_types_attribute(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117722  """
    app = 'WebEx'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    mapping_script = "destination.webExId = source.CanonicalizeName;"\
                     "destination.email = source.Email;" \
                     "var nameTokens = source.DisplayName.split(\" \");" \
                     "destination.firstName = nameTokens[0];" \
                     "if (nameTokens.length == 1) {destination.lastName = nameTokens[0];}" \
                     "else {destination.lastName = nameTokens.slice(1, nameTokens.length).join(\" \");}" \
                     "destination.supportedServices.meetingCenterSpecified=true;" \
                     "destination.supportedServices.meetingCenter=true;" \
                     "destination.meetingTypes = [16,564];"
    cloud_setup.updating_role_mapping_for_webex(app, app_key, role['role_name'], mapping_script=mapping_script)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"meetingCenter":"true"')
    provisioning_worker.validate_job_report(job_id, '"meetingTypes":["16","564"]')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
