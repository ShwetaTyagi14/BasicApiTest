""" Contains all functional tests that are Zendesk app specific """


from idaptive_testrail.plugin import pytestrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker

# @pytestrail.case('C40232')
# @pytest.mark.parametrize('dest_role', [
#     "admin"
#  ])
# def test_cloud_user_dest_role(dest_role, cloud_session):
#     app = "ZenDesk"
#     api_session = cloud_session['api_session']
#     dc_info = cloud_session['dc_info']
#
#     data_steps = DataSteps(cloud_session['mongo_cred'])
#     outbound_steps = OutboundSteps(api_session, data_steps)
#     cloud_environment = CloudEnvironment(api_session, data_steps)
#     integration_steps = IntegrationAppSteps()
#
#     try:
#         role_name = '{} CUS Provisioning - Test Role - Remove'.format(app)
#         test_data = data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
#
#         user_id = cloud_environment.create_cloud_user(f"user.{app.lower()}", dc_info)
#         assert user_id is not None
#
#         role_id = cloud_environment.create_core_role(role_name)
#         assert role_id is not None
#         assert outbound_steps.map_user_to_core_role(role_id, user_id).success is True
#
#         app_key = cloud_environment.import_app(test_data['importName'])
#         assert app_key is not None
#
#         if test_data['updateApplicationDE'] is not None:
#             assert outbound_steps.update_application_de(app_key, test_data['updateApplicationDE']).success is True
#
#         test_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
#         test_data['updateAppProvisioning']['mergeusers'] = True
#         test_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationRole'] = dest_role
#
#         assert outbound_steps.update_app(app_key, test_data['updateAppProvisioning']).success is True
#         assert outbound_steps.get_app(app_key).success is True
#
#         job_result = outbound_steps.request_outbound_full_sync(app_key)
#         assert job_result['success'] is True
#         outbound_steps.validate_user_prov_status(
#             app_id=app_key,
#             expected_status="'Created','Merged','Updated'"
#         )
#
#         assert integration_steps.get_user_from_zen(f"user.{app.lower()}").role == 'admin'
#
#         cloud_environment.delete_cloud_user(user_id)
#
#         job_result = outbound_steps.request_outbound_full_sync(app_key)
#         assert job_result['success'] is True
#
#         outbound_steps.validate_user_prov_status(
#             app_id=app_key,
#             expected_status="'Deactivated'"
#         )
#     finally:
#         cloud_environment.clean_cloud_environment()


@pytestrail.case('C93724')
def test_modify_user_attributes(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/93724  """
    app = "ZenDesk"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    email_id = cloud_setup.get_user_attribute_value(user, 'email')
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    provisioning_worker.save_notification_settings()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, email_id)
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])
    cloud_setup.script_specific_attribute_mapping(app, app_key, role['role_name'], destination_attribute='Email',
                                                  destination_attribute_value="xyz@testing.com")
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, "xyz@testing.com")
    cloud_setup.remove_all_users()


@pytestrail.case('C117595')
def test_sync_up_user_to_agent_destination_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117595  """
    app = "ZenDesk"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role['role_name'], role_attribute='DestinationRole',
                                                role_attribute_value="agent")
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"role":"agent"')
    cloud_setup.remove_all_users()


@pytestrail.case('C117596')
def test_sync_up_user_to_end_user_destination_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117596  """
    app = "ZenDesk"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role['role_name'], role_attribute='DestinationRole',
                                                role_attribute_value="end-user")
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"role":"end-user"')
    cloud_setup.remove_all_users()


@pytestrail.case('C117594')
def test_switch_both_the_mapped_source_role_and_destination_role_to_re_sync_users(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117594  """
    app = "ZenDesk"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role_1 = cloud_setup.create_unique_role()
    role_2 = cloud_setup.create_unique_role()
    user_1 = cloud_setup.create_unique_user()
    user_2 = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role_1['role_id'], user_1['user_id'])
    app_key = cloud_setup.import_application(app, True, role_1['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role_1['role_name'], role_attribute='DestinationRole',
                                                role_attribute_value="admin")
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.add_user_to_role(role_2['role_id'], user_2['user_id'])
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role_2['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role_2['role_name'], role_attribute='DestinationRole',
                                                role_attribute_value="end-user")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, 'User deprovisioned:')
    provisioning_worker.validate_job_report(job_id, 'User added:')
    cloud_setup.remove_all_users()


@pytestrail.case('C117593')
def test_switch_mapped_destination_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117593  """
    app = "ZenDesk"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role['role_name'], role_attribute='DestinationRole',
                                                role_attribute_value="agent")
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])
    cloud_setup.updating_role_mapping_attribute(app, app_key, role['role_name'], role_attribute='DestinationRole',
                                                role_attribute_value="admin")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, 'User updated:')
    cloud_setup.remove_all_users()
