""" Contains all functional tests that are O365 Specific"""
import uuid
import time

import pytest
from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import ApiSession
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.ms_office_worker import MsOfficeWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C23')
@pytest.mark.pipeline
def test_o365_basic_provisioning(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/23  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28')
@pytest.mark.pipeline
def test_o365_mismatched_suffix_provisioning(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='userPrincipalName',
        attribute_value=f"{base_name}user1@{dc_info['default_login_suffix']}"
    )
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Failed',
        user_principal_name=f"{base_name}user1@{dc_info['default_login_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'],
                                            'User with the given userPrincipalName not found.')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C27')
@pytest.mark.pipeline
def test_o365_cus_provisioning(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/27  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()

    try:
        cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
        office_worker.import_o365_instance(update_app=True,
                                           roles=[role],
                                           setup_script='O365modUPNwithScript')
        cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                                role_name=role['role_name'])
        provisioning_worker.fire_app_sync_job(office_worker.app_key)
        provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
        office_worker.validate_msoffice_user_license(user_name=user['user'].login_name,
                                                     expected_license='centrifyqaautomation:ENTERPRISEPACK')
    finally:
        office_worker.clean_msoffice_online(user['user'].login_name)


@pytestrail.case('C26')
@pytest.mark.pipeline
def test_o365_cus_remove_user_from_role_deprovision(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/26  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    dc_info = cloud_session['dc_info']

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365modUPNwithScript')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=user['user'].login_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    cloud_setup.remove_user_from_role(role['role_id'], user['user_id'])
    cloud_setup.refresh_user_token(user['user_id'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{user['user'].login_name}@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User deprovisioned:')
    office_worker.validate_msoffice_user_license(user_name=user['user'].login_name, expected_user_count=0)
    office_worker.clean_msoffice_online(user['user'].login_name)


@pytestrail.case('C2116')
@pytest.mark.pipeline
def test_o365_ad_disable_user_delete_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/2116  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.disable_user_in_ad(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}'
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User deprovisioned:')
    office_worker.validate_msoffice_user_license(
        user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
        expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C5813')
@pytest.mark.pipeline
def test_o365_ad_remove_from_group_no_deprovision(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/5813  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       retainDeprovAccount=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.remove_user_from_group(
        f"CN={base_name}user1,OU={base_name},DC={dc_info['domain_name']},DC={dc_info['domain_suffix']}",
        f"CN={base_name}Group1,OU={base_name},DC={dc_info['domain_name']},DC={dc_info['domain_suffix']}"
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(
        query_results[0]['Row']['JobUniqueId'],
        f"{base_name}user1@{dc_info['default_email_suffix']} because provisioning setting")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28149')
@pytest.mark.pipeline
def test_o365_ad_delete_user_delete_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28149  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.delete_ad_user(
        f"{base_name}user1", f"OU={base_name}"
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User deprovisioned:')
    office_worker.validate_msoffice_user_license(
        user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
        expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C22404')
@pytest.mark.pipeline
def test_o365_immutable_id_mapping_script(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/22404  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365UpdateAppDataImmutableScript')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    user_guid = domain_worker.get_ad_user_attribute('Administrator', f"CN=Users", 'objectGUID')
    converted_immutable_id = office_worker.convert_object_guid_to_immutable_id(user_guid)
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='description',
        attribute_value=converted_immutable_id
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28143')
@pytest.mark.pipeline
def test_o365_assign_single_license_by_order(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28143  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    initial_role = cloud_setup.create_unique_role()
    secondary_role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(initial_role['role_id'], groups)
    cloud_setup.add_ad_groups_to_role(secondary_role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[initial_role, secondary_role],
                                       setup_script='O365UpdateAppDataLicenseOrderScript')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=initial_role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28144')
@pytest.mark.pipeline
def test_o365_assign_specific_license_services(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28144  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    initial_role = cloud_setup.create_unique_role()
    secondary_role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(initial_role['role_id'], groups)
    cloud_setup.add_ad_groups_to_role(secondary_role['role_id'], groups)
    disabled_service_plans = [initial_role['role_name'], initial_role['role_name']]
    office_worker.import_o365_instance(update_app=True,
                                       roles=[initial_role, secondary_role],
                                       setup_script='O365UpdateAppDataSubLicenseScript',
                                       disabled_service_plans=disabled_service_plans)
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=initial_role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.validate_msoffice_sub_license(user_name=base_name,
                                                license_name='SWAY',
                                                status='Disabled')
    office_worker.validate_msoffice_sub_license(user_name=base_name,
                                                license_name='TEAMS1',
                                                status='Disabled')
    office_worker.validate_msoffice_sub_license(user_name=base_name,
                                                license_name='OFFICESUBSCRIPTION',
                                                status='Success')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28145')
@pytest.mark.pipeline
def test_o365_app_with_large_json_file(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28145  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    initial_role = cloud_setup.create_unique_role()
    secondary_role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(initial_role['role_id'], groups)
    cloud_setup.add_ad_groups_to_role(secondary_role['role_id'], groups)
    office_worker.import_o365_instance(
        update_app=True,
        roles=[initial_role, secondary_role, initial_role, secondary_role, initial_role, initial_role],
        setup_script='CISSUP4725_smaller'
    )
    # This very large script is expected to not work
    try:
        office_worker.import_o365_instance(
            update_app=True,
            roles=[initial_role, secondary_role, initial_role, secondary_role, initial_role, initial_role],
            setup_script='CISSUP4725'
        )
    except AssertionError:
        pass


@pytestrail.case('C28146')
@pytest.mark.pipeline
def test_o365_assign_conflicting_licenses(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28146  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    initial_role = cloud_setup.create_unique_role()
    secondary_role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(initial_role['role_id'], groups)
    cloud_setup.add_ad_groups_to_role(secondary_role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[initial_role, secondary_role],
                                       setup_script='O365UpdateAppDataConflictingLicenseScript')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=initial_role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Failed',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'invalid combination of licenses error')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28051')
@pytest.mark.pipeline
def test_o365_assign_all_licenses_and_allowed_services(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28051  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    initial_role = cloud_setup.create_unique_role()
    secondary_role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(initial_role['role_id'], groups)
    cloud_setup.add_ad_groups_to_role(secondary_role['role_id'], groups)
    disabled_service_plans = [initial_role['role_name'],
                              initial_role['role_name'],
                              initial_role['role_name'],
                              initial_role['role_name']]
    office_worker.import_o365_instance(update_app=True,
                                       roles=[secondary_role, initial_role],
                                       setup_script='O365UpdateAppDataAllLicenses',
                                       disabled_service_plans=disabled_service_plans)
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=initial_role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    licenses = 'centrifyqaautomation:EXCHANGE_ANALYTICS centrifyqaautomation:ENTERPRISEPACK centrifyqaautomation:STANDARDPACK'
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license=licenses)
    office_worker.validate_msoffice_sub_license(user_name=base_name,
                                                license_name='EXCHANGE_S_ENTERPRISE',
                                                status='Disabled')
    office_worker.validate_msoffice_sub_license(user_name=base_name,
                                                license_name='BPOS_S_TODO_2',
                                                status='Disabled')
    office_worker.validate_msoffice_sub_license(user_name=base_name,
                                                license_name='OFFICESUBSCRIPTION',
                                                status='Success')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C2662')
@pytest.mark.pipeline
def test_o365_ad_delete_user_incrementals(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/2662  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.delete_ad_user(
        f"{base_name}user1", f"OU={base_name}"
    )
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User deprovisioned:')
    office_worker.validate_msoffice_user_license(
        user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
        expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C28150')
@pytest.mark.pipeline
def test_o365_ad_disable_user_using_only_incrementals(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/28150  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.disable_user_in_ad(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}'
    )
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User deprovisioned:')
    office_worker.validate_msoffice_user_license(
        user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
        expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C31689')
@pytest.mark.pipeline
def test_o365_sync_mail_enabled_groups(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/31689  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_hybrid_settings(role_name=role['role_name'],
                                              domain_name=dc_info['default_login_suffix'])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}Group1',
        ou_string=f'ou={base_name}',
        attribute_name='mail',
        attribute_value=f"{base_name}Group1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}Group1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:STANDARDPACK')
    office_worker.validate_msol_group_members(group_name=f'{base_name}Group1', user_name=base_name)
    office_worker.clean_msoffice_online(search_string=base_name, group_name=f'{base_name}Group1')


@pytestrail.case('C31699')
@pytest.mark.pipeline
def test_o365_sync_contact(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/31699  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    domain_worker.create_ad_contact(first_name=f'{base_name}contact',
                                    last_name=f'1',
                                    email=f"{base_name}contact1@{dc_info['default_email_suffix']}",
                                    dn_string=f"ou={base_name},dc={dc_info['domain_name']},dc={dc_info['domain_suffix']}")
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}contact 1',
        ou_string=f'ou={base_name}',
        attribute_name='proxyAddresses',
        attribute_value=f"SMTP:{base_name}contact1@{dc_info['default_email_suffix']}"
    )

    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_hybrid_settings(role_name=role['role_name'],
                                              domain_name=dc_info['default_login_suffix'],
                                              sync_contact=True)
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"SMTP:{base_name}contact1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    office_worker.validate_msoffice_contact(f'{base_name}contact1')
    office_worker.clean_msoffice_online(search_string=base_name, group_name=f'{base_name}Group1')


@pytestrail.case('C33182')
@pytest.mark.pipeline
def test_o365_bad_provisioning_password(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33182  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    update_result = office_worker.update_o365_instance(roles=[role], setup_script='O365WrongPassword', get_response=True)
    assert update_result.response['success'] is False
    assert "Authentication to provisioning endpoint failed" in update_result.response['Message']


@pytestrail.case('C33415')
@pytest.mark.pipeline
def test_o365_preview_mode_active_directory_user(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33415  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365PreviewMode')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    job_result = provisioning_worker.fire_app_sync_job(office_worker.app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "Sync Preview Mode")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33428')
@pytest.mark.pipeline
def test_o365_ad_disable_user_unmodified_o365_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33428  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role, {'role_name': dc_info['default_login_suffix'], 'role_id': 0}],
                                       setup_script='O365UnmodifiedDeprov')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.disable_user_in_ad(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}'
    )
    provisioning_worker.await_attribute_increment_update(
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33455')
@pytest.mark.pipeline
def test_o365_ad_delete_user_unmodified_o365_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33455  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role, {'role_name': dc_info['default_login_suffix'], 'role_id': 0}],
                                       setup_script='O365UnmodifiedDeprov')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key, role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name, expected_license='centrifyqaautomation:ENTERPRISEPACK')
    api_session = ApiSession(
        base_url=cloud_session['api_session'].base_url,
        tenant_id=cloud_session['api_session'].tenant_id,
        username=f"{base_name}user1@{dc_info['default_email_suffix']}",
        password='testTEST1234!@'
    )
    assert api_session.session is not None
    domain_worker.delete_ad_user(f"{base_name}user1", f"OU={base_name}")
    user_id = cloud_setup.get_user_details_from_email(user_name=f'{base_name}user1')
    cloud_setup.refresh_user_token(user_id)
    try:
        provisioning_worker.await_attribute_increment_update(
            user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
        )
    except Exception:  # pylint: disable=broad-except
        # If this fails we'll try to resume the test
        pass
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    office_worker.validate_msoffice_user_license(user_name=base_name, expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33459')
@pytest.mark.pipeline
def test_o365_ad_disable_user_remove_license_o365_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33459  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role, {'role_name': dc_info['default_login_suffix'], 'role_id': 0}],
                                       setup_script='O365RemoveLicenseDeprov')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.disable_user_in_ad(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}'
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Deprovisioning user')
    office_worker.validate_msoffice_user_license(
        user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
        expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33460')
@pytest.mark.pipeline
def test_o365_ad_delete_user_remove_license_o365_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33460  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role, {'role_name': dc_info['default_login_suffix'], 'role_id': 0}],
                                       setup_script='O365RemoveLicenseDeprov')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    api_session = ApiSession(
        base_url=cloud_session['api_session'].base_url,
        tenant_id=cloud_session['api_session'].tenant_id,
        username=f"{base_name}user1@{dc_info['default_email_suffix']}",
        password='testTEST1234!@'
    )
    assert api_session.session is not None
    domain_worker.delete_ad_user(f"{base_name}user1", f"OU={base_name}")
    user_id = cloud_setup.get_user_details_from_email(user_name=f'{base_name}user1')
    cloud_setup.refresh_user_token(user_id)
    try:
        provisioning_worker.await_attribute_increment_update(
            user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
            retry_count=20
        )
    except Exception:  # pylint: disable=broad-except
        # If this fails we'll try to resume the test
        pass
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User deprovisioned:')
    office_worker.validate_msoffice_user_license(
        user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
        expected_user_count=0)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33473')
@pytest.mark.pipeline
def test_o365_deprovisioning_ad_group_unmodified_o365_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33473  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=2,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_instance(roles=[role, {'role_name': dc_info['default_login_suffix'], 'role_id': 0}],
                                       setup_script='O365UnmodifiedDeprov',
                                       sync_groups=True)
    cloud_setup.set_application_permissions(app_key=office_worker.app_key, role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}Group1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    domain_worker.delete_ad_user(f"{base_name}Group1", f"OU={base_name}")
    try:
        provisioning_worker.await_attribute_increment_update(
            user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
        )
    except Exception:  # pylint: disable=broad-except
        # If this fails we'll try to resume the test
        pass
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    office_worker.validate_msol_group_members(group_name=f'{base_name}Group1', user_name=base_name, assert_group_only=True)
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33591')
@pytest.mark.pipeline
def test_o365_update_o365_user_with_attributes_from_ad(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33591  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='mobile',
        attribute_value='1231231234'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='title',
        attribute_value='General Manager'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='department',
        attribute_value='Information'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='displayName',
        attribute_value='New name'
    )
    user_id = cloud_setup.get_user_details_from_email(user_name=f'{base_name}user1')
    cloud_setup.refresh_user_token(user_id)
    try:
        provisioning_worker.await_attribute_increment_update(
            user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
            retry_count=20
        )
    except Exception:  # pylint: disable=broad-except
        # If this fails we'll try to resume the test
        pass
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    time.sleep(30)
    msol_attributes = office_worker.get_msol_user_attributes(f"{base_name}user1@{dc_info['default_email_suffix']}")
    assert msol_attributes['Users'][0]['Attributes']['Department'] == 'Information'
    assert msol_attributes['Users'][0]['Attributes']['MobileNumber'] == '1231231234'
    assert msol_attributes['Users'][0]['Attributes']['Title'] == 'General Manager'
    assert msol_attributes['Users'][0]['DisplayName'] == 'New name'
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33647')
@pytest.mark.pipeline
def test_o365_update_o365_group_with_attributes_from_ad(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33647  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_hybrid_settings(role_name=role['role_name'],
                                              domain_name=dc_info['default_login_suffix'])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}Group1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}Group1',
        ou_string=f'ou={base_name}',
        attribute_name='mail',
        attribute_value=f"{base_name}g1@{dc_info['default_email_suffix']}"
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}Group1',
        ou_string=f'ou={base_name}',
        attribute_name='proxyAddresses',
        attribute_value=f"SMTP:{base_name}g1@{dc_info['default_email_suffix']}"
    )
    user_id = cloud_setup.get_user_details_from_email(user_name=f'{base_name}user1')
    cloud_setup.refresh_user_token(user_id)
    try:
        provisioning_worker.await_attribute_increment_update(
            user_principal_name=f"{base_name}Group1@{dc_info['default_email_suffix']}",
            retry_count=20
        )
    except Exception:  # pylint: disable=broad-except
        # If this fails we'll try to resume the test
        pass
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    time.sleep(300)
    office_worker.validate_msol_group_members(group_name=f'{base_name}g1', user_name=f'{base_name}')
    office_worker.clean_msoffice_online(search_string=base_name, group_name=f'{base_name}g1')


@pytestrail.case('C33650')
@pytest.mark.pipeline
def test_o365_sync_ad_user_with_no_email_address(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33650  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='mail',
        attribute_value=f" "
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    msol_attributes = office_worker.get_msol_user_attributes(f"{base_name}user1@{dc_info['default_email_suffix']}")
    assert f"SMTP:{base_name}user1@automationrdtesting.com" in msol_attributes['Users'][0]['Attributes']['ProxyAddresses']
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='mail',
        attribute_value=f"o365updated@{dc_info['default_email_suffix']}"
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='proxyAddresses',
        attribute_value=f"SMTP:o365updated@{dc_info['default_email_suffix']}"
    )
    time.sleep(300)
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    msol_attributes = office_worker.get_msol_user_attributes(f"{base_name}user1@{dc_info['default_email_suffix']}")
    assert "SMTP:o365updated@automationrdtesting.com" in msol_attributes['Users'][0]['Attributes']['ProxyAddresses']
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33655')
@pytest.mark.pipeline
def test_o365_federate_take_ownership_of_domain(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33655  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    secondary_office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365UpdateAppDataImmutableScript')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    secondary_office_worker.import_o365_instance(update_app=True, roles=[role])
    cloud_setup.set_application_permissions(app_key=secondary_office_worker.app_key, role_name=role['role_name'])
    office_worker.federate_domain()
    time.sleep(60)
    office_worker.validate_federation()
    secondary_office_worker.federate_domain()
    time.sleep(60)
    secondary_office_worker.validate_federation()
    secondary_office_worker.unfederate_domain()


@pytestrail.case('C33657')
@pytest.mark.pipeline
def test_o365_unfederate_domain(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33657  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365UpdateAppDataImmutableScript')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    office_worker.federate_domain()
    time.sleep(60)
    office_worker.validate_federation()
    office_worker.unfederate_domain()
    time.sleep(60)
    office_worker.validate_unfederation()


@pytestrail.case('C33658')
@pytest.mark.pipeline
def test_o365_delete_o365_app_no_user_deprovision(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33658  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    cloud_setup.delete_application(office_worker.app_key)
    time.sleep(400)
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C33661')
@pytest.mark.pipeline
def test_o365_add_remove_linked_applications(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33661  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    office_worker.update_o365_linked_apps()
    linked_apps = office_worker.validate_linked_app_list(expected_app_count=4)
    remove_via_delete = linked_apps.pop()
    cloud_setup.delete_application(remove_via_delete['Row']['ID'])
    office_worker.delete_linked_apps(linked_apps)
    office_worker.validate_linked_app_list(expected_app_count=2)


@pytestrail.case('C40274')
@pytest.mark.pipeline
def test_o365_preferred_data_location(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40274  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365UpdateAppDataPreferredData')
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msol_preferred_data_value(user_name=f"{base_name}user1@{dc_info['default_email_suffix']}",
                                                     validate_key='PreferredDataLocation',
                                                     validate_value='CAN')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C68919')
@pytest.mark.pipeline
def test_o365_remove_from_role_unmodified_o365_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/68919  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=True,
                                       roles=[role],
                                       setup_script='O365UpdateAppDataPreferredData',
                                       retainDeprovAccount=True)
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    cloud_setup.remove_group_from_role(role['role_id'], groups[0]['objectGUID'].value.replace('{', '').replace('}', ''))
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Deactivated',
        user_principal_name=f"{base_name}user1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'User skipped:')
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)


@pytestrail.case('C70006')
@pytest.mark.pipeline
def test_o365_add_contact_to_group_validate_in_o365(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/70006  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    domain_worker.create_ad_contact(
        first_name=f'{base_name}contact',
        last_name='1',
        email=f"{base_name}contact1@{dc_info['default_email_suffix']}",
        dn_string=f"ou={base_name},dc={dc_info['domain_name']},dc={dc_info['domain_suffix']}"
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_hybrid_settings(role_name=role['role_name'],
                                              domain_name=dc_info['default_login_suffix'],
                                              sync_contact=True)
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}Group1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    time.sleep(60)
    office_worker.validate_msol_group_members(group_name=f'{base_name}Group1', user_name=base_name)
    domain_worker.add_member_to_group(
        group_dn=groups[0].distinguishedName.value,
        object_dn=[f"cn={base_name}contact 1,ou={base_name},dc={dc_info['domain_name']},dc={dc_info['domain_suffix']}"]
    )
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    time.sleep(300)
    office_worker.validate_msol_group_members(group_name=f'{base_name}Group1', user_name=base_name, group_member_count=2)
    office_worker.clean_msoffice_online(search_string=base_name, group_name=f'{base_name}Group1')


@pytestrail.case('C70214')
@pytest.mark.pipeline
def test_o365_validate_multiple_ad_attributes_in_o365(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/70214  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='physicalDeliveryOfficeName',
        attribute_value='Salt Lake'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='telephoneNumber',
        attribute_value='111-111-1111'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='mobile',
        attribute_value='222-222-2222'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='homePhone',
        attribute_value='333-333-3333'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='facsimileTelephoneNumber',
        attribute_value='444-444-4444'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='l',
        attribute_value='Murray'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='co',
        attribute_value='United States'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='postalCode',
        attribute_value='84100'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='title',
        attribute_value='Worker Bee'
    )
    domain_worker.modify_ad_user_attribute(
        user_name=f'{base_name}user1',
        ou_string=f'ou={base_name}',
        attribute_name='department',
        attribute_value='QA Automation'
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_hybrid_settings(role_name=role['role_name'],
                                              domain_name=dc_info['default_login_suffix'])
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    query_results = provisioning_worker.get_user_prov_events(
        app_name='Office 365',
        sync_type_result='Updated',
        user_principal_name=f"{base_name}Group1@{dc_info['default_email_suffix']}"
    )
    provisioning_worker.validate_job_report(query_results[0]['Row']['JobUniqueId'], 'Created/Updated user/related object')
    msol_attributes = office_worker.get_msol_user_all_attributes(f"{base_name}user1@{dc_info['default_email_suffix']}")
    assert msol_attributes['Users'][0]['Attributes']['physicalDeliveryOfficeName'] == 'Salt Lake'
    assert msol_attributes['Users'][0]['Attributes']['telephoneNumber'] == '111-111-1111'
    assert msol_attributes['Users'][0]['Attributes']['MobileNumber'] == '222-222-2222'
    assert msol_attributes['Users'][0]['Attributes']['facisimileTelephoneNumber'] == '444-444-4444'
    assert msol_attributes['Users'][0]['Attributes']['l'] == 'Murray'
    assert msol_attributes['Users'][0]['Attributes']['co'] == 'United States'
    assert msol_attributes['Users'][0]['Attributes']['postalCode'] == '84100'
    assert msol_attributes['Users'][0]['Attributes']['title'] == 'Worker Bee'
    assert msol_attributes['Users'][0]['Attributes']['department'] == 'QA Automation'
    office_worker.clean_msoffice_online(search_string=base_name, group_name=f'{base_name}Group1')


@pytestrail.case('C83884')
@pytest.mark.pipeline
def test_o365_add_additional_member_to_distribution_list(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/83884  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    office_worker = MsOfficeWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    dc_info = cloud_session['dc_info']

    base_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_environment(
        base_name=base_name,
        default_password='testTEST1234!@',
        num_groups=1,
        num_users=1
    )
    dl_group = domain_worker.create_ad_group(
        group_name=f'{base_name}DL',
        ou_string=f'ou={base_name}',
        email_address=f"testdl@{dc_info['default_email_suffix']}",
        is_dl=True
    )
    domain_worker.add_member_to_group(
        group_dn=dl_group[0].entry_dn,
        object_dn=[f"cn={base_name}user1,ou={base_name},dc={dc_info['domain_name']},dc={dc_info['domain_suffix']}"]
    )
    role = cloud_setup.create_unique_role()
    groups = domain_worker.get_ad_group_details(base_name)
    cloud_setup.add_ad_groups_to_role(role['role_id'], groups)
    office_worker.import_o365_instance(update_app=False)
    office_worker.update_o365_distribution_list_sync(role_name=role['role_name'],
                                                     domain=f"{dc_info['domain_suffix']}.{dc_info['domain_suffix']}")
    cloud_setup.set_application_permissions(app_key=office_worker.app_key,
                                            role_name=role['role_name'])
    provisioning_worker.fire_app_sync_job(office_worker.app_key)
    provisioning_worker.validate_user_sync_status(office_worker.app_key, "'Created','Merged','Updated'")
    office_worker.validate_msoffice_user_license(user_name=base_name,
                                                 expected_license='centrifyqaautomation:ENTERPRISEPACK')
    office_worker.clean_msoffice_online(base_name)

    # TODO The tests below need additional brainstorming to complete
    # @pytestrail.case('C33180')
    # def test_o365_sync_6k_objects(cloud_session):
    #     # C33180 O365 Sync 6k objects
    #     # app = "O365LargeNumOfObjects"
    #     app ="O365m725user"
    #     email_user_name = app[:8]
    #
    #     num_groups = 200
    #     num_users = 2000
    #     num_contacts = 500
    #
    #     api_session = cloud_session['api_session']
    #     data_steps = DataSteps(cloud_session['mongo_cred'])
    #     dc_info = cloud_session['dc_info']
    #     outbound_steps = OutboundSteps(api_session, data_steps)
    #     domain_environment = DomainEnvironmentSteps(dc_info)
    #     cloud_environment = CloudEnvironment(api_session, data_steps)
    #
    #     try:
    #         domain_environment.create_ad_environment(app[:8], num_groups=num_groups, num_users=num_users, num_contacts=num_contacts)
    #         groups = domain_environment.get_ad_group_details(
    #             f"{app[:8]}"
    #         )
    #
    #         role_name = f'{app} - Test Role - Remove'
    #         role_id = cloud_environment.create_core_role(role_name)
    #         assert role_id is not None
    #
    #         map_these_groups = []
    #         for group in groups:
    #             map_these_groups.append(group['objectGUID'].value.replace('{', '').replace('}', ''))
    #         assert outbound_steps.map_ad_group_to_core_role(role_id, map_these_groups).success is True
    #
    #         app_key = cloud_environment.import_app('Office 365v2')
    #         assert outbound_steps.o365_update_hybrid_settings(app_key, f'{role_name}', dc_info['default_login_suffix'],
    #                                                           sync_contact=True).success is True
    #         assert outbound_steps.set_app_permission(app_key, role_id).success is True
    #         job_result = outbound_steps.request_outbound_full_sync(app_key)
    #         assert job_result['success'] is True
    #
    #         result = outbound_steps.confirm_large_o365_job_completion(email_user_name, num_users, num_groups, num_contacts)
    #         assert result is True
    #
    #     finally:
    #         cleanup_o365_environment = outbound_steps.remove_all_o365_objects_and_empty_recycle(
    #             f"{email_user_name}")
    #         cloud_environment.clean_cloud_environment()
    #         domain_environment.clean_domain_environment()
    #
    # @pytestrail.case('C33539')
    # def test_o365_google_directory_user_provisioning(cloud_session):
    #     #  - O365 Google Directory User Provisioning
    #     app = "O365GDUserProv"
    #     email_user_name = app[:8]
    #
    #     api_session = cloud_session['api_session']
    #     data_steps = DataSteps(cloud_session['mongo_cred'])
    #     dc_info = cloud_session['dc_info']
    #     outbound_steps = OutboundSteps(api_session, data_steps)
    #     domain_environment = DomainEnvironmentSteps(dc_info)
    #     cloud_environment = CloudEnvironment(api_session, data_steps)
    #
    #     try:
    #         domain_environment.create_ad_environment(app[:8])
    #         groups = domain_environment.get_ad_group_details(
    #             f"{app[:8]}"
    #         )
    #
    #         role_name = f'{app} - Test Role - Remove'
    #         role_id = cloud_environment.create_core_role(role_name)
    #         assert role_id is not None
    #
    #         map_these_groups = []
    #         for group in groups:
    #             map_these_groups.append(group['objectGUID'].value.replace('{', '').replace('}', ''))
    #         assert outbound_steps.map_ad_group_to_core_role(role_id, map_these_groups).success is True
    #         assert outbound_steps.map_user_to_core_role(role_id, "109101056323109493790-de198581820242c8b8a2687a297d9e9b").success is True
    #
    #         domain_environment.delete_ad_user(
    #             f"{email_user_name}Sub1user1", f"OU={app[:8]}Sub1,OU={app[:8]}"
    #         )
    #
    #         app_key = cloud_environment.import_app('Office 365v2')
    #         assert outbound_steps.o365_update_app(app_key, f'{role_name}', 'O365modUPNwithScript').success is True
    #         assert outbound_steps.set_app_permission(app_key, role_id).success is True
    #         job_result = outbound_steps.request_outbound_full_sync(app_key)
    #         assert job_result['success'] is True
    #
    #         job_report = outbound_steps.get_any_type_sync_report_continuously(
    #             "o365googleuser1@automationrdtesting.com", 'Updated', 'Office 365')
    #
    #         assert "Created/Updated user/related object".encode() in job_report
    #
    #         user_license_info = outbound_steps.get_msol_user_license_continuously(
    #             "o365googleuser1@automationrdtesting.com")
    #         assert user_license_info['Users'][0]['Licenses'] == 'centrifyqaautomation:ENTERPRISEPACK'
    #
    #     finally:
    #         cleanup_o365_user = outbound_steps.remove_o365_user_and_empty_recycle(
    #             "o365googleuser1@automationrdtesting.com")
    #         domain_environment.clean_domain_environment()
    #         cloud_environment.clean_cloud_environment()
    #
    # @pytestrail.case('C33540')
    # def test_o365_google_directory_user_remove_from_role_deprovisioning(cloud_session):
    #     #  - O365 Google Directory User Remove from Role DeProvisioning
    #     app = "O365GDDeprov"
    #     email_user_name = app[:8]
    #
    #     api_session = cloud_session['api_session']
    #     data_steps = DataSteps(cloud_session['mongo_cred'])
    #     dc_info = cloud_session['dc_info']
    #     outbound_steps = OutboundSteps(api_session, data_steps)
    #     domain_environment = DomainEnvironmentSteps(dc_info)
    #     cloud_environment = CloudEnvironment(api_session, data_steps)
    #
    #     try:
    #         domain_environment.create_ad_environment(app[:8])
    #         groups = domain_environment.get_ad_group_details(
    #             f"{app[:8]}"
    #         )
    #
    #         role_name = f'{app} - Test Role - Remove'
    #         role_id = cloud_environment.create_core_role(role_name)
    #         assert role_id is not None
    #
    #         map_these_groups = []
    #         for group in groups:
    #             map_these_groups.append(group['objectGUID'].value.replace('{', '').replace('}', ''))
    #         assert outbound_steps.map_ad_group_to_core_role(role_id, map_these_groups).success is True
    #         assert outbound_steps.map_user_to_core_role(role_id,
    #                                                     "109101056323109493790-de198581820242c8b8a2687a297d9e9b").success is True
    #
    #         domain_environment.delete_ad_user(
    #             f"{email_user_name}Sub1user1", f"OU={app[:8]}Sub1,OU={app[:8]}"
    #         )
    #
    #         app_key = cloud_environment.import_app('Office 365v2')
    #         assert outbound_steps.o365_update_app(app_key, f'{role_name}', 'O365modUPNwithScript').success is True
    #         assert outbound_steps.set_app_permission(app_key, role_id).success is True
    #         job_result = outbound_steps.request_outbound_full_sync(app_key)
    #         assert job_result['success'] is True
    #
    #         job_report = outbound_steps.get_any_type_sync_report_continuously(
    #             "o365googleuser1@automationrdtesting.com", 'Updated', 'Office 365')
    #
    #         assert "Created/Updated user/related object".encode() in job_report
    #
    #         user_license_info = outbound_steps.get_msol_user_license_continuously(
    #             "o365googleuser1@automationrdtesting.com")
    #         assert user_license_info['Users'][0]['Licenses'] == 'centrifyqaautomation:ENTERPRISEPACK'
    #
    #         assert outbound_steps.remove_user_from_core_role(role_id, "109101056323109493790-de198581820242c8b8a2687a297d9e9b").success is True
    #
    #         job_result = outbound_steps.request_outbound_full_sync(app_key)
    #         assert job_result['success'] is True
    #
    #         job_report = outbound_steps.get_any_type_sync_report_continuously(
    #             "o365googleuser1@automationrdtesting.com", 'Deactivated', 'Office 365')
    #
    #         user_license_info = outbound_steps.get_msol_user_license(
    #             "o365googleuser1@automationrdtesting.com")
    #
    #         assert "User deprovisioned:".encode() in job_report
    #         assert user_license_info['Users'].__len__() == 0
    #
    #     finally:
    #         cleanup_o365_user = outbound_steps.remove_o365_user_and_empty_recycle(
    #             "o365googleuser1@automationrdtesting.com")
    #         domain_environment.clean_domain_environment()
    #         cloud_environment.clean_cloud_environment()
