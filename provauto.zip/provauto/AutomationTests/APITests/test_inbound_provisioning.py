"""
Contains all functional tests for Inbound Provisioning that are not
UI driven.  Inbound Provisioning includes tests for Workday, UltiPro,
SuccessFactors, and BambooHR.
"""
import time
import uuid
import pytest

from idaptive_testrail.plugin import pytestrail
from idaptive_automation.api_client import ApiSession
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C12')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_verify_read_creds(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/12 """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    provisioning_worker.validate_inbound_source_creds(source)


@pytestrail.case('C3')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_sync_preview_rule(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/3  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Preview',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'No change has been made in preview mode.')
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')


@pytestrail.case('C2')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_sync_active_rule(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/2  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')


@pytestrail.case('C5')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_attribute_mapping(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/5  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    script_block = "var sc = SyncContext;" \
                   "sc.TargetUserRecord.PersonalTitle = sc.SourceUserRecord.BusinessTitle;" \
                   "sc.TargetUserRecord.Division = sc.SourceUserRecord.PositionType;" \
                   "sc.TargetUserRecord.IpPhone = sc.SourceUserRecord.WorkMobile;" \
                   "var deptNumbers = [];" \
                   "deptNumbers.push(sc .SourceUserRecord.WorkPostalCode);" \
                   "sc.TargetUserRecord.DepartmentNumber = deptNumbers;" \
                   "var poxBoxes = [];" \
                   "poxBoxes.push(sc .SourceUserRecord.LastName);" \
                   "sc.TargetUserRecord.PostOfficeBox = poxBoxes;"
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution',
                                            script_block=script_block)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    users = domain_worker.get_ad_ou_users(ou_name)
    custom_attribute_count = 0
    for user in users:
        try:
            assert user.entry_attributes_as_dict['personalTitle'] is not None
            assert user.entry_attributes_as_dict['division'] is not None
            assert user.entry_attributes_as_dict['ipPhone'] is not None
            assert user.entry_attributes_as_dict['departmentNumber'] is not None
            assert user.entry_attributes_as_dict['postOfficeBox'] is not None
            custom_attribute_count = custom_attribute_count + 1
        except Exception:  # pylint: disable=broad-except
            # We don't really care if there is an exception in retrieving these values as they may not
            # be populated in our Workday instance
            pass
    assert custom_attribute_count > 0


@pytestrail.case('C31697')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_resync_deleted_ad_users(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/31697  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    domain_worker.delete_ad_user(
        provisioning_worker.get_inbound_test_user(source)['user_name'],
        f'OU={ou_name}'
    )
    # We need a hard wait here (10 minutes)
    # otherwise the second full sync we run will not recognize that the user has been removed
    time.sleep(600)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] == 1
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: 1')


@pytestrail.case('C33458')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_sync_to_ad_login(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33458 """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')

    user = provisioning_worker.get_inbound_test_user(source)
    new_user_session = ApiSession(
        base_url=cloud_session['api_session'].base_url,
        tenant_id=cloud_session['api_session'].tenant_id,
        username=user['user_name'],
        password=user['password']
    )
    assert new_user_session.auth_details.success is True


@pytestrail.case('C33548')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_full_sync_inactive_workday_rule(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33548  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Disabled',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] == 0
    provisioning_worker.validate_job_report(job_id, 'Message: No enabled rules are found for InboundProv instance')


@pytestrail.case('C7')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_disabled_source_sync(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/7  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source=source,
                                                          name=source_name,
                                                          enabled=False)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] == 0
    provisioning_worker.validate_job_report(job_id, 'Message: The InboundProv instance is disabled')


@pytestrail.case('C6')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_assign_users_to_group(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/6  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    ad_group_name = str(uuid.uuid4())[0:8]
    domain_worker.create_ad_group(ad_group_name, f'OU={ou_name}')
    group_details = next(
        (
            group for group in domain_worker.get_ad_group_details(ou_name)
            if group.name == ad_group_name
        )
    )
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution',
                                            script_block=None,
                                            group_rule=True,
                                            group=group_details)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    users = domain_worker.get_ad_group_members(group_details.distinguishedName.value)
    assert users.__len__() > 0


@pytestrail.case('C8')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_enabled_source_no_rule_sync(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/8  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] == 0
    provisioning_worker.validate_job_report(job_id, 'Message: No enabled rules are found for InboundProv instance')


@pytestrail.case('C9')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_invalid_ad_password(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/9  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='tmp123')
    job_id = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync', retry_count=15)
    provisioning_worker.validate_job_report(job_id, 'UnableToSetPassword')


@pytestrail.case('C33488')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_can_add_multiple_enabled_sources(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33488  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    initial_source_name = str(uuid.uuid4())[0:8]
    initial_source_id = provisioning_worker.create_inbound_source(source, initial_source_name)
    secondary_source_name = str(uuid.uuid4())[0:8]
    secondary_source_id = provisioning_worker.create_inbound_source(source, secondary_source_name)
    assert initial_source_id is not None
    assert secondary_source_id is not None
    provisioning_worker.remove_all_created_inbound_sources()


@pytestrail.case('C33589')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_sync_send_complete_email_report(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33589  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source=source,
                                                          name=source_name,
                                                          enabled=True,
                                                          email=True,
                                                          email_list=['idaptiveprovisioning@gmail.com'])
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    provisioning_worker.validate_email([f'{source_name}', job_id])


@pytestrail.case('C33490')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_cannot_run_simultaneous_syncs_same_source(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33490  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    initial_sync_request = provisioning_worker.fire_inbound_prov_sync(source_instance_id=source_id,
                                                                      sync_type='FullSync',
                                                                      wait_for_result=False)
    secondary_sync_request = provisioning_worker.fire_inbound_prov_sync(source_instance_id=source_id,
                                                                        sync_type='FullSync',
                                                                        wait_for_result=False)
    initial_job_id = initial_sync_request.response['Result']
    secondary_job_id = secondary_sync_request.response['Result']

    assert secondary_job_id is not None
    job_result = provisioning_worker.wait_for_provisioning_job(job_id=initial_job_id)
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(initial_job_id, 'Number of Succeeded worker syncs: ')
    assert f'Cannot schedule job for source {source_name} of type Workday. A job is already scheduled to run shortly.' \
           in secondary_sync_request.response['Message']


@pytestrail.case('C33453')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_delete_source_job_pending(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33453  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_request = provisioning_worker.fire_inbound_prov_sync(source_instance_id=source_id,
                                                             sync_type='FullSync',
                                                             wait_for_result=False)
    job_id = job_request.response['Result']
    provisioning_worker.remove_all_created_inbound_sources()
    job_result = provisioning_worker.wait_for_provisioning_job(job_id=job_id, retry_count=5)
    assert job_result is not None
    provisioning_worker.validate_job_status(job_id, 'Cancelled')


@pytestrail.case('C33454')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_delete_source_job_running(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33454  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_request = provisioning_worker.fire_inbound_prov_sync(source_instance_id=source_id,
                                                             sync_type='FullSync',
                                                             wait_for_result=False)
    job_id = job_request.response['Result']
    assert provisioning_worker.wait_for_job_to_start_running(job_id) is True
    provisioning_worker.remove_all_created_inbound_sources()
    job_result = provisioning_worker.wait_for_provisioning_job(job_id=job_id, retry_count=5)
    assert job_result is not None
    try:
        provisioning_worker.validate_job_report(job_id, 'Sync job status: Cancelled')
    except AttributeError:
        provisioning_worker.validate_job_status(job_id, 'Cancelled')


@pytestrail.case('C117778')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_login_generated_password(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117778  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            generated_password_email='idaptiveprovisioning@gmail.com')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    syncd_users = provisioning_worker.download_generated_passwords()
    for user in syncd_users:
        api_session = ApiSession(
            base_url=cloud_session['api_session'].base_url,
            tenant_id=cloud_session['api_session'].tenant_id,
            username=user[0],
            password=user[1]
        )
        assert api_session.auth_details is not None


@pytestrail.case('C10')
@pytest.mark.pipeline
def test_ping(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/10  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    provisioning_worker.ping_inbound()


@pytestrail.case('C11')
@pytest.mark.pipeline
def test_query_supported_providers(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/11  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    providers = provisioning_worker.query_inbound_providers()
    assert providers.__len__() == 5


@pytestrail.case('C31698')
@pytest.mark.pipeline
def test_domain_administrator_account(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/31698  """
    domain_worker = helpers['active_directory_helper']
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)

    dc_info = cloud_session['dc_info']
    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    domain_worker.create_admin_user(
        str(uuid.uuid4())[0:8],
        f"OU={ou_name},DC={dc_info['domain_name']},DC={dc_info['domain_suffix']}"
    )
    user = domain_worker.get_ad_ou_users(ou_name)[0]
    user_guid = user.objectGUID.value.replace('{', '').replace('}', '')
    provisioning_worker.set_administrative_account(
        user_name=user.userPrincipalName.value,
        user_id=user_guid,
        password='testTEST1234!@'
    )
    admin_guid = domain_worker.get_ad_user_attribute('Administrator', f"CN=Users", 'objectGUID')\
        .value.replace('{', '').replace('}', '')
    provisioning_worker.set_administrative_account(
        user_name=f"administrator@{dc_info['domain_name']}.{dc_info['domain_suffix']}",
        user_id=admin_guid,
        password=dc_info['password'],
    )


@pytestrail.case('C40178')
@pytest.mark.pipeline
def test_wd_sync_custom_report(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/40178  """
    source = 'Workday'
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source_with_integrated_report(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    script_block = "var sc = SyncContext;" \
                   "sc.TargetUserRecord.PersonalTitle = sc.SourceUserRecord.ReportRow.Get('Full_Name');"
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution',
                                            script_block=script_block)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')


@pytestrail.case('C76650')
@pytest.mark.pipeline
@pytest.mark.parametrize('destination_role', [
    "employeeID",
    "title",
    "employeeType",
    "department",
    "c",
    "co",
    "st",
    "company",
    "division",
    "displayNamePrintable"
])
def test_custom_attribute_mapping(cloud_session, helpers, destination_role):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/C76650  """
    source = "Workday"
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']

    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    script_block = "var sc = SyncContext;" \
                   f"sc.TargetUserRecord.{destination_role}='null'"
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution',
                                            script_block=script_block)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    users = domain_worker.get_ad_ou_users(ou_name)
    custom_attribute_count = 0
    for user in users:
        try:
            assert user.entry_attributes_as_dict[destination_role] is not None

            custom_attribute_count = custom_attribute_count + 1
        except Exception:  # pylint: disable=broad-except
            # We don't really care if there is an exception in retrieving these values as they may not
            # be populated in our Workday instance
            pass
    assert custom_attribute_count > 0


@pytestrail.case('C33775')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday",
    "Bamboo",
    "SuccessFactors"
])
def test_create_custom_ad_attribute_list(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/2  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_custom_inbound_rule(source=source,
                                                   source_name=source_name,
                                                   source_instance_id=source_id,
                                                   rule_name=rule_name,
                                                   target_ou=ou_name,
                                                   rule_state='Production',
                                                   static_password='@bSolution',
                                                   title='1234',
                                                   department='def',
                                                   telephonenumber='1234567890')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "'Title' from '<no_value>' to '1234'")
    provisioning_worker.validate_job_report(job_id, "'Department' from '<no_value>' to 'def'")
    provisioning_worker.validate_job_report(job_id, "'TelephoneNumber' from '<no_value>' to '1234567890'")


@pytestrail.case('C70242')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday"
])
def test_validate_manager_attribute_mapping(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/70242  """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule_with_manager_attribute(source=source,
                                                                   source_name=source_name,
                                                                   source_instance_id=source_id,
                                                                   rule_name=rule_name,
                                                                   target_ou=ou_name,
                                                                   rule_state='Production',
                                                                   static_password='@bSolution',
                                                                   set_manager='true')

    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "'manager' from '<no_value>' to 'CN=lmcneil")


@pytestrail.case('C39853')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday"
])
def test_subsequent_full_active_sync(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/39853 """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution')
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, 'Number of Succeeded worker syncs: ')
    job_result_next = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id_next = job_result_next['Row']['JobUniqueId']
    assert job_result_next['Row']['JobItemsSucceeded'] == 0
    provisioning_worker.validate_job_report(job_id_next, 'Sync job status: Succeeded')
    provisioning_worker.remove_all_created_inbound_sources()


@pytestrail.case('C83864')
@pytest.mark.pipeline
@pytest.mark.parametrize('source', [
    "Workday"
])
def test_create_user_with_null_or_empty_array_attribute(source, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/83864 """
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    domain_worker = helpers['active_directory_helper']
    ou_name = str(uuid.uuid4())[0:7]
    domain_worker.create_basic_ad_ou(ou_name)
    source_name = str(uuid.uuid4())[0:8]
    source_id = provisioning_worker.create_inbound_source(source, source_name)
    rule_name = str(uuid.uuid4())[0:8]
    script_block = "var sc = SyncContext;" \
                   "sc.TargetUserRecord.postalCode = 'null';"
    provisioning_worker.create_inbound_rule(source=source,
                                            source_name=source_name,
                                            source_instance_id=source_id,
                                            rule_name=rule_name,
                                            target_ou=ou_name,
                                            rule_state='Production',
                                            static_password='@bSolution',
                                            script_block=script_block)
    job_result = provisioning_worker.fire_inbound_prov_sync(source_id, 'FullSync')
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, "Changed property name 'PostalCode' from '<no_value>' to 'null'.")
    provisioning_worker.remove_all_created_inbound_sources()
