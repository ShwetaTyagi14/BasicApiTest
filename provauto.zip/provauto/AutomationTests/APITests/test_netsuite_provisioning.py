""" Contains all functional tests that are Netsuite app specific """
from idaptive_testrail.plugin import pytestrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C117726')
def test_auto_synced_up_user_attribute_listed_in_provisioning_script(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117726  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role['role_name'],
                                                                   groups_value='Administrator')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117727')
def test_modify_provisioning_script(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117727  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_multiple_attribute_for_netsuite(app, app_key, role['role_name'],
                                                                      groups_value='Administrator',
                                                                      destination_attribute='subsidiaryId',
                                                                      destination_attribute_value=1,
                                                                      destination_attribute_2='phone',
                                                                      destination_attribute_val_2=888888888)
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    assert job_result['Row']['JobItemsSucceeded'] > 0
    provisioning_worker.validate_job_report(job_id, '"phone":"888888888"')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117728')
def test_switch_mapped_destination_role_and_then_trigger_start_sync(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117728  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role['role_name'],
                                                                   groups_value='Accountant')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role['role_name'],
                                                                   groups_value='Accountant (Reviewer)')
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"roleList":["Accountant (Reviewer)"]')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117729')
def test_switch_both_the_mapped_source_role_and_destination_role_to_re_sync_users(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117729  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role_1 = cloud_setup.create_unique_role()
    role_2 = cloud_setup.create_unique_role()
    user_1 = cloud_setup.create_unique_user()
    user_2 = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role_1['role_id'], user_1['user_id'])
    app_key = cloud_setup.import_application(app, True, role_1['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role_1['role_name'],
                                                                   groups_value='Accountant')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.add_user_to_role(role_2['role_id'], user_2['user_id'])
    cloud_setup.update_app(app=app,
                           app_key=app_key,
                           setup_provisioning=True,
                           role_name=role_2['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role_2['role_name'],
                                                                   groups_value='Accountant (Reviewer)')
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, 'User deprovisioned:')
    provisioning_worker.validate_job_report(job_id, 'User added:')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117730')
def test_sync_up_user_to_single_destination_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117730  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role['role_name'],
                                                                   groups_value='Administrator')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117731')
def test_sync_up_user_to_multipule_destination_roles(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117731  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    roles = []
    role = cloud_setup.create_unique_role()
    roles.append(role)
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.append_role_to_app_for_netsuite(app=app, app_key=app_key, setup_provisioning=True,
                                                roles=roles,
                                                destination_role=["Accountant", "Accountant (Reviewer)"])
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, '"roleList":["Accountant","Accountant (Reviewer)"]')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C117732')
def test_auto_synced_up_user_attribute_custom_role(cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/117732  """
    app = "NetSuite"
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.updating_role_mapping_group_attribute_for_netsuite(app, app_key, role['role_name'],
                                                                   groups_value='10711')
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, 'Invalid selectedrole reference key 1071')
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)