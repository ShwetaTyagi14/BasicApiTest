""" Contains all functional tests that are mango app specific """
from idaptive_testrail.plugin import pytestrail
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C117599')
def test_auto_attribute_mango_apps(cloud_session, helpers):
    """TestCaseLink:https://idaptiveqa.testrail.io/index.php?/cases/view/117599 """
    app = 'MangoApps'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    assert provisioning_worker.fire_app_sync_job(app_key)is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()


@pytestrail.case('C117598')
def test_modify_user_attributes_mango_apps(cloud_session, helpers):
    """TestCaseLink:https://idaptiveqa.testrail.io/index.php?/cases/view/117598"""
    app = 'MangoApps'
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    login_name = cloud_setup.get_user_attribute_value(user, 'login_name')
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application(app, True, role['role_name'])
    cloud_setup.script_specific_integer_attribute_mapping(app, app_key, role['role_name'],
                                                          destination_attribute='email',
                                                          destination_attribute_value=
                                                          'source.Email.split("@")[0] + "@lucky.com"')
    job_result = provisioning_worker.fire_app_sync_job(app_key)
    assert job_result is not None
    job_id = job_result['Row']['JobUniqueId']
    provisioning_worker.validate_job_report(job_id, str(login_name) + "@lucky.com")
    cloud_setup.remove_all_users()
