"""
Contains all functional tests that are SCIM Provisioning Specific
Apps Tested:  TalentLMS, FacebookAtWork
"""
import pytest

from idaptive_testrail.plugin import pytestrail
from Steps.data_steps import DataSteps
from Workers.cloud_setup_worker import CloudSetupWorker
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('CC33424')
@pytest.mark.parametrize('app', [
    "TalentLMS",
    "FacebookAtWork"
])
def test_custom_saml_enable_prov_auth_bearer_token(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33424  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    data_steps = DataSteps(cloud_session['mongo_cred'])

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application('GenericSAML', update_app=False)
    app_data = data_steps.query_db_collection(
        db='automation',
        collection='provision_apps',
        query={'name': app}
    )
    cloud_setup.saml_update_app(
        app_key=app_key,
        url=app_data['scimInfo']['scimUrl'],
        auth_token=app_data['scimInfo']['bearerToken'],
        role=role['role_name'],
        user_script=app_data['updateAppProvisioning']['settings']['UserScript']
    )
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)


@pytestrail.case('C33427')
@pytest.mark.parametrize('app', [
    "FacebookAtWork"
])
def test_custom_saml_enable_prov_direct_header(app, cloud_session, helpers):
    """ Test Case Link : https://idaptiveqa.testrail.io/index.php?/cases/view/33427  """
    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    provisioning_worker = ProvisioningWorker(cloud_session, helpers)
    data_steps = DataSteps(cloud_session['mongo_cred'])

    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user()
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application('GenericSAML', update_app=False)
    app_data = data_steps.query_db_collection(
        db='automation',
        collection='provision_apps',
        query={'name': app}
    )
    cloud_setup.saml_update_app(
        app_key=app_key,
        url=app_data['scimInfo']['scimUrl'],
        direct_header=app_data['scimInfo']['directHeader'],
        role=role['role_name'],
        user_script=app_data['updateAppProvisioning']['settings']['UserScript']
    )
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_sync_status(app_key, "'Created','Merged','Updated'")
    cloud_setup.remove_all_users()
    assert provisioning_worker.fire_app_sync_job(app_key) is not None
    provisioning_worker.validate_user_deactivated(app_key)
