import uuid

from idaptive_testrail.plugin import pytestrail
from BrowserSteps.inbound_source_steps import InboundSourceSteps
from idaptive_automation.ui_automation import ProvisioningSourceDialog
from Fixtures.ui_fixtures import ui_add_inbound_source_driver


@pytestrail.case('C18')
def test_settings_tab(ui_add_inbound_source_driver):
    InboundSourceSteps(ui_add_inbound_source_driver).validate_default_settings() \
        .validate_post_source_selection_settings() \
        .validate_password_mask()


@pytestrail.case('C19')
def test_report_integrations_tab(ui_add_inbound_source_driver):
    source_name = f'WD - {uuid.uuid4()}'
    InboundSourceSteps(ui_add_inbound_source_driver).configure_source_settings(source_name) \
        .validate_report_integration_defaults() \
        .validate_report_integration_enabled_defaults() \
        .validate_min_max_report_query_timeout()


@pytestrail.case('C20')
def test_sync_settings_tab(ui_add_inbound_source_driver):
    source_name = f'WD - {uuid.uuid4()}'
    InboundSourceSteps(ui_add_inbound_source_driver).configure_source_settings(source_name) \
        .validate_sync_settings_defaults() \
        .validate_min_max_pre_provisioning_interval() \
        .validate_min_max_tenant_utc_offset()


@pytestrail.case('C21')
def test_sync_reports(ui_add_inbound_source_driver):
    source_name = f'WD - {uuid.uuid4()}'
    InboundSourceSteps(ui_add_inbound_source_driver).configure_source_settings(source_name) \
        .validate_sync_report_defaults() \
        .validate_send_report_defaults()
