import pytest

from idaptive_automation.ui_automation import AppsPage
from idaptive_testrail.plugin import pytestrail
from BrowserSteps.inbound_page_steps import InboundProvisioningPageSteps
from Fixtures.ui_fixtures import ui_apps_prov_driver


@pytestrail.case('C22389')
def test_validate_provisioning_column(ui_apps_prov_driver):
    apps_page = AppsPage(ui_apps_prov_driver)
    apps_page.wait_for_page_to_load()
    apps = apps_page.get_apps()
    assert 'Disabled' in list(filter(lambda app: 'Absorb LMS' in app.text, apps))[0].text
    assert 'Enabled' in list(filter(lambda app: 'Zendesk' in app.text, apps))[0].text


@pytestrail.case('C24579')
def test_check_account_mapping_disabled(ui_apps_prov_driver):
    apps_page = AppsPage(ui_apps_prov_driver)
    apps_page.wait_for_page_to_load()
    app_detail_page = apps_page.select_web_app('Zendesk')
    app_detail_page.click_on_account_mapping()
    assert app_detail_page.is_app_not_available_label_displayed() is True


@pytestrail.case('C22390')
def test_validate_provisioning_detail_page(ui_apps_prov_driver):
    apps_page = AppsPage(ui_apps_prov_driver)
    apps_page.wait_for_page_to_load()
    app_detail_page = apps_page.select_web_app('Zendesk')
    app_detail_page.open_provisioning_tab()
    assert app_detail_page.open_script_block() is not None
    app_detail_page.validate_learn_more_link('Zendesk')
