import uuid

from idaptive_testrail.plugin import pytestrail

from BrowserSteps.inbound_page_steps import InboundProvisioningPageSteps
from Fixtures.ui_fixtures import ui_inbound_prov_driver
from Workers.provisioning_worker import ProvisioningWorker


@pytestrail.case('C13')
def test_check_inbound_provisioning_links(ui_inbound_prov_driver):
    page = InboundProvisioningPageSteps(ui_inbound_prov_driver).validate_learn_more_link()
    page.validate_view_reports_link()


@pytestrail.case('C33489')
def test_multiple_enabled_sources_no_actions(ui_inbound_prov_driver, cloud_session, helpers_fixture):
    provisioning_worker = ProvisioningWorker(cloud_session, helpers_fixture)

    initial_source_name = str(uuid.uuid4())[0:8]
    initial_source_id = provisioning_worker.create_inbound_source('Workday', initial_source_name)
    secondary_source_name = str(uuid.uuid4())[0:8]
    secondary_source_id = provisioning_worker.create_inbound_source('Workday', secondary_source_name)
    assert initial_source_id is not None
    assert secondary_source_id is not None

    page = InboundProvisioningPageSteps(ui_inbound_prov_driver).refresh_source_list()
    page.select_inbound_source(initial_source_name)
    page.select_inbound_source(secondary_source_name)
    page.validate_no_actions_available()
