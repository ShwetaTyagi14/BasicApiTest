from idaptive_testrail.plugin import pytestrail

from BrowserSteps.outbound_page_steps import OutboundProvisioningPageSteps
from Fixtures.ui_fixtures import ui_outbound_prov_driver


@pytestrail.case('C13')
def test_check_daily_sync_options(ui_outbound_prov_driver):
    steps = OutboundProvisioningPageSteps(ui_outbound_prov_driver).validate_default_daily_sync_settings()
    steps.validate_enabling_daily_sync()
    steps.validate_reset_outbound_daily_sync()
