import pytest

from idaptive_automation.api_client import ApiSession
from idaptive_automation.ui_automation.idaptive_driver import Driver
from ldap3.core.exceptions import LDAPSocketOpenError
from mongocred.mongocred import MongoCred
from idaptive_automation.api_helpers import AppHelper, \
    RoleApi, \
    UserApi, \
    ProvisioningApi, \
    RedrockApi, \
    ActiveDirectoryHelper, \
    CDirectoryService, \
    O365Api, UserProvisioningHelper
from selenium import webdriver

from BrowserSteps.login_steps import Login
from BrowserSteps.navigate_steps import Navigate


def pytest_addoption(parser):
    parser.addoption(
        '--tenant', action='append', default=None,
        help='tenant to test'
    )
    # parser.addoption(
    #     '--base_url', action='append', default=None,
    #     help='tenant to test'
    # )
    # parser.addoption(
    #     '--username', action='append', default=None,
    #     help='tenant to test'
    # )
    # parser.addoption(
    #     '--password', action='append', default=None,
    #     help='tenant to test'
    # )
    parser.addoption(
        '--env', action='append', default=None,
        help='tenant to test'
    )


def pytest_generate_tests(metafunc):
    if 'tenant' in metafunc.fixturenames:
        metafunc.parametrize('tenant', metafunc.config.getoption('tenant'))

    # if 'base_url' in metafunc.fixturenames:
    #     metafunc.parametrize('base_url', metafunc.config.getoption('base_url'))

    # if 'username' in metafunc.fixturenames:
    #     metafunc.parametrize('username', metafunc.config.getoption('username'))
    #
    # if 'password' in metafunc.fixturenames:
    #     metafunc.parametrize('password', metafunc.config.getoption('password'))


def pytest_configure(config):
    config.addinivalue_line(
        "markers", "pipeline: mark test to be ran as part of the build pipeline"
    )


@pytest.fixture(name='cloud_session')
def idaptive_session(request, tenant):
    """
    Global fixture used to maintain an active session with the Idaptive cloud
    """
    mongo_cred = MongoCred()
    environment = request.config.getoption('--env')[0]
    test_creds = mongo_cred.get_tenant_credentials(tenant, env=environment)

    session = ApiSession(
        test_creds['base_url'],
        test_creds['tenant_id'],
        test_creds['username'],
        test_creds['password'],
        db_metrics=False
    )
    test_session = {
        'api_session': session,
        'mongo_cred': mongo_cred,
        'dc_info': test_creds['domain_controller']
    }
    yield test_session


@pytest.fixture(name='helpers')
def helpers_fixture(cloud_session):
    helpers = {}
    dc = cloud_session['dc_info']
    with AppHelper(cloud_session['api_session'], auto_clean=True, db_metrics=False) as app_helper, \
            RoleApi(cloud_session['api_session'], auto_clean=True, db_metrics=False) as role_helper, \
            UserApi(cloud_session['api_session'], auto_clean=True, db_metrics=False) as user_helper, \
            ProvisioningApi(cloud_session['api_session'], auto_clean=True, db_metrics=False) as provisioning_helper, \
            CDirectoryService(cloud_session['api_session'], db_metrics=False) as cdirectory_helper, \
            O365Api(cloud_session['api_session'], db_metrics=False) as o365_helper, \
            UserProvisioningHelper(cloud_session['api_session'], db_metrics=False) as user_prov_helper:
        helpers['app_helper'] = app_helper
        helpers['role_helper'] = role_helper
        helpers['user_helper'] = user_helper
        helpers['provisioning_helper'] = provisioning_helper
        helpers['redrock_helper'] = RedrockApi(cloud_session['api_session'])
        helpers['cdirectory_helper'] = cdirectory_helper
        helpers['o365_helper'] = o365_helper
        helpers['user_prov_helper'] = user_prov_helper

        try:
            with ActiveDirectoryHelper(server_address=dc['server_address'],
                                       domain_name=dc['domain_name'],
                                       domain_suffix=dc['domain_suffix'],
                                       email_suffix=dc['default_email_suffix'],
                                       username=dc['username'],
                                       password=dc['password'],
                                       auto_clean=True) as active_directory_helper:
                helpers['active_directory_helper'] = active_directory_helper
        except:
            # Not every test is going to require an AD instance so if we are unable
            # to connect to the DC go ahead and try to execute the test run anyways
            helpers['active_directory_helper'] = None
        yield helpers
        if helpers['active_directory_helper'] is not None:
            active_directory_helper.clean_domain_environment()


@pytest.fixture(name='pod_validation')
def pod_validation_fixture(base_url, tenant, username, password):
    mongo_cred = MongoCred()
    api_session = ApiSession(
        base_url,
        tenant,
        username,
        password
    )

    validation_session = {
        'api_session': api_session,
        'mongo_cred': mongo_cred,
        'base_url': base_url,
        'tenant': tenant,
        'username': username,
        'password': password,
        'dc_info': None
    }

    yield validation_session
    api_session.security.logout()
    mongo_cred.client.close()


@pytest.fixture(name='validation_helpers')
def validation_helpers_fixture(pod_validation):
    helpers = {}
    with AppHelper(pod_validation['api_session'], True) as app_helper, \
            RoleApi(pod_validation['api_session'], True) as role_helper, \
            UserApi(pod_validation['api_session'], True) as user_helper, \
            CDirectoryService(pod_validation['api_session']) as cdirectory_helper, \
            O365Api(pod_validation['api_session']) as o365_helper, \
            ProvisioningApi(pod_validation['api_session'], True) as provisioning_helper, \
            UserProvisioningHelper(pod_validation['api_session'], True) as user_prov_helper:
        helpers['app_helper'] = app_helper
        helpers['role_helper'] = role_helper
        helpers['provisioning_helper'] = provisioning_helper
        helpers['redrock_helper'] = RedrockApi(pod_validation['api_session'])
        helpers['user_helper'] = user_helper
        helpers['cdirectory_helper'] = cdirectory_helper
        helpers['o365_helper'] = o365_helper
        helpers['user_prov_helper'] = user_prov_helper
        yield helpers


@pytest.fixture(params=['Chrome'])
def ui_validation_apps_page_driver(tenant, request, pod_validation):
    options = None
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    with Driver(options, base_url=pod_validation['base_url']) as browser:
        browser.maximize_window()
        Login(browser, pod_validation['base_url']) \
            .to_admin_portal(pod_validation['username'], pod_validation['password'], True)
        Navigate(browser).to_apps_page()
        yield browser

