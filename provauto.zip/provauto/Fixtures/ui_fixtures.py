import pytest
import uuid

from selenium import webdriver
from mongocred.mongocred import MongoCred
from idaptive_automation.ui_automation.idaptive_driver import Driver
from BrowserSteps.login_steps import Login
from BrowserSteps.navigate_steps import Navigate
from Workers.cloud_setup_worker import CloudSetupWorker


@pytest.fixture(params=['Chrome'])
def ui_add_inbound_source_driver(tenant, request):
    mongo_cred = MongoCred()
    ui_creds = mongo_cred.get_tenant_credentials(tenant)
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    elif request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=ui_creds['base_url']) as browser:
        browser.maximize_window()
        Login(browser, ui_creds['base_url']) \
            .to_admin_portal(ui_creds['username'], ui_creds['password'], True)
        Navigate(browser).to_inbound_provisioning_page() \
            .add_inbound_source()
        yield browser


@pytest.fixture(params=['Chrome'])
def ui_add_inbound_source_rule(tenant, request):
    mongo_cred = MongoCred()
    ui_creds = mongo_cred.get_tenant_credentials(tenant)
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    elif request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=ui_creds['base_url']) as browser:
        browser.maximize_window()
        Login(browser, ui_creds['base_url']) \
            .to_admin_portal(ui_creds['username'], ui_creds['password'], True)
        Navigate(browser).to_inbound_provisioning_page() \
            .add_inbound_source()
    yield browser


@pytest.fixture(params=['Chrome'])
def ui_inbound_prov_driver(tenant, request):
    mongo_cred = MongoCred()
    ui_creds = mongo_cred.get_tenant_credentials(tenant)
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    elif request.param == 'Firefox':
        options = webdriver.FirefoxOptions()
    with Driver(options, base_url=ui_creds['base_url']) as browser:
        browser.maximize_window()
        Login(browser, ui_creds['base_url']) \
            .to_admin_portal(ui_creds['username'], ui_creds['password'], True)
        Navigate(browser).to_inbound_provisioning_page()
        yield browser


@pytest.fixture(params=['Chrome'])
def ui_outbound_prov_driver(tenant, request):
    mongo_cred = MongoCred()
    ui_creds = mongo_cred.get_tenant_credentials(tenant)
    options = None
    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    with Driver(options, base_url=ui_creds['base_url']) as browser:
        browser.maximize_window()
        Login(browser, ui_creds['base_url']) \
            .to_admin_portal(ui_creds['username'], ui_creds['password'], True)
        Navigate(browser).to_outbound_provisioning_page()
        yield browser


@pytest.fixture(params=['Chrome'])
def ui_apps_prov_driver(cloud_session, helpers, tenant, request):
    mongo_cred = MongoCred()
    ui_creds = mongo_cred.get_tenant_credentials(tenant)
    options = None

    cloud_setup = CloudSetupWorker(cloud_session, helpers)
    role = cloud_setup.create_unique_role()
    user = cloud_setup.create_unique_user(str(uuid.uuid4())[0:8])
    cloud_setup.add_user_to_role(role['role_id'], user['user_id'])
    app_key = cloud_setup.import_application('AbsorbLMS', True, role['role_name'])
    cloud_setup.disable_app_provisioning('AbsorbLMS', app_key, role['role_name'])
    app_key = cloud_setup.import_application('ZenDesk', True, role['role_name'])

    if request.param == 'Chrome':
        options = webdriver.ChromeOptions()
    with Driver(options, base_url=ui_creds['base_url']) as browser:
        browser.maximize_window()
        Login(browser, ui_creds['base_url']) \
            .to_admin_portal(ui_creds['username'], ui_creds['password'], True)
        Navigate(browser).to_apps_page()
        yield browser
