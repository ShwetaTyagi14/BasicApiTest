import pytest

from ADLibrary.ad_server import AdServer


@pytest.yield_fixture()
def create_domain_environment():
    ad_server = AdServer(
        'LDAPS://192.168.118.135',
        'cent-station',
        'administrator',
        'testTEST1234'
    )

    ad_server.create_organizational_unit(
        'O365ProvisionOU',
        'dc=cent-station,dc=com'
    )

    for ou in range(5):
        ad_server.create_organizational_unit(
            'O365ProvisionGroup{}'.format(ou + 1),
            'ou=O365ProvisionOU,dc=cent-station,dc=com'
        )

    ad_server.create_organizational_unit(
        'O365GroupsOU',
        'ou=O365ProvisionOU,dc=cent-station,dc=com'
    )

    for group in range(5):
        group_users = []
        ad_server.create_ad_group(
            'O365Group{}'.format(group + 1),
            'OU=O365GroupsOU,OU=O365ProvisionOU,DC=cent-station,DC=com'
        )
        for user in range(20):
            ad_server.create_ad_user(
                'OU={},OU=O365ProvisionOU,DC=cent-station,DC=com'.format('O365ProvisionGroup{}'.format(group + 1)),
                samaccount_name='O365Group{}user{}'.format(group + 1, user + 1),
                password='@bS0lution',
                first_name='O365Group{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='O365Group{}user{}@automationrdtesting.com'.format(group + 1, user + 1),
                domain='cent-station.com'
            )

            group_users.append('CN={},OU={},OU=O365ProvisionOU,DC=cent-station,DC=com'
                               .format('O365Group{}user{}'
                                       .format(group + 1, user + 1),
                                       'O365ProvisionGroup{}'.format(group + 1)
                                       )
                               )

        ad_server.add_users_to_group(group_users, 'CN=O365Group{},OU=O365GroupsOU,OU=O365ProvisionOU,'
                                                  'DC=cent-station,DC=com'.format(group + 1))

    yield ad_server


@pytest.yield_fixture()
def saml_environment():
    ad_server = AdServer(
        'LDAP://192.168.118.135',
        'cent-station',
        'administrator',
        'testTEST1234'
    )

    ad_server.create_organizational_unit(
        'SAMLProvisionOU',
        'dc=cent-station,dc=com'
    )

    for ou in range(5):
        ad_server.create_organizational_unit(
            'SAMLProvisionGroup{}'.format(ou + 1),
            'ou=SAMLProvisionOU,dc=cent-station,dc=com'
        )

    ad_server.create_organizational_unit(
        'SAMLGroupsOU',
        'ou=SAMLProvisionOU,dc=cent-station,dc=com'
    )

    for group in range(5):
        group_users = []
        ad_server.create_ad_group(
            'SAMLGroup{}'.format(group + 1),
            'OU=SAMLGroupsOU,OU=SAMLProvisionOU,DC=cent-station,DC=com'
        )
        for user in range(2):
            ad_server.create_ad_user(
                'OU={},OU=SAMLProvisionOU,DC=cent-station,DC=com'.format('SAMLProvisionGroup{}'.format(group + 1)),
                samaccount_name='SAMLGroup{}user{}'.format(group + 1, user + 1),
                password='@bS0lution',
                first_name='SAMLGroup{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='SAMLGroup{}user{}@automationrdtesting.com'.format(group + 1, user + 1),
                domain='cent-station.com'
            )

            group_users.append('CN={},OU={},OU=SAMLProvisionOU,DC=cent-station,DC=com'
                               .format('SAMLGroup{}user{}'
                                       .format(group + 1, user + 1),
                                       'ProvisionGroup{}'.format(group + 1)
                                       )
                               )

        ad_server.add_users_to_group(group_users, 'CN=SAMLGroup{},OU=SAMLGroupsOU,OU=SAMLProvisionOU,'
                                                  'DC=cent-station,DC=com'.format(group + 1))

    yield ad_server

    ad_server.delete_ad_object('ou=SAMLProvisionOU,dc=cent-station,dc=com')


@pytest.yield_fixture()
def aws_environment():
    ad_server = AdServer(
        'LDAPS://192.168.118.135',
        'cent-station',
        'administrator',
        'testTEST1234'
    )

    ad_server.create_organizational_unit(
        'AWSProvisionOU',
        'dc=cent-station,dc=com'
    )

    for ou in range(5):
        ad_server.create_organizational_unit(
            'AWSProvisionGroup{}'.format(ou + 1),
            'ou=AWSProvisionOU,dc=cent-station,dc=com'
        )

    ad_server.create_organizational_unit(
        'AWSGroupsOU',
        'ou=AWSProvisionOU,dc=cent-station,dc=com'
    )

    for group in range(5):
        group_users = []
        ad_server.create_ad_group(
            'AWSGroup{}'.format(group + 1),
            'OU=AWSGroupsOU,OU=AWSProvisionOU,DC=cent-station,DC=com'
        )
        for user in range(2):
            ad_server.create_ad_user(
                'OU={},OU=AWSProvisionOU,DC=cent-station,DC=com'.format('AWSProvisionGroup{}'.format(group + 1)),
                samaccount_name='AWSGroup{}user{}'.format(group + 1, user + 1),
                password='@bS0lution',
                first_name='AWSGroup{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='AWSGroup{}user{}@automationrdtesting.com'.format(group + 1, user + 1),
                domain='cent-station.com'
            )

            group_users.append('CN={},OU={},OU=AWSProvisionOU,DC=cent-station,DC=com'
                               .format('AWSGroup{}user{}'
                                       .format(group + 1, user + 1),
                                       'ProvisionGroup{}'.format(group + 1)
                                       )
                               )

        ad_server.add_users_to_group(group_users, 'CN=AWSGroup{},OU=AWSGroupsOU,OU=AWSProvisionOU,'
                                                  'DC=cent-station,DC=com'.format(group + 1))

    yield ad_server

    ad_server.delete_ad_object('ou=AWSProvisionOU,dc=cent-station,dc=com')


@pytest.yield_fixture()
def create_mismatched_domain_environment():
    ad_server = AdServer(
        'LDAPS://192.168.118.135',
        'cent-station',
        'administrator',
        'testTEST1234'
    )

    ad_server.create_organizational_unit(
        'O365MismatchProvisionOU',
        'dc=cent-station,dc=com'
    )

    for ou in range(5):
        ad_server.create_organizational_unit(
            'O365MismatchProvisionGroup{}'.format(ou + 1),
            'ou=O365MismatchProvisionOU,dc=cent-station,dc=com'
        )

    ad_server.create_organizational_unit(
        'O365MismatchGroupsOU',
        'ou=O365MismatchProvisionOU,dc=cent-station,dc=com'
    )

    for group in range(5):
        group_users = []
        ad_server.create_ad_group(
            'O365MismatchGroup{}'.format(group + 1),
            'OU=O365MismatchGroupsOU,OU=O365MismatchProvisionOU,DC=cent-station,DC=com'
        )
        for user in range(20):
            ad_server.create_ad_user(
                'OU={},OU=O365MismatchProvisionOU,DC=cent-station,DC=com'.format('O365MismatchProvisionGroup{}'.format(group + 1)),
                samaccount_name='O365Mismatch{}user{}'.format(group + 1, user + 1),
                password='@bS0lution',
                first_name='O365Mismatch{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='O365Mismatch{}user{}@mismatched.com'.format(group + 1, user + 1),
                domain='cent-station.com'
            )

            group_users.append('CN={},OU={},OU=O365MismatchProvisionOU,DC=cent-station,DC=com'
                               .format('O365Mismatch{}user{}'
                                       .format(group + 1, user + 1),
                                       'O365MismatchProvisionGroup{}'.format(group + 1)
                                       )
                               )

        ad_server.add_users_to_group(
            group_users,
            'CN=O365MismatchGroup{},OU=O365MismatchGroupsOU,OU=O365MismatchProvisionOU,DC=cent-station,DC=com'.format(group + 1)
        )

    yield ad_server

    ad_server.delete_ad_object('OU=O365MismatchProvisionOU,DC=cent-station,DC=com')


@pytest.yield_fixture()
def create_disable_environment():
    ad_server = AdServer(
        'LDAPS://192.168.118.135',
        'cent-station',
        'administrator',
        'testTEST1234'
    )

    ad_server.create_organizational_unit(
        'O365DisableProvisionOU',
        'dc=cent-station,dc=com'
    )

    for ou in range(1):
        ad_server.create_organizational_unit(
            'O365DisableProvisionGroup{}'.format(ou + 1),
            'ou=O365DisableProvisionOU,dc=cent-station,dc=com'
        )

    ad_server.create_organizational_unit(
        'O365DisableGroupsOU',
        'ou=O365DisableProvisionOU,dc=cent-station,dc=com'
    )

    for group in range(1):
        group_users = []
        ad_server.create_ad_group(
            'O365DisableGroup{}'.format(group + 1),
            'OU=O365DisableGroupsOU,OU=O365DisableProvisionOU,DC=cent-station,DC=com'
        )
        for user in range(1):
            ad_server.create_ad_user(
                'OU={},OU=O365DisableProvisionOU,DC=cent-station,DC=com'.format(
                    'O365DisableProvisionGroup{}'.format(group + 1)),
                samaccount_name='O365Disable{}user{}'.format(group + 1, user + 1),
                password='@bS0lution',
                first_name='O365Disable{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='O365Disable{}user{}@automationrdtesting.com'.format(group + 1, user + 1),
                domain='cent-station.com'
            )

            group_users.append('CN={},OU={},OU=O365DisableProvisionOU,DC=cent-station,DC=com'
                               .format('O365Disable{}user{}'
                                       .format(group + 1, user + 1),
                                       'O365DisableProvisionGroup{}'.format(group + 1)
                                       )
                               )

        ad_server.add_users_to_group(
            group_users,
            'CN=O365DisableGroup{},OU=O365DisableGroupsOU,OU=O365DisableProvisionOU,DC=cent-station,DC=com'.format(
                group + 1)
        )

    yield ad_server

    ad_server.delete_ad_object('OU=O365DisableProvisionOU,DC=cent-station,DC=com')


@pytest.yield_fixture()
def create_remove_group_environment():
    ad_server = AdServer(
        'LDAPS://192.168.118.135',
        'cent-station',
        'administrator',
        'testTEST1234'
    )

    ad_server.create_organizational_unit(
        'O365RemoveProvisionOU',
        'dc=cent-station,dc=com'
    )

    for ou in range(1):
        ad_server.create_organizational_unit(
            'O365RemoveProvisionGroup{}'.format(ou + 1),
            'ou=O365RemoveProvisionOU,dc=cent-station,dc=com'
        )

    ad_server.create_organizational_unit(
        'O365RemoveGroupsOU',
        'ou=O365RemoveProvisionOU,dc=cent-station,dc=com'
    )

    for group in range(1):
        group_users = []
        ad_server.create_ad_group(
            'O365RemoveGroup{}'.format(group + 1),
            'OU=O365RemoveGroupsOU,OU=O365RemoveProvisionOU,DC=cent-station,DC=com'
        )
        for user in range(1):
            ad_server.create_ad_user(
                'OU={},OU=O365RemoveProvisionOU,DC=cent-station,DC=com'.format(
                    'O365RemoveProvisionGroup{}'.format(group + 1)),
                samaccount_name='O365Remove{}user{}'.format(group + 1, user + 1),
                password='@bS0lution',
                first_name='O365Remove{}'.format(group + 1),
                last_name='user {}'.format(user + 1),
                email='O365remove{}user{}@automationrdtesting.com'.format(group + 1, user + 1),
                domain='cent-station.com'
            )


            group_users.append(
                'CN={},OU={},OU=O365RemoveProvisionOU,DC=cent-station,DC=com'
                .format('O365Remove{}user{}'
                        .format(group + 1, user + 1),
                        'O365RemoveProvisionGroup{}'
                        .format(group + 1)
                        )
            )

        ad_server.add_users_to_group(
            group_users,
            'CN=O365RemoveGroup{},OU=O365RemoveGroupsOU,OU=O365RemoveProvisionOU,DC=cent-station,DC=com'.format(
                group + 1)
        )

    yield ad_server

    ad_server.delete_ad_object('OU=O365RemoveProvisionOU,DC=cent-station,DC=com')
