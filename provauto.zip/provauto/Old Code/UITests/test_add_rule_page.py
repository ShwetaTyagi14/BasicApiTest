import pytest
from idaptive_testrail.plugin import pytestrail
from selenium import webdriver

from Steps.add_rule_steps import AddRuleSteps
from Steps.add_source_steps import AddSourceSteps
from Steps.admin_steps import AdminSteps
from driver import Driver


@pytestrail.case('C14')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_check_source_tab(name, browser, idaptive_ui_environment):
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])
        dc_info = idaptive_ui_environment['domain_controller']

        add_source_steps = AddSourceSteps(driver)
        add_rule_steps = AddRuleSteps(driver, dc_info)
        admin_steps = AdminSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_inbound_provisioning()

        source_name = add_source_steps.configure_source_settings()
        add_source_steps.save_provisioning_source()
        admin_steps.validate_admin_portal_loaded()

        add_rule_steps.add_inbound_source_rule(source_name)
        add_rule_steps.check_add_rule_source_defaults()
        add_rule_steps.check_supervisory_organization_add()

        admin_steps.navigate_to_inbound_provisioning()
        add_rule_steps.clean_up_rule(source_name)
    finally:
        driver.quit()


@pytestrail.case('C15')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_check_target_tab(name, browser, idaptive_ui_environment):
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])
        dc_info = idaptive_ui_environment['domain_controller']

        add_source_steps = AddSourceSteps(driver)
        add_rule_steps = AddRuleSteps(driver, dc_info)
        admin_steps = AdminSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_inbound_provisioning()

        source_name = add_source_steps.configure_source_settings()
        add_source_steps.save_provisioning_source()
        admin_steps.validate_admin_portal_loaded()

        add_rule_steps.add_inbound_source_rule(source_name)
        add_rule_steps.configure_rule_source()
        add_rule_steps.check_target_defaults()

        admin_steps.navigate_to_inbound_provisioning()
        add_rule_steps.clean_up_rule(source_name)
    finally:
        driver.quit()


@pytestrail.case('C16')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_check_attributes_tab(name, browser, idaptive_ui_environment):
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])
        dc_info = idaptive_ui_environment['domain_controller']

        add_source_steps = AddSourceSteps(driver)
        add_rule_steps = AddRuleSteps(driver, dc_info)
        admin_steps = AdminSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_inbound_provisioning()

        source_name = add_source_steps.configure_source_settings()
        add_source_steps.save_provisioning_source()
        admin_steps.validate_admin_portal_loaded()

        add_rule_steps.add_inbound_source_rule(source_name)
        add_rule_steps.configure_rule_source()
        add_rule_steps.configure_rule_target()

        add_rule_steps.check_attribute_required_mappings()
        add_rule_steps.check_attribute_mapping_script()

        admin_steps.navigate_to_inbound_provisioning()
        add_rule_steps.clean_up_rule(source_name)
    finally:
        driver.quit()


@pytestrail.case('C17')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_check_options_tab(name, browser, idaptive_ui_environment):
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])
        dc_info = idaptive_ui_environment['domain_controller']

        add_source_steps = AddSourceSteps(driver)
        add_rule_steps = AddRuleSteps(driver, dc_info)
        admin_steps = AdminSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_inbound_provisioning()

        source_name = add_source_steps.configure_source_settings()
        add_source_steps.save_provisioning_source()
        admin_steps.validate_admin_portal_loaded()

        add_rule_steps.add_inbound_source_rule(source_name)
        add_rule_steps.configure_rule_source()
        add_rule_steps.configure_rule_target()
        add_rule_steps.configure_attributes()

        add_rule_steps.check_option_defaults()
        add_rule_steps.check_static_password_defaults()
        add_rule_steps.check_generated_password_defaults()
        add_rule_steps.check_map_provisioning_group_defaults()

        admin_steps.navigate_to_inbound_provisioning()
        add_rule_steps.clean_up_rule(source_name)
    finally:
        driver.quit()
