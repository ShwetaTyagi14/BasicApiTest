import uuid

import pytest
from idaptive_testrail.plugin import pytestrail
from selenium import webdriver

from Steps.admin_steps import AdminSteps
from Steps.app_steps import AppSteps
from Steps.cloud_environment_steps import CloudEnvironment
from Steps.data_steps import DataSteps
from Steps.outbound_steps import OutboundSteps
from driver import Driver


# @pytestrail.case('C22389')
# @pytest.mark.parametrize('name, browser', [
#     ('Chrome', webdriver.ChromeOptions()),
#     ('Firefox', webdriver.FirefoxOptions())
#  ])
# def test_validate_provisioning_column(name, browser, idaptive_ui_environment):
#     driver = Driver(browser)
#
#     try:
#         driver.get(idaptive_ui_environment['base_url'])
#
#         admin_steps = AdminSteps(driver)
#         app_steps = AppSteps(driver)
#
#         admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
#         admin_steps.navigate_to_admin_portal()
#
#         admin_steps.navigate_to_web_apps()
#         app_steps.validate_web_apps_page_loaded()
#         app_steps.validate_enabled_disabled_prov_columns()
#     finally:
#         driver.quit()


# @pytestrail.case('C22390')
# @pytest.mark.parametrize('name, browser', [
#     ('Chrome', webdriver.ChromeOptions()),
#     ('Firefox', webdriver.FirefoxOptions())
#  ])
# def test_validate_provisioning_detail_page(name, browser, idaptive_ui_environment):
#     driver = Driver(browser)
#
#     try:
#         driver.get(idaptive_ui_environment['base_url'])
#
#         admin_steps = AdminSteps(driver)
#         app_steps = AppSteps(driver)
#
#         admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
#         admin_steps.navigate_to_admin_portal()
#
#         admin_steps.navigate_to_web_apps()
#         app_steps.validate_web_apps_page_loaded()
#         app_steps.select_web_app('App Prov Enabled')
#
#         app_steps.validate_provisioning_script_enables()
#         app_steps.validate_learn_more_link()
#     finally:
#         driver.quit()


@pytestrail.case('C22391')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_duplicated_role_mapping(name, browser, idaptive_ui_environment):
    # TODO This test case needs some refactoring work - It's not always passing when it should
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])

        admin_steps = AdminSteps(driver)
        app_steps = AppSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()

        admin_steps.navigate_to_web_apps()
        app_steps.validate_web_apps_page_loaded()
        app_steps.select_web_app('App Prov Enabled')

        app_steps.add_web_app_role('System Administrator')
        app_steps.validate_role_not_available('System Administrator')
        app_steps.cancel_add_web_app_role()
    finally:
        driver.quit()


@pytestrail.case('C24578')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_validate_non_oauth_cred_input(name, browser, idaptive_ui_environment):
    # TODO This test case needs some refactoring work - It's not always passing when it should
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])

        admin_steps = AdminSteps(driver)
        app_steps = AppSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_web_apps()
        app_steps.validate_web_apps_page_loaded()

        app_steps.add_custom_saml_app()
        app_steps.select_web_app('SAML')
        app_steps.enable_app_provisioning()

        app_steps.validate_creds_required_nav_tab()
        app_steps.validate_creds_requried_save_tab()

        app_steps.input_scim_creds(
            url='https://trello.com/scim/v',
            token='11faac7d7a6480bc1ff86189579c83a6f0ea16a70cd24964b7b1dc921977bc61'
        )
        app_steps.check_message_on_invalid_creds()

        app_steps.input_scim_creds(
            url='https://trello.com/scim/v2',
            token='11faac7d7a6480bc1ff86189579c83a6f0ea16a70cd24964b7b1dc921977bc61'
        )
        app_steps.check_valid_creds()

        app_steps.validate_creds_are_persistent(
            url='https://trello.com/scim/v2',
            token='11faac7d7a6480bc1ff86189579c83a6f0ea16a70cd24964b7b1dc921977bc61'
        )

        app_steps.cancel_provisioning_tab()
        app_steps.delete_provisioning_app(app='SAML')
    finally:
        driver.quit()


# @pytestrail.case('C24579')
# @pytest.mark.parametrize('name, browser', [
#     ('Chrome', webdriver.ChromeOptions()),
#     ('Firefox', webdriver.FirefoxOptions())
#  ])
# def test_check_account_mapping_disabled(name, browser, idaptive_ui_environment):
#     driver = Driver(browser)
#
#     try:
#         driver.get(idaptive_ui_environment['base_url'])
#
#         admin_steps = AdminSteps(driver)
#         app_steps = AppSteps(driver)
#
#         admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
#         admin_steps.navigate_to_admin_portal()
#         admin_steps.navigate_to_web_apps()
#         app_steps.validate_web_apps_page_loaded()
#
#         app_steps.select_web_app('App Prov Enabled')
#         app_steps.validate_account_mapping_not_available()
#     finally:
#         driver.quit()


@pytestrail.case('C33495')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_provisioning_script_trace(name, browser, idaptive_session, idaptive_ui_environment):
    app = "ZenDesk"
    driver = Driver(browser)

    api_session = idaptive_session['api_session']
    dc_info = idaptive_session['dc_info']

    data_steps = DataSteps(idaptive_session['mongo_cred'])
    outbound_steps = OutboundSteps(api_session, data_steps)
    cloud_environment = CloudEnvironment(api_session, data_steps)

    try:
        # region "API Driven"
        role_name = '{} Prov Script Trace - Test Role - Remove'.format(app)
        test_data = data_steps.query_db_collection('automation', 'provision_apps', {'name': app})

        user_name = f'{uuid.uuid4()}'
        user_id = cloud_environment.create_cloud_user(user_name, dc_info)
        assert user_id is not None

        role_id = cloud_environment.create_core_role(role_name)
        assert role_id is not None
        assert outbound_steps.map_user_to_core_role(role_id, user_id).success is True

        app_key = cloud_environment.import_app(test_data['importName'])
        assert app_key is not None

        app_name = f'{uuid.uuid4()}'
        if test_data['updateApplicationDE'] is not None:

            test_data['updateApplicationDE']['Name'] = app_name
            assert outbound_steps.update_application_de(app_key, test_data['updateApplicationDE']).success is True

        # TODO Not in love with how this is done
        test_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name

        assert outbound_steps.update_app(app_key, test_data['updateAppProvisioning']).success is True
        assert outbound_steps.get_app(app_key).success is True
        # endregion

        # region "UI Driven"
        driver.get(idaptive_ui_environment['base_url'])

        admin_steps = AdminSteps(driver)
        app_steps = AppSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()

        admin_steps.navigate_to_web_apps()
        app_steps.validate_web_apps_page_loaded()
        app_steps.select_web_app(app_name)

        app_steps.validate_provisioning_script_test(user_name)
        # endregion
    finally:
        cloud_environment.clean_cloud_environment()
        driver.quit()
