from Steps.outbound_page_steps import OutboundProvPageSteps
from Steps.job_history_page_steps import JobHistoryPageSteps
import pytest
from selenium import webdriver
from Steps.admin_steps import AdminSteps
from Steps.app_steps import AppSteps
from driver import Driver
from idaptive_testrail.plugin import pytestrail
from Steps.cloud_environment_steps import CloudEnvironment
from Steps.outbound_steps import OutboundSteps
from Steps.data_steps import DataSteps
from Steps.domain_environment_steps import DomainEnvironmentSteps
import time




@pytestrail.case('C33693')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
])
def test_o365_check_default_job_history_filter(name, browser, idaptive_ui_environment):
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])

        admin_steps = AdminSteps(driver)
        outbound_prov_steps = OutboundProvPageSteps(driver)
        job_history_steps = JobHistoryPageSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_outbound_provisioning()

        outbound_prov_steps.click_job_history_link()
        job_history_steps.page_loaded()
        job_history_steps.check_default_filter()

    finally:
        driver.quit()


@pytestrail.case('C33698')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
 ])
def test_validate_job_history_filtering(name, browser, idaptive_ui_environment):
    driver = Driver(browser)

    try:
        driver.get(idaptive_ui_environment['base_url'])

        admin_steps = AdminSteps(driver)
        outbound_prov_steps = OutboundProvPageSteps(driver)
        job_history_steps = JobHistoryPageSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_outbound_provisioning()

        outbound_prov_steps.click_job_history_link()
        job_history_steps.page_loaded()
        job_history_steps.validate_filter("All Completed Jobs With Issues")

    finally:
        driver.quit()


@pytestrail.case('C33699')
@pytest.mark.parametrize('name, browser', [
    ('Chrome', webdriver.ChromeOptions()),
    ('Firefox', webdriver.FirefoxOptions())
])
def test_search_job_history(name, browser, idaptive_ui_environment, idaptive_session):
    # API Part based on: C23 - O365 SAML Provisioning
    app = "UIO365JobHistory"
    email_user_name = app[:8]

    api_session = idaptive_session['api_session']
    data_steps = DataSteps(idaptive_session['mongo_cred'])
    dc_info = idaptive_session['dc_info']
    outbound_steps = OutboundSteps(api_session, data_steps)
    domain_environment = DomainEnvironmentSteps(dc_info)
    cloud_environment = CloudEnvironment(api_session, data_steps)
    driver = Driver(browser)

    try:
        #API Portion:
        domain_environment.create_ad_environment(app[:8])
        groups = domain_environment.get_ad_group_details(
            f"{app[:8]}"
        )

        role_name = f'{app} - Test Role - Remove'
        role_id = cloud_environment.create_core_role(role_name)
        assert role_id is not None

        map_these_groups = []
        for group in groups:
            map_these_groups.append(group['objectGUID'].value.replace('{', '').replace('}', ''))
        assert outbound_steps.map_ad_group_to_core_role(role_id, map_these_groups).success is True

        app_key = cloud_environment.import_app('Office 365v2')
        assert outbound_steps.o365_update_app(app_key, f'{role_name}').success is True
        assert outbound_steps.set_app_permission(app_key, role_id).success is True
        job_result = outbound_steps.request_outbound_full_sync(app_key)
        assert job_result['success'] is True

        job_report = outbound_steps.get_any_type_sync_report_continuously(
            f"{email_user_name}Sub1user1@{dc_info['default_email_suffix']}", 'Updated', 'Office 365')

        assert "Created/Updated user/related object".encode() in job_report

        #UI Portion
        driver.get(idaptive_ui_environment['base_url'])

        admin_steps = AdminSteps(driver)
        outbound_prov_steps = OutboundProvPageSteps(driver)
        job_history_steps = JobHistoryPageSteps(driver)

        admin_steps.login(idaptive_ui_environment['username'], idaptive_ui_environment['password'])
        admin_steps.navigate_to_admin_portal()
        admin_steps.navigate_to_outbound_provisioning()

        outbound_prov_steps.click_job_history_link()
        job_history_steps.page_loaded()
        job_history_steps.validate_search("blahbalh", False)
        job_history_steps.validate_search("Full provisioning sync for Office 365")

    finally:
        driver.quit()
        cleanup_o365_user = outbound_steps.remove_o365_user_and_empty_recycle(
            f"{email_user_name}Sub1user1@{dc_info['default_email_suffix']}")
        domain_environment.clean_domain_environment()
        cloud_environment.clean_cloud_environment()








