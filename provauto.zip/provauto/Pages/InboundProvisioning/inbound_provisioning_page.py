from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from Pages.InboundProvisioning.provisioning_rule_page import ProvisioningRulePage
from Pages.InboundProvisioning.provisioning_source_dialog import ProvisioningSourceDialog


class InboundProvisioningPage:
    def __init__(self, driver):
        self.loaded_element = (By.XPATH, '//div[@viewparttitle="Inbound Provisioning"]')
        # self.modal = (By.CLASS_NAME, 'modal-window')
        # self.yes_btn = (By.XPATH, '//span[text()="Yes"]')
        # self.add_source_button = (By.LINK_TEXT, 'Add Source')
        # self.learn_more_link = (By.LINK_TEXT, "Learn more")
        # self.sync_options_tab = (By.XPATH, '//a[@buttontext="Sync Options"]')
        # self.actions_button = (By.XPATH, '//a[@buttontext="Actions"]')
        # self.view_job_reports_link = (By.LINK_TEXT, "View Synchronization Job Status and Reports")

        self.provisioning_source = ProvisioningSourceDialog(driver)
        self.provisioning_rule = ProvisioningRulePage(driver)
        self.driver = driver

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def click_add_source(self):
        self.driver.click_element(self.add_source_button)

    def select_inbound_source_rule(self, source):
        source_row = self.driver.wait_for_visible_element((By.XPATH, '//span[contains(text(), "{}")]'.format(source)))
        ActionChains(self.driver).context_click(source_row).perform()
        self.driver.click_element((By.XPATH, '//span[text() = "Add Rule"]'))

    def check_inbound_source(self, source):
        source_row = self.driver.wait_for_visible_element((By.XPATH, '//span[contains(text(), "{}")]'.format(source))).find_element_by_xpath('..')
        source_row.find_element_by_class_name('x-tree-checkbox').click()

    def click_actions_button(self):
        container_element = self.driver.wait_for_visible_element(self.loaded_element)
        elements = container_element.find_elements_by_xpath('//a[@buttontext="Actions"]')

        # TODO: Not in love with this but only way without automation ids
        for item in elements:
            if item.is_displayed() is True:
                item.click()

    def validate_no_actions_visible(self):
        element = self.driver.wait_for_visible_element((By.XPATH, '//div[contains(text(), "No actions available")]'))
        return element is not None

    def delete_inbound_source(self, source):
        source_row = self.driver.wait_for_visible_element((By.XPATH, '//span[contains(text(), "{}")]'.format(source)))
        ActionChains(self.driver).context_click(source_row).perform()
        self.driver.click_element((By.XPATH, '//span[text() = "Delete"]'))
        modal = self.driver.wait_for_visible_element(self.modal)
        modal.send_keys(Keys.ENTER)

    def click_learn_more_link(self):
        self.driver.click_element(self.learn_more_link)
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('How to configure inbound provisioning')

    def close_how_to_window(self):
        if self.driver.title == 'How to configure inbound provisioning':
            self.driver.close()
            self.driver.switch_to_window_by_title('Admin Portal')
            return True
        return False

    def click_sync_options_tab(self):
        self.driver.click_element(self.sync_options_tab)

    def click_view_job_reports_link(self):
        self.driver.click_element(self.view_job_reports_link)
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('Job History')

    def close_job_history_window(self):
        if self.driver.title == 'Job History':
            self.driver.close()
            self.driver.switch_to_window_by_title('Admin Portal')
            return True
        return False
