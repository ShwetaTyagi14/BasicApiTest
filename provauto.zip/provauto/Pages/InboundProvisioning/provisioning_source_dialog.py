from selenium.webdriver.common.by import By


class ProvisioningSourceDialog:
    def __init__(self, driver):
        # region Settings
        # self.loaded_element = (By.XPATH, '//div[@viewparttitle="Provisioning Source"]')
        # self.source_drop_down = (By.NAME, 'SourceName')
        # self.enable_instance_checkbox = '//input[@testname="IsInstanceEnabled"]'
        # self.enable_writeback_checkbox = (By.XPATH, '//input[@testname="IsSourceWriteEnabled"]')
        # self.name_input = (By.XPATH, '//input[@testname="Name"]')
        # self.workday_url_input = (By.NAME, 'WorkdayUrl')
        # self.auth_username_input = (By.NAME, 'Auth_UserName')
        # self.auth_encrypted_password = (By.NAME, 'Auth_Encrypted_Password')
        # self.show_password_btn = (By.CLASS_NAME, 'show-password')
        # self.verify_button = '//a[@buttontext="Verify"]'
        # endregion

        # region Report Integration
        # self.enable_report_integration_checkbox = (By.XPATH, '//input[@testname="EnableCustomAttributes"]')
        # self.base_report_url_input = (By.NAME, 'BaseReportUrl')
        # self.relative_schema_url_input = (By.NAME, 'CustomReportXmlSchemaUrl')
        # self.relative_json_data_url_input = (By.NAME, 'CustomReportJsonDataUrl')
        # self.worker_unique_id_field_name_input = (By.NAME, 'CustomReportWorkdayIdField')
        # self.report_query_timeout_input = (By.NAME, 'CustomReportQueryTimeoutMinutes')
        # endregion

        # region Sync Settings
        # self.enable_new_hire_pre_provisioning_checkbox = (
        #     By.XPATH,
        #     '//input[@testname="EnableNewUserPreProvisioning"]'
        # )
        # self.enable_new_hire_pre_provisioning_interval_input = (
        #     By.XPATH,
        #     '//input[@testname="NewUserPreProvisionIntervalHours"]'
        # )
        # self.run_incremental_sync_automatically_checkbox = (
        #     By.XPATH,
        #     '//input[@testname="EnableIncrementalSyncs"]'
        # )
        # self.run_incremental_sync_automatically_frequency_input = (
        #     By.XPATH,
        #     '//input[@testname="IncrementalSyncRepeatIntervalInMinutes"]'
        # )
        # self.tenant_utc_offset_input = (By.XPATH, '//input[@testname="InboundProvTenantUtcOffset"]')
        # self.do_not_create_new_users_checkbox = (By.XPATH, '//input[@testname="UpdateExistingUsersOnly"]')
        # self.ignore_sync_cache_checkbox = (By.XPATH, '//input[@testname="IgnoreSyncCache"]')
        # self.discard_directory_identifiers_checkbox = (
        #     By.XPATH,
        #     '//input[@testname="IgnoreUuidFromCacheIfCacheIgnored"]'
        # )
        # endregion

        # region Sync Reports
        # self.send_report_on_completion_checkbox = (
        #     By.XPATH,
        #     '//input[@testname="EnableSyncNotificationEmails"]'
        # )
        # self.sync_report_type_dropdown = (
        #     By.XPATH,
        #     '//input[@testname="NotificationOptions"]'
        # )
        # self.distribution_add_btn = (
        #     By.XPATH,
        #     '//a[@buttontext="Add"]'
        # )
        # self.sync_rpt_email_input = (
        #     By.NAME,
        #     'email'
        # )
        # # endregion
        #
        # self.report_integration_menu = (By.XPATH, '//span[text() = "Report Integration"]')
        # self.sync_settings_menu = (By.XPATH, '//span[text() = "Sync Settings"]')
        # self.sync_reports_menu = (By.XPATH, '//span[text() = "Sync Reports"]')
        # self.save_provisioning_source_btn = (By.XPATH, '//a[@buttontext="Save"]')
        self.driver = driver

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def is_enable_instance_enabled(self):
        enabled_checkbox = self.driver.get_child_element_by_xpath(self.loaded_element, self.enable_instance_checkbox)
        return enabled_checkbox.is_enabled()

    def is_name_input_enabled(self):
        name_input = self.driver.wait_for_visible_element(self.name_input)
        return name_input.is_enabled()

    def is_verify_button_disabled(self):
        verify_button = self.driver.get_child_element_by_xpath(self.loaded_element, self.verify_button)
        return 'on' in verify_button.get_attribute('unselectable')

    def is_write_back_enabled(self):
        write_back_checkbox = self.driver.fetch_element(self.enable_writeback_checkbox)
        return write_back_checkbox.is_enabled()

    def is_workday_url_enabled(self):
        workday_url = self.driver.wait_for_clickable_element(self.workday_url_input)
        return workday_url.is_enabled()

    def is_username_enabled(self):
        username_input = self.driver.wait_for_clickable_element(self.auth_username_input)
        return username_input.is_enabled()

    def is_password_enabled(self):
        password = self.driver.wait_for_clickable_element(self.auth_encrypted_password)
        return password.is_enabled()

    def is_show_password_enabled(self):
        show_password = self.driver.wait_for_clickable_element(self.show_password_btn)
        return show_password.is_enabled()

    def is_report_integration_checkbox_enabled(self):
        report_integration_chkbox = self.driver.wait_for_clickable_element(self.enable_report_integration_checkbox)
        return report_integration_chkbox.is_enabled()

    def is_base_report_url_enabled(self):
        base_report_url = self.driver.wait_for_visible_element(self.base_report_url_input)
        return base_report_url.is_enabled()

    def is_relative_schema_url_enabled(self):
        relative_schema_url = self.driver.wait_for_visible_element(self.relative_schema_url_input)
        return relative_schema_url.is_enabled()

    def is_relative_json_url_enabled(self):
        relative_json_url = self.driver.wait_for_visible_element(self.relative_json_data_url_input)
        return relative_json_url.is_enabled()

    def is_worker_field_name_enabled(self):
        worker_field_name = self.driver.wait_for_visible_element(self.worker_unique_id_field_name_input)
        return worker_field_name.is_enabled()

    def is_sync_report_type_enabled(self):
        sync_report_type = self.driver.wait_for_visible_element(self.sync_report_type_dropdown)
        return sync_report_type.is_enabled()

    def get_worker_field_name_text(self):
        worker_field_name = self.driver.wait_for_clickable_element(self.worker_unique_id_field_name_input)
        return worker_field_name.get_attribute('value')

    def is_query_timeout_enabled(self):
        query_timeout = self.driver.wait_for_visible_element(self.report_query_timeout_input)
        return query_timeout.is_enabled()

    def click_new_hire_pre_provision(self):
        self.driver.click_element(self.enable_new_hire_pre_provisioning_checkbox)

    def is_new_hire_pre_provisioning_interval_enabled(self):
        pre_prov_interval = self.driver.wait_for_visible_element(self.enable_new_hire_pre_provisioning_interval_input)
        return pre_prov_interval.is_enabled()

    def get_password_mask_attribute(self):
        password = self.driver.wait_for_clickable_element(self.auth_encrypted_password)
        return password.get_attribute('type')

    def click_show_password(self):
        self.driver.click_element(self.show_password_btn)

    def click_report_integration_menu(self):
        self.driver.click_element(self.report_integration_menu)

    def click_sync_settings_menu(self):
        self.driver.click_element(self.sync_settings_menu)

    def click_sync_reports_menu(self):
        self.driver.click_element(self.sync_reports_menu)

    def click_enable_report_integration(self):
        self.driver.click_element(self.enable_report_integration_checkbox)

    def click_send_report_on_sync_complete(self):
        self.driver.click_element(self.send_report_on_completion_checkbox)

    def click_add_distribution_btn(self):
        self.driver.click_element(self.distribution_add_btn)

    def is_email_input_visible(self):
        email_input = self.driver.wait_for_visible_element(self.sync_rpt_email_input)
        return email_input.is_displayed()

    def select_source(self, value):
        self.driver.click_element(self.source_drop_down)
        source_xpath = (By.XPATH, '//li[@data-text="{}"]'.format(value))
        self.driver.click_element(source_xpath)

    def enter_source_name(self, name):
        self.driver.send_element_keys(self.name_input, name)

    def enter_source_url(self, url):
        self.driver.send_element_keys(self.workday_url_input, url)

    def enter_source_username(self, name):
        self.driver.send_element_keys(self.auth_username_input, name)

    def enter_source_password(self, password):
        self.driver.send_element_keys(self.auth_encrypted_password, password)

    def enter_report_query_timeout(self, value):
        self.driver.send_element_keys(self.report_query_timeout_input, value)

    def enter_pre_provisioning_interval(self, value):
        self.driver.send_element_keys(self.enable_new_hire_pre_provisioning_interval_input, value)

    def get_pre_provisioning_interval_text(self):
        pre_prov_interval = self.driver.wait_for_clickable_element(self.enable_new_hire_pre_provisioning_interval_input)
        return pre_prov_interval.get_attribute('value')

    def enter_tenant_utc_offset(self, value):
        self.driver.send_element_keys(self.tenant_utc_offset_input, value)

    def check_tenant_utc_offset_invalid(self):
        tenant_utc_offset = self.driver.wait_for_clickable_element(self.tenant_utc_offset_input)
        classes = tenant_utc_offset.get_attribute('class')
        return 'x-form-invalid-field' in classes

    def check_pre_provisioning_interval_invalid(self):
        pre_prov_interval = self.driver.wait_for_clickable_element(self.enable_new_hire_pre_provisioning_interval_input)
        classes = pre_prov_interval.get_attribute('class')
        return 'x-form-invalid-field' in classes

    def check_report_query_timeout_invalid(self):
        query_timeout = self.driver.wait_for_clickable_element(self.report_query_timeout_input)
        classes = query_timeout.get_attribute('class')
        return 'x-form-invalid-field' in classes

    def is_distribution_add_button_enabled(self):
        add_button = self.driver.wait_for_visible_element(self.distribution_add_btn)
        classes = add_button.get_attribute('class')
        return 'x-disabled' not in classes

    def click_save_provisioning_source_btn(self):
        self.driver.click_element(self.save_provisioning_source_btn)
        # Sometimes we have to double click this button for some unknown reason
        try:
            self.driver.click_element(self.save_provisioning_source_btn)
        except Exception:
            pass
