from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select


class ProvisioningRulePage:
    def __init__(self, driver):
        self.driver = driver

        # region Source Tab
        self.rule_name = (By.NAME, 'Name')
        self.inactive_rule_label = (By.XPATH, '//label[text() = "Inactive"]')
        self.active_rule_label = (By.XPATH, '//label[text() = "Active"]')
        self.preview_rule_label = (By.XPATH, '//label[text() = "Preview"]')

        self.source_selection_rule = (By.NAME, 'RuleSelectionType')
        self.supervisory_organization_item = (By.XPATH, '//li[@data-text="Supervisory Organization"]')
        self.all_users_item = (By.XPATH, '//li[@data-text="All Users"]')
        self.supervisory_organization_add_btn = (By.XPATH, '//a[@buttontext="Add"]')
        self.org_dropdown = (By.NAME, 'Id')
        # endregion

        # region Target Tab
        self.target_drop_down = (By.XPATH, '//input[@testname="DirectoryServiceUuid"]')
        # endregion

        # region Attributes Tab
        self.load_sample_btn = (By.XPATH, '//a[@buttontext="Load Sample"]')
        # endregion

        # region Options Tab
        self.password_type_dropdown = (By.NAME, 'PasswordType')
        self.require_password_change_checkbox = (By.XPATH, '//input[@testname="ForcePasswordChange"]')
        self.static_password_input = (By.NAME, 'StaticPassword')
        self.show_password_icon = (By.CLASS_NAME, 'show-password')

        self.send_password_to_email_checkbox = (By.XPATH, '//input[@testname="SendNewUserPasswordToEmail"]')
        self.send_password_to_manager_checkbox = (By.XPATH, '//input[@testname="SendNewUserPasswordEmailToManager"]')
        self.send_password_to_personal_email_checkbox = (By.XPATH, '//input[@testname="SendNewUserPasswordEmailToUser"]')
        self.notify_email_input = (By.XPATH, '//input[@testname="NotifyEmail"]')
        self.map_group_checkbox = (By.XPATH, '//input[@testname="GroupMapEnabled"]')
        self.add_provisioning_group_map_btn = (By.XPATH, '//a[@itemid="addButton"]')
        # endregion

    def click_map_group_checkbox(self):
        self.driver.click_element(self.map_group_checkbox)

    def is_mapping_table_present(self):
        body = self.driver.find_element_by_tag_name('body')
        add_btn = body.find_element_by_xpath('//a[@itemid="addButton"]')
        return add_btn is not None

    def is_send_password_to_email_available(self):
        checkbox = self.driver.wait_for_visible_element(self.send_password_to_email_checkbox)
        return checkbox is not None

    def is_send_password_to_manager_available(self):
        checkbox = self.driver.wait_for_visible_element(self.send_password_to_manager_checkbox)
        return checkbox is not None

    def is_send_password_to_personal_email_available(self):
        checkbox = self.driver.wait_for_visible_element(self.send_password_to_personal_email_checkbox)
        return checkbox is not None

    def click_send_password_to_email(self):
        self.driver.click_element(self.send_password_to_email_checkbox)

    def check_notify_email_is_required(self):
        notify_email = self.driver.wait_for_visible_element(self.notify_email_input)
        return 'x-form-required-field' in notify_email.get_attribute('class')

    def enter_notify_email(self, email):
        self.driver.send_element_keys(self.notify_email_input, email)

    def is_invalid_email_alert_present(self):
        notify_email = self.driver.wait_for_visible_element(self.notify_email_input)
        error_id = notify_email.get_attribute('id').replace('inputEl', 'errorEl')

        error_alert = self.driver.wait_for_visible_element((By.ID, error_id))
        return error_alert is not None

    def is_inactive_rule(self):
        radio_label = self.driver.wait_for_clickable_element(self.inactive_rule_label)
        radio_id = radio_label.get_attribute('for').replace('-inputEl', '')
        radio = self.driver.wait_for_clickable_element((By.ID, radio_id))
        return 'x-form-cb-checked' in radio.get_attribute('class')

    def select_supervisory_org_source(self):
        self.driver.click_element(self.source_selection_rule)
        source_selection = self.driver.wait_for_visible_element(self.supervisory_organization_item)

        if source_selection is None:
            self.driver.click_element(self.source_selection_rule)

        self.driver.click_element(self.supervisory_organization_item)

    def select_all_users_source(self):
        self.driver.click_element(self.source_selection_rule)
        source_selection = self.driver.wait_for_visible_element(self.all_users_item)

        if source_selection is None:
            self.driver.click_element(self.source_selection_rule)

        self.driver.click_element(self.all_users_item)

    def select_target_from_dropdown(self, target):
        self.driver.click_element(self.target_drop_down)
        target_selection = self.driver.wait_for_visible_element((By.XPATH, '//li[@data-text="{}"]'.format(target)))

        if target_selection is None:
            self.driver.click_element(self.target_drop_down)

        self.driver.click_element((By.XPATH, '//li[@data-text="{}"]'.format(target)))

    def check_target_is_required(self):
        target_selection = self.driver.wait_for_visible_element(self.target_drop_down)
        return 'x-form-required-field' in target_selection.get_attribute('class')

    def check_domain_is_required(self):
        # TODO the target tab has two elements - domain & domain controller that have no identifiable attributes
        domain_drop_down = self.driver.wait_for_visible_element((By.XPATH, '//input[@testname="undefined"]'))
        return 'x-form-required-field' in domain_drop_down.get_attribute('class')

    def check_domain_controller_is_required(self):
        # TODO the target tab has two elements - domain & domain controller that have no identifiable attributes
        domain_controller_label = self.driver.wait_for_visible_element((By.XPATH, '//label[text() = "Domain Controller"]'))
        domain_controller_id = domain_controller_label.get_attribute('id').replace('labelEl', 'inputEl')

        domain_controller_dropdown = self.driver.wait_for_visible_element((By.ID, domain_controller_id))
        return 'x-form-required-field' in domain_controller_dropdown.get_attribute('class')

    def select_domain_controller_from_dropdown(self, domain_controller):
        # TODO the target tab has two elements - domain & domain controller that have no identifiable attributes
        domain_controller_label = self.driver.wait_for_visible_element(
            (By.XPATH, '//label[text() = "Domain Controller"]'))
        domain_controller_id = domain_controller_label.get_attribute('id').replace('labelEl', 'inputEl')

        domain_controller_dropdown = self.driver.wait_for_visible_element((By.ID, domain_controller_id))
        domain_controller_dropdown.click()

        domain_controller_selection = self.driver.wait_for_visible_element((By.XPATH, '//li[@data-text="{}"]'.format(domain_controller)))
        if domain_controller_selection is None:
            domain_controller_dropdown.click()

        self.driver.click_element((By.XPATH, '//li[@data-text="{}"]'.format(domain_controller)))

    def select_domain_from_dropdown(self, domain):
        # TODO the target tab has two elements - domain & domain controller that have no identifiable attributes
        domain_drop_down = self.driver.wait_for_visible_element((By.XPATH, '//input[@testname="undefined"]'))
        domain_drop_down.click()

        domain_selection = self.driver.wait_for_visible_element((By.XPATH, '//li[@data-text="{}"]'.format(domain)))

        if domain_selection is None:
            domain_drop_down.click()

        self.driver.click_element((By.XPATH, '//li[@data-text="{}"]'.format(domain)))

    def select_target_ou(self, target_ou):
        target_ou_tree_panel = self.driver.wait_for_visible_element((By.CLASS_NAME, 'plus-minus-tree'))
        target_item = target_ou_tree_panel.find_element_by_xpath('//span[text() = "{}"]'.format(target_ou))
        target_row = target_item.find_element_by_xpath('..')
        target_checkbox = target_row.find_element_by_tag_name('input')

        target_checkbox.click()

    def click_next_btn(self):
        toolbar = self.driver.find_element_by_tag_name('body')
        next_button = toolbar.find_element_by_xpath('//a[@buttontext="Next >"]')
        next_button.click()

    def click_add_source_btn(self):
        self.driver.click_element(self.supervisory_organization_add_btn)

    def select_supervisory_org(self, org):
        self.driver.click_element(self.org_dropdown)

        item = (By.XPATH, '//li[text() = "{}"]'.format(org))
        org_element = self.driver.wait_for_visible_element(item)

        if org_element is None:
            self.driver.click_element(self.org_dropdown)
        self.driver.click_element(item)

        parent_div = self.driver.fetch_element(self.org_dropdown).find_element_by_xpath('..')
        add_org_btn = parent_div.find_elements_by_xpath('//a[@buttontext="Add"]')
        add_org_btn[1].click()

    def validate_org_selections(self, orgs):
        found_orgs = []
        for _ in orgs:
            org = self.driver.wait_for_visible_element((By.XPATH, '//div[text() = "{}"]'.format(_)))
            if org is not None:
                found_orgs.append(org)
        return found_orgs

    def enter_rule_name(self, name):
        self.driver.send_element_keys(self.rule_name, name)

    def get_is_field_required(self,field):
        body = self.driver.find_element_by_tag_name('body')
        common_name_element = body.find_element_by_xpath(
            '//div[text() = "{}"]'.format(field)
        )
        common_name_row = common_name_element.find_element_by_xpath("../..")
        is_required = common_name_row.find_element_by_tag_name('img')

        img = is_required.get_attribute('src')

        return 'checkmark' in img

    def click_load_sample_btn(self):
        self.driver.click_element(self.load_sample_btn)

    def get_sample_script_loaded(self):
        sample_line = self.driver.wait_for_visible_element(
            (
                By.XPATH,
                '//span[text() = "// This is a test script that shows scripting capabilities for attribute mapping"]'
            )
        )

        return sample_line is not None

    def set_invalid_attribute_mapping_script(self):
        code_mirror = self.driver.find_element_by_class_name('CodeMirror')
        self.driver.execute_script('arguments[0].CodeMirror.setValue("This is Invalid Code")', code_mirror)

    def clear_attribute_mapping_script(self):
        code_mirror = self.driver.find_element_by_class_name('CodeMirror')
        self.driver.execute_script('arguments[0].CodeMirror.setValue("")', code_mirror)

    def get_is_attribute_mapping_script_invalid(self):
        invalid_marker = self.driver.wait_for_visible_element((By.CLASS_NAME, 'CodeMirror-lint-marker-error'))

        return invalid_marker is not None

    def check_password_type_is_required(self):
        password_type = self.driver.wait_for_visible_element(self.password_type_dropdown)
        return 'x-form-required-field' in password_type.get_attribute('class')

    def get_require_password_change_is_checked(self):
        require_password_change = self.driver.wait_for_visible_element(self.require_password_change_checkbox)
        check_box_id = require_password_change.get_attribute('id').replace('-inputEl', '')
        return 'x-form-cb-checked' in self.driver.wait_for_visible_element((By.ID, check_box_id)).get_attribute('class')

    def select_password_type_from_dropdown(self, type):
        self.driver.click_element(self.password_type_dropdown)
        type_selection = self.driver.wait_for_visible_element((By.XPATH, '//li[@data-text="{}"]'.format(type)))

        if type_selection is None:
            self.driver.click_element(self.password_type_dropdown)

        self.driver.click_element((By.XPATH, '//li[@data-text="{}"]'.format(type)))

    def enter_static_password(self, password):
        self.driver.send_element_keys(self.static_password_input, password)

    def get_password_mask_attribute(self):
        password = self.driver.wait_for_clickable_element(self.static_password_input)
        return password.get_attribute('type')

    def click_show_password(self):
        self.driver.click_element(self.show_password_icon)
