from selenium.webdriver.common.by import By


class SignInPage:
    def __init__(self, driver):
        self.user_name_input = (By.NAME, 'username')
        self.password_input = (By.CSS_SELECTOR, '#passwordForm>div.form-field-container>div>input[type="password"]')
        self.user_next_button = (By.CSS_SELECTOR, '#usernameForm>div.button-wrapper>button')
        self.password_next_button = (By.CSS_SELECTOR, '#passwordForm > div.button-wrapper > button')
        self.driver = driver

    def login(self, user_name, password):
        ele = self.driver.wait_for_clickable_element(self.user_next_button)

        self.driver.send_element_keys(self.user_name_input, user_name)
        self.driver.click_element(self.user_next_button)

        self.driver.send_element_keys(self.password_input, password)
        self.driver.click_element(self.password_next_button)
