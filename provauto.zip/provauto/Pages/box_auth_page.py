from selenium.webdriver.common.by import By


class BoxAuthPage:
    def __init__(self, driver):
        self.login_input = (By.ID, 'login')
        self.password_input = (By.ID, 'password')
        self.authorize_btn = (By.NAME, 'login_submit')
        self.grant_access_btn = (By.ID, 'consent_accept_button')

        self.authorization_sucess_div = (By.XPATH, '//div[text() = "Authorization Success"]')

        self.driver = driver

    def authorize_box(self, username, password):
        self.driver.send_element_keys(self.login_input, username)
        self.driver.send_element_keys(self.password_input, password)

        self.driver.click_element(self.authorize_btn)
        self.driver.click_element(self.grant_access_btn)

        assert self.driver.wait_for_visible_element(self.authorization_sucess_div) is not None
