import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from Pages.add_web_apps_page import AddWebAppsPage


class WebAppsPage:
    def __init__(self, driver):
        self.driver = driver
        self.web_apps_window = (By.XPATH, '//div[@viewparttitle="Web Apps"]')
        self.search_apps_input = (By.NAME, 'search-field-input')
        self.search_apps_btn = (By.CLASS_NAME, 'search-button')
        self.add_web_apps_btn = (By.XPATH, '//a[@buttontext="Add Web Apps"]')
        self.modal = (By.CLASS_NAME, 'modal-window')

        self.add_web_apps_page = AddWebAppsPage(self.driver)

        self.loaded_element = self.web_apps_window

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def delete_web_app(self, app):
        app_row = self.driver.wait_for_visible_element((By.XPATH, '//div[text()="{}"]'.format(app)))
        ActionChains(self.driver).context_click(app_row).perform()
        self.driver.click_element((By.XPATH, '//span[text() = "Delete"]'))
        modal = self.driver.wait_for_visible_element(self.modal)
        modal.send_keys(Keys.ENTER)

    def parse_apps_table(self):
        # TODO This is why id's are important - if for some reason the devs add a second "basicGrid" to this page then
        #  the test will break

        basic_grid = self.driver.find_elements_by_xpath("//*[contains(@id, 'basicGrid')]")
        web_app_rows = []

        time.sleep(1)

        for grid in basic_grid:
            if grid.is_displayed() and 'body' in grid.get_attribute('id'):
                table = grid.find_element_by_tag_name('table')
                web_app_rows = table.find_elements_by_tag_name('tr')

        app_list = []
        for row in web_app_rows:
            columns = row.find_elements_by_tag_name('td')
            app = {
                'Name': columns[2].text,
                'Type': columns[3].text,
                'Description': columns[4].text,
                'Provisioning': columns[5].text,
                'Status': columns[7].text
            }
            app_list.append(app)

        return app_list

    def select_web_app(self, web_app):
        app_item = self.driver.wait_for_visible_element((By.XPATH, f'//div[text() = "{web_app}"]'))
        app_item.click()

    def click_add_web_apps_btn(self):
        self.driver.click_element(self.add_web_apps_btn)

    def refresh_page(self):
        self.driver.refresh()
