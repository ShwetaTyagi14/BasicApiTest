from selenium.webdriver.common.by import By


class UserPortalPage:
    def __init__(self, driver):
        self.profile_button = (By.XPATH, '//a[@itemid="toolDrop"]')
        self.switch_to_admin_portal_item = (By.XPATH, '//span[text() = "Switch to Admin Portal"]')
        self.loaded_element = self.profile_button
        self.driver = driver

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def switch_to_admin_portal(self):
        self.driver.click_element(self.profile_button)
        self.driver.click_element(self.switch_to_admin_portal_item)
