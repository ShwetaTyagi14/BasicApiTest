import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


class OutboundProvisioningPage:
    def __init__(self, driver):
        self.loaded_element = (By.XPATH, '//div[@viewparttitle="Outbound Provisioning"]')
        self.save_btn = (By.XPATH, '//a[@buttontext="Save"]')
        self.enable_daily_sync_chkbox = (By.XPATH, '//input[@testname="DailySync"]')
        self.sync_info_icon = (By.XPATH, '//div[text()="I"]')
        self.sync_info_tooltip = (By.XPATH, '//div[text()="Synchronization starts within the time range specified"]')
        self.daily_sync_start_time_dropdown = (By.XPATH, '//input[@testname="DailySyncHour"]')
        self.modal = (By.CLASS_NAME, 'modal-window')
        self.job_history_link = (By.XPATH, '//a[text()="View Synchronization Job Status and Reports"]')

        self.driver = driver

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def is_daily_sync_enabled(self):
        check_box_id = self.driver.wait_for_visible_element(
            self.enable_daily_sync_chkbox
        ).get_attribute('id').replace('-inputEl', '')

        return 'x-form-cb-checked' in self.driver.wait_for_visible_element((By.ID, check_box_id)).get_attribute('class')

    def click_enable_daily_sync_chkbox(self):
        self.driver.click_element(self.enable_daily_sync_chkbox)

    def check_daily_sync_tooltip(self):
        self.driver.hover_element(self.driver.wait_for_visible_element(self.sync_info_icon))
        tooltip_id = self.driver.wait_for_visible_element(
            self.sync_info_icon
        ).get_attribute('id').replace('-innterCt', '')

        return 'x-hide-offsets' not in self.driver.wait_for_visible_element((By.ID, tooltip_id)).get_attribute('class')

    def click_daily_sync_start_time_dropdown(self):
        self.driver.click_element(self.daily_sync_start_time_dropdown)
        li = self.driver.wait_for_visible_element((By.XPATH, '//li[contains(text(), "00:00 - 01:00")]'))

        return li.is_displayed()

    def click_save_btn(self):
        self.driver.click_element(self.save_btn)

    def is_warning_modal_visible(self):
        modal = self.driver.wait_for_visible_element(self.modal)
        return modal.find_element_by_xpath('//div[text() = "Warning"]').is_displayed()

    def close_warning_modal(self):
        modal = self.driver.wait_for_visible_element(self.modal)
        modal.find_element_by_xpath('//a[@buttontext="Close"]').click()

    def click_job_history_link(self):
        self.driver.click_element(self.job_history_link)
        job_history_window = self.driver.window_handles[1]
        self.driver.switch_to_window(job_history_window)

