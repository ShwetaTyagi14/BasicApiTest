from selenium.webdriver.common.by import By


class AdminPortalPage:
    def __init__(self, driver):
        self.dashboard_row = (By.ID, 'nav-part-Dashboards-Dashboards')
        self.settings_item = (By.XPATH, '//span[text() = "Settings"]')
        self.settings_user_item = (By.ID, 'nav-part-UserSettings-Users')
        self.user_menu = (By.XPATH, '//*[@id="nav-part-UserSettings-Users"]/td/div/a')
        self.apps_menu = (By.XPATH, '//span[text() = "Apps"]')
        self.top_user_menu = (By.XPATH, '//*[@id="nav-part-UserList-Users"]/td/div/a')
        self.core_services_root = (By.XPATH, '//*[@id="nav-part-Core-Services"]')
        self.welcome_wizard = (By.CLASS_NAME, 'idaptive-welcome-wizard')
        self.inbound_provisioning_item = (By.XPATH, '//span[text() = "Inbound Provisioning"]')
        self.outbound_provisioning_item = (By.XPATH, '//span[text() = "Outbound Provisioning"]')
        self.web_apps_item = (By.LINK_TEXT, 'Web Apps')
        self.loading_dialog = (By.ID, 'ext-gen1303')
        self.loaded_element = self.dashboard_row
        self.driver = driver

    def is_page_loaded(self):
        try:
            welcome_modal = self.driver.wait_for_visible_element(self.welcome_wizard)
            welcome_modal.find_element_by_class_name('close-btn').click()
        except():
            log_message = 'Wizard Modal Not Found'
        finally:
            return self.driver.page_loaded(self.loaded_element)

    def select_inbound_provisioning(self):
        self.driver.wait_for_invisible_element(self.loading_dialog)
        if self.driver.wait_for_visible_element(self.settings_user_item) is None:
            self.driver.click_element(self.settings_item)

        self.driver.wait_for_invisible_element(self.loading_dialog)
        self.driver.click_element(self.user_menu)

        self.driver.click_element(self.inbound_provisioning_item)

    def select_outbound_provisioning(self):
        self.driver.wait_for_invisible_element(self.loading_dialog)
        if self.driver.wait_for_visible_element(self.settings_user_item) is None:
            self.driver.click_element(self.settings_item)

        self.driver.wait_for_invisible_element(self.loading_dialog)
        self.driver.click_element(self.user_menu)

        self.driver.click_element(self.outbound_provisioning_item)

    def select_web_apps(self):
        self.driver.wait_for_invisible_element(self.loading_dialog)

        if self.driver.wait_for_visible_element(self.web_apps_item) is None:
            self.driver.click_element(self.apps_menu)

        self.driver.wait_for_invisible_element(self.loading_dialog)
        self.driver.click_element(self.web_apps_item)
