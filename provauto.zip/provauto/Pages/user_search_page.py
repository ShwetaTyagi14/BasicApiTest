import time

from selenium.webdriver.common.by import By


class UserSearchPage:
    def __init__(self, driver):
        self.select_user_dialog = (By.XPATH, '//div[@viewparttitle="Select User"]')
        self.name_input = (By.NAME, "search-field-input")
        self.next_btn = (By.XPATH, '//a[@buttontext="Next"]')

        self.driver = driver

    def input_user_name(self, name):
        container = self.driver.wait_for_visible_element(self.select_user_dialog)
        element = container.find_element_by_name("search-field-input")
        element.send_keys(name)

    def select_user(self, name):
        container = self.driver.wait_for_visible_element(self.select_user_dialog)
        # TODO Need to switch this to not be a hard wait but need to figure it out
        time.sleep(2)
        element = container.find_element_by_xpath(f'//div[contains(text(), "{name}")]')
        element.click()

    def click_next_button(self):
        self.driver.click_element(self.next_btn)
