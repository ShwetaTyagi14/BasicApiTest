import time

from selenium.webdriver.common.by import By


class JobHistoryPage:
    def __init__(self, driver):
        # Samples:
        # self.loaded_element = (By.XPATH, '//div[@viewparttitle="Outbound Provisioning"]')
        # self.save_btn = (By.XPATH, '//a[@buttontext="Save"]')
        # self.enable_daily_sync_chkbox = (By.XPATH, '//input[@testname="DailySync"]')
        # self.sync_info_icon = (By.XPATH, '//div[text()="I"]')
        # self.sync_info_tooltip = (By.XPATH, '//div[text()="Synchronization starts within the time range specified"]')
        # self.daily_sync_start_time_dropdown = (By.XPATH, '//input[@testname="DailySyncHour"]')
        # self.modal = (By.CLASS_NAME, 'modal-window')
        # self.job_history_link = (By.XPATH, '//a[text()="View Synchronization Job Status and Reports"]')

        self.loaded_element = (By.XPATH, '//span[@id="nav-part-SchedulerJobs-Job-History-btnIconEl"]')
        self.filter_combobox = (By.XPATH, '//input[@value="All Jobs"]')
        self.search_button = (By.XPATH, '//span[contains(@class,"x-btn-wrap]')
        self.search_input = (By.XPATH, '//input[@name="search-field-input"]')
        self.driver = driver

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def check_default_filter(self):
        return self.driver.wait_for_visible_element(self.filter_combobox)

    def select_filter(self, filter_name, current_filter):
        time.sleep(5)
        self.driver.click_element((By.XPATH, f"//input[@value='{current_filter}']"))
        self.driver.click_element((By.XPATH, f"//li[@data-text='{filter_name}']"))

    def check_table_for_full_text(self, expected_value):
        element = self.driver.wait_for_visible_element((By.XPATH, f"//div[text()='{expected_value}']"))
        return element

    def perform_search(self, search_value):
        time.sleep(5)
        self.driver.wait_for_clickable_element(self.search_input)
        self.driver.send_element_keys(self.search_input, search_value)
        element = self.driver.find_element(By.XPATH, '//input[@name="search-field-input"]')
        element.send_keys(u'\ue007')

    def validate_search(self, search_value, valid=True):
        if valid:
            element = self.check_table_for_full_text(search_value)
        else:
            element = self.driver.wait_for_visible_element((By.XPATH, "//div[text()='No results were found for: ']"))

        return element
