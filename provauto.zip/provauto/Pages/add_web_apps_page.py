import time

from selenium.webdriver.common.by import By


class AddWebAppsPage:
    def __init__(self, driver):
        self.driver = driver
        self.custom_tab = (By.XPATH, '//span[text()="Custom"]')
        self.add_yes_btn = (By.XPATH, '//a[@buttontext="Yes"]')
        self.close_btn = (By.XPATH, '//a[@buttontext="Close"]')

        self.saml_app_icon = (By.XPATH, '//span[@tip-text="This template enables you to provide single sign-on to a web application that uses SAML (Security Assertion Markup Language) for authentication."]')

    def click_custom_tab(self):
        self.driver.click_element(self.custom_tab)

    def add_saml_app(self):
        saml_element = self.driver.fetch_element(self.saml_app_icon)
        div_parent = saml_element.find_element_by_xpath('..').find_element_by_xpath('..')
        div_parent.find_element_by_link_text('Add').click()

        self.driver.click_element(self.add_yes_btn)
        self.driver.click_element(self.close_btn)

    def add_featured_app(self, web_app):
        app = (By.XPATH, f'//span[@title="{web_app}"]')
        app_element = self.driver.fetch_element(app)
        div_parent = app_element.find_element_by_xpath('..').find_element_by_xpath('..')
        div_parent.find_element_by_link_text('Add').click()

        self.driver.click_element(self.add_yes_btn)
        self.driver.click_element(self.close_btn)
