import time

from selenium.webdriver.common.by import By


class WebAppProvDetailPage:
    def __init__(self, driver):
        self.learn_more_link = self.add_web_apps_btn = (By.XPATH, '//a[@buttontext="Learn more"]')
        self.script_tag = (By.XPATH, '//div[text()="Provisioning Script"]')
        self.script_test_btn = (By.XPATH, '//a[@buttontext="Test"]')
        self.provisioning_item = (By.XPATH, '//span[text()="Provisioning"]')
        self.account_mapping_item = (By.XPATH, '//span[text()="Account Mapping"]')
        self.app_menu = (By.XPATH, '//div[@viewparttitle="TabbedFormTabTree"]')
        self.role_add_btn = (By.XPATH, '//a[@itemid="addButton"]')
        self.enable_chk_box = (By.XPATH, '//input[@testname="enabled"]')
        self.scim_prov_yes_btn = (By.XPATH, '//a[@itemid="yes"]')
        self.warning_modal = (By.XPATH, '//*[contains(@id, "warningwindow")]')
        self.error_modal = (By.XPATH, '//*[contains(@id, "errorwindow")]')
        self.warning_modal_close_btn = (By.XPATH, '//a[@buttontext="Close"]')
        self.save_btn = (By.XPATH, '//a[@itemid="saveChanges"]')
        self.scim_url_input = (By.NAME, 'Url')
        self.scim_auth_token_input = (By.NAME, 'AuthToken')
        self.verify_btn = (By.XPATH, '//a[@itemid="Verify"]')
        self.provisioning_cancel_btn = (By.XPATH, '//a[@buttontext="Cancel"]')
        self.app_not_available_label = (By.XPATH, '//label[text()="User account mapping for this app is not available when provisioning is enabled."]')
        self.test_results_dialog = (By.XPATH, '//div[@viewparttitle="Test Results"]')
        self.authorize_btn = (By.XPATH, '//a[@buttontext="Authorize"]')

        # region Role Mapping Dialog
        self.role_mapping_dialog = (By.XPATH, '//div[@viewparttitle="Role Mapping"]')
        self.done_btn = (By.XPATH, '//a[@buttontext="Done"]')
        self.role_name_dropdown = (By.NAME, 'RoleName')
        # endregion

        self.loaded_element = self.learn_more_link
        self.driver = driver
        # TODO Need to somehow adjust this so that it's not tied to a dynamic id
        self.loading_dialog = (By.ID, 'ext-gen1303')

    def is_page_loaded(self):
        return self.driver.page_loaded(self.loaded_element)

    def click_learn_more_link(self):
        self.driver.wait_for_visible_element(self.loading_dialog)
        self.driver.wait_for_invisible_element(self.loading_dialog)

        self.driver.click_element(self.learn_more_link)
        self.driver.wait_for_new_window()
        self.driver.switch_to_window_by_title('cs-Settings')

    def click_script_tag(self):
        self.driver.wait_for_visible_element(self.loading_dialog)
        self.driver.wait_for_invisible_element(self.loading_dialog)

        self.driver.click_element(self.script_tag)

    def input_script_text(self, text):
        code_mirror = self.driver.find_element_by_class_name('CodeMirror')
        self.driver.execute_script(f'arguments[0].CodeMirror.setValue("{text}")', code_mirror)

    def click_script_test_button(self):
        self.driver.click_element(self.script_test_btn)

    def click_provisioning_item(self):
        self.driver.wait_for_visible_element(self.loading_dialog)
        self.driver.wait_for_invisible_element(self.loading_dialog)

        menu = self.driver.fetch_element(self.app_menu)
        prov_items = menu.find_elements_by_xpath('//span[text()="Provisioning"]')

        # TODO: Not in love with this but only way without automation ids
        for item in prov_items:
            if item.is_displayed() is True:
                item.click()

    def click_settings_item(self):
        self.driver.wait_for_visible_element(self.loading_dialog)
        self.driver.wait_for_invisible_element(self.loading_dialog)

        menu = self.driver.fetch_element(self.app_menu)
        settings_items = menu.find_elements_by_xpath('//span[text()="Settings"]')

        # TODO: Not in love with this but only way without automation ids
        for item in settings_items:
            if item.is_displayed() is True:
                item.click()

    def is_provisioning_script_open(self):
        return self.driver.wait_for_visible_element((By.CLASS_NAME, 'CodeMirror')).is_displayed()

    def close_how_to_window(self):
        if self.driver.title == 'cs-Settings':
            self.driver.close()
            self.driver.switch_to_window_by_title('Admin Portal')
            return True
        return False

    def click_add_role_btn(self):
        self.driver.click_element(self.role_add_btn)

    def is_add_role_btn_visible(self):
        return self.driver.fetch_element(self.role_add_btn).is_displayed()

    def click_done_button(self):
        self.driver.click_element(self.done_btn)

    def click_role_name_dropdown(self):
        ele = self.driver.wait_for_visible_element(self.role_name_dropdown)
        parent_row = ele.find_element_by_xpath('../..')
        drop_arrow = parent_row.find_element_by_class_name('x-form-arrow-trigger')
        drop_arrow.click()

    def validate_role_name_available(self, name):
        element = self.driver.wait_for_visible_element((By.XPATH, '//li[@data-text="{}"]'.format(name)))
        return element is not None

    def select_role_name(self, name):
        element = self.driver.wait_for_visible_element((By.XPATH, '//li[@data-text="{}"]'.format(name)))
        element.click()

    def click_cancel_button(self):
        role_mapping_dialog = self.driver.wait_for_visible_element(self.role_mapping_dialog)
        cancel_btn = role_mapping_dialog.find_elements_by_xpath('//a[@buttontext="Cancel"]')
        cancel_btn[1].click()

    def click_enable_checkbox(self):
        self.driver.wait_for_visible_element(self.loading_dialog)
        self.driver.wait_for_invisible_element(self.loading_dialog)
        self.driver.click_element(self.enable_chk_box)

        try:
            self.driver.click_element(self.scim_prov_yes_btn)
        except:
            return

    def click_acocunt_mapping_item(self):
        self.driver.wait_for_visible_element(self.loading_dialog)
        self.driver.wait_for_invisible_element(self.loading_dialog)

        self.driver.click_element(self.account_mapping_item)

    def is_warning_modal_displayed(self):
        try:
            return self.driver.wait_for_visible_element(self.warning_modal).is_displayed()
        except:
            return False

    def close_warning_modal(self):
        self.driver.click_element(self.warning_modal_close_btn)

    def is_error_modal_displayed(self):
        try:
            return self.driver.wait_for_visible_element(self.error_modal).is_displayed()
        except:
            return False

    def close_error_modal(self):
        self.driver.click_element(self.warning_modal_close_btn)

    def click_save_button(self):
        self.driver.click_element(self.save_btn)

    def input_scim_service_url(self, url):
        self.driver.send_element_keys(self.scim_url_input, url)

    def input_scim_auth_token(self, token):
        self.driver.send_element_keys(self.scim_auth_token_input, token)

    def click_verify_button(self):
        self.driver.click_element(self.verify_btn)

    def get_scim_service_url(self):
        return self.driver.fetch_element(self.scim_url_input).get_attribute('value')

    def get_scim_auth_token(self):
        return self.driver.fetch_element(self.scim_auth_token_input).get_attribute('value')

    def click_provisioning_cancel_btn(self):
        self.driver.click_element(self.provisioning_cancel_btn)
        self.driver.click_element((By.XPATH, '//a[@itemid="discard"]'))

    def is_app_not_available_label_displayed(self):
        return self.driver.fetch_element(self.app_not_available_label).is_displayed()

    def validate_test_result(self, value):
        container = self.driver.wait_for_visible_element(self.test_results_dialog)
        element = container.find_element_by_xpath(f'//textarea[contains(text(), "{value}")]')
        return element is not None

    def click_authorize_btn(self):
        self.driver.click_element(self.authorize_btn)
