import uuid

from Steps.data_steps import DataSteps
from idaptive_automation.api_payloads import CloudUser


class CloudSetupWorker:
    def __init__(self, session, helpers_fixture):
        self.api_client = session["api_session"]
        self.user_helper = helpers_fixture["user_helper"]
        self.role_helper = helpers_fixture["role_helper"]
        self.app_helper = helpers_fixture["app_helper"]
        self.redrock_helper = helpers_fixture["redrock_helper"]
        self.cdirectory_helper = helpers_fixture["cdirectory_helper"]
        self.user_prov_helper = helpers_fixture["user_prov_helper"]
        self.data_steps = DataSteps(session['mongo_cred'])
        self.dc_info = session['dc_info']

    def create_unique_role(self):
        uuid_name = str(uuid.uuid4())
        role = dict(role_name=uuid_name, role_id=self.role_helper.create_role(uuid_name))
        return role

    def create_unique_user(self, new_username=None):
        if new_username is None:
            username = str(uuid.uuid4())[0:8]
        else:
            username = new_username
        user = CloudUser(
            self.dc_info['default_login_suffix'],
            username
        )
        user.email = f"{username}@{self.dc_info['default_email_suffix']}"
        user.display_name = user.name
        return dict(user=user, user_id=self.user_helper.create_cloud_user(user.to_payload()).response['Result'])

    def create_service_user(self, new_username=None):
        if new_username is None:
            username = str(uuid.uuid4())[0:8]
        else:
            username = new_username
        user = CloudUser(
            self.dc_info['default_login_suffix'],
            username
        )
        user.email = f"{username}@{self.dc_info['default_email_suffix']}"
        user.display_name = user.name
        user.in_everybody = False
        user.oauth_client = True
        user.pwd_never_expire = True
        return dict(user=user, user_id=self.user_helper.create_cloud_user(user.to_payload()).response['Result'])

    def add_user_to_role(self, role_id, user_id):
        self.role_helper.add_users_to_role(role_id, [user_id])

    def add_child_role_to_parent_role(self, parent_role_id, child_role_id):
        self.role_helper.add_child_role_to_role(parent_role_id, [child_role_id])

    def remove_user_from_role(self, role_id, user_id):
        self.role_helper.remove_users_from_role(role_id, [user_id])

    def remove_group_from_role(self, role_id, group_id):
        self.role_helper.remove_groups_from_role(role_id, [group_id])

    def add_ad_groups_to_role(self, role_id, groups):
        group_list = []
        for group in groups:
            if group.groupType != 2:
                group_list.append(group['objectGUID'].value.replace('{', '').replace('}', ''))
        self.role_helper.add_groups_to_role(role_id, group_list)

    def import_oauth_server_application(self, role_name=None,):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': 'OAuthServer'})
        app_key = self.app_helper.import_app_by_name(app_data['importName'])

        app_data['updateApplicationDE']['_RowKey'] = app_key
        app_data['updateApplicationDE']['Name'] = 'OAuth2Test'
        app_data['updateApplicationDE']['ServiceName'] = 'OAuth2Test'
        self.app_helper.update_application_de(app_data['updateApplicationDE'])
        return app_key

    def import_application(self, app, setup_provisioning=False, role_name=None, preview_mode=False, update_app=True):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_key = self.app_helper.import_app_by_name(app_data['importName'])
        if update_app:
            self.update_app(app, app_key, setup_provisioning, role_name, preview_mode)
        return app_key

    def import_application_check_response(self, app, validate_response):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        response = self.app_helper.import_app_by_name(app_data['importName'], False)
        assert validate_response in response.response['Message']

    def delete_application(self, app_key):
        self.app_helper.delete_application(app_key)

    def update_app(self, app, app_key, setup_provisioning=False, role_name=None, preview_mode=False):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        update_payload = ""

        if app_data['updateApplicationDE'] is not None:
            app_data['updateApplicationDE']['_RowKey'] = app_key
            self.app_helper.update_application_de(app_data['updateApplicationDE'])
        if setup_provisioning:
            app_data['updateAppProvisioning']['appKey'] = app_key
            app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
            update_payload = app_data['updateAppProvisioning']
        else:
            app_data['updateApp']['appKey'] = app_key
            update_payload = app_data['updateApp']
        if preview_mode:
            update_payload['preview'] = True
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)
        return app_key

    def disable_app_provisioning(self, app, app_key, role_name):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['enabled'] = False
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)

    def map_all_not_required_attributes(self, app, app_key, role_name=None, default_attribute_value='null'):
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']

        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        mapping_script = app_data['updateAppProvisioning']['settings']['UserScript']
        # TODO Need to figure out what data types we can use - for example if it's a boolean we can't pass null
        for attribute in attributes:
            if not attribute['Required']:
                mapping_script = mapping_script + f"\ndestination.{attribute['Name']} = {default_attribute_value};"
        app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def update_app_check_response(self, app, app_key, validate_response):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateApp']['appKey'] = app_key
        update_payload = app_data['updateApp']

        response = self.user_prov_helper.update_app(update_payload, False)
        assert validate_response in response.response['Message']

    def saml_update_app(self, app_key, url, auth_token=None, direct_header=None, role=None, user_script=None):
        app_data = self.data_steps.query_db_collection(
            db='automation',
            collection='payload_templates',
            query={'name': 'SAMLUpdateApp'}
        )['payload']
        app_data['appKey'] = app_key
        app_data['creds']['Url'] = url
        if auth_token is not None:
            app_data['creds']['AuthToken'] = auth_token
        if direct_header is not None:
            app_data['creds']['AuthToken'] = direct_header
            app_data['creds']['HeaderSubType'] = 'Direct'
            app_data['creds']['mergeusers'] = False
        if role is not None:
            app_data.update({
                'settings': {
                    'RoleMappings': [
                        {
                            'RoleName': role,
                            'MappingType': 'Role'
                        }
                    ],
                    'UserScript': user_script,
                    'DirGroupSync': False
                }
            })
        self.user_prov_helper.update_app(app_data)
        self.user_prov_helper.get_app(app_key)

    def append_role_to_app(self, app, app_key, setup_provisioning=False, roles=None, preview_mode=False):
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        update_payload = ""

        if app_data['updateApplicationDE'] is not None:
            app_data['updateApplicationDE']['_RowKey'] = app_key
            self.app_helper.update_application_de(app_data['updateApplicationDE'])
        if setup_provisioning:
            app_data['updateAppProvisioning']['appKey'] = app_key
            app_data['updateAppProvisioning']['settings']['RoleMappings'] = []
            for role in roles:
                app_data['updateAppProvisioning']['settings']['RoleMappings'].append(
                    {
                        'RoleName': role['role_name'],
                        'DestinationRole': 'end-user',
                        'MappingType': 'Role'
                    }
                )
            update_payload = app_data['updateAppProvisioning']
        else:
            app_data['updateApp']['appKey'] = app_key
            update_payload = app_data['updateApp']
        if preview_mode:
            update_payload['preview'] = True
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)
        return app_key

    def remove_all_users(self):
        while self.user_helper.users_created.__len__() > 0:
            user = self.user_helper.users_created.pop()
            self.user_helper.delete_user(user)

    def get_user_details_from_email(self, user_name, email_suffix=None):
        email = f"{user_name}@{self.dc_info['default_email_suffix']}"
        payload = {
            'Script': f"SELECT   * \
                       FROM     ( \
                                    Select  ID, \
                                            DisplayName, \
                                            Email, \
                                            LastInvite, \
                                            LastLogin, \
                                            SourceDsLocalized, \
                                            SourceDsType, \
                                            Status, \
                                            StatusEnum, \
                                            Username, \
                                            ServiceUser, \
                                            UserType \
                                    from    User \
                                ) \
                        WHERE   (UserType = 'User' \
                                OR \
                                UserType IS NULL) \
                                AND Email ='{email}'",
            'Args': {
                'PageNumber': 1,
                'PageSize': 100,
                'Limit': 100000,
                'SortBy': 'Username',
                'Ascending': True,
                'Caching': -1
            }
        }
        query_result = self.redrock_helper.execute_redrock_query(payload).response
        return query_result['Result']['Results'][0]['Row']['ID']

    def refresh_user_token(self, user_id):
        self.cdirectory_helper.refresh_ad_user_token(user_id)

    def assign_role_super_rights(self, role_id, role_type):
        payload = self.data_steps.query_db_collection(
            collection='predefined_roles',
            query={'Name': role_type},
            db='automation'
        )['AdminRights']

        for role in payload:
            role['Role'] = role_id
        self.role_helper.assign_super_rights_to_role(payload)

    def validate_provisioning_changelog(self, app_key):
        payload = {
            'Script': f"select    ID,  \
                           whenoccurred as Date, \
                           EventType as Change, \
                           NormalizedUser as User   \
                from       event  \
                where      ( \
                               ( \
                                   +EventType='Cloud.Saas.Application.AppAdd'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppModify'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppDelete'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppPublish'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppUnpublish'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppClone'  \
                                   or  \
                                   EventType='Cloud.Saas.Application.AppProvModify' \
                               )  \
                               and WhenOccurred >= datefunc('now', -30) \
                               and ApplicationID = '{app_key}' \
                           )"
        }
        result = self.redrock_helper.execute_redrock_query(payload).response['Result']['Results']
        assert result.__len__() >= 2
        assert any(r['Row']['Change'] == 'Cloud.Saas.Application.AppProvModify' for r in result)
        assert any(r['Row']['Change'] == 'Cloud.Saas.Application.AppAdd' for r in result)

    def set_application_permissions(self, app_key, role_name):
        payload = {
          "Grants": [
            {
              "Principal": role_name,
              "PType": "Role",
              "Rights": "View,Execute,Automatic"
            }
          ],
          "ID": app_key,
          "RowKey": app_key,
          "PVID": app_key
        }
        self.app_helper.set_application_permissions(payload)

    def script_specific_attribute_mapping(self, app, app_key, role_name=None, destination_attribute=None,
                                          destination_attribute_value=None):
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        mapping_script = app_data['updateAppProvisioning']['settings']['UserScript']
        mapping_script = mapping_script + f'\ndestination.{destination_attribute} = "{destination_attribute_value}";'
        app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_mapping_attribute(self, app, app_key, role_name=None, role_attribute=None,
                                       role_attribute_value=None):
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0][role_attribute] = role_attribute_value;
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def get_user_attribute_value(self, user, attribute):
        for element in dir(user.get('user')):
            if attribute in element:
                attribute_value = str(getattr(user.get('user'), element))
                break
        return attribute_value

    def updating_role_mapping_attribute_for_salesforce(self, app, app_key, role_name=None,
                                                       user_licenseId_value=None,
                                                       profileid_value=None,
                                                       mappingtype_value=None):
        """" Update role mapping attribute for the Salesforce app """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['UserLicenseId'] = user_licenseId_value;
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['ProfileId'] = profileid_value;
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['MappingType'] = mappingtype_value;
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_mapping_attribute_for_citrix_sharefile(self, app, app_key, role_name=None,
                                                             license_value=None,
                                                             friendly_value=None):
        """" Update role mapping attribute for the CitrixShare app """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        # app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'] = None
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0]['Value']=license_value;
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0]['Friendly']=friendly_value;
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def append_role_to_app_for_citrix(self, app, app_key, setup_provisioning=False, roles=None, preview_mode=False,
                                      list_licences=None):
        """" Update the CitrixShare app with multiple role with same or different destination group """
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        update_payload = ""

        if app_data['updateApplicationDE'] is not None:
            app_data['updateApplicationDE']['_RowKey'] = app_key
            self.app_helper.update_application_de(app_data['updateApplicationDE'])
        if setup_provisioning:
            app_data['updateAppProvisioning']['appKey'] = app_key
            app_data['updateAppProvisioning']['settings']['RoleMappings'] = []
            destination_group = []
            for licence in list_licences:
                destination_group.append({"Value": licence,
                                          "Friendly": licence})
            for role in roles:
                app_data['updateAppProvisioning']['settings']['RoleMappings'].append(
                    {
                        'RoleName': role['role_name'],
                        'DestinationGroups': destination_group,
                        'MappingType': 'Role'
                    }
                )
            update_payload = app_data['updateAppProvisioning']
        else:
            app_data['updateApp']['appKey'] = app_key
            update_payload = app_data['updateApp']
        if preview_mode:
            update_payload['preview'] = True
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)
        return app_key

    def script_specific_integer_attribute_mapping(self, app, app_key, role_name=None, destination_attribute=None,
                                                  destination_attribute_value=None):
        """ Update the provisioning script attribute with integer value or boolean value """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        mapping_script = app_data['updateAppProvisioning']['settings']['UserScript']
        mapping_script = mapping_script + f'\ndestination.{destination_attribute} = {destination_attribute_value};'
        app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_with_no_destination_group(self, app, app_key, role_name=None):
        """ Update the CitrixShare app with no destination group """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'] = None
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_mapping_attribute_for_servicenow(self, app, app_key, role_name=None,
                                                       license_value=None,
                                                       friendly_value=None):
        """
             Update role mapping attribute for the servicenow app
             :param app : take specific app name
             :param app_key : take the app_key
             :param role_name : take take the role name
             :param license_value : take the value destination role
             :param friendly_value : take the value destination role
        """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0]['Value']=license_value;
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0]['Friendly']=friendly_value;
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_mapping_for_attribute_absorblms(self, app, app_key, role_name=None, learner_attribute_value=None,
                                                      instructor_attribute_value=None,
                                                      mapping_script=None, admin_attribute_value=None):
        """
             Update role mapping attribute for the servicenow app
             :param app : take specific app name
             :param app_key : take the app_key
             :param role_name : take the role name
             :param learner_attribute_value : take the learner value
             :param instructor_attribute_value : take the instructor value
             :param admin_attribute_value : take the admin value
             :param mapping_script : provisioning script
        """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['Learner'] = learner_attribute_value
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['Instructor'] = instructor_attribute_value
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['Admin'] = admin_attribute_value
        if mapping_script is not None:
            app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_mapping_group_attribute_for_netsuite(self, app, app_key, role_name=None,
                                                           groups_value=None):

        """" Update role mapping attribute for the NetSuite app
                            :param app : take specific app name
                            :param app_key : take the app_key
                            :param role_name : take the role name
                            :param groups_value : take the group value
        """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0] = groups_value
        mapping_script = app_data['updateAppProvisioning']['settings']['UserScript']
        app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def updating_role_mapping_multiple_attribute_for_netsuite(self, app, app_key, role_name=None,
                                                              groups_value=None, destination_attribute=None,
                                                              destination_attribute_value=None,
                                                              destination_attribute_2=None,
                                                              destination_attribute_val_2=None):

        """" Update role mapping attribute for the NetSuite app
                    :param app : take specific app name
                    :param app_key : take the app_key
                    :param role_name : take the role name
                    :param destination_attribute : take the attribute
                    :param destination_attribute_value : take the attribute value
                    :param destination_attribute_2 : take the second attribute
                    :param destination_attribute_val_2 : take the second attribute value
                    :param groups_value : take the destination group value
        """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0] = groups_value
        mapping_script = app_data['updateAppProvisioning']['settings']['UserScript']
        mapping_script = mapping_script + f'\ndestination.{destination_attribute} = "{destination_attribute_value}";'
        mapping_script = mapping_script + f'\ndestination.{destination_attribute_2} = {destination_attribute_val_2};'
        app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def append_role_to_app_for_netsuite(self, app, app_key, setup_provisioning=False, roles=None, preview_mode=False,
                                        destination_attribute='subsidiaryId', destination_attribute_value=1,
                                        destination_role=None):
        """" Update the Netsuite app with multiple role with same or different destination group
                   :param app : take specific app name
                   :param app_key : take the app_key
                   :param roles : take the roles
                   :param destination_attribute : take the attribute
                   :param destination_attribute_value : take the attribute value
                   :param destination_role : take the destination_role value
                   :param setup_provisioning : take the setup_provisioning value
                   :param preview_mode : to set the preview mode
        """
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        update_payload = ""

        if app_data['updateApplicationDE'] is not None:
            app_data['updateApplicationDE']['_RowKey'] = app_key
            self.app_helper.update_application_de(app_data['updateApplicationDE'])
        if setup_provisioning:
            app_data['updateAppProvisioning']['appKey'] = app_key
            app_data['updateAppProvisioning']['settings']['RoleMappings'] = []
            destination_group = []
            for group in destination_role:
                destination_group.append(group)
            for role in roles:
                app_data['updateAppProvisioning']['settings']['RoleMappings'].append(
                    {
                        'RoleName': role['role_name'],
                        'DestinationGroups': destination_group,
                        'MappingType': 'Role'
                    }
                )
            mapping_script = app_data['updateAppProvisioning']['settings']['UserScript']
            mapping_script = mapping_script + f'\ndestination.{destination_attribute} = "{destination_attribute_value}";'
            app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
            update_payload = app_data['updateAppProvisioning']
        else:
            app_data['updateApp']['appKey'] = app_key
            update_payload = app_data['updateApp']
        if preview_mode:
            update_payload['preview'] = True
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)
        return app_key

    def updating_role_mapping_for_webex(self, app, app_key, role_name=None, mapping_script=None):
        """
        Update role mapping attribute for the Webex app
        :param app : take specific app name
        :param app_key : take the app_key
        :param role_name : take the role name
        :param mapping_script : take the provisioning script

        """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        if mapping_script is not None:
            app_data['updateAppProvisioning']['settings']['UserScript'] = mapping_script
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)

    def get_all_directory_services_uuids(self):
        directory_services = self.user_helper.get_directory_services_info()
        ds_list = []
        for ds in directory_services:
            ds_list.append(ds['directoryServiceUuid'])
        return ds_list

    def change_directory_service_lookup(self, payload):
        return self.user_helper.change_lookup_order(payload)


    def append_role_to_app_for_aws_specific(self, app, app_key, setup_provisioning=False, roles=None,
                                            preview_mode=False,
                                            list_licences=None):
        """" Update the aws_specific app with multiple role and multiple destination group """
        """
                            Update role mapping attribute for the aws_specific app
                            :param app : take specific app name
                            :param app_key : take the app_key
                            :param roles : take the multiple role
                            :param list_licences : take the value from list of destination roles
        """
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        update_payload = ""

        if app_data['updateApplicationDE'] is not None:
            app_data['updateApplicationDE']['_RowKey'] = app_key
            self.app_helper.update_application_de(app_data['updateApplicationDE'])
        if setup_provisioning:
            app_data['updateAppProvisioning']['appKey'] = app_key
            app_data['updateAppProvisioning']['settings']['RoleMappings'] = []
            destination_group = []
            for licence in list_licences:
                destination_group.append({"Value": licence,
                                          "Friendly": licence})
            for role in roles:
                app_data['updateAppProvisioning']['settings']['RoleMappings'].append(
                    {
                        'RoleName': role['role_name'],
                        'DestinationGroups': destination_group,
                        'MappingType': 'Role'
                    }
                )
            update_payload = app_data['updateAppProvisioning']
        else:
            app_data['updateApp']['appKey'] = app_key
            update_payload = app_data['updateApp']
        if preview_mode:
            update_payload['preview'] = True
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)
        return app_key

    def updating_role_mapping_attribute_for_aws_specific(self, app, app_key, role_name=None,
                                                         group_value=None,
                                                         friendly_value=None):
        """" Update role mapping attribute for the aws_specific app """
        """
                     Update role mapping attribute for the aws_specific app
                     :param app : take specific app name
                     :param app_key : take the app_key
                     :param role_name : take take the role name
                     :param group_value : take the value destination role
                     :param friendly_value : take the value destination role
        """
        app_details = self.user_prov_helper.get_app(app_key)
        attributes = app_details['endpointData']['ObjectDescriptors']['Destination']['Fields']
        app_data = self.data_steps.query_db_collection('automation', 'provision_apps', {'name': app})
        app_data['updateAppProvisioning']['appKey'] = app_key
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0]['Value'] = group_value;
        app_data['updateAppProvisioning']['settings']['RoleMappings'][0]['DestinationGroups'][0]['Friendly'] = friendly_value;
        update_payload = app_data['updateAppProvisioning']
        self.user_prov_helper.update_app(update_payload)
        self.user_prov_helper.get_app(app_key)
