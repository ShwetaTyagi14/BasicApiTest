import csv
import datetime
import email
import os
import poplib
import time

from Helpers.DomainInfo import DomainInfo
from Steps.data_steps import DataSteps


class ProvisioningWorker:
    def __init__(self, session, helpers_fixture):
        self.provisioning_helper = helpers_fixture["provisioning_helper"]
        self.redrock_helper = helpers_fixture["redrock_helper"]
        self.user_helper = helpers_fixture["user_helper"]
        self.data_steps = DataSteps(session['mongo_cred'])
        self.dc_info = session['dc_info']

    def fire_app_sync_job(self, app_key, preview_mode=False, retry_count=40):
        job_payload = {
            'previewMode': preview_mode,
            'appid': app_key
        }
        job_id = self.provisioning_helper.sync_all(job_payload).response['Result']['JobId']
        job_result = None
        count = 0
        while job_result is None:
            count = count + 1
            job_result = self.provisioning_helper.get_job_result(job_id)
            if count == retry_count:
                break
            else:
                time.sleep(15)
        return job_result

    def fire_user_sync_job(self, user_id, retry_count=40):
        job_id = self.provisioning_helper.sync_user(user_id).response['Result']['JobId']
        job_result = None
        count = 0
        while job_result is None:
            count = count + 1
            job_result = self.provisioning_helper.get_job_result(job_id)
            if count == retry_count:
                break
            else:
                time.sleep(15)
        return job_result

    def fire_inbound_prov_sync(self, source_instance_id, sync_type, retry_count=40, wait_for_result=True):
        job_response = self.provisioning_helper.request_inbound_sync(source_instance_id, sync_type, wait_for_result)
        if wait_for_result:
            result = self.wait_for_provisioning_job(job_response.response['Result'])
            return result
        return job_response

    def wait_for_provisioning_job(self, job_id, retry_count=40):
        job_result = None
        count = 0
        while job_result is None:
            count = count + 1
            job_result = self.provisioning_helper.get_job_result(job_id)
            if count == retry_count:
                break
            else:
                time.sleep(15)
        if job_result is not None:
            return job_result
        else:
            return job_id

    def validate_user_sync_status(self, app_key, sync_status, retry_count=40):
        query_time = {
            'end_time': str(datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z",
            'start_time': str((datetime.datetime.utcnow() - datetime.timedelta(minutes=2)).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"
        }
        user_status_payload = {
            'Script': f"SELECT  LastSync, \
                                AppRowKey, \
                                DestUpn, \
                                SyncStatusCode \
                        FROM    UserProvisioningSync up \
                        WHERE   up.AppRowKey='{app_key}' \
                                AND up.SyncStatusCode in ({sync_status}) ",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": query_time['end_time'],
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": query_time['start_time'],
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }
        query_results = self.redrock_helper.execute_redrock_query(user_status_payload).response['Result']['Results']
        found_status = query_results.__len__()
        count = 0
        while found_status == 0:
            count = count + 1
            query_results = self.redrock_helper.execute_redrock_query(user_status_payload).response['Result']['Results']
            found_status = query_results.__len__()
            if count == retry_count:
                break
            time.sleep(15)
        assert found_status > 0
        return query_results

    def get_user_prov_events(self, app_name, sync_type_result, user_principal_name, retry_count=40):
        query_time = {
            'end_time': str((datetime.datetime.utcnow() + datetime.timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z",
            'start_time': str((datetime.datetime.utcnow() - datetime.timedelta(minutes=2)).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"
        }
        payload = {
            'Script': f"SELECT  WhenOccurred, \
                                AppName, \
                                DestUpn, \
                                SyncType, \
                                EventType, \
                                Event.SyncResult, \
                                JobUniqueId \
                        FROM    Event \
                        WHERE   Event.EventType = 'Cloud.Provisioning.UserAppSyncCompleted' \
                                AND Event.AppName = '{app_name}' \
                                AND Event.SyncResult = '{sync_type_result}' \
                                AND Event.DestUpn is '{user_principal_name}' \
                                AND Event.WhenOccurred > @startDate \
                                AND Event.WhenOccurred < @endDate",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": query_time['end_time'],
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": query_time['start_time'],
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }
        query_results = self.redrock_helper.execute_redrock_query(payload).response['Result']['Results']
        found_status = query_results.__len__()
        count = 0
        while found_status == 0:
            count = count + 1
            query_results = self.redrock_helper.execute_redrock_query(payload).response['Result']['Results']
            found_status = query_results.__len__()
            if count == retry_count:
                break
            time.sleep(15)
        assert found_status > 0
        return query_results

    def validate_user_deactivated(self, app_key):
        affected_users = 0
        count = 0
        query_time = {
            'end_time': str(datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z",
            'start_time': str((datetime.datetime.utcnow() - datetime.timedelta(minutes=2)).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"
        }
        user_status_payload = {
            'Script': f"SELECT  LastSync, \
                                            AppRowKey, \
                                            DestUpn, \
                                            SyncStatusCode \
                                    FROM    UserProvisioningSync up \
                                    WHERE   up.AppRowKey='{app_key}' \
                                            AND up.SyncStatusCode in ('Deactivated') ",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": query_time['end_time'],
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": query_time['start_time'],
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }
        while affected_users == 0:
            user_status_response = self.redrock_helper.execute_redrock_query(user_status_payload)
            try:
                count = count + 1
                affected_users = user_status_response.response['Result']['Results'].__len__()
            except AttributeError:
                affected_users = 0
            if count == 20:
                break
            if affected_users == 0:
                time.sleep(20)
        assert affected_users > 0

    def save_notification_settings(self):
        self.provisioning_helper.save_notification_settings()

    def reset_notification_settings(self):
        self.provisioning_helper.reset_notification_settings()

    def validate_job_report(self, job_id, validate_message, negative_check=False):
        response = self.provisioning_helper.get_job_report(job_id)
        report_url = response.response['Result']['reportUrl'].replace('/vfs/Traces/scheduler', '')
        zip_file = self.provisioning_helper.download_sync_job_report(report_url)
        report_contents = zip_file.open(zip_file.filelist[0]).read()

        if negative_check:
            assert validate_message.encode() not in report_contents
        else:
            assert validate_message.encode() in report_contents

    def validate_inbound_source_creds(self, source):
        source_data = self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})
        self.provisioning_helper.verify_source_creds(source_data['sourceCreds'])

    def wait_for_job_to_start_running(self, job_id, retry_count=20):
        job_details = self.provisioning_helper.get_single_job_history(job_id).response['Result']
        count = 0
        while job_details['JobStatus'] != 'Running':
            job_details = self.provisioning_helper.get_single_job_history(job_id).response['Result']
            count = count + 1
            if count == retry_count:
                return False
            else:
                time.sleep(5)
        return True

    def validate_job_status(self, job_id, status):
        job_details = self.provisioning_helper.get_single_job_history(job_id).response['Result']
        assert status == job_details['JobStatus']

    def create_inbound_source(self, source, name=None, enabled=True, email=False, email_list=None):
        source_payload = self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})['sourceCreds']
        source_payload['Name'] = name
        source_payload['IsInstanceEnabled'] = enabled
        if email is True:
            source_payload['EnableSyncNotificationEmails'] = True
            source_payload['SyncNotificationEmails'] = email_list
        return self.provisioning_helper.create_inbound_source(source_payload)

    def create_inbound_source_with_integrated_report(self, source, name, enabled=True):
        source_payload = self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})['customReportCreds']
        source_payload['Name'] = name
        source_payload['IsInstanceEnabled'] = enabled
        return self.provisioning_helper.create_inbound_source(source_payload)

    def remove_all_created_inbound_sources(self):
        self.provisioning_helper.delete_all_created_inbound_sources()

    def create_inbound_rule(self, source, source_name,
                            source_instance_id, rule_name, target_ou,
                            rule_state, static_password=None, script_block=None,
                            group_rule=False, group=None, generated_password_email=None):
        domain_info = DomainInfo()
        rule_template = self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})['ruleTemplate']
        directory_service_uuid = self.__get_directory_service_uuid()
        ou_tree_payload = self.__create_ou_tree_payload(directory_service_uuid)
        ou_tree = next(
            iter(
                self.user_helper.get_ou_tree_contents(ou_tree_payload, True).response['Result']
            ),
            None
        )
        domain_info.domain_name = ou_tree['Name']
        domain_info.domain_ou = ou_tree['DistinguishedName']
        domain_info.directory_descriptor = ou_tree['Name']
        domain_info.domain_guid = ou_tree['Uuid']
        domain_info.directory_service_uuid = directory_service_uuid
        ou_tree_payload = self.__create_ou_tree_payload(None, domain_info.domain_guid, False)
        self.user_helper.get_ou_tree_contents(ou_tree_payload, True)
        domain_controller_payload = self.__create_domain_controller_payload(directory_service_uuid, domain_info.domain_name)
        domain_info.domain_controller_host_name = next(
            iter(
                self.user_helper.get_domain_controllers_for_domain(domain_controller_payload).response['Result']
            )
        )['Name']
        domain_info.organizational_unit = f"OU={target_ou},DC={self.dc_info['domain_name']},DC={self.dc_info['domain_suffix']}"
        domain_info.organizational_unit_display_name = target_ou
        group_payload = None
        if group_rule:
            group_payload = self.__build_group_rule(group=group,
                                    directory_uuid=directory_service_uuid,
                                    forrest=f"{self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}")

        rule_template['InstanceId'] = source_instance_id
        rule_template['DirectoryServiceUuid'] = domain_info.directory_service_uuid
        rule_template['DirectoryDescriptor'] = domain_info.directory_descriptor
        rule_template['OrganizationalUnit'] = domain_info.organizational_unit
        rule_template['ActiveDirectoryRuleData']['OrganizationalUnit'] = domain_info.organizational_unit
        rule_template['ActiveDirectoryRuleData']['OrganizationUnitDisplayName'] = domain_info.organizational_unit_display_name
        rule_template['ActiveDirectoryRuleData']['DomainControllerHostName'] = domain_info.domain_controller_host_name
        rule_template['ActiveDirectoryRuleData']['DomainName'] = domain_info.domain_name
        rule_template['ActiveDirectoryRuleData']['DomainGuid'] = domain_info.domain_guid
        rule_template['RuleState'] = rule_state
        rule_template['SourceName'] = source_name
        rule_template['Name'] = rule_name
        if static_password is not None:
            rule_template['NewUserPasswordConfig']['StaticPassword'] = static_password
        if script_block is not None:
            rule_template['ActiveDirectoryRuleData']['ScriptBlock'] = script_block
        if group_payload is not None:
            rule_template['ActiveDirectoryRuleData']['Groups'].append(group_payload)
        if generated_password_email is not None:
            rule_template['NewUserPasswordConfig']['PasswordType'] = 'GeneratePassword'
            rule_template['NewUserPasswordConfig']['ForcePasswordChange'] = False
            rule_template['NewUserPasswordConfig']['NotifyEmailList'] = [generated_password_email]

        self.provisioning_helper.create_inbound_source_rule(rule_template)

    def get_inbound_test_user(self, source):
        return self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})['test_user']

    def ping_inbound(self):
        self.provisioning_helper.ping_inbound()

    def query_inbound_providers(self):
        return self.provisioning_helper.query_supported_providers()

    def set_administrative_account(self, user_name, user_id, password):
        return self.provisioning_helper.set_administrative_accounts(
            user_name=user_name,
            user_uuid=user_id,
            password=password,
            domains=f"{self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}"
        )

    def await_attribute_increment_update(self, user_principal_name, retry_count = 40):
        query_time = {
            'end_time': str(datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z",
            'start_time': str((datetime.datetime.utcnow() - datetime.timedelta(minutes=2)).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]) + "Z"
        }
        user_status_payload = {
            'Script': f"SELECT WhenOccurred, EventType, NormalizedUser \
                                FROM Event \
                                WHERE Event.EventType = 'Cloud.Core.DSEntityChange' \
                                AND Event.NormalizedUser is '{user_principal_name.lower()}' \
                                AND Event.WhenOccurred > @startDate \
                                AND Event.WhenOccurred < @endDate",
            'Args': {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                "Parameters": [
                    {
                        "Name": "endDate",
                        "Value": query_time['end_time'],
                        "Label": "endDate",
                        "Type": "date",
                        "ColumnType": 3
                    },
                    {
                        "Name": "startDate",
                        "Value": query_time['start_time'],
                        "Label": "startDate",
                        "Type": "date",
                        "ColumnType": 3
                    }
                ]
            }
        }
        query_results = self.redrock_helper.execute_redrock_query(user_status_payload).response['Result']['Results']
        found_status = query_results.__len__()
        count = 0
        while found_status == 0:
            count = count + 1
            query_results = self.redrock_helper.execute_redrock_query(user_status_payload).response['Result']['Results']
            found_status = query_results.__len__()
            if count == retry_count:
                break
            time.sleep(15)
        assert found_status > 0
        return query_results

    def __get_directory_service_uuid(self):
        directory_services = self.user_helper.get_directory_services_info()
        display_name = f"Active Directory: {self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}"
        return next(
            (
                directory_service for directory_service in directory_services
                if directory_service['DisplayName'] == display_name
            )
        )['directoryServiceUuid']

    @staticmethod
    def validate_email(validate_messages):
        content_found = 0
        SERVER = "pop.gmail.com"
        USER = "idaptiveprovisioning"
        PASSWORD = "testTEST1234"

        server = poplib.POP3_SSL(SERVER)
        server.user(USER)
        server.pass_(PASSWORD)

        resp, mails, octets = server.list()
        index = len(mails)
        resp, lines, octets = server.retr(index)

        message = email.message_from_bytes(b'\n'.join(lines))
        payload = message.get_payload(decode=True)

        for part in message.walk():
            message_part = part.get_payload(decode=True)
            if message_part is not None:
                for validation in validate_messages:
                    if str.encode(validation) in message_part:
                        content_found += 1

        assert content_found >= validate_messages.__len__()
        server.dele(index)
        server.quit()

    @staticmethod
    def download_generated_passwords():
        SERVER = "pop.gmail.com"
        USER = "idaptiveprovisioning"
        PASSWORD = "testTEST1234"

        server = poplib.POP3_SSL(SERVER)
        server.user(USER)
        server.pass_(PASSWORD)

        resp, mails, octets = server.list()
        index = len(mails)
        resp = server.retr(index)
        raw_message = resp[1]

        dir_path = os.path.dirname(os.path.realpath(__file__))
        strmessage = email.message_from_bytes(b'\n'.join(raw_message))
        users_sycd = []
        filename = ''

        for part in strmessage.walk():
            if part.get_content_maintype() == 'multipart':
                continue

            if part.get('Content-Disposition') is None:
                print("no content dispo")
                continue

            filename = part.get_filename()

            fp = open(os.path.join(dir_path, filename), 'wb')
            fp.write(part.get_payload(decode=1))
            fp.close()

        server.dele(index)
        server.quit()

        with open(os.path.join(dir_path, filename), newline='') as f:
            reader = csv.reader(f)
            next(reader)

            for row in reader:
                users_sycd.append(row)

        os.remove(os.path.join(dir_path, filename))
        return users_sycd

    @staticmethod
    def __create_ou_tree_payload(directory_service_id=None, _id=None, use_cache=False):
        return {
                "directoryServiceUuid": directory_service_id,
                "id": _id,
                "useCache": use_cache
        }

    @staticmethod
    def __create_domain_controller_payload(directory_service_uuid, domain_name):
        return {
            "directoryServiceUuid": directory_service_uuid,
            "domainName": domain_name,
            "useCache": False
        }

    @staticmethod
    def __build_group_rule(group, directory_uuid, forrest):
        return {
            "DirectoryServiceUuid": directory_uuid,
            "DisplayName": group.cn.value,
            "DistinguishedName": group.distinguishedName.value,
            "Forest": forrest,
            "Guid": group.objectGUID.value,
            "InternalName": group.objectGUID.value,
            "Name": f'{group.cn.value}@{forrest}',
            "ObjectType": "Group",
            "ServiceInstance": f'AdProxy_{forrest}',
            "ServiceInstanceLocalized": f'Active Directory ({forrest})',
            "ServiceType": "AdProxy",
            "SystemName": f'{group.cn.value}@{forrest}',
            "Type": "Group",
            "Type-generated-field": "/vfslow/lib/ui/../uibuild/compiled/centrify/production/resources/images/entities/group_icon_sml.png?_ver=1538194052"
        }

    def create_custom_inbound_rule(self, source, source_name,
                                   source_instance_id, rule_name, target_ou,
                                   rule_state, static_password=None, script_block=None,
                                   group_rule=False, group=None, generated_password_email=None,
                                   title=None, department=None,
                                   telephonenumber=None):
        domain_info = DomainInfo()
        rule_template = self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})['ruleTemplate']
        directory_service_uuid = self.__get_directory_service_uuid()
        ou_tree_payload = self.__create_ou_tree_payload(directory_service_uuid)
        ou_tree = next(
            iter(
                self.user_helper.get_ou_tree_contents(ou_tree_payload, True).response['Result']
            ),
            None
        )
        domain_info.domain_name = ou_tree['Name']
        domain_info.domain_ou = ou_tree['DistinguishedName']
        domain_info.directory_descriptor = ou_tree['Name']
        domain_info.domain_guid = ou_tree['Uuid']
        domain_info.directory_service_uuid = directory_service_uuid
        ou_tree_payload = self.__create_ou_tree_payload(None, domain_info.domain_guid, False)
        self.user_helper.get_ou_tree_contents(ou_tree_payload, True)
        domain_controller_payload = self.__create_domain_controller_payload(directory_service_uuid, domain_info.domain_name)
        domain_info.domain_controller_host_name = next(
            iter(
                self.user_helper.get_domain_controllers_for_domain(domain_controller_payload).response['Result']
            )
        )['Name']
        domain_info.organizational_unit = f"OU={target_ou},DC={self.dc_info['domain_name']},DC={self.dc_info['domain_suffix']}"
        domain_info.organizational_unit_display_name = target_ou
        group_payload = None
        if group_rule:
            group_payload = self.__build_group_rule(group=group,
                                                    directory_uuid=directory_service_uuid,
                                                    forrest=f"{self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}")

        rule_template['InstanceId'] = source_instance_id
        rule_template['DirectoryServiceUuid'] = domain_info.directory_service_uuid
        rule_template['DirectoryDescriptor'] = domain_info.directory_descriptor
        rule_template['OrganizationalUnit'] = domain_info.organizational_unit
        rule_template['ActiveDirectoryRuleData']['OrganizationalUnit'] = domain_info.organizational_unit
        rule_template['ActiveDirectoryRuleData']['OrganizationUnitDisplayName'] = domain_info.organizational_unit_display_name
        rule_template['ActiveDirectoryRuleData']['DomainControllerHostName'] = domain_info.domain_controller_host_name
        rule_template['ActiveDirectoryRuleData']['DomainName'] = domain_info.domain_name
        rule_template['ActiveDirectoryRuleData']['DomainGuid'] = domain_info.domain_guid
        rule_template['ActiveDirectoryRuleData']['TitleExpression'] = title
        rule_template['ActiveDirectoryRuleData']['DepartmentExpression'] = department
        rule_template['ActiveDirectoryRuleData']['TelephoneNumberExpression'] = telephonenumber
        rule_template['RuleState'] = rule_state
        rule_template['SourceName'] = source_name
        rule_template['Name'] = rule_name
        if static_password is not None:
            rule_template['NewUserPasswordConfig']['StaticPassword'] = static_password
        if script_block is not None:
            rule_template['ActiveDirectoryRuleData']['ScriptBlock'] = script_block
        if group_payload is not None:
            rule_template['ActiveDirectoryRuleData']['Groups'].append(group_payload)
        if generated_password_email is not None:
            rule_template['NewUserPasswordConfig']['PasswordType'] = 'GeneratePassword'
            rule_template['NewUserPasswordConfig']['ForcePasswordChange'] = True
            rule_template['NewUserPasswordConfig']['NotifyEmailList'] = [generated_password_email]

        self.provisioning_helper.create_inbound_source_rule(rule_template)

    def create_inbound_rule_with_manager_attribute(self, source, source_name,
                                                   source_instance_id, rule_name, target_ou,
                                                   rule_state, static_password=None, script_block=None,
                                                   group_rule=False, group=None, generated_password_email=None,
                                                   set_manager=False):
        domain_info = DomainInfo()
        rule_template = self.data_steps.query_db_collection('automation', 'provision_sources', {'name': source})[
            'ruleTemplate']
        directory_service_uuid = self.__get_directory_service_uuid()
        ou_tree_payload = self.__create_ou_tree_payload(directory_service_uuid)
        ou_tree = next(
            iter(
                self.user_helper.get_ou_tree_contents(ou_tree_payload, True).response['Result']
            ),
            None
        )
        domain_info.domain_name = ou_tree['Name']
        domain_info.domain_ou = ou_tree['DistinguishedName']
        domain_info.directory_descriptor = ou_tree['Name']
        domain_info.domain_guid = ou_tree['Uuid']
        domain_info.directory_service_uuid = directory_service_uuid
        ou_tree_payload = self.__create_ou_tree_payload(None, domain_info.domain_guid, False)
        self.user_helper.get_ou_tree_contents(ou_tree_payload, True)
        domain_controller_payload = self.__create_domain_controller_payload(directory_service_uuid,
                                                                            domain_info.domain_name)
        domain_info.domain_controller_host_name = next(
            iter(
                self.user_helper.get_domain_controllers_for_domain(domain_controller_payload).response['Result']
            )
        )['Name']
        domain_info.organizational_unit = f"OU={target_ou},DC={self.dc_info['domain_name']},DC={self.dc_info['domain_suffix']}"
        domain_info.organizational_unit_display_name = target_ou
        group_payload = None
        if group_rule:
            group_payload = self.__build_group_rule(group=group,
                                                    directory_uuid=directory_service_uuid,
                                                    forrest=f"{self.dc_info['domain_name']}.{self.dc_info['domain_suffix']}")

        rule_template['InstanceId'] = source_instance_id
        rule_template['DirectoryServiceUuid'] = domain_info.directory_service_uuid
        rule_template['DirectoryDescriptor'] = domain_info.directory_descriptor
        rule_template['OrganizationalUnit'] = domain_info.organizational_unit
        rule_template['ActiveDirectoryRuleData']['OrganizationalUnit'] = domain_info.organizational_unit
        rule_template['ActiveDirectoryRuleData'][
            'OrganizationUnitDisplayName'] = domain_info.organizational_unit_display_name
        rule_template['ActiveDirectoryRuleData']['DomainControllerHostName'] = domain_info.domain_controller_host_name
        rule_template['ActiveDirectoryRuleData']['DomainName'] = domain_info.domain_name
        rule_template['ActiveDirectoryRuleData']['DomainGuid'] = domain_info.domain_guid
        rule_template['RuleState'] = rule_state
        rule_template['SourceName'] = source_name
        rule_template['Name'] = rule_name
        rule_template['RuleSelectionType'] = 'SupervisoryOrg'
        rule_template['RuleSelectionValues'] = [
            {"Id": "e02485f863ec48d39a082bb95cc4abe4", "Name": "Human Resources"},
            {"Id": "9378b36dabd94cc391ef5392166aa00e", "Name": "ExecutiveManagement"}
        ]
        if static_password is not None:
            rule_template['NewUserPasswordConfig']['StaticPassword'] = static_password
        if script_block is not None:
            rule_template['ActiveDirectoryRuleData']['ScriptBlock'] = script_block
        if set_manager is not None:
            rule_template['ActiveDirectoryRuleData']['SetManager'] = set_manager
        if group_payload is not None:
            rule_template['ActiveDirectoryRuleData']['Groups'].append(group_payload)
        if generated_password_email is not None:
            rule_template['NewUserPasswordConfig']['PasswordType'] = 'GeneratePassword'
            rule_template['NewUserPasswordConfig']['ForcePasswordChange'] = True
            rule_template['NewUserPasswordConfig']['NotifyEmailList'] = [generated_password_email]

        self.provisioning_helper.create_inbound_source_rule(rule_template)