import base64
import os
import time
import uuid
import subprocess

from Steps.data_steps import DataSteps
from idaptive_automation.api_payloads import CloudUser


class MsOfficeWorker:
    def __init__(self, session, helpers_fixture):
        self.api_client = session["api_session"]
        self.user_helper = helpers_fixture["user_helper"]
        self.role_helper = helpers_fixture["role_helper"]
        self.app_helper = helpers_fixture["app_helper"]
        self.redrock_helper = helpers_fixture["redrock_helper"]
        self.cdirectory_helper = helpers_fixture["cdirectory_helper"]
        self.o365_helper = helpers_fixture["o365_helper"]
        self.user_prov_helper = helpers_fixture["user_prov_helper"]
        self.data_steps = DataSteps(session['mongo_cred'])
        self.dc_info = session['dc_info']
        self.import_name = 'Office 365v2'
        self.app_key = None

    def import_o365_instance(self, update_app=True, roles=None, retainDeprovAccount=False, setup_script='O365UpdateAppData', disabled_service_plans=None):
        self.app_key = self.app_helper.import_app_by_name(self.import_name)
        if update_app:
            self.update_o365_instance(roles=roles,
                                      retainDeprovAccount=retainDeprovAccount,
                                      setup_script=setup_script,
                                      disabled_service_plans=disabled_service_plans)

    def update_o365_instance(self, roles, retainDeprovAccount=False, setup_script='O365UpdateAppData', disabled_service_plans=None, get_response=False, sync_groups=False):
        app_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': setup_script})
        # TODO Can we refactor this to not use hard coded indices
        app_data = app_data['value'][0]
        app_data['appKey'] = self.app_key
        count = 0
        for role in roles:
            app_data['settings']['RoleMappings'][count]['RoleName'] = role['role_name']
            count = count + 1
        if disabled_service_plans is not None:
            count = 0
            for plan in disabled_service_plans:
                if app_data['settings']['RoleMappings'][0]['DisabledServicePlans'].__len__() > 0:
                    app_data['settings']['RoleMappings'][0]['DisabledServicePlans'][count]['Role'] = plan
                    count = count + 1
                elif app_data['settings']['RoleMappings'][1]['DisabledServicePlans'].__len__() > 0:
                    app_data['settings']['RoleMappings'][1]['DisabledServicePlans'][count]['Role'] = plan
                    count = count + 1
        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True
        if sync_groups is True:
            app_data['settings']['RoleMappings'][1]['SyncGroups'] = True
        assert_success = not get_response
        response = self.user_prov_helper.update_app(app_data, assert_success)
        self.user_prov_helper.get_app(self.app_key)
        if get_response:
            return response

    def update_o365_distribution_list_sync(self, role_name, domain, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': 'O365UpdateAppData'})
        app_data = test_data['value'][0]
        app_data['appKey'] = self.app_key
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name

        app_data['settings']['RoleMappings'].append({
            'MappingType': 'Forest',
            'RoleName': domain,
            'SyncContacts': False,
            'SyncUsers': False,
            'SyncGroups': True,
            'SyncResources': False,
            'LicenseNames': None
        })

        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True

        self.user_prov_helper.update_app(app_data)
        self.user_prov_helper.get_app(self.app_key)

    def update_o365_hybrid_settings(self, role_name, domain_name, sync_contact=False, retainDeprovAccount=False):
        test_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': 'O365GroupsChecked'})

        app_data = test_data['value'][0]
        app_data['appKey'] = f'{self.app_key}'
        app_data['settings']['RoleMappings'][0]['RoleName'] = role_name
        app_data['settings']['RoleMappings'][1]['RoleName'] = f'{domain_name}'
        app_data['settings']['RoleMappings'][1]['SyncGroups'] = True
        app_data['settings']['RoleMappings'][1]['SyncContacts'] = sync_contact
        if retainDeprovAccount:
            app_data['retainDeprovAccount'] = True
        self.user_prov_helper.update_app(app_data)
        self.user_prov_helper.get_app(self.app_key)

    def update_o365_linked_apps(self):
        app_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script', {'name': 'O365AddLinkedApps'})['value'][0]
        app_data['_RowKey'] = self.app_key
        self.user_prov_helper.get_app(app_data)

    def delete_linked_apps(self, linked_apps):
        app_data = self.data_steps.query_db_collection('automation', 'office365_application_setup_script',
                                                        {'name': 'O365RemoveLinkedApps'})['value'][0]
        app_data['_RowKey'] = self.app_key
        count = 0
        delete_this_app = linked_apps.pop()
        for app in linked_apps:
            app_data['ChildLinkedApps'][count]['ParentApp'] = self.app_key
            app_data['ChildLinkedApps'][count]['_RowKey'] = app['Row']['ID']
            count = count + 1
        # TODO Really don't like this candidate for refactor
        app_data['ChildLinkedApps'][2]['AppKey'] = delete_this_app['Row']['ID']
        app_data['ChildLinkedApps'][2]['_RowKey'] = delete_this_app['Row']['ID']
        self.user_prov_helper.get_app(app_data)

    def validate_linked_app_list(self, expected_app_count=0):
        payload = {
            'Script': f'SELECT Application.DisplayName, Application.ID \
                    FROM Application \
                    WHERE Application.ParentApp = "{self.app_key}"'
        }
        linked_app_count = 0
        retry_count = 0
        query_results = None
        while linked_app_count != expected_app_count:
            self.api_client.refresh_token()
            query_results = self.redrock_helper.execute_redrock_query(payload).response['Result']['Results']
            linked_app_count = query_results.__len__()
            time.sleep(30)
            retry_count = retry_count + 1
            if retry_count == 20:
                break
        assert query_results.__len__() == expected_app_count
        return query_results

    def federate_domain(self):
        self.o365_helper.federate_domain(
            domain_name=self.dc_info["default_email_suffix"],
            app_row_key=self.app_key
        )

    def unfederate_domain(self):
        self.o365_helper.unfederate_domain(
            domain_name=self.dc_info["default_email_suffix"],
            app_row_key=self.app_key
        )

    def validate_federation(self):
        info = self.o365_helper.get_domain_info_page(self.app_key)
        is_federated = False
        for result in info.response['Result']['Results']:
            if result['Row']['Name'] == 'automationRDtesting.com':
                assert result['Row']['IsOwned'] is True
                is_federated = True
        assert is_federated is True

    def validate_unfederation(self):
        info = self.o365_helper.get_domain_info_page(self.app_key)
        is_federated = True
        for result in info.response['Result']['Results']:
            if result['Row']['Name'] == 'automationRDtesting.com':
                assert result['Row']['IsOwned'] is False
                is_federated = False
        assert is_federated is False

    def validate_msoffice_contact(self, email_prefix):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_contact.ps1',
                               email_prefix],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        assert contact['Contacts'][0]['EmailAddress'] == f"{email_prefix}@{self.dc_info['default_email_suffix']}"

    def validate_msol_group_members(self, group_name, user_name, assert_group_only=False, group_member_count=0):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_group_members.ps1',
                               group_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        group_members = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        member_found = False
        if not assert_group_only:
            for member in group_members['Group']['Members']:
                if member['User'] == f"{user_name.lower()}user1@{self.dc_info['default_email_suffix']}":
                    member_found = True
            assert member_found is True
        else:
            assert group_members['Group']['Name'].__len__() > 9
        if group_member_count > 0:
            assert group_members['Group']['Members'].__len__() == group_members

    @staticmethod
    def get_msol_user_attributes(user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_user_attributes.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact_attr = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        return contact_attr

    @staticmethod
    def get_msol_user_all_attributes(user_principal_name):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_all_msol_user_attributes.ps1',
                               user_principal_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        contact_attr = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        return contact_attr

    @staticmethod
    def convert_object_guid_to_immutable_id(object_guid):
        return str(base64.b64encode(uuid.UUID(str(object_guid)[1:-1]).bytes_le))[2:-1]

    @staticmethod
    def validate_msoffice_user_license(user_name, expected_user_count=1, expected_license=None):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        office_rules = {'Users': []}
        count = 0
        office_license = ' '

        if expected_license is not None:
            while (office_rules['Users'].__len__() != expected_user_count) and office_license is '':
                ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                                       '-ExecutionPolicy',
                                       'Unrestricted',
                                       rf'{file_dir}\Scripts\get_msol_user_licenses.ps1',
                                       user_name],
                                      stdout=subprocess.PIPE,
                                      cwd=os.getcwd()
                                      )
                office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
                count = count + 1
                office_license = office_rules['Users'][0]['Licenses']
                if count == 20:
                    raise Exception('Unable to validate user license')
                time.sleep(15)
        else:
            while office_rules['Users'].__len__() != expected_user_count:
                ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                                       '-ExecutionPolicy',
                                       'Unrestricted',
                                       rf'{file_dir}\Scripts\get_msol_user_licenses.ps1',
                                       user_name],
                                      stdout=subprocess.PIPE,
                                      cwd=os.getcwd()
                                      )
                office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
                count = count + 1
                if count == 20:
                    raise Exception('Unable to validate user license')
                time.sleep(15)

        if (expected_license is not None) and office_rules['Users']:
            print("License = *** " + office_rules['Users'][0]['Licenses'] + " ***")
            assert office_rules['Users'][0]['Licenses'] == expected_license

    @staticmethod
    def validate_msoffice_sub_license(user_name, license_name, status):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        office_rules = {'Users': []}
        count = 0
        while office_rules['Users'].__len__() < 1:
            ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                                   '-ExecutionPolicy',
                                   'Unrestricted',
                                   rf'{file_dir}\Scripts\get_msol_user_licenses.ps1',
                                   user_name],
                                  stdout=subprocess.PIPE,
                                  cwd=os.getcwd()
                                  )
            office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
            count = count + 1
            if count == 20:
                raise Exception('Unable to validate user license')
            time.sleep(15)
        assert office_rules['Users'][0]['SubLicenses'][license_name] == status

    @staticmethod
    def validate_msol_preferred_data_value(user_name, validate_key, validate_value):
        file_dir = os.path.dirname(os.path.realpath('__file__'))
        ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                               '-ExecutionPolicy',
                               'Unrestricted',
                               rf'{file_dir}\\Scripts\\get_msol_pref_data_location.ps1',
                               user_name],
                              stdout=subprocess.PIPE,
                              cwd=os.getcwd()
                              )
        office_rules = eval(ps.communicate()[0].decode('utf-8').replace("'", '"'))
        assert office_rules['Users'][0]['Attributes'][validate_key] == validate_value

    @staticmethod
    def clean_msoffice_online(search_string, group_name=None):
        try:
            file_dir = os.path.dirname(os.path.realpath('__file__'))
            ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                                   '-ExecutionPolicy',
                                   'Unrestricted',
                                   rf'{file_dir}\Scripts\remove_o365_all_objects_recyclebin.ps1',
                                   search_string],
                                  stdout=subprocess.PIPE,
                                  cwd=os.getcwd()
                                  )
            result = ps.wait()
            assert result == 0
        except AssertionError:
            file_dir = os.path.dirname(os.path.realpath('__file__'))
            ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                                   '-ExecutionPolicy',
                                   'Unrestricted',
                                   rf'{file_dir}\Scripts\remove_o365_users_recyclebin.ps1',
                                   search_string],
                                  stdout=subprocess.PIPE,
                                  cwd=os.getcwd()
                                  )
            result = ps.wait()
            assert result == 0

        try:
            if group_name is not None:
                file_dir = os.path.dirname(os.path.realpath('__file__'))
                ps = subprocess.Popen([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                                       '-ExecutionPolicy',
                                       'Unrestricted',
                                       rf'{file_dir}\Scripts\remove_o365_groups.ps1',
                                       group_name],
                                      stdout=subprocess.PIPE,
                                      cwd=os.getcwd()
                                      )
                result = ps.wait()
                assert result == 0
        except:
            pass
