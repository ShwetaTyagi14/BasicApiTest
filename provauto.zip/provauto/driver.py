import logging

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait, Select

logger = logging.getLogger(__name__)


class Driver(webdriver.Remote):
    def __init__(self, options):
        super().__init__(options=options)

    def navigate_to(self, url):
        self.get(url)

    def wait_for_visible_element(self, by, default_wait=20):
        logger.debug('Waiting for Visible Element - {}'.format(by))

        try:
            return WebDriverWait(self, default_wait).until(
                expected_conditions.visibility_of_element_located(by)
            )
        except Exception:
            return None

    def wait_for_clickable_element(self, by, default_wait=20):
        logger.debug('Waiting for Clickable Element - {}'.format(by))

        try:
            return WebDriverWait(self, default_wait).until(
                expected_conditions.element_to_be_clickable(by)
            )
        except Exception:
            return None

    def wait_for_invisible_element(self, by, default_wait=20):
        logger.debug('Waiting for Element to Disappear - {}'.format(by))

        try:
            return WebDriverWait(self, default_wait).until(
                expected_conditions.invisibility_of_element_located(by)
            )
        except Exception:
            return None

    def wait_for_new_window(self, default_wait=20):
        try:
            handles_before = self.window_handles
            return WebDriverWait(self, default_wait).until(
                expected_conditions.new_window_is_opened(handles_before)
            )
        except Exception:
            return

    def switch_to_window_by_title(self, title):
        window_found = False

        for _ in self.window_handles:
            self.switch_to.window(_)
            if self.title == title:
                window_found = True
                break

        if window_found is False:
            raise Exception('Window {} not found'.format(title))

    def fetch_element(self, by, default_wait=20):
        logger.debug('Searching for Element - {}'.format(by))
        try:
            return WebDriverWait(self, default_wait).until(
                expected_conditions.presence_of_element_located(by)
            )
        except Exception:
            return None

    def send_element_keys(self, element, value):
        self.wait_for_visible_element(element).clear()
        self.wait_for_visible_element(element).send_keys(value)

    def click_element(self, element):
        self.wait_for_visible_element(element).click()

    def hover_element(self, element):
        hover = ActionChains(self).move_to_element(element)
        hover.perform()

    def accept_alert(self):
        alert = self.switch_to.alert()
        alert.accept()

    def element_enabled(self, element):
        return self.fetch_element(element).is_enabled

    def page_loaded(self, loaded_element):
        if self.wait_for_visible_element(loaded_element) is not None:
            return True
        else:
            return False

    def click_child_element_by_xpath(self, parent, child):
        parent = self.fetch_element(parent)
        elem = parent.find_element_by_xpath(child)
        elem.click()

    def get_child_element_by_xpath(self, parent, child):
        parent = self.fetch_element(parent)
        elem = parent.find_element_by_xpath(child)
        return elem

    def select_from_dropdown(self, element, value):
        select = Select(self.wait_for_clickable_element(element))
        select.select_by_visible_text(value)
