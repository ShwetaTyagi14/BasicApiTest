import json

import requests


class Rest:
    def __init__(self, headers=None):
        self.headers = headers
        self.session = requests.session()

    def get(self, url, payload=None, headers=None):
        return self.session.get(url, data=payload,
                                headers=self.headers if headers is None else {**self.headers, **headers})

    def put(self, url, payload=None, headers=None):
        return self.session.put(url, data=json.dumps(payload),
                                headers=self.headers if headers is None else {**self.headers, **headers})

    def post(self, url, payload=None, headers=None):
        return self.session.post(url, data=json.dumps(payload),
                                 headers=self.headers if headers is None else {**self.headers, **headers})

    def param_post(self, url, params=None, headers=None):
        return self.session.post(url, params=params,
                                 headers=self.headers if headers is None else {**self.headers, **headers})

    def multi_post(self, url, files=None, payload=None, headers=None):
        del self.headers['Content-type']    # Cannot reuse Content-type here
        return self.session.post(url, files=files, data=payload,
                                 headers=self.headers if headers is None else {**self.headers, **headers})

    def delete(self, url, payload=None, headers=None):
        return self.session.delete(url, data=json.dumps(payload),
                                   headers=self.headers if headers is None else {**self.headers, **headers})