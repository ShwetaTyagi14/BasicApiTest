import setuptools

setuptools.setup(
    name='idaptivewrapper',
    version='0.6.1',
    author='Tyler Christensen',
    author_email='tyler.christensen@centrify.com',
    description='Simple API Wrapper for idAptive RESTful Services',
    url='https://bitbucket.idaptive.com/projects/SHAREDAUTOMATION/repos/idaptivewrapper',
    packages=setuptools.find_packages(),
    install_requires=[
        'oath>=1.4.1',
        'mongocred @ git+https://bitbucket.idaptive.com/scm/sharedautomation/mongocred.git',
        'requests>=2.18.4',
        'beautifulsoup4>=4.9.0'
    ],
    extras_require={
        'test': [
            'pytest>=3.5.1'
        ]
    },
    dependency_links=[
        'https://bitbucket.idaptive.com/scm/sharedautomation/mongocred.git',
        'https://bitbucket.idaptive.com/scm/sharedautomation/idaptive-automation.git'
    ]
)
