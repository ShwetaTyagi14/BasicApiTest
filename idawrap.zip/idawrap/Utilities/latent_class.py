class LatentClass:
    def __init__(self, latent_class, parent):
        self.latent_class = latent_class
        self.parent = parent

    def initialize(self):
        return self.latent_class(self.parent)
