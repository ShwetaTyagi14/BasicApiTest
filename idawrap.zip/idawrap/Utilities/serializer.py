import json
from builtins import staticmethod
from collections import namedtuple

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Serializer:
    @staticmethod
    def deserialize_json(json_string):
        try:
            obj = json.loads(json.dumps(json_string), object_hook=lambda d: namedtuple('X', d.keys(), rename=True)(*d.values()))
            return obj
        except:
            logger.warning("unable to deserialize string - {}".format(json_string))
            return json_string
