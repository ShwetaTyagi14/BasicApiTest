import pytest
import time
import uuid
import oath
from IdaptiveSession.idaptive_session import IdaptiveSession
from Utilities.serializer import Serializer
from RestWrapper.rest import Rest
from mongocred.mongocred import MongoCred


class Test:
    mongo_cred = MongoCred()

    def test_get_request_object(self):
        rest_client = Rest()
        r = Serializer.deserialize_json(rest_client.get('https://httpbin.org/ip').json())
        print(r.origin)
        assert r is not None

    def test_get_request_json(self):
        rest_client = Rest()
        response = rest_client.get('https://httpbin.org/ip')
        assert response is not None

    def test_idaptive_session(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA0863', env='hotfix'))

        assert idaptive.auth_details is not None
        assert idaptive.inbound.ping_inbound().success is True

        idaptive.security.logout()

    def test_get_directory_services(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA0863', env='hotfix'))

        payload = {
            'Args': {
                'PageNumber': 1,
                'PageSize': 100000,
                'Limit': 100000,
                'SortBy': "",
                'direction': "False",
                'Caching': -1
            }
        }

        result = idaptive.core.get_directory_services(payload).Result.Results
        # test = next((x for x in result if x.Row.DisplayName == 'Active Directory: qaautomation.com'), None)
        # print(test.Row)
        # print(test.Row.directoryServiceUuid)
        # assert test is not None

    def test_get_ou_tree_contents(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA0863', env='hotfix'))

        payload = {
            "directoryServiceUuid": None,
            "id": "e22de863-6c9a-468a-8adf-0c25dc42c40d",
            "useCache": False
        }

        result = idaptive.core.get_ou_tree_contents(payload, True)
        print(result)
        assert result is not None

    def test_get_job_report(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA0863', env='hotfix'))

        payload = {
            "jobId": "f729d844-f14a-75b6-0300-0f8ce94c82ff",
        }

        result = idaptive.scheduler_history.get_job_details(payload)
        print(result)
        assert result is not None

    def test_get_domain_controllers_for_domain(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA0863', env='hotfix'))

        payload = {
            'Args': {
                'PageNumber': 1,
                'PageSize': 100000,
                'Limit': 100000,
                'SortBy': '',
                'direction': 'False',
                 'Caching': 0
            },
            'directoryServiceUuid': '7a27cc0a-73cc-764c-ee7a-f6f6d9519daf',
            'domainName': 'qaautomation.com'
        }

        result = idaptive.core.get_domain_controllers_for_domain(payload)
        print(result.Result)
        assert result.success is True

    @pytest.mark.skip(reason="remove this skip if you have an active report path and the test has been updated")
    def test_get_report_file(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        report_path = 'InboundProvSyncJob_Workday_604d649df6c046f58b6770d48a3ca489_FullSync_OneTime/f729d5e3-cf13-daed-1500-073018d0b35d/Report.zip'
        result = idaptive.core.download_sync_job_report(report_path)

        for name in result.filelist:
            print(result.open(name).read())

    def test_get_ad_cloud_users(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA0863', env='hotfix'))

        payload = {
            "Script": "SELECT   * "
                      "FROM     ("
                      "             Select  ID, "
                      "                     DisplayName, "
                      "                     Email, "
                      "                     LastInvite, "
                      "                     LastLogin, "
                      "                     SourceDsLocalized, "
                      "                     SourceDsType, "
                      "                     Status, "
                      "                     StatusEnum, "
                      "                     Username, "
                      "                     ServiceUser, "
                      "                     UserType "
                      "             from    User "
                      "             ORDER BY    Username "
                      "             COLLATE NOCASE"
                      "         ) "
                      "WHERE    SourceDsType = \"AdProxy\" "
                      "         AND ("
                      "                 UserType <> \"Service\" "
                      "                 AND "
                      "                 UserType <> \"OAuth2\""
                      "             )",
            "Args": {
                        "PageNumber": 1,
                        "PageSize": 1000,
                        "Limit": 100000,
                        "SortBy": "",
                        "direction": "False",
                        "Caching": -1
                    }
        }

        response = idaptive.red_rock.execute_redrock_query(payload)

        # Add queried users to a list array
        users = []

        for user in response.Result.Results:
            if user.Row.Status != 'Active':
                users.append(user.Row.ID)

        # Test the delete Cloud users
        delete_payload = {
            "Users": users
        }

        print(delete_payload.__len__())

        r = idaptive.user_management.remove_users(delete_payload)

    def test_create_cloud_users(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        payload = {
            'LoginName': 'awstest',
            'Mail': 'awstest@automationrdtesting.com',
            'DisplayName': 'awstest',
            'Password': 'testTEST1234',
            'confirmPassword': 'testTEST1234',
            'PasswordNeverExpire': False,
            'ForcePasswordChangeNext': True,
            'InEverybodyRole': True,
            'OauthClient': False,
            'SendEmailInvite': True,
            'Description': '',
            'OfficeNumber': '',
            'HomeNumber': '',
            'MobileNumber': '',
            'fileName': '',
            'ID': '',
            'state': 'None',
            'jsutil-checkbox-1287-inputEl': False,
            'ReportsTo': 'Unassigned',
            'Name': 'awstest@automationrdtesting.com'
        }

        r = idaptive.cdirectory_service.create_cloud_user(**payload)

    def test_refresh_user_token(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        payload = {
            'DirectoryServiceUuid': '4cdd659f-8fe9-1554-951a-d63b079def3d',
            'ID': '10ac165f-9152-4e45-a3cf-64ce091f4f90'
        }

        result = idaptive.cdirectory_service.refresh_ad_user_token('10ac165f-9152-4e45-a3cf-64ce091f4f90')

        s = 1

    def test_auth_profile_endpoints(self):

        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        r = idaptive.auth_profile.get_profile_list()

        profiles = r.Result

        r = idaptive.auth_profile.save_profile(**profiles[0]._asdict())

        assert r.success is True

    def test_delete_auth_profile(self):

        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        policy_name = f'test_policy_{time.time()}'

        payload = {
            "Name": policy_name,
            "Challenges": [
                "UP"
            ]
        }

        r = idaptive.auth_profile.save_profile(**payload)

        assert r.success

        profile_uuid = r.Result.Uuid

        r = idaptive.auth_profile.get_profile_list()

        profile_exists = False

        for profile in r.Result:
            if profile.Uuid == profile_uuid:
                profile_exists = True

        assert profile_exists

        r = idaptive.auth_profile.delete_profile(uuid=profile_uuid)

        assert r.success

        r = idaptive.auth_profile.get_profile_list()

        for profile in r.Result:
            assert profile.Uuid != profile_uuid

    def test_policy(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        r = idaptive.policy.get_policy_block()

        assert r['success'] is True

        settings = r['Result']['Settings']

        r = idaptive.policy.get_nice_plinks()

        assert r['success'] is True

        r = idaptive.policy.update_policy(policy_name="Default Policy", settings=settings)

        assert r.success is True

    def test_change_policy_setting(self):
        setting = "/Core/Authentication/AllowIwa"

        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        current_settings = idaptive.policy.get_policy_block()['Result']['Settings']

        current_bool = current_settings[setting]

        idaptive.policy.change_policy_setting(setting=setting, value=not current_bool)

        altered_settings = idaptive.policy.get_policy_block()['Result']['Settings']

        altered_bool = altered_settings[setting]

        assert current_bool is not altered_bool

        idaptive.policy.change_policy_setting(setting=setting, value=current_bool)

        assert idaptive.policy.get_policy_block()['Result']['Settings'][setting] is current_bool

    def test_set_profile(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        idaptive.policy.set_default_profile('Password Only')

        idaptive.policy.get_policy_block()

        pw_only_profile = \
            idaptive.policy.policy_blocks['Default Policy']['Settings']['/Core/Authentication/'
                                                                        'AuthenticationRulesDefaultProfileId']

        idaptive.policy.set_default_profile('Pass and Security')

        idaptive.policy.get_policy_block()

        pw_sec_profile = \
            idaptive.policy.policy_blocks['Default Policy']['Settings']['/Core/Authentication/'
                                                                        'AuthenticationRulesDefaultProfileId']

        assert pw_only_profile != pw_sec_profile

    def test_delete_setting_and_policy(self):
        setting = "/Core/Authentication/AllowIwa"

        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        policy_name = f'test_policy_{uuid.uuid4()}'

        result = idaptive.policy.create_policy(policy_name=policy_name, settings={"key": "value"})

        assert result.success

        plinks = idaptive.policy.massage_plinks(idaptive.policy.get_nice_plinks()['Result'])

        created = False

        for plink in plinks:
            if policy_name in plink['PolicySet']:
                created = True

        assert created is True

        idaptive.policy.change_policy_setting(setting=setting, value=True, policy_name=policy_name)

        new_settings = idaptive.policy.get_policy_block(policy_name=policy_name)['Result']['Settings']

        setting_bool = new_settings[setting]

        assert setting_bool

        idaptive.policy.delete_policy_setting(setting=setting, policy_name=policy_name)

        new_settings = idaptive.policy.get_policy_block(policy_name=policy_name)['Result']['Settings']

        assert setting not in new_settings

        idaptive.policy.delete_policy(policy_name=policy_name)

        plinks = idaptive.policy.massage_plinks(idaptive.policy.get_nice_plinks()['Result'])

        for plink in plinks:
            assert policy_name not in plink['PolicySet']

    def test_tenant_config(self):
        new_question = f"This is a question {time.time()}?"
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        start_questions = idaptive.tenant_config.get_admin_security_questions()

        assert start_questions.success

        r = idaptive.tenant_config.set_admin_security_question(new_question)

        assert r.success

        test_new_question = False

        mid_questions = idaptive.tenant_config.get_admin_security_questions()

        for question in mid_questions.Result:
            if question.Question == new_question:
                test_new_question = True
                new_question_uuid = question.Uuid

        assert test_new_question

        r = idaptive.tenant_config.delete_admin_security_question(uuid=new_question_uuid)

        assert r.success

        final_questions = idaptive.tenant_config.get_admin_security_questions()

        for question in final_questions.Result:
            assert question.Uuid != new_question_uuid

    def test_get_templates(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        result = idaptive.saas_manage.get_templates_and_categories()

        assert result is not None

    def test_update_device_policies(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        device_ids = ["66f612927ee27c9a-R38K206K2BR-1560043795"]

        result = idaptive.mobile.update_device_policies(device_ids)

        assert result['success'] is True

    def test_phone_pin(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        user_id = idaptive.user_management.get_user_info()['Result']['Id']

        result = idaptive.user_management.set_phone_pin(user_uuid=user_id, phone_pin='9182736')

        assert result.success

    def test_security_questions(self):
        question_text = f"test {uuid.uuid4()}"
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        result = idaptive.user_management.update_security_questions({"Deleted": [],
                                                                     "Added": [{
                                                                        "Type": "User",
                                                                        "QuestionText": question_text,
                                                                        "Modified": True,
                                                                        "HasAnswer": False,
                                                                        "Answer": "test!"
                                                                     }]})

        assert result.success

        current_questions = idaptive.user_management.get_security_questions().Result.Questions

        question_found = False

        for question in current_questions:
            if question.QuestionText == question_text:
                question_uuid = question.Uuid
                question_found = True

        assert question_found

        result = idaptive.user_management.update_security_questions({"Deleted": [question_uuid],
                                                                     "Added": []})

        assert result.success

        current_questions = idaptive.user_management.get_security_questions().Result.Questions

        for question in current_questions:
            assert question.Uuid != question_uuid

    @pytest.mark.skip(reason="remove this skip and update the device_id in this test to run it")
    def test_reapply_device_policy(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        device_ids = ["AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE"]

        result = idaptive.mobile.reapply_device_policy(device_ids)

        assert result['success'] is True

    @pytest.mark.skip(reason="remove this skip and update the device_id in this test to run it")
    def test_lock_device(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        device_id = "AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE"
        passcode = "123456"

        result = idaptive.mobile.lock_device(device_id, passcode)

        assert result['success'] is True

    @pytest.mark.skip(reason="remove this skip and update the device_id in this test to run it")
    def test_unenroll_device(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        device_ids = ["AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE"]

        result = idaptive.mobile.unenroll_devices(device_ids)

        assert result['success'] is True

    @pytest.mark.skip(reason="remove this skip and update the device_id in this test to run it")
    def test_lapm_password(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        vault_id = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
        
        checkout_res = idaptive.lapm.checkout_password(vault_id)
        assert checkout_res['success']

        checkout_id = checkout_res['Result']['COID']

        extend_res = idaptive.lapm.extend_password(checkout_id)
        assert extend_res['success']

        checkin_res = idaptive.lapm.checkin_password(checkout_id)
        assert checkin_res['success']

    def test_tenant_config(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        r = idaptive.core.get_tenant_config(key='PortalForceTimeout')

        current_value = r.Result

        if current_value == 'True':
            a_value = False
        else:
            a_value = True

        idaptive.core.set_tenant_config(key='PortalForceTimeout', value=a_value)

        r = idaptive.core.get_tenant_config(key='PortalForceTimeout')

        new_value = r.Result

        idaptive.core.set_tenant_config(key='PortalForceTimeout', value=current_value)

        r = idaptive.core.get_tenant_config(key='PortalForceTimeout')

        final_value = r.Result

        assert new_value != current_value

        assert final_value == current_value

    def test_update_cloud_user(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        username = f'changetest_{uuid.uuid4()}@automationrdtesting.com'

        payload = {
            'LoginName': 'changetest',
            'Mail': 'changetest@automationrdtesting.com',
            'DisplayName': 'Change Test',
            'Password': 'testTEST1234',
            'confirmPassword': 'testTEST1234',
            'PasswordNeverExpire': False,
            'ForcePasswordChangeNext': False,
            'InEverybodyRole': True,
            'OauthClient': False,
            'SendEmailInvite': True,
            'Description': '',
            'OfficeNumber': '',
            'HomeNumber': '',
            'MobileNumber': '',
            'fileName': '',
            'ID': '',
            'state': 'None',
            'jsutil-checkbox-1287-inputEl': False,
            'ReportsTo': 'Unassigned',
            'Name': username
        }

        user_id = idaptive.cdirectory_service.create_cloud_user(**payload).Result
        assert user_id is not None

        payload = {
            'LoginName': 'changetest',
            'Mail': 'changetest@automationrdtesting.com',
            'DisplayName': 'Change Test',
            'Password': 'testTEST1234',
            'confirmPassword': 'testTEST1234',
            'PasswordNeverExpire': False,
            'ForcePasswordChangeNext': False,
            'InEverybodyRole': True,
            'OauthClient': False,
            'SendEmailInvite': True,
            'Description': '',
            'OfficeNumber': '',
            'HomeNumber': '',
            'MobileNumber': '',
            'fileName': '',
            'ID': user_id,
            'state': 'Locked',
            'jsutil-checkbox-1287-inputEl': False,
            'ReportsTo': 'Unassigned',
            'Name': username
        }

        result = idaptive.cdirectory_service.change_user(**payload)
        assert result.success is True

        payload = {
            "LoginName": "changetest",
            "loginsuffixfield-1951-inputEl": "automationrdtesting.com",
            "Mail": "changetest@automationrdtesting.com",
            "DisplayName": "Change Test",
            "passwordCreationType": "manual",
            "enableState": True,
            "PasswordNeverExpire": False,
            "ForcePasswordChangeNext": False,
            "InEverybodyRole": False,
            "OauthClient": False,
            "Description": "",
            "OfficeNumber": "",
            "HomeNumber": "",
            "MobileNumber": "",
            "Picture": "",
            "fileName": "",
            "ID": user_id,
            "state": "Locked",
            "jsutil-checkbox-1996-inputEl": False,
            "ReportsTo": "Unassigned"
        }

        result = idaptive.cdirectory_service.set_user_state(**payload)
        assert result.success is True

        users = [user_id]

        delete_payload = {
            "Users": users
        }

        idaptive.user_management.remove_users(delete_payload)

    def test_set_cloud_user_state(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        username = f'changetest_{uuid.uuid4()}@automationrdtesting.com'

        payload = {
            'LoginName': 'changetest',
            'Mail': 'changetest@automationrdtesting.com',
            'DisplayName': 'Change Test',
            'Password': 'testTEST1234',
            'confirmPassword': 'testTEST1234',
            'PasswordNeverExpire': False,
            'ForcePasswordChangeNext': False,
            'InEverybodyRole': True,
            'OauthClient': False,
            'SendEmailInvite': True,
            'Description': '',
            'OfficeNumber': '',
            'HomeNumber': '',
            'MobileNumber': '',
            'fileName': '',
            'ID': '',
            'state': 'None',
            'jsutil-checkbox-1287-inputEl': False,
            'ReportsTo': 'Unassigned',
            'Name': username
        }

        user_id = idaptive.cdirectory_service.create_cloud_user(**payload).Result
        assert user_id is not None

        payload = {
            "LoginName": "changetest",
            "loginsuffixfield-1951-inputEl": "automationrdtesting.com",
            "Mail": "changetest@automationrdtesting.com",
            "DisplayName": "Change Test",
            "passwordCreationType": "manual",
            "enableState": True,
            "PasswordNeverExpire": False,
            "ForcePasswordChangeNext": False,
            "InEverybodyRole": False,
            "OauthClient": False,
            "Description": "",
            "OfficeNumber": "",
            "HomeNumber": "",
            "MobileNumber": "",
            "Picture": "",
            "fileName": "",
            "ID": user_id,
            "state": "Locked",
            "jsutil-checkbox-1996-inputEl": False,
            "ReportsTo": "Unassigned"
        }

        result = idaptive.cdirectory_service.set_user_state(**payload)
        assert result.success is True

    def test_get_sys_info(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0334'))

        result = idaptive.sysinfo.get_about()
        print(result['Result']['Version'])
        assert result['Result']['Version'] is not None

    def test_red_rock_oath(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        payload = {
            "Script": "@@All Devices",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100,
                "Limit": 100000,
                "SortBy": "Name",
                "Ascending": True,
                "Caching": -1
            }
        }

        response = idaptive.red_rock.execute_redrock_query(payload)

        assert response['success'] is True

    def test_get_users(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        users = idaptive.cdirectory_service.get_users()

        correct_users = False

        for user in users.Result.Results:
            if user.Row.Name == "admin@jared-qa":
                correct_users = True
                break

        assert correct_users is True

    def test_core_range_endpoints(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        label = f"test_label_{uuid.uuid4()}"

        value = "192.168.1.1"

        idaptive.core.add_prem_detect_range(label=label, value=value)

        ranges = idaptive.core.get_prem_detect_ranges()

        was_created = False

        for a_range in ranges.Result.Results:
            if a_range.Row.Label == label:
                was_created = True

        assert was_created is True

        idaptive.core.del_prem_detect_range(value=value)

        ranges = idaptive.core.get_prem_detect_ranges()

        for a_range in ranges.Result.Results:
            assert a_range.Row.Label != label

    def test_change_policy_order(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        policy_name = f'test_policy_{uuid.uuid4()}'

        result = idaptive.policy.create_policy(policy_name=policy_name, settings={})

        assert result.success

        idaptive.policy.get_nice_plinks()

        last_index = idaptive.policy.plinks['Count'] - 1

        idaptive.policy.change_policy_order(policy_name, last_index)

        massaged_plinks = idaptive.policy.massage_plinks(idaptive.policy.get_nice_plinks())

        assert policy_name in massaged_plinks[last_index]['ID']

        idaptive.policy.change_policy_order(policy_name, 0)

        massaged_plinks = idaptive.policy.massage_plinks(idaptive.policy.get_nice_plinks())

        assert policy_name in massaged_plinks[0]['ID']

        idaptive.policy.delete_policy(policy_name=policy_name)

    def test_set_user_otp(self):
        creds = self.mongo_cred.get_tenant_credentials('aap0083')
        idaptive = IdaptiveSession(**creds)
        test_uuid = uuid.uuid4()

        alias = idaptive.core.get_tenant_aliases().Result.Results[0].Row.ID

        user_payload = {
            "LoginName": f"test_user_{test_uuid}",
            "Password": "testTEST1234",
            "confirmPassword": "testTEST1234",
            "Name": f'test_user_{test_uuid}@{alias}'
        }

        user_result = idaptive.cdirectory_service.create_cloud_user(**user_payload)

        assert user_result.success

        user_session = IdaptiveSession(base_url=creds['base_url'], tenant_id=creds['tenant_id'],
                                       username=user_payload['Name'], password=user_payload['Password'])

        otp_stuff = user_session.mobile.get_user_third_party_otp()

        authenticator = oath.GoogleAuthenticator(otp_stuff.Result.Url)

        code = authenticator.generate()

        otp_result = user_session.mobile.set_user_otp(code, otp_stuff.Result.ProfileUuid)

        assert otp_result['success']

        remove_payload = {
            "Users": [
                user_result.Result
            ]
        }

        idaptive.user_management.remove_users(remove_payload)

    def test_custom_headers(self):
        creds = self.mongo_cred.get_tenant_credentials('aap0083')
        idaptive = IdaptiveSession(**creds, headers={'brave': 'toaster'})

        assert idaptive.headers.get('brave') == 'toaster'

    def test_save_notification_settings(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAP0597'))

        payload = {
          'FromEmail': 'no-reply@centrify.com',
          'ToEmail': 'idaptivetester@qaidaptive.net',
          'IncludeDebugTrace': False,
          'NotifyOnFull': True,
          'NotifyOnIndividual': False,
          'NotifyOnError': True,
          'DailySync': False
        }

        r = idaptive.provisioning.save_notification_settings(payload)

    def test_reset_user_password(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))
        test_uuid = uuid.uuid4()

        alias = idaptive.core.get_tenant_aliases().Result.Results[0].Row.ID

        user_payload = {
            "LoginName": f"test_user_{test_uuid}",
            "Password": "testTEST1234",
            "confirmPassword": "testTEST1234",
            "Name": f'test_user_{test_uuid}@{alias}'
        }

        new_user = idaptive.cdirectory_service.create_cloud_user(**user_payload).Result

        payload = {
            'ID': new_user,
            'newPassword': 'Password1!'
        }

        result = idaptive.user_management.reset_user_password(payload)

        remove_payload = {
            "Users": [new_user]
        }

        idaptive.user_management.remove_users(remove_payload)

        assert result.success is True

    def test_latent_classes(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'), auto_init=False)
        idaptive.user_management = idaptive.user_management.initialize()
        result = idaptive.user_management.get_user_info()

        assert result['success'] is True

    def test_role_applications(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))
        test_uuid = uuid.uuid4()
        role_name = f"test_role_{test_uuid}"
        role_result = idaptive.saas_manage.store_role({"Name": role_name})

        role_id = role_result['Result']['_RowKey']

        assert role_id is not None

        red_rock_query = {
            "Script": "select * from application\nORDER BY Name COLLATE NOCASE",
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
        }

        app_info = idaptive.red_rock.execute_redrock_query(payload=red_rock_query)

        app_id = app_info['Result']['Results'][0]['Entities'][0]['Key']

        publish_app_result = idaptive.saas_manage.publish_application(role=role_id, application_id=app_id)

        assert publish_app_result.success

        published_apps = idaptive.saas_manage.get_role_apps(role=role_id)

        app_published = False

        for result in published_apps.Result.Results:
            if result.Row.ID == app_id:
                app_published = True

        assert app_published

        deletion_result = idaptive.saas_manage.delete_roles(payload=[role_id])

        assert deletion_result.success

    def test_email_link(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        result = idaptive.mobile.email_link('idaptiveqa@gmail.com')

        assert result['success'] is True

    def test_text_link(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        result = idaptive.mobile.text_link('(385) 212-4758')

        assert result['success'] is True

    def test_sync_user(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('AAA4026'))
        result = idaptive.provisioning.sync_user('d5ada508-0bf9-4814-b5b1-fea40e609517')

        assert result['success'] is True

    def test_get_user_and_app_store_url_info(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        result = idaptive.mobile.get_user_and_app_store_url_info()

        assert result['success'] is True
        assert result['Result']['EmailAddress'] == "jared.morgan@centrify.com"

    def test_get_apns_cert_expiration(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        result = idaptive.mobile.get_apns_cert_expiration()

        assert result.success is True

    @pytest.mark.skip(reason="Password and location to certificate are user specific")
    def test_upload_existing_push_cert(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        cert = open("/Users/jeremy.nguyen/Documents/misc/dev_apns2_ldap4$.p12", 'rb')

        password = "ask_jeremy"

        result = idaptive.mobile.upload_existing_push_cert(cert, password)

        assert result.success is True

    @pytest.mark.skip(reason="Need to generate cert from Apple for tenant under test")
    def test_upload_mdm_csr_result(self):
        idaptive = IdaptiveSession(**self.mongo_cred.get_tenant_credentials('aap0083'))

        cert = open("/Users/jeremy.nguyen/Desktop/MDM_ Centrify Corporation_Certificate.pem", 'rb')

        result = idaptive.mobile.upload_mdm_csr_result(cert)

        assert result.success is True
