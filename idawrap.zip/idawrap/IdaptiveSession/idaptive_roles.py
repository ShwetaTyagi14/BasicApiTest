from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


# TODO Need to add method to call api to delete role
class Roles:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def update_role(self, payload):
        logger.info('updating core role - {}/Roles/UpdateRole - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Roles/UpdateRole'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('core role updated - {}'.format(result))
        return result
