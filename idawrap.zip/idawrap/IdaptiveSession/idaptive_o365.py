from Utilities.serializer import Serializer
from io import BytesIO
from zipfile import ZipFile
import uuid

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Office365:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def o365_federate_domain(self, domain_name, app_row_key):
        logger.info(
            f'Federating O365 Domain: {self.idaptive_session.base_url}/O365/FederateDomain?domainName={domain_name}&applicationRowKey={app_row_key}')

        payload = {}

        response = self.idaptive_session.rest_client.param_post(
            f'{self.idaptive_session.base_url}/O365/FederateDomain?domainName={domain_name}&applicationRowKey={app_row_key}',
            params=payload
        )

        result = Serializer.deserialize_json(response).json()

        logger.info('O365 Domain Federated complete: - {result}')

        return result

    def o365_unfederate_domain(self, domain_name, app_row_key):
        logger.info(
            f'UnFederating O365 Domain: {self.idaptive_session.base_url}/O365/UnfederateDomain?domainName={domain_name}&applicationRowKey={app_row_key}')

        payload = {}

        response = self.idaptive_session.rest_client.param_post(
            f'{self.idaptive_session.base_url}/O365/UnfederateDomain?domainName={domain_name}&applicationRowKey={app_row_key}',
            params=payload
        )

        result = Serializer.deserialize_json(response).json()

        logger.info('O365 Domain UnFederated complete: - {result}')

        return result

    def o365_get_domain_info_page(self, app_row_key):
        payload = {}
        response = self.idaptive_session.rest_client.param_post(
            f'{self.idaptive_session.base_url}/O365/GetOffice365Domains?rowKey={app_row_key}',
            params=payload
        )

        result = Serializer.deserialize_json(response).json()

        logger.info('Getting O365 Domain Info Page: - {result}')

        return result