from Utilities.serializer import Serializer

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Oath:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def resynchronize_oath_token(self, first_code, second_code, token_id):
        payload = {
            "firstCode": first_code,
            "secondCode": second_code,
            "tokenId": token_id
        }

        url = f'{self.idaptive_session.base_url}/oath/ResynchronizeOathToken'

        logger.info(f'resynchronizing oath token - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished resychronizing the oath token - {result}')

        return result

    def submit_uploaded_file(self, return_id, admin_email):
        url = f'{self.idaptive_session.base_url}/Oath/SubmitUploadedFile'

        payload = {
            "ReturnID": return_id,
            "AdminEmail": admin_email
        }

        logger.info(f'submitting uploaded file - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished submitting uploaded file - {result}')

        return result

    def get_profile_list(self):
        url = f'{self.idaptive_session.base_url}/Oath/GetProfileList'
        payload = {
            "Args": {

                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1
            }
        }

        logger.info(f'Getting profile list - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished getting profile list - {result}')

        return result
