from Utilities.serializer import Serializer

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Task:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_job_history(self, payload):
        logger.info('requesting job history report - {}/Task/GetJobHistory'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
                '{}/Task/GetJobHistory'.format(self.idaptive_session.base_url),
                payload
            ).json()

        logger.info('job history retrieved - {}'
                    .format(result)
                    )

        return result

    def cancel_job(self, payload):
        logger.info('job cancel requested - {}/Task/CancelJob'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/Task/CancelJob'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('job cancel request completed - {}'
                    .format(result)
                    )

        return result
