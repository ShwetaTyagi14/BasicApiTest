from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class SaasManage:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def store_role(self, payload):
        logger.info('storing core role - {}/SaasManage/StoreRole - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/StoreRole'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('core role stored - {}'.format(result))
        return result

    def import_app_from_template(self, payload):
        logger.info('importing app from template - {}/SaasManage/ImportAppFromTemplate - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/ImportAppFromTemplate'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('app imported from template - {}'.format(result))
        return result

    def update_application_de(self, payload):
        logger.info('updating app de - {}/SaasManage/UpdateApplicationDE - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/UpdateApplicationDE'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('app de updated - {}'.format(result))
        return result

    def set_application_permissions(self, payload):
        logger.info('setting application permissions - {}/SaasManage/SetApplicationPermissions - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/SetApplicationPermissions'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('app permissions set - {}'.format(result))
        return result

    def get_application_permissions(self, payload):

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Acl/GetRowAces'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('app permissions get - {}'.format(result))
        return result

    def delete_roles(self, payload):
        logger.info('deleting roles from cloud - {}/SaasManage/DeleteRoles - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/DeleteRoles'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('delete roles request made - {}'.format(result))
        return result

    def delete_applications(self, payload):
        logger.info('deleting applications from cloud - {}/SaasManage/DeleteApplication - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/DeleteApplication'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('delete applications request made - {}'.format(result))
        return result

    def get_templates_and_categories(self):
        logger.info('retrieving templates and categories - {}/SaasManage/GetTemplatesAndCategories'
                    .format(self.idaptive_session.base_url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/GetTemplatesAndCategories'.format(self.idaptive_session.base_url)
            ).json()
        )

        logger.info('templates and categories request made - {}'.format(result))
        return result

    def assign_super_rights(self, payload):
        logger.info('assigning super rights - {}/SaasManage/AssignSuperRights'
                    .format(self.idaptive_session.base_url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SaasManage/AssignSuperRights'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('super rights assigned - {}'.format(result))
        return result

    def publish_application(self, role, application_id):
        url = f'{self.idaptive_session.base_url}/saasManage/PublishApplication'
        payload = [{
            "Role": role,
            "Application": application_id
        }]

        logger.info(f'publishing application - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'Attempt to publish application complete - {result}')

        return result

    def get_role_apps(self, role):
        url = f'{self.idaptive_session.base_url}/SaasManage/GetRoleApps?role={role}'

        logger.info(f'getting role apps for role - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url
            ).json()
        )

        logger.info(f'finished getting role apps for role - {result}')

        return result

    def get_app_info(self, payload):
        url = f'{self.idaptive_session.base_url}/saasManage/GetApplication'

        logger.info(f'getting info for app - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished getting app info - {result}')

        return result

    def get_app_challenge_state_id(self, app_uuid):
        url = f'{self.idaptive_session.base_url}/uprest/HandleAppClick?appkey={app_uuid}'
        logger.info(f'getting app challenge state id - {url}')
        result = self.idaptive_session.rest_client.get(url)
        logger.info(f'finished getting app challenge state id - {result}')

        return result

    def modify_application_shortcuts(self, payload):
        logger.info('Modifying application shortcuts in portal - {}/uprest/ModifyApplicationShortcuts - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/uprest/ModifyApplicationShortcuts'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )
        logger.info('Modify Application Shortcuts completed - {}'.format(result))
        return result

    def setup_app_creds(self, app_key, payload):
        logger.info('Modifying application shortcuts in portal - {}/uprest/SetUserCredsForApp?appkey=@~/apps/{}'
            .format(self.idaptive_session.base_url, app_key)
        )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/uprest/SetUserCredsForApp?appkey=@~/apps/{}'.format(self.idaptive_session.base_url, app_key),
                payload
            ).json()
        )

        logger.info('Setup application Credentials completed - {}'.format(result))
        return result

    def launch_app_from_up(self, app_name):
        url = f'{self.idaptive_session.base_url}/uprest/HandleAppClick?appkey=@~/apps/{app_name}'
        result = self.idaptive_session.rest_client.get(url)
        logger.info(f'finished launch app - {result}')
        return result   