from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class TenantConfig:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def set_admin_security_question(self, question):
        payload = {'Question': str(question)}
        url = f'{self.idaptive_session.base_url}/TenantConfig/SetAdminSecurityQuestion'

        logger.info('Setting admin security question - {} - {}'
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Attempt to set security question complete - {}'.format(result))
        return result

    def get_admin_security_questions(self):
        payload = {
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": False,
                "Caching": -1
            }}

        url = f'{self.idaptive_session.base_url}/TenantConfig/GetAdminSecurityQuestions'

        logger.info('Getting admin security questions - {} - {}'
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Attempt to retrieve security questions complete - {}'.format(result))
        return result

    def delete_admin_security_question(self, uuid):
        payload = {'id': uuid}
        url = f'{self.idaptive_session.base_url}/TenantConfig/DeleteAdminSecurityQuestion'

        logger.info('Deleting admin security question - {} - {}'
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Attempt to delete security question complete - {}'.format(result))
        return result

    def set_ui_settings(self, **kwargs):
        payload = {
            "uisection": {
                "quickStartWizardKey": {
                    "WEB_APP_ADDED_KEY": False,
                    "INVITES_SENT_KEY": False,
                    "MOBILE_APP_ADDED_KEY": False,
                    "USER_CREATED_KEY": False
                },
                "nav-part-Apps-expanded": True,
                "nav-part-Core-Services-expanded": True,
                "nav-part-Settings-expanded": True,
                "doNotShowQuickstart": True,
                "nav-part-Infrastructure-expanded": True,
                "showedOTPQRCode": True
            },
            **kwargs
        }

        url = f'{self.idaptive_session.base_url}/TenantConfig/SetUISettings'

        logger.info(f'setting ui settings - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished setting ui settings - {result}')

        return result
    
    def set_otp_code_length(self, length):
        payload = {'OtpCodeLength': length}
        url = f'{self.idaptive_session.base_url}/TenantConfig/SetCustomerConfig'

        logger.info('Set OTP code length - {} - {}'
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Set OTP code length - {}'.format(result))
        return result

    def get_otp_code_length(self):
        url = f'{self.idaptive_session.base_url}/TenantConfig/getCustomerConfig'

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                ""
            ).json()
        )

        logger.info('Get OTP code length - {}'.format(result))
        return result
