from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)



class SchedulerHistory:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_job_details(self, payload):
        logger.info('getting job status - {}/SchedulerHistory/GetJobReport - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SchedulerHistory/GetJobReport'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('get job status complete - {}'.format(result))
        return result

    def delete_job_history(self, payload):
        logger.info('deleting job history - {}/SchedulerHistory/DeleteJobHistory - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/SchedulerHistory/DeleteJobHistory'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('job history delete requested - {}'.format(result))
        return result
