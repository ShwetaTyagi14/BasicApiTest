from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class UserMgmt:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def reset_user_password(self, payload):
        logger.info('resetting user password - {}/UserMgmt/ResetUserPassword - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/UserMgmt/ResetUserPassword'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('user password reset - {}'.format(result))
        return result

    def remove_users(self, payload):
        logger.info('removing cloud users - {}/UserMgmt/RemoveUsers - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/UserMgmt/RemoveUsers'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('cloud users removed - {}'.format(result))
        return result

    def get_user_attributes(self, payload):
        logger.info('getting ad user attributes - {}/UserMgmt/GetUserAttributes - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/UserMgmt/GetUserAttributes'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('ad attributes received - {}'.format(result))
        return result

    def get_user_info(self):
        url = f'{self.idaptive_session.base_url}/UserMgmt/GetUserInfo'
        logger.info('getting user info - {}'
                    .format(url)
                    )

        result = self.idaptive_session.rest_client.post(
                url
            ).json()

        logger.info('user info received - {}'.format(result))

        return result

    def get_security_questions(self, add_admin_questions=False):
        url = f'{self.idaptive_session.base_url}/UserMgmt/GetSecurityQuestions'
        if add_admin_questions:
            url = url + '?addAdminQuestions=true'

        logger.info('Retrieving Security Questions for current user - {}'
                    .format(url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url
            ).json()
        )

        logger.info('Security Question retrieval complete - {}'.format(result))

        return result

    def update_security_questions(self, payload):
        url = f'{self.idaptive_session.base_url}/UserMgmt/UpdateSecurityQuestions'
        logger.info('Updating security questions - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Security Question Update complete - {}'.format(result))

        return result

    def set_phone_pin(self, user_uuid, phone_pin):
        payload = {
            "ID": user_uuid,
            "phonepin": phone_pin
        }

        url = f'{self.idaptive_session.base_url}/UserMgmt/SetPhonePin'

        logger.info('Setting phone pin - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Phone pin complete - {}'.format(result))

        return result

    def end_user_mfa_policy_checks(self, payload = {
                "policies": ["/Core/Security/CDS/ExternalMFA/ShowQRCodeForSelfService",
                             "/Core/Security/CDS/ExternalMFA/ShowU2f"]
            }):
        
        url = f'{self.idaptive_session.base_url}/Policy/PolicyChecks'
        logger.info('Retrieving PolicyChecks - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('PolicyChecks retrieval attempt complete - {}'.format(result))
        return result
    
    def update_user_password(self, payload):
        url = f'{self.idaptive_session.base_url}/UserMgmt/ChangeUserPassword'
        logger.info('Updating User Password - {} - {} '
                .format(url, payload)
                )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
            url,
            payload
            ).json()
        )
        logger.info('Update User Password complete - {}'.format(result))
        return result

    def invite_user(self, payload):
        url = f'{self.idaptive_session.base_url}/UserMgmt/InviteUsers'
        logger.info('Inviting user - {} - {} '
                .format(url, payload)
                )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
            url,
            payload
            ).json()
        )
        logger.info('Inviting user complete - {}'.format(result))
        return result
    