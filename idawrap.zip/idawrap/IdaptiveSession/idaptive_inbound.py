from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Inbound:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def delete_instance(self, payload):
        logger.info('removing provisioning source - {}/InboundProv/DeleteInstance - {} '
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/DeleteInstance'.format(self.idaptive_session.base_url),
                payload
            )
        )

        logger.info('removal of source completed - {}'.format(result))
        return result

    def ping_inbound(self):
        logger.info('pinging centrify session - {}/InboundProv/Ping'
                    .format(self.idaptive_session.base_url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post('{}/InboundProv/Ping'.format(self.idaptive_session.base_url)).json()
        )

        logger.info('ping complete - {}'.format(result))
        return result

    def query_all_instances(self):
        logger.info('querying available instances {}/InboundProv/QueryInstances'
                    .format(self.idaptive_session.base_url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/QueryInstances'.format(self.idaptive_session.base_url)
            ).json()
        )

        logger.info('query Instances complete - {}'.format(result))
        return result

    def query_supported_providers(self):
        logger.info('querying available providers - {}/InboundProv/QuerySupportedProviders'
                    .format(self.idaptive_session.base_url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/QuerySupportedProviders'.format(self.idaptive_session.base_url)
            ).json()
        )

        logger.info('query Providers complete - {}'.format(result))
        return result

    def save_rule(self, payload):
        logger.info('saving provisioning rule - {}/InboundProv/SaveRule - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/SaveRule'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('save of provisioning rule complete - {}'.format(result))
        return result

    def save_source(self, payload):
        logger.info('saving provisioning source - {}/InboundProv/SaveInstance - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/SaveInstance'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('save of provisioning source complete - {}'.format(result))
        return result

    def start_sync_job(self, payload):
        logger.info('requesting inbound synchronize job - {}/InboundProv/StartSyncJob - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/StartSyncJob'.format(self.idaptive_session.base_url),
                payload
            )
        )

        logger.info('sync job requested - {}'.format(result))
        return result

    def verify_read_creds(self, payload):
        logger.info('verifying third party credentials - {}/InboundProv/VerifyWorkdayReadCreds - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/InboundProv/VerifyWorkdayReadCreds'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('credential verification complete - {}'.format(result))
        return result
