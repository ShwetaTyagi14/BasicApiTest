from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class LAPM:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def checkout_password(self, vault_id):
        payload = {'ID': vault_id}

        logger.info('checking out lapm password - {}/ServerManage/CheckoutPassword'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/ServerManage/CheckoutPassword'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('checking out lapm password complete - {}'
                    .format(result)
                    )

        return result

    def extend_password(self, lapm_checkout_id):
        payload = {'ID': lapm_checkout_id}

        logger.info('extending lapm password - {}/ServerManage/ExtendCheckout'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/ServerManage/ExtendCheckout'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('extending lapm password complete - {}'
                    .format(result)
                    )

        return result

    def checkin_password(self, lapm_checkout_id):
        payload = {'ID': lapm_checkout_id}

        logger.info('checking-in lapm password - {}/ServerManage/CheckinPassword'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/ServerManage/CheckinPassword'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('checking-in lapm password complete - {}'
                    .format(result)
                    )

        return result
