import requests
import logging
import bs4 as bs
import json

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class AnalyticsManage:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session
        self.cookies = None

    def get_event_trigger_list(self, url, bearer):
        logger.info('retrieving event triggers - https://{}/analytics/services/v1.0/rules'
                    .format(url)
                    )

        result = self.idaptive_session.rest_client.get(
            f'https://{url}/analytics/services/v1.0/rules',
            headers={'authorization': 'Bearer {}'.format(bearer)}
        )

        return result

    def delete_event_trigger(self, url, bearer, policy_id):
        logger.info('retrieving event triggers - https://{}/analytics/services/v1.0/rules/{}'
                    .format(url, policy_id)
                    )

        headers = {"Authorization": "Bearer {}".format(bearer),
                   'content-type': 'application/json'}
        url = f'https://{url}/analytics/services/v1.0/rules/{policy_id}'

        result = self.idaptive_session.rest_client.delete(url=url, headers=headers)

        return result.status_code

    def create_event_trigger(self, analytic_base_url, bearer, payload, trigger_type):
        if trigger_type == 'lock-user':
            endpoint_url = '/analytics/services/v1.0/rules/lock-user'
        elif trigger_type == 'webhook':
            endpoint_url = '/analytics/services/v1.0/rules/webhook'
        else:
            endpoint_url = '/analytics/services/v1.0/rules/email'

        logger.info('creating event triggers - https://{}{}'.format(analytic_base_url, endpoint_url))
        endpoint_url = f'https://{analytic_base_url}{endpoint_url}'
        headers = {"Authorization": f"Bearer {bearer}",
                   'content-type': 'application/json'}
        result = self.idaptive_session.rest_client.post(endpoint_url, payload=payload, headers=headers)

        return result.status_code

    def get_access_token_through_standalone(self, tenant_id, user_info):
        analytic_base_url = user_info['analytic_base_url']
        data = {"tenant_id": tenant_id,
                "user_name": user_info['analytic_username'],
                "password": user_info['analytic_password'],
                "redirect_uri": ""}
        endpoint = f"https://{analytic_base_url}/analytics/services/v1.0/users/login2"

        page = requests.post(endpoint, data=data)
        if page.status_code == 200:
            # Parsing the access token
            soup = bs.BeautifulSoup(page.text, 'lxml')
            dynamic_access_token = soup.body.contents[1].string.split('\"')[1]
            return dynamic_access_token
        else:
            assert False, 'No access token is provided in return page'

    def get_access_token_through_portal(self, tenant_id, user_info, app_uuid):

        login_url = '{}/security/Login'.format(user_info['base_url'])
        payload = {'systemID': tenant_id, 'user': user_info['username'], 'password': user_info['password']}
        req = requests.get(url=login_url, params=payload, verify=True)
        self.cookies = req.cookies

        rest_call_url = '{}/uprest/HandleAppClick?appkey={}'.format(user_info['base_url'], app_uuid)
        app_url_result = requests.get(url=rest_call_url, cookies=req.cookies)
        saml_token = app_url_result.text.split('value')[1].split('\"')[1]

        rest_call_url = 'https://{}/analytics/callback?client_name=MySAML2Client'.format(user_info['analytic_base_url'])
        data = {'SAMLResponse': saml_token}
        header = {'Host': user_info['analytic_base_url'],
                  'Origin': user_info['base_url']}

        page = requests.post(url=rest_call_url, data=data, headers=header, cookies=req.cookies)
        if page.status_code != 200:
            assert False, 'Bad response {} {}'.format(page.status_code, page.text)
        else:
            soup = bs.BeautifulSoup(page.text, 'lxml')
            try:
                access_token = soup.body.contents[1].string.split('\"')[3]
                return access_token
            except Exception as e:
                assert False, 'Issue getting access token from string {}, Error: {}'.format(soup, e)

    def get_access_token_through_sso(self, tenant_id, user_info):

        login_url = '{}/security/Login'.format(user_info['base_url'])
        payload = {'systemID': tenant_id,
                   'user': user_info['analytic_username'],
                   'password': user_info['analytic_password']}
        req = requests.get(url=login_url, params=payload, verify=True)
        self.cookies = req.cookies

        rest_call_url = '{}/run?appkey=_I18N_AdaptiveMfaPortal_DisplayName&customerId={}&yfirtnecrun=true' \
            .format(user_info['base_url'], user_info['tenant_id'])
        app_url_result = requests.get(url=rest_call_url, cookies=req.cookies)
        saml_token = app_url_result.text.split('value')[1].split('\"')[1]

        rest_call_url = 'https://{}/analytics/callback?client_name=MySAML2Client'.format(user_info['analytic_base_url'])
        data = {'SAMLResponse': saml_token}
        header = {'Host': user_info['analytic_base_url'],
                  'Origin': user_info['base_url']}

        page = requests.post(url=rest_call_url, data=data, headers=header, cookies=req.cookies)
        if page.status_code != 200:
            assert False, 'Bad response {} {}'.format(page.status_code, page.text)
        else:
            soup = bs.BeautifulSoup(page.text, 'lxml')
            try:
                access_token = soup.body.contents[1].string.split('\"')[1]
                return access_token
            except Exception as e:
                assert False, 'Issue getting access token from string {}, Error: {}'.format(soup, e)

    def logout_analytics(self, url, bearer):
        result = self.idaptive_session.rest_client.post(
            f'https://{url}/analytics/services/v1.0/users/logout',
            headers={'authorization': 'Bearer {}'.format(bearer)}
        )

        return result

    @staticmethod
    def analytics_crud_operation(header, **kwargs):

        headers = {'Authorization': f'Bearer {kwargs["bearer"]}',
                   'content-type': 'application/json'}

        if header is not None:
            for key in header:
                headers[key] = header[key]

        if 'files' in kwargs:
            files = kwargs['files']
        else:
            files = None

        response = requests.request(kwargs['operation'],
                                    kwargs['endpoint'],
                                    data=json.dumps(kwargs['payload']),
                                    headers=headers,
                                    files=files)
        return response
