from Utilities.serializer import Serializer

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Provisioning:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def sync_all(self, payload):
        logger.info('requesting full provisioning sync - {}/Provisioning/FullDirSyncAll'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
                '{}/Provisioning/FullDirSyncAll'.format(self.idaptive_session.base_url),
                payload
            ).json()

        logger.info('full provisioning sync request complete - {}'
                    .format(result)
                    )

        return result

    def save_notification_settings(self, payload):
        logger.info('saving notification settings - {}/Provisioning/SaveNotificationSettings'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/Provisioning/SaveNotificationSettings'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('notification settings saved - {}'
                    .format(result)
                    )

        return result

    def sync_user(self, user_id):
        logger.info('saving notification settings - {}/Provisioning/SaveNotificationSettings'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/Provisioning/SyncUser?id={}'.format(self.idaptive_session.base_url, user_id)
        ).json()

        logger.info('notification settings saved - {}'
                    .format(result)
                    )

        return result
