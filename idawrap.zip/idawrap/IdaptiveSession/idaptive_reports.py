from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


# TODO Need to add method to call api to delete role
class Reports:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def write_report(self, payload):
        logger.info('writing report - {}/Core/WriteFile - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/WriteFile'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('report written - {}'.format(result))
        return result

    def delete_report(self, payload):
        logger.info('deleting report - {}/Core/DeleteFile - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/DeleteFile'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('report deleted - {}'.format(result))
        return result

    def export_report(self, payload):
        logger.info('exporting report - {}/redrock/export1 - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )
        result = self.idaptive_session.rest_client.post(
                '{}/redrock/export1'.format(self.idaptive_session.base_url),
                payload
            )

        logger.info('report exported - {}'.format(result))
        return result

    def email_report(self, payload):
        logger.info('emailing report - {}/task/emailreport - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/task/emailreport'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('report emailed - {}'.format(result))
        return result

    def create_directory(self, payload):
        logger.info('creating report - {}/Core/CreateDirectory - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/CreateDirectory'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('directory created - {}'.format(result))
        return result
    
    def delete_directory(self, payload):
        logger.info('deleting report - {}/Core/DeleteDirectory - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/DeleteDirectory'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('directory deleted - {}'.format(result))
        return result
    
    def assign_directory_rights_to_roles(self, payload):
        logger.info('assigning directory rights to roles - {}/Core/AssignDirectoryRightsToRoles - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/AssignDirectoryRightsToRoles'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('assigned directory rights to roles - {}'.format(result))
        return result
    
    def get_report_info(self, payload):
        logger.info('executing get report info - {}/Core/GetFileInfo - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/GetFileInfo'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('get report info executed - {}'.format(result))
        return result

    def get_directory_info(self, payload):
        logger.info('executing get directory info - {}/Core/GetDirectoryInfo - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/GetDirectoryInfo'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('get directory info executed - {}'.format(result))
        return result

    def get_effective_report_rights(self, payload):
        logger.info('executing get effective report rights - {}/Acl/GetEffectiveFileRights - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Acl/GetEffectiveFileRights'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('get effective report rights - {}'.format(result))
        return result

    def update_report_rights(self, payload):
        logger.info('executing update report rights - {}/Acl/UpdateFileAces - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Acl/UpdateFileAces'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('update report rights - {}'.format(result))
        return result
    
    def get_directory_role_and_rights(self, payload):
        logger.info('get directory roles and rights - {}/Core/GetDirectoryRolesAndRights - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/GetDirectoryRolesAndRights'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('get directory roles and rights - {}'.format(result))
        return result

    def get_directory_contents(self, payload):
        logger.info('executing get directory info - {}/Core/GetDirectoryContents - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/GetDirectoryContents'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )
        logger.info('get directory cont executed - {}'.format(result))
        return result
    
    def rename_directory(self, payload):
        logger.info('rename directory started - {}/Core/MoveDirectory - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/Core/MoveDirectory'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('rename directory completed - {}'.format(result))
        return result
