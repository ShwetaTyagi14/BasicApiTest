from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class Policy:
    policy_blocks = {}
    plinks = None
    revstamp = None

    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_policy_block(self, policy_name="Default Policy", **kwargs):
        payload = {
            'name': f"/Policy/{policy_name}",
            **kwargs
        }
        url = f'{self.idaptive_session.base_url}/Policy/GetPolicyBlock'
        logger.info('Retrieving Policy Block - {} - {} '
                    .format(url, payload)
                    )

        result = self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()

        if result['success']:
            self.policy_blocks[policy_name] = result['Result']
            self.revstamp = result['Result']['RevStamp']

        logger.info('Policy Block retrieval attempt complete - {}'.format(result))
        return result

    def get_nice_plinks(self, **kwargs):
        payload = {
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                **kwargs
            }
        }

        url = f'{self.idaptive_session.base_url}/Policy/GetNicePlinks'
        logger.info('Retrieving Nice Plinks - {} - {} '
                    .format(url, payload)
                    )

        result = self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()

        if result['success']:
            self.plinks = result['Result']

        logger.info('Nice Plink retrieval attempt complete - {}'.format(result))
        return result

    def set_default_profile(self, profile_name, uuid=None, policy_name='Default Policy', profile_payload=None):
        if policy_name not in self.policy_blocks:
            self.get_policy_block(policy_name=policy_name)
        if profile_name and not uuid:
            uuid = self.get_profile_uuid_using_name(profile_name, profile_payload=profile_payload)

        if uuid:
            self.policy_blocks[policy_name]['Settings']['/Core/Authentication/AuthenticationRulesDefaultProfileId'] = \
                uuid
            self.update_policy(policy_name=policy_name, settings=self.policy_blocks[policy_name]['Settings'])

    def get_profile_uuid_using_name(self, profile_name, profile_payload=None):
        profile_list = self.idaptive_session.auth_profile.get_profile_list().Result
        for profile in profile_list:
            if profile.Name == profile_name:
                return profile.Uuid
        if profile_payload:
            result = self.idaptive_session.auth_profile.save_profile(**profile_payload['settings'])
            if result.success is True:
                return result.Result.Uuid
        return None

    def save_policy_block_2(self, payload, policy_name="Default Policy"):
        full_policy_name = f"/Policy/{policy_name}"
        url = f'{self.idaptive_session.base_url}/Policy/SavePolicyBlock2?name={full_policy_name}'
        logger.info('Saving policy block - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Policy save attempt complete - {}'.format(result))
        return result

    def update_policy(self, policy_name, settings, plink_update={}):
        self.get_policy_block(policy_name=policy_name)
        self.get_nice_plinks()

        plinks = self.massage_plinks(self.plinks)

        if plink_update:
            for i in range(len(plinks)):
                if plinks[i]['PolicySet'] == f"/Policy/{policy_name}":
                    plinks[i] = {**plinks[i], **plink_update}

        url = f'{self.idaptive_session.base_url}/Policy/SavePolicyBlock3'
        payload = {
            "policy": {
                "Newpolicy": False,
                "Path": f"/Policy/{policy_name}",
                "RevStamp": self.revstamp,
                "Description": f"Automation test policy {policy_name}",
                "Version": 1,
                "Settings": settings
            },
            "plinks": plinks
        }
        logger.info('Saving policy block - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Policy save attempt complete - {}'.format(result))
        return result

    def change_policy_setting(self, setting, value, policy_name="Default Policy"):
        self.get_policy_block(policy_name=policy_name)

        self.policy_blocks[policy_name]['Settings'][setting] = value

        return self.update_policy(policy_name=policy_name, settings=self.policy_blocks[policy_name]['Settings'])

    def delete_policy_setting(self, setting, policy_name):
        self.get_policy_block(policy_name=policy_name)

        self.policy_blocks[policy_name]['Settings'].pop(setting)

        return self.update_policy(policy_name=policy_name, settings=self.policy_blocks[policy_name]['Settings'])

    def update_via_policyblock2(self, policy_name="Default Policy", **kwargs):
        if policy_name not in self.policy_blocks:
            self.get_policy_block(policy_name=policy_name)
        if self.plinks is None:
            self.get_nice_plinks()
        payload = {
            'description': self.policy_blocks[policy_name]['Description'],
            'newpolicy': False,
            'path': f"/Policy/{policy_name}",
            'plinks': self.massage_plinks(self.plinks),
            'settings':
            {
                'Version': self.policy_blocks[policy_name]['Version'],
                'Settings': self.policy_blocks[policy_name]['Settings'],
                'AuthProfiles': self.policy_blocks[policy_name]['AuthProfiles'],
                'Path': self.policy_blocks[policy_name]['Path']
            },
            **kwargs
        }

        result = self.save_policy_block_2(payload=payload)

        return result

    def create_policy(self, policy_name, settings={}, plink={}):
        self.get_nice_plinks()

        plink = {
            "Description": "",
            "PolicySet": f"/Policy/{policy_name}",
            "LinkType": "Global",
            "Priority": 1,
            "Params": [],
            "Filters": [],
            "Allowedpolicies": [],
            **plink
        }

        plinks = [plink] + self.massage_plinks(self.plinks)

        url = f'{self.idaptive_session.base_url}/Policy/SavePolicyBlock3'
        payload = {
            "policy": {
                "Newpolicy": True,
                "Path": f"/Policy/{policy_name}",
                "Description": "",
                "Version": 1,
                "Settings": settings
            },
            "plinks": plinks
        }
        logger.info('Saving new policy - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('New policy save attempt complete - {}'.format(result))
        return result

    def delete_policy(self, policy_name):
        if '/Policy/' not in policy_name:
            policy_name = f'/Policy/{policy_name}'

        url = f'{self.idaptive_session.base_url}/Policy/DeletePolicyBlock'

        payload = {"path": policy_name}

        logger.info('Deleting policy block - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Policy delete attempt complete - {}'.format(result))

        return result

    def set_plinks(self, payload):
        url = f'{self.idaptive_session.base_url}/policy/setPlinksv2'

        logger.info(f'Setting plinks - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'Setting plinks complete - {result}')

        if result.success:
            self.revstamp = result.Result.RevStamp

        return result

    def change_policy_order(self, policy_name, new_index):

        if '/Policy/' not in policy_name:
            full_name = f"/Policy/{policy_name}"
        else:
            full_name = policy_name

        raw_plinks = self.get_nice_plinks()

        rev_stamp = raw_plinks['Result']['RevStamp']

        plinks = self.massage_plinks(raw_plinks['Result'])

        current_index = 0
        the_plink = None

        for i in range(len(plinks)):
            if plinks[i]['ID'] == full_name:
                current_index = i
                the_plink = plinks[i]
                break

        if the_plink is None:
            return None

        plinks.remove(the_plink)

        plinks.insert(new_index, the_plink)

        payload = {
            "Plinks": plinks,
            "RevStamp": rev_stamp
        }

        return self.set_plinks(payload)

    @staticmethod
    def massage_plinks(plink_result):
        if 'Results' in plink_result:
            rows = plink_result['Results']
        elif 'Result' in plink_result:
            rows = plink_result['Result']['Results']
        else:
            rows = plink_result

        plinks = []

        for i in range(len(rows)):
            plinks.append(rows[i]['Row'])
            plinks[i]['inode'] = ""
            plinks[i]['id'] = i + 1

        return plinks

    def check_policy(self, payload, policy_name="Default Policy"):
        url = f'{self.idaptive_session.base_url}/policy/PolicyChecks'
        logger.info('Check policy block - {} - {} '
            .format(url, payload)
        )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        return result