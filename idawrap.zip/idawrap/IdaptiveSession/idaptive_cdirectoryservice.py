from Utilities.serializer import Serializer
from io import BytesIO
from zipfile import ZipFile
import uuid

import logging
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class CDirectoryService:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def create_cloud_user(self, **kwargs):
        new_uuid = uuid.uuid4()
        payload = {
            "LoginName": f"test_user_creation_{new_uuid}",
            "Mail": "test@test.test",
            "DisplayName": "test",
            "Password": "testTEST1234",
            "confirmPassword": "testTEST1234",
            "PasswordNeverExpire": True,
            "ForcePasswordChangeNext": False,
            "InEverybodyRole": True,
            "OauthClient": False,
            "SendEmailInvite": False,
            "SendSmsInvite": False,
            "Description": "",
            "OfficeNumber": "",
            "HomeNumber": "",
            "MobileNumber": "",
            "fileName": "",
            "ID": "",
            "state": "None",
            "jsutil-checkbox-2233-inputEl": False,
            "ReportsTo": "Unassigned",
            "Name": f"test_user_creation_{new_uuid}@test.test",
            "CmaRedirectedUserUuid": None,
            **kwargs
        }
        
        logger.info('creating idaptive cloud user - {}/cdirectoryservice/createuser - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(self.idaptive_session.rest_client.post(
                '{}/cdirectoryservice/createuser'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('idaptive cloud user created - {}'.format(result))

        return result

    def refresh_ad_user_token(self, user_id):
        logger.info('refreshing idaptive ad user token - {}/cdirectoryservice/refreshtoken - {}'
                    .format(self.idaptive_session.base_url, user_id)
                    )

        payload = {'ID': user_id}

        result = self.idaptive_session.rest_client.param_post(
            '{}/cdirectoryservice/refreshtoken'.format(self.idaptive_session.base_url), params=payload
        )

        logger.info('idaptive ad user token refreshed - {}'.format(result))

        return result

    def change_user(self, payload=None, **kwargs):
        if payload is None:
            if 'payload' in kwargs:
                del kwargs['payload']
            payload = {
                "LoginName": None,
                "Mail": None,
                "DisplayName": None,
                "enableState": False,
                "PasswordNeverExpire": False,
                "ForcePasswordChangeNext": False,
                "InEverybodyRole": True,
                "OauthClient": False,
                "SendEmailInvite": False,
                "Description": "",
                "OfficeNumber": "",
                "HomeNumber": "",
                "MobileNumber": "",
                "fileName": "",
                "ID": None,
                "state": "None",
                "jsutil-checkbox-1454-inputEl": False,
                "ReportsTo": None,
                "Name": None,
                "Password": None,
                **kwargs
            }

        logger.info('updating idaptive cloud user - {}/cdirectoryservice/changeuser - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(self.idaptive_session.rest_client.post(
            '{}/cdirectoryservice/changeuser'.format(self.idaptive_session.base_url),
            payload
        ).json()
                                             )

        logger.info('idaptive cloud user updated - {}'.format(result))

        return result

    def set_user_state(self, **kwargs):
        payload = {
            "LoginName": None,
            "loginsuffixfield-1951-inputEl": None,
            "Mail": None,
            "DisplayName": None,
            "passwordCreationType": None,
            "enableState": True,
            "PasswordNeverExpire": False,
            "ForcePasswordChangeNext": False,
            "InEverybodyRole": False,
            "OauthClient": False,
            "Description": "",
            "OfficeNumber": "",
            "HomeNumber": "",
            "MobileNumber": "",
            "Picture": "",
            "fileName": "",
            "ID": None,
            "state": "Locked",
            "jsutil-checkbox-1996-inputEl": False,
            "ReportsTo": "Unassigned",
            **kwargs
        }

        logger.info('setting idaptive cloud user state - {}/cdirectoryservice/setuserstate - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(self.idaptive_session.rest_client.post(
            '{}/cdirectoryservice/setuserstate'.format(self.idaptive_session.base_url),
            payload
        ).json()
                                             )

        logger.info('idaptive cloud user state set - {}'.format(result))

        return result

    def get_users(self):
        url = f'{self.idaptive_session.base_url}/CDirectoryService/GetUsers'

        logger.info(f'getting users - {url}')

        raw_result = self.idaptive_session.rest_client.post(url, {})

        result = Serializer.deserialize_json(raw_result.json())

        logger.info(f'finished getting users - {result}')

        return result

    def mfa_unlock(self, uid):
        logger.info('MFA Unlock - {}/cdirectoryservice/ExemptUserFromMfa - {}'
                    .format(self.idaptive_session.base_url, uid)
                    )

        payload = {'ID': uid,
                   'systemId': ''}
        result = self.idaptive_session.rest_client.param_post(
            '{}/cdirectoryservice/ExemptUserFromMfa'.format(self.idaptive_session.base_url), params=payload
        )
        logger.info('MFA Unlock - {}'.format(result))
        time.sleep(10)
        return result
