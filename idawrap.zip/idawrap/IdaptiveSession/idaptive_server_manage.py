from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class ServerManage:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def set_administrative_accounts(self, payload):
        logger.info('setting administrative account - {}/ServerManage/SetAdministrativeAccounts - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/ServerManage/SetAdministrativeAccounts'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('administrative account set - {}'.format(result))
        return result
