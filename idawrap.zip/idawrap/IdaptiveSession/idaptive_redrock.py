from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class RedRock:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def execute_redrock_query(self, payload):
        logger.info('executing RedRock query - {}/RedRock/query - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/RedRock/query'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('RedRock query executed - {}'.format(result))
        return result
