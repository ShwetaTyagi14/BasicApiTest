from Utilities.serializer import Serializer

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Mobile:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_registered_mobile_devices(self, payload, active_only):
        logger.info('getting registered mobile devices - {}/Mobile/GetMyDevices?getActiveOnly={}'
                    .format(self.idaptive_session.base_url, active_only)
                    )

        result = self.idaptive_session.rest_client.post(
                '{}/Mobile/GetMyDevices?getActiveOnly={}'.format(self.idaptive_session.base_url, active_only),
                payload
            ).json()

        logger.info('get registered mobile devices complete - {}'
                    .format(result)
                    )

        return result

    def update_device_policies(self, device_ids):
        payload = {'deviceIds': device_ids}

        logger.info('updating device policies - {}/Mobile/updatedevicepolicy'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
                '{}/Mobile/updatedevicepolicy'.format(self.idaptive_session.base_url),
                payload
            ).json()

        logger.info('updating device policies complete - {}'
                    .format(result)
                    )

        return result

    def reapply_device_policy(self, device_ids):
        payload = {'deviceIds': device_ids}

        logger.info('reapplying device policies - {}/mobile/ReapplyDevicePolicy'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/mobile/ReapplyDevicePolicy'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('reapplying device policies complete - {}'
                    .format(result)
                    )

        return result

    def lock_device(self, device_id, passcode):
        payload = {'deviceID': device_id,
                   'passcode': passcode}

        logger.info('locking device - {}/mobile/lockdevice'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/mobile/lockdevice'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('locking device complete - {}'
                    .format(result)
                    )

        return result

    def unenroll_devices(self, device_ids):
        payload = {'deviceIds': device_ids}

        logger.info('unenrolling device - {}/mobile/removedeviceprofile'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
            '{}/mobile/removedeviceprofile'.format(self.idaptive_session.base_url),
            payload
        ).json()

        logger.info('unenrolling device complete - {}'
                    .format(result)
                    )

        return result

    def set_user_otp(self, otp_code, uuid):
        payload = {
            "otpCode": otp_code,
            "uuid": uuid
        }

        url = f"{self.idaptive_session.base_url}/mobile/ValidateAndSetUserThirdPartyOtp"

        logger.info(f'setting user third party otp - {url} {payload}')

        result = self.idaptive_session.rest_client.post(
            url,
            payload
        ).json()

        logger.info(f'finished setting user third party otp - {result}')

        return result

    def get_user_third_party_otp(self):
        url = f'{self.idaptive_session.base_url}/mobile/GetUserThirdPartyOtp'

        logger.info(f'getting user oath otp details - {url}')

        raw_result = self.idaptive_session.rest_client.post(
                url,
                {}
            )

        result = Serializer.deserialize_json(raw_result.json())

        logger.info(f'finished getting oath otp details - {result}')

        return result

    def ping_device(self, device_id):
        url = f'{self.idaptive_session.base_url}/mobile/pingdevice'

        payload = {
            'deviceId': device_id
        }

        logger.info(f'pinging device  - {url} - {payload}')

        result = self.idaptive_session.rest_client.post(
            url,
            payload
        ).json()

        logger.info(f'finished pinging device - {result}')

        return result

    def delete_device(self, device_ids):
        payload = {'deviceIds': device_ids}
        url = f'{self.idaptive_session.base_url}/mobile/deletedevice'

        logger.info(f'deleting devices - {url} - {payload}')

        result = self.idaptive_session.rest_client.post(
            url,
            payload
        ).json()

        logger.info('deleting devices complete - {}'
                    .format(result)
                    )

        return result

    def set_corporate_owned(self, device_ids):
        payload = {'deviceIds': device_ids}
        url = f'{self.idaptive_session.base_url}/mobile/SetCorporateOwned'

        logger.info(f'setting devices to be corporate owned - {url} - {payload}')

        result = self.idaptive_session.rest_client.post(url, payload).json()

        logger.info('setting devices to corporate owned complete - {}'.format(result))

        return result

    def set_personal_owned(self, device_ids):
        payload = {'deviceIds': device_ids}
        url = f'{self.idaptive_session.base_url}/mobile/SetPersonalOwned'

        logger.info(f'setting devices to be personal owned - {url} - {payload}')

        result = self.idaptive_session.rest_client.post(url, payload).json()

        logger.info('setting devices to personal owned complete - {}'.format(result))

        return result

    def email_link(self, email):
        payload = {'email': email}

        url = f'{self.idaptive_session.base_url}/Mobile/EmailLink'

        logger.info(f'emailing link - {url} - {payload}')

        result = self.idaptive_session.rest_client.post(url, payload).json()

        logger.info(f'emailing link complete - {result}')

        return result

    def text_link(self, phone):
        payload = {"phone": phone}

        url = f'{self.idaptive_session.base_url}/Mobile/TextLink'

        logger.info(f'texting link - {url} - {payload}')

        result = self.idaptive_session.rest_client.post(url, payload).json()

        logger.info(f'texting link complete - {result}')

        return result

    def get_user_and_app_store_url_info(self):
        url = f'{self.idaptive_session.base_url}/Mobile/GetUserAndAppStoreUrlInfo'

        logger.info(f'requesting user app store url info - {url}')

        result = self.idaptive_session.rest_client.post(url).json()

        logger.info(f'requesting user app store url info complete - {result}')

        return result

    def get_apns_cert_expiration(self):
        url = f'{self.idaptive_session.base_url}/mobile/GetApnsCertExpiration'

        logger.info(f'getting apns cert expiration - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(url).json()
        )

        logger.info(f'finished getting apns cert expiration - {result}')

        return result

    def upload_existing_push_cert(self, certificate, password):
        file = {'pkcs12Field': certificate}

        payload = {'uploadPassword': password}

        url = f'{self.idaptive_session.base_url}/mobile/UploadExistingPushCert'

        logger.info(f'uploading protected APNS cert - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.multi_post(url, file, payload).json()
        )

        logger.info(f'finished uploading protected APNS cert - {result}')

        return result

    def upload_mdm_csr_result(self, certificate):
        file = {'portalFileResponse': certificate}

        url = f'{self.idaptive_session.base_url}/mobile/UploadMdmCsrResult'

        logger.info(f'uploading APNS cert - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.multi_post(url, file).json()
        )

        logger.info(f'finished uploading APNS cert - {result}')

        return result
