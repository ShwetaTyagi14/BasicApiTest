from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class UserProv:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def run_script(self, payload):
        logger.info('running user provisioning script - {}/UserProv/RunScript - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/UserProv/RunScript'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('provisioning script complete - {}'.format(result))
        return result

    def get_app(self, payload):
        logger.info('getting app details - {}/UserProv/GetApp - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/UserProv/GetApp'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('app details retrieved - {}'.format(result))
        return result

    def update_app(self, payload):
        logger.info('updating application - {}/UserProv/UpdateApp - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                '{}/UserProv/UpdateApp'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('application updated- {}'.format(result))
        return result
