from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class Security:
    mechanisms = None

    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def advance_authentication(self, **kwargs):
        payload = {
            'TenantId': self.idaptive_session.tenant_id,
            'Action': 'Answer',
            'PersistentLogin': True,
            'SessionId': self.idaptive_session.session_id,
            'MechanismId': self.idaptive_session.pass_mech_id,
            'Answer': self.idaptive_session.password,
            **kwargs
        }

        url = f'{self.idaptive_session.base_url}/Security/AdvanceAuthentication'
        logger.info('Advancing authentication session- {} - {} '
                    .format(url, payload)
                    )

        result = self.idaptive_session.rest_client.post(url, payload)

        if result.ok:
            self.idaptive_session.cookies = result.cookies
            self.idaptive_session.auth_details = Serializer.deserialize_json(result.json())
            if self.idaptive_session.auth_details.Result.Summary == "LoginSuccess":
                self.idaptive_session.user_id = self.idaptive_session.auth_details.Result.UserId


        logger.info('Authentication advanced for session - {}'.format(result))
        return self.idaptive_session.auth_details

    def cleanup_authentication(self, **kwargs):
        payload = {
            'TenantId': self.idaptive_session.tenant_id,
            'SessionId': self.idaptive_session.session_id,
            **kwargs
        }
        url = f'{self.idaptive_session.base_url}/Security/CleanupAuthentication'
        logger.info('Cleaning up authentication session - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Authentication session cleanup finished - {}'.format(result))
        return result

    def logout(self, **kwargs):
        payload = {
            'Authorization': self.idaptive_session.auth_details.Result.Auth,
            **kwargs
        }
        url = f'{self.idaptive_session.base_url}/Security/Logout'
        logger.info('Logging out of Authentication session - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Finished logging out of session - {}'.format(result))
        return result

    def on_demand_challenge(self, **kwargs):
        payload = {
            'User': self.idaptive_session.username,
            'PolicyModifier': None,
            **kwargs
        }
        url = f'{self.idaptive_session.base_url}/Security/OnDemandChallenge'
        logger.info('Performing MFA on behalf of user - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Finished Performing MFA on behalf of user - {}'.format(result))
        return result

    def refresh_token(self):
        url = f'{self.idaptive_session.base_url}/Security/RefreshToken'
        logger.info('Reloading cached identity from directory service - {}'
                    .format(url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url
            ).json()
        )

        logger.info('Finished reloading cached identity from directory service - {}'.format(result))
        return result

    def start_authentication(self, **kwargs):
        payload = {
            'TenantId': self.idaptive_session.tenant_id,
            'Version': '1.0',
            'User': self.idaptive_session.username,
            'ApplicationId': None,
            'MfaRequestor': None,
            **kwargs
        }
        url = f'{self.idaptive_session.base_url}/Security/StartAuthentication'
        logger.info('Starting authentication session - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        if result.success:
            self.idaptive_session.challenge_details = result
            self.idaptive_session.session_id = self.idaptive_session.challenge_details.Result.SessionId
            if result.Result.Challenges[0].Mechanisms[0].PromptSelectMech == 'Password':
                self.idaptive_session.pass_mech_id = result.Result.Challenges[0].Mechanisms[0].MechanismId

        logger.info('Authentication session started - {}'.format(result))
        return result

    def get_authenticated_user(self):
        url = f'{self.idaptive_session.base_url}/Security/whoami'
        logger.info('Getting information about the currently authenticated user - {}'
                    .format(url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url
            ).json()
        )

        logger.info('User information request finished - {}'.format(result))
        return result

    def start_challenge(self, challenge_id):
        url = f'{self.idaptive_session.base_url}/Security/StartChallenge'
        payload = {
            'TenantId': self.idaptive_session.tenant_id,
            'Version': '1.0',
            'User': self.idaptive_session.username,
            'AssociatedEntityType': 'Portal',
            'AssociatedEntityName': 'Portal',
            'ExtIdpAuthChallengeState': '',
            'ChallengeStateId': challenge_id
        }
        logger.info('Starting challenge session - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        if result.success:
            self.idaptive_session.challenge_details = result
            self.idaptive_session.session_id = self.idaptive_session.challenge_details.Result.SessionId
            if result.Result.Challenges[0].Mechanisms[0].PromptSelectMech == 'Password':
                self.idaptive_session.pass_mech_id = result.Result.Challenges[0].Mechanisms[0].MechanismId

        logger.info('Challenge session started - {}'.format(result))
        return result
