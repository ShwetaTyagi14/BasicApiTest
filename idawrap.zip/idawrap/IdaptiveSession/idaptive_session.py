from IdaptiveSession.idaptive_cdirectoryservice import CDirectoryService
from IdaptiveSession.idaptive_core import Core
from IdaptiveSession.idaptive_inbound import Inbound
from IdaptiveSession.idaptive_mobile import Mobile
from IdaptiveSession.idaptive_provisioning import Provisioning
from IdaptiveSession.idaptive_redrock import RedRock
from IdaptiveSession.idaptive_roles import Roles
from IdaptiveSession.idaptive_saas_manage import SaasManage
from IdaptiveSession.idaptive_scheduler_history import SchedulerHistory
from IdaptiveSession.idaptive_server_manage import ServerManage
from IdaptiveSession.idaptive_sysinfo import SysInfo
from IdaptiveSession.idaptive_task import Task
from IdaptiveSession.idaptive_user_management import UserMgmt
from IdaptiveSession.idaptive_user_prov import UserProv
from IdaptiveSession.idaptive_security import Security
from IdaptiveSession.idaptive_authprofile import AuthProfile
from IdaptiveSession.idaptive_policy import Policy
from IdaptiveSession.idaptive_tenant_config import TenantConfig
from IdaptiveSession.idaptive_lapm import LAPM
from IdaptiveSession.idaptive_oath import Oath
from IdaptiveSession.idaptive_o365 import Office365
from Utilities.latent_class import LatentClass
from RestWrapper.rest import Rest
from idaptive_automation.api_client.client.api_session import ApiSession
from IdaptiveSession.idaptive_analytics import AnalyticsManage
from IdaptiveSession.idaptive_reports import Reports


import logging
import sys

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class IdaptiveSession(ApiSession):
    def __init__(self, base_url, tenant_id, username, password, start_auth=True, auto_auth=True, auto_init=True,
                 **kwargs):
        super().__init__(base_url, tenant_id, username, password, start_auth, auto_auth)
        if 'headers' in kwargs and isinstance(kwargs.get('headers'), dict):
            self.headers = {**self.headers, **kwargs.get('headers')}
        self.session_id = None
        self.rest_client = Rest(self.headers)
        self.pass_mech_id = None
        self.security = Security(self)
        self.analytics_manage = AnalyticsManage(self)

        if start_auth:
            self.security.start_authentication()

        if auto_auth:
            self.security.advance_authentication()

        self.inbound = Inbound(self) if auto_init else LatentClass(Inbound, self)
        self.mobile = Mobile(self) if auto_init else LatentClass(Mobile, self)
        self.scheduler_history = SchedulerHistory(self) if auto_init else LatentClass(SchedulerHistory, self)
        self.core = Core(self) if auto_init else LatentClass(Core, self)
        self.saas_manage = SaasManage(self) if auto_init else LatentClass(SaasManage, self)
        self.roles = Roles(self) if auto_init else LatentClass(Roles, self)
        self.user_prov = UserProv(self) if auto_init else LatentClass(UserProv, self)
        self.provisioning = Provisioning(self) if auto_init else LatentClass(Provisioning, self)
        self.task = Task(self) if auto_init else LatentClass(Task, self)
        self.red_rock = RedRock(self) if auto_init else LatentClass(RedRock, self)
        self.user_management = UserMgmt(self) if auto_init else LatentClass(UserMgmt, self)
        self.cdirectory_service = CDirectoryService(self) if auto_init else LatentClass(CDirectoryService, self)
        self.auth_profile = AuthProfile(self) if auto_init else LatentClass(AuthProfile, self)
        self.policy = Policy(self) if auto_init else LatentClass(Policy, self)
        self.tenant_config = TenantConfig(self) if auto_init else LatentClass(TenantConfig, self)
        self.lapm = LAPM(self) if auto_init else LatentClass(LAPM, self)
        self.oath = Oath(self) if auto_init else LatentClass(Oath, self)
        self.sysinfo = SysInfo(self) if auto_init else LatentClass(SysInfo, self)
        self.server_manage = ServerManage(self) if auto_init else LatentClass(ServerManage, self)
        self.o365 = Office365(self) if auto_init else LatentClass(Office365, self)
        self.reports = Reports(self) if auto_init else LatentClass(Reports, self)
