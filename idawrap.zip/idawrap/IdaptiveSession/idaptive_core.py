from Utilities.serializer import Serializer
from io import BytesIO
from zipfile import ZipFile

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class Core:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_directory_services(self, payload):
        logger.info('getting active directory services - {}/Core/GetDirectoryServices - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(self.idaptive_session.rest_client.post(
                '{}/Core/GetDirectoryServices'.format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('active directory services received - {}'.format(result))

        return result

    def get_ou_tree_contents(self, payload, admin_account_status):
        logger.info('getting ou tree contents - {}/Core/GetOUTreeContents?getAdminAccountStatus={} - {}'
                    .format(self.idaptive_session.base_url, admin_account_status, payload)
                    )

        result = Serializer.deserialize_json(self.idaptive_session.rest_client.post(
                '{}/Core/GetOUTreeContents?getAdminAccountStatus={}'
                .format(self.idaptive_session.base_url, admin_account_status),
                payload
            ).json()
         )

        logger.info('ou tree contents received - {}'.format(result))

        return result

    def get_domain_controllers_for_domain(self, payload):
        logger.info('getting domain controllers for domain - {}/Core/GetDomainControllersForDomain - {}'
                    .format(self.idaptive_session.base_url, payload)
                    )

        result = Serializer.deserialize_json(self.idaptive_session.rest_client.post(
                '{}/Core/GetDomainControllersForDomain'
                .format(self.idaptive_session.base_url),
                payload
            ).json()
        )

        logger.info('domain controllers for domain received - {}'.format(result))

        return result

    def download_sync_job_report(self, file_path):
        logger.info('downloading file from {} - {}'.format(self.idaptive_session.base_url, file_path))
        url = '{}/Core/DownloadFile?path=/Traces/scheduler/{}'.format(self.idaptive_session.base_url, file_path)
        report_response = self.idaptive_session.rest_client.get(url)

        logger.info('parsing zip file')
        report = ZipFile(BytesIO(report_response.content))

        logger.info('sync job report successfully retrieved')
        return report

    def get_tenant_config(self, key, default=None):
        url = f'{self.idaptive_session.base_url}/Core/GetTenantConfig'

        payload = {
            "key": key
        }

        if default:
            payload["dflt"] = default

        logger.info(f'getting tenant config - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished getting tenant config {result}')

        return result

    def set_tenant_config(self, key, value):
        url = f'{self.idaptive_session.base_url}/Core/SetTenantConfig'

        payload = {
            "key": key,
            "value": value
        }

        logger.info(f'setting value in tenant config - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished setting value in tenant config {result}')

        return result

    def add_prem_detect_range(self, label, value):
        url = f'{self.idaptive_session.base_url}/Core/AddPremDetectRange'

        payload = {
            "Label": label,
            "value": value
        }

        logger.info(f'Adding prem detect range - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished adding prem detect range - {result}')

        return result

    def get_prem_detect_ranges(self, **kwargs):
        url = f'{self.idaptive_session.base_url}/Core/GetPremDetectRanges'

        payload = {
            "Args": {
                "PageNumber": 1,
                "PageSize": 100000,
                "Limit": 100000,
                "SortBy": "",
                "direction": "False",
                "Caching": -1,
                **kwargs
            }
        }

        logger.info(f'Getting prem detect range - {url} - {payload}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished getting prem detect range - {result}')

        return result

    def del_prem_detect_range(self, value):

        url = f'{self.idaptive_session.base_url}/core/DelPremDetectRange?systemId=&value={value}'

        logger.info(f'Deleting prem detect range - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                {}
            ).json()
        )

        logger.info(f'deletion of prem detect range complete - {result}')

        return result

    def get_tenant_aliases(self):
        payload = {}

        url = f'{self.idaptive_session.base_url}/core/GetCdsAliasesForTenant'

        logger.info(f'Getting aliases for tenant - {url}')

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info(f'finished getting aliases for tenant - {result}')

        return result
