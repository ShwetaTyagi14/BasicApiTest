from Utilities.serializer import Serializer
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)


class AuthProfile:
    auth_profiles = None

    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_profile_list(self):
        url = f'{self.idaptive_session.base_url}/AuthProfile/GetProfileList'
        logger.info('Getting the list of policies for the tenant - {}'
                    .format(url)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url
            ).json()
        )

        if result.success:
            self.auth_profiles = result.Result

        logger.info('Policies retrieved - {}'.format(result))
        return result

    def save_profile(self, **kwargs):
        payload = {
            'settings':
                {
                    'Uuid': None,
                    'Name': None,
                    'Challenges': [
                                      "UP"
                                  ],
                    **kwargs
                }
        }
        url = f'{self.idaptive_session.base_url}/AuthProfile/SaveProfile'
        logger.info('Saving an auth profile - {} - {} '
                    .format(url, payload)
                    )

        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Auth profile saving attempt complete - {}'.format(result))
        return result

    def delete_profile(self, uuid):
        payload = {'uuid': uuid}
        url = f'{self.idaptive_session.base_url}/AuthProfile/DeleteProfile'
        logger.info('Deleting auth profile - {} - {} '
                    .format(url, payload)
                    )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Auth profile delete attempt complete - {}'.format(result))
        return result

    def get_profile(self, uuid):
        payload = {'uuid': uuid}
        url = f'{self.idaptive_session.base_url}/AuthProfile/GetProfile'
        logger.info('Get auth profile - {} - {} '
                    .format(url, payload)
                    )
        result = Serializer.deserialize_json(
            self.idaptive_session.rest_client.post(
                url,
                payload
            ).json()
        )

        logger.info('Auth profile retrieve attempt complete - {}'.format(result))
        return result
