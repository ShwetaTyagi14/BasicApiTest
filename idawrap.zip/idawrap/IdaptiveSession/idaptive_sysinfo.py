from Utilities.serializer import Serializer

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(asctime)s:%(message)s')
filer_handler = logging.FileHandler('idaptive_session.log')
filer_handler.setFormatter(formatter)

logger.addHandler(filer_handler)


class SysInfo:
    def __init__(self, idaptive_session):
        self.idaptive_session = idaptive_session

    def get_about(self):
        logger.info('requesting system about info - {}/sysinfo/about'
                    .format(self.idaptive_session.base_url)
                    )

        result = self.idaptive_session.rest_client.post(
                '{}/sysinfo/about'.format(self.idaptive_session.base_url)
            ).json()

        logger.info('system about info retrieved - {}'
                    .format(result)
                    )

        return result
